#!/usr/bin/env bash

# Usage:
#   ./06-start-stack.sh                 # default: --chat mean
#   ./06-start-stack.sh --chat lean     # smollm2:135m, ~500MB VRAM
#   ./06-start-stack.sh --chat mean     # mistral-nemo:12b, ~7-8GB VRAM (default)
#   ./06-start-stack.sh --chat claw     # deepseek-r1:14b, ~9GB VRAM, full VRAM to reasoning
#
# CHAT lean:  smollm2:135m       (~500MB VRAM — dev/test)
# CHAT mean:  mistral-nemo:12b   (~7-8GB VRAM — general chat, default)
# CHAT claw:  deepseek-r1:14b    (~9GB VRAM — chain-of-thought reasoning, NemoClaw agent mode)
#             set CLAW_MODEL=phi4:14b in .env to switch to Phi-4 instead
#
# Stack: dashboard + ollama/bitnet + open-webui + NemoClaw (mean/claw only)
#
# Backend selection:
#   Set BACKEND_ENGINE=ollama (default) or BACKEND_ENGINE=bitnet in .env
#   to switch between Ollama and BitNet inference engines.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
# shellcheck source=scripts/install/tooling/ui.sh
source "$REPO_DIR/scripts/install/tooling/ui.sh"

htsai_banner "06 — Start Stack"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
step()  { echo -e "\n${CYAN}══ $* ══${NC}"; }

CHAT_MODE="mean"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --chat)
      [[ $# -ge 2 ]] || { echo "[FAIL] --chat requires lean|mean|claw" >&2; exit 1; }
      CHAT_MODE="$2"; shift 2 ;;
    *) echo "[FAIL] Unknown argument: $1" >&2; exit 1 ;;
  esac
done

case "$CHAT_MODE" in lean|mean|claw) ;; *) echo "[FAIL] --chat must be lean, mean, or claw" >&2; exit 1 ;; esac

# ── Load .env ─────────────────────────────────────────────────────────────────
if [[ -f "$REPO_DIR/.env" ]]; then
  set -a
  # shellcheck source=/dev/null
  source "$REPO_DIR/.env"
  set +a
else
  warn ".env not found at $REPO_DIR/.env — run 01-autoinstall.sh first"
fi

BACKEND_ENGINE="${BACKEND_ENGINE:-ollama}"

echo ""
info "Backend: ${CYAN}${BACKEND_ENGINE}${NC}"
if [[ "$BACKEND_ENGINE" == "bitnet" ]]; then
  info "Chat: ${CYAN}bitnet${NC} — ${BITNET_MODEL:-Llama3-8B-1.58-100B-tokens} (1-bit quantised)"
elif [[ "$CHAT_MODE" == "claw" ]]; then
  CLAW_MODEL="${CLAW_MODEL:-deepseek-r1:14b}"
  info "Chat: ${CYAN}claw${NC} — ${CLAW_MODEL} (~9GB VRAM, reasoning/agent)"
elif [[ "$CHAT_MODE" == "mean" ]]; then
  FULL_MODEL="${OLLAMA_MODEL:-mistral-nemo:12b}"
  info "Chat: ${CYAN}mean${NC} — ${FULL_MODEL} (~7-8GB VRAM, default)"
else
  info "Chat: ${CYAN}lean${NC} — smollm2:135m (~500MB VRAM, dev/test)"
fi
echo ""

COMPOSE_FILE="$REPO_DIR/docker-compose.yml"
ENV_FILE="$REPO_DIR/.env"

# Build profile list: always include backend engine, optionally add dashboard
PROFILES="$BACKEND_ENGINE"
DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-false}"
if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  PROFILES="$PROFILES,dashboard"
fi

compose() { docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" --profile "$PROFILES" "$@"; }

# ── health_check <label> <url> ────────────────────────────────────────────────
health_check() {
  local label="$1"
  local url="$2"
  local attempts=0
  printf "  %-35s" "$label"
  until curl -sf "$url" >/dev/null 2>&1; do
    sleep 2
    attempts=$((attempts + 1))
    if [[ $attempts -ge 30 ]]; then
      echo -e "${RED}FAIL${NC} ($url)"
      return 1
    fi
  done
  echo -e "${GREEN}OK${NC}"
}

# ── swap_ollama_model <model> ─────────────────────────────────────────────────
swap_ollama_model() {
  local model="$1"
  info "Pulling $model..."
  docker exec ollama ollama pull "$model" 2>&1 | tail -1
  info "Warming $model (10m keep_alive)..."
  curl -s "http://localhost:11434/api/generate" \
    -d "{\"model\":\"${model}\",\"keep_alive\":\"10m\",\"prompt\":\"\"}" >/dev/null 2>&1 || true
  ok "ollama → $model loaded"
}

# ─────────────────────────────────────────────────────────────────────────────
# Step 1: Bring up all services
# ─────────────────────────────────────────────────────────────────────────────
step "Services (dashboard, ${BACKEND_ENGINE}, open-webui)"
compose up -d --wait

# ─────────────────────────────────────────────────────────────────────────────
# Step 2: Load chat model
# ─────────────────────────────────────────────────────────────────────────────
if [[ "$BACKEND_ENGINE" == "bitnet" ]]; then
  step "Chat model — BitNet (${BITNET_MODEL:-Llama3-8B-1.58-100B-tokens})"
  info "BitNet model downloads automatically on first run."
  info "Waiting for BitNet health check (may take 2-5 min on first run)..."
  local_attempts=0
  until curl -sf "http://localhost:8080/v1/models" >/dev/null 2>&1; do
    sleep 5
    local_attempts=$((local_attempts + 1))
    if [[ $local_attempts -ge 60 ]]; then
      warn "BitNet did not become healthy within 5 minutes — check: docker logs bitnet"
      break
    fi
  done
  if curl -sf "http://localhost:8080/v1/models" >/dev/null 2>&1; then
    ok "bitnet → ready"
  fi
else
  step "Chat model — ${CHAT_MODE}"
  if [[ "$CHAT_MODE" == "lean" ]]; then
    swap_ollama_model "smollm2:135m"
  elif [[ "$CHAT_MODE" == "claw" ]]; then
    CLAW_MODEL="${CLAW_MODEL:-deepseek-r1:14b}"
    swap_ollama_model "$CLAW_MODEL"
  else
    FULL_MODEL="${OLLAMA_MODEL:-mistral-nemo:12b}"
    swap_ollama_model "$FULL_MODEL"
  fi
fi

# ─────────────────────────────────────────────────────────────────────────────
# Step 3: NemoClaw — connect sandboxes (mean and claw only)
# ─────────────────────────────────────────────────────────────────────────────
nemoclaw_handle() {
  local sandbox="$1"
  local status_out

  status_out=$(NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" status 2>&1)
  # nemoclaw exits 0 for unknown sandboxes but prints "Unknown command"
  if echo "$status_out" | grep -qi "unknown command\|no sandboxes\|not found"; then
    warn "Sandbox '$sandbox' not found — run ./04-setup-nemoclaw.sh first"
    return 0
  fi

  if echo "$status_out" | grep -qi "connected"; then
    echo ""
    warn "NemoClaw sandbox '$sandbox' is already connected."
    echo -e "  ${CYAN}[i]${NC}gnore (default)  ${CYAN}[r]${NC}eplace  ${CYAN}[d]${NC}estroy"
    local choice
    if read -r -t 30 -p "  Choice [i/r/d, 30s timeout → ignore]: " choice 2>/dev/null; then
      choice="${choice,,}"
    else
      echo ""
      info "Timeout — defaulting to ignore"
      choice="i"
    fi
    case "$choice" in
      r|replace)
        info "Replacing $sandbox..."
        NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" disconnect 2>/dev/null || true
        sleep 1
        NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" connect &
        sleep 2 ;;
      d|destroy)
        warn "Destroying $sandbox..."
        NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" destroy 2>/dev/null || true ;;
      *)
        info "Ignoring $sandbox (already connected)" ;;
    esac
  else
    info "Connecting $sandbox..."
    NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" connect &
    sleep 2
  fi
}

if [[ "$CHAT_MODE" == "mean" || "$CHAT_MODE" == "claw" ]]; then
  step "NemoClaw sandboxes"
  nemoclaw_handle "hts-ai-assistant-prod"
  nemoclaw_handle "hts-ai-assistant-test"
else
  info "Skipping NemoClaw (lean mode)"
fi

# ─────────────────────────────────────────────────────────────────────────────
# Health checks
# ─────────────────────────────────────────────────────────────────────────────
step "Health checks"
health_check "Dashboard        :80"    "http://localhost:80"
if [[ "$BACKEND_ENGINE" == "bitnet" ]]; then
  health_check "BitNet           :8080" "http://localhost:8080/v1/models"
else
  health_check "Ollama           :11434" "http://localhost:11434/api/tags"
fi
health_check "Open WebUI       :3000"  "http://localhost:3000"
if [[ "$CHAT_MODE" == "mean" || "$CHAT_MODE" == "claw" ]]; then
  health_check "NemoClaw prod    :18789" "http://localhost:18789"
  health_check "NemoClaw test    :18790" "http://localhost:18790"
fi

# ─────────────────────────────────────────────────────────────────────────────
# Done
# ─────────────────────────────────────────────────────────────────────────────
echo ""
ok "Stack up — backend:${BACKEND_ENGINE} chat:${CHAT_MODE}"
echo ""
echo "  ./06-start-stack.sh              # chat:mean  (~7-8GB, default)"
echo "  ./06-start-stack.sh --chat claw  # chat:claw  (~9GB, reasoning)"
echo "  ./06-start-stack.sh --chat lean  # chat:lean  (~500MB, dev/test)"
echo ""
echo "  Set BACKEND_ENGINE=bitnet in .env to use BitNet instead of Ollama"
echo "  Stop: docker compose --profile $BACKEND_ENGINE down"

