# Static Resources

Assets, templates, and function definitions consumed by services at runtime.

Last updated: 2026-04-05 20:30:00

## What happens here

This folder holds static resources that are loaded into running services — not scripts that run directly. Files here are consumed by provisioning scripts or mounted into containers, not executed from the command line.

## Files and structure

| Folder | Purpose |
|--------|---------|
| `dashboard/` | HTML/CSS/JS files served by the dashboard container. Also hosts runtime-generated token sidecars (`nemoclaw-tokens.json`, `openwebui-token.json`) used for auto-login links (gitignored). |
| `nginx/` | Nginx reverse proxy configuration templates |
| `open-webui/` | Assets bind-mounted into the Open WebUI container |
| `open-webui/login.html` | Same-origin login bridge page — reads `#token=JWT` from the URL hash, sets `localStorage.token`, and redirects to `/`. Mounted at `/app/build/static/login.html` inside the container via `docker-compose.yml`. |
| `open-webui-functions/` | Python function files auto-provisioned into Open WebUI via API |

## Python files — Open WebUI functions

Open WebUI functions live in `open-webui-functions/` and follow the **Pipe class** pattern:

| Convention | Rule |
|------------|------|
| Filename | `snake_case.py` (matches Open WebUI function ID) |
| Header | Metadata docstring: `title`, `author`, `version`, `description` |
| Class | Single `class Pipe` with `Valves` inner class for config |
| Dependencies | Standard library only (`urllib`, `json`) — no pip packages |
| Provisioning | Auto-registered by `scripts/utils/provision-webui-functions.sh` |

These files are **not run directly** — they are uploaded to Open WebUI's `/api/v1/functions/` endpoint. The function ID is derived from the filename (e.g. `audit_models.py` → `audit_models`).

## What good looks like

- Resources are consumed by services, not executed by users
- Python files have metadata blocks (title, author, version)
- No secrets or credentials in resource files
- Provisioning is automated (not manual upload)

## Tools and skills

- **Python 3** — Open WebUI function definitions (Pipe class pattern)
- **provision-webui-functions.sh** — Registers functions via REST API
