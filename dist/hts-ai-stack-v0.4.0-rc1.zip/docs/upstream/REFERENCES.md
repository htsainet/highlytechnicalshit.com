# Upstream Dependencies — Tracking

Last updated: 2026-04-08 20:00:00

## Dependency Inventory

Core upstream repositories that hts-ai-stack sources, builds, or installs from.

| Repo | Pinned Version | Pin Method | Health | Last Checked |
|------|----------------|------------|--------|--------------|
| [ollama/ollama](https://github.com/ollama/ollama) | `0.20.2` (digest-pinned) | Dockerfile | healthy | 2026-04-08 |
| [mostlygeek/llama-swap](https://github.com/mostlygeek/llama-swap) | `cpu` (digest-pinned) | Dockerfile | healthy | 2026-04-08 |
| [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) | latest release (unpinned) | install script | watch | 2026-04-08 |
| [open-webui/open-webui](https://github.com/open-webui/open-webui) | `main` (digest-pinned) | Dockerfile | healthy | 2026-04-08 |
| [bytedance/deer-flow](https://github.com/bytedance/deer-flow) | `main` branch | Dockerfile ARG | healthy | 2026-04-08 |
| [HKUDS/OpenSpace](https://github.com/HKUDS/OpenSpace) | `main` branch | Dockerfile ARG | healthy | 2026-04-08 |
| [microsoft/BitNet](https://github.com/microsoft/BitNet) | HEAD (unpinned) | git clone | watch | 2026-04-08 |
| [unslothai/unsloth](https://github.com/unslothai/unsloth) | `2026.4.4-pt2.9.0-vllm-0.16.0-cu12.8-studio-release-v0.1.35-beta` | compose image | healthy | 2026-04-08 |
| [tailscale/tailscale](https://github.com/tailscale/tailscale) | `v1.96.5` | compose image | healthy | 2026-04-08 |
| [AsamK/signal-cli](https://github.com/AsamK/signal-cli) | latest release (unpinned) | install script | healthy | 2026-04-08 |
| [siutin/stable-diffusion-webui-docker](https://github.com/siutin/stable-diffusion-webui-docker) | `cuda-13.2.0-v1.10.1-2026-03-17` | compose image | healthy | 2026-04-08 |
| [SillyTavern/SillyTavern](https://github.com/SillyTavern/SillyTavern) | `1.17.0` | GHCR image | healthy | 2026-04-08 |
| [NVIDIA/openshell](https://github.com/NVIDIA/openshell) | latest release (unpinned) | `nemoclaw` dependency | watch | 2026-04-11 |
| [openclaw/openclaw](https://github.com/openclaw/openclaw) | `latest` (npm) | sandbox local install | watch | 2026-04-11 |

**Health key:** `healthy` = current or near-current, no known issues | `watch` = unpinned or known issues | `stale` = significantly behind upstream

## Active Tracked Issues

Upstream bugs and gaps that affect our stack. Each row links to a detailed issue file.

| Issue | State | Severity | Impact | Workaround | File |
|-------|-------|----------|--------|------------|------|
| [NVIDIA/NemoClaw#1685](https://github.com/NVIDIA/NemoClaw/issues/1685) | OPEN | high | sandbox-base:latest ships stale OpenClaw 2026.3.11 | None — waiting on upstream image rebuild | [issues/NVIDIA-NemoClaw-1685.md](issues/NVIDIA-NemoClaw-1685.md) |
| [NVIDIA/NemoClaw#1640](https://github.com/NVIDIA/NemoClaw/issues/1640) | OPEN | high | Sandbox image missing gnupg — `gpg` not found | None | [issues/NVIDIA-NemoClaw-1640.md](issues/NVIDIA-NemoClaw-1640.md) |
| [NVIDIA/NemoClaw#1641](https://github.com/NVIDIA/NemoClaw/issues/1641) | OPEN | medium | `nemoclaw list` resurrects destroyed sandboxes | Ignore ghost entries | [issues/NVIDIA-NemoClaw-1641.md](issues/NVIDIA-NemoClaw-1641.md) |
| [NVIDIA/NemoClaw#1642](https://github.com/NVIDIA/NemoClaw/issues/1642) | OPEN | medium | Errors in openclaw log (config, gateway, EACCES) | Noise — no functional impact yet | [issues/NVIDIA-NemoClaw-1642.md](issues/NVIDIA-NemoClaw-1642.md) |
| [NVIDIA/NemoClaw#1686](https://github.com/NVIDIA/NemoClaw/issues/1686) | OPEN | low | `tls: terminate` deprecated in blueprints (WARN spam) | Ignore warnings | [issues/NVIDIA-NemoClaw-1686.md](issues/NVIDIA-NemoClaw-1686.md) |
| NVIDIA/NemoClaw — DRAFT | DRAFT | high | `inference set --model` is gateway-global; no per-sandbox model override | Removed CPU sandbox; evaluating gVisor/Daytona | [issues/NVIDIA-NemoClaw-DRAFT-per-sandbox-model.md](issues/NVIDIA-NemoClaw-DRAFT-per-sandbox-model.md) |
