# Wizard UX Redesign — Implementation Plan

**Date:** 2026-04-17
**Branch:** `feature/manifest-wizard`
**File to modify:** `config/wizard/ai_stack_setup.py` (currently 633 lines)
**Goal:** Replace 13 sequential wizard screens with 4 screens: Mode → Profile → Grouped Checkboxes → Follow-ups → Confirm

---

## Table of Contents

1. [Current State](#1-current-state)
2. [Target State](#2-target-state)
3. [Screen-by-Screen Specification](#3-screen-by-screen-specification)
4. [Data Structures](#4-data-structures)
5. [Component Registry (from manifests)](#5-component-registry-from-manifests)
6. [Config Key Mapping](#6-config-key-mapping)
7. [Implementation Steps](#7-implementation-steps)
8. [Code Sections to Keep vs Replace](#8-code-sections-to-keep-vs-replace)
9. [Testing Checklist](#9-testing-checklist)

---

## 1. Current State

The wizard file `config/wizard/ai_stack_setup.py` has 13 sequential screens, each a separate function:

| Step | Function            | What it asks                               | Lines   |
|------|---------------------|--------------------------------------------|---------|
| 1    | `choose_backend()`  | ollama or bitnet (select)                  | 140-149 |
| 2    | `choose_model()`    | model name from list (select)              | 152-159 |
| 3    | `choose_instances()`| single or prod/test (select + text)        | 162-183 |
| 4    | `choose_model_cache()`| none/local/network (select + text)       | 186-213 |
| 5    | `choose_voice()`    | enable + STT engine + TTS engine (confirm+select) | 216-249 |
| 6    | `choose_images()`   | enable + engine + GPU layers (confirm+select)      | 252-278 |
| 7    | `choose_claw3d()`   | enable + renderer + resolution (confirm+select)    | 281-302 |
| 8    | `choose_paperclip()`| enable + max agents + memory + restart (confirm+select) | 305-330 |
| 9    | `choose_openspace()`| enable + dashboard + auto-improve + sharing (confirm+select) | 333-354 |
| 10   | `choose_docker_network()` | topology (select)                    | 357-370 |
| 11   | `choose_comms()`    | platforms + tokens (checkbox + text)       | 373-401 |
| 12   | `choose_admin()`    | tools + config (checkbox + text)           | 404-430 |
| 13   | `choose_extras()`   | services from SERVICE_CATALOG (checkbox)   | 433-446 |

After all screens: `print_summary()` → confirm → `save_config()`.

**Key helper functions to KEEP AS-IS:**
- `save_config()` (lines 510-569) — handles backup, secret stripping, JSON write
- `print_banner()` (lines 129-135) — ASCII banner
- `section()` helper (lines 122-126) — step counter display (will need `TOTAL_STEPS` update)
- STYLE constant (lines 107-116) — questionary theme
- Path constants (lines 20-28) — REPO_ROOT, CONFIG_DIR, etc.

**Dependencies:**
- Python package: `questionary` (already installed, provides select, checkbox, confirm, text prompts)
- Python stdlib: json, os, shutil, datetime, pathlib, copy, glob

---

## 2. Target State

### Flow Diagram

```
┌──────────────────────────┐
│  Screen 0: Mode Select   │
│  Fresh / Reconfig /      │
│  Nuke & Pave / Cancel    │
└────────┬─────────────────┘
         │
    ┌────▼────┐
    │ Fresh?  │──No──▶ Load existing stack.json
    └────┬────┘        (pre-populate selections)
         │
┌────────▼─────────────────┐
│  Screen 1: Profile       │
│  Full / Standard /       │
│  Minimal / Custom        │
└────────┬─────────────────┘
         │
┌────────▼─────────────────┐
│  Screen 2: Grouped       │
│  Checkboxes              │
│  (one screen, all comps) │
└────────┬─────────────────┘
         │
┌────────▼─────────────────┐
│  Screen 3: Follow-ups    │
│  (only for selected      │
│   components that need   │
│   extra config)          │
└────────┬─────────────────┘
         │
┌────────▼─────────────────┐
│  Screen 4: Summary +     │
│  Confirm / Save / Back   │
└──────────────────────────┘
```

---

## 3. Screen-by-Screen Specification

### Screen 0 — Mode Selection

**questionary type:** `select`

```python
mode = questionary.select(
    "What would you like to do?",
    choices=[
        Choice("Fresh Install        — configure and deploy the full stack",   value="fresh"),
        Choice("Reconfigure          — change component selection (keeps data)", value="reconfig"),
        Choice("Nuke & Pave          — destroy ALL containers/volumes, start fresh", value="nuke"),
        Choice("Cancel               — exit without changes",                  value="cancel"),
    ],
    style=STYLE,
).ask()
```

**Behavior for each choice:**

- **`fresh`**: Proceed to Screen 1. If `stack.json` already exists, warn but continue (wizard will overwrite it; `save_config()` backs up the old one automatically).

- **`reconfig`**: Load existing `stack.json` with `json.load()`. Extract currently-enabled component IDs by evaluating each manifest's `config.read_path` against the loaded JSON. Pass these as `pre_checked` to Screen 2 (skip Screen 1 — profile is irrelevant when reconfiguring). Also load non-component config (backend, model, instances, etc.) to preserve them.

- **`nuke`**: Print a red warning. Ask `questionary.text("Type NUKE to confirm:")`. If input != "NUKE", print "Cancelled" and return to Screen 0. If confirmed, print instructions to run `./scripts/utils/nuke.sh` (or execute it directly if it exists — check first). Then restart wizard from Screen 1 as if fresh.

- **`cancel`**: Print "Setup cancelled." and `sys.exit(0)`.

### Screen 1 — Profile Picker

**questionary type:** `select`

```python
profile = questionary.select(
    "Choose a stack profile:",
    choices=[
        Choice("Full Stack (Recommended)  — all services, GPU required (~28 components)", value="full"),
        Choice("Standard                  — inference + chat + agents + monitoring (~18)", value="standard"),
        Choice("Minimal                   — Ollama + Open WebUI only (~5 components)",     value="minimal"),
        Choice("Custom                    — start with nothing, pick individually",         value="custom"),
    ],
    style=STYLE,
).ask()
```

**Profile definitions** (see Section 4 for the PROFILES dict):

- **full**: All components checked EXCEPT: signal, telegram, tailscale (need tokens/external setup)
- **standard**: Core inference + chat + search + agents + monitoring. No voice, no image gen, no training.
- **minimal**: Only ollama, llama-swap, open-webui, pipelines, dashboard
- **custom**: Nothing pre-checked

The profile returns a `set` of component IDs that should be pre-checked on Screen 2.

### Screen 2 — Grouped Component Checkboxes

**questionary type:** `checkbox`

This is ONE `questionary.checkbox()` call. Items are grouped visually using `questionary.Separator()` lines. Each component is a `questionary.Choice()` with `checked=True/False` based on the profile.

**Group order** (matches dashboard sections):

```
── Inference ──────────────────────────────────
  [x] Ollama (GPU)                   — GPU inference via NVIDIA
  [x] BitNet (CPU)                   — 1-bit quantized CPU inference
  [x] llama-swap                     — Multi-model router
  [ ] LocalAI                        — OpenAI-compatible inference server
  [ ] LM Studio (Host Tool)          — Desktop inference app

── Applications ───────────────────────────────
  [x] Open WebUI Pipelines           — Plugin framework for Open WebUI
  [x] SearXNG (Meta-Search)          — Privacy-first search for RAG

── Image Generation ───────────────────────────
  [x] Stable Diffusion               — Full AUTOMATIC1111 (GPU)
  [x] ComfyUI (GPU)                  — Node-based image pipeline

── Audio & Voice ──────────────────────────────
  [x] Faster-Whisper                  — Fast STT (speech-to-text)
  [x] Coqui TTS                      — Neural text-to-speech
  [x] Audio Flamingo                  — Audio understanding
  [x] Vosk                           — Lightweight offline STT

── Agent Applications ─────────────────────────
  [x] OpenSpace (MCP Skills)         — Self-evolving agent skills
  [x] DeerFlow                       — Agent workflow orchestration
  [x] Flowise                        — Drag-and-drop LLM chains
  [x] n8n                            — Workflow automation (400+ integrations)
  [x] Langflow                       — Visual AI builder

── Sandboxes ──────────────────────────────────
  [x] htsclaw                        — htsclaw GPU sandbox
  [x] NemoClaw                       — NemoClaw GPU sandbox

── Creative & Training ────────────────────────
  [x] Unsloth (LLM Training)         — Fine-tune LLMs on consumer GPUs

── Monitoring ─────────────────────────────────
  [x] Prometheus                     — Metrics collection
  [x] Grafana                        — Dashboards & visualization

── Management ─────────────────────────────────
  [x] Portainer                      — Docker GUI manager
  [x] Duplicati (Backup)             — Encrypted file backups

── Skills & Tools ─────────────────────────────
  [x] LanguageTool                   — Grammar & style checker

── Communications ─────────────────────────────
  [ ] Telegram Bot                   — Requires bot token
  [ ] Signal Bot                     — Requires phone number

── Admin & Remote Access ──────────────────────
  [ ] Tailscale (VPN)                — Zero-config VPN mesh
```

**Items NOT shown** (always-on, managed internally):
- `dashboard` (config type: `always`, dashboard.show: false)
- `open-webui` (config type: `always` — always deployed)
- `gvisor-sandbox` (dashboard.show: false — internal to NemoClaw)
- `sillytavern` (dashboard.show: false — hidden for now)

**How to determine which items are always-on vs selectable:**
- If manifest `config.type == "always"` → always enabled, skip from checkbox
- If manifest `dashboard.show == false` → skip from checkbox (hidden infrastructure)
- Everything else → show in checkbox

**Building the checkbox choices programmatically:**

```python
import glob

def load_manifests():
    """Load all component manifests and return a list of dicts."""
    manifests = []
    manifest_dir = REPO_ROOT / "scripts" / "components"
    for path in sorted(manifest_dir.glob("*/*.manifest.json")):
        with open(path) as f:
            m = json.load(f)
        m['_manifest_path'] = str(path)
        manifests.append(m)
    return manifests

def build_checkbox_choices(manifests, pre_checked_ids):
    """
    Build a list of questionary.Choice and questionary.Separator items
    for the grouped component checkbox screen.
    
    Args:
        manifests: list of manifest dicts from load_manifests()
        pre_checked_ids: set of component ID strings that should be pre-checked
    
    Returns:
        list of Choice/Separator objects for questionary.checkbox()
    """
    # Filter to selectable components only
    selectable = [
        m for m in manifests
        if m.get('config', {}).get('type') != 'always'
        and m.get('dashboard', {}).get('show', True) is not False
    ]
    
    # Group by wizard_group (derived from dashboard.section or category)
    SECTION_ORDER = [
        "Inference",
        "Applications",
        "Image Generation",
        "Audio & Voice",
        "Agent Applications",
        "Sandboxes",
        "Creative & Training",
        "Monitoring",
        "Management",
        "Skills & Tools",
        "Communications",
        "Admin & Remote Access",
    ]
    
    # Map manifest dashboard.section → wizard group name
    SECTION_MAP = {
        "Inference": "Inference",
        "AI Backends": "Inference",           # LocalAI → merge into Inference
        "Applications": "Applications",
        "Image Generation": "Image Generation",
        "Audio & Voice": "Audio & Voice",
        "Agent Applications": "Agent Applications",
        "htsclaw Sandbox": "Sandboxes",       # merge sandbox sections
        "NemoClaw Sandbox": "Sandboxes",
        "Creative & Training": "Creative & Training",
        "Monitoring": "Monitoring",
        "Management": "Management",
        "Skills & Tools": "Skills & Tools",
    }
    
    # Components without a dashboard section get mapped by category
    CATEGORY_MAP = {
        "comms": "Communications",
        "admin": "Admin & Remote Access",
    }
    
    groups = {name: [] for name in SECTION_ORDER}
    
    for m in selectable:
        dash_section = m.get('dashboard', {}).get('section', '')
        group = SECTION_MAP.get(dash_section)
        if not group:
            group = CATEGORY_MAP.get(m.get('category', ''), 'Extras')
        if group not in groups:
            groups[group] = []
        groups[group].append(m)
    
    # Sort items within each group by manifest 'order' field
    for group_items in groups.values():
        group_items.sort(key=lambda m: m.get('order', 999))
    
    # Build the choices list
    choices = []
    for group_name in SECTION_ORDER:
        items = groups.get(group_name, [])
        if not items:
            continue
        choices.append(questionary.Separator(f"── {group_name} {'─' * (40 - len(group_name))}"))
        for m in items:
            cid = m['id']
            label = m.get('display_name', cid)
            checked = cid in pre_checked_ids
            choices.append(questionary.Choice(label, value=cid, checked=checked))
    
    return choices
```

### Screen 3 — Follow-up Questions

Only shown for components that need additional configuration beyond on/off.
Each follow-up is gated by checking if the relevant component ID is in the user's selections.

**Follow-up conditions and questions:**

| Condition | Question | Type | Default | Config key written |
|-----------|----------|------|---------|-------------------|
| `"ollama" in selected` | "Select default Ollama model:" | select | `gemma4:e4b` | `.model` |
| `"bitnet" in selected` | "Select BitNet model:" | select | `bitnet-b1.58-2B-4T` | `.model` (if backend=bitnet only) |
| `"ollama" in selected AND "bitnet" in selected` | (auto-set backend to "dual") | — | — | `.backend = "dual"` |
| `"ollama" in selected AND "bitnet" not in selected` | (auto-set backend to "ollama") | — | — | `.backend = "ollama"` |
| `"bitnet" in selected AND "ollama" not in selected` | (auto-set backend to "bitnet") | — | — | `.backend = "bitnet"` |
| `"telegram" in selected` | "Telegram bot token (blank to set later):" | text | `""` | `.comms.tokens.telegram_bot_token` |
| `"signal" in selected` | "Signal phone number:" | text | `""` | `.comms.tokens.signal_phone_number` |
| `"tailscale" in selected` | "Tailscale auth key (blank for interactive):" | text | `""` | `.admin.tailscale_authkey` |
| ~~NAS~~ | ~~Removed from wizard~~ | — | — | ~~Separate script: `scripts/utils/nas-setup.sh`~~ |

**Items that do NOT need follow-up questions** (just on/off is sufficient):
- All voice components (faster-whisper, coqui-tts, audio-flamingo, vosk)
- All image gen (stable-diffusion, comfyui)
- All agents (openspace, deerflow, flowise, n8n, langflow)
- All monitoring (prometheus, grafana)
- All management (portainer, duplicati)
- Skills (languagetool)
- Sandboxes (htsclaw, nemoclaw)
- Training (unsloth)
- LocalAI, LM Studio, SearXNG, Pipelines

**Backend inference auto-detection logic:**

```python
def derive_backend(selected_ids):
    """Determine backend string from selected inference components."""
    has_ollama = "ollama" in selected_ids
    has_bitnet = "bitnet" in selected_ids
    if has_ollama and has_bitnet:
        return "dual"
    elif has_bitnet:
        return "bitnet"
    else:
        return "ollama"  # default even if neither selected (fallback)
```

### Screen 4 — Summary + Confirm

Reuse existing `print_summary()` function (updated for new config shape — see Section 7 step 7).

**questionary type:** `select`

```python
action = questionary.select(
    "What would you like to do?",
    choices=[
        Choice("Save & Install   — write config and start converge", value="save_install"),
        Choice("Save Only        — write config, don't install yet",  value="save_only"),
        Choice("Go Back          — return to component selection",    value="back"),
        Choice("Cancel           — exit without saving",             value="cancel"),
    ],
    style=STYLE,
).ask()
```

**Behavior:**
- `save_install`: Call `save_config(config)`, then print a message telling the user to run `./scripts/utils/converge.sh --yes` (or exec it directly).
- `save_only`: Call `save_config(config)` only.
- `back`: Loop back to Screen 2.
- `cancel`: Exit without saving.

---

## 4. Data Structures

### PROFILES dict

This dict maps profile names to the set of component IDs that should be pre-checked.

```python
PROFILES = {
    "full": {
        # All selectable components EXCEPT ones that need tokens/external setup
        "include": [
            # Inference
            "ollama", "bitnet", "llama-swap", "lmstudio",
            # Applications
            "pipelines", "searxng",
            # Image Generation
            "stable-diffusion", "comfyui",
            # Audio & Voice
            "faster-whisper", "coqui-tts", "audio-flamingo", "vosk",
            # Agent Applications
            "openspace", "deerflow", "flowise", "n8n", "langflow",
            # Sandboxes
            "htsclaw", "nemoclaw",
            # Creative & Training
            "unsloth",
            # Monitoring
            "prometheus", "grafana",
            # Management
            "portainer", "duplicati",
            # Skills
            "languagetool",
        ],
        # Explicitly excluded (need external setup):
        # "localai", "telegram", "signal", "tailscale"
    },
    "standard": {
        "include": [
            "ollama", "bitnet", "llama-swap",
            "pipelines", "searxng",
            "openspace", "deerflow", "flowise", "n8n", "langflow",
            "htsclaw", "nemoclaw",
            "prometheus", "grafana",
            "portainer", "duplicati",
        ],
    },
    "minimal": {
        "include": [
            "ollama", "llama-swap",
            "pipelines",
        ],
    },
    "custom": {
        "include": [],
    },
}
```

**Usage:** `pre_checked = set(PROFILES[profile_name]["include"])`

### OLLAMA_MODELS and BITNET_MODELS lists

Keep existing lists from lines 32-55 of the current file. No changes needed.

### DOCKER_NETWORK_DETAILS dict

**REMOVE.** Network topology is no longer a wizard screen — always use "Single vnet" (bridge mode). Hardcode in config output:
```python
config["network"] = {"topology": "Single vnet", "mode": "bridge",
                     "description": "Containers share a single bridge network. Simple and isolated."}
```

### SERVICE_CATALOG list

**REMOVE.** The checkbox is now built dynamically from manifests (see `build_checkbox_choices()`).

---

## 5. Component Registry (from manifests)

These are ALL 33 components with their manifest data. The wizard reads these at runtime via `load_manifests()`.

### Components shown in wizard checkbox (selectable)

| ID | display_name | category | dashboard.section | config.type | config.read_path | order |
|----|-------------|----------|-------------------|-------------|------------------|-------|
| ollama | Ollama (GPU) | inference | Inference | enum | .backend | 20 |
| bitnet | BitNet (CPU) | inference | Inference | enum | .backend | 30 |
| llama-swap | llama-swap | inference | Inference | enum | .backend | 40 |
| localai | LocalAI | inference | AI Backends | boolean | .localai.enabled | 25 |
| lmstudio | LM Studio (Host Tool) | inference | Inference | boolean | .lmstudio.install | 160 |
| pipelines | Open WebUI Pipelines | core | Applications | array_member | .extras.components | 55 |
| searxng | SearXNG (Meta-Search) | extras | Applications | array_member | .extras.components | 175 |
| stable-diffusion | Stable Diffusion | image | Image Generation | boolean | .images.stable_diffusion | 70 |
| comfyui | ComfyUI (GPU Image Generation) | images | Creative & Training | boolean | .images.comfyui | 180 |
| faster-whisper | Faster-Whisper | audio | Audio & Voice | boolean | .voice.stt | 92 |
| coqui-tts | Coqui TTS | audio | Audio & Voice | boolean | .voice.tts | 91 |
| audio-flamingo | Audio Flamingo | audio | Audio & Voice | boolean | .voice.audio_flamingo | 90 |
| vosk | Vosk | audio | Audio & Voice | boolean | .voice.vosk | 93 |
| openspace | OpenSpace (MCP Skills) | agents | Agent Applications | boolean | .openspace.enabled | 110 |
| deerflow | DeerFlow (Agent Orchestration) | agents | Agent Applications | array_member | .extras.components | 120 |
| flowise | Flowise (LLM Builder) | agents | Agent Applications | array_member | .extras.components | 125 |
| n8n | n8n (Workflow Automation) | agents | Agent Applications | array_member | .extras.components | 127 |
| langflow | Langflow (Visual AI Builder) | agents | Agent Applications | array_member | .extras.components | 128 |
| htsclaw | htsclaw | sandbox | htsclaw Sandbox | enum | .sandbox.engine | 60 |
| nemoclaw | NemoClaw | sandbox | NemoClaw Sandbox | enum | .sandbox.engine | 70 |
| unsloth | Unsloth (LLM Training) | training | Creative & Training | boolean | .unsloth.enabled | 190 |
| prometheus | Prometheus | monitoring | Monitoring | array_member | .extras.components | 80 |
| grafana | Grafana | monitoring | Monitoring | array_member | .extras.components | 90 |
| portainer | Portainer | admin | Management | array_member | .extras.components | 100 |
| duplicati | Duplicati (Backup) | extras | Management | array_member | .extras.components | 140 |
| languagetool | LanguageTool | skill | Skills & Tools | boolean | .skills.languagetool | 26 |
| telegram | Telegram Bot | comms | (hidden) | boolean | .comms.telegram.enabled | 200 |
| signal | Signal Bot | comms | (hidden) | boolean | .comms.signal.enabled | 210 |
| tailscale | Tailscale (VPN) | admin | (hidden) | array_member | .admin.tools | 150 |

### Components NOT shown in wizard checkbox (always-on or hidden infra)

| ID | Reason |
|----|--------|
| dashboard | config.type == "always", dashboard.show == false |
| open-webui | config.type == "always" (always deployed) |
| gvisor-sandbox | dashboard.show == false (internal to NemoClaw) |
| sillytavern | dashboard.show == false (hidden for now) |

**Note:** `telegram`, `signal`, and `tailscale` have `dashboard.show: false` in their manifests. However, the wizard SHOULD show them because users need to be able to select them. The filter logic should be:

```python
# Show in wizard if:
# 1. config.type != "always"  (not infrastructure)
# 2. Either dashboard.show == true, OR category in ("comms", "admin")
def is_wizard_selectable(manifest):
    cfg_type = manifest.get('config', {}).get('type', '')
    if cfg_type == 'always':
        return False
    dash_show = manifest.get('dashboard', {}).get('show', True)
    category = manifest.get('category', '')
    if dash_show:
        return True
    # Show hidden items if they're user-facing categories
    if category in ('comms', 'admin'):
        return True
    return False
```

This will include telegram, signal, tailscale in the checkbox but exclude dashboard, open-webui, gvisor-sandbox, sillytavern.

---

## 6. Config Key Mapping

When the user checks/unchecks components, the wizard must write the correct keys into `stack.json`. This section documents EXACTLY how each component's on/off state maps to config JSON.

### Mapping rules by config.type

**Type: `boolean`** — Write `true`/`false` to `config.read_path`:

| Component | Path | On value | Off value |
|-----------|------|----------|-----------|
| localai | `.localai.enabled` | `true` | `false` |
| lmstudio | `.lmstudio.install` | `true` | `false` |
| stable-diffusion | `.images.stable_diffusion` | `true` | `false` |
| comfyui | `.images.comfyui` | `true` | `false` |
| openspace | `.openspace.enabled` | `true` | `false` |
| unsloth | `.unsloth.enabled` | `true` | `false` |
| languagetool | `.skills.languagetool` | `true` | `false` |
| telegram | `.comms.telegram.enabled` | `true` | `false` |
| signal | `.comms.signal.enabled` | `true` | `false` |
| audio-flamingo | `.voice.audio_flamingo` | `true` | `false` |
| vosk | `.voice.vosk` | `true` | `false` |

**Special booleans** (write non-boolean values):

| Component | Path | On value | Off value |
|-----------|------|----------|-----------|
| faster-whisper | `.voice.stt` | `true` | `false` |
| coqui-tts | `.voice.tts` | `true` | `false` |

Note: The write_rules in the manifests show `on_enable: "faster-whisper"` and `on_enable: "coqui"` but the config.read_path checks `.voice.stt` and `.voice.tts` as booleans. For the wizard, write `true`/`false` to these paths. The actual engine names are implementation details the scripts handle internally.

**Type: `enum`** — Write to a string field, value depends on combination:

| Components | Path | Logic |
|-----------|------|-------|
| ollama, bitnet, llama-swap | `.backend` | If both ollama+bitnet selected → `"dual"`. If only ollama → `"ollama"`. If only bitnet → `"bitnet"`. llama-swap is auto-enabled when backend is "dual". |
| htsclaw, nemoclaw | `.sandbox.engine` | If both selected → `"both"`. If only htsclaw → `"htsclaw"`. If only nemoclaw → `"nemoclaw"`. If neither → `"none"`. |

**Type: `array_member`** — Add/remove from a JSON array:

| Component | Array path | Member value |
|-----------|-----------|--------------|
| deerflow | `.extras.components` | `"deerflow"` |
| flowise | `.extras.components` | `"flowise"` |
| n8n | `.extras.components` | `"n8n"` |
| langflow | `.extras.components` | `"langflow"` |
| prometheus | `.extras.components` | `"prometheus"` |
| grafana | `.extras.components` | `"grafana"` |
| portainer | `.extras.components` | `"portainer"` |
| duplicati | `.extras.components` | `"duplicati"` |
| searxng | `.extras.components` | `"searxng"` |
| pipelines | `.extras.components` | `"pipelines"` |
| tailscale | `.admin.tools` | `"tailscale"` |

### Implementation: `selections_to_config()`

```python
def selections_to_config(selected_ids: set, followup_answers: dict) -> dict:
    """
    Convert a set of selected component IDs + follow-up answers into a
    stack.json-compatible config dict.
    
    Args:
        selected_ids: set of component ID strings (e.g. {"ollama", "bitnet", ...})
        followup_answers: dict with keys like "model", "nas", "telegram_token", etc.
    
    Returns:
        dict ready to pass to save_config()
    """
    config = {}
    config["generated_at"] = datetime.now().isoformat()
    
    # ── Backend (enum logic) ──────────────────────────────────────────────
    has_ollama = "ollama" in selected_ids
    has_bitnet = "bitnet" in selected_ids
    if has_ollama and has_bitnet:
        config["backend"] = "dual"
    elif has_bitnet:
        config["backend"] = "bitnet"
    else:
        config["backend"] = "ollama"
    
    # ── Model ─────────────────────────────────────────────────────────────
    config["model"] = followup_answers.get("model", "gemma4:e4b")
    config["pull_all_models"] = False
    
    # ── Inference settings ────────────────────────────────────────────────
    config["inference"] = {
        "router": "llama-swap",
        "router_port": "8081",
        "ollama_port": "11434",
        "ollama_model": followup_answers.get("model", "gemma4:e4b"),
        "bitnet_model": "bitnet",
        "lmstudio": {
            "enabled": "lmstudio" in selected_ids,
            "url": "http://localhost:1234",
        },
    }
    
    # ── LM Studio ─────────────────────────────────────────────────────────
    config["lmstudio"] = {
        "install": "lmstudio" in selected_ids,
        "peer": True,
        "url": "http://localhost:1234",
    }
    
    # ── Instances (hardcoded single for now) ──────────────────────────────
    config["instances"] = {"mode": "single", "prod_port": "11434", "test_port": "11435"}
    
    # ── Model cache (hardcoded none for now) ──────────────────────────────
    config["model_cache"] = {"type": "none"}
    
    # ── Voice ─────────────────────────────────────────────────────────────
    any_voice = any(cid in selected_ids for cid in
                    ["faster-whisper", "coqui-tts", "audio-flamingo", "vosk"])
    config["voice"] = {
        "enabled": any_voice,
        "stt": "faster-whisper" in selected_ids,
        "tts": "coqui-tts" in selected_ids,
        "vosk": "vosk" in selected_ids,
        "audio_flamingo": "audio-flamingo" in selected_ids,
        "wake_word": False,
    }
    
    # ── Images ────────────────────────────────────────────────────────────
    has_sd = "stable-diffusion" in selected_ids
    has_comfy = "comfyui" in selected_ids
    config["images"] = {
        "enabled": has_sd or has_comfy,
        "stable_diffusion": has_sd,
        "comfyui": has_comfy,
        "gpu_layers": "All",
    }
    
    # ── Sandbox ───────────────────────────────────────────────────────────
    has_htsclaw = "htsclaw" in selected_ids
    has_nemoclaw = "nemoclaw" in selected_ids
    if has_htsclaw and has_nemoclaw:
        sandbox_engine = "both"
    elif has_htsclaw:
        sandbox_engine = "htsclaw"
    elif has_nemoclaw:
        sandbox_engine = "nemoclaw"
    else:
        sandbox_engine = "none"
    config["sandbox"] = {
        "engine": sandbox_engine,
        "agent_personas": True,
    }
    
    # ── Claw3D (disabled for now — no wizard screen) ──────────────────────
    config["claw3d"] = {"enabled": False, "renderer": "", "resolution": ""}
    
    # ── Paperclip (disabled for now — no wizard screen) ───────────────────
    config["paperclip"] = {
        "enabled": False, "max_agents": "4",
        "agent_memory": "In-memory (fast)", "auto_restart": True,
    }
    
    # ── Network (hardcoded bridge) ────────────────────────────────────────
    config["network"] = {
        "topology": "Single vnet", "mode": "bridge",
        "description": "Containers share a single bridge network. Simple and isolated.",
    }
    
    # ── Comms ─────────────────────────────────────────────────────────────
    platforms = []
    tokens = {}
    if "telegram" in selected_ids:
        platforms.append("telegram")
        tokens["telegram_bot_token"] = followup_answers.get("telegram_token", "")
    if "signal" in selected_ids:
        platforms.append("signal")
        tokens["signal_phone_number"] = followup_answers.get("signal_phone", "")
    config["comms"] = {"platforms": platforms, "tokens": tokens}
    
    # ── Admin ─────────────────────────────────────────────────────────────
    admin_tools = ["ssh_server"]  # always include SSH
    if "tailscale" in selected_ids:
        admin_tools.append("tailscale")
    config["admin"] = {
        "tools": admin_tools,
        "ssh_port": "22",
        "ssh_pubkey_only": True,
        "sudo_keepalive": True,
    }
    if "tailscale" in selected_ids:
        config["admin"]["tailscale_authkey"] = followup_answers.get("tailscale_key", "")
    
    # ── NAS — NOT in wizard (separate script: scripts/utils/nas-setup.sh) ────
    config["nas"] = {
        "enabled": False,
        "host": "",
        "nfs4_domain": "htsai",
        "uses": [],
        "model_cache_share": "",
        "model_cache_mount": "/mnt/ai_models",
        "docker_backup_share": "",
        "docker_backup_mount": "/mnt/nas-backups",
        "timeshift_share": "",
        "timeshift_mount": "/mnt/nas-timeshift",
    }
    
    # ── Services (external URL overrides — keep defaults) ─────────────────
    config["services"] = {
        "ollama": {"use_external": False, "external_url": "http://localhost:11434"},
        "open_webui": {"use_external": False, "external_url": "http://localhost:3000"},
        "stable_diffusion": {"use_external": False, "external_url": "http://localhost:7860"},
        "bitnet": {"use_external": False, "external_url": "http://localhost:8080"},
        "openspace": {"use_external": False, "external_url": "http://localhost:5000"},
        "nemoclaw": {"deploy": True, "agent_personas": True},
        "llama_swap": {"port": "8080", "config": "config/llama-swap.yaml"},
    }
    
    # ── Extras (array_member components) ──────────────────────────────────
    extras_components = []
    EXTRAS_MEMBERS = {
        "pipelines", "searxng", "prometheus", "grafana", "portainer",
        "deerflow", "flowise", "n8n", "langflow", "duplicati",
    }
    # Always include open_webui and nginx in extras
    extras_components.append("open_webui")
    for cid in EXTRAS_MEMBERS:
        if cid in selected_ids:
            extras_components.append(cid)
    # Add nginx if it was previously in the config
    extras_components.append("nginx")
    config["extras"] = {
        "components": extras_components,
        "model_audit": True,
    }
    
    # ── Independent boolean components ────────────────────────────────────
    config["openspace"] = {"enabled": "openspace" in selected_ids}
    config["unsloth"] = {"enabled": "unsloth" in selected_ids}
    config["skills"] = {"languagetool": "languagetool" in selected_ids}
    config["localai"] = {"enabled": "localai" in selected_ids}
    
    return config
```

---

## 7. Implementation Steps

### Step 1: Add imports and new constants

At the top of the file, add `glob` to imports. Replace `TOTAL_STEPS = 13` with `TOTAL_STEPS = 4`.

**Add** the `PROFILES` dict (from Section 4) after line 103 (after SERVICE_CATALOG — which will be deleted).

**Delete** `SERVICE_CATALOG` (lines 75-103) and `DOCKER_NETWORK_DETAILS` (lines 57-70).

### Step 2: Add `load_manifests()` function

Add this function after the constants. It reads all `scripts/components/*/*.manifest.json` files.
See the code in Section 3, Screen 2 above. Place it around where `choose_backend()` currently starts (~line 140).

### Step 3: Add `is_wizard_selectable()` function

See code in Section 5. Place it next to `load_manifests()`.

### Step 4: Add `build_checkbox_choices()` function

See code in Section 3, Screen 2 above. This function takes manifests + pre_checked set → returns Choice/Separator list.

### Step 5: Add `selections_to_config()` function

See the full code in Section 6 above. This is the largest new function (~120 lines).

### Step 6: Add `choose_mode()` function

New function for Screen 0. See Screen 0 specification in Section 3.

```python
def choose_mode() -> str:
    section(0, "Setup Mode")
    return questionary.select(
        "What would you like to do?",
        choices=[
            questionary.Choice("Fresh Install        — configure and deploy the full stack",    value="fresh"),
            questionary.Choice("Reconfigure          — change component selection (keeps data)", value="reconfig"),
            questionary.Choice("Nuke & Pave          — destroy ALL containers/volumes, start fresh", value="nuke"),
            questionary.Choice("Cancel               — exit without changes",                   value="cancel"),
        ],
        style=STYLE,
    ).ask()
```

### Step 7: Add `choose_profile()` function

New function for Screen 1. See Screen 1 specification in Section 3.

```python
def choose_profile() -> str:
    section(1, "Stack Profile")
    return questionary.select(
        "Choose a stack profile:",
        choices=[
            questionary.Choice("Full Stack (Recommended)  — all services, GPU required (~28 components)", value="full"),
            questionary.Choice("Standard                  — inference + chat + agents + monitoring (~18)", value="standard"),
            questionary.Choice("Minimal                   — Ollama + Open WebUI only (~5 components)",     value="minimal"),
            questionary.Choice("Custom                    — start with nothing, pick individually",         value="custom"),
        ],
        style=STYLE,
    ).ask()
```

### Step 8: Add `choose_components()` function

New function for Screen 2.

```python
def choose_components(manifests, pre_checked_ids: set) -> set:
    section(2, "Component Selection")
    choices = build_checkbox_choices(manifests, pre_checked_ids)
    selected = questionary.checkbox(
        "Select components to install  [Space to toggle, Enter to confirm]:",
        choices=choices,
        style=STYLE,
    ).ask()
    return set(selected) if selected else set()
```

### Step 9: Add `ask_followups()` function

New function for Screen 3.

```python
def ask_followups(selected_ids: set) -> dict:
    """Ask follow-up questions only for components that need extra config."""
    answers = {}
    
    has_ollama = "ollama" in selected_ids
    has_bitnet = "bitnet" in selected_ids
    
    # ── Model selection ───────────────────────────────────────────────
    if has_ollama or has_bitnet:
        section(3, "Follow-up Configuration")
    
    if has_ollama:
        answers["model"] = questionary.select(
            "Select default Ollama model:",
            choices=OLLAMA_MODELS,
            style=STYLE,
        ).ask()
    
    # ── NAS is NOT configured here ────────────────────────────────────
    # NAS setup is a separate script: scripts/utils/nas-setup.sh
    # It involves system-level changes (fstab, idmapd, NFS mounts)
    # and should be run independently before or after the wizard.
    
    # ── Comms tokens ──────────────────────────────────────────────────
    if "telegram" in selected_ids:
        answers["telegram_token"] = questionary.text(
            "Telegram bot token (blank to set later):", default="", style=STYLE
        ).ask()
    
    if "signal" in selected_ids:
        answers["signal_phone"] = questionary.text(
            "Signal phone number (e.g. +441234567890):", default="", style=STYLE
        ).ask()
    
    # ── Tailscale ─────────────────────────────────────────────────────
    if "tailscale" in selected_ids:
        answers["tailscale_key"] = questionary.text(
            "Tailscale auth key (blank for interactive auth):", default="", style=STYLE
        ).ask()
    
    return answers
```

### Step 10: Update `print_summary()` function

The current `print_summary()` references `cfg['images']['engine']` which no longer exists. Update it to handle the new config shape:

```python
def print_summary(cfg: dict):
    print("""
╔══════════════════════════════════════════════════╗
║               CONFIGURATION SUMMARY             ║
╚══════════════════════════════════════════════════╝""")

    print(f"  Backend       : {cfg['backend'].title()}")
    print(f"  Model         : {cfg['model']}")
    print(f"  Instances     : {cfg['instances']['mode']}")
    print(f"  Model cache   : {cfg['model_cache']['type']}")

    v = cfg['voice']
    print(f"  Voice         : {tick(v['enabled'])}", end="")
    if v['enabled']:
        parts = []
        if v.get('stt'):    parts.append("STT")
        if v.get('tts'):    parts.append("TTS")
        if v.get('vosk'):   parts.append("Vosk")
        if v.get('audio_flamingo'): parts.append("Audio Flamingo")
        print(f"  [{' / '.join(parts)}]", end="")
    print()

    img = cfg['images']
    print(f"  Images        : {tick(img['enabled'])}", end="")
    if img['enabled']:
        engines = []
        if img.get('stable_diffusion'): engines.append("Stable Diffusion")
        if img.get('comfyui'):          engines.append("ComfyUI")
        print(f"  [{' + '.join(engines)}]", end="")
    print()

    sandbox = cfg.get('sandbox', {})
    print(f"  Sandboxes     : {sandbox.get('engine', 'none')}")

    print(f"  Docker net    : {cfg['network']['topology']}  ({cfg['network']['mode']})")

    comms = cfg['comms']['platforms']
    print(f"  Comms         : {', '.join(comms) if comms else 'none'}")

    admin = cfg['admin']['tools']
    print(f"  Admin         : {', '.join(admin) if admin else 'none'}")

    extras = cfg['extras']['components']
    print(f"  Services      : {', '.join(extras) if extras else 'none'}")

    # New items
    print(f"  OpenSpace     : {tick(cfg.get('openspace', {}).get('enabled', False))}")
    print(f"  Unsloth       : {tick(cfg.get('unsloth', {}).get('enabled', False))}")
    print(f"  LanguageTool  : {tick(cfg.get('skills', {}).get('languagetool', False))}")
    print(f"  LocalAI       : {tick(cfg.get('localai', {}).get('enabled', False))}")
    print()
```

### Step 11: Rewrite `main()` function

Replace the entire `main()` function:

```python
def main():
    print_banner()
    print("  Use arrow keys to navigate, Space to toggle, Enter to confirm.\n")

    try:
        # ── Screen 0: Mode ─────────────────────────────────────────────
        mode = choose_mode()

        if mode == "cancel":
            print("  Setup cancelled.\n")
            return

        if mode == "nuke":
            print("\n  ⚠  WARNING: This will destroy ALL containers, volumes, and config.")
            print("  ⚠  All data will be permanently lost.\n")
            confirm_nuke = questionary.text(
                "Type NUKE to confirm:", style=STYLE
            ).ask()
            if confirm_nuke != "NUKE":
                print("  Cancelled — nothing was destroyed.\n")
                return
            # Execute nuke script if it exists
            nuke_script = REPO_ROOT / "scripts" / "utils" / "nuke.sh"
            if nuke_script.exists():
                import subprocess
                print("  Running nuke script...")
                subprocess.run(["bash", str(nuke_script)], check=False)
            else:
                print("  ⚠  No nuke script found. Remove containers/volumes manually,")
                print(f"     then delete {STACK_JSON} and re-run this wizard.\n")
                return

        # ── Load manifests ─────────────────────────────────────────────
        manifests = load_manifests()

        # ── Determine pre-checked set ──────────────────────────────────
        if mode == "reconfig":
            # Load existing config and determine what's currently enabled
            pre_checked = load_current_selections(manifests)
            # Skip profile picker — go straight to checkboxes
        else:
            # ── Screen 1: Profile ──────────────────────────────────────
            profile = choose_profile()
            pre_checked = set(PROFILES[profile]["include"])

        # ── Screen 2: Component Checkboxes ─────────────────────────────
        while True:  # Loop allows "Go Back" from Screen 4
            selected_ids = choose_components(manifests, pre_checked)

            # ── Screen 3: Follow-ups ───────────────────────────────────
            followup_answers = ask_followups(selected_ids)

            # ── Build config ───────────────────────────────────────────
            config = selections_to_config(selected_ids, followup_answers)

            # ── Screen 4: Summary + Confirm ────────────────────────────
            print_summary(config)

            action = questionary.select(
                "What would you like to do?",
                choices=[
                    questionary.Choice("Save & Install   — write config and start converge", value="save_install"),
                    questionary.Choice("Save Only        — write config, don't install yet",  value="save_only"),
                    questionary.Choice("Go Back          — return to component selection",    value="back"),
                    questionary.Choice("Cancel           — exit without saving",             value="cancel"),
                ],
                style=STYLE,
            ).ask()

            if action == "back":
                pre_checked = selected_ids  # preserve current selections
                continue
            elif action == "cancel":
                print("  Config not saved.\n")
                return
            else:
                break  # save_install or save_only

        # ── Save ───────────────────────────────────────────────────────
        stack_path, secrets_path = save_config(config)
        print(f"  ✓ Config saved  → {stack_path}")
        if secrets_path:
            print(f"  ✓ Secrets saved → {secrets_path}  (gitignored)")
        print()

        if action == "save_install":
            print("  To deploy now, run:")
            print(f"    cd {REPO_ROOT}")
            print("    ./scripts/utils/converge.sh --yes")
            print()

    except KeyboardInterrupt:
        print("\n\n  Setup cancelled.\n")
```

### Step 12: Add `load_current_selections()` for reconfigure mode

```python
def load_current_selections(manifests) -> set:
    """
    Read existing stack.json and determine which component IDs are currently
    enabled, by evaluating each manifest's config.read_path against the config.
    
    Returns a set of component ID strings.
    """
    if not STACK_JSON.exists():
        print("  ⚠  No existing config found. Starting fresh.\n")
        return set()
    
    with open(STACK_JSON) as f:
        cfg = json.load(f)
    
    enabled = set()
    
    for m in manifests:
        cid = m['id']
        config_block = m.get('config', {})
        cfg_type = config_block.get('type', '')
        read_path = config_block.get('read_path', '')
        
        if cfg_type == 'always':
            continue  # not selectable
        
        # Navigate the JSON path (e.g. ".voice.stt" → cfg["voice"]["stt"])
        value = _resolve_json_path(cfg, read_path)
        
        if cfg_type == 'boolean':
            # Value is truthy (True, "true", non-empty string)
            if value and str(value).lower() not in ('false', '0', 'none', ''):
                enabled.add(cid)
        
        elif cfg_type == 'enum':
            match_values = config_block.get('match_values', [])
            if str(value) in match_values:
                enabled.add(cid)
        
        elif cfg_type == 'array_member':
            member_value = config_block.get('member_value', '')
            if isinstance(value, list) and member_value in value:
                enabled.add(cid)
    
    return enabled


def _resolve_json_path(obj, path: str):
    """
    Resolve a jq-style JSON path like ".voice.stt" against a dict.
    Returns None if any key is missing or the path is invalid.
    """
    if not path or not path.startswith('.'):
        return None
    keys = path.lstrip('.').split('.')
    current = obj
    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return None
    return current
```

### Step 13: Delete old functions

Remove these functions entirely (they are replaced by the new flow):

- `choose_backend()` (lines 140-149)
- `choose_model()` (lines 152-159)
- `choose_instances()` (lines 162-183)
- `choose_model_cache()` (lines 186-213)
- `choose_voice()` (lines 216-249)
- `choose_images()` (lines 252-278)
- `choose_claw3d()` (lines 281-302)
- `choose_paperclip()` (lines 305-330)
- `choose_openspace()` (lines 333-354)
- `choose_docker_network()` (lines 357-370)
- `choose_comms()` (lines 373-401)
- `choose_admin()` (lines 404-430)
- `choose_extras()` (lines 433-446)

Also delete:
- `SERVICE_CATALOG` (lines 75-103)
- `DOCKER_NETWORK_DETAILS` (lines 57-70)

### Step 14: Update section() helper

Change `TOTAL_STEPS = 13` → `TOTAL_STEPS = 4` at line 118.

---

## 8. Code Sections to Keep vs Replace

### KEEP (do not modify these)

| What | Lines | Reason |
|------|-------|--------|
| Shebang + docstring | 1-11 | Still accurate |
| Imports | 13-18 | Add `glob` to this block |
| Path constants | 20-28 | No change |
| OLLAMA_MODELS list | 32-46 | Used in follow-up |
| BITNET_MODELS list | 48-55 | Used in follow-up |
| STYLE constant | 105-116 | Used everywhere |
| `section()` helper | 122-126 | Used by new screens (update TOTAL_STEPS) |
| `print_banner()` | 129-135 | Used by new main() |
| `tick()` helper | 451-452 | Used by summary |
| `save_config()` | 510-569 | Core save logic, no change |

### REPLACE (delete and replace with new code)

| What | Lines | Replaced by |
|------|-------|-------------|
| `DOCKER_NETWORK_DETAILS` | 57-70 | Hardcoded in `selections_to_config()` |
| `SERVICE_CATALOG` | 75-103 | `load_manifests()` reads from files |
| `TOTAL_STEPS = 13` | 118 | `TOTAL_STEPS = 4` |
| `choose_backend()` | 140-149 | Auto-derived in `selections_to_config()` |
| `choose_model()` | 152-159 | `ask_followups()` |
| `choose_instances()` | 162-183 | Hardcoded single in `selections_to_config()` |
| `choose_model_cache()` | 186-213 | Hardcoded none in `selections_to_config()` |
| `choose_voice()` | 216-249 | Checkbox + `selections_to_config()` |
| `choose_images()` | 252-278 | Checkbox + `selections_to_config()` |
| `choose_claw3d()` | 281-302 | Hardcoded disabled in `selections_to_config()` |
| `choose_paperclip()` | 305-330 | Hardcoded disabled in `selections_to_config()` |
| `choose_openspace()` | 333-354 | Checkbox toggle only |
| `choose_docker_network()` | 357-370 | Hardcoded bridge in `selections_to_config()` |
| `choose_comms()` | 373-401 | Checkbox + `ask_followups()` |
| `choose_admin()` | 404-430 | Checkbox + `ask_followups()` |
| `choose_extras()` | 433-446 | `build_checkbox_choices()` |
| `print_summary()` | 455-507 | Updated version (new config shape) |
| `main()` | 574-633 | New 4-screen flow |

### ADD (new code)

| What | Description |
|------|-------------|
| `PROFILES` dict | Profile definitions (component ID sets) |
| `SECTION_ORDER` list | Display order for checkbox groups |
| `SECTION_MAP` dict | Map manifest section → wizard group |
| `CATEGORY_MAP` dict | Map manifest category → wizard group |
| `load_manifests()` | Read all `*.manifest.json` files |
| `is_wizard_selectable()` | Filter for selectable components |
| `build_checkbox_choices()` | Build grouped Choice/Separator list |
| `selections_to_config()` | Map selections → stack.json dict |
| `choose_mode()` | Screen 0 |
| `choose_profile()` | Screen 1 |
| `choose_components()` | Screen 2 |
| `ask_followups()` | Screen 3 |
| `load_current_selections()` | Load existing config for reconfigure |
| `_resolve_json_path()` | Helper to traverse JSON by dot path |

---

## 9. Testing Checklist

After implementation, verify these scenarios:

### Fresh Install Flow
1. Run `python3 config/wizard/ai_stack_setup.py`
2. Select "Fresh Install"
3. Select "Full Stack" profile → verify all expected items pre-checked
4. Toggle a few items off → Enter
5. Verify model picker appears (Ollama selected)
6. Verify NAS question appears
7. Verify summary shows correct config
8. Select "Save Only" → verify `config/stack.json` written correctly
9. Verify `config/backups/` has a backup of previous stack.json

### Reconfigure Flow
1. Ensure `config/stack.json` exists from previous run
2. Run wizard → Select "Reconfigure"
3. Verify checkboxes reflect current stack.json state
4. Toggle some items → save
5. Verify stack.json updated correctly

### Cancel/Nuke Flows
1. Run wizard → Select "Cancel" → verify clean exit, no file changes
2. Run wizard → Select "Nuke & Pave" → type something other than "NUKE" → verify cancelled
3. Run wizard → Select "Nuke & Pave" → type "NUKE" → verify it attempts nuke

### Profile Verification
1. Select each profile (Full/Standard/Minimal/Custom)
2. Verify the correct components are pre-checked for each
3. Verify Custom starts with nothing checked

### Go Back Flow
1. Complete through to summary → Select "Go Back"
2. Verify you return to component checkboxes
3. Verify your previous selections are preserved

### Config Output Verification
Compare wizard-generated `stack.json` against the reference format:
- `.backend` should be "dual", "ollama", or "bitnet" matching selections
- `.extras.components` array should contain all selected array_member components
- `.sandbox.engine` should be "both", "htsclaw", "nemoclaw", or "none"
- Boolean paths (`.localai.enabled`, `.unsloth.enabled`, etc.) should match selections
- `.voice.*` fields should match audio component selections
- `.images.*` fields should match image component selections

### Edge Cases
- Select no inference components → backend defaults to "ollama"
- Select only llama-swap → backend still "ollama" (llama-swap auto-enables with dual)
- Select no components at all → config should still be valid JSON
- Ctrl+C at any point → clean "Setup cancelled." exit

---

## Appendix A: File Structure Reference

```
config/
├── wizard/
│   ├── ai_stack_setup.py      ← THIS FILE (being rewritten)
│   └── apply_config.sh        ← Maps stack.json → .env (no changes needed)
├── stack.json                 ← Output of wizard
├── stack.secrets.json         ← Secrets extracted by save_config()
└── backups/
    └── YYYYMMDD-HHMMSS/
        └── stack.json         ← Automatic backup

scripts/
└── components/
    ├── ollama/
    │   ├── ollama.manifest.json    ← Read by load_manifests()
    │   └── ollama.sh
    ├── bitnet/
    │   ├── bitnet.manifest.json
    │   └── bitnet.sh
    ... (33 total components)
```

## Appendix B: questionary API Quick Reference

The wizard uses the `questionary` Python library. Key APIs:

```python
# Single selection (radio buttons)
questionary.select("Question:", choices=[...], style=STYLE).ask() → str

# Multiple selection (checkboxes)
questionary.checkbox("Question:", choices=[...], style=STYLE).ask() → list[str]

# Yes/No
questionary.confirm("Question:", default=True, style=STYLE).ask() → bool

# Free text
questionary.text("Question:", default="", style=STYLE).ask() → str

# Visual separator in checkbox/select
questionary.Separator("── Header ──")

# Choice with value different from label
questionary.Choice("Display Label", value="internal_value", checked=True)
```

## Appendix C: Nuke Script Specification

If `scripts/utils/nuke.sh` does not exist yet, it needs to be created. It should:

1. Stop all docker-compose services: `docker compose -f <project>/docker-compose.yml down -v` for each component
2. Remove all docker volumes: `docker volume prune -f`
3. Remove all project containers: `docker container prune -f`
4. Delete `config/stack.json`
5. Delete `config/stack.secrets.json`
6. Delete `.env`
7. Print summary of what was destroyed

This is a separate task from the wizard rewrite. For now, the wizard can just print instructions if the script doesn't exist.
