#!/usr/bin/env bash
# NanoClaw wrapper – sets a deterministic sandbox name with the hts‑ai prefix
# scripts/components/nanoclaw/nanoclaw.sh — Wrapper for NanoClaw (AI Assistant)
# Handles install (clone), start (run upstream script), stop, status, and destroy.

set -euo pipefail

# Default sandbox/container name – can be overridden via env var or --name flag
# Mirrors the pattern used by the nemo‑claw component.
NANOCLAW_SANDBOX_NAME="${NANOCLAW_SANDBOX_NAME:-hts-ai-nanoclaw}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
# Directory where we clone the upstream NanoClaw repository.
NANOCLOW_REPO_DIR="${SCRIPT_DIR}/nanoclaw_repo"

# Load environment helpers (step, info, ok, warn)
source "$REPO_ROOT/scripts/lib/common.sh"
# Load .env variables (including NEMOCLAW_MODEL) so we can reuse the same model
load_env
# Use the same model that Nemoclaw uses, falling back to a sane default
NANOCLAW_MODEL="${NEMOCLAW_MODEL:-mistral-nemo:latest}"

# ── nanoclaw_install — Clone the upstream repo if not already present ──
nanoclaw_install() {
  step "NanoClaw — install"
  if [[ -d "${NANOCLOW_REPO_DIR}/.git" ]]; then
    info "NanoClaw repo already cloned at ${NANOCLOW_REPO_DIR}."
  else
    git clone https://github.com/qwibitai/nanoclaw.git "${NANOCLOW_REPO_DIR}"
    ok "NanoClaw repository cloned."
  fi
}

# ── nanoclaw_start — Run the upstream nanoclaw.sh script ──
nanoclaw_start() {
  step "NanoClaw — start"
  if [[ ! -d "${NANOCLOW_REPO_DIR}" ]]; then
    fail "NanoClaw repository not found. Run --install first."
  fi
  (export NANOCLAW_SANDBOX_NAME NANOCLAW_MODEL; cd "${NANOCLOW_REPO_DIR}" && bash nanoclaw.sh "$@") &
  ok "NanoClaw started (background)."
}

# ── nanoclaw_stop — Terminate the NanoClaw process ──
nanoclaw_stop() {
  step "NanoClaw — stop"
  # NanoClaw runs a Node process compiled to dist/index.js; kill by pattern.
  pkill -f "node.*dist/index.js" || true
  ok "NanoClaw stopped (if it was running)."
}

# ── nanoclaw_status — Show running status ──
nanoclaw_status() {
  if pgrep -f "node.*dist/index.js" > /dev/null; then
    ok "NanoClaw is running."
  else
    warn "NanoClaw is not running."
  fi
}

# ── nanoclaw_destroy — Remove the cloned repository ──
nanoclaw_destroy() {
  step "NanoClaw — destroy"
  rm -rf "${NANOCLOW_REPO_DIR}"
  ok "NanoClaw repository removed."
}

# ── nanoclaw_health — Placeholder (no network endpoint) ──
nanoclaw_health() {
  : # No health endpoint; returns success.
}

# ── Standalone execution handling ──
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install"; shift;;
      --start)     ACTION="start"; shift;;
      --stop)      ACTION="stop"; shift;;
      --restart)   ACTION="restart"; shift;;
      --status)    ACTION="status"; shift;;
      --destroy)   ACTION="destroy"; shift;;
      *) shift;;
    esac
  done

  case "$ACTION" in
    install)   nanoclaw_install   ;;
    start)     nanoclaw_start      ;;
    stop)      nanoclaw_stop       ;;
    restart)   nanoclaw_stop; nanoclaw_start ;;
    status)    nanoclaw_status     ;;
    destroy)   nanoclaw_destroy    ;;
    default)   nanoclaw_install; nanoclaw_start ;;
  esac
fi
