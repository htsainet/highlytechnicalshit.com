#!/usr/bin/env python3
"""llamaswap-routing-check.py — all LLM traffic must go through llama-swap.

Invariant:
    llama-swap is the single OpenAI-compatible routing surface for every LLM
    consumer in the stack. No component config or component install script
    may hardcode `ollama:11434`, `http://ollama:…`, `bitnet:8080`, or
    `http://bitnet:…` as a backend URL. BitNet is reachable by setting
    `model: bitnet` against llama-swap's /v1 endpoint, NOT by a second URL.

Rationale:
    Ollama is routinely cold-pulled/loaded and BitNet has occasional hangs.
    Routing everything through llama-swap gives us one surface to health-
    probe, one place to add retries / fallbacks, and one config to audit.
    Direct ollama / bitnet URLs regress that invariant silently.

Scope:
    Scans:
        - config/**/*.{yaml,yml,json,env,conf}
        - scripts/components/*/*.sh
    Reports any occurrence of the banned substrings. Allowed files are
    listed in ALLOW (llama-swap's own config, diag / maintenance scripts
    that probe the raw backends on purpose, and this checker itself).

Usage:
    scripts/maintenance/llamaswap-routing-check.py            # report only
    scripts/maintenance/llamaswap-routing-check.py --strict   # exit 1 on hit

Exit codes:
    0 = clean, OR hits-present in report-only mode
    1 = --strict AND at least one hit
    2 = file / walk error
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]

# Banned substrings — anything here is a direct-to-backend URL that should
# be routed through llama-swap instead.
BANNED = [
    re.compile(r"\bollama:11434\b"),
    re.compile(r"https?://ollama[:/]"),
    re.compile(r"\bbitnet:8080\b"),
    re.compile(r"https?://bitnet[:/]"),
]

# Files that are allowed to mention the banned URLs because they ARE the
# routing surface or they probe the raw backend on purpose (health, diag,
# pull scripts). Paths are relative to the repo root.
ALLOW = {
    # llama-swap's own config — it routes TO these backends.
    "config/llama-swap.yaml",
    "config/llama-swap/llama-swap.yaml",
    # The Ollama component owns the raw URL; its script probes /api/tags
    # and /api/pull on the backend directly.
    "scripts/components/ollama/ollama.sh",
    # Same for BitNet's component (if/when a direct probe exists).
    "scripts/components/bitnet/bitnet.sh",
    # The llama-swap component script naturally mentions both backends.
    "scripts/components/llama-swap/llama-swap.sh",
    # Prometheus scrape targets — the monitoring side legitimately scrapes
    # each backend's /metrics directly; this is not LLM routing.
    "config/prometheus.yml",
    "config/prometheus/prometheus.yml",
    # Maintenance / diag helpers that poke the raw backends intentionally.
    "scripts/maintenance/llamaswap-routing-check.py",
    "scripts/maintenance/ollama-health.sh",
    "scripts/maintenance/bitnet-health.sh",
}

# File extensions and roots to scan.
CONFIG_GLOBS = ("*.yaml", "*.yml", "*.json", "*.env", "*.conf")


def iter_targets() -> list[Path]:
    targets: list[Path] = []
    config_root = REPO / "config"
    if config_root.is_dir():
        for pat in CONFIG_GLOBS:
            targets.extend(config_root.rglob(pat))
    comp_root = REPO / "scripts" / "components"
    if comp_root.is_dir():
        targets.extend(comp_root.glob("*/*.sh"))
    return targets


def is_allowed(rel: str) -> bool:
    return rel in ALLOW


def scan_file(p: Path) -> list[tuple[int, str, str]]:
    hits: list[tuple[int, str, str]] = []
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        sys.stderr.write(f"WARN: cannot read {p}: {exc}\n")
        return hits
    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        # Skip shell / yaml / hash comments so documentation about the
        # invariant itself isn't flagged.
        if stripped.startswith("#") or stripped.startswith("//"):
            continue
        for pat in BANNED:
            m = pat.search(line)
            if m:
                hits.append((lineno, m.group(0), line.rstrip()))
                break
    return hits


def main() -> int:
    strict = "--strict" in sys.argv[1:]

    try:
        targets = iter_targets()
    except Exception as exc:
        sys.stderr.write(f"ERROR walking repo: {exc}\n")
        return 2

    all_hits: list[tuple[str, int, str, str]] = []
    for p in targets:
        rel = p.relative_to(REPO).as_posix()
        if is_allowed(rel):
            continue
        for lineno, token, line in scan_file(p):
            all_hits.append((rel, lineno, token, line))

    if not all_hits:
        print(
            f"✓ llama-swap routing invariant holds "
            f"({len(targets)} files scanned, {len(ALLOW)} allow-listed)."
        )
        return 0

    print(f"✗ Direct-to-backend LLM URLs found ({len(all_hits)}):")
    for rel, lineno, token, line in all_hits:
        print(f"    {rel}:{lineno}: {token}")
        print(f"        {line}")
    print()
    print("  → Route these consumers through llama-swap instead:")
    print("      base_url: http://llama-swap:${LLAMA_SWAP_PORT:-8081}/v1")
    print("      model:    ${OLLAMA_MODEL:-smollm2:135m}   # or 'bitnet'")
    print("    Allow-list legitimate exceptions in")
    print("    scripts/maintenance/llamaswap-routing-check.py (ALLOW).")

    return 1 if strict else 0


if __name__ == "__main__":
    sys.exit(main())
