"""Audio Flamingo 3 — minimal FastAPI inference server.

Loads nvidia/audio-flamingo-3-hf from HuggingFace at startup and exposes
a REST API for audio understanding (captioning, classification, QA).
Model weights are cached in the HuggingFace hub volume.

Device selection (env AF_DEVICE):
  auto  — use GPU if available, otherwise CPU (default)
  gpu   — force GPU; fail if no CUDA device found
  cpu   — force CPU-only inference (no quantization, fp32)

Quantization (env AF_QUANTIZE, GPU only):
  auto  — pick by VRAM: >=20 GB → none, >=10 GB → int8, else int4
  none  — fp16, ~16 GB VRAM
  int8  — 8-bit, ~8 GB VRAM
  int4  — 4-bit, ~5 GB VRAM
"""

import io
import logging
import os

import soundfile as sf
import torch
import uvicorn
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import JSONResponse

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("audio-flamingo")

MODEL_ID = os.environ.get("AF_MODEL_ID", "nvidia/audio-flamingo-3-hf")
PORT = int(os.environ.get("AF_PORT", "8601"))
AF_DEVICE = os.environ.get("AF_DEVICE", "auto").lower().strip()
AF_QUANTIZE = os.environ.get("AF_QUANTIZE", "auto")


MIN_FREE_VRAM_MB = int(os.environ.get("AF_MIN_FREE_VRAM_MB", "5000"))


def _resolve_device():
    """Resolve the effective compute device from AF_DEVICE.

    In auto mode, checks free VRAM and falls back to CPU when there is
    not enough headroom (e.g. Ollama is consuming GPU memory).
    """
    if AF_DEVICE == "cpu":
        logger.info("AF_DEVICE=cpu — forcing CPU-only inference")
        return "cpu"
    if AF_DEVICE == "gpu":
        if not torch.cuda.is_available():
            raise RuntimeError("AF_DEVICE=gpu but no CUDA device found")
        return "cuda"
    # auto — check CUDA availability and free VRAM
    if not torch.cuda.is_available():
        logger.info("AF_DEVICE=auto — no CUDA device, using CPU")
        return "cpu"
    free_bytes, total_bytes = torch.cuda.mem_get_info(0)
    free_mb = free_bytes / (1024 * 1024)
    total_mb = total_bytes / (1024 * 1024)
    logger.info("AF_DEVICE=auto — GPU %s: %.0f MB free / %.0f MB total",
                torch.cuda.get_device_name(0), free_mb, total_mb)
    if free_mb < MIN_FREE_VRAM_MB:
        logger.warning("Only %.0f MB free VRAM (need %d MB) — falling back to CPU",
                        free_mb, MIN_FREE_VRAM_MB)
        return "cpu"
    logger.info("AF_DEVICE=auto — resolved to cuda (%.0f MB free)", free_mb)
    return "cuda"


DEVICE = _resolve_device()

app = FastAPI(title="Audio Flamingo 3", version="1.0.0")

model = None
processor = None
_quant_mode = None


def _detect_quantize_mode():
    """Pick quantization based on available VRAM if AF_QUANTIZE=auto."""
    mode = AF_QUANTIZE.lower().strip()
    if mode != "auto":
        return mode
    if DEVICE != "cuda":
        return "none"
    vram_mb = torch.cuda.get_device_properties(0).total_memory / (1024 * 1024)
    logger.info("Detected %.0f MB VRAM on %s", vram_mb, torch.cuda.get_device_name(0))
    if vram_mb >= 20_000:
        return "none"
    elif vram_mb >= 10_000:
        return "int8"
    else:
        return "int4"


def load_model():
    """Load model and processor (lazy, on first request or startup)."""
    global model, processor, _quant_mode
    if model is not None:
        return

    _quant_mode = _detect_quantize_mode()
    logger.info("Loading Audio Flamingo 3 from %s (device=%s, quantize=%s) ...",
                MODEL_ID, DEVICE, _quant_mode)
    from transformers import AudioFlamingo3ForConditionalGeneration, AutoProcessor

    if DEVICE == "cpu":
        load_kwargs = {"device_map": "cpu", "torch_dtype": torch.float32}
    else:
        load_kwargs = {"device_map": "auto"}
        if _quant_mode == "int4":
            from transformers import BitsAndBytesConfig
            load_kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_quant_type="nf4",
                llm_int8_enable_fp32_cpu_offload=True,
            )
        elif _quant_mode == "int8":
            from transformers import BitsAndBytesConfig
            load_kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_8bit=True,
                llm_int8_enable_fp32_cpu_offload=True,
            )
        else:
            load_kwargs["torch_dtype"] = torch.float16

    processor = AutoProcessor.from_pretrained(MODEL_ID)
    model = AudioFlamingo3ForConditionalGeneration.from_pretrained(MODEL_ID, **load_kwargs)
    logger.info("Model loaded (device=%s, quantize=%s)", DEVICE, _quant_mode)


@app.on_event("startup")
async def startup():
    load_model()


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "model": MODEL_ID,
        "device": DEVICE,
        "quantize": _quant_mode or "loading",
    }


@app.post("/v1/audio/analyze")
async def analyze(
    file: UploadFile = File(...),
    prompt: str = Form("Describe this audio in detail."),
):
    """Analyze an uploaded audio file with an optional text prompt."""
    load_model()

    audio_bytes = await file.read()
    waveform, sample_rate = sf.read(io.BytesIO(audio_bytes))

    if len(waveform.shape) > 1:
        waveform = waveform.mean(axis=1)

    inputs = processor(
        text=prompt,
        audios=[waveform],
        sampling_rate=sample_rate,
        return_tensors="pt",
    ).to(model.device)

    with torch.no_grad():
        output_ids = model.generate(**inputs, max_new_tokens=512)

    response_text = processor.batch_decode(output_ids, skip_special_tokens=True)[0]

    return JSONResponse({"response": response_text, "model": MODEL_ID})


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="info")
