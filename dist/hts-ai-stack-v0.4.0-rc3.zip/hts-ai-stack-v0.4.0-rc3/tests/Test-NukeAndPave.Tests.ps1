$ErrorActionPreference = 'Stop'

# Validates that nuke-stack.sh --pave leaves no stack artifacts behind.
# Run this AFTER a pave and BEFORE reinstalling — containers and processes
# created by a subsequent install will cause Docker/process tests to fail.
# Failing tests indicate teardown.sh is missing a cleanup step.
#
# Usage:
#   pwsh -NoLogo -NoProfile -Command "Invoke-Pester tests/Test-NukeAndPave.Tests.ps1 -Output Detailed"

BeforeAll {
    $script:RepoRoot  = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:UserHome  = $env:HOME
}

# ── Binaries ─────────────────────────────────────────────────────────────────

Describe 'binaries removed' {

    It 'openshell not present at /usr/local/bin/openshell' {
        '/usr/local/bin/openshell' | Should -Not -Exist
    }

    It 'openshell shadow install not present at ~/.local/bin/openshell' {
        Join-Path $script:UserHome '.local/bin/openshell' | Should -Not -Exist
    }

    It 'nemoclaw not present at ~/.local/bin/nemoclaw' {
        Join-Path $script:UserHome '.local/bin/nemoclaw' | Should -Not -Exist
    }

    It 'signal-cli symlink not present at /usr/local/bin/signal-cli' {
        '/usr/local/bin/signal-cli' | Should -Not -Exist
    }
}

# ── NemoClaw NVM binaries ─────────────────────────────────────────────────────

Describe 'nemoclaw NVM binaries removed' {

    It 'no nemoclaw binary in any NVM node version' {
        $nvmDir = Join-Path $script:UserHome '.nvm/versions/node'
        if (Test-Path $nvmDir) {
            $found = Get-ChildItem -Path $nvmDir -Filter 'nemoclaw' -Recurse -ErrorAction SilentlyContinue
            $found | Should -BeNullOrEmpty -Because "nemoclaw binaries should be removed from all NVM node versions"
        }
        else {
            Set-ItResult -Skipped -Because '~/.nvm/versions/node not present'
        }
    }
}

# ── Directories ───────────────────────────────────────────────────────────────

Describe 'directories removed' {

    It '~/.nemoclaw/ removed' {
        Join-Path $script:UserHome '.nemoclaw' | Should -Not -Exist
    }

    It '~/.config/openshell/ removed' {
        Join-Path $script:UserHome '.config/openshell' | Should -Not -Exist
    }

    It '/opt/signal-cli removed' {
        '/opt/signal-cli' | Should -Not -Exist
    }

    It 'repo node_modules/ removed' {
        Join-Path $script:RepoRoot 'node_modules' | Should -Not -Exist
    }
}

# ── Repo artifacts ────────────────────────────────────────────────────────────

Describe 'repo artifacts removed' {

    It '.env removed' {
        Join-Path $script:RepoRoot '.env' | Should -Not -Exist
    }

    It 'logs/manifest.json removed' {
        Join-Path $script:RepoRoot 'logs/manifest.json' | Should -Not -Exist
    }
}

# ── Systemd timers ────────────────────────────────────────────────────────────

Describe 'systemd health timers removed' {

    BeforeAll {
        # PS7 on Linux exposes Get-Service via systemd; fall back to systemctl CLI
        function script:Get-UnitStatus ([string]$Name) {
            if (Get-Command Get-Service -ErrorAction SilentlyContinue) {
                return (Get-Service -Name $Name -ErrorAction SilentlyContinue)?.Status?.ToString()
            }
            if (Get-Command systemctl -ErrorAction SilentlyContinue) {
                return (& systemctl is-active $Name 2>&1).Trim()
            }
            return $null
        }
    }

    It 'hts-nemoclaw-health.timer not active' {
        $status = script:Get-UnitStatus 'hts-nemoclaw-health.timer'
        $status | Should -Not -BeIn @('Running', 'active') `
            -Because "nemoclaw health timer should be disabled after pave"
    }

    It 'hts-htsclaw-health.timer not active' {
        $status = script:Get-UnitStatus 'hts-htsclaw-health.timer'
        $status | Should -Not -BeIn @('Running', 'active') `
            -Because "htsclaw health timer should be disabled after pave"
    }

    It 'hts-nemoclaw-health.service unit file removed' {
        '/etc/systemd/system/hts-nemoclaw-health.service' | Should -Not -Exist
    }

    It 'hts-htsclaw-health.service unit file removed' {
        '/etc/systemd/system/hts-htsclaw-health.service' | Should -Not -Exist
    }
}

# ── Processes ─────────────────────────────────────────────────────────────────

Describe 'stack processes not running' {

    It 'no openshell-server process running' {
        $procs = Get-Process -Name 'openshell-server' -ErrorAction SilentlyContinue
        $procs | Should -BeNullOrEmpty -Because "openshell-server should not be running after pave"
    }

    It 'no openclaw process running' {
        $procs = Get-Process -Name 'openclaw*' -ErrorAction SilentlyContinue
        $procs | Should -BeNullOrEmpty -Because "openclaw processes should not be running after pave"
    }

    It 'no nemoclaw sandbox connect process running' {
        $found = Get-Process -Name 'node' -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -match 'nemoclaw' -and $_.CommandLine -match 'connect' }
        $found | Should -BeNullOrEmpty -Because "nemoclaw connect processes should not be running after pave"
    }
}

# ── Ports ─────────────────────────────────────────────────────────────────────

Describe 'stack ports not listening' {

    BeforeAll {
        $script:Listeners = [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners()
    }

    It 'port 18789 (nemoclaw) not bound' {
        $script:Listeners | Where-Object Port -EQ 18789 | Should -BeNullOrEmpty `
            -Because "nemoclaw forward port should be free after pave"
    }

    It 'port 18792 (htsclaw) not bound' {
        $script:Listeners | Where-Object Port -EQ 18792 | Should -BeNullOrEmpty `
            -Because "htsclaw forward port should be free after pave"
    }

    It 'port 8080 (openshell gateway) not bound' {
        $script:Listeners | Where-Object Port -EQ 8080 | Should -BeNullOrEmpty `
            -Because "openshell cluster gateway port should be free after pave"
    }
}

# ── Docker ────────────────────────────────────────────────────────────────────

Describe 'Docker stack artifacts removed' {

    BeforeAll {
        $script:DockerAvailable = (Get-Command 'docker' -ErrorAction SilentlyContinue) -ne $null
    }

    It 'no openshell-cluster-nemoclaw container or volume' {
        if (-not $script:DockerAvailable) { Set-ItResult -Skipped -Because 'docker not available'; return }
        & docker inspect openshell-cluster-nemoclaw 2>$null | Out-Null
        $containerGone = $LASTEXITCODE -ne 0
        & docker volume inspect openshell-cluster-nemoclaw 2>$null | Out-Null
        $volumeGone = $LASTEXITCODE -ne 0
        $containerGone -and $volumeGone | Should -Be $true `
            -Because "stale nemoclaw cluster container and volume should be removed"
    }

    It 'no openshell-cluster-htsclaw container or volume' {
        if (-not $script:DockerAvailable) { Set-ItResult -Skipped -Because 'docker not available'; return }
        & docker inspect openshell-cluster-htsclaw 2>$null | Out-Null
        $containerGone = $LASTEXITCODE -ne 0
        & docker volume inspect openshell-cluster-htsclaw 2>$null | Out-Null
        $volumeGone = $LASTEXITCODE -ne 0
        $containerGone -and $volumeGone | Should -Be $true `
            -Because "stale htsclaw cluster container and volume should be removed"
    }

    It 'no hts-ai-* containers running' {
        if (-not $script:DockerAvailable) { Set-ItResult -Skipped -Because 'docker not available'; return }
        $running = & docker ps --filter 'name=hts-ai-' --format '{{.Names}}' 2>$null
        $running | Should -BeNullOrEmpty -Because "all hts-ai-* containers should be stopped after pave"
    }
}
