# 4-setup-nemoclaw.sh — NemoClaw + OpenShell

> **Alpha Warning:** NemoClaw launched March 16, 2026. Not production-ready.
> APIs and behavior may change without notice.

---

## Architecture Overview

NemoClaw is a CLI tool that manages sandboxed OpenClaw agents — not a container
you run directly. The full stack looks like this:

```text
Your Host
├── nemoclaw CLI        (npm global package — installed here)
├── openshell CLI       (separate binary — installed here)
└── Docker
    └── OpenShell gateway container (k3s embedded)
        └── Sandbox pod
            └── OpenClaw agent + NemoClaw plugin
```

You interact with `nemoclaw` and `openshell` commands from your host terminal.
Everything else runs inside Docker automatically.

> NemoClaw runs on the **host**, not inside Docker. It manages Docker from the
> outside and requires access to cgroups, k3s, and the Docker daemon.

---

## Prerequisites

Complete steps 1–3 first. Verify all of these before continuing:

```bash
# Docker running and accessible without sudo
docker ps

# NVIDIA Container Toolkit configured
nvidia-ctk --version

# Node.js v22+
node --version   # must be v22.x.x or higher

# Set nvm default explicitly (avoids installer version conflicts)
nvm alias default 22
source ~/.bashrc

# Confirm npm is up to date
npm --version    # should be 10+
npm install -g npm@latest

# Ollama reachable via llama-swap (required for local inference)
curl http://localhost:8080/health
```

---

## Step 1 — Fix cgroup v2 (Required for Ubuntu 24.04)

Ubuntu 24.04 uses cgroup v2 by default. NemoClaw's OpenShell gateway runs k3s
inside Docker, which fails on cgroup v2 without this fix.

**Symptom if skipped:**

```text
openat2 /sys/fs/cgroup/kubepods/pids.max: no such file or directory
Failed to start ContainerManager: failed to initialize top level QOS containers
```

**Check if you need it:**

```bash
stat -fc %T /sys/fs/cgroup/
# "cgroup2fs" = you need the fix
# "tmpfs"     = cgroup v1, skip this step
```

**Apply the fix:**

```bash
# Add cgroupns=host to Docker daemon config
sudo bash -c 'cat > /etc/docker/daemon.json << EOF
{
  "default-cgroupns-mode": "host"
}
EOF'

sudo systemctl restart docker
docker ps   # verify Docker still works
```

> If `/etc/docker/daemon.json` already exists with other content, add
> `"default-cgroupns-mode": "host"` as an additional key — do not overwrite the file.

---

## Step 2 — GitHub CLI (Required for OpenShell)

OpenShell is distributed via GitHub releases and requires the GitHub CLI to download.

```bash
# Add GitHub CLI repo
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | \
  sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] \
  https://cli.github.com/packages stable main" | \
  sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null

sudo apt update && sudo apt install -y gh

# Authenticate with GitHub
gh auth login
```

---

## Step 3 — OpenShell CLI

OpenShell is the sandboxing runtime. It is a separate binary from NemoClaw.

```bash
# Download and install OpenShell binary
ARCH=$(uname -m)
gh release download \
  --repo NVIDIA/OpenShell \
  --pattern "openshell-${ARCH}-unknown-linux-musl.tar.gz"

tar xzf openshell-${ARCH}-unknown-linux-musl.tar.gz
sudo install -m 755 openshell /usr/local/bin/openshell

# Verify
openshell --version
```

---

## Step 4 — NemoClaw

The installer script handles the npm package install.

```bash
curl -fsSL https://www.nvidia.com/nemoclaw.sh | bash
```

Alternatively, install from source (requires build step):

```bash
git clone https://github.com/NVIDIA/NemoClaw && cd NemoClaw
npm install --ignore-scripts
(cd nemoclaw && npm install --ignore-scripts && npm run build)
npm link
```

> `npm install -g .` alone will fail — the TypeScript plugin must be built first.

After install, reload your shell:

```bash
source ~/.bashrc

# Verify
nemoclaw --version
```

---

## Step 5 — Onboard Wizard

The script runs the wizard with `NEMOCLAW_EXPERIMENTAL=1` to enable local
inference via llama-swap. Port 8080 is used by llama-swap for the unified LLM
endpoint. NemoClaw gets port 18789 for the GPU sandbox dashboard.

```bash
NEMOCLAW_EXPERIMENTAL=1 nemoclaw onboard
```

The wizard runs 7 steps. Here's what to expect at each prompt:

| Step | What Happens | What To Do |
|---|---|---|
| 1 | Preflight checks | Fix any failures before continuing |
| 2 | Sandbox name | Enter `hts-ai-openshell-nemoclaw-gpu` (first sandbox) |
| 3 | Gateway startup | Pulls ~2.4 GB image, takes a few minutes |
| 4 | NVIDIA API key | Enter `local-ollama` (using local inference) |
| 5 | Model selection | Enter `gemma4:e4b` |
| 6 | Policy presets | Enter `n` for now — add presets later as needed |
| 7 | OpenClaw gateway | Enter `Y` |

---

## Step 6 — Configure llama-swap Inference

After onboard, the script automatically points NemoClaw at your local llama-swap
router via OpenShell's host routing:

```bash
nemoclaw inference set \
  --provider llama-swap-local \
  --model gemma4:e4b \
  --endpoint http://host.openshell.internal:8080/v1
```

`host.openshell.internal` is resolved by OpenShell to your host machine's IP
from inside the sandbox — this is how the sandboxed agent reaches llama-swap
without breaking the network isolation. llama-swap then routes to the correct
backend (Ollama GPU or BitNet CPU) based on model name.

---

## Step 6 — Connect and Use

```bash
# Connect to GPU sandbox
nemoclaw hts-ai-openshell-nemoclaw-gpu connect

# Inside the sandbox — check agent health
openclaw status --deep

# Inside the sandbox — update OpenClaw to latest
openclaw update

# Inside the sandbox — interactive TUI
openclaw tui

# Inside the sandbox — single message via CLI
openclaw agent --agent main --local -m "hello" --session-id test
```

> Run `openclaw status --deep` and `openclaw update` on first connect to confirm the agent is healthy and on the latest version.

---

## Managing Your Sandbox

Run all of these from the host (outside the sandbox):

```bash
# Check status
nemoclaw hts-ai-openshell-nemoclaw-gpu status

# List all sandboxes
openshell sandbox list

# Watch live network decisions in real time
openshell term

# Follow logs
nemoclaw hts-ai-openshell-nemoclaw-gpu logs --follow
```

---

## Network Policy Files

NemoClaw's sandbox policies live in:

```text
~/.nemoclaw/
└── nemoclaw-blueprint/
    └── policies/
        ├── openclaw-sandbox.yaml   ← main policy (edit this)
        └── presets/
            ├── pypi.yaml
            ├── docker-hub.yaml
            ├── huggingface.yaml
            ├── slack.yaml
            └── jira.yaml
```

Network rules are **hot-reloadable** (no sandbox restart needed):

```bash
openshell policy set my-policy.yaml
```

Filesystem rules are **locked at creation** — cannot be changed on a running sandbox.

---

## Ports Used

| Port | Service |
|---|---|
| 8080 | llama-swap (unified LLM router) |
| 11434 | Ollama GPU (direct debug access) |
| 18789 | NemoClaw GPU sandbox dashboard |

---

## Troubleshooting

### Preflight fails: cgroup v2 not configured

```bash
cat /etc/docker/daemon.json   # confirm setting is present
sudo systemctl restart docker
```

### `nemoclaw: command not found` after install

```bash
source ~/.bashrc
# or open a new terminal
```

### `openshell: command not found`

OpenShell must be installed separately — the installer does not always handle it.
Repeat Step 3.

### Port 18789 already in use

If something else already has 18789:

```bash
lsof -i :18789 -sTCP:LISTEN
```

### Failed onboard left corrupt k3s state

A partial `nemoclaw onboard` run corrupts k3s. Clean everything before retrying:

```bash
openshell sandbox delete hts-ai-assistant 2>/dev/null
openshell gateway destroy -g nemoclaw 2>/dev/null
docker volume rm openshell-cluster-nemoclaw 2>/dev/null
NEMOCLAW_EXPERIMENTAL=1 nemoclaw onboard
```

### Network egress blocked by sandbox

This is expected behavior — not a bug. The sandbox is enforcing policy.
Open the TUI to see what was blocked and approve if needed:

```bash
openshell term
```

---

## Uninstall

```bash
curl -fsSL https://raw.githubusercontent.com/NVIDIA/NemoClaw/refs/heads/main/uninstall.sh | bash
```

Removes: sandboxes, gateway, Docker images, local state, npm package.
Does NOT remove: Docker, Node.js, npm, Ollama, or OpenShell binary.

To also remove OpenShell:

```bash
sudo rm /usr/local/bin/openshell
```

---

## Next Step

→ Your full local AI stack is operational.

| Service | Access |
|---|---|
| llama-swap | http://localhost:8080/ui |
| Ollama GPU | http://localhost:11434 |
| Open WebUI | http://localhost:3000 |
| NemoClaw GPU | http://localhost:18789 |
| NemoClaw sandbox | `nemoclaw hts-ai-openshell-nemoclaw-gpu connect` |
