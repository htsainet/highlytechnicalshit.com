#!/usr/bin/env bash
# scripts/components/synfig/synfig.sh — Synfig Studio: install, configure, health
#
# Host-native installer for Synfig Studio, a free 2D vector animation suite.
# Features motion tweening, bone rigging, and advanced layer-based compositing.
#
# Standalone usage:
#   ./scripts/components/synfig/synfig.sh              # full: install + configure + health
#   ./scripts/components/synfig/synfig.sh --install    # install only
#   ./scripts/components/synfig/synfig.sh --configure  # configure only
#   ./scripts/components/synfig/synfig.sh --start      # no-op (desktop app)
#   ./scripts/components/synfig/synfig.sh --stop       # no-op (desktop app)
#   ./scripts/components/synfig/synfig.sh --restart    # no-op (desktop app)
#   ./scripts/components/synfig/synfig.sh --health     # health check only
#   ./scripts/components/synfig/synfig.sh --status     # show status + health
#   ./scripts/components/synfig/synfig.sh --destroy    # uninstall Synfig
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# ── Functions ────────────────────────────────────────────────────────────────

synfig_install() {
  step "Synfig Studio — install"
  if command -v synfigstudio &>/dev/null; then
    skip "Synfig Studio already installed."
  else
    info "Installing Synfig Studio..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq synfigstudio
    ok "Synfig Studio installed."
  fi
}

synfig_configure() {
  step "Synfig Studio — configure"
  info "Synfig Studio is a desktop application — no service configuration needed."
  ok "Synfig Studio configured."
}

synfig_start() {
  step "Synfig Studio — start"
  info "Synfig Studio is a desktop application. Launch from your application menu."
}

synfig_stop() {
  step "Synfig Studio — stop"
  info "Synfig Studio is a desktop application. Close it from the window."
}

synfig_restart() {
  synfig_stop
  synfig_start
}

synfig_health() {
  step "Synfig Studio — health"
  if command -v synfigstudio &>/dev/null; then
    ok "Synfig Studio is installed."
    return 0
  else
    warn "Synfig Studio is not installed."
    return 1
  fi
}

synfig_status() {
  step "Synfig Studio — status"
  synfig_health
}

synfig_destroy() {
  step "Synfig Studio — destroy"
  if dpkg -l synfigstudio &>/dev/null 2>&1; then
    info "Removing Synfig Studio..."
    sudo apt-get remove -y synfigstudio
    ok "Synfig Studio removed."
  else
    skip "Synfig Studio is not installed."
  fi
}

# ── CLI entry point ──────────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  case "${1:-}" in
    --install)   synfig_install   ;;
    --configure) synfig_configure ;;
    --start)     synfig_start     ;;
    --stop)      synfig_stop      ;;
    --restart)   synfig_restart   ;;
    --health)    synfig_health    ;;
    --status)    synfig_status    ;;
    --destroy)   synfig_destroy   ;;
    *)
      synfig_install
      synfig_configure
      synfig_health
      ;;
  esac
fi
