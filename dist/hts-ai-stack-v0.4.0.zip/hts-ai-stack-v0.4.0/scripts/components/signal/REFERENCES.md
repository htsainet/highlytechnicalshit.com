# Signal References

Last updated: 2026-04-15

## Upstream

- [GitHub — AsamK/signal-cli](https://github.com/AsamK/signal-cli)

## Official documentation

- [signal-cli README](https://github.com/AsamK/signal-cli#readme)
- [signal-cli Man Page](https://github.com/AsamK/signal-cli/blob/master/man/signal-cli.1.adoc)
