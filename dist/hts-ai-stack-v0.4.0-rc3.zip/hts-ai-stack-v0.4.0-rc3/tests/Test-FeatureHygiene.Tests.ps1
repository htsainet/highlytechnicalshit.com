$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:FeaturesDir = Join-Path $script:RepoRoot 'docs/development/features'
}

Describe 'Feature hygiene' {

    BeforeAll {
        # Collect shipped git tags (semver-style v* tags)
        $script:ShippedTags = @()
        try {
            $script:ShippedTags = git -C $script:RepoRoot tag --list 'v*' |
                ForEach-Object { $_.Trim() } |
                Where-Object { $_ -match '^v\d+\.\d+\.\d+$' }
        } catch {
            # git unavailable or not a repo — tests will pass vacuously
        }

        # Scan FEATURE-###.md files for Target Release fields pointing at shipped tags
        $script:StaleFeatures = [System.Collections.Generic.List[string]]::new()

        $featureFiles = Get-ChildItem -Path $script:FeaturesDir -Filter 'FEATURE-*.md' -ErrorAction SilentlyContinue

        foreach ($file in $featureFiles) {
            $content = Get-Content $file.FullName -Raw

            # Match "Target Release:" lines — extract the version even if surrounded by text
            # e.g. "**Target Release:** v0.5.0" or "**Target Release:** Next Minor (v0.5.0)"
            if ($content -match '\*?\*?Target Release\*?\*?:\s*.*?(v\d+\.\d+\.\d+)') {
                $targetVersion = $Matches[1]
                if ($script:ShippedTags -contains $targetVersion) {
                    $script:StaleFeatures.Add("$($file.Name) targets $targetVersion which is already shipped")
                }
            }
        }
    }

    It 'features directory exists' {
        $script:FeaturesDir | Should -Exist
    }

    It 'no FEATURE file targets an already-shipped git tag' {
        if ($script:StaleFeatures.Count -gt 0) {
            $detail = $script:StaleFeatures -join "`n  "
            "Stale features:`n  $detail" | Should -Be '' -Because 'features must not target a release that has already shipped — update Target Release or archive the feature'
        }
    }
}
