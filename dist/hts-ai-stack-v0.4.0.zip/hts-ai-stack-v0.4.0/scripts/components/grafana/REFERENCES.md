# Grafana References

Last updated: 2026-04-15

## Upstream

- [GitHub — grafana/grafana](https://github.com/grafana/grafana)

## Official documentation

- [Grafana Docs](https://grafana.com/docs/grafana/latest/)
