# Ubuntu Studio Audio Component

Last updated: 2026-04-17

## What happens here

Ubuntu Studio Audio is a host-native package set that installs the
professional audio foundation for Linux: JACK2 audio server, PulseAudio-JACK
bridge, QjackCtl GUI, low-latency kernel, and curated audio plugins.

## Files and structure

| File | Purpose |
|------|---------|
| `ubuntu-audio.sh` | Full lifecycle: install, configure, start, stop, health |
| `ubuntu-audio.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- Host-native packages — no Docker container or web UI
- Configures realtime audio group and PAM limits for low-latency operation
- Low-latency kernel (`linux-lowlatency`) may require a reboot after install
- Works alongside KXStudio (Cadence replaces QjackCtl for JACK management)

See [usage.md](./usage.md) for command usage.
