# NVIDIA/NemoClaw#1642 — Lots of errors in openclaw log

| Field | Value |
|-------|-------|
| **Repo** | [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) |
| **Issue** | [#1642](https://github.com/NVIDIA/NemoClaw/issues/1642) |
| **State** | OPEN |
| **Severity** | medium |
| **Labels** | bug, Platform: Ubuntu, OpenShell, NV QA |
| **Opened** | 2026-04-08 |
| **Subscribed** | No |

## Impact on us

OpenClaw logs inside sandboxes are noisy with errors: config anomalies, gateway closure warnings, and EACCES permission errors. While these don't appear to cause functional failures, they make it difficult to diagnose real problems and could mask genuine issues.

Affected files:

- Sandbox runtime logs (inside containers, not in our repo)
- Debugging workflow — harder to spot real errors in noisy logs

## Workaround

Treat as noise — no functional impact observed so far. Filter logs when debugging: `grep -v "gateway\|EACCES\|config anomal"`.

## Action when resolved

1. Pull updated sandbox image or OpenClaw version with the fix
2. Re-onboard sandboxes
3. Verify log output is cleaner: `docker logs <sandbox> 2>&1 | tail -50`

## Status log

- **2026-04-08** — Reported upstream.
- **2026-04-08** — Identified during our upstream issue scan. No functional impact confirmed.
