# SearXNG References

Last updated: 2026-04-15

## Upstream

- [GitHub — searxng/searxng](https://github.com/searxng/searxng)

## Official documentation

- [SearXNG Docs](https://docs.searxng.org/)
