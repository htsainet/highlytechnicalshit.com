$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/nemoclaw'
    $script:ComponentScript = Join-Path $script:ComponentDir 'nemoclaw.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'nemoclaw.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'nemoclaw file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'nemoclaw manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is nemoclaw' {
        $script:Manifest.id | Should -Be 'nemoclaw'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/nemoclaw/nemoclaw.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is nemoclaw' {
        $script:Manifest.func_prefix | Should -Be 'nemoclaw'
    }

    It 'dashboard port is 18789' {
        [int]$script:Manifest.dashboard.port | Should -Be 18789
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'nemoclaw component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines nemoclaw_install function' {
        $script:ComponentContent | Should -Match 'nemoclaw_install\s*\(\)'
    }

    It 'defines nemoclaw_configure function' {
        $script:ComponentContent | Should -Match 'nemoclaw_configure\s*\(\)'
    }

    It 'defines nemoclaw_start function' {
        $script:ComponentContent | Should -Match 'nemoclaw_start\s*\(\)'
    }

    It 'defines nemoclaw_stop function' {
        $script:ComponentContent | Should -Match 'nemoclaw_stop\s*\(\)'
    }

    It 'defines nemoclaw_health function' {
        $script:ComponentContent | Should -Match 'nemoclaw_health\s*\(\)'
    }

    It 'supports --onboard, --configure, --health, --stop, and --update CLI flags' {
        $script:ComponentContent | Should -Match '--onboard\)'
        $script:ComponentContent | Should -Match '--configure\)'
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
        $script:ComponentContent | Should -Match '--update\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/nemoclaw/nemoclaw\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'nemoclaw port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 18789 is registered in portmap.json' {
        $script:Portmap.ports.'18789' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'18789'.service | Should -Be 'nemoclaw'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'nemoclaw no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/nemoclaw\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/nemoclaw/nemoclaw\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}

# ── Nemoclaw port relay ─────────────────────────────────────────────────────

Describe 'nemoclaw port relay' {
    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines _start_port_relay helper function' {
        $script:ComponentContent | Should -Match '_start_port_relay\s*\(\)'
    }

    It 'relay uses a supervisor loop for crash recovery' {
        $script:ComponentContent | Should -Match 'relay-supervisor'
    }

    It 'relay forwards listen_port to target_port' {
        $script:ComponentContent | Should -Match 'listen_port.*target_port'
    }
}
