# LangGraph — Stateful Agent Orchestration Framework

**Priority:** MEDIUM
**Effort:** 2–3 hours
**Risk:** Low-medium — MIT license; LangSmith observability can push toward paid platform (document local-only path).
**Target Release:** v0.6.0
**Depends on:** llama-swap routing (merged), shared agents container (FEATURE-022)
**Blocks:** Nothing

## Problem

CrewAI (FEATURE-022) uses a role-based crew model for short-lived task completion.
LangGraph complements it with durable graph-based agent workflows: long-running tasks,
human-in-the-loop interrupts, persistent short-term and long-term memory, and
conditional branching. They address different parts of the agent lifecycle.

## Current State

Tracked in `docs/planning/feature-repos/REFERENCES.md` as WATCH (status: `watch`).
Promoted to Proposed. No component script or Docker service exists.

## Architecture

LangGraph is a Python library — it co-installs in the shared `hts-ai-agents` container
alongside CrewAI. No dedicated port or persistent service.

```text
  scripts/components/langgraph/langgraph.sh
        │
        ▼
  docker/agents/Dockerfile   ← shared with FEATURE-022
  (hts-ai-agents container)
  ├── crewai
  ├── langgraph
  └── resources/agents/
        ├── crewai/
        └── langgraph/
```

## Implementation Steps

### P0 — Shared container (coordinate with FEATURE-022)

- [ ] **1. Verify `docker/agents/requirements.txt` includes `langgraph`**
  Should already be present if FEATURE-022 is implemented first.
  If not: `echo "langgraph" >> docker/agents/requirements.txt`

- [ ] **2. Rebuild agents container** after adding langgraph to requirements.

### P1 — Component script

- [ ] **3. Create `scripts/components/langgraph/langgraph.sh`**
  - `langgraph_install` — build/rebuild agents container image (idempotent)
  - `langgraph_run <workflow>` — `docker run --rm hts-ai-agents python /app/agents/langgraph/<workflow>.py`
  - `langgraph_health` — verify `import langgraph` succeeds in container

### P2 — Example workflow

- [ ] **4. Create `resources/agents/langgraph/example_graph.py`**
  A minimal stateful graph: two nodes (worker + supervisor) with a conditional edge
  that loops until the supervisor approves the output. Uses llama-swap as LLM backend.

### P3 — Local-only observability

LangGraph defaults to sending traces to LangSmith (paid). Configure local-only mode:

```python
import os
os.environ["LANGCHAIN_TRACING_V2"] = "false"
os.environ["LANGCHAIN_API_KEY"] = "not-needed"
```

Document this in `resources/agents/langgraph/` README and component script.
Do **not** set `LANGCHAIN_API_KEY` to a real key in `.env.example`.

## Acceptance Criteria

- `langgraph_health` confirms `import langgraph` succeeds in container
- `langgraph_run example_graph` completes without error
- LLM calls route through llama-swap
- No traces sent to LangSmith (confirm with `LANGCHAIN_TRACING_V2=false`)

## Related

- [FEATURE-022](FEATURE-022.md) — CrewAI (shares `hts-ai-agents` container)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md) — row: `langchain-ai/langgraph`
