#!/usr/bin/env bash
# scripts/components/deerflow/deerflow.sh — DeerFlow agent workflow harness
#
# Standalone usage:
#   ./scripts/components/deerflow/deerflow.sh              # full: install + configure + start + health
#   ./scripts/components/deerflow/deerflow.sh --install    # install only
#   ./scripts/components/deerflow/deerflow.sh --configure  # configure only
#   ./scripts/components/deerflow/deerflow.sh --start      # start only
#   ./scripts/components/deerflow/deerflow.sh --stop       # stop
#   ./scripts/components/deerflow/deerflow.sh --restart    # restart (stop + start)
#   ./scripts/components/deerflow/deerflow.sh --health     # health check only
#   ./scripts/components/deerflow/deerflow.sh --status     # show status + port + health
#   ./scripts/components/deerflow/deerflow.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
DEERFLOW_CONTAINER="${DEERFLOW_CONTAINER:-hts-ai-deerflow-1}"
DEERFLOW_PORT="${DEERFLOW_PORT:-3002}"
DEERFLOW_BACKEND_PORT="${DEERFLOW_BACKEND_PORT:-8003}"

# ── Functions ────────────────────────────────────────────────────────────────

# deerflow_install — Pull DeerFlow + sandbox images via compose
deerflow_install() {
  step "DeerFlow — install"
  compose_pull --profile deerflow
  ok "DeerFlow images pulled."
}

# deerflow_configure — Validate configuration
deerflow_configure() {
  step "DeerFlow — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^DEERFLOW_PORT=" "$env_file" 2>/dev/null; then
    printf 'DEERFLOW_PORT=%s\n' "$DEERFLOW_PORT" >> "$env_file"
    info "Added DEERFLOW_PORT=${DEERFLOW_PORT} to .env"
  fi

  info "Web UI port: ${DEERFLOW_PORT}"
  info "Backend port: ${DEERFLOW_BACKEND_PORT}"
  ok "DeerFlow configured."
}

# deerflow_start — Bring up DeerFlow + sandbox via compose
deerflow_start() {
  step "DeerFlow — start"
  compose_up --profile deerflow
  ok "DeerFlow started (UI :${DEERFLOW_PORT}, backend :${DEERFLOW_BACKEND_PORT})."
}

# deerflow_stop — Bring down DeerFlow + sandbox
deerflow_stop() {
  step "DeerFlow — stop"
  compose_down --profile deerflow
  ok "DeerFlow stopped."
}

# deerflow_health — Probe the DeerFlow web UI
deerflow_health() {
  health_probe "DeerFlow :${DEERFLOW_PORT}" "http://localhost:${DEERFLOW_PORT}/"
}

deerflow_restart() {
  deerflow_stop
  deerflow_start
}

deerflow_destroy() {
  step "DeerFlow — destroy"
  compose_down --profile deerflow -v
  ok "DeerFlow destroyed."
}

deerflow_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=deerflow" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "DeerFlow is running (port ${DEERFLOW_PORT})"
  else
    warn "DeerFlow is not running."
  fi
  deerflow_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   deerflow_install   ;;
    configure) deerflow_configure ;;
    start)     deerflow_start     ;;
    stop)      deerflow_stop      ;;
    restart)   deerflow_restart   ;;
    health)    deerflow_health    ;;
    status)    deerflow_status    ;;
    destroy)   deerflow_destroy   ;;
    default)
      deerflow_install
      deerflow_configure
      deerflow_start
      deerflow_health
      ;;
  esac
fi
