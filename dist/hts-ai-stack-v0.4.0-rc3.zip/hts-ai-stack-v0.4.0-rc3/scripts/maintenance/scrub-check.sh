#!/usr/bin/env bash
# scrub-check.sh — scan for PII / secrets / operator-specific strings.
#
# Usage:
#   scrub-check.sh                 # scan staged files only (pre-commit default)
#   scrub-check.sh --all           # scan entire working tree (minus gitignored)
#   scrub-check.sh --path docs/    # scan a specific subtree
#   scrub-check.sh --paranoid      # add extra name-corpus rules (noisy)
#   scrub-check.sh --fix-paths     # rewrite /home/$USER/ -> /home/<user>/ in staged files
#
# Exit codes:
#   0 = clean
#   1 = one or more hits (commit should be aborted)
#   2 = usage / setup error
#
# Reads an optional user-local deny list from config/pii-deny.txt
# (gitignored). Format: one token per line, comments with '#', matched
# case-insensitively with word boundaries.

set -uo pipefail

repo_root="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$repo_root"

MODE=staged   # staged | all | path
SCAN_PATH=
PARANOID=0
FIX_PATHS=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --all)       MODE=all; shift ;;
    --path)      MODE=path; SCAN_PATH="${2:-}"; shift 2 ;;
    --paranoid)  PARANOID=1; shift ;;
    --fix-paths) FIX_PATHS=1; shift ;;
    -h|--help)   sed -n '2,30p' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

tmpfiles=$(mktemp)
trap 'rm -f "$tmpfiles"' EXIT

case "$MODE" in
  staged)
    git diff --cached --name-only --diff-filter=ACMR > "$tmpfiles"
    ;;
  all)
    git ls-files > "$tmpfiles"
    ;;
  path)
    [[ -n "$SCAN_PATH" ]] || { echo "--path requires an argument" >&2; exit 2; }
    if [[ -d "$SCAN_PATH" ]]; then
      find "$SCAN_PATH" -type f > "$tmpfiles"
    else
      git ls-files -- "$SCAN_PATH" > "$tmpfiles"
    fi
    ;;
esac

filter_files() {
  while IFS= read -r f; do
    [[ -f "$f" ]] || continue
    local sz; sz=$(stat -c '%s' "$f" 2>/dev/null || echo 0)
    (( sz > 2000000 )) && continue
    file --mime "$f" 2>/dev/null | grep -qi 'charset=binary' && continue
    printf '%s\n' "$f"
  done < "$tmpfiles"
}

files=$(filter_files)
[[ -z "$files" ]] && { echo "scrub-check: no files to scan"; exit 0; }

rules=(
  'BEGIN (RSA|EC|OPENSSH|PGP|DSA|ENCRYPTED|PRIVATE) (PRIVATE )?KEY|private key material'
  'ghp_[A-Za-z0-9]{36}|GitHub personal access token'
  'github_pat_[A-Za-z0-9_]{22,}|GitHub fine-grained PAT'
  'xox[baprs]-[A-Za-z0-9-]{10,}|Slack token'
  'AIza[0-9A-Za-z_-]{35}|Google API key'
  'sk-[A-Za-z0-9]{32,}|OpenAI-style API key'
  'AKIA[0-9A-Z]{16}|AWS access key'
  '\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b|JWT token'
  '(?i)(password|passwd|secret|api[_-]?key|auth[_-]?token|access[_-]?token)\s*[:=]\s*["'\''](?!\$\{)[^"'\''\n]{12,}["'\'']|inline credential assignment'
  '/home/'"tim"'/|operator home path'
  '\b''tim''@htsai\.net\b|operator email'
  '\bKEEP''ITTUNED\b|operator NAS hostname'
  '\bhta''-ai\b|operator workstation hostname'
  '\b192\.168\.''77''\.165\b|operator NAS IP'
  '"token"\s*:\s*"[A-Fa-f0-9]{32,}"|bare hex token in JSON'
)

deny_file="config/pii-deny.txt"
if [[ -f "$deny_file" ]]; then
  names=$(grep -vE '^\s*($|#)' "$deny_file" | awk '{print $1}' | tr '\n' '|' | sed 's/|$//')
  if [[ -n "$names" ]]; then
    rules+=( "(?i)\b(${names})\b|operator deny list (config/pii-deny.txt)" )
  fi
fi

if (( PARANOID )); then
  rules+=(
    '\b\d{3}-\d{2}-\d{4}\b|possible US SSN'
    '\b\(\d{3}\)\s?\d{3}-\d{4}\b|possible US phone'
  )
fi

if (( FIX_PATHS )); then
  while IFS= read -r f; do
    [[ -f "$f" ]] || continue
    sed -i -E "s#/home/${USER}/#/home/<user>/#g" "$f"
  done <<< "$files"
  echo "scrub-check: --fix-paths applied"
fi

hits=0
while IFS= read -r f; do
  [[ -f "$f" ]] || continue
  for rule in "${rules[@]}"; do
    pattern="${rule%|*}"
    label="${rule##*|}"
    if matches=$(grep -nP --color=never "$pattern" "$f" 2>/dev/null); then
      while IFS= read -r line; do
        echo "✖ $f: $label"
        echo "    $line"
        hits=$((hits + 1))
      done <<< "$matches"
    fi
  done
done <<< "$files"

if (( hits > 0 )); then
  echo
  echo "scrub-check: $hits hit(s) found."
  echo "  - Review above and either redact or adjust rules."
  echo "  - Add operator-local names/pets/handles to config/pii-deny.txt"
  echo "    (gitignored — see config/pii-deny.txt.example)."
  exit 1
fi

echo "scrub-check: clean"
exit 0
