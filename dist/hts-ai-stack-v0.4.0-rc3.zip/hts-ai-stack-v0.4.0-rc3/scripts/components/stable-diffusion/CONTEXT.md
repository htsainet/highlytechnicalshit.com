# Stable Diffusion Component

Last updated: 2026-04-17

## What happens here

Stable Diffusion WebUI (AUTOMATIC1111) provides a browser-based interface
for AI image generation. Used in the stack as an alternative to ComfyUI
with GPU acceleration via CUDA.

## Files and structure

| File | Purpose |
|------|---------|
| `stable-diffusion.sh` | Full lifecycle: install, configure, start, stop, health, download |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Community forks (critical)

Stability-AI removed their GitHub repos in late 2025. The Dockerfile uses
community forks by `w-e-w` as replacements:
- `w-e-w/stablediffusion` (was `Stability-AI/stablediffusion`)
- `w-e-w/generative-models` (was `Stability-AI/generative-models`)

These are pre-cloned on the host and COPYed into the Docker image
(BuildKit network is unreliable for large git clones during build).
See `docker/stable-diffusion/repositories/` (gitignored).

## Attention backend

Uses `--opt-sdp-attention` (PyTorch native SDP) instead of xformers.
xFormers PyPI wheels target CUDA 12.4 but the container runs CUDA 12.6,
causing a symbol mismatch at runtime. SDP attention is built into PyTorch
and works with any CUDA version.

## COMMANDLINE_ARGS gotcha

AUTOMATIC1111's `launch.py` **appends** the `COMMANDLINE_ARGS` environment
variable to `sys.argv`. This means if you set flags via both `environment:`
and `command:` in docker-compose, BOTH sets of flags are active. Always use
`command:` in compose to fully override the Dockerfile CMD — don't rely on
the env var alone.
