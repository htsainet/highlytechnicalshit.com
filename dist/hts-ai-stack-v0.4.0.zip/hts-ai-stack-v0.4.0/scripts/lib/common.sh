#!/usr/bin/env bash
# scripts/lib/common.sh — Shared colors, logging, and environment helpers
# Source this file; do NOT run directly.

# ── Colors ────────────────────────────────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

# ── Repo root detection ──────────────────────────────────────────────────────
# Callers may override REPO_DIR before sourcing; otherwise auto-detect.
if [[ -z "${REPO_DIR:-}" ]]; then
  REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

# ── Logging ───────────────────────────────────────────────────────────────────
# LOG_FILE can be set by the caller before or after sourcing this file.
_log() {
  local level="$1"; shift
  [[ -w "${LOG_FILE:-}" || -z "${LOG_FILE:-}" ]] && \
    echo "[$(date '+%F %T')] [$level] $*" >> "${LOG_FILE:-/dev/null}" 2>/dev/null || true
}

info()   { echo -e "${GREEN}[INFO]${NC} $*" >&2; _log INFO "$*"; }
warn()   { echo -e "${YELLOW}[WARN]${NC} $*" >&2; _log WARN "$*"; }
fail()   { echo -e "${RED}[FAIL]${NC} $*" >&2; [[ -n "${LOG_FILE:-}" ]] && echo -e "${RED}[FAIL]${NC} See log: $LOG_FILE" >&2; _log FAIL "$*"; exit 1; }
step()   { echo -e "\n${CYAN}${BOLD}══ $* ══${NC}" >&2; _log STEP "══ $* ══"; }
ok()     { echo -e "${GREEN}[OK]${NC} $*" >&2; _log OK "$*"; }
skip()   { echo -e "${CYAN}[SKIP]${NC} $*" >&2; _log SKIP "$*"; }

banner() {
  echo -e "\n${CYAN}${BOLD}╔══════════════════════════════════════════════════════╗${NC}" >&2
  echo -e "${CYAN}${BOLD}║                HTS AI Stack Installer                ║${NC}" >&2
  echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════╝${NC}\n" >&2
  _log INFO "=== HTS AI STACK INSTALLER STARTED ==="
}

# ── Interactive prompt helpers ────────────────────────────────────────────────

# prompt_yesno <title> <message> [--default-yes]
# Shows a whiptail yes/no dialog. Returns 0 (Yes) or 1 (No/Cancel).
prompt_yesno() {
  local title="$1"
  local message="$2"
  local default_yes="${3:-}"
  local extra_args=()
  [[ "$default_yes" == "--default-yes" ]] && extra_args+=("--defaultno" )
  whiptail --title "$title" --yesno "$message" 10 60 "${extra_args[@]}" 3>&1 1>&2 2>&3
}

# prompt_checklist <title> <message> <nameref_in> <nameref_out>
# Shows a whiptail checklist. Items passed as an array of "tag|desc|on|off".
# <nameref_in>  — name of array variable: each element "tag|description|on" or "tag|description|off"
# <nameref_out> — name of array variable to receive selected tags
#
# Example:
#   items=("foo|Do the foo thing|on" "bar|Do the bar thing|off")
#   prompt_checklist "Pick actions" "Space to toggle, Enter to confirm" items selected
#   for tag in "${selected[@]}"; do echo "$tag"; done
prompt_checklist() {
  local title="$1"
  local message="$2"
  local -n _pc_items="$3"
  local -n _pc_out="$4"

  local args=()
  for entry in "${_pc_items[@]}"; do
    local tag="${entry%%|*}"; local rest="${entry#*|}"
    local desc="${rest%%|*}"; local state="${rest##*|}"
    args+=("$tag" "$desc" "$state")
  done

  local raw
  raw=$(whiptail \
    --title "$title" \
    --checklist "$message" \
    20 78 "${#_pc_items[@]}" \
    "${args[@]}" \
    3>&1 1>&2 2>&3) || { _pc_out=(); return 1; }

  # Parse whiptail output: space-separated double-quoted tokens
  _pc_out=()
  for token in $raw; do
    _pc_out+=("${token//\"/}")
  done
}

# ── Environment loader ────────────────────────────────────────────────────────
load_env() {
  local env_file="${1:-$REPO_DIR/.env}"
  if [[ -f "$env_file" ]]; then
    set -a
    # shellcheck source=/dev/null
    source "$env_file"
    set +a
  fi
}

# ── Shared OpenShell installer ────────────────────────────────────────────────
# install_openshell_nvidia — Install or verify OpenShell using NVIDIA's script.
#
# Used by the nemoclaw component so openshell version stays
# in sync and install logic isn't duplicated.
#
# Version is supplied by the caller via OPENSHELL_VERSION env var.
# Caller reads the canonical value from nemoclaw.manifest.json
# upstream.openshell_pinned_version. See DEVIATIONS.md.
# The NVIDIA install-openshell.sh script is idempotent — exits clean if already
# at the pinned version. If the script is unreachable, falls back to a direct
# GitHub release download pinned to max_ver.
#
# Returns 0 on success, 1 on failure. Does NOT call fail() — let the caller
# decide how to handle a failure.
install_openshell_nvidia() {
  local max_ver="${OPENSHELL_VERSION:?install_openshell_nvidia requires OPENSHELL_VERSION env var}"
  local min_ver="$max_ver"

  # Quick-exit if already at pinned version
  local current_ver
  current_ver=$(openshell --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
  if [[ "$current_ver" == "$max_ver" ]]; then
    info "OpenShell already at v${max_ver}"
    return 0
  fi

  # Try NVIDIA's install-openshell.sh (authoritative, idempotent, version-pinned)
  local script_url="https://raw.githubusercontent.com/NVIDIA/NemoClaw/refs/heads/main/scripts/install-openshell.sh"
  local tmp_script
  tmp_script=$(mktemp /tmp/install-openshell.XXXXXX.sh)

  if curl -fsSL "$script_url" -o "$tmp_script" 2>/dev/null; then
    if bash "$tmp_script"; then
      rm -f "$tmp_script"
      # Re-verify: NVIDIA script is idempotent but may install a range of versions
      local installed_ver
      installed_ver=$(openshell --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
      if [[ "$installed_ver" == "$max_ver" ]]; then
        ok "OpenShell v${installed_ver} installed via NVIDIA install-openshell.sh"
        return 0
      fi
      warn "NVIDIA script installed v${installed_ver:-unknown} (expected v${max_ver}) — falling back to pinned direct download"
    else
      warn "NVIDIA install-openshell.sh failed — falling back to direct download"
    fi
  else
    warn "Could not fetch ${script_url} — falling back to direct download"
  fi
  rm -f "$tmp_script"

  # Fallback: direct GitHub release download pinned to max_ver
  local arch tarball dl_url tmpdir
  arch=$(uname -m)
  tarball="openshell-${arch}-unknown-linux-musl.tar.gz"
  dl_url="https://github.com/NVIDIA/OpenShell/releases/download/v${max_ver}/${tarball}"
  tmpdir=$(mktemp -d /tmp/openshell-install.XXXXXX)

  if ! curl -fsSL "$dl_url" -o "${tmpdir}/${tarball}"; then
    rm -rf "$tmpdir"
    warn "Failed to download OpenShell v${max_ver} from ${dl_url}"
    return 1
  fi
  tar xzf "${tmpdir}/${tarball}" -C "$tmpdir"
  sudo install -m 755 "${tmpdir}/openshell" /usr/local/bin/openshell
  rm -rf "$tmpdir"
  ok "OpenShell v${max_ver} installed (direct download)"
  return 0
}
