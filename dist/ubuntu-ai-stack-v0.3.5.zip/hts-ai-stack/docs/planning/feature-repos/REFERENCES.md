# Feature Repos — Tracking

Non-security repositories relevant to this stack: agents, memory, platforms, UI, personas, skills, integrations.
Review workflow documented in [CONTEXT.md](CONTEXT.md).

**Trust:** `high` · `reference` · `medium` · `unknown` · `not-trusted`
**Health:** `healthy` · `watch` · `stale`

---

## Core Stack References

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [NVIDIA/OpenShell](https://github.com/NVIDIA/OpenShell) | Trusted upstream reference | nvidia | high | | | | | | |
| [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) | Trusted upstream reference | nvidia | high | | | | | | |
| [microsoft/PromptKit](https://github.com/microsoft/PromptKit) | Trusted | microsoft | high | | | | | | |
| [openclaw/openclaw](https://github.com/openclaw/openclaw) | OpenClaw repo | openclaw-ecosystem | reference | | | | | | |
| [ollama/ollama](https://github.com/ollama/ollama) | Ollama repo | reference | reference | | | | | | |
| [ollama/ollama-python](https://github.com/ollama/ollama-python) | Ollama Python integration | reference | reference | | | | | | |
| [ollama/ollama-js](https://github.com/ollama/ollama-js) | Ollama JavaScript integration | reference | reference | | | | | | |
| [open-webui/open-webui](https://github.com/open-webui/open-webui) | OpenWebUI | reference | reference | | | | | | |

## LLM / Inference References

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [ggml-org/llama.cpp](https://github.com/ggml-org/llama.cpp) | llama.cpp | reference | reference | | | | | | |
| [ggml-org/whisper.cpp](https://github.com/ggml-org/whisper.cpp) | whisper.cpp | reference | reference | | | | | | |
| [ggml-org/llama.vscode](https://github.com/ggml-org/llama.vscode) | VS Code plugin | reference | reference | | | | | | |
| [ggml-org/llama.qtcreator](https://github.com/ggml-org/llama.qtcreator) | Qt Creator plugin | reference | reference | | | | | | |
| [ggml-org/llama.vim](https://github.com/ggml-org/llama.vim) | Vim plugin | reference | reference | | | | | | |
| [ggml-org/ggml](https://github.com/ggml-org/ggml) | Tensor library for machine learning | reference | reference | | | | | | |
| [ggml-org (HuggingFace)](https://huggingface.co/ggml-org) | ggml mirror on HuggingFace | reference | reference | | | | | | |
| [ggml-org/LlamaBarn](https://github.com/ggml-org/LlamaBarn) | macOS-optimized LLM manager (1k★, MIT, Swift). Platform-specific — info only | alternative-platforms | reference | haiku-4-5 | haiku | healthy | 2026-03-24 | 2026-03-31 | |
| [Docker Model Runner](https://docs.docker.com/ai/model-runner/) | Official Docker AI model runner — informational reference | reference | reference | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |

## OpenClaw Ecosystem

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [openclaw/clawhub](https://github.com/openclaw/clawhub) | Official skill + soul registry (7k★); CLI useful but backend is Convex+OpenAI — not self-hostable | openclaw-ecosystem | reference | claude-sonnet-4-6 | | | | | |
| [jasonsiuxMCP/clawon8004](https://github.com/jasonsiuxMCP/clawon8004) | On-chain ERC-8004 agent identity anchoring (3★, Python). Blockchain dependency — evaluate path | openclaw-ecosystem | medium | haiku-4-5 | haiku | healthy | 2026-02-02 | 2026-03-31 | |
| [xhuaustc/openclaw-soul-generator](https://github.com/xhuaustc/openclaw-soul-generator) | Browser-based soul config wizard (0★, HTML, offline-capable). Candidate for docs integration | openclaw-ecosystem | high | haiku-4-5 | haiku | healthy | 2026-03-17 | 2026-03-31 | |
| [will-assistant/openclaw-agents](https://github.com/will-assistant/openclaw-agents) | 217 curated agent personas (56★, MIT, Shell). Use as content source | openclaw-ecosystem | high | haiku-4-5 | haiku | healthy | 2026-03-09 | 2026-03-31 | |
| [ThatGuySizemore/openclaw-agent-config](https://github.com/ThatGuySizemore/openclaw-agent-config) | Intelligent agent context file editing skill (5★, MIT). Reference for safe config workflows | openclaw-ecosystem | medium | haiku-4-5 | haiku | healthy | 2026-02-02 | 2026-03-31 | |
| [openclawdoc/openclaw-workspace](https://github.com/openclawdoc/openclaw-workspace) | Official workspace scaffold (0★). Baseline template for AGENTS.md, SOUL.md | openclaw-ecosystem | reference | haiku-4-5 | haiku | healthy | 2026-02-22 | 2026-03-31 | |
| [cucuapi/openclaw-prompts](https://github.com/cucuapi/openclaw-prompts) | Light config collection (0★). Priority low | openclaw-ecosystem | unknown | haiku-4-5 | haiku | watch | 2026-03-30 | 2026-03-31 | |
| [yomero243/PhysicClaw-VEA](https://github.com/yomero243/PhysicClaw-VEA) | Real-time 3D visualization for agent souls (2★, TypeScript) | openclaw-ecosystem | medium | haiku-4-5 | haiku | healthy | 2026-03-22 | 2026-03-31 | |
| [BitmapAsset/pepeclaw](https://github.com/BitmapAsset/pepeclaw) | Real-time 3D agent visualization (1★, Three.js/React, MIT). Reference for UI patterns | openclaw-ecosystem | medium | haiku-4-5 | haiku | healthy | 2026-03-30 | 2026-03-31 | |
| [clawsouls/soulspec](https://github.com/clawsouls/soulspec) | Open standard for SOUL.md format (2★, TypeScript). Standardization candidate | openclaw-ecosystem | high | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [monswag/soul-wizard](https://github.com/monswag/soul-wizard) | Telegram Mini App for SOUL.md config (0★, TypeScript). Niche | openclaw-ecosystem | unknown | haiku-4-5 | haiku | watch | 2026-02-25 | 2026-03-31 | |

## Agents

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [NousResearch/hermes-agent](https://github.com/NousResearch/hermes-agent) | Self-improving AI agent (20k★, MIT, Python). Built-in learning loop, multi-platform. Highly relevant | agents | high | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [AstrBotDevs/AstrBot](https://github.com/AstrBotDevs/AstrBot) | Agentic IM chatbot infrastructure (28k★, AGPLv3, Python). Verify AGPL compatibility | agents | medium | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [agentscope-ai/HiClaw](https://github.com/agentscope-ai/HiClaw) | Collaborative Multi-Agent OS via Matrix rooms (3.6k★, Apache 2.0). Evaluate Matrix integration | agents | medium | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [aiming-lab/MetaClaw](https://github.com/aiming-lab/MetaClaw) | Self-evolving agent (3.1k★, MIT, Python). Compare with hermes-agent patterns | agents | medium | haiku-4-5 | haiku | healthy | 2026-03-29 | 2026-03-31 | |
| [BlockRunAI/ClawRouter](https://github.com/BlockRunAI/ClawRouter) | Agent-native LLM router (6.5k★, MIT, TypeScript). 41+ models, <1ms routing | agents | high | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [nearai/ironclaw](https://github.com/nearai/ironclaw) | OpenClaw-inspired Rust implementation (11k★, Apache 2.0). Privacy/security focused | agents | high | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |

## Memory

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [MemTensor/MemOS](https://github.com/MemTensor/MemOS) | AI memory OS (8k★, Apache 2.0, arXiv-backed). Evaluate local path against Ollama | memory | medium | claude-sonnet-4-6 | | | | | |
| [NevaMind-AI/memU](https://github.com/NevaMind-AI/memU) | Filesystem-metaphor memory (13k★). License is "other" — must review before adoption | memory | medium | claude-sonnet-4-6 | | | | | |
| [EverMind-AI/EverMemOS](https://github.com/EverMind-AI/EverMemOS) | Memory OS (3.5k★, Apache 2.0). Heavy deps (MongoDB, Elasticsearch, Milvus) | memory | medium | claude-sonnet-4-6 | | | | | |

## Skills

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [VoltAgent/awesome-openclaw-skills](https://github.com/VoltAgent/awesome-openclaw-skills) | 5,200+ community skills indexed by category (43k★, MIT). Primary skills discovery | skills | high | claude-sonnet-4-6 | | | | | |
| [nemoclaw-nvidia/NemoClaw](https://github.com/nemoclaw-nvidia/NemoClaw) | Unofficial installer (3★). Routes to NVIDIA cloud — conflicts with self-hosted goals | skills | not-trusted | claude-sonnet-4-6 | | | | | |
| [kepano/obsidian-skills](https://github.com/kepano/obsidian-skills) | Obsidian agent skills (18.5k★, MIT). Install if team uses Obsidian | skills | reference | claude-sonnet-4-6 | | | | | |
| [openclaw/skills](https://github.com/openclaw/skills) | Do not use directly | not-trusted | not-trusted | | | | | | |

## Use Cases

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [hesamsheikh/awesome-openclaw-usecases](https://github.com/hesamsheikh/awesome-openclaw-usecases) | 42+ real-world use cases (28k★, MIT). Verify linked skill sources | use-cases | high | haiku-4-5 | haiku | healthy | 2026-03-24 | 2026-03-31 | |

## Alternative Platforms

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [RightNow-AI/openfang](https://github.com/RightNow-AI/openfang) | Agent OS in Rust (16k★, Apache 2.0). 137K LOC, 1,767+ tests. Pre-1.0 | alternative-platforms | high | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [memovai/mimiclaw](https://github.com/memovai/mimiclaw) | Pocket AI on $5 chip (4.9k★, MIT, C). Niche embedded — info only | alternative-platforms | reference | haiku-4-5 | haiku | healthy | 2026-03-17 | 2026-03-31 | |
| [intervalrain/OpenClaw.Net](https://github.com/intervalrain/OpenClaw.Net) | OpenClaw in .NET (12★, MIT, C#). Very early — monitor | alternative-platforms | unknown | haiku-4-5 | haiku | watch | 2026-03-31 | 2026-03-31 | |
| [qwibitai/nanoclaw](https://github.com/qwibitai/nanoclaw) | Lightweight container alternative (26k★, MIT, TypeScript). Multi-platform messaging | alternative-platforms | high | haiku-4-5 | haiku | healthy | 2026-03-30 | 2026-03-31 | |
| [LostRuins/koboldcpp](https://github.com/LostRuins/koboldcpp) | GGUF model runner (9.9k★, AGPLv3, C++). Ollama alternative — check AGPL | alternative-platforms | medium | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [containers/ramalama](https://github.com/containers/ramalama) | Container-native AI model serving (2.7k★, MIT, Python). Ollama replacement/alongside | alternative-platforms | high | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [intentee/paddler](https://github.com/intentee/paddler) | LLM load balancer (1.5k★, Apache 2.0, Rust). Multi-model scaling | alternative-platforms | high | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [mostlygeek/llama-swap](https://github.com/mostlygeek/llama-swap) | Model hot-swapping (3k★, MIT, Go). Solves OLLAMA_MAX_LOADED_MODELS=1 | alternative-platforms | medium | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [vllm-project/semantic-router](https://github.com/vllm-project/semantic-router) | Mixture-of-Models router (3.6k★, Apache 2.0, Go). Compare against paddler | alternative-platforms | high | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [openclaw-rocks/openclaw-operator](https://github.com/openclaw-rocks/openclaw-operator) | Kubernetes operator (272★, Apache 2.0, Go). For multi-node scale-out | alternative-platforms | medium | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |

## References / Curated Lists

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [VoltAgent/awesome-nemoclaw](https://github.com/VoltAgent/awesome-nemoclaw) | Curated NemoClaw presets and recipes | reference | reference | claude-sonnet-4-6 | | | | | |
| [SillyTavern/SillyTavern-Docs](https://github.com/SillyTavern/SillyTavern-Docs) | Stack documentation; verify before adopting | sillytavern | medium | | | | | | |

## Ring Central (not-trusted)

| Repo | Description | Category | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|----------|-------|---------------|--------|--------|-------------|--------------|---------|
| [ringclaw/openclaw-ringcentral](https://github.com/ringclaw/openclaw-ringcentral) | RC Team Messaging plugin — requires corporate account; not self-hosted relevant | ring-central | not-trusted | claude-sonnet-4-6 | | | | | |
| [ringclaw/ringclaw](https://github.com/ringclaw/ringclaw) | RC AI agent bridge (Go) — requires corporate account | ring-central | not-trusted | claude-sonnet-4-6 | | | | | |

## Not Yet Reviewed

Repos below are from the master list but have not been reviewed. Categorized by original tag.

### Character Cards / Lorebooks / Personas

| Repo | Category | Trust |
|------|----------|-------|
| [dmitryplyaskin/SillyInnkeeper](https://github.com/dmitryplyaskin/SillyInnkeeper) | character-cards | unknown |
| [OpenRouterTeam/character](https://github.com/OpenRouterTeam/character) | character-cards | unknown |
| [Nya-Foundation/card-forge](https://github.com/Nya-Foundation/card-forge) | character-cards | unknown |
| [bmen25124/SillyTavern-Custom-Scenario](https://github.com/bmen25124/SillyTavern-Custom-Scenario) | character-cards | unknown |
| [BobTheBinChicken/Ultimate-Persona](https://github.com/BobTheBinChicken/Ultimate-Persona) | character-cards | unknown |
| [bradennapier/character-cards-v2](https://github.com/bradennapier/character-cards-v2) | character-cards | unknown |
| [malfoyslastname/character-card-spec-v2](https://github.com/malfoyslastname/character-card-spec-v2) | character-cards | unknown |
| [prolix-oc/SillyTavern-SimTracker](https://github.com/prolix-oc/SillyTavern-SimTracker) | character-cards | unknown |
| [aikohanasaki/SillyTavern-MemoryBooks](https://github.com/aikohanasaki/SillyTavern-MemoryBooks) | lorebooks | unknown |
| [Coneja-Chibi/TunnelVision](https://github.com/Coneja-Chibi/TunnelVision) | lorebooks | unknown |
| [cha1latte/universal-lorebook-creator](https://github.com/cha1latte/universal-lorebook-creator) | lorebooks | unknown |
| [aikohanasaki/SillyTavern-LorebookOrdering](https://github.com/aikohanasaki/SillyTavern-LorebookOrdering) | lorebooks | unknown |
| [DangerDaza/Dooms-Enhancement-Suite](https://github.com/DangerDaza/Dooms-Enhancement-Suite) | lorebooks | unknown |
| [Ca1nlee/persona-cloner-skill](https://github.com/Ca1nlee/persona-cloner-skill) | personas | unknown |
| [duanecilliers/openclaw-admin](https://github.com/duanecilliers/openclaw-admin) | personas | unknown |
| [unisone/openclaw-config](https://github.com/unisone/openclaw-config) | personas | unknown |
| [robbyczgw-cla/clawdbot-personas](https://github.com/robbyczgw-cla/clawdbot-personas) | personas | unknown |
| [acnlabs/OpenPersona](https://github.com/acnlabs/OpenPersona) | personas | unknown |
| [TravisLeeeeee/awesome-openclaw-personas](https://github.com/TravisLeeeeee/awesome-openclaw-personas) | personas | unknown |
| [kahalewai/openclaw-secure-personas](https://github.com/kahalewai/openclaw-secure-personas) | personas | unknown |
| [oceanbase/powermem](https://github.com/oceanbase/powermem) | memory | unknown |
| [comet-ml/opik-openclaw](https://github.com/comet-ml/opik-openclaw) | observability | unknown |
| [MemTensor/MemOS-Cloud-OpenClaw-Plugin](https://github.com/MemTensor/MemOS-Cloud-OpenClaw-Plugin) | memory | unknown |

### SillyTavern

| Repo | Category | Trust |
|------|----------|-------|
| [SpicyMarinara/rpg-companion-sillytavern](https://github.com/SpicyMarinara/rpg-companion-sillytavern) | sillytavern | unknown |
| [city-unit/SillyTavern-Chub-Search](https://github.com/city-unit/SillyTavern-Chub-Search) | sillytavern | unknown |
| [BlueprintCoding/SillyTavernSimpleLauncher](https://github.com/BlueprintCoding/SillyTavernSimpleLauncher) | sillytavern | unknown |
| [bmen25124/SillyTavern-Character-Creator](https://github.com/bmen25124/SillyTavern-Character-Creator) | sillytavern | unknown |
| [SillyTavern/SillyTavern-Timelines](https://github.com/SillyTavern/SillyTavern-Timelines) | sillytavern | unknown |
| [SillyTavern/SillyTavern-Content](https://github.com/SillyTavern/SillyTavern-Content) | sillytavern | unknown |
| [LenAnderson/SillyTavern-LALib](https://github.com/LenAnderson/SillyTavern-LALib) | sillytavern | unknown |
| [NeoTavern/NeoTavern-Frontend](https://github.com/NeoTavern/NeoTavern-Frontend) | sillytavern | unknown |
| [mia13165/SillyTavern-BotBrowser](https://github.com/mia13165/SillyTavern-BotBrowser) | sillytavern | unknown |

### Integrations

| Repo | Category | Trust |
|------|----------|-------|
| [AijooseFactory/clawproxy](https://github.com/AijooseFactory/clawproxy) | integration | unknown |
| [FanYin1/openclaw-sillytavern-cards](https://github.com/FanYin1/openclaw-sillytavern-cards) | integration | unknown |
| [ArlartArmin/openclaw-tavern-chat](https://github.com/ArlartArmin/openclaw-tavern-chat) | integration | unknown |

### UI Helpers

| Repo | Category | Trust |
|------|----------|-------|
| [builderz-labs/mission-control](https://github.com/builderz-labs/mission-control) | ui-helpers | unknown |
| [TianyiDataScience/openclaw-control-center](https://github.com/TianyiDataScience/openclaw-control-center) | ui-helpers | unknown |
| [tugcantopaloglu/openclaw-dashboard](https://github.com/tugcantopaloglu/openclaw-dashboard) | ui-helpers | unknown |
| [rizqcon/openclawdev-taskboard](https://github.com/rizqcon/openclawdev-taskboard) | ui-helpers | unknown |

### Mobile

| Repo | Category | Trust |
|------|----------|-------|
| [a-ghorbani/pocketpal-ai](https://github.com/a-ghorbani/pocketpal-ai) | mobile | unknown |
| [guinmoon/LLMFarm](https://github.com/guinmoon/LLMFarm) | mobile | unknown |
| [Vali-98/ChatterUI](https://github.com/Vali-98/ChatterUI) | mobile | unknown |
| [shubham0204/SmolChat-Android](https://github.com/shubham0204/SmolChat-Android) | mobile | unknown |

### Misc / Unclassified

| Repo | Category | Trust |
|------|----------|-------|
| [ringhyacinth/Star-Office-UI](https://github.com/ringhyacinth/Star-Office-UI) | misc | unknown |
| [mksglu/context-mode](https://github.com/mksglu/context-mode) | misc | unknown |
| [ValueCell-ai/ClawX](https://github.com/ValueCell-ai/ClawX) | misc | unknown |
| [MervinPraison/PraisonAI](https://github.com/MervinPraison/PraisonAI) | misc | unknown |
| [Gen-Verse/OpenClaw-RL](https://github.com/Gen-Verse/OpenClaw-RL) | misc | unknown |
| [mnfst/manifest](https://github.com/mnfst/manifest) | misc | unknown |
| [Martian-Engineering/lossless-claw](https://github.com/Martian-Engineering/lossless-claw) | misc | unknown |
| [linuxhsj/openclaw-zero-token](https://github.com/linuxhsj/openclaw-zero-token) | misc | unknown |
| [ggml-org/whisper.cpp — wchess](https://github.com/ggml-org/whisper.cpp/tree/master/examples/wchess) | misc | unknown |
| [fastrepl/char](https://github.com/fastrepl/char) | misc | unknown |
| [handy.computer](https://handy.computer) | misc | unknown |
| [superwhisper.com](https://superwhisper.com/) | misc | unknown |
| [VLC AI Subtitles (tweet)](https://x.com/videolan/status/1877072497146781946) | misc | unknown |
| [centminmod/explain-openclaw](https://github.com/centminmod/explain-openclaw) | misc | unknown |
| [davidgivondoh/OpenClaw-Automation](https://github.com/davidgivondoh/OpenClaw-Automation) | misc | unknown |
| [win4r/ClawTeam-OpenClaw](https://github.com/win4r/ClawTeam-OpenClaw) | misc | unknown |
| [UniRound-Tec/Aurogen](https://github.com/UniRound-Tec/Aurogen) | misc | unknown |
| [LeoYeAI/openclaw-backup](https://github.com/LeoYeAI/openclaw-backup) | misc | unknown |
| [heshengtao/super-agent-party](https://github.com/heshengtao/super-agent-party) | misc | unknown |
| [grp06/openclaw-studio](https://github.com/grp06/openclaw-studio) | misc | unknown |
| [xmanrui/OpenClaw-bot-review](https://github.com/xmanrui/OpenClaw-bot-review) | misc | unknown |
| [shenhao-stu/openclaw-agents](https://github.com/shenhao-stu/openclaw-agents) | misc | unknown |
| [getclawe/clawe](https://github.com/getclawe/clawe) | misc | unknown |
| [daggerhashimoto/openclaw-nerve](https://github.com/daggerhashimoto/openclaw-nerve) | misc | unknown |
| [raulvidis/openclaw-multi-agent-kit](https://github.com/raulvidis/openclaw-multi-agent-kit) | misc | unknown |
| [nikilster/clawflows](https://github.com/nikilster/clawflows) | misc | unknown |
| [supermemoryai/openclaw-supermemory](https://github.com/supermemoryai/openclaw-supermemory) | misc | unknown |
| [mudrii/openclaw-dashboard](https://github.com/mudrii/openclaw-dashboard) | misc | unknown |
| [LeoYeAI/openclaw-master-skills](https://github.com/LeoYeAI/openclaw-master-skills) | misc | unknown |
| [LeoYeAI/openclaw-guardian](https://github.com/LeoYeAI/openclaw-guardian) | misc | unknown |
| [LeoYeAI/openclaw-ultra-scraping](https://github.com/LeoYeAI/openclaw-ultra-scraping) | misc | unknown |
| [LeoYeAI/myclaw-bench](https://github.com/LeoYeAI/myclaw-bench) | misc | unknown |
| [LeoYeAI/ask-lenny](https://github.com/LeoYeAI/ask-lenny) | misc | unknown |
| [LeoYeAI/openclaw-marketing-skills](https://github.com/LeoYeAI/openclaw-marketing-skills) | misc | unknown |
| [win4r/openclaw-a2a-gateway](https://github.com/win4r/openclaw-a2a-gateway) | misc | unknown |
| [ShunsukeHayashi/openclaw-prod](https://github.com/ShunsukeHayashi/openclaw-prod) | misc | unknown |
| [openxcn/openX](https://github.com/openxcn/openX) | misc | unknown |
| [pbxclaw/pbxclaw](https://github.com/pbxclaw/pbxclaw) | misc | unknown |
| [DJTSmith18/openclaw-voipms-sms](https://github.com/DJTSmith18/openclaw-voipms-sms) | misc | unknown |
| [funny-agent/funnyangel-openviking-setup](https://github.com/funny-agent/funnyangel-openviking-setup) | misc | unknown |
| [proaliceagent/proaliceagent](https://github.com/proaliceagent/proaliceagent) | misc | unknown |
| [iOfficeAI/AionUi](https://github.com/iOfficeAI/AionUi) | unclassified | unknown |
| [xpf0000/FlyEnv](https://github.com/xpf0000/FlyEnv) | unclassified | unknown |
| [evinjohnn/natively-cluely-ai-assistant](https://github.com/evinjohnn/natively-cluely-ai-assistant) | unclassified | unknown |
| [ClawBio/ClawBio](https://github.com/ClawBio/ClawBio) | unclassified | unknown |
| [NadirRouter/NadirClaw](https://github.com/NadirRouter/NadirClaw) | unclassified | unknown |
| [ellipticmarketing/modelrelay](https://github.com/ellipticmarketing/modelrelay) | unclassified | unknown |
| [JasonDocton/lucid-memory](https://github.com/JasonDocton/lucid-memory) | unclassified | unknown |
| [DeepMyst/Mysti](https://github.com/DeepMyst/Mysti) | unclassified | unknown |
| [LeoYeAI/openclaw-auto-dream](https://github.com/LeoYeAI/openclaw-auto-dream) | unclassified | unknown |
| [RogueCtrl/OpenClawDreams](https://github.com/RogueCtrl/OpenClawDreams) | unclassified | unknown |
| [DKistenev/openclaw-inner-life](https://github.com/DKistenev/openclaw-inner-life) | unclassified | unknown |
| [tashfeenahmed/scallopbot](https://github.com/tashfeenahmed/scallopbot) | unclassified | unknown |
| [MidnightV1/openclaw-evo](https://github.com/MidnightV1/openclaw-evo) | unclassified | unknown |
| [ChaosChain/trustless-agents-erc-ri](https://github.com/ChaosChain/trustless-agents-erc-ri) | unclassified | unknown |
| [agent0lab/agent0-ts](https://github.com/agent0lab/agent0-ts) | unclassified | unknown |
| [Eversmile12/create-8004-agent](https://github.com/Eversmile12/create-8004-agent) | unclassified | unknown |
| [murrlincoln/anet](https://github.com/murrlincoln/anet) | unclassified | unknown |
| [CasualHackathon/TrustlessAgents](https://github.com/CasualHackathon/TrustlessAgents) | unclassified | unknown |
| [erc-8004/erc-8004-contracts](https://github.com/erc-8004/erc-8004-contracts) | unclassified | unknown |
| [sudeepb02/awesome-erc8004](https://github.com/sudeepb02/awesome-erc8004) | unclassified | unknown |
| [thedaviddias/souls-directory](https://github.com/thedaviddias/souls-directory) | unclassified | unknown |
| [ExpertVagabond/agent-template](https://github.com/ExpertVagabond/agent-template) | unclassified | unknown |
| [ExpertVagabond/coldstar-colosseum](https://github.com/ExpertVagabond/coldstar-colosseum) | unclassified | unknown |
| [ExpertVagabond/agent-marketplace-site](https://github.com/ExpertVagabond/agent-marketplace-site) | unclassified | unknown |
| [ExpertVagabond/nemofish](https://github.com/ExpertVagabond/nemofish) | unclassified | unknown |
| [ExpertVagabond/awesome-blockchain-mcps](https://github.com/ExpertVagabond/awesome-blockchain-mcps) | unclassified | unknown |
| [swordfeng/yorishiro](https://github.com/swordfeng/yorishiro) | unclassified | unknown |
| [PitayaK/taste.md](https://github.com/PitayaK/taste.md) | unclassified | unknown |
| [iblai/iblai-claw-agents](https://github.com/iblai/iblai-claw-agents) | unclassified | unknown |
| [Jovancoding/Network-AI](https://github.com/Jovancoding/Network-AI) | unclassified | unknown |
| [Open-Source-Legal/OpenContracts](https://github.com/Open-Source-Legal/OpenContracts) | unclassified | unknown |
| [open-gitagent/gitclaw](https://github.com/open-gitagent/gitclaw) | unclassified | unknown |
| [Legit-Control/monorepo](https://github.com/Legit-Control/monorepo) | unclassified | unknown |
| [visivo-io/visivo](https://github.com/visivo-io/visivo) | unclassified | unknown |
| [EYH0602/skillshub](https://github.com/EYH0602/skillshub) | unclassified | unknown |
| [automateyournetwork/gait](https://github.com/automateyournetwork/gait) | unclassified | unknown |
| [riasali-sudo/claude-expert-system](https://github.com/riasali-sudo/claude-expert-system) | unclassified | unknown |
| [mulletmcnasty/molt-cycle](https://github.com/mulletmcnasty/molt-cycle) | unclassified | unknown |
| [artificially-ai/ai-engineering](https://github.com/artificially-ai/ai-engineering) | unclassified | unknown |
| [letta-ai/agent-file](https://github.com/letta-ai/agent-file) | unclassified | unknown |
| [clearml/clearml-server](https://github.com/clearml/clearml-server) | unclassified | unknown |
| [web3infra-foundation/libra](https://github.com/web3infra-foundation/libra) | unclassified | unknown |
| [clearml/clearml](https://github.com/clearml/clearml) | unclassified | unknown |
| [Sandler73/Linux-Security-Audit-Project](https://github.com/Sandler73/Linux-Security-Audit-Project) | unclassified | unknown |
| [ThomasPLibby/Security-Frameworks](https://github.com/ThomasPLibby/Security-Frameworks) | unclassified | unknown |
| [jotyprokash/Ubuntu-nginx-hardening-framework](https://github.com/jotyprokash/Ubuntu-nginx-hardening-framework) | unclassified | unknown |
| [shayanrsh/bug-bounty-toolkit-install-script](https://github.com/shayanrsh/bug-bounty-toolkit-install-script) | unclassified | unknown |
| [opral/lix](https://github.com/opral/lix) | unclassified | unknown |
| [smixs/skill-conductor](https://github.com/smixs/skill-conductor) | unclassified | unknown |
| [Shelpuk-AI-Technology-Consulting/agent-skill-tdd](https://github.com/Shelpuk-AI-Technology-Consulting/agent-skill-tdd) | unclassified | unknown |
| [Charpup/triadev](https://github.com/Charpup/triadev) | unclassified | unknown |
| [Charpup/openclaw-tdd-sdd-skill](https://github.com/Charpup/openclaw-tdd-sdd-skill) | unclassified | unknown |
| [bellfireg/openclaw-superpowers](https://github.com/bellfireg/openclaw-superpowers) | unclassified | unknown |
| [microsoft/PromptWizard](https://github.com/microsoft/PromptWizard) | unclassified | unknown |
| [microsoftarchive/promptbench](https://github.com/microsoftarchive/promptbench) | unclassified | unknown |
| [Eladlev/AutoPrompt](https://github.com/Eladlev/AutoPrompt) | unclassified | unknown |
| [danielmiessler/Fabric](https://github.com/danielmiessler/Fabric) | unclassified | unknown |
| [BoundaryML/baml](https://github.com/BoundaryML/baml) | unclassified | unknown |
| [thunlp/OpenPrompt](https://github.com/thunlp/OpenPrompt) | unclassified | unknown |
| [Meirtz/Awesome-Context-Engineering](https://github.com/Meirtz/Awesome-Context-Engineering) | unclassified | unknown |
| [heshengtao/comfyui_LLM_party](https://github.com/heshengtao/comfyui_LLM_party) | unclassified | unknown |
| [kenjudy/pdca-code-generation-process](https://github.com/kenjudy/pdca-code-generation-process) | unclassified | unknown |
| [tktk4751/superspec](https://github.com/tktk4751/superspec) | unclassified | unknown |
| [hasanakyol/pindex](https://github.com/hasanakyol/pindex) | unclassified | unknown |
| [keithmcnulty/peopleanalytics-regression-book](https://github.com/keithmcnulty/peopleanalytics-regression-book) | unclassified | unknown |
