#!/usr/bin/env bash
# scripts/components/run-nat-eval.sh — helper to run NAT eval locally (no-op if nat missing)
set -euo pipefail
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
EVAL_CONFIG="${REPO_DIR}/scripts/components/nat-optimizer-config.yml"
SAMPLE_DATA="${REPO_DIR}/scripts/components/nat-eval-sample.jsonl"

if ! command -v nat >/dev/null 2>&1; then
  echo "[WARN] 'nat' CLI not found — cannot run eval. Create venv with nat or use --no-venv." >&2
  exit 2
fi

# Example invocation (adjust flags per your nat version)
nat eval --config "$EVAL_CONFIG" --input "$SAMPLE_DATA" || echo "nat eval failed or returned non-zero"
