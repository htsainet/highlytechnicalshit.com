# OpenSpace Component

Last updated: 2026-04-15

## What happens here

OpenSpace provides a collaborative workspace environment for the stack,
enabling shared access to AI tools and services.

## Files and structure

| File | Purpose |
|------|---------|
| `openspace.sh` | Full lifecycle: install, configure, start, stop, health |
| `openspace.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
