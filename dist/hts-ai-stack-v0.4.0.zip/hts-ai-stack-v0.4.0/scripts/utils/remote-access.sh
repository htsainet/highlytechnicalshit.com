#!/usr/bin/env bash
# scripts/utils/remote-access.sh — Unified SSH and GNOME Remote Desktop manager
#
# Provides a single entry point to manage remote access settings:
#   • SSH server (port, auth, security)
#   • GNOME Remote Desktop (RDP primary, VNC optional)
#   • Combined security dashboard
#
# Usage:
#   ./remote-access.sh                 # Opens main menu
#   ./remote-access.sh ssh             # Open SSH menu directly
#   ./remote-access.sh rdp             # Open RDP (desktop) menu directly
#   ./remote-access.sh --help          # Show this help
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source common logging functions
# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/common.sh" || {
  # Fallback if common.sh not available
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  RED='\033[0;31m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
}

SSH_SCRIPT="$SCRIPT_DIR/ssh.sh"
RDP_SCRIPT="$SCRIPT_DIR/rdp.sh"
TAILSCALE_SCRIPT="$SCRIPT_DIR/tailscale.sh"

# ── Tailscale detection ──────────────────────────────────────────────────────

is_tailscale_available() {
  command -v tailscale >/dev/null 2>&1 && echo "yes" || echo "no"
}

is_tailscale_active() {
  systemctl is-active tailscaled >/dev/null 2>&1 && echo "yes" || echo "no"
}

get_tailscale_ip() {
  if [[ $(is_tailscale_active) == "yes" ]]; then
    tailscale ip -4 2>/dev/null | head -1 || echo ""
  else
    echo ""
  fi
}

# ── Helper functions ──────────────────────────────────────────────────────

# Quick status checks
is_ssh_enabled() {
  systemctl is-enabled ssh >/dev/null 2>&1 && echo "yes" || echo "no"
}

is_rdp_enabled() {
  if command -v grdctl >/dev/null 2>&1; then
    grdctl status 2>/dev/null | grep -qi "RDP.*Enabled\|rdp.*true" && echo "yes" || echo "no"
  else
    echo "no"
  fi
}

get_ssh_port() {
  local port="22"
  if [[ -f /etc/ssh/sshd_config.d/99-ai-stack.conf ]]; then
    port=$(grep "^Port " /etc/ssh/sshd_config.d/99-ai-stack.conf 2>/dev/null | awk '{print $NF}' | head -1 || echo "22")
  fi
  if [[ -z "$port" ]]; then
    port=$(grep "^Port " /etc/ssh/sshd_config 2>/dev/null | awk '{print $NF}' | head -1 || echo "22")
  fi
  echo "${port:-22}"
}

# Display status with color coding
show_status() {
  local label="$1"
  local value="$2"
  local color="${GREEN}"
  [[ "$value" == "no" ]] && color="${RED}"
  [[ "$value" =~ ^[0-9]+$ ]] && color="${GREEN}"
  printf "  %-40s ${color}%-16s${NC}\n" "$label" "$value"
}

# ── Service control helpers ────────────────────────────────────────────────

set_ssh_enabled() {
  local enable="$1"
  
  if [[ "$enable" == "true" ]]; then
    sudo systemctl enable ssh 2>/dev/null || true
    sudo systemctl start ssh 2>/dev/null || true
  else
    sudo systemctl stop ssh 2>/dev/null || true
    sudo systemctl disable ssh 2>/dev/null || true
  fi
}

set_rdp_enabled() {
  local enable="$1"
  
  if ! command -v grdctl >/dev/null 2>&1; then
    return 1
  fi
  
  if [[ "$enable" == "true" ]]; then
    sudo grdctl rdp enable 2>/dev/null || true
  else
    sudo grdctl rdp disable 2>/dev/null || true
  fi
}

# ── Main Menu ─────────────────────────────────────────────────────────────

show_main_menu() {
  local ssh_en=$(is_ssh_enabled)
  local ssh_port=$(get_ssh_port)
  local rdp_en=$(is_rdp_enabled)
  local ts_available=$(is_tailscale_available)
  local ts_active=$(is_tailscale_active)
  local ts_ip=$(get_tailscale_ip)

  # Build status display for the menu
  local status_text="Remote Access Status:\n"
  status_text+="  SSH: $ssh_en (port $ssh_port)  |  RDP: $rdp_en (port 3389)"
  
  if [[ "$ts_available" == "yes" ]]; then
    status_text+="  |  Tailscale: $ts_active"
    if [[ -n "$ts_ip" ]]; then
      status_text+=" ($ts_ip)"
    fi
  fi

  local choice
  choice=$(whiptail --title "Remote Access Manager" \
    --menu "$status_text\n\nChoose an option:" 0 0 0 \
    "1" "Quick Setup (Enable SSH/RDP with defaults)" \
    "2" "Security Profiles (Hardening options)" \
    "3" "Advanced Configuration (Fine-tuning)" \
    "4" "Status Dashboard (Detailed view)" \
    "5" "Help & Documentation" \
    "6" "Exit" \
    3>&1 1>&2 2>&3) || return 0  # Exit if user clicks Cancel

  case "$choice" in
    1)
      show_quick_setup_menu
      show_main_menu
      ;;
    2)
      show_hardening_menu
      show_main_menu
      ;;
    3)
      show_advanced_menu
      show_main_menu
      ;;
    4)
      show_detailed_dashboard
      show_main_menu
      ;;
    5)
      show_help_menu
      show_main_menu
      ;;
    6)
      return 0
      ;;
    *)
      ;;
  esac
}

# ── Quick Setup Menu ──────────────────────────────────────────────────

show_quick_setup_menu() {
  local msg="QUICK SETUP - Enable remote access\n\n"
  msg+="Choose which services to enable:\n"
  msg+="(Uses sensible defaults for your network)\n"

  local choice
  choice=$(whiptail --title "Quick Setup" \
    --menu "$msg" 0 0 0 \
    "1" "Both SSH and RDP (recommended)" \
    "2" "SSH only" \
    "3" "RDP only" \
    "4" "Cancel" \
    3>&1 1>&2 2>&3) || return 0

  case "$choice" in
    1)
      apply_quick_setup_both
      ;;
    2)
      apply_quick_setup_ssh_only
      ;;
    3)
      apply_quick_setup_rdp_only
      ;;
    *)
      return 0
      ;;
  esac
}

apply_quick_setup_both() {
  local msg="QUICK SETUP: SSH + RDP\n\n"
  msg+="This will enable both services with sensible defaults:\n\n"
  msg+="SSH:\n"
  msg+="  • Port: 22 (standard)\n"
  msg+="  • Auth: Current system defaults\n"
  msg+="  • Status: Enabled and running\n\n"
  msg+="RDP (GNOME Remote Desktop):\n"
  msg+="  • Port: 3389 (Microsoft Remote Desktop Protocol)\n"
  msg+="  • Status: Enabled\n\n"
  msg+="Ready to proceed?"

  if ! whiptail --yesno "$msg" 0 0; then
    return 0
  fi

  whiptail --infobox "Enabling SSH and RDP...\nPlease wait..." 8 50

  # Enable SSH
  if [[ -x "$SSH_SCRIPT" ]]; then
    set_ssh_enabled true
  fi

  # Enable RDP
  if [[ -x "$RDP_SCRIPT" ]]; then
    set_rdp_enabled true
  fi

  whiptail --msgbox "✓ Quick setup complete!\n\nBoth SSH (port 22) and RDP (port 3389) are now enabled.\n\nNext: Consider applying a Security Profile for hardening." 0 0
}

apply_quick_setup_ssh_only() {
  local msg="QUICK SETUP: SSH Only\n\n"
  msg+="This will enable SSH with standard settings:\n\n"
  msg+="  • Port: 22\n"
  msg+="  • Status: Enabled and running\n\n"
  msg+="RDP will remain unchanged.\n\n"
  msg+="Ready to proceed?"

  if ! whiptail --yesno "$msg" 0 0; then
    return 0
  fi

  whiptail --infobox "Enabling SSH...\nPlease wait..." 8 50

  if [[ -x "$SSH_SCRIPT" ]]; then
    set_ssh_enabled true
  fi

  whiptail --msgbox "✓ SSH is now enabled on port 22" 8 40
}

apply_quick_setup_rdp_only() {
  local msg="QUICK SETUP: RDP Only\n\n"
  msg+="This will enable GNOME Remote Desktop (RDP):\n\n"
  msg+="  • Port: 3389 (Microsoft Remote Desktop Protocol)\n"
  msg+="  • Status: Enabled\n\n"
  msg+="SSH will remain unchanged.\n\n"
  msg+="Ready to proceed?"

  if ! whiptail --yesno "$msg" 0 0; then
    return 0
  fi

  whiptail --infobox "Enabling RDP...\nPlease wait..." 8 50

  if [[ -x "$RDP_SCRIPT" ]]; then
    set_rdp_enabled true
  fi

  whiptail --msgbox "✓ GNOME Remote Desktop (RDP) is now enabled on port 3389" 8 40
}

# ── Advanced Menu ──────────────────────────────────────────────────────

show_advanced_menu() {
  local msg="ADVANCED CONFIGURATION\n\n"
  msg+="Fine-tune individual services.\n"
  msg+="⚠️  For power users only!\n"

  local -a menu_items=("1" "SSH Server Configuration"
                       "2" "GNOME Remote Desktop (RDP)"
                       "3" "Tailscale VPN Configuration")
  
  local choice
  choice=$(whiptail --title "Advanced Configuration" \
    --menu "$msg" 0 0 0 \
    "${menu_items[@]}" \
    "4" "Back to main menu" \
    3>&1 1>&2 2>&3) || return 0

  case "$choice" in
    1)
      open_ssh_manager
      ;;
    2)
      open_rdp_manager
      ;;
    3)
      open_tailscale_manager
      ;;
    4)
      return 0
      ;;
    *)
      ;;
  esac
}

# ── Help Menu ──────────────────────────────────────────────────────────

show_help_menu() {
  local msg="REMOTE ACCESS MANAGER - HELP\n\n"
  msg+="🔧 QUICK SETUP\n"
  msg+="Enable SSH and/or RDP with sensible defaults\n"
  msg+="for your local network.\n\n"
  msg+="🛡️  SECURITY PROFILES\n"
  msg+="Choose a hardening level:\n"
  msg+="  • Full Hardening: For internet-exposed systems\n"
  msg+="  • LAN-Friendly: For home/office networks\n"
  msg+="  • OS Defaults: Remove all customizations\n\n"
  msg+="⚙️  ADVANCED CONFIGURATION\n"
  msg+="Granular control over SSH, RDP, Tailscale.\n\n"
  msg+="📊 STATUS DASHBOARD\n"
  msg+="View detailed settings and configuration paths."

  whiptail --msgbox "$msg" 0 0
}

# ── Menu handlers ─────────────────────────────────────────────────────────

handle_menu_choice() {
  local choice="$1"
  local ts_available=$(is_tailscale_available)

  case "$choice" in
    1)
      open_ssh_manager
      ;;
    2)
      open_rdp_manager
      ;;
    3)
      show_hardening_menu
      ;;
    4)
      show_detailed_dashboard
      ;;
    5)
      # Could be Tailscale or Reset depending on availability
      if [[ "$ts_available" == "yes" ]]; then
        open_tailscale_manager
      else
        confirm_reset_all
      fi
      ;;
    6)
      # Reset to defaults (only if Tailscale option exists)
      if [[ "$ts_available" == "yes" ]]; then
        confirm_reset_all
      fi
      ;;
    *)
      ;;
  esac
}

open_ssh_manager() {
  if [[ ! -x "$SSH_SCRIPT" ]]; then
    whiptail --msgbox "ERROR: SSH manager not found or not executable.\n\n$SSH_SCRIPT" 8 50
    show_main_menu
    return
  fi
  "$SSH_SCRIPT"
  show_main_menu
}

open_rdp_manager() {
  if [[ ! -x "$RDP_SCRIPT" ]]; then
    whiptail --msgbox "ERROR: Remote Desktop manager not found or not executable.\n\n$RDP_SCRIPT" 8 50
    show_main_menu
    return
  fi
  "$RDP_SCRIPT"
  show_main_menu
}

open_tailscale_manager() {
  if [[ ! -x "$TAILSCALE_SCRIPT" ]]; then
    whiptail --msgbox "ERROR: Tailscale manager not found or not executable.\n\n$TAILSCALE_SCRIPT" 8 50
    show_main_menu
    return
  fi
  "$TAILSCALE_SCRIPT"
  show_main_menu
}

show_hardening_menu() {
  local msg="SECURITY HARDENING PROFILES\n\n"
  msg+="Choose a security profile:\n\n"
  msg+="1. FULL HARDENING (All networks)\n"
  msg+="   • SSH port 2222, pubkey-only, no root\n"
  msg+="   • RDP enabled, Tailscale restricted\n"
  msg+="   • Best for: Internet-exposed systems\n\n"
  msg+="2. LAN-FRIENDLY (Local + Tailscale)\n"
  msg+="   • Allow SSH/RDP on standard ports (22, 3389)\n"
  msg+="   • Tailscale unrestricted on own network\n"
  msg+="   • Best for: Home/office networks\n\n"
  msg+="3. OS DEFAULTS (Reset all)\n"
  msg+="   • Remove all customizations\n"
  msg+="   • Revert to Ubuntu defaults"

  local choice
  choice=$(whiptail --title "Security Hardening Profiles" \
    --menu "$msg" 0 0 0 \
    "1" "Full Hardening (all networks)" \
    "2" "LAN-Friendly (local + Tailscale)" \
    "3" "OS Defaults (reset)" \
    "4" "Cancel" \
    3>&1 1>&2 2>&3) || return 0

  case "$choice" in
    1)
      apply_full_hardening
      ;;
    2)
      apply_lan_friendly_hardening
      ;;
    3)
      apply_os_defaults
      ;;
    *)
      show_main_menu
      ;;
  esac
}

apply_full_hardening() {
  local msg="APPLYING FULL HARDENING PROFILE\n\n"
  msg+="This profile applies maximum security (internet-exposed):\n\n"
  msg+="SSH Changes:\n"
  msg+="  • Port → 2222\n"
  msg+="  • Authentication → Pubkey only\n"
  msg+="  • Root login → Disabled\n\n"
  msg+="RDP Changes:\n"
  msg+="  • Status → Enabled on port 3389\n"
  msg+="  • Access → Tailscale IP only (firewall restricted)\n\n"
  msg+="⚠️  Ensure SSH keys are configured first!"

  if ! whiptail --yesno "$msg" 0 0; then
    show_main_menu
    return 0
  fi

  # Check for sudo
  if ! sudo -l >/dev/null 2>&1; then
    whiptail --msgbox "ERROR: sudo access required\n\nPlease run: sudo $0" 8 40
    show_main_menu
    return 1
  fi

  whiptail --infobox "Applying full hardening profile...\nPlease wait..." 8 50

  # Apply SSH hardening
  bash -c '
    set -e
    SSH_CONFIG="/etc/ssh/sshd_config.d/99-ai-stack.conf"
    
    sudo mkdir -p $(dirname "$SSH_CONFIG")
    {
      echo "# AI Stack - Full Hardening Profile"
      echo "Port 2222"
      echo "PubkeyAuthentication yes"
      echo "PasswordAuthentication no"
      echo "PermitRootLogin no"
    } | sudo tee "$SSH_CONFIG" >/dev/null
    
    # Verify and reload
    if sudo sshd -t 2>/dev/null; then
      sudo systemctl reload ssh >/dev/null 2>&1 || sudo systemctl restart ssh >/dev/null 2>&1 || true
    fi
  ' 2>/dev/null || true

  # Enable RDP
  if command -v grdctl >/dev/null 2>&1; then
    sudo grdctl rdp enable 2>/dev/null || true
  fi

  # Apply Tailscale firewall restriction if available
  if [[ $(is_tailscale_available) == "yes" && $(is_tailscale_active) == "yes" ]]; then
    bash -c '
      set -e
      TS_SUBNET="100.64.0.0/10"
      RDP_PORT="3389"
      
      # Remove any existing unrestricted rules and add restricted rule
      sudo ufw delete allow $RDP_PORT/tcp 2>/dev/null || true
      sudo ufw allow from $TS_SUBNET to any port $RDP_PORT proto tcp 2>/dev/null || true
    ' 2>/dev/null || true
  fi

  success_msg="✓ FULL HARDENING PROFILE APPLIED\n\n"
  success_msg+="SSH Configuration:\n"
  success_msg+="  Port: 2222 (custom)\n"
  success_msg+="  Auth: Pubkey only\n"
  success_msg+="  Root login: Disabled\n\n"
  success_msg+="RDP Configuration:\n"
  success_msg+="  Port: 3389\n"
  success_msg+="  Status: Enabled\n"
  if [[ $(is_tailscale_available) == "yes" ]]; then
    success_msg+="  Firewall: Tailscale subnet only (100.64.0.0/10)\n"
  fi
  success_msg+="\nNEXT STEPS:\n"
  success_msg+="  1. Update firewall: ufw allow 2222/tcp\n"
  success_msg+="  2. Test SSH login with key: ssh -p 2222 user@host\n"
  success_msg+="  3. Verify all connectivity before client disconnects"

  whiptail --msgbox "$success_msg" 0 0
  show_main_menu
}

apply_lan_friendly_hardening() {
  local msg="APPLYING LAN-FRIENDLY HARDENING PROFILE\n\n"
  msg+="This profile balances security and usability (home/office networks):\n\n"
  msg+="SSH Changes:\n"
  msg+="  • Port → 22 (standard, LAN accessible)\n"
  msg+="  • Authentication → Pubkey only\n"
  msg+="  • Root login → Disabled\n"
  msg+="  • Access → All networks (NO Tailscale restriction)\n\n"
  msg+="RDP Changes:\n"
  msg+="  • Port → 3389 (Microsoft Remote Desktop Protocol)\n"
  msg+="  • Status → Enabled\n"
  msg+="  • Access → All networks (NO Tailscale restriction)\n\n"
  msg+="✓ Local devices can connect on standard ports\n"
  msg+="✓ Tailscale can connect without restrictions\n"
  msg+="⚠️  Ensure you're on a trusted network!"

  if ! whiptail --yesno "$msg" 0 0; then
    show_main_menu
    return 0
  fi

  # Check for sudo
  if ! sudo -l >/dev/null 2>&1; then
    whiptail --msgbox "ERROR: sudo access required\n\nPlease run: sudo $0" 8 40
    show_main_menu
    return 1
  fi

  whiptail --infobox "Applying LAN-friendly hardening profile...\nPlease wait..." 8 50

  # Apply SSH hardening (keep port 22, pubkey only, no root)
  bash -c '
    set -e
    SSH_CONFIG="/etc/ssh/sshd_config.d/99-ai-stack.conf"
    
    sudo mkdir -p $(dirname "$SSH_CONFIG")
    {
      echo "# AI Stack - LAN-Friendly Hardening Profile"
      echo "Port 22"
      echo "PubkeyAuthentication yes"
      echo "PasswordAuthentication no"
      echo "PermitRootLogin no"
    } | sudo tee "$SSH_CONFIG" >/dev/null
    
    # Verify and reload
    if sudo sshd -t 2>/dev/null; then
      sudo systemctl reload ssh >/dev/null 2>&1 || sudo systemctl restart ssh >/dev/null 2>&1 || true
    fi
  ' 2>/dev/null || true

  # Enable RDP
  if command -v dconf >/dev/null 2>&1; then
    dconf write /org/gnome/desktop/remote-access/enabled true 2>/dev/null || true
  fi

  # Remove any Tailscale firewall restrictions
  bash -c '
    set -e
    RDP_PORT="3389"
    
    # Remove Tailscale-restricted rule and add unrestricted rule
    sudo ufw delete allow from 100.64.0.0/10 to any port $RDP_PORT proto tcp 2>/dev/null || true
    sudo ufw allow $RDP_PORT/tcp 2>/dev/null || true
  ' 2>/dev/null || true

  success_msg="✓ LAN-FRIENDLY HARDENING PROFILE APPLIED\n\n"
  success_msg+="SSH Configuration:\n"
  success_msg+="  Port: 22 (standard)\n"
  success_msg+="  Auth: Pubkey only\n"
  success_msg+="  Root login: Disabled\n"
  success_msg+="  Access: Local network + Tailscale\n\n"
  success_msg+="RDP Configuration:\n"
  success_msg+="  Port: 3389 (Microsoft Remote Desktop Protocol)\n"
  success_msg+="  Status: Enabled\n"
  success_msg+="  Access: Local network + Tailscale\n\n"
  success_msg+="CONNECTIVITY:\n"
  success_msg+="  • SSH: Accessible from local network (port 22)\n"
  success_msg+="  • RDP: Accessible from local network (port 3389)\n"
  success_msg+="  • Tailscale: Both services fully accessible"

  whiptail --msgbox "$success_msg" 0 0
  show_main_menu
}

apply_os_defaults() {
  local msg="RESET TO OS DEFAULTS\n\n"
  msg+="This removes ALL AI Stack customizations.\n"
  msg+="Services will revert to Ubuntu factory defaults:\n\n"
  msg+="SSH:\n"
  msg+="  ✗ Remove port customization (revert to 22)\n"
  msg+="  ✗ Remove pubkey-only restriction\n"
  msg+="  ✗ Remove root login restrictions\n"
  msg+="  ✗ Delete /etc/ssh/sshd_config.d/99-ai-stack.conf\n\n"
  msg+="RDP:\n"
  msg+="  ✗ Disable GNOME Remote Desktop\n"
  msg+="  ✗ Clear AI Stack RDP settings\n\n"
  msg+="Firewall:\n"
  msg+="  ✗ Remove all Tailscale subnet restrictions\n\n"
  msg+="⚠️  WARNING: Destructive change - systems will be open with defaults!"

  if ! whiptail --yesno "$msg" 0 0; then
    show_main_menu
    return 0
  fi

  # Final confirmation
  if ! whiptail --yesno "Really reset all systems to OS defaults?" 0 0; then
    show_main_menu
    return 0
  fi

  # Check for sudo
  if ! sudo -l >/dev/null 2>&1; then
    whiptail --msgbox "ERROR: sudo access required\n\nPlease run: sudo $0" 8 40
    show_main_menu
    return 1
  fi

  whiptail --infobox "Resetting to OS defaults...\nPlease wait..." 8 50

  # Remove custom SSH config
  sudo rm -f /etc/ssh/sshd_config.d/99-ai-stack.conf 2>/dev/null || true
  sudo systemctl reload ssh 2>/dev/null || true

  # Disable RDP
  if command -v dconf >/dev/null 2>&1; then
    dconf write /org/gnome/desktop/remote-access/enabled false 2>/dev/null || true
  fi

  # Remove all firewall customizations
  bash -c '
    sudo ufw delete allow 5900/tcp 2>/dev/null || true
    sudo ufw delete allow from 100.64.0.0/10 to any port 5900 proto tcp 2>/dev/null || true
  ' 2>/dev/null || true

  success_msg="✓ ALL SYSTEMS RESET TO OS DEFAULTS\n\n"
  success_msg+="Removed:\n"
  success_msg+="  ✗ Custom SSH port customization\n"
  success_msg+="  ✗ Pubkey-only SSH restriction\n"
  success_msg+="  ✗ Root login restrictions\n"
  success_msg+="  ✗ RDP configuration\n"
  success_msg+="  ✗ Tailscale firewall rules\n\n"
  success_msg+="Current state:\n"
  success_msg+="  • SSH: Port 22, all auth methods, root allowed\n"
  success_msg+="  • RDP: Disabled\n"
  success_msg+="  • Firewall: No AI Stack rules\n\n"
  success_msg+="⚠️  System is now in a permissive state (Ubuntu defaults).\n"
  success_msg+="Consider applying security hardening for production use."

  whiptail --msgbox "$success_msg" 0 0
  show_main_menu
}

show_detailed_dashboard() {
  local ssh_enabled=$(is_ssh_enabled)
  local ssh_active=$(systemctl is-active ssh 2>/dev/null || echo "inactive")
  local ssh_port=$(get_ssh_port)
  local rdp_enabled=$(is_rdp_enabled)
  local ts_available=$(is_tailscale_available)
  local ts_active=$(is_tailscale_active)
  local ts_ip=$(get_tailscale_ip)

  local msg="DETAILED STATUS DASHBOARD\n\n"
  msg+="━━━━━━━━━━━━ SSH SERVICE ━━━━━━━━━━━━\n"
  msg+="  Service enabled: $ssh_enabled\n"
  msg+="  Service active: $ssh_active\n"
  msg+="  Listening port: $ssh_port\n"
  msg+="  Config: /etc/ssh/sshd_config\n"
  msg+="  Custom: /etc/ssh/sshd_config.d/99-ai-stack.conf\n\n"
  msg+="━━━━━━━━ GNOME REMOTE DESKTOP (RDP) ━━━━━━━━\n"
  msg+="  RDP enabled: $rdp_enabled\n"
  msg+="  Schema: /org/gnome/desktop/remote-access/enabled\n"
  
  if [[ "$ts_available" == "yes" ]]; then
    msg+="\n━━━━━━━━ TAILSCALE VPN ━━━━━━━━\n"
    msg+="  Installed: yes\n"
    msg+="  Running: $ts_active\n"
    if [[ -n "$ts_ip" ]]; then
      msg+="  Tailscale IP: $ts_ip\n"
    fi
  fi
  
  msg+="\n━━━━━━━━━━ FIREWALL NOTES ━━━━━━━━━━\n"
  msg+="  Remember to allow SSH port in firewall:\n"
  msg+="  • ufw allow $ssh_port/tcp\n"
  msg+="  • firewalld: firewall-cmd --add-port=$ssh_port/tcp\n"

  whiptail --msgbox "$msg" 0 0
  show_main_menu
}

confirm_reset_all() {
  local msg="RESET ALL TO DEFAULTS?\n\n"
  msg+="This will:\n"
  msg+="  • Disable SSH custom port (revert to port 22)\n"
  msg+="  • Allow password auth on SSH\n"
  msg+="  • Allow root SSH login\n"
  msg+="  • Disable GNOME Remote Desktop\n\n"
  msg+="WARNING: Requires sudo. This is destructive!"

  if whiptail --yesno "$msg" 0 0; then
    if ! sudo -l >/dev/null 2>&1; then
      whiptail --msgbox "ERROR: sudo access required\n\nPlease run: sudo $0" 8 40
      return 1
    fi

    whiptail --infobox "Resetting to defaults...\nPlease wait..." 8 50

    # Remove custom SSH config
    sudo rm -f /etc/ssh/sshd_config.d/99-ai-stack.conf 2>/dev/null || true
    sudo systemctl reload ssh 2>/dev/null || true

    # Disable RDP
    if command -v dconf >/dev/null 2>&1; then
      dconf write /org/gnome/desktop/remote-access/enabled false 2>/dev/null || true
    fi

    whiptail --msgbox "✓ All settings reset to defaults" 8 40
  fi
  show_main_menu
}

# ── Help ──────────────────────────────────────────────────────────────────

show_help() {
  cat <<EOF
${CYAN}Remote Access Configuration Manager${NC}

Unified management for SSH and GNOME Remote Desktop (RDP) settings.

${BOLD}Usage:${NC}
  $0                    Opens main menu
  $0 ssh               Jump to SSH configuration
  $0 rdp               Jump to RDP configuration
  $0 --help            Show this help

${BOLD}Features:${NC}
  • SSH server configuration (port, auth, security)
  • GNOME Remote Desktop (RDP) management
  • Security hardening wizard
  • Unified status dashboard
  • Reset to defaults

${BOLD}Requirements:${NC}
  • whiptail (dialog boxes)
  • SSH installed (openssh-server)
  • dconf (for GNOME settings)
  • systemctl (systemd)
  • sudo (for configuration changes)

${BOLD}Security Best Practices:${NC}
  1. Disable default SSH port (22) → 2222
  2. Enforce key-based authentication
  3. Disable root login
  4. Allow SSH in firewall for custom port
  5. Use VPN/Tailscale for additional security

${BOLD}SSH Port Change Warning:${NC}
  Always update firewall AFTER changing SSH port:
    ufw allow 2222/tcp
    firewall-cmd --add-port=2222/tcp

EOF
}

# ── Entry point ───────────────────────────────────────────────────────────

main() {
  # Handle arguments
  case "${1:-}" in
    --help|-h)
      show_help
      exit 0
      ;;
    ssh)
      open_ssh_manager
      exit 0
      ;;
    rdp)
      open_rdp_manager
      exit 0
      ;;
  esac

  # Check dependencies
  if ! command -v whiptail >/dev/null 2>&1; then
    echo -e "${RED}whiptail not found. Install: sudo apt install whiptail${NC}"
    exit 1
  fi

  if [[ "$USER" == "root" ]]; then
    echo -e "${YELLOW}WARNING: Running as root. Some operations may not work as expected.${NC}"
  fi

  show_main_menu
}

main "$@"
