$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/nemoclaw'
    $script:ComponentScript = Join-Path $script:ComponentDir 'nemoclaw.sh'
    $script:ContextFile = Join-Path $script:ComponentDir 'CONTEXT.md'
    $script:BundleScript = Join-Path $script:RepoRoot 'scripts/bundles/nemoclaw.sh'
    $script:DispatchScript = Join-Path $script:RepoRoot 'scripts/install/04-setup-nemoclaw.sh'
    $script:UpgradeScript = Join-Path $script:RepoRoot 'scripts/utils/upgrade-nemoclaw.sh'
    $script:StartStackScript = Join-Path $script:RepoRoot 'scripts/install/06-start-stack.sh'
}

# ── Extended file inventory ──────────────────────────────────────────────────

Describe 'nemoclaw extended file inventory' {

    It 'CONTEXT.md exists' {
        $script:ContextFile | Should -Exist
    }

    It 'bundle script exists' {
        $script:BundleScript | Should -Exist
    }

    It 'upgrade script exists' {
        $script:UpgradeScript | Should -Exist
    }
}

# ── Nemoclaw-specific functions ──────────────────────────────────────────────

Describe 'nemoclaw extended component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines nemoclaw_onboard function' {
        $script:ComponentContent | Should -Match 'nemoclaw_onboard\s*\(\)'
    }

    It 'defines nemoclaw_connect_sandbox function' {
        $script:ComponentContent | Should -Match 'nemoclaw_connect_sandbox\s*\(\)'
    }

    It 'defines nemoclaw_cli function' {
        $script:ComponentContent | Should -Match 'nemoclaw_cli\s*\(\)'
    }

    It 'systemd health timer uses the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/nemoclaw/nemoclaw\.sh'
    }
}

# ── Bundle script ────────────────────────────────────────────────────────────

Describe 'nemoclaw bundle orchestration' {

    BeforeAll {
        $script:BundleContent = Get-Content -Path $script:BundleScript -Raw
    }

    It 'invokes ollama, bitnet, and llama-swap before nemoclaw component' {
        $ollamaPos = $script:BundleContent.IndexOf('components/ollama')
        $bitnetPos = $script:BundleContent.IndexOf('components/bitnet')
        $llamaSwapPos = $script:BundleContent.IndexOf('components/llama-swap')
        $nemoclawPos = $script:BundleContent.IndexOf('components/nemoclaw/nemoclaw.sh')

        $ollamaPos | Should -BeGreaterThan -1 -Because 'bundle should invoke ollama'
        $bitnetPos | Should -BeGreaterThan -1 -Because 'bundle should invoke bitnet'
        $llamaSwapPos | Should -BeGreaterThan -1 -Because 'bundle should invoke llama-swap'
        $nemoclawPos | Should -BeGreaterThan -1 -Because 'bundle should invoke nemoclaw'

        $ollamaPos | Should -BeLessThan $nemoclawPos -Because 'ollama must precede nemoclaw'
        $bitnetPos | Should -BeLessThan $nemoclawPos -Because 'bitnet must precede nemoclaw'
        $llamaSwapPos | Should -BeLessThan $nemoclawPos -Because 'llama-swap must precede nemoclaw'
    }

    It 'conditionally invokes dashboard' {
        $script:BundleContent | Should -Match 'DASHBOARD_ENABLED.*==.*true'
        $script:BundleContent | Should -Match 'dashboard'
    }

    It 'uses the subfolder path for nemoclaw' {
        $script:BundleContent | Should -Match 'components/nemoclaw/nemoclaw\.sh'
    }
}

# ── Install pipeline dispatcher ──────────────────────────────────────────────

Describe 'sandbox engine dispatcher routes nemoclaw correctly' {

    BeforeAll {
        $script:DispatchContent = Get-Content -Path $script:DispatchScript -Raw
    }

    It 'routes nemoclaw to subfolder path' {
        $script:DispatchContent | Should -Match 'components/nemoclaw/nemoclaw\.sh'
    }

    It 'routes "both" to nemoclaw subfolder path' {
        $script:DispatchContent | Should -Match 'both\)[\s\S]*?nemoclaw/nemoclaw\.sh'
    }
}

# ── Upgrade script ───────────────────────────────────────────────────────────

Describe 'upgrade-nemoclaw.sh references' {

    BeforeAll {
        $script:UpgradeContent = Get-Content -Path $script:UpgradeScript -Raw
    }

    It 'uses subfolder path for full setup' {
        $script:UpgradeContent | Should -Match 'components/nemoclaw/nemoclaw\.sh"$'
    }

    It 'uses subfolder path for --update' {
        $script:UpgradeContent | Should -Match 'components/nemoclaw/nemoclaw\.sh" --update'
    }

    It 'uses subfolder path for --health' {
        $script:UpgradeContent | Should -Match 'components/nemoclaw/nemoclaw\.sh" --health'
    }
}

# ── Start-stack sources ──────────────────────────────────────────────────────

Describe '06-start-stack.sh sources nemoclaw' {

    BeforeAll {
        $script:StartContent = Get-Content -Path $script:StartStackScript -Raw
    }

    It 'sources from subfolder path' {
        $script:StartContent | Should -Match 'source.*components/nemoclaw/nemoclaw\.sh'
    }
}

# ── Extended port allocation ─────────────────────────────────────────────────

Describe 'nemoclaw extended port allocation' {

    BeforeAll {
        $script:ReferencesContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'REFERENCES.md') -Raw
    }

    It 'port 18789 is registered in REFERENCES.md port map' {
        $script:ReferencesContent | Should -Match '18789.*[Nn]emo[Cc]law'
    }
}

# ── CONTEXT.md content ───────────────────────────────────────────────────────

Describe 'nemoclaw CONTEXT.md' {

    BeforeAll {
        $script:ContextContent = Get-Content -Path $script:ContextFile -Raw
    }

    It 'documents OpenShell lifecycle guidance' {
        $script:ContextContent | Should -Match 'OpenShell lifecycle'
        $script:ContextContent | Should -Match 'nemoclaw onboard'
    }

    It 'documents key functions' {
        $script:ContextContent | Should -Match 'nemoclaw_install'
        $script:ContextContent | Should -Match 'nemoclaw_health'
    }
}
