# Kdenlive References

Last updated: 2026-04-17

## Upstream

- [Kdenlive](https://kdenlive.org/)
- [Kdenlive Documentation](https://docs.kdenlive.org/)
- [GitLab — KDE/kdenlive](https://invent.kde.org/multimedia/kdenlive)

## Package

- Ubuntu package: `kdenlive`
