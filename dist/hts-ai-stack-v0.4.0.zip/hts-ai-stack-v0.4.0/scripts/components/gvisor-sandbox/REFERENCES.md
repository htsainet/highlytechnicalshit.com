# gVisor Sandbox References

Last updated: 2026-04-15

## Upstream

- [GitHub — google/gvisor](https://github.com/google/gvisor)

## Official documentation

- [gVisor Docs](https://gvisor.dev/docs/)
- [gVisor Quick Start](https://gvisor.dev/docs/user_guide/quick_start/docker/)
