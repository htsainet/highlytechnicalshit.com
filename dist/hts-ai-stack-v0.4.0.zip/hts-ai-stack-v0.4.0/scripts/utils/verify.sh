#!/usr/bin/env bash
# verify.sh — Run Pester stack-validation tests
#
# Usage:
#   ./verify.sh          # run all stack validation tests
#   ./verify.sh --quick  # skip endpoint tests (compose + script checks only)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'

if ! command -v pwsh >/dev/null 2>&1; then
  echo -e "${RED}[FAIL]${NC} pwsh (PowerShell) not found. Install: sudo snap install powershell --classic"
  exit 1
fi

PESTER_FILE="$REPO_DIR/tests/Test-StackValidation.Tests.ps1"

if [[ ! -f "$PESTER_FILE" ]]; then
  echo -e "${RED}[FAIL]${NC} $PESTER_FILE not found."
  exit 1
fi

echo ""
echo -e "${GREEN}══ Stack Validation ══${NC}"
echo ""

pwsh -NoLogo -NoProfile -Command "
  Import-Module Pester -ErrorAction Stop
  \$c = [PesterConfiguration]::Default
  \$c.Run.Path = '$PESTER_FILE'
  \$c.Run.PassThru = \$true
  \$c.Output.Verbosity = 'Detailed'
  \$r = Invoke-Pester -Configuration \$c
  if (\$r.FailedCount -gt 0) { exit 1 }
"
