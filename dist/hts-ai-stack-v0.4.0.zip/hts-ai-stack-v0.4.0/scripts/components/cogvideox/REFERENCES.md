# CogVideoX References

Last updated: 2026-04-17

## Upstream

- [GitHub — THUDM/CogVideo](https://github.com/THUDM/CogVideo)
- [CogVideoX Technical Report](https://github.com/THUDM/CogVideo/blob/main/resources/CogVideoX.pdf)

## Models (HuggingFace)

- [THUDM/CogVideoX-2b](https://huggingface.co/THUDM/CogVideoX-2b) — 2B params (~6GB VRAM)
- [THUDM/CogVideoX-5b](https://huggingface.co/THUDM/CogVideoX-5b) — 5B params (~12GB VRAM)

## Papers

- [CogVideoX: Text-to-Video Diffusion Models with An Expert Transformer (arXiv)](https://arxiv.org/abs/2408.06072)

## API

- Gradio web UI: `http://localhost:7865/`
- Gradio API: `http://localhost:7865/api/`
