# Dashboard References

Last updated: 2026-04-15

## Upstream

- Internal component — no upstream repository.

## Official documentation

- Built in-house as part of hts-ai-stack.
