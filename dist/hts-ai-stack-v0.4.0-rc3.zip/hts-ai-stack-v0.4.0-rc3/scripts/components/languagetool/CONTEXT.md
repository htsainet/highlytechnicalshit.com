# LanguageTool

Offline grammar, spelling, and style checker exposed as a REST API.

## What happens here

This component runs LanguageTool as a Docker container, providing a self-hosted grammar and style checking service. It processes text through rule-based and n-gram analysis to detect errors in 30+ languages — all without sending data to external services.

## Key integration points

- **Pipeline skill** — n8n, Flowise, or DeerFlow can call `/v2/check` as a post-processing step to polish LLM output
- **Open WebUI tool** — grammar-check responses before presenting to users
- **API endpoint** — `POST /v2/check` accepts text and returns annotations with suggestions

## API usage

```bash
# Check text for errors
curl -s http://localhost:8010/v2/check \
  -d "language=en-US" \
  -d "text=This are a test." | jq .

# List supported languages
curl -s http://localhost:8010/v2/languages | jq .
```

## Files and structure

| File | Purpose |
|------|---------|
| `languagetool.sh` | Component lifecycle script (install, start, stop, health, destroy) |
| `languagetool.manifest.json` | Component metadata for manifest loader |
| `CONTEXT.md` | This file — component overview |
| `REFERENCES.md` | Upstream links and documentation |

## Process / Workflow

1. `languagetool.sh --install` builds the Docker image (thin wrapper around `erikvl87/languagetool`)
2. `languagetool.sh --start` brings up the container via Docker Compose profile `languagetool`
3. Service listens on port 8010 (configurable via `LANGUAGETOOL_PORT` in `.env`)
4. Health check polls `/v2/languages` endpoint

## What good looks like

- Container running and healthy on port 8010
- `/v2/check` returns grammar annotations for test input
- No external network calls — fully offline operation
- Low resource usage (~500 MB RAM, CPU-only)
