#!/usr/bin/env bash
# scripts/components/inkscape/inkscape.sh — Inkscape: install, configure, health
#
# Host-native installer for Inkscape, a professional vector graphics editor.
# SVG as the native format, with support for PDF, EPS, AI, and other formats.
#
# Standalone usage:
#   ./scripts/components/inkscape/inkscape.sh              # full: install + configure + health
#   ./scripts/components/inkscape/inkscape.sh --install    # install only
#   ./scripts/components/inkscape/inkscape.sh --configure  # configure only
#   ./scripts/components/inkscape/inkscape.sh --start      # no-op (desktop app)
#   ./scripts/components/inkscape/inkscape.sh --stop       # no-op (desktop app)
#   ./scripts/components/inkscape/inkscape.sh --restart    # no-op (desktop app)
#   ./scripts/components/inkscape/inkscape.sh --health     # health check only
#   ./scripts/components/inkscape/inkscape.sh --status     # show status + health
#   ./scripts/components/inkscape/inkscape.sh --destroy    # uninstall Inkscape
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

load_env

inkscape_install() {
  step "Inkscape — install"
  if command -v inkscape &>/dev/null; then
    skip "Inkscape already installed."
  else
    info "Installing Inkscape via snap (latest stable)..."
    sudo snap install inkscape
    ok "Inkscape installed."
  fi
}

inkscape_configure() {
  step "Inkscape — configure"
  info "Inkscape is a desktop application — no service configuration needed."
  ok "Inkscape configured."
}

inkscape_start() {
  step "Inkscape — start"
  info "Inkscape is a desktop application. Launch from your application menu."
}

inkscape_stop() {
  step "Inkscape — stop"
  info "Inkscape is a desktop application. Close it from the window."
}

inkscape_restart() { inkscape_stop; inkscape_start; }

inkscape_health() {
  step "Inkscape — health"
  if command -v inkscape &>/dev/null; then
    local ver
    ver=$(inkscape --version 2>/dev/null | head -1 || echo "unknown")
    ok "Inkscape is installed: $ver"
    return 0
  else
    warn "Inkscape is not installed."
    return 1
  fi
}

inkscape_status() { step "Inkscape — status"; inkscape_health; }

inkscape_destroy() {
  step "Inkscape — destroy"
  if snap list inkscape &>/dev/null 2>&1; then
    info "Removing Inkscape snap..."
    sudo snap remove inkscape
    ok "Inkscape removed."
  elif dpkg -l inkscape &>/dev/null 2>&1; then
    info "Removing Inkscape apt package..."
    sudo apt-get remove -y inkscape
    ok "Inkscape removed."
  else
    skip "Inkscape is not installed."
  fi
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  case "${1:-}" in
    --install)   inkscape_install   ;;
    --configure) inkscape_configure ;;
    --start)     inkscape_start     ;;
    --stop)      inkscape_stop      ;;
    --restart)   inkscape_restart   ;;
    --health)    inkscape_health    ;;
    --status)    inkscape_status    ;;
    --destroy)   inkscape_destroy   ;;
    *)
      inkscape_install
      inkscape_configure
      inkscape_health
      ;;
  esac
fi
