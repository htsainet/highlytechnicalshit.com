#!/usr/bin/env bash
# scripts/utils/verify-openshell-pin.sh — Post-apply sanity check for the
# openshell version pin (DEVIATIONS.md → NemoClaw).
#
# Run this AFTER: ./scripts/components/nemoclaw/nemoclaw.sh --install
# Confirms:
#   1. openshell --version matches EXPECTED
#   2. ~/.nemoclaw/blueprint.yaml still agrees with EXPECTED
#   3. No stale 0.0.32 defaults remain in the four repo files
# Update EXPECTED here when blueprint.yaml changes.

set -u

EXPECTED="$(jq -r '.upstream.openshell_pinned_version' \
  "$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)/scripts/components/nemoclaw/nemoclaw.manifest.json" 2>/dev/null)"
[[ -z "$EXPECTED" || "$EXPECTED" == "null" ]] && {
  echo "FATAL: could not read openshell_pinned_version from nemoclaw.manifest.json" >&2
  exit 1
}
fail=0

echo "── OpenShell pin verification ──────────────────────────────────────────"

# 1. Installed binary
if ! command -v openshell >/dev/null 2>&1; then
  echo "[FAIL] openshell CLI not on PATH"
  fail=1
else
  installed=$(openshell --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
  if [[ "$installed" == "$EXPECTED" ]]; then
    echo "[ OK ] openshell --version = $installed"
  else
    echo "[FAIL] openshell --version = ${installed:-<none>} (expected $EXPECTED)"
    fail=1
  fi
fi

# 2. Blueprint (source of truth)
bp=$(find "$HOME/.nemoclaw" -name 'blueprint.yaml' 2>/dev/null | head -1 || true)
if [[ -z "$bp" ]]; then
  echo "[warn] ~/.nemoclaw/blueprint.yaml not found — nemoclaw onboard may not have run yet"
else
  mn=$(grep -E 'min_openshell_version' "$bp" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
  mx=$(grep -E 'max_openshell_version' "$bp" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
  echo "[info] blueprint min=$mn max=$mx  (file: $bp)"
  # EXPECTED must fall within [min, max] (inclusive). Blueprint legitimately
  # ships a window — pinning the upper bound is what we want.
  in_range=1
  if [[ -n "$mn" ]] && [[ "$(printf '%s\n' "$mn" "$EXPECTED" | sort -V | head -1)" != "$mn" ]]; then
    in_range=0
  fi
  if [[ -n "$mx" ]] && [[ "$(printf '%s\n' "$EXPECTED" "$mx" | sort -V | head -1)" != "$EXPECTED" ]]; then
    in_range=0
  fi
  if [[ $in_range -eq 0 ]]; then
    echo "[FAIL] blueprint window [$mn, $mx] does not include pinned $EXPECTED — update the pin in:"
    echo "       scripts/lib/common.sh, nemoclaw.sh, utils/upgrade-nemoclaw.sh"
    fail=1
  fi
fi

# 3. All repo pins agree
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
echo "[info] repo pins:"
grep -nE 'OPENSHELL_VERSION:-|max_ver=|min_ver=' \
  "$REPO/scripts/lib/common.sh" \
  "$REPO/scripts/components/nemoclaw/nemoclaw.sh" \
  "$REPO/scripts/utils/upgrade-nemoclaw.sh" 2>/dev/null | sed 's/^/       /'

stale=$(grep -rE '"0\.0\.32"' \
  "$REPO/scripts/lib/common.sh" \
  "$REPO/scripts/components/nemoclaw/nemoclaw.sh" \
  "$REPO/scripts/utils/upgrade-nemoclaw.sh" 2>/dev/null || true)
if [[ -n "$stale" ]]; then
  echo "[FAIL] stale 0.0.32 still present:"
  echo "$stale" | sed 's/^/       /'
  fail=1
fi

echo "────────────────────────────────────────────────────────────────────────"
if [[ $fail -eq 0 ]]; then
  echo "All good. Safe to re-run: ./scripts/components/nemoclaw/nemoclaw.sh --start"
  exit 0
else
  echo "One or more checks failed — see [FAIL] lines above."
  exit 1
fi
