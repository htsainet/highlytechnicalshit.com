$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/sillytavern'
    $script:ComponentScript = Join-Path $script:ComponentDir 'sillytavern.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'sillytavern.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'sillytavern file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'sillytavern manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is sillytavern' {
        $script:Manifest.id | Should -Be 'sillytavern'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/sillytavern/sillytavern.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is sillytavern' {
        $script:Manifest.func_prefix | Should -Be 'sillytavern'
    }

    It 'category is extras' {
        $script:Manifest.category | Should -Be 'extras'
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'sillytavern component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines sillytavern_install function' {
        $script:ComponentContent | Should -Match 'sillytavern_install\s*\(\)'
    }

    It 'defines sillytavern_configure function' {
        $script:ComponentContent | Should -Match 'sillytavern_configure\s*\(\)'
    }

    It 'defines sillytavern_start function' {
        $script:ComponentContent | Should -Match 'sillytavern_start\s*\(\)'
    }

    It 'defines sillytavern_stop function' {
        $script:ComponentContent | Should -Match 'sillytavern_stop\s*\(\)'
    }

    It 'defines sillytavern_health function' {
        $script:ComponentContent | Should -Match 'sillytavern_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/sillytavern/sillytavern\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'sillytavern no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/sillytavern\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/sillytavern/sillytavern\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}

# ── SillyTavern security config ─────────────────────────────────────────────

Describe 'sillytavern security config' {
    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'configure injects securityOverride: true' {
        $script:ComponentContent | Should -Match 'securityOverride:\s*true'
    }

    It 'configure sets enableUserAccounts: true' {
        $script:ComponentContent | Should -Match 'enableUserAccounts:\s*true'
    }

    It 'configure disables whitelistMode' {
        $script:ComponentContent | Should -Match 'whitelistMode:\s*false'
    }

    It 'configure sets autorun: false' {
        $script:ComponentContent | Should -Match 'autorun:\s*false'
    }
}
