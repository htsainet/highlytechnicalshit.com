# Model Library Resources

* **model-registry.json** – Top‑level JSON file (repo root) that lists every model type for every service, with `url`, `license`, and `trust` metadata. See `model-registry.json` for the current schema.
* **model.sh** – Bash library providing `model_get_url`, `model_get_license`, and a generic `model_download_if_missing` stub. Component scripts should source this file (`source "${REPO_DIR}/scripts/lib/model.sh"`) and call the helper.
* **Usage pattern** (example from Stable Diffusion):
  ```bash
  source "${REPO_DIR}/scripts/lib/model.sh"
  model_download_if_missing "stable_diffusion" "checkpoint" "$SD_CHECKPOINT" "$sd_volume" "$NAS_SD_CACHE"
  ```
* **Extending** – To add a new service, add an entry under the service name in `model-registry.json`, add corresponding prompts in the component’s manifest, and call `model_download_if_missing` in the component script.
