# Audio Flamingo Component

Last updated: 2026-04-17

## What happens here

Audio Flamingo is NVIDIA's audio understanding LLM — a 7B model that
handles sound event detection, music analysis, and speech understanding
in a single unified model. Runs locally with GPU (CUDA) or CPU-only mode.

## Files and structure

| File | Purpose |
|------|---------|
| `audio-flamingo.sh` | Full lifecycle: install, configure, start, stop, health |
| `audio-flamingo.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Runtime

- **Server**: FastAPI + Uvicorn on port 8601 (not Gradio)
- **Endpoints**: `GET /health`, `POST /v1/audio/analyze`, `GET /docs` (Swagger UI)
- **Model**: nvidia/audio-flamingo-3-hf (7B, ~14GB download, cached in Docker volume)

## Quantization (AF_QUANTIZE)

The server auto-detects GPU VRAM and selects quantization via the `AF_QUANTIZE`
environment variable (default: `auto`):

| Value  | VRAM needed | When auto-selected        |
|--------|-------------|---------------------------|
| `none` | ~16GB       | GPUs with ≥20GB (3090, 4090, A6000) |
| `int8` | ~8GB        | GPUs with 10–20GB         |
| `int4` | ~5GB        | GPUs with <10GB           |
| `auto` | varies      | Reads `torch.cuda.get_device_properties()` |

INT4/INT8 quantization uses `bitsandbytes` with NF4 quantization type.
CPU offload (`llm_int8_enable_fp32_cpu_offload`) is enabled for both modes
so non-quantizable layers (embeddings, norms) can spill to system RAM when
GPU VRAM is tight. The `devel` PyTorch base image is required (not `runtime`)
because bitsandbytes needs CUDA dev libraries at load time.

## Device Selection (AF_DEVICE)

Controls whether the model runs on GPU or CPU. Set via `AF_DEVICE` env var
or `--cpu` / `--gpu` CLI flags.

| Value  | Behavior |
|--------|----------|
| `auto` | Check free VRAM at start; use GPU if ≥5 GB free, otherwise fall back to CPU |
| `gpu`  | Force GPU — warn if free VRAM is low but proceed anyway |
| `cpu`  | Force CPU — fp32, no quantization, slower but always works |

The `auto` fallback uses a point-in-time `nvidia-smi memory.free` snapshot.
This is an interim solution — FEATURE-052 will replace it with a proper
VRAM budget system that tracks all services' requirements.

## Notes

- Supports up to 10 minutes of audio input
- FastAPI auto-docs at `/docs` (the only UI — no Gradio)
- HuggingFace model weights cached in `audio_flamingo_cache` Docker volume
- First startup downloads ~14GB; subsequent starts use cached weights
- Set `HF_TOKEN` env var for faster authenticated downloads
