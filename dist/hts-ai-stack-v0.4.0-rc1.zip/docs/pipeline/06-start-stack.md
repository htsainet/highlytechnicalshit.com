# 06-start-stack.sh — Start Dual Backends + llama-swap + NemoClaw

Starts Ollama GPU, BitNet CPU, llama-swap router, and connects NemoClaw sandboxes.

```bash
./06-start-stack.sh
```

---

## Modes

| Flag | What starts |
|---|---|
| *(none)* | Ollama GPU + BitNet CPU + llama-swap + NemoClaw GPU sandbox |
| `--test` | Backends + llama-swap only (skips NemoClaw connect) |

---

## Services started

| Service | Port |
|---|---|
| llama-swap (router) | 8080 |
| Ollama GPU | 11434 |
| BitNet CPU | *(internal only)* |
| NemoClaw — GPU sandbox | 18789 |

NemoClaw manages its own OpenClaw gateway instance — there is no
standalone OpenClaw container.

---

## Prerequisites

- Steps 00–04 completed (Docker, NVIDIA toolkit, NemoClaw sandboxes onboarded)
- Sandboxes created: `hts-ai-openshell-nemoclaw-gpu`

If sandboxes are not yet created, run:

```bash
./04-setup-nemoclaw.sh
```

---

## Usage

```bash
# Full stack (Ollama + NemoClaw GPU sandbox)
./06-start-stack.sh

# Ollama only (skip NemoClaw connect)
./06-start-stack.sh --test
```

---

## Teardown

```bash
# Stop all backends and router
docker compose --profile ollama-gpu --profile bitnet-cpu --profile llama-swap down

# Stop NemoClaw sandbox
nemoclaw hts-ai-openshell-nemoclaw-gpu down
```
