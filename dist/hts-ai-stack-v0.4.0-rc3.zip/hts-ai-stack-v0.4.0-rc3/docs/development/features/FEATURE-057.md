# FEATURE-057 — Runtime Threat Detection (Falco + Alerting)

| Field | Value |
|-------|-------|
| Status | Proposed (Future) |
| Category | Security / Observability |
| Target Release | v0.6.0+ |
| Priority | MEDIUM |
| Effort | L |
| Components | `falco` (new), `falcosidekick` (new, optional), Grafana/Loki integration |
| Dependencies | None hard; complements FEATURE-055 (Authelia), FEATURE-056 (Microsegmentation), SECURITY-005 (Observability), SECURITY-009 (Secret Isolation) |
| Related | Closes the "runtime detection" gap in the defense-in-depth matrix |

## Summary

Add [Falco](https://falco.org/) — CNCF-graduated runtime threat
detection — as a new component. Falco observes syscalls and container
events in real time and emits alerts when behavior matches
suspicious-activity rules (e.g., shell spawned in container, unexpected
network connection, sensitive file read, privilege escalation attempt).

Pair with **Falcosidekick** to fan out alerts to Loki / Grafana /
webhook / email so events are visible on the stack's dashboard.

This is the detection layer that Authelia + microsegmentation don't
provide. The prior features *prevent* paths; Falco *notices* when
something bypasses or abuses an allowed path.

## Why this matters

Defense-in-depth stack after FEATURE-055 + FEATURE-056 + SECURITY-009:

| Layer | Control | Status |
|---|---|---|
| L7 auth | Who can call what URL | FEATURE-055 |
| L4/TLS | Encrypted transport | FEATURE-055 |
| L3 segmentation | Who can reach whom | FEATURE-056 |
| Host firewall | Inbound allowlist | SECURITY-000 |
| Container isolation | Syscall filtering | gvisor-sandbox |
| Volume/secret isolation | Blast radius of stolen creds | SECURITY-009 |
| **Runtime detection** | **Noticing the breach in real time** | **← THIS FEATURE** |
| Audit log aggregation | Forensics after the fact | SECURITY-005 |

Without runtime detection, a successful compromise that stays within
declared paths (e.g., malicious code in a legitimate container using
its allowed dependencies for abuse) is **invisible** until damage shows
up downstream. Falco catches "container did a thing it has never done
before" in seconds.

## What Falco detects (out of the box)

- Shell spawned in a container
- Writes below `/etc` or `/usr/bin` in a running container
- Unexpected outbound network connections
- Reads of sensitive files (`/etc/shadow`, SSH keys, cloud creds)
- Privilege escalation (setuid, capabilities added at runtime)
- Crypto mining patterns
- Container drift (binary executed that wasn't in the image)
- Kubernetes audit events (N/A for Docker-compose stack; Docker events supported)

Rules are YAML, extensible, and the community maintains a large ruleset
(`falco-rules`, `falco-incubating-rules`).

## Proposed architecture

```
┌──────────────────────────────────────────────┐
│  Host kernel ← eBPF probe ← Falco daemon     │
│                              │               │
│                              ▼               │
│                       Falcosidekick          │
│                        │         │           │
│                        ▼         ▼           │
│                    Loki/Grafana  Dashboard   │
│                                  notification│
└──────────────────────────────────────────────┘
```

- **Falco** runs as a privileged container (needs kernel access via
  eBPF or kernel module). Reads syscalls across all containers on the host.
- **Falcosidekick** receives Falco events and fans them out to outputs
  (Loki is the obvious one given the existing observability stack;
  also: webhook, Discord/Slack, file, statsd).
- **Grafana dashboard** — preconfigured panels for: events/minute,
  top offenders, rule hit distribution, severity timeline.
- **Alert webhook** — tie to dashboard notification component (toast
  in the stack dashboard) or local email/desktop notification.

## Phases

### Phase 1 — Falco component
- `scripts/components/falco/falco.sh` — lifecycle
- `scripts/components/falco/falco.manifest.json`
- `stack/falco/falco.yaml` — config
- `stack/falco/rules.d/` — rule files (base + custom)
- eBPF probe setup (preferred over kernel module on modern kernels)
- docker-compose service: privileged, host PID, volumes for kernel headers

### Phase 2 — Falcosidekick + outputs
- Falcosidekick container
- Primary output: Loki (reuse existing stack Loki if present; else add)
- Secondary output: webhook to dashboard notification endpoint
- Optional: local SMTP relay or Discord webhook

### Phase 3 — Custom rules for the AI stack
Rules tuned to the stack's legitimate activity:
- **Baseline allowed**: model downloads (HF cache), volume writes for
  state, expected outbound to declared endpoints
- **Always alert**: shell spawned in any model-inference container
  (ollama, localai, comfyui, etc. — these should never need a shell)
- **Alert on drift**: binaries executed that aren't in the image
- **Alert on credential files**: reads of `.env`, Authelia users DB,
  Duplicati encryption key, SSH keys
- **Alert on Docker socket access**: any container reading `/var/run/docker.sock`
  that isn't Traefik or Portainer

### Phase 4 — Dashboard integration
- Grafana dashboard JSON under `stack/grafana/dashboards/security.json`
- Panels: severity breakdown, top rules, top source containers,
  events-per-hour sparkline
- Link tile on main stack dashboard

### Phase 5 — Tuning & runbooks
- First-week triage process (lots of false positives common)
- `docs/security/falco-runbook.md` — "alert fired, now what"
- Suppression rules for known-noisy legitimate behaviors

## Performance considerations

- Falco with eBPF: ~1-3% CPU overhead, small memory footprint
- Higher on syscall-heavy workloads (DB, file-heavy services)
- Rule complexity matters; keep custom rules tight
- Not expected to impact GPU inference workloads meaningfully

## Risks & mitigations

| Risk | Mitigation |
|---|---|
| Alert fatigue (default rules noisy on busy dev hosts) | Curated starter ruleset + tuning phase; start with severity ≥ WARNING |
| Privileged container (Falco needs kernel access) | Unavoidable — document clearly; keep Falco image pinned and verified |
| Kernel header / eBPF compatibility | Falco uses modern-bpf; supports Linux 5.8+. Your stack is Ubuntu recent, fine. |
| Log volume into Loki | Dedupe + suppression rules; rotate retention aggressively |
| False sense of security | Document that Falco detects; it does not prevent. Still need the other layers. |

## Out of scope

- Falco → Kubernetes audit integration (stack is Docker-compose)
- Commercial Sysdig Secure (Falco is the open-source subset — no paid deps)
- Automated response (SOAR) — detection only for v1, response playbooks later
- Host-level AV/EDR (different category; consider ClamAV or Wazuh separately)

## Acceptance criteria

- [ ] Falco component installs and runs on fresh stack.
- [ ] Base ruleset fires on a synthetic test (e.g., `docker exec ollama sh`).
- [ ] Events land in Loki within 5 seconds.
- [ ] Grafana security dashboard renders without errors.
- [ ] Custom rules for the AI stack documented and loaded.
- [ ] Triage runbook written.
- [ ] Performance overhead < 5% sustained on idle host.
