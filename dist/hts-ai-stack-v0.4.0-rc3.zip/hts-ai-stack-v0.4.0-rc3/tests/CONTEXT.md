# Pester Tests

Validation test suite for installation pipeline and framework integrity.

Last updated: 2026-04-05 20:30:00

## What happens here

This workspace contains all Pester tests that validate the installation scripts, configuration, and framework structure. Tests use TDD principles to catch regressions early and ensure system behavior matches expectations.

## Process / Workflow

1. Write test cases first (Verb-Noun.Tests.ps1 files)
2. Run tests against current system state
3. Implement or fix code to pass tests
4. Commit tests with code changes
5. Tests run as pre-commit hooks during git operations

## Commands

```bash
# changed markdown, shell, and config files
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1

# staged files only (same mode used by pre-commit)
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1 -Staged

# full repository sweep
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1 -All

# install git hooks
pwsh -NoLogo -NoProfile -File tests/Install-GitHooks.ps1
```

## Files and structure

| File | Purpose |
|------|---------|
| `Test-FrameworkStructure.Tests.ps1` | Framework architecture validation |
| `Test-FrameworkStructure.md` | Human-readable explanation of the framework and what the compliance tests enforce |
| `Test-RepoChecks.Tests.ps1` | Markdown, shell, spell, and config validation |
| `Test-StackValidation.Tests.ps1` | Docker stack and service validation |
| `Test-ModelCache.Tests.ps1` | Model cache and download validation |
| `Test-FeatureHygiene.Tests.ps1` | Fails if any FEATURE-###.md targets an already-shipped git tag |
| `Test-IssueHygiene.Tests.ps1` | Validates issue metadata, Target Release tagging, and review-date requirements |
| `Test-ReleaseGate.Tests.ps1` | Deep pre-release sweep — run manually before tagging a new version |
| `Invoke-RepoChecks.ps1` | Repo health check runner for changed, staged, or all files |
| `Install-GitHooks.ps1` | Configures `.githooks/` as the repository hook path |
| `Test-WorkspaceValidation.Tests.ps1` | Validates a workspace against the base Claude folder framework |
| `Test-HostPrerequisites.Tests.ps1` | Host-level prerequisite checks (packages, tools) |
| `Test-NukeAndPave.Tests.ps1` | Post-pave validation — confirms all stack artifacts, processes, ports, timers, and containers are removed after `nuke-stack.sh --pave` |
| `Test-ModelHelpers.Tests.ps1` | Model helper function validation |
| `Test-NamingConventions.Tests.ps1` | Script filename pattern enforcement per folder |
| `Test-NoEditorSwap.Tests.ps1` | Fails if editor swap/backup files are committed |
| `Test-NpmAuditSecurity.Tests.ps1` | npm audit security check for `package.json` |
| `Test-IssueReviewDeadlines.Tests.ps1` | Validates issue review-date requirements |
| `Test-StaleReferences.Tests.ps1` | Detects stale or broken cross-file references |
| `Test-WizardMenu.Tests.ps1` | Wizard menu flow and option validation |
| `REFERENCES.md` | Source material and framework references for these test conventions |
| `validate-config-files.cjs` | Node-based parser validation for JSON, JSONC, YAML, and YML files |

## What runs

| Check | Tool | Notes |
|------|------|-------|
| Markdown lint | `markdownlint-cli2` | Installed from `package.json` via `npm install` |
| Shell syntax | `bash -n` | Runs on selected `*.sh` files |
| Shell lint | `shellcheck` | Optional; test is skipped if `shellcheck` is not installed |
| Config parse | `node` + `jsonc-parser` + `yaml` | Validates selected `*.json`, `*.jsonc`, `*.yml`, `*.yaml` files |

## What good looks like

- Compatible with Pester 5.7.1 & PowerShell 7.6.0 on Ubuntu 24.04 LTS
- Follow PowerShell approved verbs and pipeline conventions
- Test file naming: `Verb-Noun.Tests.ps1`
- Clear test descriptions using natural language
- Tests are repeatable and don't depend on manual state
- Avoid `Write-Host` (use output objects or logging instead)
- Pre-commit hooks enforce tests pass before commits

## Hook setup

Running `pwsh -NoLogo -NoProfile -File tests/Install-GitHooks.ps1` sets `core.hooksPath` to `.githooks/`, and `git commit` then runs the staged repo checks for markdown and shell files.

## Dependencies

- `pwsh`
- Pester module
- Node.js / NPM
- `markdownlint-cli2` from `npm install`
- `jsonc-parser` and `yaml` from `npm install`
- `bash`
- optional: `shellcheck`

## Notes

- Default mode checks changed files, not the entire repo. That keeps old unrelated markdown debt from blocking normal edits.
- Use `-All` when you explicitly want a full cleanup sweep.

## Tools and skills

- **Pester 5.7.1** — PowerShell test framework
- **PowerShell 7.6** — Test execution engine
- **markdownlint-cli2** — Configuration validation
- **cspell** — Spell checking in test output
- **Docker** — Docker compose validation (StackValidation tests)
- **git hooks** — Pre-commit test automation
