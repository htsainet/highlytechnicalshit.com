# refs/ — Per-Repo Detail Notes

> **Note:** Per-repo review artifacts are now organized into purpose-specific folders:
>
> - **Security repos:** [`docs/planning/security-repos/`](../planning/security-repos/) — `owner-reponame.md` per repo
> - **Feature repos:** [`docs/planning/feature-repos/`](../planning/feature-repos/) — `owner-reponame.md` per repo
> - **Security papers:** [`docs/planning/security-whitepapers/`](../planning/security-whitepapers/) — `arXiv-ID.md` per paper
>
> This directory is retained for legacy notes. New artifacts should go in the appropriate sub-folder above.

This directory holds individual Markdown files with detailed notes for repositories
listed in [`../docs_references.md`](../docs_references.md).

## Naming Convention

Each file is named after the repository it describes, using the pattern:

```text
<org>-<repo>.md
```

For example, notes for `ollama/ollama` live in `ollama-ollama.md`.

## File Template

```markdown
# org/repo

- **URL:** https://github.com/org/repo
- **Category:** <category>
- **Trust:** <trust level>
- **Last Reviewed:** YYYY-MM-DD

## Summary

<!-- What does this repo do? -->

## Relevance to this project

<!-- Why is it in the list? What could we use it for? -->

## Notes

<!-- Anything else worth recording — caveats, setup notes, alternatives, etc. -->
```
