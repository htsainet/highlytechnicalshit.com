"""AudioCraft / MusicGen — Gradio web UI for text-to-music generation."""

import os
import gradio as gr
import torch
import torchaudio
from audiocraft.models import MusicGen

MODEL_NAME = os.environ.get("MUSICGEN_MODEL", "facebook/musicgen-small")
DURATION = int(os.environ.get("MUSICGEN_DURATION", "8"))
PORT = int(os.environ.get("AUDIOCRAFT_PORT", "8602"))

model = None


def load_model():
    global model
    if model is None:
        model = MusicGen.get_pretrained(MODEL_NAME)
        model.set_generation_params(duration=DURATION)
    return model


def generate_music(prompt: str, duration: float = 8.0):
    """Generate music from a text description."""
    m = load_model()
    m.set_generation_params(duration=min(duration, 30.0))

    wav = m.generate([prompt])

    # wav shape: [batch, channels, samples]
    output_path = "/tmp/musicgen_output.wav"
    torchaudio.save(output_path, wav[0].cpu(), sample_rate=32000)
    return output_path


def generate_with_melody(prompt: str, melody_audio, duration: float = 8.0):
    """Generate music conditioned on a melody + text description."""
    m = load_model()
    m.set_generation_params(duration=min(duration, 30.0))

    if melody_audio is not None:
        sr, melody_wav = melody_audio
        melody_tensor = torch.tensor(melody_wav).float().unsqueeze(0)
        if melody_tensor.dim() == 2:
            melody_tensor = melody_tensor.unsqueeze(0)
        wav = m.generate_with_chroma([prompt], melody_tensor, sr)
    else:
        wav = m.generate([prompt])

    output_path = "/tmp/musicgen_output.wav"
    torchaudio.save(output_path, wav[0].cpu(), sample_rate=32000)
    return output_path


with gr.Blocks(title="AudioCraft / MusicGen") as app:
    gr.Markdown("# 🎵 AudioCraft / MusicGen")
    gr.Markdown(f"Text-to-music generation powered by **{MODEL_NAME}**")

    with gr.Tab("Text to Music"):
        prompt_input = gr.Textbox(
            label="Describe the music you want",
            placeholder="e.g., An upbeat electronic track with synthesizers and a driving beat",
        )
        duration_input = gr.Slider(
            minimum=1, maximum=30, value=8, step=1, label="Duration (seconds)"
        )
        generate_btn = gr.Button("Generate", variant="primary")
        audio_output = gr.Audio(label="Generated Music", type="filepath")
        generate_btn.click(
            generate_music, inputs=[prompt_input, duration_input], outputs=audio_output
        )

    with gr.Tab("Melody Conditioning"):
        melody_prompt = gr.Textbox(
            label="Describe the style",
            placeholder="e.g., A jazz rendition with piano and upright bass",
        )
        melody_input = gr.Audio(label="Upload melody (optional)", type="numpy")
        melody_duration = gr.Slider(
            minimum=1, maximum=30, value=8, step=1, label="Duration (seconds)"
        )
        melody_btn = gr.Button("Generate with Melody", variant="primary")
        melody_output = gr.Audio(label="Generated Music", type="filepath")
        melody_btn.click(
            generate_with_melody,
            inputs=[melody_prompt, melody_input, melody_duration],
            outputs=melody_output,
        )

if __name__ == "__main__":
    app.launch(server_name="0.0.0.0", server_port=PORT)
