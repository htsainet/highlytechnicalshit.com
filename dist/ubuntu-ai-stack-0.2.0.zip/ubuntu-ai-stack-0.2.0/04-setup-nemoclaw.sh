#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=setup/tooling/ui.sh
source "$SCRIPT_DIR/setup/tooling/ui.sh"

htsai_banner "04 — NemoClaw Setup"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already installed"; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

# ── Pre-run checklist ─────────────────────────────────────────────────────────
checklist_start
checklist_item false "1. Verify cgroup v2"
checklist_item false "2. GitHub CLI configured"
checklist_item false "3. OpenShell CLI installed"
checklist_item false "4. NemoClaw cloned"
checklist_item false "5. NemoClaw onboarded (prod & test)"
checklist_item false "6. Ollama inference running"
checklist_end

# ── Step 1: Fix cgroup v2 (required for Ubuntu 24.04) ────────────────────────
step "1 — cgroup v2 fix"

FS_TYPE=$(stat -fc %T /sys/fs/cgroup/)

if [ "$FS_TYPE" = "cgroup2fs" ]; then
  if sudo grep -q "default-cgroupns-mode" /etc/docker/daemon.json 2>/dev/null; then
    skip "cgroup v2 fix already applied"
  else
    info "Applying cgroup v2 fix for Docker/k3s..."
    if [ -f /etc/docker/daemon.json ]; then
      # Merge into existing daemon.json
      sudo python3 -c "
import json
with open('/etc/docker/daemon.json') as f:
    config = json.load(f)
config['default-cgroupns-mode'] = 'host'
with open('/etc/docker/daemon.json', 'w') as f:
    json.dump(config, f, indent=2)
print('Merged into existing daemon.json')
"
    else
      sudo bash -c 'echo "{\"default-cgroupns-mode\": \"host\"}" > /etc/docker/daemon.json'
    fi
    sudo systemctl restart docker
  fi
else
  skip "cgroup v1 detected (${FS_TYPE}) — fix not needed"
fi

# ── Step 2: GitHub CLI ────────────────────────────────────────────────────────
step "2 — GitHub CLI"

if gh --version &>/dev/null; then
  skip "GitHub CLI ($(gh --version | head -1))"
else
  info "Installing GitHub CLI..."
  curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | \
    sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg

  echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] \
    https://cli.github.com/packages stable main" | \
    sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null

  sudo apt update && sudo apt install -y gh
fi

if ! gh auth status &>/dev/null; then
  info "Authenticating with GitHub..."
  gh auth login
else
  skip "GitHub CLI already authenticated"
fi

# ── Step 3: OpenShell CLI ─────────────────────────────────────────────────────
step "3 — OpenShell CLI"

if openshell --version &>/dev/null; then
  skip "OpenShell ($(openshell --version))"
else
  info "Downloading OpenShell binary..."
  ARCH=$(uname -m)
  TARBALL="openshell-${ARCH}-unknown-linux-musl.tar.gz"

  gh release download \
    --repo NVIDIA/OpenShell \
    --pattern "$TARBALL"

  tar xzf "$TARBALL"
  sudo install -m 755 openshell /usr/local/bin/openshell
  rm -f "$TARBALL" openshell

  openshell --version
fi

# ── Step 4: NemoClaw ──────────────────────────────────────────────────────────
step "4 — NemoClaw"

# Source NVM in case Node was installed earlier in this session
# set +eu: nvm.sh uses unset variables and has commands that return non-zero
NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
set +eu
if [[ -s "$NVM_DIR/nvm.sh" ]]; then source "$NVM_DIR/nvm.sh"; fi
set -eu

if ! command -v npm &>/dev/null; then
  echo "[FAIL] npm not found — NVM may not have sourced correctly. Try: source ~/.nvm/nvm.sh" >&2
  exit 1
fi

# Add npm global bin to PATH now so nemoclaw is visible whether already installed or just installed
NPM_BIN=$(command -v npm)
NPM_PREFIX=$("$NPM_BIN" config get prefix)
NEMOCLAW_BIN="$NPM_PREFIX/bin/nemoclaw"

if [[ -x "$NEMOCLAW_BIN" ]]; then
  skip "NemoClaw ($("$NEMOCLAW_BIN" --version 2>/dev/null || echo 'installed'))"
else
  info "Installing NemoClaw (npm $(npm --version), node $(node --version))..."

  # Clean up any previous partial install
  NEMOCLAW_SRC="$HOME/.nemoclaw/source"
  rm -rf "$NEMOCLAW_SRC"
  mkdir -p "$(dirname "$NEMOCLAW_SRC")"

  # Resolve latest release tag; fall back to main
  RELEASE_REF=$(curl -fsSL --max-time 10 \
    https://api.github.com/repos/NVIDIA/NemoClaw/releases/latest 2>/dev/null \
    | grep '"tag_name"' | sed -E 's/.*"tag_name":[[:space:]]*"([^"]+)".*/\1/' | head -1 || true)
  [[ "$RELEASE_REF" =~ ^v[0-9] ]] || RELEASE_REF="main"
  info "NemoClaw ref: $RELEASE_REF"

  git clone --depth 1 --branch "$RELEASE_REF" https://github.com/NVIDIA/NemoClaw.git "$NEMOCLAW_SRC"

  # Root deps → build plugin TypeScript → global link
  (cd "$NEMOCLAW_SRC" && "$NPM_BIN" install --ignore-scripts)
  (cd "$NEMOCLAW_SRC/nemoclaw" && "$NPM_BIN" install --ignore-scripts && "$NPM_BIN" run build)
  (cd "$NEMOCLAW_SRC" && "$NPM_BIN" link)

  [[ -x "$NEMOCLAW_BIN" ]] || { echo "[FAIL] nemoclaw binary not found at $NEMOCLAW_BIN" >&2; exit 1; }
  "$NEMOCLAW_BIN" --version
fi

# ── Step 5: Onboard ───────────────────────────────────────────────────────────
step "5 — NemoClaw Onboard (prod + test)"

echo ""
warn "Ports 18789 and 18790 must be free before continuing."
warn "First run will pull ~2.4 GB of images."
echo ""

declare -A SANDBOX_PORTS=(
  ["ubuntu-ai-assistant-prod"]="11434"
  ["ubuntu-ai-assistant-test"]="11435"
)

# ── check_sandbox_health <sandbox> ────────────────────────────────────────────
# Prints phase and NIM status; returns 0 if Phase=Ready, 1 otherwise.
check_sandbox_health() {
  local sandbox="$1"
  local status_out
  status_out=$(nemoclaw "$sandbox" status 2>/dev/null)

  local phase nim
  phase=$(echo "$status_out" | grep "Phase:" | awk '{print $2}')
  nim=$(echo "$status_out"   | grep "NIM:"   | sed 's/.*NIM:[[:space:]]*//')

  echo -e "    Phase : ${phase:-unknown}"
  echo -e "    NIM   : ${nim:-unknown}"

  [[ "${phase:-}" == "Ready" ]]
}

do_onboard() {
  local sandbox="$1" port="$2"
  info "Onboarding sandbox: ${sandbox} (Ollama on port ${port})..."
  NEMOCLAW_EXPERIMENTAL=1 \
  NEMOCLAW_SANDBOX_NAME="$sandbox" \
  NEMOCLAW_PROVIDER=ollama \
  NEMOCLAW_MODEL=mistral-nemo:latest \
  NEMOCLAW_POLICY_PRESETS=docker,npm,pypi,telegram,huggingface \
    nemoclaw onboard --non-interactive
  ok "Sandbox '${sandbox}' onboarded."
}

for sandbox in "ubuntu-ai-assistant-prod" "ubuntu-ai-assistant-test"; do
  port="${SANDBOX_PORTS[$sandbox]}"

  if ! nemoclaw list 2>/dev/null | grep -q "$sandbox"; then
    do_onboard "$sandbox" "$port"
    continue
  fi

  # ── Sandbox exists: check health and prompt ────────────────────────────────
  echo ""
  info "Sandbox '${sandbox}' already exists. Checking health..."
  if check_sandbox_health "$sandbox"; then
    health_label="${GREEN}healthy (Phase: Ready)${NC}"
  else
    health_label="${YELLOW}degraded${NC}"
  fi
  echo -e "\n  Sandbox '${sandbox}' is ${health_label}.\n"
  echo    "  Options:"
  echo -e "    [s] Skip  — keep existing sandbox  ${YELLOW}(default, auto-selects in 30s)${NC}"
  echo    "    [o] Overwrite — destroy and re-onboard"
  echo ""

  reply=""
  if read -r -t 30 -p "  Choice [s/o]: " reply 2>/dev/null; then
    : # got input
  else
    echo ""
    info "No input — skipping '${sandbox}'."
  fi

  case "${reply,,}" in
    o|overwrite)
      warn "Destroying sandbox '${sandbox}'..."
      nemoclaw "$sandbox" destroy --yes 2>/dev/null || true
      do_onboard "$sandbox" "$port"
      ;;
    *)
      skip "Sandbox '${sandbox}' — keeping existing."
      ;;
  esac
done

# ── Patch registry: NemoClaw bug — updateSandbox uses gateway name "nemoclaw" ─
# rather than the actual sandbox name, so model/provider stay null after onboard.
# We patch sandboxes.json directly with the known Ollama values.
SANDBOXES_JSON="$HOME/.nemoclaw/sandboxes.json"
if [[ -f "$SANDBOXES_JSON" ]]; then
  info "Patching NemoClaw registry with model/provider..."
  python3 - "$SANDBOXES_JSON" <<'EOF_PY'
import json, sys
path = sys.argv[1]
with open(path) as f:
    data = json.load(f)
for sb in data.get("sandboxes", {}).values():
    if not sb.get("model"):
        sb["model"] = "mistral-nemo:latest"
    if not sb.get("provider"):
        sb["provider"] = "ollama-local"
with open(path, "w") as f:
    json.dump(data, f, indent=2)
print("  Registry patched.")
EOF_PY
fi

# ── Step 6: Inference endpoints ───────────────────────────────────────────────
step "6 — Local Ollama inference"

info "Prod sandbox endpoint  : http://host.openshell.internal:11434/v1"
info "Test sandbox endpoint  : http://host.openshell.internal:11435/v1"
echo ""

if curl -sf http://localhost:11434/api/tags >/dev/null 2>&1; then
  info "Ollama prod (11434) is reachable — ready to use."
else
  warn "Ollama prod (11434) not reachable — start the stack first: ./06-start-stack.sh --test"
fi

if curl -sf http://localhost:11435/api/tags >/dev/null 2>&1; then
  info "Ollama test (11435) is reachable — ready to use."
else
  warn "Ollama test (11435) not reachable — start the stack first: ./06-start-stack.sh --test"
fi

echo ""
info "NemoClaw setup complete."
info "Connect to sandboxes:"
info "  nemoclaw ubuntu-ai-assistant-prod connect"
info "  nemoclaw ubuntu-ai-assistant-test connect"

