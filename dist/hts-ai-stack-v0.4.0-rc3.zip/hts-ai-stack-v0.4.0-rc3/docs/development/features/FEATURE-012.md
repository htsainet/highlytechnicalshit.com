# gVisor Sandbox — Secure CPU Agent Runtime

**Priority:** HIGH
**Effort:** 8–12 hours
**Risk:** Low — additive container runtime; no changes to existing NemoClaw
sandbox or Docker Compose services
**Target Release:** v0.5.0
**Depends on:** Dual-inference plan merged (llama-swap available on
`ai-network`)
**Blocks:** Nothing — comparison data informs FEATURE-013 decision

## Problem

NemoClaw's OpenShell gateway forces a single model for all sandboxes via
`openshell inference set --model`. This blocks true dual-backend routing where
the GPU sandbox uses Ollama and the CPU sandbox uses BitNet simultaneously.

The gateway name is hardcoded to `"nemoclaw"` in NemoClaw's source
(`gateway-state.js:20`, `onboard.js:103`), making a second gateway impractical
without reverse-engineering the onboard flow.

We need a second sandbox technology that provides **comparable security
isolation** to NemoClaw's containerd microVMs while bypassing the gateway
single-model limitation entirely.

## Solution

Run a **gVisor (`runsc`) container** on the Docker `ai-network` hosting
OpenClaw (or a compatible agent), pointed directly at llama-swap for BitNet
inference. gVisor intercepts syscalls in user-space, providing VM-level
isolation without an actual VM.

### Architecture

```text
NemoClaw GPU sandbox (existing)
  └─ containerd microVM → OpenShell gateway → llama-swap → Ollama (gemma4:e4b)

gVisor CPU sandbox (new)
  └─ runsc container → Docker ai-network → llama-swap → BitNet (bitnet)
```

### Security Isolation Comparison

| Property | NemoClaw (containerd microVM) | gVisor (runsc) |
|----------|------------------------------|----------------|
| Kernel isolation | Separate kernel in microVM | User-space kernel (Sentry) |
| Syscall filtering | VM boundary | Application kernel intercepts all syscalls |
| Network egress | Proxy allowlist (10.200.0.1:3128) | Docker network + iptables rules |
| Filesystem | Copy-on-write overlay in VM | Read-only rootfs + tmpfs |
| Resource limits | k8s resource quotas | Docker cgroups (cpus, memory) |
| GPU access | Optional (--gpu flag) | Not needed (CPU-only workload) |
| Production users | NVIDIA NemoClaw | Google Cloud Run, GKE Sandbox |
| Overhead | ~500MB (k3s cluster) | ~20MB (runsc binary) |

## Implementation Steps

### Phase 1 — Install gVisor Runtime (host prerequisite)

Add to `scripts/host/` as a prerequisite script.

```bash
# Install gVisor runsc binary
curl -fsSL https://gvisor.dev/archive.key | sudo gpg --dearmor -o /usr/share/keyrings/gvisor-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/gvisor-archive-keyring.gpg] https://storage.googleapis.com/gvisor/releases release main" | \
  sudo tee /etc/apt/sources.list.d/gvisor.list > /dev/null
sudo apt-get update && sudo apt-get install -y runsc

# Register as Docker runtime
sudo runsc install
sudo systemctl reload docker

# Verify
docker run --rm --runtime=runsc hello-world
```

### Phase 2 — OpenClaw Container Image

Build a Docker image that runs the OpenClaw agent (same agent NemoClaw uses,
without NemoClaw's gateway layer).

```dockerfile
# docker/gvisor-sandbox/Dockerfile
FROM node:22-slim
WORKDIR /sandbox

# Install OpenClaw from npm (same version NemoClaw uses)
RUN npm install -g openclaw@latest

# Security hardening
RUN useradd -m -s /bin/bash sandbox && \
    chown -R sandbox:sandbox /sandbox
USER sandbox

EXPOSE 18791
CMD ["openclaw", "start", "--port", "18791"]
```

### Phase 3 — Docker Compose Service

```yaml
# docker-compose.yml — new service
gvisor-sandbox:
  build: ./docker/gvisor-sandbox
  image: hts-ai-gvisor-sandbox
  container_name: hts-ai-gvisor-sandbox
  runtime: runsc
  profiles: [gvisor-sandbox]
  ports:
    - "18791:18791"
  networks:
    - ai-network
  environment:
    - OPENCLAW_MODEL=bitnet
    - OPENCLAW_INFERENCE_URL=http://hts-ai-llama-swap:8081/v1
    - OPENCLAW_API_KEY=not-needed
  deploy:
    resources:
      limits:
        cpus: '4.0'
        memory: 4g
  read_only: true
  tmpfs:
    - /tmp:size=512m
    - /sandbox/.openclaw:size=256m
  security_opt:
    - no-new-privileges:true
```

### Phase 4 — Egress Control

Lock down outbound network access to match NemoClaw's proxy allowlist model.

```bash
# Option A: Docker network isolation (simplest)
# Container only has access to ai-network — no internet
# llama-swap is the only service it can reach

# Option B: iptables rules (more granular)
# Allow: ai-network (llama-swap, other stack services)
# Allow: npm registry, pypi (for agent package installs)
# Deny: everything else
```

### Phase 5 — Component Script

New file: `scripts/components/gvisor-sandbox/gvisor-sandbox.sh`

- Install gVisor runtime if not present
- Build container image
- Start with `docker compose --profile gvisor-sandbox up -d`
- Health check: `curl -sf http://localhost:18791/health`
- Compare inference latency vs NemoClaw sandbox

### Phase 6 — Dashboard Integration

- Add gVisor sandbox card to dashboard (port 18791)
- Add comparison metrics panel: NemoClaw vs gVisor response times

## Port Allocation

| Host Port | Service | Notes |
|-----------|---------|-------|
| 18791 | gVisor sandbox dashboard | Adjacent to NemoClaw ports (18789, 18790) |

## Evaluation Criteria

| Metric | NemoClaw Baseline | gVisor Target |
|--------|-------------------|---------------|
| Container start time | ~60s (k3s + microVM) | <5s |
| Memory overhead | ~500MB (k3s cluster) | <50MB |
| Inference latency | gateway + proxy hop | Direct Docker network |
| Syscall coverage | Full VM isolation | gVisor Sentry (~70% Linux syscalls) |
| Egress control | Proxy allowlist (fine-grained) | Docker network / iptables |
| Operational complexity | NemoClaw CLI + openshell | Standard Docker Compose |

## Risks

- gVisor does not support all Linux syscalls — OpenClaw or its dependencies
  may hit unsupported syscalls. Test early with `docker run --runtime=runsc`.
- gVisor + Docker Compose `runtime:` key requires Docker Engine 23.0+
  (already satisfied by our host prerequisites).
- No built-in policy preset system like NemoClaw — egress rules are manual
  iptables or Docker network configuration.

## Decision Point

After evaluation, choose one of:

1. **Keep both** — NemoClaw for GPU/managed sandbox, gVisor for CPU/lightweight
2. **Consolidate to gVisor** — if isolation is sufficient and operational
   overhead is meaningfully lower
3. **Consolidate to NemoClaw** — if per-sandbox inference routes land upstream
