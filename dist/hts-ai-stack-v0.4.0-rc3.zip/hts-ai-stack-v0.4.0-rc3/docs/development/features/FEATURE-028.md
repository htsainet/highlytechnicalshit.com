# Vosk API — Offline CPU Speech-to-Text Service

**Priority:** MEDIUM
**Effort:** 2–3 hours
**Risk:** Low — Apache 2.0 license, CPU-only (no GPU contention), stable gRPC API.
**Target Release:** v0.6.0
**Depends on:** Nothing
**Blocks:** FEATURE-027 Nerd Dictation (shares vosk library on host, independent)

## Problem

GPU-accelerated Faster-Whisper (FEATURE-026) is the high-throughput STT tier,
but it competes for the GPU with inference and video generation services.
Vosk provides a CPU-native STT option with <50MB models, 20+ language support,
streaming zero-latency transcription, and a gRPC API — making it the CPU complement
to the GPU-tier Whisper service.

## Current State

Not in the stack. `alphacep/vosk-api` is not tracked in feature-repos.

## Architecture

CPU-only gRPC server on port 2700. No GPU device reservation needed.
Runs alongside the GPU services without contention.

```text
  client → gRPC :2700
               │
           vosk-server (Docker)
               │
           vosk-model (CPU)
               │
           JSON transcript stream
```

Also provides the underlying library (`pip install vosk`) used by
Nerd Dictation (FEATURE-027) on the host — but those are independent deployments.

## Implementation Steps

### P0 — Service

- [ ] **1. Docker compose service**
  Add `vosk` service under `profiles: [vosk]`.

  ```yaml
  vosk:
    image: alphacep/kaldi-en:latest
    container_name: hts-ai-vosk
    profiles: [vosk]
    restart: unless-stopped
    ports:
      - "${VOSK_PORT:-2700}:2700"
    environment:
      - VOSK_MODEL_LANG=${VOSK_MODEL_LANG:-en-us}
    volumes:
      - vosk-models:/opt/vosk-model
    networks:
      - ai-network
    healthcheck:
      test: ["CMD", "nc", "-z", "localhost", "2700"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 15s
  ```

  > **Note:** `alphacep/kaldi-en` is the English gRPC server image. For multi-language,
  > use `alphacep/kaldi-vosk-server` and mount a downloaded model volume.
  > Evaluate image variants during implementation.

- [ ] **2. Component script**
  Create `scripts/components/vosk/vosk.sh` implementing:
  - `vosk_install` — pull image; optionally pre-download model
  - `vosk_configure` — validate `VOSK_MODEL_LANG` env var
  - `vosk_start` — start service + TCP health check on port 2700
  - `vosk_health` — `nc -z localhost ${VOSK_PORT}`
  - `vosk_stop` — stop service

- [ ] **3. Env vars**
  Add to `.env.example`:

  ```text
  VOSK_PORT=2700
  VOSK_MODEL_LANG=en-us
  ```

### P1 — Registration

- [ ] **4. Port map** — Add port 2700 to `REFERENCES.md` Host Port Map table.
- [ ] **5. Feature index** — Add row to `docs/development/features/REFERENCES.md`.

### P2 — Multi-language model

For non-English use, document model download path:

```bash
# Download a small model (50MB) for low-latency use
wget https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
unzip vosk-model-small-en-us-0.15.zip -d /path/to/vosk-models/
```

## Acceptance Criteria

- `docker compose --profile vosk up` starts the service
- gRPC port 2700 accepts connections
- `vosk_health` returns success
- Audio sent to gRPC endpoint returns JSON transcript
- No GPU required; CPU-only confirmed via `docker stats`

## Related

- [FEATURE-026](FEATURE-026.md) — Faster-Whisper (GPU STT, GPU tier)
- [FEATURE-027](FEATURE-027.md) — Nerd Dictation (uses `pip install vosk` on host, independent)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md) — row: `alphacep/vosk-api`
