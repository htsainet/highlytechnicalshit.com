$ErrorActionPreference = 'Stop'

# Guard bootstrap.sh against refactor regressions.
# Each It block checks one non-negotiable requirement.
# If you're removing something intentionally, update this test — don't just skip it.

BeforeAll {
    $script:RepoRoot  = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:Bootstrap = Join-Path $script:RepoRoot 'bootstrap.sh'
    $script:Content   = Get-Content $script:Bootstrap -Raw -ErrorAction Stop
}

Describe 'bootstrap.sh — existence and syntax' {

    It 'exists at repo root' {
        Test-Path $script:Bootstrap | Should -Be $true
    }

    It 'passes bash -n syntax check' {
        $out = & bash -n $script:Bootstrap 2>&1
        $LASTEXITCODE | Should -Be 0 -Because "bash -n reported: $out"
    }

    It 'starts with a bash shebang' {
        $script:Content | Should -Match '(?m)^#!/usr/bin/env bash'
    }

    It 'uses set -euo pipefail' {
        $script:Content | Should -Match 'set -euo pipefail'
    }
}

Describe 'bootstrap.sh — GitHub Copilot CLI' {

    It 'installs the gh-copilot extension' {
        $script:Content | Should -Match 'gh extension install github/gh-copilot'
    }

    It 'skips install if already present' {
        $script:Content | Should -Match 'gh extension list'
    }

    It 'refreshes token for copilot scope via browser (no password)' {
        $script:Content | Should -Match 'gh auth refresh.*--scopes.*copilot|gh auth refresh.*copilot'
    }
}

Describe 'bootstrap.sh — GitHub CLI auth (no password auth)' {

    It 'installs the gh CLI' {
        $script:Content | Should -Match 'apt.*install.*\bgh\b|install.*\bgh\b'
    }

    It 'authenticates via gh auth login --web (no password)' {
        $script:Content | Should -Match 'gh auth login.*--web'
    }

    It 'configures git credential helper via gh auth setup-git' {
        $script:Content | Should -Match 'gh auth setup-git'
    }

    It 'clones the repo with gh repo clone (not bare git clone https://)' {
        # gh repo clone is required — plain git clone over HTTPS requires a password
        $script:Content | Should -Match 'gh repo clone'
        # Bare git clone of the main repo must not appear
        $script:Content | Should -Not -Match 'git clone https://github\.com/htsainet'
    }
}

Describe 'bootstrap.sh — git identity setup' {

    It 'reads GitHub username from gh api user' {
        $script:Content | Should -Match 'gh api user'
    }

    It 'sets git user.name from the GitHub session' {
        $script:Content | Should -Match 'git config --global user\.name'
    }

    It 'sets git user.email from the GitHub session' {
        $script:Content | Should -Match 'git config --global user\.email'
    }
}

Describe 'bootstrap.sh — NVIDIA driver setup' {

    It 'calls scripts/host/nvidia.sh' {
        $script:Content | Should -Match 'scripts/host/nvidia\.sh'
    }

    It 'detects whether drivers were missing before calling nvidia.sh' {
        # Required to own the reboot prompt — nvidia.sh exits 0 after driver install
        $script:Content | Should -Match 'DRIVERS_WERE_MISSING|nvidia-smi'
    }

    It 'prompts for reboot after NVIDIA driver install' {
        $script:Content | Should -Match 'sudo reboot'
    }

    It 'exits before install.sh when a reboot is required' {
        # Must not fall through to install.sh if drivers were just installed
        $script:Content | Should -Match 'exit 0'
    }
}

Describe 'bootstrap.sh — Docker Engine' {

    It 'calls scripts/host/docker.sh' {
        $script:Content | Should -Match 'scripts/host/docker\.sh'
    }

    It 'installs Docker before NVIDIA (so container toolkit can configure it post-reboot)' {
        $dockerLine = @(
            $content = Get-Content $script:Bootstrap
            for ($i = 0; $i -lt $content.Count; $i++) {
                if ($content[$i] -match 'scripts/host/docker\.sh') { $i + 1 }
            }
        ) | Measure-Object -Minimum | Select-Object -ExpandProperty Minimum

        $nvidiaLine = @(
            for ($i = 0; $i -lt $content.Count; $i++) {
                if ($content[$i] -match 'scripts/host/nvidia\.sh') { $i + 1 }
            }
        ) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

        $dockerLine | Should -BeLessThan $nvidiaLine -Because 'Docker must be installed before NVIDIA drivers trigger the reboot'
    }
}

Describe 'bootstrap.sh — PowerShell and Pester' {

    It 'registers the Microsoft package repo before installing PowerShell' {
        $script:Content | Should -Match 'packages-microsoft-prod'
    }

    It 'installs PowerShell via apt' {
        $script:Content | Should -Match 'apt.*install.*powershell|apt-get install.*powershell'
    }

    It 'skips PowerShell install if pwsh is already present' {
        $script:Content | Should -Match 'command -v pwsh'
    }

    It 'installs Pester from PSGallery' {
        $script:Content | Should -Match 'Install-Module.*Pester|PSGallery'
    }

    It 'trusts PSGallery before installing Pester' {
        $script:Content | Should -Match 'Set-PSRepository.*PSGallery.*Trusted|InstallationPolicy.*Trusted'
    }
}

Describe 'bootstrap.sh — NVIDIA is always the last install step' {

    # Strategy: read the file as an array of lines, find the line numbers of
    # every "install" action and the nvidia.sh call, then assert that nvidia.sh
    # comes after all of them.  This will catch any future reordering.

    BeforeAll {
        $script:Lines = Get-Content $script:Bootstrap

        # Line number (1-based) of the nvidia.sh invocation
        $nvidiaLines = @(
            for ($i = 0; $i -lt $script:Lines.Count; $i++) {
                if ($script:Lines[$i] -match 'scripts/host/nvidia\.sh') { $i + 1 }
            }
        )
        $script:NvidiaLine = if ($nvidiaLines.Count -gt 0) { ($nvidiaLines | Measure-Object -Maximum).Maximum } else { 0 }

        # Line numbers of every install/apt-get/dpkg action (excluding the nvidia block itself)
        $script:InstallLines = @(
            for ($i = 0; $i -lt $script:Lines.Count; $i++) {
                $line = $script:Lines[$i]
                if ($line -match 'apt-get install|apt install|dpkg -i|gh extension install|Install-Module|pwsh.*Install' `
                    -and $line -notmatch 'nvidia|cuda|#') {
                    $i + 1
                }
            }
        )
    }

    It 'has a detectable nvidia.sh call' {
        $script:NvidiaLine | Should -BeGreaterThan 0 -Because 'nvidia.sh must be present'
    }

    It 'nvidia.sh call comes after every other apt/install action' {
        $violations = $script:InstallLines | Where-Object { $_ -gt $script:NvidiaLine }
        $violatingLines = $violations | ForEach-Object { "  line ${_}: $($script:Lines[$_ - 1].Trim())" }
        $violatingLines | Should -BeNullOrEmpty -Because (
            "these install actions appear AFTER nvidia.sh — reboot would skip them:`n" +
            ($violatingLines -join "`n")
        )
    }
}
