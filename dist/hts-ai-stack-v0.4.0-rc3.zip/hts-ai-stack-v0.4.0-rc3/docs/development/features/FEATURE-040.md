# FEATURE-040 — Interactive Reconfigure (manifest-driven)

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | HIGH |
| **Effort** | 1 day |
| **Risk** | Low — reads/writes stack.json only; no service restarts without explicit converge |
| **Target Release** | v0.7.0 |
| **Depends on** | FEATURE-041 (Component Manifests) |
| **Blocks** | Nothing |

## Problem

There was no interactive way to enable or disable optional components after
initial install. Users had to manually edit `config/stack.json`, look up the
correct key name, and then manually run `converge.sh`. Adding a new component
prompt required editing multiple scripts.

## Solution

`scripts/utils/reconfigure.sh` — a thin orchestrator that reads component
metadata entirely from manifests and drives whiptail dialogs.

### User Flow

```text
./scripts/utils/reconfigure.sh

  Step 1 — Top-level checklist (14 toggleable components, pre-filled
            from current stack.json state)

  Step 2 — Per-component config menus for any enabled component that
            has prompts (comfyui → gpu_layers/port, tailscale → auth_key,
            telegram → bot_token, signal → phone + custom setup)

  Step 3 — config/stack.json and .env written atomically (jq + mv)

  Step 4 — "Apply changes now?" → converge.sh --yes
```

### Toggle Logic

Each manifest declares `write_rules` — an array of atomic operations applied
on enable or disable:

| Rule type | Example | Action |
|-----------|---------|--------|
| Simple set | `{path: ".portainer.enabled", on_enable: true}` | `jq 'path = val'` |
| Array add/remove | `{path: ".extras.components", action: "add_remove", value: "duplicati"}` | `jq 'path += [val]'` |

### Group Deduplication

Prometheus and Grafana both read `.monitoring.enabled`. Prometheus is the
group representative (`group: "monitoring"`, `toggleable: true`); Grafana
follows it automatically (`toggleable: false`). The checklist shows one
"Prometheus" entry that controls both.

### Checklist Coverage

| Component | Type | Group |
|-----------|------|-------|
| Dashboard | boolean | — |
| Prometheus | boolean | monitoring (controls Grafana) |
| Portainer | boolean | — |
| OpenSpace | boolean | — |
| DeerFlow | boolean | — |
| gVisor Sandbox | boolean | — |
| Duplicati | array\_member | — |
| Tailscale | array\_member | — |
| LM Studio | boolean | — |
| SillyTavern | array\_member | — |
| ComfyUI | enum | — |
| Unsloth | boolean | — |
| Telegram | boolean | — |
| Signal | boolean | — |

### Usage

```bash
# Interactive
./scripts/utils/reconfigure.sh

# Non-interactive: save + converge immediately
./scripts/utils/reconfigure.sh --converge
```

## Files

| File | Purpose |
|------|---------|
| `scripts/utils/reconfigure.sh` | Main orchestrator |
| `scripts/lib/manifest-loader.sh` | Loads manifests into COMPONENT\_\* arrays |
| `scripts/lib/menu-handler.sh` | Generic whiptail prompt handler |
| `scripts/components/*.manifest.json` | Per-component declarations |

## Testing

1. Run `./scripts/utils/reconfigure.sh`
2. Toggle ComfyUI on → verify `config/stack.json` has `.images.engine = "comfyui"`
3. Toggle Portainer off → verify `.portainer.enabled = false`
4. Enable Telegram → verify bot\_token prompt, written to `.env`
5. Toggle Duplicati on → verify `"duplicati"` appears in `.extras.components`
6. Answer "Yes" to converge → verify `converge.sh --yes` runs
