#!/usr/bin/env bash
# scripts/lib/menu-handler.sh — Generic whiptail menu handler for component manifests
# Source this file; do NOT run directly.
#
# Reads a component's prompts[] array from its manifest and pops the appropriate
# whiptail dialogs. Supports two modes:
#
#   menu_configure_component <id>            — pre-fills from current config
#   menu_configure_component <id> --defaults — pre-fills from manifest defaults
#
# Used by: reconfigure.sh
# Requires: common.sh, manifest-loader.sh sourced first
# Requires: jq, whiptail

# Stores answers from current component's prompts; used for depends_on checks.
declare -gA _MENU_ANSWERS=()

# ── Public entry point ────────────────────────────────────────────────────────

# menu_configure_component <id> [--defaults]
# Walks the prompts[] array in the manifest and pops whiptail dialogs.
# Writes answers to stack.json or .env per each prompt's write_target.
# Returns 1 if the user cancels at any required prompt.
menu_configure_component() {
  local id="$1"
  local mode="${2:-}"  # "" = current config; "--defaults" = manifest defaults

  local file; file="$(manifest_file "$id")"
  local count; count=$(jq -r '.prompts | length' "$file")

  [[ "$count" -eq 0 ]] && return 0

  _MENU_ANSWERS=()

  local i
  for (( i = 0; i < count; i++ )); do
    local prompt; prompt=$(jq -c ".prompts[$i]" "$file")
    _menu_handle_prompt "$prompt" "$mode" || return 1
  done
}

# ── Prompt dispatcher ─────────────────────────────────────────────────────────

# _menu_handle_prompt <prompt_json> <mode>
_menu_handle_prompt() {
  local prompt="$1"
  local mode="$2"

  local key type label default required depends_on
  key=$(jq -r '.key' <<< "$prompt")
  type=$(jq -r '.type' <<< "$prompt")
  label=$(jq -r '.label' <<< "$prompt")
  default=$(jq -r '.default // ""' <<< "$prompt")
  required=$(jq -r '.required // false' <<< "$prompt")
  depends_on=$(jq -r '.depends_on // ""' <<< "$prompt")

  # depends_on check: skip this prompt if its dependency was falsy
  if [[ -n "$depends_on" ]]; then
    local dep_val="${_MENU_ANSWERS[$depends_on]:-}"
    if [[ -z "$dep_val" || "$dep_val" == "false" || "$dep_val" == "0" ]]; then
      return 0
    fi
  fi

  # Determine initial value
  local current
  if [[ "$mode" == "--defaults" ]]; then
    current="$default"
  else
    current=$(_menu_read_current "$prompt")
    [[ -z "$current" ]] && current="$default"
  fi

  # Dispatch to dialog type
  local answer
  case "$type" in
    input)
      answer=$(_menu_inputbox "$label" "$current") || {
        [[ "$required" == "true" ]] && return 1
        answer="$current"
      }
      ;;
    secret)
      answer=$(_menu_passwordbox "$label") || {
        [[ "$required" == "true" ]] && return 1
        answer=""
      }
      # Empty secret with existing value → keep existing
      [[ -z "$answer" && -n "$current" ]] && answer="$current"
      ;;
    yesno)
      if _menu_yesno "$label" "$current"; then
        answer="true"
      else
        answer="false"
      fi
      ;;
    checklist)
      local choices; choices=$(jq -c '.choices' <<< "$prompt")
      answer=$(_menu_checklist "$label" "$choices" "$current") || {
        [[ "$required" == "true" ]] && return 1
        answer="$current"
      }
      ;;
    radiolist)
      local choices; choices=$(jq -c '.choices' <<< "$prompt")
      answer=$(_menu_radiolist "$label" "$choices" "$current") || {
        [[ "$required" == "true" ]] && return 1
        answer="$current"
      }
      ;;
    custom)
      local custom_func; custom_func=$(jq -r '.custom_func' <<< "$prompt")
      if declare -f "$custom_func" &>/dev/null; then
        "$custom_func" || return 1
      else
        warn "Custom function '$custom_func' not defined — skipping"
      fi
      _MENU_ANSWERS[$key]="custom"
      return 0
      ;;
    *)
      warn "Unknown prompt type '$type' for key '$key' — skipping"
      return 0
      ;;
  esac

  _MENU_ANSWERS[$key]="$answer"
  _menu_write_answer "$prompt" "$answer"
}

# ── Current value reader ──────────────────────────────────────────────────────

# _menu_read_current <prompt_json>
# Reads the current value from stack.json or .env based on write_target.
_menu_read_current() {
  local prompt="$1"
  local write_target; write_target=$(jq -r '.write_target // ""' <<< "$prompt")

  case "$write_target" in
    stack.json)
      local path; path=$(jq -r '.write_path // ""' <<< "$prompt")
      [[ -z "$path" ]] && return 0
      local stack_file="${REPO_DIR}/config/stack.json"
      [[ -f "$stack_file" ]] || return 0
      jq -r "$path // empty" "$stack_file" 2>/dev/null || true
      ;;
    env)
      local env_var; env_var=$(jq -r '.env_var // ""' <<< "$prompt")
      [[ -z "$env_var" ]] && return 0
      local env_file="${REPO_DIR}/.env"
      [[ -f "$env_file" ]] || return 0
      grep -m1 "^${env_var}=" "$env_file" 2>/dev/null | cut -d= -f2- || true
      ;;
  esac
}

# ── Answer writer ─────────────────────────────────────────────────────────────

# _menu_write_answer <prompt_json> <value>
# Writes the answer to the appropriate destination.
_menu_write_answer() {
  local prompt="$1"
  local value="$2"
  local write_target; write_target=$(jq -r '.write_target // ""' <<< "$prompt")

  case "$write_target" in
    stack.json)
      local path; path=$(jq -r '.write_path // ""' <<< "$prompt")
      [[ -n "$path" ]] && _write_stack_json "$path" "$value"
      ;;
    env)
      local env_var; env_var=$(jq -r '.env_var // ""' <<< "$prompt")
      [[ -n "$env_var" ]] && _write_env "$env_var" "$value"
      ;;
  esac
}

# ── stack.json writer ─────────────────────────────────────────────────────────

# _write_stack_json <jq_path> <value>
# Atomically writes a value to config/stack.json.
# Auto-detects type: true/false → boolean, digits-only → number, else string.
_write_stack_json() {
  local path="$1"
  local value="$2"
  local stack_file="${REPO_DIR}/config/stack.json"
  local tmp_file="${stack_file}.tmp.$$"

  # Type detection
  local jq_value
  if [[ "$value" == "true" || "$value" == "false" ]]; then
    jq_value="$value"
  elif [[ "$value" =~ ^-?[0-9]+$ ]]; then
    jq_value="$value"
  else
    jq_value=$(jq -n --arg v "$value" '$v')
  fi

  jq --argjson val "$jq_value" "$path = \$val" "$stack_file" > "$tmp_file" \
    && mv "$tmp_file" "$stack_file" \
    || { rm -f "$tmp_file"; warn "Failed to write $path to stack.json"; return 1; }
}

# ── .env writer ───────────────────────────────────────────────────────────────

# _write_env <var> <value>
# Idempotent .env update. Uses a temp file — no sed.
# If var already exists, replaces the line. If not, appends.
_write_env() {
  local var="$1"
  local value="$2"
  local env_file="${REPO_DIR}/.env"
  local tmp_file="${env_file}.tmp.$$"

  if [[ ! -f "$env_file" ]]; then
    echo "${var}=${value}" > "$env_file"
    return
  fi

  if grep -q "^${var}=" "$env_file"; then
    # Replace existing line by writing all lines, substituting the match
    local found=0
    while IFS= read -r line; do
      if [[ "$line" == "${var}="* && $found -eq 0 ]]; then
        echo "${var}=${value}"
        found=1
      else
        echo "$line"
      fi
    done < "$env_file" > "$tmp_file"
    mv "$tmp_file" "$env_file"
  else
    echo "${var}=${value}" >> "$env_file"
  fi
}

# ── whiptail wrappers ─────────────────────────────────────────────────────────

_menu_inputbox() {
  local label="$1"
  local current="$2"
  whiptail --title "Configure" --inputbox "$label" 10 60 "$current" 3>&1 1>&2 2>&3
}

_menu_passwordbox() {
  local label="$1"
  whiptail --title "Configure" --passwordbox "$label" 10 60 "" 3>&1 1>&2 2>&3
}

_menu_yesno() {
  local label="$1"
  local current="$2"
  local args=()
  # Default to "no" unless current is true/yes
  [[ "$current" == "true" || "$current" == "yes" || "$current" == "1" ]] || args+=("--defaultno")
  whiptail --title "Configure" --yesno "$label" 10 60 "${args[@]}" 3>&1 1>&2 2>&3
}

# _menu_checklist <label> <choices_json> <current_csv>
# choices_json: JSON array of {value, label} objects
# current_csv:  comma-separated currently selected values
_menu_checklist() {
  local label="$1"
  local choices_json="$2"
  local current="$3"

  local -a args=()
  local count; count=$(jq -r 'length' <<< "$choices_json")
  local i
  for (( i = 0; i < count; i++ )); do
    local val lbl state
    val=$(jq -r ".[$i].value" <<< "$choices_json")
    lbl=$(jq -r ".[$i].label" <<< "$choices_json")
    # Mark on if val appears in current csv
    if echo ",$current," | grep -q ",${val},"; then
      state="ON"
    else
      state="OFF"
    fi
    args+=("$val" "$lbl" "$state")
  done

  whiptail --title "Configure" --checklist "$label" \
    20 78 "$count" "${args[@]}" 3>&1 1>&2 2>&3 \
    | tr -d '"' | tr ' ' ','
}

# _menu_radiolist <label> <choices_json> <current>
# choices_json: JSON array of {value, label} objects
_menu_radiolist() {
  local label="$1"
  local choices_json="$2"
  local current="$3"

  local -a args=()
  local count; count=$(jq -r 'length' <<< "$choices_json")
  local i
  for (( i = 0; i < count; i++ )); do
    local val lbl state
    val=$(jq -r ".[$i].value" <<< "$choices_json")
    lbl=$(jq -r ".[$i].label" <<< "$choices_json")
    [[ "$val" == "$current" ]] && state="ON" || state="OFF"
    args+=("$val" "$lbl" "$state")
  done

  whiptail --title "Configure" --radiolist "$label" \
    20 78 "$count" "${args[@]}" 3>&1 1>&2 2>&3
}
