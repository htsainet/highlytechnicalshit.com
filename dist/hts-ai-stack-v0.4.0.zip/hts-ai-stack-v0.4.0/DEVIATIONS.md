# Vendor-Instruction Deviations

Last updated: 2026-04-29

Per the **Install per vendor instructions** rule (see `CLAUDE.md` / `AGENTS.md`),
all components must be installed following the official software vendor's
documented instructions. This file is the single source of truth for every
knowing deviation from those instructions.

- **CONTEXT.md** — links here; does not duplicate entries.
- **REFERENCES.md** — holds the vendor doc URL plus any supporting links
  (upstream issues, PRs, advisories) that justify each deviation.

## Baseline: the manifest

For any given component, the **vendor install baseline** is the manifest's
`upstream` block — specifically the `install_docs` URL and `install_method`
(see `scripts/components/CONTEXT.md` for the schema). A "deviation" is any
install/config step not traceable to that URL. `REFERENCES.md` mirrors the
same info for humans; if the two disagree, the manifest wins and
`REFERENCES.md` must be corrected.

## When to add an entry

Add an entry *before* merging any change that:

- Uses a non-vendor package source, mirror, or fork.
- Adds custom install flags, patches, or post-install steps not in the vendor docs.
- Pins to a version the vendor does not currently recommend.
- Skips or reorders a step the vendor marks as required.
- Replaces a vendor-supplied installer/CLI with our own wrapper.

If in doubt, add an entry. No silent deviations.

## Entry template

Copy this block per component. Keep subsections alphabetical.

```markdown
### <Component Name>

- **Vendor doc followed:** <URL to the official install/quickstart page>
- **Deviation:** <what we do differently from the vendor's steps>
- **Why:** <rationale — bug, env constraint, security hardening, pinning, etc.>
- **Where implemented:** <script / manifest / compose file path>
- **Revisit when:** <condition that would let us drop the deviation>
- **References:** see `REFERENCES.md` → *<Component Name>* section
```

<!-- Add component deviation subsections below this line, alphabetical. -->

### KoboldCpp

- **Vendor doc followed:** <https://github.com/LostRuins/koboldcpp#compiling-on-linux-using-make-recommended>
- **Deviation:** Building from upstream LostRuins/koboldcpp source at pinned tag
  `v1.112.2` (commit `b31877e8ec8a1a58e7da88e0b235b9ca0028f504`) instead of
  pulling `koboldai/koboldcpp:latest` from Docker Hub. A custom `entrypoint.sh`
  maps `KOBOLDCPP_*` env vars to `koboldcpp.py` CLI args and handles first-run
  model download via `curl`, replacing the upstream `docker-helper.sh` (which
  also fetches the koboldcpp binary, runs `aria2`, and starts a Cloudflare
  tunnel).
- **Why:** KoboldAI publishes only `:latest` — no semver tags, no signed
  releases, no SBOM. Building from a pinned LostRuins release tag gives
  reproducible provenance and removes the runtime binary fetch, `aria2`, and
  the Cloudflare tunnel client that ship in the upstream image.
- **Where implemented:** `docker/koboldcpp/Dockerfile` (multi-stage
  `nvidia/cuda` source build); `docker/koboldcpp/entrypoint.sh` (env-var →
  arg mapping + model download);
  `scripts/components/koboldcpp/koboldcpp.manifest.json`
  (`upstream.install_method: "docker-build"`,
  `upstream.pinned_version: "v1.112.2"`).
- **Revisit when:** KoboldAI starts publishing tagged immutable images to
  Docker Hub, or LostRuins publishes an official Docker image directly.
- **References:** see `REFERENCES.md` → *KoboldCpp* section

### NemoClaw

NemoClaw deviations are tracked alongside the component, not here. Source of truth:

- [`scripts/components/nemoclaw/DEVIATIONS.md`](scripts/components/nemoclaw/DEVIATIONS.md)
  — current deviations grounded to the manifest pin (NemoClaw `v0.0.31`,
  OpenShell `0.0.36`).
- [`scripts/components/nemoclaw/DEVIATIONS-history.md`](scripts/components/nemoclaw/DEVIATIONS-history.md)
  — historical context (v0.0.21 → v0.0.29 transition, removed scaffolding).
- [`scripts/components/nemoclaw/CONTEXT.md`](scripts/components/nemoclaw/CONTEXT.md)
  — operational runbook.
- [`scripts/components/nemoclaw/REFERENCES.md`](scripts/components/nemoclaw/REFERENCES.md)
  — architecture, working configuration, smoke-test plan, rollback procedure.

### Open-LLM-VTuber

- **Vendor doc followed:** <https://github.com/Open-LLM-VTuber/Open-LLM-VTuber>
- **Deviation:** We build a custom Dockerfile from source (upstream ships no
  official Docker image). `run_server.py` is used as the entry point (upstream
  renamed it from `main.py`). `conf.yaml` is written to
  `config/open-llm-vtuber/conf.yaml` in the repo and bind-mounted into the
  container at `/app/conf.yaml:ro` rather than being injected into a named
  volume. Only `/app/data` is volume-mounted (runtime state); the app root
  `/app` is left as image content so the cloned repo remains visible.
- **Why:** Upstream provides no official image. The previous implementation
  mounted a named volume at `/app` (the app root), which hid the entire cloned
  repo including `run_server.py`, causing the container to crash-loop with
  `python: can't open file '/app/main.py': [Errno 2] No such file or directory`.
  The volume was also pre-created manually via `docker volume create`, which
  caused compose to emit `volume already exists but was not created by Docker
  Compose` warnings and prevented the volume from being managed by compose
  lifecycle commands. The bind-mount approach is idiomatic for config files
  that live at a fixed path in the repo root.
- **Where implemented:** `docker/open-llm-vtuber/Dockerfile` (entry point,
  data dir); `docker-compose.yml` (`open-llm-vtuber` service volumes block);
  `scripts/components/open-llm-vtuber/open-llm-vtuber.sh`
  (`open_llm_vtuber_configure`).
- **Revisit when:** Upstream publishes an official Docker image or a
  `docker-compose.yml` with documented volume layout; or when upstream
  stabilises the entry point name and config file path.
- **References:** see `REFERENCES.md` → *Open-LLM-VTuber* section

#### Additional deviations (avatar + chat fixes)

- **Auto-generated `model_dict.json`.** Upstream's
  `model_dict.json` only registers `mao_pro`; every other on-disk Live2D
  avatar (hijiki, shizuku, tororo, IceGirl, etc.) crashes
  `init_live2d` → `init_agent` with `'NoneType' object has no
  attribute 'emo_str'`. We ship `gen_model_dict.py` which scans
  `live2d-models/` and writes `config/open-llm-vtuber/model_dict.json`
  with the curated `mao_pro` entry preserved and minimal defaults
  (`kScale: 0.0003`, `emotionMap: {neutral: 0}`) for the rest. The
  generated file is bind-mounted to `/app/model_dict.json:ro`.
  *Where:* `scripts/components/open-llm-vtuber/gen_model_dict.py`,
  `open-llm-vtuber.sh::open_llm_vtuber_configure`,
  `docker-compose.yml`.
  *Revisit when:* upstream registers all bundled avatars in
  `model_dict.json`, or we add per-avatar `kScale`/offset overrides
  upstream.

- **`--choose-avatar` force-recreates the container.** The default
  compose flow (`--no-recreate`) plus single-file bind-mounts (which
  pin inode at mount time) meant edits to `conf.yaml` never propagated
  to a running container — the avatar picker silently no-op'd or
  triggered a crash-loop. Our flow now stops the container, regenerates
  `conf.yaml` + `model_dict.json`, then starts with
  `HTS_FORCE_REBUILD=1` (→ `--force-recreate --build`).
  *Where:* `open-llm-vtuber.sh::open_llm_vtuber_choose_avatar`,
  `reapply-config.sh`.
  *Revisit when:* upstream supports SIGHUP-style config reload, or
  Docker single-file bind-mounts learn inode-tracking.

- **conf.yaml template hard-codes container-internal endpoint.**
  Template uses `base_url: http://llama-swap:8080/v1` (container port),
  not `${LLAMA_SWAP_PORT:-8081}` which is the host-published port and
  isn't routable on `ai-network`. Provider key is
  `openai_compatible_llm` (matches the only `llm_configs` block) — a
  prior `ollama_llm` value crashed `agent_factory` with
  `'NoneType' object has no attribute 'pop'`.
  *Where:* `open-llm-vtuber.sh::open_llm_vtuber_configure` template.
  *Revisit when:* upstream `agent_factory.py` gains a friendlier error
  for missing `llm_configs` keys, or we templatise the model id from a
  shared `.env` var.

### ROCm AMD drivers

- **Vendor doc followed:** <https://rocmdocs.amd.com/en/latest/Installation_Guide/Installation-Guide.html>
- **Deviation:** Adds official ROCm apt repository and installs `rocm-dkms`, `rocm-utils`, `rocm-dev` via a custom script (`scripts/host/amd.sh`) rather than manual steps.
- **Why:** Automates ROCm driver installation, integrates with bootstrap, ensures consistent version tracking.
- **Where implemented:** `scripts/host/amd.sh`, invoked from `bootstrap.sh`.
- **Revisit when:** ROCm provides an official installer script or the repository layout changes.
- **References:** see `REFERENCES.md` → *ROCm (AMD GPU drivers)* section.

### SearXNG

- **Vendor doc followed:** <https://docs.searxng.org/admin/installation-docker.html>
- **Deviation:** Added `DAC_OVERRIDE` to `cap_add` and set `FORCE_OWNERSHIP=true`
  explicitly in the environment block of the `searxng` service in
  `docker-compose.yml`. Upstream's basic compose example ships with no
  `cap_drop` at all; our hardened setup drops `ALL` capabilities and adds back
  only what is needed, which requires `DAC_OVERRIDE` to be listed explicitly.
- **Why:** With `cap_drop: ALL`, root loses its implicit bypass of
  discretionary-access-control checks. The upstream entrypoint
  (`container/entrypoint.sh`) chowns `/etc/searxng` to `searxng:searxng` and
  then, still running as root, `cp`s the bundled `settings.yml` template into
  that directory — which now requires `DAC_OVERRIDE` to succeed. Without it
  every fresh-volume start fails with
  `cp: can't create '/etc/searxng/settings.yml': Permission denied` and the
  container crash-loops. `CHOWN` alone is insufficient; it governs ownership
  changes, not write access across uid boundaries. `FORCE_OWNERSHIP=true`
  makes the entrypoint's chown path explicit rather than relying on the image
  default (which the entrypoint checks against the literal string `true` — so
  `FORCE_OWNERSHIP=1` would silently disable it). The healthcheck was also
  extended from `retries: 3 / start_period: 15s` to `retries: 5 /
  start_period: 30s` because Granian (the WSGI server used since the
  `2026.4.x` image series) takes longer than 15s to bind `/healthz` on first
  start.
- **Where implemented:** `docker-compose.yml` (`searxng` service `cap_add`,
  `environment`, and `healthcheck` blocks).
- **Revisit when:** The SearXNG entrypoint pre-initialises volume contents at
  image build time (removing the need for runtime writes to a chowned
  directory), or upstream publishes a compose example that documents the
  required capabilities for hardened deployments explicitly.
- **References:** upstream entrypoint
  <https://github.com/searxng/searxng/blob/master/container/entrypoint.sh>;
  related issue <https://github.com/searxng/searxng/issues/5059>.

### Stable Diffusion

- **Vendor doc followed:** <https://github.com/AUTOMATIC1111/stable-diffusion-webui/wiki/Install-and-Run-on-NVidia-GPUs>
- **Deviation:** We build and run AUTOMATIC1111's stable-diffusion-webui
  from a custom `docker/stable-diffusion/Dockerfile` (upstream ships no
  official image). We invoke A1111's own
  `launch.py --exit --skip-torch-cuda-test` **at image build time** so
  `prepare_environment()` clones the four support repos
  (`stable-diffusion-stability-ai`, `generative-models`, `k-diffusion`,
  `BLIP`) and checks out upstream's pinned commits using upstream's own
  pin table in `modules/launch_utils.py`. At runtime we pass
  `--skip-prepare-environment` so `launch.py` never touches git on the
  hot path. We also keep the healthcheck generous
  (`start_period: 900s`, `retries: 20`).
- **Why:** Running `prepare_environment()` at container start was the
  root of three distinct crash-loop classes within one month — git 2.34
  lacking `--refetch`, `generative-models` cloned shallow, and
  `k-diffusion` cloned shallow — each caused by upstream pinning a
  commit that wasn't in the shallow history. Moving the prepare step
  to build time makes every git-CLI or pin-reachability issue fail the
  *build* once (visible, fixable) instead of crash-looping the
  container forever. It also lets us use whatever git ships in the
  PyTorch base image (no more ppa:git-core/ppa) because git never runs
  at runtime.
- **Where implemented:** `docker/stable-diffusion/Dockerfile` (new
  build-time `RUN python launch.py --exit --skip-torch-cuda-test` and
  runtime `--skip-prepare-environment` CMD flag);
  `docker-compose.yml` (`stable-diffusion` service healthcheck);
  `scripts/components/stable-diffusion/stable-diffusion.sh`
  (`sd_health`).
- **Revisit when:** AUTOMATIC1111 publishes an official Docker image,
  or adds `--skip-prepare-environment` semantics to their own image
  build pattern.
- **References:** see `REFERENCES.md` → *Stable Diffusion* section;
  plan: `docs/planning/autopilot-mvp-stability-pass.md` Task 2.
