# setup-telegram.sh — Telegram Bot

Wires a Telegram bot into OpenClaw so you can chat with the AI via Telegram.

```bash
./setup-telegram.sh
```

> Requires the Docker stack running (`./02-setup-docker.sh` first) and an
> OpenClaw container up. The bot token is saved to `.env` on first run.

---

## Prerequisites

1. Create a bot via [@BotFather](https://t.me/BotFather) on Telegram:
   - Send `/newbot` and follow the prompts
   - Copy the token it gives you (format: `123456:ABC-DEF1234...`)

2. Optionally pre-set it in `.env` to skip the prompt:

   ```bash
   echo "TELEGRAM_BOT_TOKEN=<your-token>" >> .env
   ```

---

## What it does

| Step | Action |
|---|---|
| 1 | Reads `TELEGRAM_BOT_TOKEN` from `.env` or prompts for it |
| 2 | Validates the token with `api.telegram.org/getMe` |
| 3 | Patches `openclaw.json` inside the container to enable the Telegram channel |
| 4 | Restarts the `openclaw` container to apply the config |

---

## After setup

Open Telegram and message your bot. OpenClaw routes all messages through the
configured AI model and replies in the same thread.

```bash
# Check OpenClaw is receiving messages
docker compose logs -f openclaw
```

To disable the bot, set `enabled: false` in `openclaw.json`:

```bash
docker exec openclaw node -e "
  const fs = require('fs');
  const path = '/home/node/.openclaw/openclaw.json';
  const cfg = JSON.parse(fs.readFileSync(path, 'utf8'));
  cfg.channels.telegram.enabled = false;
  fs.writeFileSync(path, JSON.stringify(cfg, null, 2));
"
docker compose restart openclaw
```
