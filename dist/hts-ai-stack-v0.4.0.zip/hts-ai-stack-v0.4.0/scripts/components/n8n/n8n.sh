#!/usr/bin/env bash
# scripts/components/n8n/n8n.sh — n8n workflow automation
#
# Standalone usage:
#   ./scripts/components/n8n/n8n.sh              # full: install + configure + start + health
#   ./scripts/components/n8n/n8n.sh --install    # install only
#   ./scripts/components/n8n/n8n.sh --configure  # configure only
#   ./scripts/components/n8n/n8n.sh --start      # start only
#   ./scripts/components/n8n/n8n.sh --stop       # stop
#   ./scripts/components/n8n/n8n.sh --restart    # restart (stop + start)
#   ./scripts/components/n8n/n8n.sh --health     # health check only
#   ./scripts/components/n8n/n8n.sh --status     # show status + port + health
#   ./scripts/components/n8n/n8n.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

load_env
N8N_PORT="${N8N_PORT:-5678}"
N8N_CONTAINER="${N8N_CONTAINER:-hts-ai-n8n-1}"

# ── Lifecycle functions ───────────────────────────────────────────────────────

n8n_install() {
  step "n8n — install"
  compose_build --profile n8n n8n
  ok "n8n image built."
}

n8n_configure() {
  step "n8n — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^N8N_PORT=" "$env_file" 2>/dev/null; then
    printf 'N8N_PORT=%s\n' "$N8N_PORT" >> "$env_file"
    info "Added N8N_PORT=${N8N_PORT} to .env"
  fi

  ok "n8n configured (port ${N8N_PORT})."
}

n8n_start() {
  step "n8n — start"
  compose_up --profile n8n n8n
  ok "n8n started on port ${N8N_PORT}."
}

n8n_stop() {
  step "n8n — stop"
  compose_down --profile n8n n8n
  ok "n8n stopped."
}

n8n_health() {
  health_probe "n8n :${N8N_PORT}" "http://localhost:${N8N_PORT}/healthz"
}

n8n_restart() {
  n8n_stop
  n8n_start
}

n8n_destroy() {
  step "n8n — destroy"
  compose_down --profile n8n n8n -v
  ok "n8n destroyed."
}

n8n_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=n8n" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "n8n is running (port ${N8N_PORT})"
  else
    warn "n8n is not running."
  fi
  n8n_health 2>/dev/null || true
}

# ── Standalone execution ──────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   n8n_install   ;;
    configure) n8n_configure ;;
    start)     n8n_start     ;;
    stop)      n8n_stop      ;;
    restart)   n8n_restart   ;;
    health)    n8n_health    ;;
    status)    n8n_status    ;;
    destroy)   n8n_destroy   ;;
    default)
      n8n_install
      n8n_configure
      n8n_start
      n8n_health
      ;;
  esac
fi
