#!/usr/bin/env bash
# scripts/lib/compose.sh — Docker Compose wrapper helpers
# Source this file; do NOT run directly.
# Requires: common.sh sourced first (for REPO_DIR, colors, logging, load_env)

_compose_base() {
  local args=("docker" "compose" "-f" "$REPO_DIR/docker-compose.yml" "--env-file" "$REPO_DIR/.env")
  # Append any --profile flags passed as leading arguments
  while [[ $# -gt 0 && "$1" == "--profile" ]]; do
    args+=("--profile" "$2")
    shift 2
  done
  args+=("$@")
  "${args[@]}"
}

# compose_up [--profile <name>]... [--no-wait] [extra docker compose up flags]
# Brings up services with optional profile flags.
# Starts containers unconditionally, then waits for healthchecks (default).
# Use --no-wait to skip the health wait entirely.
# Returns 0 if containers started. Sets COMPOSE_UP_HEALTH_FAILED=1 if any
# healthchecks failed (but does NOT exit non-zero — caller decides how to handle).
COMPOSE_UP_HEALTH_FAILED=0
compose_up() {
  local profiles=()
  local do_wait=true
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --profile) profiles+=("--profile" "$2"); shift 2 ;;
      --no-wait) do_wait=false; shift ;;
      *)         break ;;
    esac
  done

  # When install.sh --force-rebuild exports HTS_FORCE_REBUILD=1, swap the
  # default --no-recreate for --force-recreate (and add --build as a safety
  # net in case the caller did not run the pre-converge rebuild step). This
  # is the only reliable way to make a freshly-rebuilt image actually be
  # used by the running container.
  local up_recreate_flags=(--no-recreate)
  if [[ "${HTS_FORCE_REBUILD:-0}" == "1" ]]; then
    up_recreate_flags=(--force-recreate --build)
  fi

  COMPOSE_UP_HEALTH_FAILED=0
  info "Starting containers..."
  _compose_base "${profiles[@]}" up -d "${up_recreate_flags[@]}" "$@"

  if [[ "$do_wait" == "true" ]]; then
    info "Waiting for healthchecks (this may take several minutes)..."
    if ! _compose_base "${profiles[@]}" up -d "${up_recreate_flags[@]}" --wait "$@" 2>/dev/null; then
      COMPOSE_UP_HEALTH_FAILED=1
      warn "One or more containers failed healthchecks — continuing"
    fi
  fi
}

# compose_down [--profile <name>]... [extra flags]
compose_down() {
  local profiles=()
  while [[ $# -gt 0 && "$1" == "--profile" ]]; do
    profiles+=("--profile" "$2")
    shift 2
  done
  _compose_base "${profiles[@]}" down "$@"
}

# compose_pull [--profile <name>]... [extra flags]
compose_pull() {
  local profiles=()
  while [[ $# -gt 0 && "$1" == "--profile" ]]; do
    profiles+=("--profile" "$2")
    shift 2
  done
  echo -e "\n${CYAN}${BOLD}┌──────────────────────────────────────────────────┐${NC}"
  echo -e "${CYAN}${BOLD}│  Pulling Docker images...                        │${NC}"
  echo -e "${CYAN}${BOLD}└──────────────────────────────────────────────────┘${NC}"
  # List images that will be pulled
  local images
  images=$(_compose_base "${profiles[@]}" config --images 2>/dev/null) || true
  if [[ -n "$images" ]]; then
    while IFS= read -r img; do
      [[ -n "$img" ]] && echo -e "  ${YELLOW}↓${NC} $img"
    done <<< "$images"
    echo ""
  fi
  _compose_base "${profiles[@]}" pull --ignore-buildable "$@"
}

# compose_build [--profile <name>]... [extra flags]
# Builds images for services that have a build: directive.
compose_build() {
  local profiles=()
  while [[ $# -gt 0 && "$1" == "--profile" ]]; do
    profiles+=("--profile" "$2")
    shift 2
  done
  echo -e "\n${CYAN}${BOLD}┌──────────────────────────────────────────────────┐${NC}"
  echo -e "${CYAN}${BOLD}│  Building Docker image from source...             │${NC}"
  echo -e "${CYAN}${BOLD}└──────────────────────────────────────────────────┘${NC}\n"
  _compose_base --progress=plain "${profiles[@]}" build "$@"
}

# ensure_backend_exclusive — DEPRECATED (dual-inference)
# Both backends (ollama-gpu + bitnet-cpu) now run simultaneously,
# fronted by llama-swap. Kept as no-op for backward compatibility.
ensure_backend_exclusive() {
  :  # no-op — dual backends are the default
}

# _container_name <service>
# Returns the running container name for a docker-compose service using label lookup.
# Resilient to replica index changes — does not hardcode the project prefix or suffix.
_container_name() {
  docker ps -a \
    --filter "label=com.docker.compose.service=$1" \
    --filter "label=com.docker.compose.project=hts-ai" \
    --format "{{.Names}}" 2>/dev/null | head -1
}
