#!/usr/bin/env bash
# scripts/components/ardour/ardour.sh — Ardour DAW: install, configure, health
#
# Host-native installer for Ardour, the professional digital audio workstation.
# Installs from the Ubuntu repositories. Requires a desktop session for use.
#
# Standalone usage:
#   ./scripts/components/ardour/ardour.sh              # full: install + configure + health
#   ./scripts/components/ardour/ardour.sh --install    # install only
#   ./scripts/components/ardour/ardour.sh --configure  # configure only
#   ./scripts/components/ardour/ardour.sh --start      # no-op (desktop app)
#   ./scripts/components/ardour/ardour.sh --stop       # no-op (desktop app)
#   ./scripts/components/ardour/ardour.sh --restart    # no-op (desktop app)
#   ./scripts/components/ardour/ardour.sh --health     # health check only
#   ./scripts/components/ardour/ardour.sh --status     # show status + health
#   ./scripts/components/ardour/ardour.sh --destroy    # uninstall Ardour
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# ── Functions ────────────────────────────────────────────────────────────────

ardour_install() {
  step "Ardour — install"

  if command -v ardour8 &>/dev/null || command -v ardour7 &>/dev/null || command -v ardour &>/dev/null; then
    local ver
    ver=$(ardour8 --version 2>/dev/null || ardour7 --version 2>/dev/null || ardour --version 2>/dev/null | head -1)
    skip "Ardour already installed (${ver:-version unknown})"
  else
    info "Installing Ardour..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq ardour
    ok "Ardour installed."
  fi
}

ardour_configure() {
  step "Ardour — configure"
  info "Launch Ardour from the desktop to complete first-run configuration."
  info "Ardour will create its config directory at ~/.config/ardour*/"
  ok "Ardour configured."
}

ardour_start() {
  step "Ardour — start"
  info "Desktop application — launch from your desktop environment."
  if [[ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]]; then
    info "Desktop session detected. You can launch Ardour from the applications menu."
  else
    warn "No desktop session detected — Ardour requires a GUI to run."
  fi
  ok "Ardour start complete."
}

ardour_stop() {
  step "Ardour — stop"
  info "Desktop application — close from the GUI."
  ok "Ardour stop complete."
}

ardour_health() {
  local label="Ardour DAW"
  printf "  %-35s" "$label"
  if command -v ardour8 &>/dev/null || command -v ardour7 &>/dev/null || command -v ardour &>/dev/null; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (ardour not found in PATH)"
    return 1
  fi
}

ardour_restart() {
  ardour_stop
  ardour_start
}

ardour_destroy() {
  step "Ardour — destroy"
  info "Removing Ardour..."
  sudo apt-get remove -y ardour 2>/dev/null || true
  sudo apt-get autoremove -y -qq
  ok "Ardour removed."
}

ardour_status() {
  step "Ardour — status"
  if command -v ardour8 &>/dev/null; then
    ok "Ardour 8 installed"
  elif command -v ardour7 &>/dev/null; then
    ok "Ardour 7 installed"
  elif command -v ardour &>/dev/null; then
    ok "Ardour installed"
  else
    warn "Ardour NOT installed"
  fi
  ardour_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   ardour_install   ;;
    configure) ardour_configure ;;
    start)     ardour_start     ;;
    stop)      ardour_stop      ;;
    restart)   ardour_restart   ;;
    health)    ardour_health    ;;
    status)    ardour_status    ;;
    destroy)   ardour_destroy   ;;
    default)
      ardour_install
      ardour_configure
      ardour_health
      ;;
  esac
fi
