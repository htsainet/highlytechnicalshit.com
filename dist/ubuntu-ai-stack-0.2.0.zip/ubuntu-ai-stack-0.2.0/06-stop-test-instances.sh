#!/usr/bin/env bash
# 06-stop-test-instances.sh — Stop test instance and shared voice services
#
# Stops:
#   - instances/test  (ollama-test, sd-test, sillytavern-test, open-webui-test)
#   - whisper, xtts   (shared infra voice services from root compose)
#
# Leaves running:
#   - instances/prod  (ollama-prod, sd-prod, sillytavern-prod, open-webui-prod)
#   - jenkins, dashboard, dashboard-proxy (root compose infra)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_COMPOSE="$SCRIPT_DIR/docker-compose.yml"
TEST_COMPOSE="$SCRIPT_DIR/instances/test/docker-compose.yml"

echo ""
echo "══ Stopping test instance ══"
if docker compose -f "$TEST_COMPOSE" ps --services --filter status=running 2>/dev/null | grep -q .; then
  docker compose -f "$TEST_COMPOSE" stop
  echo "  test instance stopped."
else
  echo "  test instance already stopped."
fi

echo ""
echo "══ Stopping shared voice services (whisper, xtts) ══"
docker compose -f "$ROOT_COMPOSE" stop whisper xtts 2>/dev/null \
  && echo "  whisper + xtts stopped." \
  || echo "  whisper/xtts not running or not found."

echo ""
echo "══ Current status ══"
echo "  — Root compose —"
docker compose -f "$ROOT_COMPOSE" ps --format "table {{.Name}}\t{{.Status}}" 2>/dev/null || true
echo ""
echo "  — Prod instance —"
docker compose -f "$SCRIPT_DIR/instances/prod/docker-compose.yml" ps --format "table {{.Name}}\t{{.Status}}" 2>/dev/null || true

echo ""
echo "Done. Prod instance left untouched."
