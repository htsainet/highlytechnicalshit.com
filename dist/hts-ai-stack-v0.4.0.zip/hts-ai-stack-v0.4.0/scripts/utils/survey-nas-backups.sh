#!/usr/bin/env bash
# survey-nas-backups.sh — Enumerate what's actually in the NAS backup mounts.
#
# Purpose:
#   find-nemoclaw-backup-version.sh came up empty. Before extending it we need
#   to know the *shape* of each backup (tarballs? loop-mountable images?
#   extracted trees? empty?) so we can walk them correctly.
#
# What it reports per mount:
#   • total size + file count
#   • top-level entries (ls -la, first 40)
#   • file-type breakdown (tarballs, images, dirs)
#   • for timeshift: whether /home is excluded (look for @/home vs @/root)
#
# Usage:
#   sudo ./scripts/utils/survey-nas-backups.sh
set -euo pipefail

MOUNTS=(
  /mnt/htsai-timeshift-backup
  /mnt/htsai-docker-volume-backup
  /mnt/htsai-disk-image
  /mnt/htsai-model-backup
)

step() { echo; echo "════ $* ════"; }
info() { echo "    $*"; }

[[ $EUID -eq 0 ]] || { echo "Re-run with: sudo $0" >&2; exit 1; }

for m in "${MOUNTS[@]}"; do
  step "$m"
  if ! mountpoint -q "$m" 2>/dev/null; then
    info "(not mounted — skipping)"
    continue
  fi

  info "size:  $(du -sh "$m" 2>/dev/null | awk '{print $1}')"
  info "files: $(find "$m" -xdev -type f 2>/dev/null | wc -l)"
  info "dirs:  $(find "$m" -xdev -type d 2>/dev/null | wc -l)"

  echo
  info "── top-level ──"
  ls -la "$m" 2>/dev/null | head -40 | sed 's/^/      /'

  echo
  info "── file-type breakdown (top 15 extensions) ──"
  find "$m" -xdev -type f 2>/dev/null \
    | awk -F. '{print tolower($NF)}' \
    | sort | uniq -c | sort -rn | head -15 \
    | sed 's/^/      /'

  echo
  info "── archives (.tar / .tar.gz / .tgz / .zst) ──"
  find "$m" -xdev -type f \
    \( -name '*.tar' -o -name '*.tar.gz' -o -name '*.tgz' \
       -o -name '*.tar.zst' -o -name '*.tar.xz' \) \
    2>/dev/null | head -20 | sed 's/^/      /'

  echo
  info "── disk images (.img / .qcow2 / .raw / .vhd) ──"
  find "$m" -xdev -type f \
    \( -name '*.img' -o -name '*.qcow2' -o -name '*.raw' -o -name '*.vhd' \
       -o -name '*.vmdk' \) \
    2>/dev/null | head -20 | sed 's/^/      /'

  echo
  info "── candidate hits (grep filenames for nemoclaw/openshell) ──"
  find "$m" -xdev 2>/dev/null | grep -iE 'nemoclaw|openshell|blueprint\.yaml' \
    | head -20 | sed 's/^/      /' || info "(none)"

  # Timeshift-specific: detect whether /home was included in snapshots
  if [[ "$m" == *timeshift* ]]; then
    echo
    info "── timeshift /home coverage ──"
    # rsync snapshots: look for snapshots/*/localhost/home/<user>
    # btrfs snapshots: look for @home vs just @
    find "$m" -xdev -maxdepth 6 -type d \
      \( -path '*/localhost/home/*' -o -name '@home' \) \
      2>/dev/null | head -5 | sed 's/^/      /' \
      || info "      (no /home in snapshots — timeshift system-mode default)"
  fi
done

echo
echo "Done. Paste this output back so we can extend the version-finder to the"
echo "actual backup format (tarball walker, loop-mount disk image, etc)."
