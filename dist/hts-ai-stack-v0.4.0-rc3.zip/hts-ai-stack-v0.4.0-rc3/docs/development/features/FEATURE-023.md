# AutoGen — SUPERSEDED

**Priority:** ~~MEDIUM~~ → Superseded
**Target Release:** N/A
**Status:** Superseded → Microsoft Agent Framework (MAF)

> **AutoGen (`microsoft/autogen`) is now in maintenance mode.**
> Microsoft has moved to [Microsoft Agent Framework (MAF) 1.0](https://github.com/microsoft/agent-framework)
> as the official successor. AutoGen will not receive new features and is community-managed only.

## Decision

Do not build a component script or Docker service for AutoGen.

- **AutoGen** — maintenance mode; no new features; community-managed only
- **Microsoft Agent Framework 1.0** — production-ready successor; stable APIs;
  long-term support commitment; enterprise-grade multi-agent orchestration;
  A2A and MCP protocol support

## Migration Path

If you have existing AutoGen-based workflows, Microsoft provides an official migration guide:

> [AutoGen → Microsoft Agent Framework Migration Guide](https://learn.microsoft.com/en-us/agent-framework/migration-guide/from-autogen/)

Key changes:

- `autogen-agentchat` → `microsoft-agentframework-agentchat`
- `OpenAIChatCompletionClient` → MAF equivalent client
- Multi-agent team API is broadly compatible

## Future Evaluation

Microsoft Agent Framework should be evaluated as a future feature when it has
sufficient community adoption and Docker deployment patterns are established.
Add a new FEATURE-### at that time.

## Related

- [microsoft/agent-framework](https://github.com/microsoft/agent-framework) — MAF 1.0
- [FEATURE-022](FEATURE-022.md) — CrewAI (deployed alternative)
- [FEATURE-024](FEATURE-024.md) — LangGraph (deployed alternative)
