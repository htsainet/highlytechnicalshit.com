#!/usr/bin/env bash
# OpenCode – terminal AI coding agent (host tool)
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# shellcheck source=scripts/lib/common.sh
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=scripts/lib/health.sh
source "$REPO_DIR/scripts/lib/health.sh"

###############################################################################
# Lifecycle
###############################################################################

opencode_install() {
  info "Installing OpenCode …"
  if command -v opencode &>/dev/null; then
    ok "OpenCode is already installed"
    return 0
  fi

  curl -fsSL https://opencode.ai/install | bash
  hash -r

  if command -v opencode &>/dev/null; then
    ok "OpenCode installed successfully"
  else
    warn "OpenCode binary not found after install — check PATH"
    return 1
  fi
}

opencode_configure() {
  info "Configuring OpenCode for local llama-swap router …"

  # Canonical global config lives at ~/.config/opencode/opencode.json
  # (opencode also reads the legacy config.json, but current schema validation
  # rejects the old flat shape, so we migrate it out of the way.)
  local config_dir="${XDG_CONFIG_HOME:-$HOME/.config}/opencode"
  mkdir -p "$config_dir"

  local legacy_file="$config_dir/config.json"
  local config_file="$config_dir/opencode.json"
  local example_file="$REPO_DIR/scripts/components/opencode/opencode.json.example"

  # Back up any legacy config.json once, then remove it so opencode doesn't
  # keep rejecting it. Skip if a backup already exists (don't clobber history).
  if [[ -f "$legacy_file" ]]; then
    local backup="$legacy_file.legacy.bak"
    if [[ ! -f "$backup" ]]; then
      cp -p "$legacy_file" "$backup"
      info "Backed up legacy config.json → ${backup}"
    fi
    rm -f "$legacy_file"
  fi

  if [[ ! -f "$config_file" ]]; then
    if [[ -f "$example_file" ]]; then
      install -m 0644 "$example_file" "$config_file"
      ok "Created $config_file → llama-swap at localhost:8081"
    else
      warn "Missing $example_file — skipping opencode config seeding"
      return 1
    fi
  else
    ok "Config already exists at $config_file (not overwritten)"
  fi
}

opencode_start() {
  info "OpenCode is a terminal tool — launch with: opencode"
}

opencode_stop()    { :; }
opencode_restart() { :; }

opencode_health() {
  if command -v opencode &>/dev/null; then
    ok "OpenCode binary found: $(command -v opencode)"
    return 0
  fi
  warn "OpenCode not found in PATH"
  return 1
}

opencode_destroy() {
  info "Removing OpenCode …"
  local bin
  bin="$(command -v opencode 2>/dev/null || true)"
  if [[ -n "$bin" ]]; then
    sudo rm -f "$bin"
    ok "Removed $bin"
  fi
  rm -rf "${XDG_CONFIG_HOME:-$HOME/.config}/opencode"
  ok "OpenCode removed"
}

opencode_status() {
  if command -v opencode &>/dev/null; then
    echo "installed"
  else
    echo "not_installed"
  fi
}
