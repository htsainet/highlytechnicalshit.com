#!/usr/bin/env python3
"""stack-compose-check.py — verify compose-install manifests have a docker service.

Invariant (static — not stack.json-aware):
    Every scripts/components/*/*.manifest.json with install_type == "compose"
    MUST have a matching service in docker-compose.yml. The manifest `id` is
    the expected service name unless the manifest declares a
    `compose_service` override.

This is strictly stronger than "enabled-in-stack.json has a service" because
it catches manifest↔compose drift the moment a rename ships, regardless of
the user's current stack.json toggles. See FEATURE-068 for the planned
stack.json-aware follow-up that additionally validates *enabled* components
have all runtime prerequisites in place.

Usage:
    scripts/maintenance/stack-compose-check.py            # report only
    scripts/maintenance/stack-compose-check.py --strict   # exit 1 on drift

Exit codes:
    0 = all compose manifests resolve, or findings in report-only mode
    1 = --strict AND one or more findings
    2 = file / parse error
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.stderr.write("PyYAML required: pip install pyyaml\n")
    sys.exit(2)

REPO = Path(__file__).resolve().parents[2]
COMPONENTS = REPO / "scripts/components"
COMPOSE = REPO / "docker-compose.yml"


def main() -> int:
    strict = "--strict" in sys.argv[1:]

    try:
        compose = yaml.safe_load(COMPOSE.read_text())
    except Exception as exc:
        sys.stderr.write(f"ERROR reading {COMPOSE}: {exc}\n")
        return 2
    services = set((compose or {}).get("services", {}) or {})

    findings: list[str] = []
    checked = 0

    for mf in sorted(COMPONENTS.glob("*/*.manifest.json")):
        try:
            data = json.loads(mf.read_text())
        except Exception as exc:
            findings.append(f"{mf.relative_to(REPO)}: parse error: {exc}")
            continue

        if data.get("install_type") != "compose":
            continue
        checked += 1

        expected = data.get("compose_service") or data.get("id")
        rel_mf = mf.relative_to(REPO)

        if not expected:
            findings.append(f"{rel_mf}: manifest has no `id` or `compose_service` to resolve")
            continue
        if expected not in services:
            findings.append(
                f"{rel_mf}: install_type=compose but no `services.{expected}` in docker-compose.yml"
            )

    if not findings:
        print(
            f"✓ stack-compose-check: {checked} compose-install manifest(s) all resolve "
            f"to docker-compose services ({len(services)} services total)."
        )
        return 0

    print(f"✗ stack-compose-check: {len(findings)} finding(s):")
    for f in findings:
        print(f"    - {f}")
    print("  → Either add the missing service to docker-compose.yml, change the")
    print("    manifest's install_type, or add a `compose_service` override field.")

    return 1 if strict else 0


if __name__ == "__main__":
    sys.exit(main())
