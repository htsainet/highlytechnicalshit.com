#!/usr/bin/env bash
# setup.sh — Start the AI stack
#
# Usage:
#   ./setup.sh               # default: --chat mean (~7-8GB VRAM)
#   ./setup.sh --chat lean   # smollm2:135m (~500MB VRAM, dev/test)
#   ./setup.sh --chat mean   # gemma4:e4b (~7-8GB VRAM, default)
#   ./setup.sh --chat claw   # deepseek-r1:14b (~9GB VRAM, reasoning)
#
# Brings up: dashboard + ollama + open-webui + NemoClaw (mean/claw)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$SCRIPT_DIR/scripts/install/06-start-stack.sh" "$@"
