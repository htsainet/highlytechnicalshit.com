$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/ubuntu-audio'
    $script:ComponentScript = Join-Path $script:ComponentDir 'ubuntu-audio.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'ubuntu-audio.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'ubuntu-audio file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }

    It 'CONTEXT.md exists' {
        Join-Path $script:RepoRoot 'CONTEXT.md' | Should -Exist
    }

    It 'REFERENCES.md exists' {
        Join-Path $script:RepoRoot 'REFERENCES.md' | Should -Exist
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'ubuntu-audio component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines ubuntu_audio_install function' {
        $script:ComponentContent | Should -Match 'ubuntu_audio_install\s*\(\)'
    }

    It 'defines ubuntu_audio_configure function' {
        $script:ComponentContent | Should -Match 'ubuntu_audio_configure\s*\(\)'
    }

    It 'defines ubuntu_audio_start function' {
        $script:ComponentContent | Should -Match 'ubuntu_audio_start\s*\(\)'
    }

    It 'defines ubuntu_audio_stop function' {
        $script:ComponentContent | Should -Match 'ubuntu_audio_stop\s*\(\)'
    }

    It 'defines ubuntu_audio_health function' {
        $script:ComponentContent | Should -Match 'ubuntu_audio_health\s*\(\)'
    }

    It 'defines ubuntu_audio_restart function' {
        $script:ComponentContent | Should -Match 'ubuntu_audio_restart\s*\(\)'
    }

    It 'defines ubuntu_audio_destroy function' {
        $script:ComponentContent | Should -Match 'ubuntu_audio_destroy\s*\(\)'
    }

    It 'defines ubuntu_audio_status function' {
        $script:ComponentContent | Should -Match 'ubuntu_audio_status\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/ubuntu-audio/ubuntu-audio\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'ubuntu-audio no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/ubuntu-audio\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/ubuntu-audio/ubuntu-audio\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
