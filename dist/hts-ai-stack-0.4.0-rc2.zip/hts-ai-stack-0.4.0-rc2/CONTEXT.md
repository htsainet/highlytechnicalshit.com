# Current Project

Last updated: 2026-04-17 14:13:00

## What we are building

We are building a reproducible installation procedure for a customizable, Linux AI stack utilizing a locally hosted LLM to act as an AI Agent.  

Org Private Repo : https://github.com/htsainet/hts-ai-stack
Org Public Repo: https://github.com/htsainet/highlytechnicalshit.com

[Core Services]
OpenClaw: https://openclaw.ai/
NemoClaw: https://www.nvidia.com/en-us/ai/nemoclaw/
OpenShell: https://docs.nvidia.com/openshell/latest/index.html
Ollama: https://ollama.com/

### Stack Categories

Beyond the core AI services, the stack includes optional components across several categories:

- **Creative Writing** — KoboldCpp, Ghostwriter, SillyTavern (AI-assisted fiction & writing)
- **Music Production** — Ardour, AudioCraft/MusicGen, Ubuntu Studio Audio
- **Video Production** — Kdenlive, OBS, CogVideoX, Open-Sora
- **Animation** — Blender, Synfig, OpenToonz, AnimateDiff
- **Digital Art & Design** — GIMP, Krita, Inkscape, Darktable
- **Voice & Avatar** — Open-LLM-VTuber, Coqui TTS, Faster-Whisper
- **Developer Tools** — Tabby, OpenCode, Aider, Gitea, Gitea Runner
- **Agents & Chat** — OpenClaw, NemoClaw, Open WebUI, LibreChat, Agnai, AnythingLLM
- **Automation** — n8n, Flowise, Langflow, DeerFlow
- **Monitoring** — Grafana, Prometheus, Portainer
- **Search** — SearXNG
- **Backup** — Duplicati

See [REFERENCES.md](REFERENCES.md) for links, ports, and architecture details.

## What good looks like

User can securely run and manage a local clawbot instance without having to install everything manually.

## Completed Projects

- **Install pipeline refactor** — restructured scripts into `lib/`, `host/`, `components/`, `bundles/`. All 16 tasks completed. See [refactor/CONTEXT.md](refactor/CONTEXT.md) for decisions and archive.
- **Config-driven convergence** (FEATURE-009) — single declarative orchestrator (`converge.sh`) that reads `stack.json` via component manifests and converges the host to the desired state. `full-stack.sh` deprecated; `install.sh` now calls `converge.sh` directly. See [docs/development/features/FEATURE-009.md](docs/development/features/FEATURE-009.md).
- **Manifest-driven components** (FEATURE-038) — every component has a `manifest.json` with metadata, config mapping, health check definitions, and deployment order. Manifests drive both converge.sh and the dashboard.

## Active Projects

- **Dual-inference backend** — adding BitNet + llama-swap alongside Ollama for GPU/CPU split inference. See `feature/dual-inference` branch.
- **Dashboard auto-login** — tokenized URLs for Open WebUI and NemoClaw sandboxes so the dashboard provides one-click authenticated access without manual sign-in. Uses a same-origin login bridge page and JWT sidecar files.
- **OpenClaw auto-update** — `nemoclaw.sh --update` automatically updates OpenClaw inside GPU/CPU sandboxes to the latest version.
- **Docker image pinning + NAS mirroring** — all 38 Dockerfiles pinned to version tags + sha256 digests. `MIRROR` build arg enables a global toggle to pull from a local NAS registry instead of upstream. See `docker-images.md`, `scripts/host/nas-setup.sh`.

## Install Lifecycle

```text
bootstrap.sh  → prereqs, Docker, NVIDIA drivers (ALWAYS LAST — requires reboot)
install.sh    → wizard → apply_config → host prereqs → converge.sh --yes
reconfigure.sh → wizard → converge.sh (day-2, no host setup)
converge.sh   → stack.json → manifests → desired vs actual → start/stop/health
```

> **NVIDIA drivers are ONLY installed from `bootstrap.sh` and ALWAYS LAST because
> they require a forced reboot. Nothing else requires a reboot.**

## What to avoid

Avoid using cloud based LLMs within the app so spend can be controlled.

## Tools and dependencies

- **Ubuntu 24.04 LTS** — Target Linux distribution
- **Docker** — Container orchestration
- **NVIDIA CUDA** — GPU acceleration
- **Ollama** — Local LLM inference
- **llama-swap** — Model multiplexer for GPU/CPU split inference
- **NemoClaw** — Sandbox security enforcement
- **OpenClaw** — AI agent runtime
- **Open WebUI** — Chat frontend (all models via llama-swap)
- **Claude Code** — Documentation and script generation
- **Pester** — Configuration and integration testing
- **skopeo** — Container image inspection and digest resolution (no Docker daemon required)

## Docker Image Pinning + NAS Mirroring

All 38 Dockerfiles use `ARG MIRROR=` before each `FROM` line. When `MIRROR` is empty (default), images pull from upstream registries. When set to a local registry (e.g., `keepittuned:5000/`), all builds pull from the NAS mirror instead.

### Key files

| File | Purpose |
|---|---|
| `docker-images.md` | Sorted reference table of all base images, tags, and digests |
| `pin-docker-images.sh` | Resolves `latest` tags to version numbers + sha256 digests via skopeo |
| `pull-all-images.sh` | Pulls all 30 base images onto a Synology NAS (run via SSH) |
| `push-to-nas.sh` | Tags + pushes all 30 images to NAS registry (skopeo fallback) |
| `scripts/host/nas-setup.sh` | Interactive whiptail menu — configures Docker mirror + NFS share mounts |
| `scripts/host/nas.sh` | NFS plumbing — idmapd, fstab, mount, validate |
| `scripts/host/backup-models.sh` | Rsync Docker model volumes → NAS (never deletes) |
| `scripts/host/migrate-nas-folders.sh` | One-off: reorganize flat NAS layout into nested structure |
| `scripts/utils/seed-model-cache.sh` | Populate NAS model cache from registry.json |

### MIRROR toggle

Set in `.env` (gitignored — per-user):

```env
# Pull from upstream (default)
MIRROR=

# Pull from local NAS registry
MIRROR=keepittuned:5000/
```

Passed to all 38 services in `docker-compose.yml` via `build.args.MIRROR`.

### NFS share names

| Share | Mount point | Purpose |
|---|---|---|
| `htsai-model-backup` | `/mnt/htsai-model-backup` | AI model cache (Ollama, SD, ComfyUI, etc.) |
| `htsai-docker-volume-backup` | `/mnt/htsai-docker-volume-backup` | Docker volume backups |
| `htsai-timeshift-backup` | `/mnt/htsai-timeshift-backup` | Timeshift system snapshots |
| `htsai-disk-image` | `/mnt/htsai-disk-image` | Full disk images for disaster recovery |

NFS settings live in `~/.config/htsai/nas.env` (survives repo nuke-and-pave).
Docker MIRROR stays in repo `.env` (build concern only, disposable).

### NAS model cache layout

```text
/mnt/htsai-model-backup/
├── ollama/models/             ← Ollama blobs + manifests
├── stable-diffusion/
│   ├── checkpoints/           ← .safetensors model files
│   ├── loras/
│   ├── embeddings/
│   └── vae/
├── comfyui/
│   ├── models/
│   ├── custom_nodes/
│   └── output/
├── bitnet/models/
├── localai/models/
├── coqui-tts/models/
└── vosk/models/
```

### How model caching works (install → NAS → restore)

**Backup (host → NAS):**

```bash
sudo ./scripts/host/backup-models.sh
```

Rsyncs each Docker volume to its NAS subfolder. No `--delete` flag, so NAS
files are never removed. Safe to re-run — skips already-synced files.

**Restore (NAS → host, automatic at install time):**

Each component script checks for models on the NAS before downloading:

1. **Already in Docker volume?** → skip
2. **Available on NAS mount?** → copy locally (fast, no internet)
3. **Neither?** → download from internet, then seed NAS cache

| Component | NAS cache env var | Default path |
|---|---|---|
| Ollama | `NAS_MODEL_CACHE` | `/mnt/htsai-model-backup/ollama/models` |
| Stable Diffusion | `NAS_SD_CACHE` | `/mnt/htsai-model-backup/stable-diffusion/checkpoints` |
| ComfyUI | `NAS_SD_CACHE` | `/mnt/htsai-model-backup/stable-diffusion/checkpoints` |

**Nuke-and-pave workflow:**

1. `sudo ./backups/pre-nuke-checklist.sh --disk` — runs all backup layers
2. Delete repo / `docker system prune -a --volumes`
3. Reinstall Ubuntu, same hostname and user
4. `git clone` + `./install.sh` — rebuilds containers
5. `sudo ./scripts/host/nas-setup.sh` — restores NFS mounts
6. Restore Docker volumes from NAS archives
7. Component scripts auto-pull models from NAS on first run (no re-download)

See [docs/guides/disaster-recovery.md](docs/guides/disaster-recovery.md) for the full runbook.

## Backup & Disaster Recovery

Five backup layers protect against data loss at every level:

| Layer | Script | Destination | What it covers |
|---|---|---|---|
| OS snapshots | `backups/timeshift/setup-timeshift.sh` | `/mnt/htsai-timeshift-backup` | System packages, drivers, configs |
| Docker volumes | `backups/docker/backup-volumes.sh` | `/mnt/htsai-docker-volume-backup` | Chat history, workflows, repos, settings |
| Model weights | `scripts/host/backup-models.sh` | `/mnt/htsai-model-backup` | Ollama, SD, ComfyUI, TTS, Vosk models |
| System configs | `backups/pre-nuke-checklist.sh` | `/mnt/htsai-docker-volume-backup/configs/` | .env, fstab, daemon.json, stack.json |
| Full disk image | `backups/disk-image/backup-disk.sh` | `/mnt/htsai-disk-image` | Byte-for-byte dd+gzip clone (nuclear option) |

### Key files

| File | Purpose |
|---|---|
| `backups/pre-nuke-checklist.sh` | Orchestrates all backup layers in sequence before a nuke-and-pave |
| `backups/disk-image/backup-disk.sh` | Full disk image via `dd + gzip` piped directly to NAS |
| `backups/docker/backup-volumes.sh` | Pause → tar → archive Docker volumes to NAS (26 volumes) |
| `backups/timeshift/setup-timeshift.sh` | Install and configure Timeshift with AI-stack-tuned exclusions |
| `backups/synology/setup-nas-mount.sh` | TPM2-encrypted Synology CIFS mount (credentials never on disk) |
| `docs/guides/disaster-recovery.md` | Step-by-step nuke-and-pave restoration runbook |
| `docs/guides/synology-nfs-shares.md` | Synology DSM NFS share setup guide (4 shares) |
