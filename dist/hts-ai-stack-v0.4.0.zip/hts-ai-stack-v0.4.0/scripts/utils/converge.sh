#!/usr/bin/env bash

# Early help – prints the usage header (comment block) and exits before any heavy imports.
if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    _line_no=0
    while IFS= read -r _line; do
        (( _line_no++ ))
        # Skip shebang line and blank line at top
        (( _line_no < 2 )) && continue
        # Stop after the header comment (approx line 30)
        (( _line_no > 30 )) && break
        # Strip leading comment markers
        if [[ "$_line" == "# "* ]]; then
            printf '%s\n' "${_line#\# }"
        elif [[ "$_line" == "#"* ]]; then
            printf '%s\n' "${_line#\#}"
        else
            printf '%s\n' "$_line"
        fi
    done < "${BASH_SOURCE[0]}"
    exit 0
fi

# scripts/utils/converge.sh — Config-driven stack convergence
#
# Reads config/stack.json, compares against current runtime state,
# and brings the host into the desired state.
#
# Usage:
#   ./scripts/utils/converge.sh              # default: --yes (unattended)
#   ./scripts/utils/converge.sh --dry-run    # print plan, no changes
#   ./scripts/utils/converge.sh --yes        # apply all changes without prompting
#   ./scripts/utils/converge.sh --interactive # prompt before each action
#   ./scripts/utils/converge.sh --force      # ignore .last-applied.json, full convergence
#
# Exit codes:
#   0 — success (all actions completed)
#   1 — one or more actions failed
#   2 — usage error
#
# FEATURE-009: Config-Driven Convergence
set -euo pipefail

if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
  echo "[FAIL] Do not run as root (or with sudo). This script calls sudo internally where needed." >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ── Source dependencies ───────────────────────────────────────────────────────
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"
source "$REPO_DIR/scripts/lib/installstatus.sh"
source "$REPO_DIR/scripts/lib/component-registry.sh"
source "$REPO_DIR/scripts/lib/state-desired.sh"
source "$REPO_DIR/scripts/lib/state-actual.sh"
source "$REPO_DIR/scripts/lib/converge-diff.sh"

# ── Configuration ─────────────────────────────────────────────────────────────
LAST_APPLIED_FILE="$REPO_DIR/.last-applied.json"
LOG_FILE="${REPO_DIR}/logs/converge-$(date +%Y%m%d-%H%M%S).log"
mkdir -p "$(dirname "$LOG_FILE")"

# ── CLI parsing ───────────────────────────────────────────────────────────────
MODE="yes"          # yes | dry-run | interactive
FORCE=false

usage() {
  cat <<EOF
Usage: $(basename "$0") [OPTIONS]

Converge the stack to match config/stack.json.

Options:
  --dry-run       Print planned actions without executing
  --yes           Apply all changes without prompting (default)
  --interactive   Show diff summary, prompt before each action
  --force         Ignore .last-applied.json, full convergence
  -h, --help      Show this help message

Exit codes:
  0  Success (all actions completed)
  1  One or more actions failed
  2  Usage error
EOF
  exit 2
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run)     MODE="dry-run"; shift ;;
    --yes)         MODE="yes"; shift ;;
    --interactive) MODE="interactive"; shift ;;
    --force)       FORCE=true; shift ;;
    -h|--help)     usage ;;
    *)             fail "Unknown option: $1"; usage ;;
  esac
done

# ── Results tracking ──────────────────────────────────────────────────────────
declare -gA RESULT_STATUS   # component → success | failed | skipped
declare -gA RESULT_MESSAGE  # component → error message (if failed)
FAILED_COUNT=0

# ── Exit trap — guarantee report prints even on unexpected exit ───────────────
_CONVERGE_STARTED=false
_REPORT_PRINTED=false
_INSTALL_STATUS_FINALIZED=false

_converge_exit_trap() {
  local exit_code=$?
  if [[ "$_CONVERGE_STARTED" == "true" && "$_REPORT_PRINTED" != "true" ]]; then
    _print_report 2>/dev/null || true
    if [[ $exit_code -ne 0 ]]; then
      echo ""
      warn "Convergence terminated unexpectedly (exit $exit_code)"
      [[ -n "${LOG_FILE:-}" ]] && info "Log file: $LOG_FILE"
    fi
  fi
  # Guarantee install-status.json reaches a terminal phase so the dashboard
  # never stays stuck in "installing" mode if converge is killed (Ctrl-C,
  # signal, parent crash) between install_status_init and the normal
  # complete/error calls at the end of _execute_plan.
  if [[ "$_CONVERGE_STARTED" == "true" && "$_INSTALL_STATUS_FINALIZED" != "true" ]]; then
    if [[ $exit_code -eq 0 ]]; then
      install_status_complete 2>/dev/null || true
    else
      install_status_error 2>/dev/null || true
    fi
  fi
}
trap _converge_exit_trap EXIT

# ── Convergence engine ────────────────────────────────────────────────────────

# _ensure_dashboard
# Always bring dashboard up first (if not already running) so the user can
# watch convergence progress in the browser. Runs before plan/execute phases.
_ensure_dashboard() {
  local dashboard_script="$REPO_DIR/scripts/components/dashboard/dashboard.sh"

  # Already running? Nothing to do.
  if docker ps -qf "label=com.docker.compose.service=dashboard" 2>/dev/null | grep -q .; then
    info "Dashboard already running"
    return 0
  fi

  step "Dashboard (early launch)"
  if bash "$dashboard_script"; then
    ok "Dashboard is up — install progress visible at http://127.0.0.1"
    # Pop browser so user can watch convergence
    if command -v firefox &>/dev/null; then
      firefox "http://127.0.0.1" &>/dev/null &
      disown
    elif command -v xdg-open &>/dev/null; then
      xdg-open "http://127.0.0.1" &>/dev/null &
      disown
    fi
  else
    warn "Dashboard failed to start — convergence will continue without live progress"
  fi
}

# run_convergence
# Main convergence loop.
run_convergence() {
  step "Loading configuration"

  # Regenerate .env from stack.json so docker-compose has current values
  local apply_script="$REPO_DIR/config/wizard/apply_config.sh"
  if [[ -f "$apply_script" && -x "$apply_script" ]]; then
    bash "$apply_script" 2>&1 | tee -a "$LOG_FILE"
  fi

  load_env

  # Dashboard goes up first — gives the user a live progress view
  _ensure_dashboard
  
  info "Reading desired state from stack.json..."
  if ! desired_state_load; then
    fail "Failed to parse stack.json"
    return 1
  fi
  
  # Load last applied state for incremental convergence
  local first_run=false
  if [[ "$FORCE" == "true" ]]; then
    info "Force mode — ignoring .last-applied.json"
  elif last_applied_state_load "$LAST_APPLIED_FILE"; then
    info "Loaded last applied state from .last-applied.json"
  else
    info "No .last-applied.json found — full convergence"
    first_run=true
  fi
  
  info "Probing actual state..."
  actual_state_load
  
  step "Planning convergence"
  converge_plan
  
  # Print plan summary
  if [[ "$MODE" == "dry-run" ]]; then
    echo ""
    plan_print_table
    echo ""
    plan_summary
    echo ""
    info "Dry run — no changes made."
    return 0
  fi
  
  # Check if any changes needed
  if ! plan_has_changes; then
    echo ""
    ok "All components in desired state — no changes needed."
    _write_last_applied
    return 0
  fi
  
  # Print plan
  echo ""
  plan_print_table
  echo ""
  
  # Interactive mode: confirm before proceeding
  if [[ "$MODE" == "interactive" ]]; then
    echo ""
    if ! prompt_yesno "Converge Stack" "Proceed with convergence?\n\nAll planned changes are shown above."; then
      info "Convergence cancelled."
      return 0
    fi
    echo ""
  fi
  
  # Initialize install status for dashboard progress
  _init_install_status

  # Mark convergence as started — EXIT trap will print report if we die early
  _CONVERGE_STARTED=true

  # Execute plan: stops first (in reverse order), then starts
  step "Executing convergence plan"
  
  # Phase 1: Stop components that should be disabled (reverse order)
  _execute_stops
  
  # Phase 2: Start/install components that should be enabled (forward order)
  _execute_starts
  
  # Phase 3: Health checks for running components
  _execute_health_checks
  
  # Write snapshot on success
  if [[ $FAILED_COUNT -eq 0 ]]; then
    _write_last_applied
    install_status_complete
  else
    install_status_error
  fi
  _INSTALL_STATUS_FINALIZED=true
  
  # Print reconciliation report
  _REPORT_PRINTED=true
  _print_report
  
  return $FAILED_COUNT
}

# _init_install_status
# Initialize the install status JSON for dashboard progress.
# Includes ALL enabled services so the dashboard can show the full picture:
#   - start/install/restart → seeded as "pending"
#   - health (already running) → seeded as "running"
# Services with no-op or stop actions are excluded (not selected).
_init_install_status() {
  local svcs=()
  local already_running=()
  local i
  for i in "${!PLAN_COMPONENT[@]}"; do
    local action="${PLAN_ACTION[$i]}"
    case "$action" in
      start|install|restart)
        svcs+=("${PLAN_COMPONENT[$i]}")
        ;;
      health)
        already_running+=("${PLAN_COMPONENT[$i]}")
        ;;
    esac
  done
  
  # Combine both lists for init (all start as "pending")
  local all_svcs=("${svcs[@]}" "${already_running[@]}")
  
  if [[ ${#all_svcs[@]} -gt 0 ]]; then
    install_status_init "${all_svcs[@]}"

    # Pre-seed already-running services as "running"
    for svc in "${already_running[@]}"; do
      install_status_set "$svc" "running"
    done

    # Probe remaining services — if already healthy, mark "running"
    for svc in "${svcs[@]}"; do
      local url="${COMPONENT_HEALTH_URL[$svc]:-}"
      if [[ -n "$url" ]] && curl -sf --max-time 3 "$url" >/dev/null 2>&1; then
        install_status_set "$svc" "running"
      fi
    done
  fi
}

# _execute_stops
# Execute stop actions in reverse component order.
# In interactive mode, shows a pre-flight checklist — user deselects to skip.
_execute_stops() {
  local components_to_stop
  mapfile -t components_to_stop < <(plan_components_to_stop)

  if [[ ${#components_to_stop[@]} -eq 0 ]]; then
    return 0
  fi

  # Reverse the array for stop order
  local reversed=()
  local i
  for ((i=${#components_to_stop[@]}-1; i>=0; i--)); do
    reversed+=("${components_to_stop[$i]}")
  done

  # Interactive: pre-flight checklist — all ticked by default, user unticks to skip
  if [[ "$MODE" == "interactive" ]]; then
    local items=()
    for component in "${reversed[@]}"; do
      local dn
      dn=$(component_display_name "$component")
      items+=("${component}|Stop: ${dn}|on")
    done

    local selected=()
    if ! prompt_checklist "Stop Components" "All checked will be stopped.\nUncheck to skip." items selected; then
      info "Stop phase cancelled — skipping all stops."
      for component in "${reversed[@]}"; do
        RESULT_STATUS[$component]="skipped"
      done
      return 0
    fi

    # Mark unchecked components as skipped
    for component in "${reversed[@]}"; do
      local found=false
      for sel in "${selected[@]}"; do
        [[ "$sel" == "$component" ]] && found=true && break
      done
      if [[ "$found" == "false" ]]; then
        local dn
        dn=$(component_display_name "$component")
        info "Skipped stopping ${dn}"
        RESULT_STATUS[$component]="skipped"
      fi
    done

    # Execute only selected
    for component in "${selected[@]}"; do
      _execute_stop "$component"
    done
  else
    info "Stopping ${#reversed[@]} component(s)..."
    for component in "${reversed[@]}"; do
      _execute_stop "$component"
    done
  fi
}

# _execute_stop <component>
# Stop a single component (no interactive prompt — handled by _execute_stops).
_execute_stop() {
  local component="$1"
  local display_name
  display_name=$(component_display_name "$component")

  info "Stopping ${display_name}..."

  local rc=0
  _stop_component "$component" || rc=$?
  if [[ $rc -eq 0 ]]; then
    ok "${display_name} stopped"
    RESULT_STATUS[$component]="success"
  else
    warn "${display_name} stop failed"
    RESULT_STATUS[$component]="failed"
    RESULT_MESSAGE[$component]="Stop command failed"
    FAILED_COUNT=$((FAILED_COUNT + 1))
  fi
}

# _execute_tier_gate <below_order> <started_components_array_name>
# Health-check all successfully started components with order < below_order.
# Warns if any are unhealthy but does not abort — dependent services may still start.
_execute_tier_gate() {
  local below="$1"
  local -n _gate_components="$2"

  local to_check=()
  for c in "${_gate_components[@]}"; do
    local ord="${COMPONENT_NUMERIC_ORDER[$c]:-999}"
    [[ $ord -lt $below ]] || continue
    [[ "${RESULT_STATUS[$c]:-}" == "success" ]] || continue
    [[ -n "${COMPONENT_HEALTH_URL[$c]:-}" ]] || continue
    to_check+=("$c")
  done

  [[ ${#to_check[@]} -eq 0 ]] && return 0

  step "── Tier gate (order < ${below}): validating ${#to_check[@]} service(s) before next tier ──"
  local failed=0
  for c in "${to_check[@]}"; do
    local rc=0
    _health_check_component "$c" || rc=$?
    if [[ $rc -ne 0 ]]; then
      warn "  ✗ $(component_display_name "$c") not healthy"
      failed=$((failed + 1))
    else
      ok "  ✓ $(component_display_name "$c") healthy"
    fi
  done
  [[ $failed -gt 0 ]] \
    && warn "Tier gate: ${failed} unhealthy service(s) — next tier services may fail" \
    || ok "Tier gate passed"
}

# _execute_starts
# Execute start/install actions in component order.
# Tier gates run between order tiers to validate core services before dependents.
# In interactive mode, shows a pre-flight checklist — user deselects to skip.
_execute_starts() {
  # Collect components that need starting
  local start_components=()
  local start_actions=()
  local i
  for i in "${!PLAN_COMPONENT[@]}"; do
    local component="${PLAN_COMPONENT[$i]}"
    local action="${PLAN_ACTION[$i]}"
    case "$action" in
      install|start|restart)
        start_components+=("$component")
        start_actions+=("$action")
        ;;
    esac
  done

  if [[ ${#start_components[@]} -eq 0 ]]; then
    return 0
  fi

  # Load tier gate thresholds from config/tiers.json (gate_at fields, sorted).
  # Falls back to hardcoded (50 100) if file is missing or unreadable.
  local -a _TIER_GATES=()
  local _tiers_json="$REPO_DIR/config/tiers.json"
  if [[ -f "$_tiers_json" ]]; then
    local _gates
    _gates=$(python3 - "$_tiers_json" <<'PYEOF' 2>/dev/null
import json, sys
try:
    tiers = json.load(open(sys.argv[1])).get("tiers", [])
    gates = sorted(t["gate_at"] for t in tiers if "gate_at" in t)
    print(" ".join(str(g) for g in gates))
except Exception:
    pass
PYEOF
    ) || true
    [[ -n "$_gates" ]] && read -ra _TIER_GATES <<< "$_gates"
  fi
  [[ ${#_TIER_GATES[@]} -eq 0 ]] && _TIER_GATES=(50 100)

  # Interactive: pre-flight checklist
  if [[ "$MODE" == "interactive" ]]; then
    local items=()
    for i in "${!start_components[@]}"; do
      local component="${start_components[$i]}"
      local action="${start_actions[$i]}"
      local dn verb
      dn=$(component_display_name "$component")
      verb="Start"; [[ "$action" == "install" ]] && verb="Install"; [[ "$action" == "restart" ]] && verb="Restart"
      items+=("${component}|${verb}: ${dn}|on")
    done

    local selected=()
    if ! prompt_checklist "Start Components" "All checked will be started.\nUncheck to skip." items selected; then
      info "Start phase cancelled — skipping all starts."
      for component in "${start_components[@]}"; do
        RESULT_STATUS[$component]="skipped"
      done
      return 0
    fi

    # Mark unchecked as skipped
    for component in "${start_components[@]}"; do
      local found=false
      for sel in "${selected[@]}"; do
        [[ "$sel" == "$component" ]] && found=true && break
      done
      if [[ "$found" == "false" ]]; then
        local dn
        dn=$(component_display_name "$component")
        info "Skipped ${dn}"
        RESULT_STATUS[$component]="skipped"
      fi
    done

    # Execute selected (preserve action lookup)
    local _started_interactive=()
    local _gate_idx_i=0
    for i in "${!start_components[@]}"; do
      local component="${start_components[$i]}"
      local found=false
      for sel in "${selected[@]}"; do
        [[ "$sel" == "$component" ]] && found=true && break
      done
      if [[ "$found" == "true" ]]; then
        local _ord="${COMPONENT_NUMERIC_ORDER[$component]:-999}"
        while [[ $_gate_idx_i -lt ${#_TIER_GATES[@]} ]] && [[ $_ord -ge ${_TIER_GATES[$_gate_idx_i]} ]]; do
          _execute_tier_gate "${_TIER_GATES[$_gate_idx_i]}" _started_interactive
          _gate_idx_i=$((_gate_idx_i + 1))
        done
        _execute_start "$component" "${start_actions[$i]}"
        _started_interactive+=("$component")
      fi
    done
  else
    local _started=()
    local _gate_idx=0
    for i in "${!start_components[@]}"; do
      local component="${start_components[$i]}"
      local _ord="${COMPONENT_NUMERIC_ORDER[$component]:-999}"
      while [[ $_gate_idx -lt ${#_TIER_GATES[@]} ]] && [[ $_ord -ge ${_TIER_GATES[$_gate_idx]} ]]; do
        _execute_tier_gate "${_TIER_GATES[$_gate_idx]}" _started
        _gate_idx=$((_gate_idx + 1))
      done
      _execute_start "$component" "${start_actions[$i]}"
      _started+=("$component")
    done
  fi
}

# _execute_start <component> <action>
# Start, install, or restart a single component (no interactive prompt — handled by _execute_starts).
_execute_start() {
  local component="$1"
  local action="$2"
  local display_name
  display_name=$(component_display_name "$component")

  # Skip host-interactive services — require manual user steps
  local install_type="${COMPONENT_INSTALL_TYPE[$component]:-}"
  if [[ "$install_type" == "host-interactive" ]]; then
    info "${display_name}: host-interactive install — skipping automated deployment"
    local script="${COMPONENT_SCRIPT[$component]:-}"
    [[ -n "$script" ]] && info "  Run manually: $REPO_DIR/$script"
    RESULT_STATUS[$component]="skipped"
    RESULT_MESSAGE[$component]="host-interactive: requires manual steps"
    install_status_set "$component" "skipped"
    install_status_msg "$component" "Manual install required"
    return 0
  fi

  install_status_set "$component" "installing"
  install_status_msg "$component" "Starting..."

  info "Starting ${display_name}..."

  local rc=0
  case "$action" in
    install)
      _install_component "$component" || rc=$?
      ;;
    start|restart)
      if [[ "$action" == "restart" ]]; then
        _stop_component "$component" 2>/dev/null || true
      fi
      _start_component "$component" || rc=$?
      ;;
  esac
  local success=false
  [[ $rc -eq 0 ]] && success=true

  if [[ "$success" == "true" ]]; then
    ok "${display_name} started"
    RESULT_STATUS[$component]="success"
    install_status_set "$component" "running"
    install_status_msg "$component" ""
  else
    warn "${display_name} failed to start"
    RESULT_STATUS[$component]="failed"
    RESULT_MESSAGE[$component]="Start command failed"
    install_status_set "$component" "error"
    install_status_msg "$component" "Failed"
    FAILED_COUNT=$((FAILED_COUNT + 1))
  fi
}

# _execute_health_checks
# Run health checks for components that are already running.
_execute_health_checks() {
  local components_to_check
  mapfile -t components_to_check < <(plan_components_to_health_check)
  
  if [[ ${#components_to_check[@]} -eq 0 ]]; then
    return 0
  fi
  
  info "Running ${#components_to_check[@]} health check(s)..."
  
  for component in "${components_to_check[@]}"; do
    local display_name
    display_name=$(component_display_name "$component")
    
    local rc=0
    _health_check_component "$component" || rc=$?
    if [[ $rc -eq 0 ]]; then
      RESULT_STATUS[$component]="success"
    else
      warn "${display_name} health check failed"
      RESULT_STATUS[$component]="failed"
      RESULT_MESSAGE[$component]="Health check failed"
      FAILED_COUNT=$((FAILED_COUNT + 1))
    fi
  done
}

# ── Component lifecycle dispatch ──────────────────────────────────────────────

# _start_component <component>
# Dispatch to the component's start function or script.
_start_component() {
  local component="$1"
  local script="${COMPONENT_SCRIPT[$component]:-}"
  local func_prefix="${COMPONENT_FUNC_PREFIX[$component]:-}"
  local profile="${COMPONENT_PROFILE[$component]:-}"
  
  # Components with dedicated scripts
  if [[ -n "$script" && -f "$REPO_DIR/$script" ]]; then
    bash "$REPO_DIR/$script" --start 2>&1 | tee -a "$LOG_FILE"
    return "${PIPESTATUS[0]}"
  elif [[ -n "$func_prefix" ]]; then
    # Try to source and call the function
    if [[ -f "$REPO_DIR/$script" ]]; then
      source "$REPO_DIR/$script"
      "${func_prefix}_start" 2>&1 | tee -a "$LOG_FILE"
      return "${PIPESTATUS[0]}"
    fi
  fi
  
  warn "No start handler for component: $component"
  return 1
}

# _stop_component <component>
# Dispatch to the component's stop function or script.
_stop_component() {
  local component="$1"
  local script="${COMPONENT_SCRIPT[$component]:-}"
  local func_prefix="${COMPONENT_FUNC_PREFIX[$component]:-}"
  local profile="${COMPONENT_PROFILE[$component]:-}"
  
  # Components with dedicated scripts
  if [[ -n "$script" && -f "$REPO_DIR/$script" ]]; then
    bash "$REPO_DIR/$script" --stop 2>&1 | tee -a "$LOG_FILE"
    return "${PIPESTATUS[0]}"
  fi
  
  # Fallback: try compose_down with profile
  if [[ -n "$profile" ]]; then
    compose_down --profile "$profile"
    return $?
  fi
  
  warn "No stop handler for component: $component"
  return 1
}

# _install_component <component>
# Dispatch to the component's full install (install + configure + start).
_install_component() {
  local component="$1"
  local script="${COMPONENT_SCRIPT[$component]:-}"
  
  # Components with dedicated scripts: run without flags (full install)
  if [[ -n "$script" && -f "$REPO_DIR/$script" ]]; then
    bash "$REPO_DIR/$script" 2>&1 | tee -a "$LOG_FILE"
    return "${PIPESTATUS[0]}"
  fi
  
  # Fallback to start
  _start_component "$component"
}

# _health_check_component <component>
# Run the component's health check with a component-specific timeout.
_health_check_component() {
  local component="$1"
  local script="${COMPONENT_SCRIPT[$component]:-}"
  local health_url="${COMPONENT_HEALTH_URL[$component]:-}"
  local timeout="${COMPONENT_HEALTH_TIMEOUT[$component]:-120}"

  # Try dedicated health script/function first
  if [[ -n "$script" && -f "$REPO_DIR/$script" ]]; then
    bash "$REPO_DIR/$script" --health 2>&1 | tee -a "$LOG_FILE"
    return "${PIPESTATUS[0]}"
  fi

  # Fallback to URL probe with component-specific timeout (sleep interval = 2s)
  if [[ -n "$health_url" ]]; then
    local max_attempts=$(( timeout / 2 ))
    health_probe "$(component_display_name "$component")" "$health_url" "$max_attempts" 2
    return $?
  fi

  # No health check available — assume healthy
  return 0
}

# ── Snapshot management ───────────────────────────────────────────────────────

# _write_last_applied
# Copy stack.json to .last-applied.json after successful convergence.
_write_last_applied() {
  local config_file="${REPO_DIR}/config/stack.json"
  if [[ -f "$config_file" ]]; then
    cp "$config_file" "$LAST_APPLIED_FILE"
    info "Snapshot written: .last-applied.json"
  fi
}

# ── Reconciliation report ─────────────────────────────────────────────────────

# _print_report
# Print the final reconciliation report.
_print_report() {
  echo ""
  step "Reconciliation Report"
  echo ""
  
  # Table header
  printf "%-20s %-12s %-12s %-10s %s\n" "Component" "Was" "Now" "Action" "Result"
  printf "%-20s %-12s %-12s %-10s %s\n" "─────────────────" "──────────" "──────────" "────────" "────────────"
  
  local i component action was now result display_name
  for i in "${!PLAN_COMPONENT[@]}"; do
    component="${PLAN_COMPONENT[$i]}"
    action="${PLAN_ACTION[$i]}"
    
    # Skip no-ops in report
    [[ "$action" == "no-op" ]] && continue
    
    display_name=$(component_display_name "$component")
    was="${ACTUAL[$component]:-unknown}"
    result="${RESULT_STATUS[$component]:-pending}"
    
    # Determine "now" state
    case "$action" in
      start|install|restart)
        now="running"
        [[ "$result" == "failed" ]] && now="stopped"
        [[ "$result" == "skipped" ]] && now="$was"
        ;;
      stop)
        now="stopped"
        [[ "$result" == "failed" ]] && now="$was"
        [[ "$result" == "skipped" ]] && now="$was"
        ;;
      health)
        now="$was"
        ;;
      *)
        now="$was"
        ;;
    esac
    
    # Color-code result
    local result_color
    case "$result" in
      success) result_color="${GREEN}${result}${NC}" ;;
      failed)  result_color="${RED}${result}${NC}" ;;
      skipped) result_color="${YELLOW}${result}${NC}" ;;
      *)       result_color="$result" ;;
    esac
    
    printf "%-20s %-12s %-12s %-10s %b\n" "$display_name" "$was" "$now" "$action" "$result_color"
    
    # Print error message if failed
    if [[ "$result" == "failed" && -n "${RESULT_MESSAGE[$component]:-}" ]]; then
      printf "  %b└─ %s%b\n" "${RED}" "${RESULT_MESSAGE[$component]}" "${NC}"
    fi
  done
  
  echo ""
  
  # Summary
  local success_count=0 fail_count=0 skip_count=0
  for component in "${!RESULT_STATUS[@]}"; do
    case "${RESULT_STATUS[$component]}" in
      success) ((success_count++)) ;;
      failed)  ((fail_count++)) ;;
      skipped) ((skip_count++)) ;;
    esac
  done
  
  if [[ $fail_count -eq 0 ]]; then
    ok "Convergence complete: ${success_count} succeeded, ${skip_count} skipped"
  else
    warn "Convergence finished with errors: ${success_count} succeeded, ${fail_count} failed, ${skip_count} skipped"
    echo ""
    info "Log file: $LOG_FILE"
  fi

  # Regenerate dashboard service registry from manifests
  if command -v python3 &>/dev/null; then
    info "Generating dashboard services.json..."
    bash "$REPO_DIR/scripts/utils/generate-services-json.sh" 2>/dev/null \
      && ok "Dashboard services.json updated" \
      || warn "Failed to generate services.json (non-fatal)"
  fi
}

# ── Main ──────────────────────────────────────────────────────────────────────

banner "Stack Convergence"

echo ""
info "Mode: ${CYAN}${MODE}${NC}"
[[ "$FORCE" == "true" ]] && info "Force: ${YELLOW}enabled${NC}"
echo ""

run_convergence
exit $?
