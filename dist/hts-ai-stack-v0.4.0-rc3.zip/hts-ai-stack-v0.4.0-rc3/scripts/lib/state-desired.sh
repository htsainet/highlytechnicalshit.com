#!/usr/bin/env bash
# scripts/lib/state-desired.sh — Parse stack.json into desired state
# Source this file; do NOT run directly.
#
# Parses config/stack.json and populates the DESIRED associative array
# with enabled/disabled state for each component.
#
# Used by: converge.sh (FEATURE-009)
# Requires: common.sh, component-registry.sh sourced first

# ── Desired state array ───────────────────────────────────────────────────────
# Populated by desired_state_load()
# Keys: component IDs from COMPONENT_ORDER
# Values: "enabled" | "disabled"
declare -gA DESIRED

# ── Internal: Parse stack.json value ──────────────────────────────────────────

# _jq_get <json_path>
# Extracts a value from stack.json using jq.
# Returns empty string if path doesn't exist.
_jq_get() {
  local path="$1"
  local config_file="${REPO_DIR}/config/stack.json"
  if [[ ! -f "$config_file" ]]; then
    return 1
  fi
  jq -r "$path // empty" "$config_file" 2>/dev/null || true
}

# _jq_array_contains <json_path> <value>
# Returns 0 if the array at json_path contains value, 1 otherwise.
_jq_array_contains() {
  local path="$1"
  local value="$2"
  local config_file="${REPO_DIR}/config/stack.json"
  if [[ ! -f "$config_file" ]]; then
    return 1
  fi
  jq -e "$path | if type == \"array\" then contains([\"$value\"]) else false end" "$config_file" >/dev/null 2>&1
}

# ── Desired state loader ──────────────────────────────────────────────────────

# desired_state_load
# Parses stack.json and populates the DESIRED array.
# Handles compound config keys (backend, sandbox.engine, arrays).
desired_state_load() {
  local config_file="${REPO_DIR}/config/stack.json"
  
  if [[ ! -f "$config_file" ]]; then
    warn "stack.json not found: $config_file"
    return 1
  fi

  # Pre-fetch commonly used values to avoid repeated jq calls
  local backend sandbox_engine images_engine
  backend=$(_jq_get '.backend')
  sandbox_engine=$(_jq_get '.sandbox.engine')
  images_engine=$(_jq_get '.images.engine')

  local component config_key
  for component in "${COMPONENT_ORDER[@]}"; do
    config_key="${COMPONENT_CONFIG_KEY[$component]:-}"
    
    if [[ -z "$config_key" ]]; then
      # No config key defined — default to disabled
      DESIRED[$component]="disabled"
      continue
    fi

    # Handle special config key patterns
    case "$config_key" in
      always)
        # Always enabled (e.g., open-webui)
        DESIRED[$component]="enabled"
        ;;
        
      backend:*)
        # Enabled if backend matches one of the values
        local values="${config_key#backend:}"
        if _check_value_in_list "$backend" "$values"; then
          DESIRED[$component]="enabled"
        else
          DESIRED[$component]="disabled"
        fi
        ;;
        
      sandbox.engine:*)
        # Enabled if sandbox.engine matches one of the values
        local values="${config_key#sandbox.engine:}"
        if _check_value_in_list "$sandbox_engine" "$values"; then
          DESIRED[$component]="enabled"
        else
          DESIRED[$component]="disabled"
        fi
        ;;
        
      images.engine:*)
        # Enabled if images.engine matches one of the values
        local values="${config_key#images.engine:}"
        if _check_value_in_list "$images_engine" "$values"; then
          DESIRED[$component]="enabled"
        else
          DESIRED[$component]="disabled"
        fi
        ;;
        
      extras.components:*)
        # Enabled if extras.components array contains the value
        local value="${config_key#extras.components:}"
        if _jq_array_contains '.extras.components' "$value"; then
          DESIRED[$component]="enabled"
        else
          DESIRED[$component]="disabled"
        fi
        ;;
        
      admin.tools:*)
        # Enabled if admin.tools array contains the value
        local value="${config_key#admin.tools:}"
        if _jq_array_contains '.admin.tools' "$value"; then
          DESIRED[$component]="enabled"
        else
          DESIRED[$component]="disabled"
        fi
        ;;
        
      comms.*.enabled)
        # Direct boolean path under comms (e.g., comms.telegram.enabled)
        local enabled
        enabled=$(_jq_get ".$config_key")
        if [[ "$enabled" == "true" ]]; then
          DESIRED[$component]="enabled"
        else
          DESIRED[$component]="disabled"
        fi
        ;;
        
      *)
        # Standard boolean path (e.g., dashboard.enabled, monitoring.enabled)
        local enabled
        enabled=$(_jq_get ".$config_key")
        if [[ "$enabled" == "true" ]]; then
          DESIRED[$component]="enabled"
        else
          DESIRED[$component]="disabled"
        fi
        ;;
    esac
  done
}

# _check_value_in_list <value> <comma_separated_list>
# Returns 0 if value is in the list, 1 otherwise.
_check_value_in_list() {
  local value="$1"
  local list="$2"
  local IFS=','
  local item
  for item in $list; do
    if [[ "$value" == "$item" ]]; then
      return 0
    fi
  done
  return 1
}

# ── Debug output ──────────────────────────────────────────────────────────────

# desired_state_dump
# Prints the current DESIRED state for debugging.
desired_state_dump() {
  local component
  echo "Desired state:"
  for component in "${COMPONENT_ORDER[@]}"; do
    printf "  %-20s %s\n" "$component" "${DESIRED[$component]:-unknown}"
  done
}

# desired_state_enabled_list
# Prints components that are desired to be enabled.
desired_state_enabled_list() {
  local component
  for component in "${COMPONENT_ORDER[@]}"; do
    if [[ "${DESIRED[$component]:-}" == "enabled" ]]; then
      echo "$component"
    fi
  done
}

# desired_state_disabled_list
# Prints components that are desired to be disabled.
desired_state_disabled_list() {
  local component
  for component in "${COMPONENT_ORDER[@]}"; do
    if [[ "${DESIRED[$component]:-}" == "disabled" ]]; then
      echo "$component"
    fi
  done
}

# ── Last applied state ────────────────────────────────────────────────────────
# For incremental convergence (Phase 7)

# Last applied state array
# Populated by last_applied_state_load()
declare -gA LAST_APPLIED

# last_applied_state_load [file_path]
# Loads the last applied state from .last-applied.json.
# Returns 1 if file doesn't exist (first run).
last_applied_state_load() {
  local last_applied_file="${1:-${REPO_DIR}/.last-applied.json}"
  
  if [[ ! -f "$last_applied_file" ]]; then
    # First run — no previous state
    return 1
  fi
  
  # Pre-fetch commonly used values
  local backend sandbox_engine images_engine
  backend=$(jq -r '.backend // empty' "$last_applied_file" 2>/dev/null || true)
  sandbox_engine=$(jq -r '.sandbox.engine // empty' "$last_applied_file" 2>/dev/null || true)
  images_engine=$(jq -r '.images.engine // empty' "$last_applied_file" 2>/dev/null || true)
  
  local component config_key
  for component in "${COMPONENT_ORDER[@]}"; do
    config_key="${COMPONENT_CONFIG_KEY[$component]:-}"
    
    if [[ -z "$config_key" ]]; then
      LAST_APPLIED[$component]="disabled"
      continue
    fi
    
    # Handle special config key patterns (same logic as desired_state_load)
    case "$config_key" in
      always)
        LAST_APPLIED[$component]="enabled"
        ;;
      backend:*)
        local values="${config_key#backend:}"
        if _check_value_in_list "$backend" "$values"; then
          LAST_APPLIED[$component]="enabled"
        else
          LAST_APPLIED[$component]="disabled"
        fi
        ;;
      sandbox.engine:*)
        local values="${config_key#sandbox.engine:}"
        if _check_value_in_list "$sandbox_engine" "$values"; then
          LAST_APPLIED[$component]="enabled"
        else
          LAST_APPLIED[$component]="disabled"
        fi
        ;;
      images.engine:*)
        local values="${config_key#images.engine:}"
        if _check_value_in_list "$images_engine" "$values"; then
          LAST_APPLIED[$component]="enabled"
        else
          LAST_APPLIED[$component]="disabled"
        fi
        ;;
      extras.components:*)
        local value="${config_key#extras.components:}"
        if jq -e ".extras.components | if type == \"array\" then contains([\"$value\"]) else false end" "$last_applied_file" >/dev/null 2>&1; then
          LAST_APPLIED[$component]="enabled"
        else
          LAST_APPLIED[$component]="disabled"
        fi
        ;;
      admin.tools:*)
        local value="${config_key#admin.tools:}"
        if jq -e ".admin.tools | if type == \"array\" then contains([\"$value\"]) else false end" "$last_applied_file" >/dev/null 2>&1; then
          LAST_APPLIED[$component]="enabled"
        else
          LAST_APPLIED[$component]="disabled"
        fi
        ;;
      comms.*.enabled)
        local enabled
        enabled=$(jq -r ".$config_key // empty" "$last_applied_file" 2>/dev/null || true)
        if [[ "$enabled" == "true" ]]; then
          LAST_APPLIED[$component]="enabled"
        else
          LAST_APPLIED[$component]="disabled"
        fi
        ;;
      *)
        local enabled
        enabled=$(jq -r ".$config_key // empty" "$last_applied_file" 2>/dev/null || true)
        if [[ "$enabled" == "true" ]]; then
          LAST_APPLIED[$component]="enabled"
        else
          LAST_APPLIED[$component]="disabled"
        fi
        ;;
    esac
  done
  
  return 0
}

# last_applied_state_dump
# Prints the last applied state for debugging.
last_applied_state_dump() {
  local component
  echo "Last applied state:"
  for component in "${COMPONENT_ORDER[@]}"; do
    printf "  %-20s %s\n" "$component" "${LAST_APPLIED[$component]:-unknown}"
  done
}

# config_changed <component>
# Returns 0 if the component's config changed since last apply, 1 otherwise.
# This is a simple enabled/disabled comparison for now.
config_changed() {
  local component="$1"
  local desired="${DESIRED[$component]:-disabled}"
  local last="${LAST_APPLIED[$component]:-}"
  
  # No last applied state — treat as changed
  [[ -z "$last" ]] && return 0
  
  # Compare enabled/disabled
  [[ "$desired" != "$last" ]]
}
