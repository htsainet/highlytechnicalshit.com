# Timeshift Component

Last updated: 2026-04-15

## What happens here

Timeshift creates incremental snapshots of the host system using rsync
or btrfs. Used in the stack for system-level rollback — lets you restore
the host to a known-good state if an install or upgrade breaks something.

## Files and structure

| File | Purpose |
|------|---------|
| `timeshift.sh` | Full lifecycle: install, configure, start, stop, health |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
