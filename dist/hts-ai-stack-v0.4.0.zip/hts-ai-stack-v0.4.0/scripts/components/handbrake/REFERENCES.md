# HandBrake References

Last updated: 2026-04-17

## Upstream

- [HandBrake](https://handbrake.fr/)
- [HandBrake Documentation](https://handbrake.fr/docs/)
- [GitHub — HandBrake/HandBrake](https://github.com/HandBrake/HandBrake)

## Packages

- `handbrake` — GUI application
- `handbrake-cli` — Command-line interface (`HandBrakeCLI`)
