#!/usr/bin/env bash
# scripts/bundles/deerflow.sh — DeerFlow agent harness bundle
#
# Chat bundle + Gitea + NemoClaw + DeerFlow (alternative agent harness).
#
# Usage:
#   ./scripts/bundles/deerflow.sh
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "DeerFlow Bundle"
load_env

DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-true}"

# ── Chat layer (dual-backend + llama-swap) ─────────────────────────────────────
step "Backend + Chat"
bash "$REPO_DIR/scripts/components/ollama/ollama.sh"
bash "$REPO_DIR/scripts/components/bitnet/bitnet.sh"
bash "$REPO_DIR/scripts/components/llama-swap/llama-swap.sh"
bash "$REPO_DIR/scripts/components/open-webui/open-webui.sh"

# ── Agent services ────────────────────────────────────────────────────────────
step "Agent services"
bash "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh"
bash "$REPO_DIR/scripts/components/deerflow/deerflow.sh"

if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/components/dashboard/dashboard.sh"
fi

echo ""
ok "DeerFlow bundle ready — dual-backend (GPU+CPU)"
