#!/usr/bin/env bash
# scripts/components/ghostwriter/ghostwriter.sh — Ghostwriter Markdown editor
#
# Host-native installer for Ghostwriter, the KDE distraction-free Markdown
# editor with live preview, focus mode, and Hemingway mode.
# Installs from the Ubuntu repositories. Requires a desktop session for use.
#
# Standalone usage:
#   ./scripts/components/ghostwriter/ghostwriter.sh              # full: install + configure + health
#   ./scripts/components/ghostwriter/ghostwriter.sh --install    # install only
#   ./scripts/components/ghostwriter/ghostwriter.sh --configure  # configure only
#   ./scripts/components/ghostwriter/ghostwriter.sh --start      # no-op (desktop app)
#   ./scripts/components/ghostwriter/ghostwriter.sh --stop       # no-op (desktop app)
#   ./scripts/components/ghostwriter/ghostwriter.sh --restart    # no-op (desktop app)
#   ./scripts/components/ghostwriter/ghostwriter.sh --health     # health check only
#   ./scripts/components/ghostwriter/ghostwriter.sh --status     # show status + health
#   ./scripts/components/ghostwriter/ghostwriter.sh --destroy    # uninstall Ghostwriter
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# ── Functions ────────────────────────────────────────────────────────────────

ghostwriter_install() {
  step "Ghostwriter — install"

  if command -v ghostwriter &>/dev/null; then
    local ver
    ver=$(ghostwriter --version 2>/dev/null | head -1 || echo "version unknown")
    skip "Ghostwriter already installed (${ver})"
  else
    info "Installing Ghostwriter..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq ghostwriter
    ok "Ghostwriter installed."
  fi
}

ghostwriter_configure() {
  step "Ghostwriter — configure"
  info "Launch Ghostwriter from the desktop to complete first-run configuration."
  ok "Ghostwriter configured."
}

ghostwriter_start() {
  step "Ghostwriter — start"
  info "Desktop application — launch from your desktop environment."
  if [[ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]]; then
    info "Desktop session detected. You can launch Ghostwriter from the applications menu."
  else
    warn "No desktop session detected — Ghostwriter requires a GUI to run."
  fi
  ok "Ghostwriter start complete."
}

ghostwriter_stop() {
  step "Ghostwriter — stop"
  info "Desktop application — close from the GUI."
  ok "Ghostwriter stop complete."
}

ghostwriter_health() {
  local label="Ghostwriter"
  printf "  %-35s" "$label"
  if command -v ghostwriter &>/dev/null; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (ghostwriter not found in PATH)"
    return 1
  fi
}

ghostwriter_restart() {
  ghostwriter_stop
  ghostwriter_start
}

ghostwriter_destroy() {
  step "Ghostwriter — destroy"
  info "Removing Ghostwriter..."
  sudo apt-get remove -y ghostwriter 2>/dev/null || true
  sudo apt-get autoremove -y -qq
  ok "Ghostwriter removed."
}

ghostwriter_status() {
  step "Ghostwriter — status"
  if command -v ghostwriter &>/dev/null; then
    ok "Ghostwriter installed"
  else
    warn "Ghostwriter NOT installed"
  fi
  ghostwriter_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   ghostwriter_install   ;;
    configure) ghostwriter_configure ;;
    start)     ghostwriter_start     ;;
    stop)      ghostwriter_stop      ;;
    restart)   ghostwriter_restart   ;;
    health)    ghostwriter_health    ;;
    status)    ghostwriter_status    ;;
    destroy)   ghostwriter_destroy   ;;
    default)
      ghostwriter_install
      ghostwriter_configure
      ghostwriter_health
      ;;
  esac
fi
