# Vosk References

Last updated: 2026-04-15

## Upstream

- [GitHub — alphacep/vosk-api](https://github.com/alphacep/vosk-api)
- [GitHub — alphacep/vosk-server](https://github.com/alphacep/vosk-server)

## Official documentation

- [Vosk Documentation](https://alphacephei.com/vosk/)
- [Vosk Models](https://alphacephei.com/vosk/models)

## Related

- See [FEATURE-028](../../../docs/development/features/FEATURE-028.md)
  for the original feature proposal.
