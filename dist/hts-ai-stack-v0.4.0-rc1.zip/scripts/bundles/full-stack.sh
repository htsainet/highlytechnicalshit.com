#!/usr/bin/env bash
# scripts/bundles/full-stack.sh — Full install pipeline
#
# Sets up host dependencies, all core services, and optional services
# based on .env configuration. Equivalent to the original install pipeline.
#
# Usage:
#   ./scripts/bundles/full-stack.sh [--chat lean|mean|claw]
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/installstatus.sh"
trap '_install_status_on_error' ERR

banner "Full Stack Install"
load_env

# ── Sudo keep-alive (unattended install) ─────────────────────────────────────
_SUDO_KEEPALIVE=$(python3 -c "
import json, sys
try:
    d = json.load(open('$REPO_DIR/config/stack.json'))
    print('true' if d.get('admin',{}).get('sudo_keepalive') else 'false')
except Exception:
    print('false')
" 2>/dev/null || echo "false")

if [[ "$_SUDO_KEEPALIVE" == "true" ]]; then
  info "Sudo keep-alive enabled — requesting credentials once."
  sudo -v
  ( while true; do sudo -n true; sleep 50; kill -0 "$$" 2>/dev/null || exit; done ) &
  _SUDO_PID=$!
  trap 'kill $_SUDO_PID 2>/dev/null' EXIT
fi

CHAT_MODE="mean"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --chat) CHAT_MODE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

NAS_ENABLED="${NAS_ENABLED:-false}"
DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-false}"
TAILSCALE_ENABLED="${TAILSCALE_ENABLED:-false}"
TELEGRAM_ENABLED="${TELEGRAM_ENABLED:-false}"
SIGNAL_ENABLED="${SIGNAL_ENABLED:-false}"
NEMOCLAW_DEPLOY="${NEMOCLAW_DEPLOY:-false}"
DUPLICATI_ENABLED="${DUPLICATI_ENABLED:-false}"
MONITORING_ENABLED="${MONITORING_ENABLED:-false}"
PORTAINER_ENABLED="${PORTAINER_ENABLED:-false}"
OPENSPACE_ENABLED="${OPENSPACE_ENABLED:-false}"
DEERFLOW_ENABLED="${DEERFLOW_ENABLED:-false}"
GVISOR_SANDBOX_ENABLED="${GVISOR_SANDBOX_ENABLED:-false}"
HTSCLAW_DEPLOY="${HTSCLAW_DEPLOY:-false}"
LMSTUDIO_INSTALL="${LMSTUDIO_INSTALL:-false}"
UPSTREAM_WATCH_ENABLED="${UPSTREAM_WATCH_ENABLED:-false}"

# ── Deferred services (component installers kept in repo) ─────────────────────
# v0.5.0: SD_ENABLED, COMFYUI_ENABLED, voice services
# v0.6.0: GITEA_ENABLED, SILLYTAVERN_ENABLED

# ── Build install manifest for dashboard progress ────────────────────────────
_SVCS=()
[[ "$DASHBOARD_ENABLED"  == "true" ]] && _SVCS+=("dashboard")
[[ "$MONITORING_ENABLED" == "true" ]] && _SVCS+=("prometheus" "grafana")
[[ "$PORTAINER_ENABLED"  == "true" ]] && _SVCS+=("portainer")
_SVCS+=("ollama-gpu" "bitnet-cpu" "llama-swap" "open-webui")
[[ "$HTSCLAW_DEPLOY"     == "true" ]] && _SVCS+=("htsclaw-sandbox")
[[ "$NEMOCLAW_DEPLOY"    == "true" ]] && _SVCS+=("nemoclaw-gpu")
[[ "$OPENSPACE_ENABLED"  == "true" ]] && _SVCS+=("openspace")
[[ "$DEERFLOW_ENABLED"   == "true" ]] && _SVCS+=("deerflow")
[[ "$GVISOR_SANDBOX_ENABLED" == "true" ]] && _SVCS+=("gvisor-sandbox")
[[ "$LMSTUDIO_INSTALL"   == "true" ]] && _SVCS+=("lmstudio")
[[ "$DUPLICATI_ENABLED"  == "true" ]] && _SVCS+=("duplicati")
[[ "$TAILSCALE_ENABLED"  == "true" ]] && _SVCS+=("tailscale")

install_status_init "${_SVCS[@]}"

# ── Host setup ────────────────────────────────────────────────────────────────
step "Host dependencies"
bash "$REPO_DIR/scripts/host/nvidia.sh"
bash "$REPO_DIR/scripts/host/docker.sh"
bash "$REPO_DIR/scripts/host/node.sh"
bash "$REPO_DIR/scripts/host/tools.sh"

if [[ "$LMSTUDIO_INSTALL" == "true" ]]; then
  step "LM Studio (host install)"
  install_status_set "lmstudio" "installing"
  install_status_msg "lmstudio" "Installing LM Studio .deb…"
  bash "$REPO_DIR/scripts/install/tooling/install-lmstudio.sh" || true
  if dpkg -s lmstudio &>/dev/null 2>&1; then
    install_status_set "lmstudio" "running"
    install_status_msg "lmstudio" ""
  else
    install_status_set "lmstudio" "failed"
    install_status_msg "lmstudio" "deb install failed"
  fi
fi

if [[ "$NAS_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/host/nas.sh"
fi

# ── Dashboard (first — shows install progress in browser) ────────────────────
if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  step "Dashboard (early launch)"
  install_status_set "dashboard" "installing"
  install_status_msg "dashboard" "Starting nginx…"
  bash "$REPO_DIR/scripts/components/dashboard.sh"
  install_status_set "dashboard" "running"
  install_status_msg "dashboard" ""
  # Open browser so user can watch install progress
  if command -v firefox &>/dev/null; then
    firefox "http://127.0.0.1" &>/dev/null &
    disown
  elif command -v xdg-open &>/dev/null; then
    xdg-open "http://127.0.0.1" &>/dev/null &
    disown
  fi
fi

# ── Monitoring & management (early — captures full boot in metrics) ───────────
source "$REPO_DIR/scripts/lib/compose.sh"

if [[ "$MONITORING_ENABLED" == "true" ]]; then
  step "Monitoring"
  install_status_set "prometheus" "installing"
  install_status_set "grafana" "installing"
  install_status_msg "prometheus" "Starting Prometheus + Grafana…"
  compose_up --profile monitoring
  install_status_set "prometheus" "running"
  install_status_msg "prometheus" ""
  install_status_set "grafana" "running"
  install_status_msg "grafana" ""
  ok "Monitoring stack started (Prometheus + cAdvisor + Grafana)."
fi

if [[ "$PORTAINER_ENABLED" == "true" ]]; then
  step "Portainer"
  install_status_set "portainer" "installing"
  install_status_msg "portainer" "Starting Portainer…"
  compose_up --profile portainer
  install_status_set "portainer" "running"
  install_status_msg "portainer" ""
  ok "Portainer started on :9000 (HTTP) / :9443 (HTTPS)."
fi

# ── Core services (dual-backend + llama-swap) ────────────────────────────────
step "Core services"

install_status_set "ollama-gpu" "installing"
install_status_msg "ollama-gpu" "Building container…"
bash "$REPO_DIR/scripts/components/ollama.sh"

install_status_msg "ollama-gpu" "Loading model for ${CHAT_MODE} mode…"
bash "$REPO_DIR/scripts/components/ollama.sh" --swap "$CHAT_MODE"
install_status_set "ollama-gpu" "running"
install_status_msg "ollama-gpu" ""

install_status_set "bitnet-cpu" "installing"
install_status_msg "bitnet-cpu" "Building container…"
bash "$REPO_DIR/scripts/components/bitnet.sh"
install_status_set "bitnet-cpu" "running"
install_status_msg "bitnet-cpu" ""

install_status_set "llama-swap" "installing"
install_status_msg "llama-swap" "Starting router…"
bash "$REPO_DIR/scripts/components/llama-swap.sh"
install_status_set "llama-swap" "running"
install_status_msg "llama-swap" ""

install_status_set "open-webui" "installing"
install_status_msg "open-webui" "Building container…"
bash "$REPO_DIR/scripts/components/open-webui.sh"
install_status_set "open-webui" "running"
install_status_msg "open-webui" ""

# ── Optional services ─────────────────────────────────────────────────────────
step "Optional services"

if [[ "$HTSCLAW_DEPLOY" == "true" ]]; then
  install_status_set "htsclaw-sandbox" "installing"
  install_status_msg "htsclaw-sandbox" "Starting self-managed sandbox…"
  bash "$REPO_DIR/scripts/components/htsclaw.sh"
  install_status_set "htsclaw-sandbox" "running"
  install_status_msg "htsclaw-sandbox" ""
fi

if [[ "$NEMOCLAW_DEPLOY" == "true" ]]; then
  install_status_set "nemoclaw-gpu" "installing"
  install_status_msg "nemoclaw-gpu" "Starting agent sandbox…"
  bash "$REPO_DIR/scripts/components/nemoclaw.sh"
  install_status_set "nemoclaw-gpu" "running"
  install_status_msg "nemoclaw-gpu" ""
fi

if [[ "$UPSTREAM_WATCH_ENABLED" == "true" ]]; then
  step "Upstream issue watcher"
  WATCH_SCRIPT="$REPO_DIR/scripts/utils/upstream-watch.sh"
  WATCH_LOG="$REPO_DIR/logs/upstream-watch.log"
  CRON_ENTRY="0 8 * * * $WATCH_SCRIPT # hts-ai-stack upstream issue watcher"
  if crontab -l 2>/dev/null | grep -qF "upstream-watch.sh"; then
    ok "Upstream issue watcher cron already installed"
  else
    (crontab -l 2>/dev/null; echo "$CRON_ENTRY") | crontab -
    ok "Upstream issue watcher cron installed (daily 8 AM)"
  fi
  info "Watch log: $WATCH_LOG"
fi

if [[ "$OPENSPACE_ENABLED" == "true" ]]; then
  install_status_set "openspace" "installing"
  install_status_msg "openspace" "Starting OpenSpace…"
  bash "$REPO_DIR/scripts/components/openspace.sh"
  install_status_set "openspace" "running"
  install_status_msg "openspace" ""
fi

if [[ "$DEERFLOW_ENABLED" == "true" ]]; then
  install_status_set "deerflow" "installing"
  install_status_msg "deerflow" "Starting DeerFlow…"
  bash "$REPO_DIR/scripts/components/deerflow.sh"
  install_status_set "deerflow" "running"
  install_status_msg "deerflow" ""
fi

if [[ "$GVISOR_SANDBOX_ENABLED" == "true" ]]; then
  install_status_set "gvisor-sandbox" "installing"
  install_status_msg "gvisor-sandbox" "Installing gVisor runtime + OpenClaw…"
  bash "$REPO_DIR/scripts/components/gvisor-sandbox.sh"
  install_status_set "gvisor-sandbox" "running"
  install_status_msg "gvisor-sandbox" ""
fi

if [[ "$DUPLICATI_ENABLED" == "true" ]]; then
  install_status_set "duplicati" "installing"
  install_status_msg "duplicati" "Starting Duplicati…"
  bash "$REPO_DIR/scripts/components/duplicati.sh"
  install_status_set "duplicati" "running"
  install_status_msg "duplicati" ""
fi

# ── Connectivity ──────────────────────────────────────────────────────────────
step "Connectivity"

if [[ "$TAILSCALE_ENABLED" == "true" ]]; then
  install_status_set "tailscale" "installing"
  install_status_msg "tailscale" "Connecting to tailnet…"
  bash "$REPO_DIR/scripts/components/tailscale.sh"
  install_status_set "tailscale" "running"
  install_status_msg "tailscale" ""
fi

if [[ "$TELEGRAM_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/components/telegram.sh"
fi

if [[ "$SIGNAL_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/components/signal.sh"
fi

echo ""
install_status_complete
ok "Full stack is ready — dual-backend (GPU+CPU) chat:${CHAT_MODE}"
