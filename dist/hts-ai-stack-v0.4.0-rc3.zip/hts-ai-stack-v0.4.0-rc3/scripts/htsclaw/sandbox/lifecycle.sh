#!/usr/bin/env bash
# scripts/htsclaw/sandbox/lifecycle.sh — htsclaw sandbox lifecycle management
#
# Core functions for creating, destroying, upgrading, and executing commands
# inside OpenShell sandboxes — direct openshell calls, no NemoClaw middleman.
#
# Standalone usage:
#   ./scripts/htsclaw/sandbox/lifecycle.sh              # full setup: create + provider + forward
#   ./scripts/htsclaw/sandbox/lifecycle.sh --create      # create sandbox only
#   ./scripts/htsclaw/sandbox/lifecycle.sh --destroy     # destroy sandbox only
#   ./scripts/htsclaw/sandbox/lifecycle.sh --upgrade     # upgrade OpenClaw in sandbox
#   ./scripts/htsclaw/sandbox/lifecycle.sh --patch       # npm audit fix inside sandbox
#   ./scripts/htsclaw/sandbox/lifecycle.sh --forward     # start port forward only
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

_LIFECYCLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_DIR="$_LIFECYCLE_DIR"
REPO_DIR="$(cd "$_LIFECYCLE_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
HTSCLAW_DEPLOY="${HTSCLAW_DEPLOY:-true}"
HTSCLAW_SANDBOX_NAME="${HTSCLAW_SANDBOX_NAME:-hts-ai-openshell-htsclaw-gpu}"
HTSCLAW_PORT="${HTSCLAW_PORT:-18790}"
HTSCLAW_GATEWAY_NAME="htsclaw"
HTSCLAW_GATEWAY_PORT="${HTSCLAW_GATEWAY_PORT:-8083}"
HTSCLAW_CLUSTER_CONTAINER="openshell-cluster-${HTSCLAW_GATEWAY_NAME}"
OLLAMA_MODEL="${OLLAMA_MODEL:-gemma4:e4b}"
LLAMA_SWAP_HOST_URL="http://host.openshell.internal:${LLAMA_SWAP_PORT:-8081}/v1"

# ── Internal helpers ─────────────────────────────────────────────────────────

_ensure_sudo() {
  if sudo -n true 2>/dev/null; then return 0; fi
  info "Administrator privileges required."
  sudo -v || { fail "Sudo authentication failed."; }
}

_require_openshell() {
  if ! command -v openshell &>/dev/null; then
    fail "openshell CLI not found — install it first (see docs/guides/)."
  fi
}

# Generate openclaw.json matching OpenClaw v2026.4.x schema.
# Key: uses `api` (not `type`), `models` array (not `models.default`).
# base_url should be https://inference.local/v1 (routed by the privacy router).
#
# request.allowPrivateNetwork bypasses the SSRF guard's hostname block for
# .local TLDs.  request.proxy.mode "env-proxy" tells the SSRF guard to use
# the sandbox's HTTPS_PROXY env (EnvHttpProxyAgent) instead of DNS-pinned
# direct connections — required because inference.local is only reachable
# through the privacy router proxy tunnel.
#
# use_request (4th arg, default "true"): set to "false" when falling back to
# global OpenClaw 2026.3.x which does not recognise the "request" key.
_generate_openclaw_config() {
  local port="$1" base_url="$2" model="$3" use_request="${4:-true}"

  local request_block=""
  if [[ "$use_request" == "true" ]]; then
    request_block=',
        "request": {
          "allowPrivateNetwork": true,
          "proxy": { "mode": "env-proxy" }
        }'
  fi

  cat <<EOCONFIG
{
  "gateway": {
    "mode": "local",
    "port": ${port},
    "auth": { "token": "" }
  },
  "models": {
    "mode": "merge",
    "providers": {
      "inference": {
        "baseUrl": "${base_url}",
        "apiKey": "not-needed",
        "api": "openai-responses",
        "models": [
          {
            "id": "${model}",
            "name": "inference/${model}",
            "reasoning": false,
            "input": ["text"],
            "cost": { "input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0 },
            "contextWindow": 131072,
            "maxTokens": 4096,
            "compat": { "supportsStore": false }
          }
        ]${request_block}
      }
    }
  }
}
EOCONFIG
}

# Upload openclaw.json into the sandbox.
# use_request (5th arg, default "true"): "false" omits the request block for
# OpenClaw 2026.3.x which does not recognise that key.
_upload_openclaw_config() {
  local sandbox="$1" port="$2" base_url="$3" model="$4" use_request="${5:-true}"
  local tmpfile
  tmpfile=$(mktemp /tmp/openclaw-config-XXXXXX.json)
  _generate_openclaw_config "$port" "$base_url" "$model" "$use_request" > "$tmpfile"

  openshell sandbox upload -g "$HTSCLAW_GATEWAY_NAME" "$sandbox" \
    "$tmpfile" /sandbox/.openclaw/openclaw.json 2>/dev/null || {
    rm -f "$tmpfile"
    fail "Failed to upload openclaw.json to '${sandbox}'."
  }
  rm -f "$tmpfile"
  ok "openclaw.json uploaded to '${sandbox}'."
}

# Start the OpenClaw gateway inside the sandbox (foreground mode via setsid).
# In containers, `openclaw gateway start` requires systemd which isn't available.
# Instead we use `openclaw gateway run` in the foreground, detached via setsid.
# PID 1 (openshell-sandbox) keeps child processes alive after exec exits.
#
# Requires the DNS hook (dns-hook.js) for inference.local resolution and a
# local OpenClaw >= 2026.4.x install for request.proxy config support.
# Poll until the sandbox reaches Phase:Ready or times out.
_wait_for_sandbox_ready() {
  local sandbox="$1" max_wait="${2:-120}" elapsed=0
  info "Waiting for sandbox '${sandbox}' to reach Ready phase (max ${max_wait}s)..."
  while [[ $elapsed -lt $max_wait ]]; do
    local phase
    phase=$(openshell sandbox get "$sandbox" 2>/dev/null | awk '/Phase/{print $2}' || true)
    if [[ "$phase" == "Ready" ]]; then
      info "Sandbox '${sandbox}' is Ready."
      return 0
    fi
    sleep 3
    elapsed=$((elapsed + 3))
  done
  fail "Sandbox '${sandbox}' did not reach Ready phase within ${max_wait}s."
}

_start_openclaw_gateway() {
  local sandbox="$1" port="$2" base_url="${3:-https://inference.local/v1}" model="${4:-$OLLAMA_MODEL}"

  # Upload the DNS hook so inference.local resolves inside the SSRF guard
  local dns_hook="${REPO_DIR}/resources/htsclaw/dns-hook.js"
  if [[ -f "$dns_hook" ]]; then
    openshell sandbox upload -g "$HTSCLAW_GATEWAY_NAME" "$sandbox" \
      "$dns_hook" /sandbox/dns-hook.js 2>/dev/null || {
      fail "Failed to upload dns-hook.js to '${sandbox}' — gateway cannot start without it."
    }
  fi

  # Ensure OpenClaw >= 2026.4.x is available locally (the sandbox image ships
  # 2026.3.x which lacks request.proxy config support, and Landlock blocks
  # global npm installs).
  _wait_for_sandbox_ready "$sandbox"

  info "Ensuring OpenClaw >= 2026.4 in sandbox..."
  local npm_out npm_rc=0
  npm_out=$(openshell sandbox exec -g "$HTSCLAW_GATEWAY_NAME" -n "$sandbox" \
    -- timeout 120 npm install --prefix /sandbox --ignore-scripts openclaw@latest 2>&1) || npm_rc=$?

  # Determine whether the local 2026.4.x binary is present.  Only 2026.4.x+
  # supports the "request" config block; 2026.3.x (global fallback) rejects it.
  local use_request="true"
  if [[ $npm_rc -ne 0 ]]; then
    warn "Local OpenClaw install failed (exit ${npm_rc}) — falling back to global."
    warn "npm output: ${npm_out}"
    use_request="false"
  else
    info "npm install: $(echo "$npm_out" | tail -1)"
  fi

  # Upload the config now that we know which OpenClaw version will run.
  _upload_openclaw_config "$sandbox" "$port" "$base_url" "$model" "$use_request"

  # Upload a start script — nohup + setsid + stdin redirect ensure the
  # process survives after the openshell exec session exits.
  local tmpscript
  tmpscript=$(mktemp /tmp/start-gw-XXXXXX.sh)
  cat > "$tmpscript" <<'EOSCRIPT'
#!/bin/sh
cd /sandbox
# Prefer local install (2026.4.x+) over global (2026.3.x)
OPENCLAW_BIN="/sandbox/node_modules/.bin/openclaw"
if [ ! -x "$OPENCLAW_BIN" ]; then
  OPENCLAW_BIN="openclaw"
fi
if [ -f /sandbox/dns-hook.js ]; then
  export NODE_OPTIONS="--require /sandbox/dns-hook.js"
fi
nohup setsid "$OPENCLAW_BIN" gateway run --port "$1" --bind loopback --auth none \
  </dev/null > /tmp/openclaw-gw.log 2>&1 &
echo "PID=$!"
sleep 2
EOSCRIPT

  openshell sandbox upload -g "$HTSCLAW_GATEWAY_NAME" "$sandbox" \
    "$tmpscript" /sandbox/start-openclaw-gw.sh 2>/dev/null || {
    rm -f "$tmpscript"
    fail "Failed to upload gateway start script."
  }
  rm -f "$tmpscript"

  info "Starting OpenClaw gateway inside '${sandbox}' on port ${port}..."
  openshell sandbox exec -g "$HTSCLAW_GATEWAY_NAME" -n "$sandbox" \
    -- sh -c "chmod +x /sandbox/start-openclaw-gw.sh && /sandbox/start-openclaw-gw.sh ${port}" 2>&1 || {
    fail "Failed to start OpenClaw gateway in '${sandbox}'."
  }
}

# Wait for the OpenClaw gateway healthz endpoint inside the sandbox.
# Cold-start (npm install + node init) typically takes 20-60s; default is 90s.
_wait_for_openclaw_healthz() {
  local sandbox="$1" port="$2" max_wait="${3:-90}"
  local elapsed=0
  info "Waiting for OpenClaw healthz (max ${max_wait}s)..."
  while [[ $elapsed -lt $max_wait ]]; do
    local health
    health=$(openshell sandbox exec -g "$HTSCLAW_GATEWAY_NAME" -n "$sandbox" \
      -- curl -sf "http://127.0.0.1:${port}/healthz" 2>/dev/null || true)
    if echo "$health" | grep -q '"ok":true'; then
      ok "OpenClaw gateway healthy in '${sandbox}'."
      return 0
    fi
    sleep 2
    elapsed=$((elapsed + 2))
  done
  warn "OpenClaw gateway did not become healthy within ${max_wait}s."
  info "Gateway log from '${sandbox}':"
  openshell sandbox exec -g "$HTSCLAW_GATEWAY_NAME" -n "$sandbox" \
    -- cat /tmp/openclaw-gw.log 2>/dev/null || true
  return 1
}

# ── Gateway management ───────────────────────────────────────────────────────

# Start the openshell gateway container if not already running.
_ensure_gateway() {
  _require_openshell

  # Try selecting first — works if metadata + container both exist
  if openshell gateway select "$HTSCLAW_GATEWAY_NAME" &>/dev/null; then
    # Verify the cluster container is actually running — metadata can survive
    # after the container is stopped/removed (nuke-and-pave, docker rm, reboot).
    local cluster_ctr="openshell-cluster-${HTSCLAW_GATEWAY_NAME}"
    if docker inspect --format '{{.State.Running}}' "$cluster_ctr" 2>/dev/null | grep -q "true"; then
      info "Gateway '${HTSCLAW_GATEWAY_NAME}' selected."
      return 0
    fi
    warn "Gateway '${HTSCLAW_GATEWAY_NAME}' metadata found but container missing — recreating..."
  fi

  # Metadata missing or gateway doesn't exist — (re)create it.
  # --recreate handles stale containers left after a nuke-and-pave.
  info "Starting openshell gateway '${HTSCLAW_GATEWAY_NAME}' on port ${HTSCLAW_GATEWAY_PORT}..."
  openshell gateway start \
    --name "$HTSCLAW_GATEWAY_NAME" \
    --port "$HTSCLAW_GATEWAY_PORT" \
    --recreate || {
    fail "Failed to start openshell gateway '${HTSCLAW_GATEWAY_NAME}'."
  }

  openshell gateway select "$HTSCLAW_GATEWAY_NAME" || {
    fail "Gateway started but could not be selected — check 'openshell gateway info -g ${HTSCLAW_GATEWAY_NAME}'."
  }
  ok "Gateway '${HTSCLAW_GATEWAY_NAME}' started and selected."
}

# Pre-pull the sandbox image into the k3s containerd cache.
# openshell sandbox create has a hardcoded 300s provision timeout — if the
# image has to be fetched from ghcr.io on a slow connection, it times out
# with "DependenciesNotReady: Pod exists with phase: Pending".
# Pre-pulling removes the image download from the 300s window.
_prepull_sandbox_image() {
  local image="${1:-ghcr.io/nvidia/openshell-community/sandboxes/openclaw:latest}"
  local cluster_ctr="$HTSCLAW_CLUSTER_CONTAINER"

  # Check if image is already cached in k3s containerd
  if docker exec "$cluster_ctr" k3s crictl images 2>/dev/null | grep -q "openclaw"; then
    info "Sandbox image already cached in gateway."
    return 0
  fi

  info "Pre-pulling sandbox image into gateway (this may take a few minutes)..."
  if docker exec "$cluster_ctr" k3s crictl pull "$image" 2>&1; then
    ok "Sandbox image pre-pulled."
  else
    warn "Image pre-pull via crictl failed — sandbox create will attempt its own pull."
  fi
}

# ── Sandbox lifecycle ────────────────────────────────────────────────────────

# htsclaw_create — Create a new sandbox with the htsclaw gateway.
# Idempotent: if the sandbox already exists, prompts the user.
htsclaw_create() {
  _require_openshell
  _ensure_gateway

  # Provider must exist before sandbox create references it
  source "$_LIFECYCLE_DIR/provider.sh"
  htsclaw_provider

  local sandbox="${1:-$HTSCLAW_SANDBOX_NAME}"
  local port="${2:-$HTSCLAW_PORT}"

  step "htsclaw — create sandbox '${sandbox}'"

  # Check if sandbox already exists
  if openshell sandbox get "$sandbox" &>/dev/null 2>&1; then
    warn "Sandbox '${sandbox}' already exists."
    echo ""
    echo -e "  ${CYAN}[s]${NC}kip (default)  ${CYAN}[o]${NC}verwrite (destroy + recreate)"
    local reply=""
    if read -r -t 30 -p "  Choice [s/o, 30s timeout → skip]: " reply 2>/dev/null; then
      : # got input
    else
      echo ""
      info "Timeout — keeping existing sandbox."
    fi

    case "${reply,,}" in
      o|overwrite)
        htsclaw_destroy "$sandbox"
        ;;
      *)
        info "Sandbox '${sandbox}' — resuming setup on existing sandbox."
        _start_openclaw_gateway "$sandbox" "$port"
        htsclaw_forward "$sandbox" "$port"
        _wait_for_openclaw_healthz "$sandbox" "$port"
        return 0
        ;;
    esac
  fi

  # Pre-flight: verify llama-swap is reachable
  local swap_port="${LLAMA_SWAP_PORT:-8081}"
  if ! curl -sf "http://localhost:${swap_port}/health" >/dev/null 2>&1; then
    fail "Pre-flight failed: llama-swap (:${swap_port}) is unreachable — cannot create sandbox."
  fi

  # Cache the sandbox image before create to avoid the 300s provision timeout
  _prepull_sandbox_image

  info "Creating sandbox '${sandbox}' on gateway '${HTSCLAW_GATEWAY_NAME}'..."
  local policy_file="${REPO_DIR}/scripts/htsclaw/policies/openclaw-sandbox.yaml"
  openshell sandbox create \
    -g "$HTSCLAW_GATEWAY_NAME" \
    --name "$sandbox" \
    --from openclaw \
    --policy "$policy_file" \
    --provider llama-swap-local \
    -- true || {
    fail "Failed to create sandbox '${sandbox}'."
  }

  ok "Sandbox '${sandbox}' created."

  _wait_for_sandbox_ready "$sandbox"

  # Upload OpenClaw config and start gateway — version detection happens inside
  # _start_openclaw_gateway after the npm install attempt.
  _start_openclaw_gateway "$sandbox" "$port"

  # Start the port forward
  htsclaw_forward "$sandbox" "$port"

  # Wait for gateway to be healthy
  _wait_for_openclaw_healthz "$sandbox" "$port"
}

# htsclaw_destroy — Stop forwards and delete a sandbox.
# Idempotent: does not fail if sandbox doesn't exist.
htsclaw_destroy() {
  _require_openshell

  local sandbox="${1:-$HTSCLAW_SANDBOX_NAME}"
  local port="${2:-$HTSCLAW_PORT}"

  step "htsclaw — destroy sandbox '${sandbox}'"

  # Stop port forward first
  openshell forward stop -g "$HTSCLAW_GATEWAY_NAME" "$port" 2>/dev/null || true

  # Delete the sandbox
  if openshell sandbox get "$sandbox" &>/dev/null 2>&1; then
    openshell sandbox delete -g "$HTSCLAW_GATEWAY_NAME" "$sandbox" 2>/dev/null || {
      warn "Failed to delete sandbox '${sandbox}' — may need manual cleanup."
      return 1
    }
    ok "Sandbox '${sandbox}' destroyed."
  else
    info "Sandbox '${sandbox}' does not exist — nothing to destroy."
  fi
}

# htsclaw_upgrade — Upgrade OpenClaw inside the sandbox.
# Installs locally to /sandbox/node_modules (Landlock blocks global installs).
# Does NOT destroy the sandbox — preserves config and personas.
htsclaw_upgrade() {
  _require_openshell

  local sandbox="${1:-$HTSCLAW_SANDBOX_NAME}"

  step "htsclaw — upgrade OpenClaw in '${sandbox}'"

  if ! openshell sandbox get "$sandbox" &>/dev/null 2>&1; then
    fail "Sandbox '${sandbox}' does not exist — create it first."
  fi

  info "Updating OpenClaw inside '${sandbox}' (local install)..."
  openshell sandbox exec -g "$HTSCLAW_GATEWAY_NAME" -n "$sandbox" \
    -- npm install --prefix /sandbox --ignore-scripts openclaw@latest 2>&1 || {
    fail "Failed to upgrade OpenClaw in '${sandbox}'."
  }

  # Restart the gateway to pick up the new version
  _htsclaw_restart_gateway "$sandbox"

  ok "OpenClaw upgraded in '${sandbox}'."
}

# htsclaw_exec — Run a command inside the sandbox.
htsclaw_exec() {
  _require_openshell

  local sandbox="${1:-$HTSCLAW_SANDBOX_NAME}"
  shift || true

  if [[ $# -eq 0 ]]; then
    fail "Usage: htsclaw_exec [sandbox] <command...>"
  fi

  openshell sandbox exec -g "$HTSCLAW_GATEWAY_NAME" -n "$sandbox" -- "$@"
}

# htsclaw_forward — Start a port forward to the sandbox.
# openshell forward maps host:PORT → sandbox:PORT (same port).
# htsclaw uses a single port (default 18790) so no relay is needed.
htsclaw_forward() {
  _require_openshell

  local sandbox="${1:-$HTSCLAW_SANDBOX_NAME}"
  local port="${2:-$HTSCLAW_PORT}"

  # Check if forward is already running
  local fwd_status
  fwd_status=$(openshell forward list -g "$HTSCLAW_GATEWAY_NAME" 2>/dev/null | grep "$port" || true)
  if echo "$fwd_status" | grep -q "running"; then
    info "Forward :${port} → '${sandbox}' already running."
    return 0
  fi

  # Stop any dead forward on this port first
  openshell forward stop -g "$HTSCLAW_GATEWAY_NAME" "$port" 2>/dev/null || true

  info "Starting forward :${port} → '${sandbox}'..."
  openshell forward start -g "$HTSCLAW_GATEWAY_NAME" -d "$port" "$sandbox" 2>/dev/null || {
    warn "Failed to start forward :${port} → '${sandbox}'."
    return 1
  }
  ok "Forward :${port} → '${sandbox}' started."
}

# htsclaw_patch — Run npm audit fix inside the sandbox (non-destructive).
# Unlike NemoClaw where patching the source is forbidden, htsclaw gives you
# direct control over dependency patching inside your own sandbox.
htsclaw_patch() {
  _require_openshell

  local sandbox="${1:-$HTSCLAW_SANDBOX_NAME}"

  step "htsclaw — patch (npm audit fix) in '${sandbox}'"

  if ! openshell sandbox get "$sandbox" &>/dev/null 2>&1; then
    fail "Sandbox '${sandbox}' does not exist — create it first."
  fi

  info "Running npm audit fix inside '${sandbox}'..."
  openshell sandbox exec -g "$HTSCLAW_GATEWAY_NAME" -n "$sandbox" -- npm audit fix 2>&1 || {
    warn "npm audit fix reported issues — review output above."
  }

  ok "Patch complete in '${sandbox}'."
}

# ── Root exec helper ─────────────────────────────────────────────────────────
# openclaw.json and gateway files are root-owned inside the sandbox.
# We exec as uid 0 via docker → containerd, same pattern as NemoClaw.
_htsclaw_root_exec() {
  local sandbox="$1" exec_prefix="$2"; shift 2

  if ! docker inspect "$HTSCLAW_CLUSTER_CONTAINER" &>/dev/null; then
    warn "Cluster container '${HTSCLAW_CLUSTER_CONTAINER}' not found."
    return 1
  fi

  local ctr_id
  ctr_id=$(docker exec "$HTSCLAW_CLUSTER_CONTAINER" \
    /bin/sh -c "ctr -n k8s.io tasks list 2>/dev/null | awk '{print \$1}'" \
    | while read -r id; do
        local hn
        hn=$(docker exec "$HTSCLAW_CLUSTER_CONTAINER" \
          ctr -n k8s.io tasks exec --exec-id "hn-${id:0:8}" --user 0 "$id" \
          hostname 2>/dev/null) || continue
        if [[ "$hn" == "$sandbox" ]]; then echo "$id"; break; fi
      done)

  if [[ -z "${ctr_id:-}" ]]; then
    warn "Could not find containerd task for '${sandbox}'."
    return 1
  fi

  docker exec "$HTSCLAW_CLUSTER_CONTAINER" \
    ctr -n k8s.io tasks exec \
      --exec-id "${exec_prefix}-${sandbox:0:8}" --user 0 "$ctr_id" \
      "$@"
}

# _htsclaw_restart_gateway — Kill the gateway and restart with updated config
_htsclaw_restart_gateway() {
  local sandbox="$1"
  local port="${2:-$HTSCLAW_PORT}"
  _htsclaw_root_exec "$sandbox" "gw" \
    /bin/sh -c "kill \$(cat /tmp/openclaw-gateway.pid 2>/dev/null) 2>/dev/null || pkill -f 'openclaw.*gateway' 2>/dev/null || true" \
    2>/dev/null || true
  sleep 3
  _start_openclaw_gateway "$sandbox" "$port"
  _wait_for_openclaw_healthz "$sandbox" "$port" 90
}

# htsclaw_repair — Re-upload config and restart the gateway on an existing sandbox.
# If the sandbox is gone, falls back to a full create automatically.
htsclaw_repair() {
  _require_openshell

  local sandbox="${1:-$HTSCLAW_SANDBOX_NAME}"
  local port="${2:-$HTSCLAW_PORT}"

  step "htsclaw — repair sandbox '${sandbox}'"

  if ! openshell sandbox get "$sandbox" &>/dev/null 2>&1; then
    warn "Sandbox '${sandbox}' not found — falling back to full create."
    htsclaw_create "$sandbox" "$port"
    return
  fi

  _start_openclaw_gateway "$sandbox" "$port"
  htsclaw_forward "$sandbox" "$port"
  _wait_for_openclaw_healthz "$sandbox" "$port"
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --create)  ACTION="create"; shift ;;
      --destroy) ACTION="destroy"; shift ;;
      --upgrade) ACTION="upgrade"; shift ;;
      --patch)   ACTION="patch"; shift ;;
      --forward) ACTION="forward"; shift ;;
      --repair)  ACTION="repair"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      htsclaw_create
      ;;
    create)  htsclaw_create ;;
    destroy) htsclaw_destroy ;;
    upgrade) htsclaw_upgrade ;;
    patch)   htsclaw_patch ;;
    forward) htsclaw_forward ;;
    repair)  htsclaw_repair ;;
  esac
fi
