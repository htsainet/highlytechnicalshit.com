# Claw3D Component

Last updated: 2026-04-17

## What happens here

Claw3D is a Three.js-powered 3D virtual office workspace for AI agents.
It provides a visual environment where agents can be observed and
interacted with in a spatial context.

## Files and structure

| File | Purpose |
|------|---------|
| `claw3d.sh` | Full lifecycle: install, configure, start, stop, health |
| `claw3d.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |

## Upstream

- [GitHub — iamlukethedev/Claw3D](https://github.com/iamlukethedev/Claw3D)

## Authentication (STUDIO_ACCESS_TOKEN)

Claw3D refuses to bind to `0.0.0.0` without `STUDIO_ACCESS_TOKEN` set
(security policy in `server/network-policy.js`). Since Docker requires
binding to `0.0.0.0` for port mapping, we set:

```yaml
environment:
  - HOST=0.0.0.0
  - STUDIO_ACCESS_TOKEN=${CLAW3D_ACCESS_TOKEN:-hts-claw3d-local}
```

The server checks for a `studio_access` cookie on every request
(`server/access-gate.js`). The dashboard uses the **cookie auth bridge**
(`/api/auth-bridge`) to set this cookie transparently when the user
clicks the Portal link. See dashboard CONTEXT.md for details.

## WebSocket connection

The `NEXT_PUBLIC_WS_URL` environment variable points to the NemoClaw
sandbox WebSocket endpoint (default: `ws://localhost:18789`). This is
how Claw3D communicates with running agent sandboxes.

## Build

Multi-stage Docker build: clones from GitHub, runs `npm ci` + `npm run
build` in the builder stage, then copies everything to a slim Node 20
runtime image. Runs `npm start` → `node server/index.js` in production.
