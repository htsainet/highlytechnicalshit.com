$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
}

Describe 'Pre-commit checks — Editor swap/backup files' {
    It 'no Vim swap files (*.swp, *.swo)' {
        $swapFiles = @(
            Get-ChildItem -Path $script:RepoRoot -Recurse -Include '*.swp', '*.swo' -ErrorAction SilentlyContinue
        )
        $swapFiles.Count | Should -Be 0 -Because "Vim swap files should not be committed; add *.swp to .gitignore"
    }

    It 'no editor backup files (*~)' {
        $backupFiles = @(
            Get-ChildItem -Path $script:RepoRoot -Recurse -Include '*~' -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -notmatch '^\.' }  # Skip hidden files like ..*~
        )
        $backupFiles.Count | Should -Be 0 -Because "Editor backup files should not be committed; add *~ to .gitignore"
    }

    It 'no Vim hidden swap files (.*.swp)' {
        $hiddenSwapFiles = @(
            Get-ChildItem -Path $script:RepoRoot -Recurse -Include '.*.swp' -ErrorAction SilentlyContinue
        )
        $hiddenSwapFiles.Count | Should -Be 0 -Because "Hidden Vim swap files should not be committed; add .*.swp to .gitignore"
    }

    It '.gitignore includes editor swap patterns' {
        $gitignore = Join-Path $script:RepoRoot '.gitignore'
        $gitignore | Should -Exist

        $content = Get-Content $gitignore -Raw
        $content | Should -Match '\*\.swp' -Because ".gitignore should ignore *.swp files"
        $content | Should -Match '\*~' -Because ".gitignore should ignore *~ backup files"
    }
}
