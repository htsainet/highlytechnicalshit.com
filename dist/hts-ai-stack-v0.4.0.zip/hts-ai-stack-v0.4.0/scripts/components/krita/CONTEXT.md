# Krita — Component Context

## Purpose

Krita is a free and open-source digital painting application designed for
concept artists, illustrators, matte and texture artists, and the VFX
industry. It features professional-grade brush engines, non-destructive
layers, and built-in frame-by-frame animation tools.

## Location

`scripts/components/krita/` — component directory

## Key Files

| File | Purpose |
|------|---------|
| `krita.manifest.json` | Convergence manifest |
| `krita.sh` | Install / configure / health script |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and notes |

## Notes

- Installed via **snap** for latest stable version
- Desktop application — no Docker service or web UI
- GPU-accelerated canvas via OpenGL
- Built-in animation timeline for frame-by-frame animation

See [usage.md](./usage.md) for command usage.
