#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════╗
# ║       AI STACK — BOOTSTRAP INSTALLER            ║
# ║       Prepares system then launches setup menu  ║
# ╚══════════════════════════════════════════════════╝
set -euo pipefail

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

ok()   { echo -e "${GREEN}  ✓${RESET}  $*"; }
info() { echo -e "${CYAN}  ▸${RESET}  $*"; }
warn() { echo -e "${YELLOW}  ⚠${RESET}  $*"; }
fail() { echo -e "${RED}  ✗${RESET}  $*"; exit 1; }

banner() {
  echo ""
  echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════╗${RESET}"
  echo -e "${CYAN}${BOLD}║       AI STACK  —  BOOTSTRAP INSTALLER          ║${RESET}"
  echo -e "${CYAN}${BOLD}║       Ubuntu AI Environment Builder             ║${RESET}"
  echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════╝${RESET}"
  echo ""
}

# ── Checks ────────────────────────────────────────────────────────────────────
check_root() {
  if [[ $EUID -ne 0 ]]; then
    warn "Not running as root. Will use sudo where needed."
    SUDO="sudo"
  else
    SUDO=""
  fi
}

check_ubuntu() {
  if ! grep -qi ubuntu /etc/os-release 2>/dev/null; then
    warn "This script is designed for Ubuntu. Proceeding anyway..."
  else
    ok "Ubuntu detected"
  fi
}

check_internet() {
  info "Checking internet connectivity..."
  if curl -s --max-time 5 https://pypi.org > /dev/null; then
    ok "Internet connection OK"
  else
    fail "No internet connection. Cannot install dependencies."
  fi
}

# ── System packages ───────────────────────────────────────────────────────────
install_system_deps() {
  echo ""
  echo -e "${BOLD}── System Packages ─────────────────────────────────${RESET}"

  info "Updating apt package index..."
  $SUDO apt-get update -qq

  PKGS=(
    python3
    python3-pip
    python3-venv
    curl
    wget
    git
    jq
    ca-certificates
    gnupg
    lsb-release
    software-properties-common
    arp-scan          # used by ai_stack_setup.sh to discover NAS/device IPs
    nfs-common        # showmount (NAS share detection) + idmapd (NFSv4 mapping)
  )

  for pkg in "${PKGS[@]}"; do
    if dpkg -s "$pkg" &>/dev/null; then
      ok "$pkg  (already installed)"
    else
      info "Installing $pkg..."
      $SUDO apt-get install -y -qq "$pkg" && ok "$pkg"
    fi
  done
}

# ── Docker ────────────────────────────────────────────────────────────────────
install_docker() {
  echo ""
  echo -e "${BOLD}── Docker ──────────────────────────────────────────${RESET}"

  if command -v docker &>/dev/null; then
    ok "Docker already installed  ($(docker --version | cut -d' ' -f3 | tr -d ','))"
    return
  fi

  info "Installing Docker via official script..."
  curl -fsSL https://get.docker.com | $SUDO sh
  $SUDO usermod -aG docker "$USER" && ok "Added $USER to docker group"
  ok "Docker installed"
  warn "You may need to log out/in for Docker group to take effect"
}

# ── Python venv + questionary ─────────────────────────────────────────────────
install_python_deps() {
  echo ""
  echo -e "${BOLD}── Python Environment ──────────────────────────────${RESET}"

  VENV_DIR="$(dirname "$0")/.venv"

  if [[ ! -d "$VENV_DIR" ]]; then
    info "Creating Python virtual environment at .venv ..."
    python3 -m venv "$VENV_DIR"
    ok "Virtual environment created"
  else
    ok "Virtual environment already exists"
  fi

  # Activate
  # shellcheck disable=SC1091
  source "$VENV_DIR/bin/activate"

  info "Upgrading pip..."
  pip install --upgrade pip -q

  PYTHON_PKGS=(
    "questionary>=2.0"
    "rich"
    "python-dotenv"
  )

  for pkg in "${PYTHON_PKGS[@]}"; do
    pkg_name=$(echo "$pkg" | cut -d'>' -f1 | cut -d'=' -f1)
    if pip show "$pkg_name" &>/dev/null; then
      ok "$pkg_name  (already installed)"
    else
      info "Installing $pkg..."
      pip install "$pkg" -q && ok "$pkg_name"
    fi
  done
}

# ── Optional: Ollama pre-install ──────────────────────────────────────────────
offer_ollama() {
  echo ""
  echo -e "${BOLD}── Ollama (optional pre-install) ───────────────────${RESET}"

  if command -v ollama &>/dev/null; then
    ok "Ollama already installed"
    return
  fi

  read -rp "$(echo -e "  ${CYAN}▸${RESET}  Pre-install Ollama now? [y/N] ")" yn
  case "$yn" in
    [Yy]*)
      info "Installing Ollama..."
      curl -fsSL https://ollama.com/install.sh | sh
      ok "Ollama installed"
      ;;
    *)
      info "Skipping Ollama — can be installed later"
      ;;
  esac
}

# ── Launch setup menu ─────────────────────────────────────────────────────────
launch_menu() {
  echo ""
  echo -e "${BOLD}── Launching Setup Menu ────────────────────────────${RESET}"

  SCRIPT_DIR="$(dirname "$0")"
  MENU_SCRIPT="$SCRIPT_DIR/ai_stack_setup.py"

  if [[ ! -f "$MENU_SCRIPT" ]]; then
    fail "ai_stack_setup.py not found in $SCRIPT_DIR"
  fi

  VENV_DIR="$SCRIPT_DIR/.venv"
  if [[ -d "$VENV_DIR" ]]; then
    source "$VENV_DIR/bin/activate"
  fi

  echo ""
  python3 "$MENU_SCRIPT"

  # Apply generated config to .env
  APPLY_SCRIPT="$SCRIPT_DIR/apply_config.sh"
  if [[ -x "$APPLY_SCRIPT" ]]; then
    echo ""
    echo -e "${BOLD}── Applying Configuration ─────────────────────────${RESET}"
    "$APPLY_SCRIPT"
  fi
}

# ── Main ──────────────────────────────────────────────────────────────────────
main() {
  banner
  check_root
  check_ubuntu
  check_internet
  install_system_deps
  install_docker
  install_python_deps
  offer_ollama

  echo ""
  ok "Bootstrap complete — all dependencies ready"
  echo ""

  read -rp "$(echo -e "  ${CYAN}▸${RESET}  Launch AI stack setup menu now? [Y/n] ")" launch
  case "$launch" in
    [Nn]*) info "Run  python3 ai_stack_setup.py  to configure later." ;;
    *)     launch_menu ;;
  esac
}

main "$@"
