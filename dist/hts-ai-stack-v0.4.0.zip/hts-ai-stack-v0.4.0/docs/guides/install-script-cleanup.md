# Install Script Cleanup — Resume Prompt

We are incrementally migrating the repo to a cleaner filesystem structure.
No big-bang refactor — move files as we touch them.

## Target Structure (agreed)

```text
hts-ai-stack/
├── bootstrap.sh            # wget-able shim: clones repo + exec install.sh
├── install.sh              # only user-facing entry point (stays at root)
├── docker-compose.yml
├── .env
├── README.md
│
├── scripts/
│   ├── pipeline/           # numbered install chain (called by install.sh)
│   │   ├── 01-autoinstall.sh
│   │   ├── 02-setup-docker.sh
│   │   ├── 03-setup-models.sh
│   │   ├── 04-setup-nemoclaw.sh
│   │   ├── 06-start-stack.sh
│   │   └── 07-setup-connectivity.sh
│   └── utils/              # operator tools (not part of install flow)
│       ├── verify.sh
│       ├── teardown.sh
│       ├── reset-stack.sh       # canonical destructive reset entrypoint
│       ├── nuke-stack.sh        # legacy compatibility shim
│       └── seed-model-cache.sh
│
├── config/
│   ├── stack.json
│   ├── wizard/             # setup menu + apply scripts
│   │   ├── ai_stack_setup.sh
│   │   ├── ai_stack_setup.py
│   │   ├── apply_config.sh
│   │   └── bootstrap.sh
│   └── backups/
│
├── services/               # one dir per composable service
│   ├── bitnet/
│   ├── deerflow/
│   └── claw3d/
│
├── setup/                  # domain install modules (keep existing structure)
├── instances/
├── resources/
├── tests/
├── backups/
├── docs/
│   ├── pipeline/           # numbered .md docs
│   └── references.md
└── experimental/           # rename from new_sen_sa_tion/
```

## Completed

- [x] `new_sen_sa_tion/stack-config/` → `config/wizard/` + updated `install.sh` lines 82-83
- [x] Numbered `.md` docs → `docs/pipeline/`
- [x] Utility scripts (`teardown.sh`, `verify.sh`, `reset-stack.sh` (canonical), `nuke-stack.sh` (legacy shim), `seed-model-cache.sh`) → `scripts/utils/` + updated installer references

## Remaining (priority order)

- [x] **Bootstrap consolidation** — `00-bootstrap.sh` removed; `01-autoinstall.sh` now installs NVIDIA drivers (instead of exiting); root `bootstrap.sh` is a wget-able shim (clone + exec install.sh); post-commit hook updated
- [x] **Priority 4** — Move numbered pipeline scripts → `scripts/pipeline/`
  - Added `REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"` to each script; replaced all `$SCRIPT_DIR/setup/`, `$SCRIPT_DIR/.env`, `$SCRIPT_DIR/docker-compose.yml` with `$REPO_DIR/...`
  - `install.sh` updated to call `$REPO_DIR/scripts/pipeline/NN-*.sh` directly
  - `bootstrap.sh` at root updated to exec the new locations (kept as user-facing shim)
  - `06-stop-test-instances.sh` moved alongside (not in install chain but numbered)

- [ ] **Priority 5** — Move `new_sen_sa_tion/ai-stack-rtx3060/deerflow/` → `services/deerflow/`

- [ ] **Priority 6** — Rename `new_sen_sa_tion/` → `experimental/`
  - Still contains: `ai-stack-rtx3060/`, `bitnet-nemoclaw/`
  - `new_sen_sa_tion/stack-config/` is now empty (already migrated) — remove it first

## Key Facts Established

- `ai_stack_setup.sh`, `apply_config.sh`, `ai_stack_setup.py` all compute `REPO_ROOT` via `../..` relative to their script location — they are currently 2 levels deep in `config/wizard/` which is correct
- No wizard logic is duplicated elsewhere in the repo
- `01-autoinstall.sh` writes `.env` defaults (tokens, `BACKEND_ENGINE=ollama`) as a bootstrap step — separate from wizard which applies user config on top
- Two wizard implementations exist: shell (whiptail) and Python (questionary) — not yet unified; install.sh only calls the shell version
- `backups/synology/setup-nas-mount.sh` is an alternative NAS mount approach (systemd+TPM2) not integrated into main flow
