# Synfig Studio — Component Context

## Purpose

Synfig Studio is a free and open-source 2D vector animation application.
It features motion tweening, bone-based rigging, and a layer-based
compositing system for producing film-quality animation without
frame-by-frame drawing.

## Location

`scripts/components/synfig/` — component directory

## Key Files

| File | Purpose |
|------|---------|
| `synfig.manifest.json` | Convergence manifest |
| `synfig.sh` | Install / configure / health script |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and notes |

## Notes

- Installed via **apt** from Ubuntu repositories
- Desktop application — no Docker service or web UI
- Supports SIF (Synfig) and Lottie export formats

See [usage.md](./usage.md) for command usage.
