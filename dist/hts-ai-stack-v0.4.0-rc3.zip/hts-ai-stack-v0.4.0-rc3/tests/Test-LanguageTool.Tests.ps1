$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/languagetool'
    $script:ComponentScript = Join-Path $script:ComponentDir 'languagetool.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'languagetool.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'languagetool file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'languagetool manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is languagetool' {
        $script:Manifest.id | Should -Be 'languagetool'
    }

    It 'category is skill' {
        $script:Manifest.category | Should -Be 'skill'
    }

    It 'profile is languagetool' {
        $script:Manifest.profile | Should -Be 'languagetool'
    }

    It 'dashboard port is 8010' {
        [int]$script:Manifest.dashboard.port | Should -Be 8010
    }

    It 'health URL targets languages endpoint' {
        $script:Manifest.health.url | Should -Match 'languages'
    }

    It 'script path points to component subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/languagetool/languagetool.sh'
    }

    It 'install_type is compose' {
        $script:Manifest.install_type | Should -Be 'compose'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'languagetool port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8010 is registered in portmap.json' {
        $script:Portmap.ports.'8010' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'8010'.service | Should -Be 'languagetool'
    }
}

# ── CLI flags ────────────────────────────────────────────────────────────────

Describe 'languagetool CLI flags' {

    BeforeAll {
        $script:ScriptContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'supports --install flag' {
        $script:ScriptContent | Should -Match '--install'
    }

    It 'supports --configure flag' {
        $script:ScriptContent | Should -Match '--configure'
    }

    It 'supports --start flag' {
        $script:ScriptContent | Should -Match '--start'
    }

    It 'supports --stop flag' {
        $script:ScriptContent | Should -Match '--stop'
    }

    It 'supports --restart flag' {
        $script:ScriptContent | Should -Match '--restart'
    }

    It 'supports --health flag' {
        $script:ScriptContent | Should -Match '--health'
    }

    It 'supports --status flag' {
        $script:ScriptContent | Should -Match '--status'
    }

    It 'supports --destroy flag' {
        $script:ScriptContent | Should -Match '--destroy'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'languagetool compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'languagetool service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'languagetool:'
    }

    It 'uses languagetool profile' {
        $script:ComposeContent | Should -Match 'languagetool'
    }

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/languagetool/Dockerfile' | Should -Exist
    }
}
