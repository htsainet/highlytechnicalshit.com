#!/usr/bin/env bash
# Gitea Actions Runner – CI/CD for Gitea (Docker)
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# shellcheck source=scripts/lib/common.sh
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=scripts/lib/health.sh
source "$REPO_DIR/scripts/lib/health.sh"
# shellcheck source=scripts/lib/compose.sh
source "$REPO_DIR/scripts/lib/compose.sh"

GITEA_RUNNER_CONTAINER="${GITEA_RUNNER_CONTAINER:-hts-ai-gitea-runner}"

###############################################################################
# Lifecycle
###############################################################################

gitea_runner_install() {
  info "Building Gitea Runner image …"
  compose_build --profile gitea-runner
  ok "Gitea Runner image ready"
}

gitea_runner_configure() {
  info "Configuring Gitea Actions Runner …"

  local token=""
  if [[ -f "$REPO_DIR/.env" ]]; then
    token="$(grep '^GITEA_RUNNER_TOKEN=' "$REPO_DIR/.env" 2>/dev/null \
             | cut -d= -f2- || true)"
  fi

  if [[ -z "$token" ]]; then
    warn "─────────────────────────────────────────────────────────"
    warn "Gitea Actions Runner requires a registration token."
    warn ""
    warn "  1. Open Gitea at http://localhost:3030"
    warn "  2. Go to Site Administration → Actions → Runners"
    warn "  3. Click 'Create new Runner' and copy the token"
    warn "  4. Add to .env:  GITEA_RUNNER_TOKEN=<your-token>"
    warn "─────────────────────────────────────────────────────────"
    return 1
  fi

  ok "Gitea Runner token found — runner will register on start"
}

gitea_runner_start() {
  info "Starting Gitea Actions Runner …"
  compose_up --profile gitea-runner
  ok "Gitea Runner started — check Gitea UI for runner status"
}

gitea_runner_stop() {
  info "Stopping Gitea Actions Runner …"
  compose_down --profile gitea-runner
  ok "Gitea Runner stopped"
}

gitea_runner_restart() {
  gitea_runner_stop
  gitea_runner_start
}

gitea_runner_health() {
  if docker ps --format '{{.Names}}' 2>/dev/null \
       | grep -q "^${GITEA_RUNNER_CONTAINER}$"; then
    ok "Gitea Runner container is running"
    return 0
  fi
  warn "Gitea Runner container not running"
  return 1
}

gitea_runner_destroy() {
  info "Destroying Gitea Runner (removing volumes) …"
  compose_down --profile gitea-runner -v
  ok "Gitea Runner destroyed"
}

gitea_runner_status() {
  if docker ps --format '{{.Names}}' 2>/dev/null \
       | grep -q "^${GITEA_RUNNER_CONTAINER}$"; then
    echo "running"
  else
    echo "stopped"
  fi
}
