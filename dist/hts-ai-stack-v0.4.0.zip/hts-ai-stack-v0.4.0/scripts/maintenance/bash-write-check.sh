#!/usr/bin/env bash
# bash-write-check.sh — scan for banned bash file-write patterns in repo-tracked files.
#
# CLAUDE.md bans awk / sed / tee for writing repo files (.env, config/*.{json,yaml},
# etc.) because these tools silently corrupt values containing '=', '|', '&', '/',
# or newlines. Use the `edit` / `create` AI-tool contract or the pure-bash
# line-rewrite pattern (see _write_env in scripts/wizard/menu-handler.sh) instead.
#
# This checker intentionally targets ONLY repo-tracked config paths. `sed -i` on
# system files like /etc/ssh/sshd_config is legitimate and not flagged.
#
# Usage:
#   bash-write-check.sh                 # scan entire repo under scripts/ (default)
#   bash-write-check.sh --staged        # scan staged files only (pre-commit mode)
#   bash-write-check.sh --path <dir>    # scan a specific subtree
#   bash-write-check.sh --strict        # exit 1 on any hit (for CI gating)
#
# Exit codes:
#   0 = clean, or hits found in report-only mode (default)
#   1 = --strict mode AND one or more hits
#   2 = usage / setup error

set -uo pipefail

repo_root="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$repo_root" || exit 1

MODE=all
SCAN_PATH=scripts
STRICT=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --staged)  MODE=staged; shift ;;
    --all)     MODE=all; shift ;;
    --path)    MODE=path; SCAN_PATH="${2:-}"; shift 2 ;;
    --strict)  STRICT=1; shift ;;
    -h|--help) awk '/^# /{sub(/^# ?/,""); print; next} /^[^#]/{exit}' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

# Collect shell files
case "$MODE" in
  staged)
    mapfile -t FILES < <(git diff --cached --name-only --diff-filter=ACM 2>/dev/null \
                         | grep -E '\.(sh|bash)$' || true)
    ;;
  all|path)
    mapfile -t FILES < <(git ls-files -- "$SCAN_PATH" 2>/dev/null \
                         | grep -E '\.(sh|bash)$' || true)
    ;;
esac

if [[ ${#FILES[@]} -eq 0 ]]; then
  echo "bash-write-check: no shell files to scan (mode=$MODE path=$SCAN_PATH)"
  exit 0
fi

# Repo-tracked config targets. The pattern matches a variable reference
# ($env_file, ${env_file}) or a literal repo-relative config path. We
# deliberately do NOT flag /etc/* or system-config writes.
REPO_FILE_RE='(\$env_file\b|\$\{env_file\}|\.env\b|"\.env"|config/[^"]*\.(json|yaml|yml)|resources/[^"]*\.(json|yaml|yml))'

hits=0
tmp_report=$(mktemp)
trap 'rm -f "$tmp_report"' EXIT

scan() {
  local label="$1" regex="$2"
  local line
  while IFS= read -r line; do
    # strip pure comments
    local stripped="${line#*:}"; stripped="${stripped#*:}"
    stripped="${stripped#"${stripped%%[![:space:]]*}"}"
    [[ "$stripped" == \#* ]] && continue
    echo "  [$label] $line" >> "$tmp_report"
    hits=$((hits + 1))
  done < <(grep -rnE "$regex" "${FILES[@]}" 2>/dev/null || true)
}

# Pattern 1 — sed -i writing to a repo-tracked config file.
scan "sed-in-place"  "sed -i\b.*${REPO_FILE_RE}"

# Pattern 2 — awk with the tmp-swap idiom aimed at repo config.
#   awk ... > "$tmp" && mv "$tmp" "$env_file"    (bad — awk splits on = by default)
scan "awk-file-rewrite" "awk\b[^#]*(\\\$tmp|mktemp).*${REPO_FILE_RE}"
scan "awk-file-rewrite" "awk\b[^#]*${REPO_FILE_RE}[^#]*>\s*\"?\\\$tmp"

# Pattern 3 — tee writing directly to a repo config.
scan "tee-to-config" "tee\s+[^|&]*${REPO_FILE_RE}"

if [[ $hits -eq 0 ]]; then
  echo "✓ bash-write-check: ${#FILES[@]} file(s) scanned, no banned write patterns."
  exit 0
fi

echo "⚠ bash-write-check: $hits finding(s) across ${#FILES[@]} scanned file(s):"
echo
cat "$tmp_report"
echo
echo "Rule: CLAUDE.md bans awk/sed/tee for writing repo-tracked config files."
echo "Fix:  use the pure-bash line-rewrite pattern (see _write_env in"
echo "      scripts/wizard/menu-handler.sh or the loop in"
echo "      scripts/components/open-webui/open-webui.sh:openwebui_bootstrap_api_key)."

if [[ $STRICT -eq 1 ]]; then
  exit 1
fi
exit 0
