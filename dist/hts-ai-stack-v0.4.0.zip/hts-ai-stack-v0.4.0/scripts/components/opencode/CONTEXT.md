# OpenCode Component — CONTEXT

Last updated: 2026-04-21

## What is OpenCode?

OpenCode is an open-source AI coding agent that runs in the terminal,
edits files in a local git repository, and speaks any OpenAI-compatible
endpoint. It is a peer of (and alternative to) Aider.

- Source: <https://github.com/sst/opencode>
- Docs: <https://opencode.ai/>

## How it fits into the HTS AI Stack

A **host-installed** CLI (not a containerized service), introduced by
FEATURE-054 alongside Aider, Tabby, and the Gitea Runner. Developers
invoke `opencode` inside any git-tracked project directory to edit code
with LLM assistance. Model calls route through the local inference
stack via llama-swap's OpenAI-compatible endpoint.

```text
Developer terminal  →  opencode (host CLI)  →  llama-swap :<port>/v1  →  ollama/bitnet
```

No GPU is required by OpenCode itself — all inference is external.

## Install method

Host install per upstream instructions
(<https://opencode.ai/>). `opencode_install` in `opencode.sh` checks
for an existing binary on `PATH` and skips re-install if found. This is
a project-policy decision consistent with Aider's host-install stance;
see `scripts/components/aider/CONTEXT.md § Why host-installed and not
containerized?` for the full rationale — it applies identically here
(interactive TTY tool, per-user git config, ssh-agent access).

This is **not** a vendor deviation. No entry in `/DEVIATIONS.md` is
required.

## Files and structure

| File | Purpose |
|------|---------|
| `opencode.sh` | Full lifecycle: `opencode_install`, `_configure`, `_start`, `_stop` (no-op), `_health`, `_destroy`, `_status` |
| `opencode.json.example` | Example client config — where to point OpenCode at llama-swap |
| `opencode.manifest.json` | Component metadata (install_type: host) |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and related features |

## Logging conventions

All log calls use the project-wide helpers defined in
`scripts/lib/common.sh`: `info`, `ok`, `warn`, `fail`, `step`. The
previously used `log_info` / `log_ok` / `log_warn` names were never
defined anywhere in `scripts/lib/` and have been renamed stack-wide —
see FEATURE-067 commit for the cleanup.

## Related components

- Aider (`scripts/components/aider/`) — peer tool, different edit
  strategy (diff-based); now configured for architect+editor tier via
  FEATURE-067.
- Tabby (`scripts/components/tabby/`) — in-editor completions
  (complement, not alternative).
- llama-swap (`scripts/components/llama-swap/`) — OpenAI-compatible
  endpoint that OpenCode addresses.
- Ollama (`scripts/components/ollama/`) — model provider behind
  llama-swap.

See [usage.md](./usage.md) for command usage.
