$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/bitnet'
    $script:ComponentScript = Join-Path $script:ComponentDir 'bitnet.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'bitnet.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'bitnet file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'bitnet manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is bitnet' {
        $script:Manifest.id | Should -Be 'bitnet'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/bitnet/bitnet.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is bitnet' {
        $script:Manifest.func_prefix | Should -Be 'bitnet'
    }

    It 'dashboard port is 8082' {
        [int]$script:Manifest.dashboard.port | Should -Be 8082
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'bitnet component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines bitnet_install function' {
        $script:ComponentContent | Should -Match 'bitnet_install\s*\(\)'
    }

    It 'defines bitnet_configure function' {
        $script:ComponentContent | Should -Match 'bitnet_configure\s*\(\)'
    }

    It 'defines bitnet_start function' {
        $script:ComponentContent | Should -Match 'bitnet_start\s*\(\)'
    }

    It 'defines bitnet_stop function' {
        $script:ComponentContent | Should -Match 'bitnet_stop\s*\(\)'
    }

    It 'defines bitnet_health function' {
        $script:ComponentContent | Should -Match 'bitnet_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/bitnet/bitnet\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'bitnet port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8082 is registered in portmap.json' {
        $script:Portmap.ports.'8082' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'8082'.service | Should -Be 'bitnet'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'bitnet no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/bitnet\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/bitnet/bitnet\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
