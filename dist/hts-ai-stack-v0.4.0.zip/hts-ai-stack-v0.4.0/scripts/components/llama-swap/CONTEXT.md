# llama-swap Component

Last updated: 2026-04-21

## What happens here

llama-swap is a lightweight model router/proxy that sits in front of
Ollama, enabling automatic model swapping and load balancing across
multiple model backends.

In this stack llama-swap runs in **peers mode** (`config/llama-swap.yaml`
→ `peers.ollama.models`). It proxies to the `hts-ai-ollama` container
via an OpenAI-compatible endpoint on host port `${LLAMA_SWAP_PORT}`
(default 8081 — see `.env`). Clients address models as
`openai/<ollama-tag>` (e.g. `openai/qwen2.5-coder:7b`); the literal
portion after `openai/` must match the exact Ollama tag including colon.

## Files and structure

| File | Purpose |
|------|---------|
| `llama-swap.sh` | Full lifecycle: install, configure, start, stop, health |
| `llama-swap.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Registered model tags

Models must be listed under `peers.ollama.models` in
`config/llama-swap.yaml` before llama-swap will proxy requests for them.
The canonical pulls (`pull_selected_models`, `pull_coding_tier` in
`scripts/wizard/model-select.sh`) land the GGUF into the Ollama data
volume; llama-swap only routes.

Current coder-tier additions (FEATURE-067, for Aider architect+editor):

- `qwen2.5-coder:7b` — editor tier
- `qwen2.5-coder:14b` — optional middle tier (≥ 16 GB VRAM)
- `deepseek-r1:14b` — architect / reasoning tier

See `docs/development/features/FEATURE-067.md` for the architect+editor
integration and `scripts/components/aider/CONTEXT.md` for the Aider
client config that consumes these tags.

See [usage.md](./usage.md) for command usage.
