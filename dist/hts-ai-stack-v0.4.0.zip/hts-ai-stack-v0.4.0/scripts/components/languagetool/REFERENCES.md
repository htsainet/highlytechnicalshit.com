# LanguageTool — References

## Upstream

| Resource | Link |
|----------|------|
| GitHub | <https://github.com/languagetool-org/languagetool> |
| Docker image | <https://hub.docker.com/r/erikvl87/languagetool> |
| API docs | <https://languagetool.org/http-api/> |
| Supported languages | <https://languagetool.org/languages/> |

## Internal

| Resource | Link |
|----------|------|
| Feature proposal | `docs/development/features/FEATURE-046.md` |
| Dockerfile | `docker/languagetool/Dockerfile` |
| Compose service | `docker-compose.yml` (profile: `languagetool`) |
| Port assignment | `config/portmap.json` → `8010` |
| Pester test | `tests/Test-LanguageTool.Tests.ps1` |
