# UFW Default-Deny + Bind Services to Localhost

**Priority:** HIGH
**Effort:** 6-8 hours
**Risk:** High — misconfigured UFW or missed port binding will cut off all LAN + Tailscale access. Requires careful rollout with console access available as fallback.
**Target Release:** v0.5.0
**Threat:** 12 of 16 stack services are unauthenticated and bound to `0.0.0.0`, meaning any device on the LAN can reach Ollama, llama-swap, Prometheus, DeerFlow, OpenSpace, and others with no credentials.
**Depends on:** Nothing — prerequisite for all other SECURITY-### features
**Blocks:** SECURITY-001 (Tailscale ACL needs ports locked first), SECURITY-003 (fail2ban needs UFW in place)

## Problem

Every Docker service publishes to `0.0.0.0` (all interfaces) by default. The install scripts
do not configure UFW, leaving services fully accessible to any LAN host. The comments in
`docker-compose.yml` say "UFW restricts LAN access" — but no UFW rules are actually deployed.

Services with no authentication currently reachable from any LAN device:

| Service | Port | Auth |
|---------|------|------|
| Ollama | 11434 | None |
| llama-swap | 8081 | None |
| BitNet | 8082 | None |
| Prometheus | 9090 | None |
| OpenSpace MCP | 5000 | None |
| OpenSpace dashboard | 3001 | None |
| DeerFlow backend | 8003 | None |
| Dashboard (nginx) | 80 | None |
| Stable Diffusion | 7860 | None |
| Unsloth Studio | 8888 | None |
| cAdvisor | (internal) | None |

## Solution

Two complementary changes applied together:

1. **Bind services to `127.0.0.1`** in `docker-compose.yml` — services only accessible locally or
   via Tailscale (which routes through the Tailscale network interface, not the LAN interface)
2. **Enable UFW default-deny** with explicit allowlists for SSH and the Tailscale interface

## Docker Caveat

Docker bypasses UFW's `INPUT` chain by inserting rules directly into `iptables` via the
`DOCKER` chain. Simply running `ufw deny 11434` does **not** block Docker-published ports.
The correct fix is to bind services to `127.0.0.1` at the Compose level — Docker will only
publish to localhost, which is not reachable from the network regardless of UFW state.

## Implementation Steps

### 1. Add `scripts/host/ufw.sh`

Create a host-level UFW configuration script:

```bash
# Enable UFW with default deny-incoming, allow SSH and Tailscale
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow in on tailscale0
ufw --force enable
```

### 2. Update `docker-compose.yml` port bindings

Change all `"0.0.0.0:PORT:PORT"` bindings to `"127.0.0.1:PORT:PORT"`.
Services already accessed via Tailscale will continue to work — Tailscale routes traffic
through the host interface, not directly to Docker ports.

Services that need LAN access (none currently identified) would be explicitly whitelisted.

### 3. Update `scripts/install/07-setup-connectivity.sh`

Call `ufw.sh` during install after Docker services start.

### 4. Rollback plan

```bash
ufw --force reset
ufw disable
```

Console access (or Tailscale SSH from a trusted device) should be confirmed working before
UFW is enabled. Do not enable UFW over an untrusted SSH session.

## Acceptance Criteria

- All services are unreachable from LAN IP (confirmed via `nmap` from another host)
- SSH still works from Tailscale-connected device
- All stack services still work locally (Open WebUI, Grafana, etc.)
- `ufw status` shows `Status: active` with default deny incoming
- Tailscale rule in place: `allow in on tailscale0`
