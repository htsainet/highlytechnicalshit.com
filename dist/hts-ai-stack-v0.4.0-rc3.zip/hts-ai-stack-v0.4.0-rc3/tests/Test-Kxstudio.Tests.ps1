$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/kxstudio'
    $script:ComponentScript = Join-Path $script:ComponentDir 'kxstudio.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'kxstudio.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'kxstudio file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }

    It 'CONTEXT.md exists' {
        Join-Path $script:RepoRoot 'CONTEXT.md' | Should -Exist
    }

    It 'REFERENCES.md exists' {
        Join-Path $script:RepoRoot 'REFERENCES.md' | Should -Exist
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'kxstudio component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines kxstudio_install function' {
        $script:ComponentContent | Should -Match 'kxstudio_install\s*\(\)'
    }

    It 'defines kxstudio_configure function' {
        $script:ComponentContent | Should -Match 'kxstudio_configure\s*\(\)'
    }

    It 'defines kxstudio_start function' {
        $script:ComponentContent | Should -Match 'kxstudio_start\s*\(\)'
    }

    It 'defines kxstudio_stop function' {
        $script:ComponentContent | Should -Match 'kxstudio_stop\s*\(\)'
    }

    It 'defines kxstudio_health function' {
        $script:ComponentContent | Should -Match 'kxstudio_health\s*\(\)'
    }

    It 'defines kxstudio_restart function' {
        $script:ComponentContent | Should -Match 'kxstudio_restart\s*\(\)'
    }

    It 'defines kxstudio_destroy function' {
        $script:ComponentContent | Should -Match 'kxstudio_destroy\s*\(\)'
    }

    It 'defines kxstudio_status function' {
        $script:ComponentContent | Should -Match 'kxstudio_status\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/kxstudio/kxstudio\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'kxstudio no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/kxstudio\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/kxstudio/kxstudio\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
