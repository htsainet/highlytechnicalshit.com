"""CogVideoX — Gradio web UI for text-to-video generation."""

import os
import torch
import gradio as gr
import imageio

MODEL_ID = os.environ.get("COGVIDEOX_MODEL", "THUDM/CogVideoX-2b")
PORT = int(os.environ.get("COGVIDEOX_PORT", "7865"))

pipe = None


def load_pipeline():
    global pipe
    if pipe is None:
        from diffusers import CogVideoXPipeline

        pipe = CogVideoXPipeline.from_pretrained(
            MODEL_ID, torch_dtype=torch.float16
        ).to("cuda")
        pipe.enable_model_cpu_offload()
    return pipe


def generate_video(prompt: str, num_frames: int = 49, guidance_scale: float = 6.0):
    """Generate a video from a text description."""
    p = load_pipeline()

    video_frames = p(
        prompt=prompt,
        num_frames=min(num_frames, 49),
        guidance_scale=guidance_scale,
        num_inference_steps=50,
    ).frames[0]

    output_path = "/tmp/cogvideox_output.mp4"
    imageio.mimsave(output_path, video_frames, fps=8, codec="libx264")
    return output_path


with gr.Blocks(title="CogVideoX") as app:
    gr.Markdown("# 🎬 CogVideoX")
    gr.Markdown(f"Text-to-video generation powered by **{MODEL_ID}**")

    prompt_input = gr.Textbox(
        label="Describe the video you want",
        placeholder="e.g., A golden retriever playing in a field of sunflowers on a sunny day",
    )
    with gr.Row():
        frames_input = gr.Slider(
            minimum=9, maximum=49, value=49, step=8, label="Frames"
        )
        guidance_input = gr.Slider(
            minimum=1.0, maximum=15.0, value=6.0, step=0.5, label="Guidance Scale"
        )
    generate_btn = gr.Button("Generate Video", variant="primary")
    video_output = gr.Video(label="Generated Video")
    generate_btn.click(
        generate_video,
        inputs=[prompt_input, frames_input, guidance_input],
        outputs=video_output,
    )

if __name__ == "__main__":
    app.launch(server_name="0.0.0.0", server_port=PORT)
