#!/usr/bin/env bash
# scripts/components/vosk/vosk.sh — Vosk: install, configure, start, health
#
# Vosk — offline CPU speech-to-text via gRPC. Lightweight alternative to
# Faster-Whisper for low-latency, low-resource STT without GPU.
#
# Standalone usage:
#   ./scripts/components/vosk/vosk.sh              # full: install + configure + start + health
#   ./scripts/components/vosk/vosk.sh --install    # install only (build image)
#   ./scripts/components/vosk/vosk.sh --configure  # configure only
#   ./scripts/components/vosk/vosk.sh --start      # start only
#   ./scripts/components/vosk/vosk.sh --stop       # stop
#   ./scripts/components/vosk/vosk.sh --restart    # restart (stop + start)
#   ./scripts/components/vosk/vosk.sh --health     # health check only
#   ./scripts/components/vosk/vosk.sh --status     # show status + port + health
#   ./scripts/components/vosk/vosk.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
VOSK_PORT="${VOSK_PORT:-2700}"

# ── Functions ────────────────────────────────────────────────────────────────

vosk_install() {
  step "Vosk — install"
  compose_pull --profile vosk 2>/dev/null || true
  compose_build --profile vosk 2>/dev/null || true
  ok "Vosk image ready."
}

vosk_configure() {
  step "Vosk — configure"
  info "gRPC port: ${VOSK_PORT}"
  info "CPU-only — no GPU required"
  info "Supports 20+ languages"

  local models_dir="$REPO_DIR/data/vosk/models"
  mkdir -p "$models_dir"

  ok "Vosk configured."
}

vosk_start() {
  step "Vosk — start"
  compose_up --profile vosk
  ok "Vosk started on port ${VOSK_PORT}."
}

vosk_stop() {
  step "Vosk — stop"
  compose_down --profile vosk
  ok "Vosk stopped."
}

vosk_health() {
  local label="Vosk :${VOSK_PORT}"
  printf "  %-35s" "$label"
  # Vosk uses WebSocket on the gRPC port — check if port is listening
  if ss -tlnp 2>/dev/null | grep -q ":${VOSK_PORT} " || \
     docker ps -qf "label=com.docker.compose.service=vosk" &>/dev/null | grep -q .; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (port ${VOSK_PORT} not listening)"
    return 1
  fi
}

vosk_restart() {
  vosk_stop
  vosk_start
}

vosk_destroy() {
  step "Vosk — destroy"
  compose_down --profile vosk -v
  ok "Vosk destroyed."
}

vosk_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=vosk" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Vosk is running (port ${VOSK_PORT})"
  else
    warn "Vosk is not running."
  fi
  vosk_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   vosk_install   ;;
    configure) vosk_configure ;;
    start)     vosk_start     ;;
    stop)      vosk_stop      ;;
    restart)   vosk_restart   ;;
    health)    vosk_health    ;;
    status)    vosk_status    ;;
    destroy)   vosk_destroy   ;;
    default)
      vosk_install
      vosk_configure
      vosk_start
      vosk_health
      ;;
  esac
fi
