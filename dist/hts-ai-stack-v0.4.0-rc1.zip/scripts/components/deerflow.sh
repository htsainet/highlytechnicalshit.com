#!/usr/bin/env bash
# scripts/components/deerflow.sh — DeerFlow agent workflow harness
#
# Standalone usage:
#   ./scripts/components/deerflow.sh            # install + configure + start + health
#   ./scripts/components/deerflow.sh --health   # health check only
#   ./scripts/components/deerflow.sh --stop     # stop DeerFlow
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
DEERFLOW_CONTAINER="${DEERFLOW_CONTAINER:-hts-ai-deerflow}"
DEERFLOW_PORT="${DEERFLOW_PORT:-3002}"
DEERFLOW_BACKEND_PORT="${DEERFLOW_BACKEND_PORT:-8003}"

# ── Functions ────────────────────────────────────────────────────────────────

# deerflow_install — Pull DeerFlow + sandbox images via compose
deerflow_install() {
  step "DeerFlow — install"
  compose_pull --profile deerflow
  ok "DeerFlow images pulled."
}

# deerflow_configure — Validate configuration
deerflow_configure() {
  step "DeerFlow — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^DEERFLOW_PORT=" "$env_file" 2>/dev/null; then
    printf 'DEERFLOW_PORT=%s\n' "$DEERFLOW_PORT" >> "$env_file"
    info "Added DEERFLOW_PORT=${DEERFLOW_PORT} to .env"
  fi

  info "Web UI port: ${DEERFLOW_PORT}"
  info "Backend port: ${DEERFLOW_BACKEND_PORT}"
  ok "DeerFlow configured."
}

# deerflow_start — Bring up DeerFlow + sandbox via compose
deerflow_start() {
  step "DeerFlow — start"
  compose_up --profile deerflow
  ok "DeerFlow started (UI :${DEERFLOW_PORT}, backend :${DEERFLOW_BACKEND_PORT})."
}

# deerflow_stop — Bring down DeerFlow + sandbox
deerflow_stop() {
  step "DeerFlow — stop"
  compose_down --profile deerflow
  ok "DeerFlow stopped."
}

# deerflow_health — Probe the DeerFlow web UI
deerflow_health() {
  health_probe "DeerFlow :${DEERFLOW_PORT}" "http://localhost:${DEERFLOW_PORT}/"
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      deerflow_install
      deerflow_configure
      deerflow_start
      deerflow_health
      ;;
    health)
      deerflow_health
      ;;
    stop)
      deerflow_stop
      ;;
  esac
fi
