# Telegram References

Last updated: 2026-04-15

## Upstream

- [Telegram Bot API](https://core.telegram.org/bots/api)

## Official documentation

- [Telegram Bot API Docs](https://core.telegram.org/bots)
- [BotFather — Create a Bot](https://core.telegram.org/bots/tutorial)
