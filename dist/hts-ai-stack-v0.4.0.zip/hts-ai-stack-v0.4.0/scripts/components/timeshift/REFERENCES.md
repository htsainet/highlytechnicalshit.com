# Timeshift References

Last updated: 2026-04-15

## Upstream

- [GitHub — linuxmint/timeshift](https://github.com/linuxmint/timeshift)

## Official documentation

- [Timeshift README](https://github.com/linuxmint/timeshift#readme)
