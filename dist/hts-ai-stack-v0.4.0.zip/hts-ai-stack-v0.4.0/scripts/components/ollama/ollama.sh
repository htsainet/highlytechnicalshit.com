#!/usr/bin/env bash
# scripts/components/ollama/ollama.sh — Ollama LLM inference: install, models, health
#
# Standalone usage:
#   ./scripts/components/ollama/ollama.sh                  # full: install + configure + start + health
#   ./scripts/components/ollama/ollama.sh --install        # install only
#   ./scripts/components/ollama/ollama.sh --configure      # configure only
#   ./scripts/components/ollama/ollama.sh --start          # start only
#   ./scripts/components/ollama/ollama.sh --stop           # stop
#   ./scripts/components/ollama/ollama.sh --restart        # restart (stop + start)
#   ./scripts/components/ollama/ollama.sh --health         # health check only
#   ./scripts/components/ollama/ollama.sh --status         # show status + port + health
#   ./scripts/components/ollama/ollama.sh --destroy        # destroy (remove containers + volumes)
#   ./scripts/components/ollama/ollama.sh --pull-models    # pull all prod models from registry
#   ./scripts/components/ollama/ollama.sh --warm           # pull + warm configured $OLLAMA_MODEL
#   ./scripts/components/ollama/ollama.sh --fix-templates  # fix missing chat templates on hf.co/* models
#   ./scripts/components/ollama/ollama.sh --fix-templates --all  # fix templates on ALL models
#
# Template auto-fix:
#   HuggingFace GGUF pulls (hf.co/...) sometimes lack a chat template in their
#   metadata.  Ollama then falls back to raw completion mode — no TEMPLATE
#   wrapping, no stop tokens — causing raw [INST]/[/INST] tokens to bleed into
#   responses.  _ollama_fix_template_for detects the prompt family from the GGUF
#   architecture field and patches the model's Ollama manifest in-place (weights
#   are reused; only the template metadata changes).  It runs automatically after
#   every successful hf.co/* pull, and can be run in batch via --fix-templates.
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"
source "$REPO_DIR/scripts/lib/assert-postcondition.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
OLLAMA_CONTAINER="${OLLAMA_CONTAINER:-hts-ai-ollama}"
OLLAMA_PORT="${OLLAMA_PORT:-11434}"
OLLAMA_BASE_URL="${OLLAMA_BASE_URL:-http://localhost:${OLLAMA_PORT}}"
OLLAMA_MODEL="${OLLAMA_MODEL:-smollm2:135m}"
REGISTRY_FILE="$REPO_DIR/scripts/install/models/registry.json"

# ── Functions ─────────────────────────────────────────────────────────────────

# ollama_install — Pull the Ollama Docker image via compose
ollama_install() {
  step "Ollama — build image"
  compose_build --profile ollama-gpu
  ok "Ollama image built."
}

# ollama_configure — Ensure .env has required Ollama keys
ollama_configure() {
  step "Ollama — configure"
  local env_file="$REPO_DIR/.env"

  _ensure_key() {
    local key="$1" default="$2"
    if ! grep -q "^${key}=" "$env_file" 2>/dev/null; then
      printf '%s=%s\n' "$key" "$default" >> "$env_file"
      info "Added ${key}=${default} to .env"
    fi
  }

  _ensure_key "OLLAMA_PORT" "$OLLAMA_PORT"
  _ensure_key "OLLAMA_BASE_URL" "$OLLAMA_BASE_URL"
  _ensure_key "OLLAMA_MODEL" "$OLLAMA_MODEL"
  ok "Ollama .env keys verified."
}

# ollama_start — Bring up Ollama via compose (with exclusivity guard)
ollama_start() {
  step "Ollama — start"
  compose_up --profile ollama-gpu
  ok "Ollama container started."

  # Pull the tiny starter model (smollm2) and the main NemoClaw model (mistral-nemo)
  # Run pulls in background so they can happen concurrently while the container warms up.
  info "Pulling starter model smollm2:135m in background..."
  docker compose -f "$REPO_DIR/docker-compose.yml" exec -T ollama ollama pull smollm2:135m &
  pull_smoll_pid=$!

  info "Pulling NemoClaw model mistral-nemo:latest in background..."
  docker compose -f "$REPO_DIR/docker-compose.yml" exec -T ollama ollama pull mistral-nemo:latest &
  pull_mistral_pid=$!

  # Wait for both pulls to complete, but do not abort the whole start if they fail.
  wait $pull_smoll_pid || warn "Background pull of smollm2 failed."
  wait $pull_mistral_pid || warn "Background pull of mistral-nemo failed."
}

# ollama_stop — Bring down Ollama
ollama_stop() {
  step "Ollama — stop"
  compose_down --profile ollama-gpu
  ok "Ollama stopped."
}

# ollama_health — Probe the Ollama API, then ensure the starter model is present.
ollama_health() {
  health_probe "Ollama :${OLLAMA_PORT}" "${OLLAMA_BASE_URL}/api/tags"
  # After the API is reachable, make sure the *configured* $OLLAMA_MODEL is
  # actually pulled. This is the hot path every reconciler action hits, so
  # it's where we catch "OLLAMA_MODEL changed on a running stack but nobody
  # ever pulled the new value" — the bug behind today's NemoClaw onboard
  # failure. Idempotent: no-op when the model is already in /api/tags.
  ollama_ensure_models
}

# ollama_ensure_models — Converge-time guarantee that $OLLAMA_MODEL is pulled.
#
# Idempotent. Called from ollama_health (every reconciler pass) and as a
# belt-and-suspenders preflight from nemoclaw.sh before onboard validation.
#
# Escape hatch: OLLAMA_SKIP_PULL=1 bypasses the whole function (for CI /
# no-network / air-gapped installs). The starter-present postcondition is
# then skipped too, because the user explicitly opted out.
#
# Timeouts:
#   - 60 s to wait for /api/tags (reusing health_probe is too chatty; we
#     just loop here).
#   - 300 s for the pull itself (_ollama_pull_if_missing drives `ollama pull`
#     which has its own streaming progress; we bound it here).
#
# The "model is present" check is wrapped in assert_postcondition from
# scripts/lib/assert-postcondition.sh so a silent pull-that-didn't-actually-
# land exits 2 with a useful diagnostic instead of letting downstream
# consumers 404 later.
ollama_ensure_models() {
  if [[ "${OLLAMA_SKIP_PULL:-0}" == "1" ]]; then
    info "OLLAMA_SKIP_PULL=1 — skipping starter-model ensure step."
    return 0
  fi

  local model="${OLLAMA_MODEL:-smollm2:135m}"

  # 1. Wait (up to 60 s) for /api/tags to answer. If Ollama isn't up,
  # nothing downstream can succeed anyway; fail loudly.
  local deadline=$(( $(date +%s) + 60 ))
  while (( $(date +%s) < deadline )); do
    if curl -fsS --max-time 3 "${OLLAMA_BASE_URL}/api/tags" >/dev/null 2>&1; then
      break
    fi
    sleep 2
  done
  if ! curl -fsS --max-time 3 "${OLLAMA_BASE_URL}/api/tags" >/dev/null 2>&1; then
    fail "ollama_ensure_models: ${OLLAMA_BASE_URL}/api/tags did not answer within 60 s"
  fi

  # 2. If the model is already present, we're done — fast path.
  if curl -fsS --max-time 3 "${OLLAMA_BASE_URL}/api/tags" 2>/dev/null \
       | jq -r '.models[].name' 2>/dev/null | grep -qxF "$model"; then
    ok "Starter model already present: ${model}"
    return 0
  fi

  # 3. Pull synchronously with a hard wall-clock budget. _ollama_pull_if_missing
  # handles registry/NAS-cache logic; we add the 300 s time cap by running
  # it as a background job and killing the process group if it overruns.
  step "Ollama — pulling starter model: ${model}"
  (
    _ollama_pull_if_missing "$model"
  ) &
  local pull_pid=$!
  local timeout_seconds=300
    [[ "$model" == *mistral-nemo* ]] && timeout_seconds=900
    local pull_deadline=$(( $(date +%s) + timeout_seconds ))
  while kill -0 "$pull_pid" 2>/dev/null; do
    if (( $(date +%s) >= pull_deadline )); then
      kill -TERM "$pull_pid" 2>/dev/null || true
      sleep 2
      kill -KILL "$pull_pid" 2>/dev/null || true
      wait "$pull_pid" 2>/dev/null || true
      fail "ollama_ensure_models: pull of ${model} did not complete within 300 s"
    fi
    sleep 2
  done
  wait "$pull_pid" || fail "ollama_ensure_models: pull of ${model} failed (see logs above)"

  # 4. Verify the real postcondition: is the model actually visible now?
  _probe_starter_in_tags() {
    curl -fsS --max-time 5 "${OLLAMA_BASE_URL}/api/tags" 2>/dev/null \
      | jq -r '.models[].name' 2>/dev/null \
      | grep -qxF "$model"
  }
  assert_postcondition "starter model ${model} present in /api/tags" _probe_starter_in_tags
}

# ollama_swap_model <model> — Pull and warm a specific model
ollama_swap_model() {
  local model="$1"
  echo -e "\n${CYAN}${BOLD}┌──────────────────────────────────────────────────┐${NC}"
  echo -e "${CYAN}${BOLD}│  Downloading model: ${model}$(printf '%*s' $((28 - ${#model})) '')│${NC}"
  echo -e "${CYAN}${BOLD}└──────────────────────────────────────────────────┘${NC}\n"
  docker compose -f "$REPO_DIR/docker-compose.yml" exec -T ollama ollama pull "$model" 2>&1
  info "Warming $model (10m keep_alive)..."
  curl -s "${OLLAMA_BASE_URL}/api/generate" \
    -d "{\"model\":\"${model}\",\"keep_alive\":\"10m\",\"prompt\":\"\"}" >/dev/null 2>&1 || true
  ok "ollama → $model loaded"
}

# ollama_pull_models [--all|--model NAME]
# Reads registry.json and pulls prod models. With --all pulls all envs.
ollama_pull_models() {
  local pull_all=false
  local specific_model=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --all)   pull_all=true; shift ;;
      --model) specific_model="$2"; shift 2 ;;
      *)       shift ;;
    esac
  done

  if [[ ! -f "$REGISTRY_FILE" ]]; then
    warn "Registry file not found: $REGISTRY_FILE — skipping model pull."
    return 0
  fi

  step "Ollama — pull models"

  if [[ -n "$specific_model" ]]; then
    _ollama_pull_if_missing "$specific_model"
    return
  fi

  local filter='.ollama[]'
  if [[ "$pull_all" == false ]]; then
    filter='.ollama[] | select(.env[] == "prod")'
  fi

  local models
  models=$(jq -r "$filter | .model" "$REGISTRY_FILE" 2>/dev/null) || {
    warn "Failed to parse registry.json"
    return 1
  }

  while IFS= read -r model; do
    [[ -z "$model" ]] && continue
    _ollama_pull_if_missing "$model"
  done <<< "$models"

  ok "Model pull complete."
}

# ── Internal helpers ──────────────────────────────────────────────────────────

# _ollama_pull_if_missing <model> — Pull a model if not already in Ollama
_ollama_pull_if_missing() {
  local model="$1"

  # Exact-name match against the full model identifier (including tag)
  local already_present=false
  if curl -s "${OLLAMA_BASE_URL}/api/tags" 2>/dev/null \
      | jq -r '.models[].name' 2>/dev/null | grep -qxF "$model"; then
    already_present=true
  fi

  if [[ "$already_present" == true ]]; then
    # Still run a template check for manually-pulled hf.co models
    if [[ "$model" == hf.co/* ]] && _ollama_needs_template_fix "$model"; then
      info "Fixing missing template for already-present model: $model"
      _ollama_fix_template_for "$model" > /dev/null
    fi
  else
    # Check NAS cache first
    local nas_cache="${NAS_MODEL_CACHE:-/mnt/htsai-model-backup/ollama/models}"
    if [[ -d "$nas_cache" ]] && docker compose -f "$REPO_DIR/docker-compose.yml" exec -T ollama test -d /home/ollama/.ollama/models 2>/dev/null; then
      info "Pulling $model (checking NAS cache at $nas_cache)..."
    fi
    echo -e "\n${CYAN}${BOLD}┌──────────────────────────────────────────────────┐${NC}"
    echo -e "${CYAN}${BOLD}│  Downloading model: ${model}$(printf '%*s' $((28 - ${#model})) '')│${NC}"
    echo -e "${CYAN}${BOLD}└──────────────────────────────────────────────────┘${NC}\n"
    if docker compose -f "$REPO_DIR/docker-compose.yml" exec -T ollama ollama pull "$model"; then
      ok "$model pulled."
      [[ "$model" == hf.co/* ]] && _ollama_fix_template_for "$model" > /dev/null
    else
      warn "$model failed to pull — check name/connectivity."
    fi
  fi
}


# ── Chat template auto-fix ────────────────────────────────────────────────────
#
# HuggingFace GGUF files embed a tokenizer.chat_template in Jinja2 format.
# Ollama converts it, but sometimes the conversion fails or the field is absent,
# leaving the model in raw completion mode (no template, no stop tokens).
#
# The functions below detect this and patch the Ollama manifest in-place:
#   FROM <existing-blob>   ← preserved from the original modelfile
#   TEMPLATE "..."         ← injected for the detected prompt family
#   PARAMETER stop "..."   ← one per required stop token
#
# Only models from a recognised prompt family are fixed (10 supported families:
# mistral, llama2, llama3, gemma, command-r, alpaca, deepseek-v1, falcon, phi2, chatml).
# Base, embedding, vision, and multimodal models are explicitly skipped.

# Known-bad model name fragments — skip template injection for these.
# base / embed / multimodal are anchored to word-like boundaries ([-_./:]
# or start/end of string) to avoid false positives on substrings like
# "codebase", "embedded", or "multimodality".
# Matches (should skip):
#   llama-3-8b-base, mistral-7b-base-v0.1, text-embed-model,
#   instruct-embed-model, openclip-vl-model, e5-large-v2, bge-large-en,
#   multimodal-clip-7b
# Does NOT match (must pass through):
#   codebase-7b-chat, mistralbase-v0.2 (unusual but real),
#   embedded-chat-7b, multimodality-7b-chat (contrived)
_SKIP_TEMPLATE_PATTERNS="(^|[-_./:])(base)([-_./:]|$)|(^|[-_./:])(embed)([-_./:]|$)|instruct-embed|vision|vl[-_]|[-_]vl[^a-z]|(^|[-_./:])(multimodal)([-_./:]|$)|e5-|bge-"

# _ollama_detect_prompt_family <model>
# Returns one of: mistral | llama3 | llama2 | gemma | command-r | alpaca | chatml | deepseek-v1 | falcon | phi2 | skip | unknown
# Detection order: GGUF architecture field → model name heuristics
_ollama_detect_prompt_family() {
  local model="$1"
  local lower="${model,,}"

  # Skip non-chat models regardless of architecture
  if printf '%s' "$lower" | grep -qE "$_SKIP_TEMPLATE_PATTERNS"; then
    echo "skip"
    return
  fi

  # Primary: read architecture from GGUF metadata via ollama show
  local raw_arch
  raw_arch=$(docker exec "$OLLAMA_CONTAINER" ollama show "$model" 2>/dev/null \
    | grep -i "^ *architecture" | tr -s '[:space:]' ' ' | cut -d' ' -f3 \
    | tr '[:upper:]' '[:lower:]' || true)
  [[ -z "$raw_arch" ]] && info "No architecture field for $model — falling back to name heuristic"

  case "$raw_arch" in
    mistral|mixtral)
      # mistral/mixtral arch covers the base Mistral-v1 Instruct models AND several
      # popular fine-tunes that override the prompt format to ChatML.  Route those
      # to chatml explicitly; only base Instruct variants keep Mistral v1.
      #   - OpenHermes-2 / OpenHermes-2.5              → ChatML (Teknium model card)
      #   - Nous-Hermes-2-*-Mistral / -Mixtral / -SOLAR → ChatML (Nous Research card)
      #   - Neural-Hermes / NeuralHermes-* DPO          → ChatML
      #   - dolphin-2.x-mistral / -mixtral              → ChatML (Eric Hartford card)
      #   - Mistral-7B-OpenOrca / SlimOrca              → ChatML (OpenOrca card)
      # Zephyr uses its own <|user|>/<|assistant|> format (not ChatML);  leave as
      # unknown so the operator supplies a dedicated Modelfile rather than get
      # close-but-wrong ChatML token bleed.
      if printf '%s' "$lower" | grep -qE "openhermes.?2|nous.?hermes.?2|neural.?hermes|dolphin.?2|open.?orca|slim.?orca"; then
        echo "chatml"
      elif printf '%s' "$lower" | grep -qE "zephyr"; then
        echo "unknown"
      else
        echo "mistral"
      fi
      return ;;
    llama)
      # llama arch covers llama2, llama3, deepseek-v1, and alpaca-format fine-tunes.
      # Order matters: llama3 → alpaca → deepseek → llama2. Alpaca must come
      # before llama2 so Vicuna / WizardLM / Beluga (all Llama-2 bases, all using
      # Alpaca prompt format) route to alpaca rather than llama2. Do not reorder
      # without re-tracing the name heuristics.
      if printf '%s' "$lower" | grep -qE "llama.?3|llama3|meta.llama.3"; then
        echo "llama3"
      elif printf '%s' "$lower" | grep -qE "alpaca|vicuna|wizard|beluga"; then
        echo "alpaca"
      elif printf '%s' "$lower" | grep -qE "deepseek"; then
        echo "deepseek-v1"
      elif printf '%s' "$lower" | grep -qE "llama.?2|llama2"; then
        echo "llama2"
      else
        echo "unknown"  # ambiguous llama — skip rather than guess
      fi
      return ;;
    gemma*)
      echo "gemma"; return ;;
    cohere*|command*)
      echo "command-r"; return ;;
    falcon*)
      echo "falcon"; return ;;
    phi2*)
      echo "phi2"; return ;;
    qwen2*|qwen3*|phi3*|phi4*)
      echo "chatml"; return ;;
    nemotron*)
      echo "chatml"; return ;;
  esac

  # Secondary: name-based heuristics (for models where show returns no arch)
  # Known ChatML fine-tunes must be checked BEFORE the mistral clause, because
  # their names also match "mistral"/"mixtral" and the arch shortcut is wrong.
  if printf '%s' "$lower" | grep -qE "openhermes.?2|nous.?hermes.?2|neural.?hermes|dolphin.?2|open.?orca|slim.?orca"; then
    echo "chatml"
  elif printf '%s' "$lower" | grep -qE "mistral|mixtral"; then
    echo "mistral"
  elif printf '%s' "$lower" | grep -qE "zephyr"; then
    echo "unknown"  # Zephyr format is not Mistral v1 and not pure ChatML
  elif printf '%s' "$lower" | grep -qE "llama.?3|llama3|meta.llama.3"; then
    echo "llama3"
  elif printf '%s' "$lower" | grep -qE "gemma"; then
    echo "gemma"
  elif printf '%s' "$lower" | grep -qE "command.r|command_r|cohere"; then
    echo "command-r"
  elif printf '%s' "$lower" | grep -qE "alpaca|vicuna|wizard(lm|_lm)?|beluga"; then
    echo "alpaca"
  elif printf '%s' "$lower" | grep -qE "llama.?2|llama2"; then
    echo "llama2"
  elif printf '%s' "$lower" | grep -qE "deepseek"; then
    echo "deepseek-v1"
  elif printf '%s' "$lower" | grep -qE "falcon"; then
    echo "falcon"
  elif printf '%s' "$lower" | grep -qE "phi.?[12]|phi1"; then
    echo "phi2"
  elif printf '%s' "$lower" | grep -qE "qwen[23]|phi[34]|nemotron|deepseek.v[23]"; then
    echo "chatml"
  else
    echo "unknown"
  fi
}

# _ollama_needs_template_fix <model>
# Returns 0 (true) if the model is missing a TEMPLATE in its Ollama manifest.
_ollama_needs_template_fix() {
  local model="$1"
  local modelfile
  modelfile=$(docker exec "$OLLAMA_CONTAINER" ollama show --modelfile "$model" 2>/dev/null)
  ! printf '%s' "$modelfile" | grep -q "^TEMPLATE"
}

# _ollama_fix_template_for <model>
# Injects the correct chat template and stop tokens into the model's manifest.
# For hf.co/* models, creates a sanitized local alias (e.g. openhermes-2-5-mistral-7b)
# because ollama create does not support the hf.co/ namespace as an output name.
# Weights blobs are reused unchanged; only the manifest metadata changes.
_ollama_fix_template_for() {
  local model="$1"

  local family
  family=$(_ollama_detect_prompt_family "$model")

  case "$family" in
    skip)
      info "Skipping template fix for non-chat model: $model"
      echo skip
      return 0 ;;
    unknown)
      warn "Cannot detect prompt family for $model — template fix skipped."
      echo unknown
      return 0 ;;
  esac

  # For hf.co/* models, ollama create rejects the hf.co/ namespace as an output
  # name.  Derive a sanitized local alias preserving the quantization tag so
  # different quants of the same model get distinct names:
  #   hf.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF:Q4_K_M → mistral-7b-instruct-v0.2-q4_k_m
  #   hf.co/x/Model-7B-GGUF  (no tag)                      → model-7b
  # Org is omitted from the alias; same-tag cross-org collisions are caught by
  # the collision guard below (refuses to overwrite a different FROM blob).
  local create_name="$model"
  if [[ "$model" == hf.co/* ]]; then
    local tag=""
    if [[ "$model" == *:* ]]; then
      tag="${model##*:}"
      tag="${tag,,}"
    fi
    create_name="${model#*/*/}"          # strip hf.co/org/ → Model-7B-GGUF:Q4_K_M
    create_name="${create_name%%:*}"     # strip :tag       → Model-7B-GGUF
    create_name="${create_name%-GGUF}"   # strip -GGUF      → Model-7B
    create_name="${create_name,,}"       # lowercase        → model-7b
    [[ -n "$tag" ]] && create_name="${create_name}-${tag}"  # → model-7b-q4_k_m
    info "Will register fixed model as local alias: $create_name"
  fi

  # Preserve the original FROM blob so the manifest does not self-reference
  local from_line
  from_line=$(docker exec "$OLLAMA_CONTAINER" ollama show --modelfile "$model" 2>/dev/null \
    | grep "^FROM " | head -1 || true)
  [[ -z "$from_line" ]] && from_line="FROM $model"

  # Collision guard: if the derived alias already exists but points at a different
  # FROM blob, refuse to overwrite (could be a different org's model at the same alias).
  local existing_from
  existing_from=$(docker exec "$OLLAMA_CONTAINER" ollama show --modelfile "$create_name" 2>/dev/null \
    | grep "^FROM " | head -1 || true)
  if [[ -n "$existing_from" && "$existing_from" != "$from_line" ]]; then
    warn "Alias $create_name already exists pointing at a different model — refusing to overwrite."
    warn "  existing: $existing_from"
    warn "  requested: $from_line"
    echo failed
    return 0
  fi

  # Idempotency: if the alias already exists with the same FROM and has a TEMPLATE,
  # skip re-creating (re-runs are safe but wasteful).
  if docker exec "$OLLAMA_CONTAINER" ollama show --modelfile "$create_name" 2>/dev/null \
       | grep -q "^TEMPLATE"; then
    info "Alias $create_name already has a TEMPLATE — skipping re-create."
    echo already_fixed
    return 0
  fi

  local template_block stops_block

  case "$family" in
    mistral)
      # Mistral v1 instruction format: <s>[INST] … [/INST] response </s>
      template_block='TEMPLATE """{{- if .System }}<s>[INST] {{ .System }} [/INST]</s>
{{- end }}{{- range $i, $_ := .Messages }}{{- if eq .Role "user" }}<s>[INST] {{ .Content }} [/INST]
{{- else if eq .Role "assistant" }} {{ .Content }}</s>
{{- end }}{{- end }}"""'
      stops_block='PARAMETER stop "</s>"
PARAMETER stop "[INST]"
PARAMETER stop "[/INST]"'
      ;;
    llama3)
      # Llama 3 / Meta format: <|start_header_id|>role<|end_header_id|>\n\ncontent<|eot_id|>
      template_block='TEMPLATE """{{- range $i, $_ := .Messages }}{{- if eq .Role "system" }}<|start_header_id|>system<|end_header_id|>

{{ .Content }}<|eot_id|>
{{- else if eq .Role "user" }}<|start_header_id|>user<|end_header_id|>

{{ .Content }}<|eot_id|>
{{- else if eq .Role "assistant" }}<|start_header_id|>assistant<|end_header_id|>

{{ .Content }}<|eot_id|>
{{- end }}{{- end }}<|start_header_id|>assistant<|end_header_id|>

"""'
      stops_block='PARAMETER stop "<|eot_id|>"
PARAMETER stop "<|end_of_text|>"'
      ;;
    llama2)
      # Llama 2 chat format: [INST] <<SYS>> system <</SYS>> user [/INST] response </s>
      template_block='TEMPLATE """{{- if .System }}[INST] <<SYS>>
{{ .System }}
<</SYS>>

{{ .Prompt }} [/INST]{{- else }}[INST] {{ .Prompt }} [/INST]{{- end }}"""'
      stops_block='PARAMETER stop "</s>"
PARAMETER stop "[INST]"
PARAMETER stop "[/INST]"'
      ;;
    chatml)
      # ChatML format: <|im_start|>role\ncontent<|im_end|>
      template_block='TEMPLATE """{{- range $i, $_ := .Messages }}{{- if eq .Role "system" }}<|im_start|>system
{{ .Content }}<|im_end|>
{{- else if eq .Role "user" }}<|im_start|>user
{{ .Content }}<|im_end|>
{{- else if eq .Role "assistant" }}<|im_start|>assistant
{{ .Content }}<|im_end|>
{{- end }}{{- end }}<|im_start|>assistant
"""'
      stops_block='PARAMETER stop "<|im_end|>"
PARAMETER stop "<|endoftext|>"'
      ;;
    gemma)
      # Gemma / Gemma 2 format: <start_of_turn>role\ncontent<end_of_turn>
      template_block='TEMPLATE """{{- range $i, $_ := .Messages }}{{- if eq .Role "system" }}<start_of_turn>user
{{ .Content }}<end_of_turn>
<start_of_turn>model
Understood.<end_of_turn>
{{- else if eq .Role "user" }}<start_of_turn>user
{{ .Content }}<end_of_turn>
<start_of_turn>model
{{- else if eq .Role "assistant" }}{{ .Content }}<end_of_turn>
{{- end }}{{- end }}"""'
      stops_block='PARAMETER stop "<end_of_turn>"
PARAMETER stop "<eos>"'
      ;;
    command-r)
      # Cohere Command-R format: <|START_OF_TURN_TOKEN|><|ROLE_TOKEN|>content<|END_OF_TURN_TOKEN|>
      template_block='TEMPLATE """{{- if .System }}<|START_OF_TURN_TOKEN|><|SYSTEM_TOKEN|>{{ .System }}<|END_OF_TURN_TOKEN|>{{ end }}{{- range $i, $_ := .Messages }}{{- if eq .Role "user" }}<|START_OF_TURN_TOKEN|><|USER_TOKEN|>{{ .Content }}<|END_OF_TURN_TOKEN|>{{- else if eq .Role "assistant" }}<|START_OF_TURN_TOKEN|><|CHATBOT_TOKEN|>{{ .Content }}<|END_OF_TURN_TOKEN|>{{- end }}{{- end }}<|START_OF_TURN_TOKEN|><|CHATBOT_TOKEN|>"""'
      stops_block='PARAMETER stop "<|END_OF_TURN_TOKEN|>"'
      ;;
    alpaca)
      # Alpaca/Vicuna instruction format: ### Instruction:\n...\n### Response:
      template_block='TEMPLATE """{{ if .System }}{{ .System }}
{{ end }}### Instruction:
{{ .Prompt }}

### Response:
"""'
      stops_block='PARAMETER stop "### Instruction:"
PARAMETER stop "### Input:"
PARAMETER stop "### Response:"'
      ;;
    deepseek-v1)
      # DeepSeek v1 / DeepSeek-Coder v1 format: User: ...\n\nAssistant:
      # Stop token uses full-width glyphs: ｜ (U+FF5C) and ▁ (U+2581) —
      # the ASCII form <|end_of_sentence|> never tokenizes to a single token.
      template_block='TEMPLATE """{{- if .System }}{{ .System }}
{{ end }}{{- range $i, $_ := .Messages }}{{- if eq .Role "user" }}User: {{ .Content }}

{{- else if eq .Role "assistant" }}
Assistant: {{ .Content }}<｜end▁of▁sentence｜>
{{- end }}{{- end }}
Assistant:"""'
      stops_block='PARAMETER stop "<｜end▁of▁sentence｜>"
PARAMETER stop "User:"
PARAMETER stop "Assistant:"'
      ;;
    falcon)
      # Falcon format: User: ...\nFalcon: (TII, v1 instruct models)
      template_block='TEMPLATE """{{- if .System }}System: {{ .System }}
{{ end }}{{- range $i, $_ := .Messages }}{{- if eq .Role "user" }}User: {{ .Content }}
Falcon:{{- else if eq .Role "assistant" }} {{ .Content }}
{{- end }}{{- end }}"""'
      stops_block='PARAMETER stop "User:"
PARAMETER stop "Falcon:"
PARAMETER stop "Assistant:"'
      ;;
    phi2)
      # Phi-1.5 / Phi-2 format: Instruct: ...\nOutput:
      template_block='TEMPLATE """{{ if .System }}{{ .System }}
{{ end }}Instruct: {{ .Prompt }}
Output:"""'
      stops_block='PARAMETER stop "Instruct:"
PARAMETER stop "Output:"'
      ;;
  esac

  info "Applying $family chat template → $create_name..."
  if printf '%s\n%s\n%s\n' "$from_line" "$template_block" "$stops_block" \
    | docker exec -i "$OLLAMA_CONTAINER" ollama create "$create_name" -f - >/dev/null 2>&1; then
    ok "Template fixed: $create_name ($family) [source: $model]"
    echo fixed
  else
    warn "Template fix failed for $model"
    echo failed
  fi
}

# ollama_fix_templates [--all]
# Scans all models (or only hf.co/* without --all) and fixes missing templates.
ollama_fix_templates() {
  local hf_only=true
  [[ "${1:-}" == "--all" ]] && hf_only=false

  local scope_label=" (all models)"
  [[ "$hf_only" == true ]] && scope_label=" (hf.co/* only)"
  step "Ollama — fix chat templates${scope_label}"

  local models
  models=$(curl -s "${OLLAMA_BASE_URL}/api/tags" 2>/dev/null \
    | jq -r '.models[].name' 2>/dev/null) || {
    warn "Could not list models from Ollama API — is Ollama running?"
    return 1
  }

  local fixed=0 already_fixed=0 skipped=0 unknown=0 failed=0 already_ok=0
  while IFS= read -r model; do
    [[ -z "$model" ]] && continue
    [[ "$hf_only" == true && "$model" != hf.co/* ]] && continue
    if _ollama_needs_template_fix "$model"; then
      local status
      status=$(_ollama_fix_template_for "$model")
      case "$status" in
        fixed)         fixed=$((fixed+1)) ;;
        already_fixed) already_fixed=$((already_fixed+1)) ;;
        skip)          skipped=$((skipped+1)) ;;
        unknown)       unknown=$((unknown+1)) ;;
        failed)        failed=$((failed+1)) ;;
        *)             warn "Unexpected status '$status' from fix for $model"; failed=$((failed+1)) ;;
      esac
    else
      info "Template OK: $model"
      already_ok=$((already_ok + 1))
    fi
  done <<< "$models"

  ok "Template scan complete — fixed:$fixed already_fixed:$already_fixed skipped:$skipped unknown:$unknown failed:$failed already_ok:$already_ok"
}

ollama_restart() {
  ollama_stop
  ollama_start
}

ollama_destroy() {
  step "Ollama — destroy"
  compose_down --profile ollama-gpu -v
  ok "Ollama destroyed."
}

ollama_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=ollama" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Ollama is running (port ${OLLAMA_PORT})"
  else
    warn "Ollama is not running."
  fi
  ollama_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"
  FIX_ALL=false

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)       ACTION="install";       shift ;;
      --configure)     ACTION="configure";     shift ;;
      --start)         ACTION="start";         shift ;;
      --stop)          ACTION="stop";          shift ;;
      --restart)       ACTION="restart";       shift ;;
      --health)        ACTION="health";        shift ;;
      --status)        ACTION="status";        shift ;;
      --destroy)       ACTION="destroy";       shift ;;
      --pull-models)   ACTION="pull";          shift ;;
      --warm)          ACTION="warm";          shift ;;
      --fix-templates) ACTION="fix-templates"; shift ;;
      --all)           FIX_ALL=true;           shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)       ollama_install   ;;
    configure)     ollama_configure ;;
    start)         ollama_start     ;;
    stop)          ollama_stop      ;;
    restart)       ollama_restart   ;;
    health)        ollama_health    ;;
    status)        ollama_status    ;;
    destroy)       ollama_destroy   ;;
    pull)          ollama_pull_models --all ;;
    warm)          ollama_swap_model "$OLLAMA_MODEL" ;;
    fix-templates)
      if [[ "$FIX_ALL" == true ]]; then
        ollama_fix_templates --all
      else
        ollama_fix_templates
      fi
      ;;
    default)
      ollama_install
      ollama_configure
      ollama_start
      ollama_health
      ;;
  esac
fi
