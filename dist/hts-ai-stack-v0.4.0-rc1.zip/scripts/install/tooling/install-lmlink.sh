#!/usr/bin/env bash
# install-lmlink.sh — Enable LM Link in LM Studio and start the local server
#
# LM Link allows external apps (e.g. browser extensions, IDEs) to connect to
# LM Studio's local inference server.
#
# Usage:
#   ./install-lmlink.sh

set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

# ── Step 1: Check lms is installed ────────────────────────────────────────────
step "1 — Check lms CLI"

if ! command -v lms &>/dev/null; then
  if [ -x "$HOME/.lmstudio/bin/lms" ]; then
    export PATH="$HOME/.lmstudio/bin:$PATH"
    info "Added ~/.lmstudio/bin to PATH for this session."
  else
    echo "lms CLI not found. Run scripts/install/tooling/install-lmstudio.sh first." >&2
    exit 1
  fi
fi

info "lms CLI found: $(command -v lms)"

# ── Step 2: Enable LM Link (requires UI) ─────────────────────────────────────
step "2 — Enable LM Link"

info "LM Link must be enabled through the LM Studio UI (one-time setup):"
echo ""
echo "    1. Open LM Studio"
echo "    2. Click the plug icon (LM Link) in the left sidebar"
echo "    3. Toggle 'Enable LM Link' to ON"
echo "    4. Approve any browser extension prompts that appear"
echo ""
warn "This step requires the LM Studio desktop app. Cannot be automated."

# ── Step 3: Start LM Studio local server ─────────────────────────────────────
step "3 — Start LM Studio server"

info "Starting LM Studio local inference server on port 1234..."
lms server start

info "LM Studio server is running."
echo ""
info "API endpoint:  http://localhost:1234/v1"
info "OpenAI-compatible — use with any app that supports custom API base URLs."
echo ""
info "To stop the server:  lms server stop"
info "To check status:     lms server status"
