#!/usr/bin/env bash
# scripts/components/languagetool/languagetool.sh — LanguageTool: offline grammar & style checker API
#
# Standalone usage:
#   ./scripts/components/languagetool/languagetool.sh                # full: install + configure + start + health
#   ./scripts/components/languagetool/languagetool.sh --install      # install only
#   ./scripts/components/languagetool/languagetool.sh --configure    # configure only
#   ./scripts/components/languagetool/languagetool.sh --start        # start only
#   ./scripts/components/languagetool/languagetool.sh --stop         # stop
#   ./scripts/components/languagetool/languagetool.sh --restart      # restart (stop + start)
#   ./scripts/components/languagetool/languagetool.sh --health       # health check only
#   ./scripts/components/languagetool/languagetool.sh --status       # show status + port + health
#   ./scripts/components/languagetool/languagetool.sh --destroy      # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
LANGUAGETOOL_PORT="${LANGUAGETOOL_PORT:-8010}"
LANGUAGETOOL_CONTAINER="${LANGUAGETOOL_CONTAINER:-hts-ai-languagetool}"

# ── Functions ─────────────────────────────────────────────────────────────────

languagetool_install() {
  step "LanguageTool — build image"
  compose_build --profile languagetool
  ok "LanguageTool image built."
}

languagetool_configure() {
  step "LanguageTool — configure"
  info "No additional configuration needed — runs with default English + auto-detected languages."
  ok "LanguageTool configured."
}

languagetool_start() {
  step "LanguageTool — start"
  info "Starting containers..."
  compose_up --profile languagetool
  ok "LanguageTool started on port ${LANGUAGETOOL_PORT}."
}

languagetool_stop() {
  step "LanguageTool — stop"
  compose_down --profile languagetool
  ok "LanguageTool stopped."
}

languagetool_restart() {
  languagetool_stop
  languagetool_start
}

languagetool_health() {
  step "LanguageTool — health check"
  health_probe "LanguageTool :${LANGUAGETOOL_PORT}" "http://localhost:${LANGUAGETOOL_PORT}/v2/languages" 30 2
}

languagetool_status() {
  step "LanguageTool — status"
  local cid
  cid=$(docker ps -qf "name=${LANGUAGETOOL_CONTAINER}" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    info "Container: running ($cid)"
    info "Port:      ${LANGUAGETOOL_PORT}"
    languagetool_health
  else
    warn "Container: not running"
  fi
}

languagetool_destroy() {
  step "LanguageTool — destroy"
  compose_down --profile languagetool -v
  ok "LanguageTool destroyed (containers + volumes removed)."
}

# ── CLI dispatch ──────────────────────────────────────────────────────────────
ACTION=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --install)   ACTION="install";   shift ;;
    --configure) ACTION="configure"; shift ;;
    --start)     ACTION="start";     shift ;;
    --stop)      ACTION="stop";      shift ;;
    --restart)   ACTION="restart";   shift ;;
    --health)    ACTION="health";    shift ;;
    --status)    ACTION="status";    shift ;;
    --destroy)   ACTION="destroy";   shift ;;
    *) shift ;;
  esac
done

case "${ACTION:-default}" in
  install)   languagetool_install   ;;
  configure) languagetool_configure ;;
  start)     languagetool_start     ;;
  stop)      languagetool_stop      ;;
  restart)   languagetool_restart   ;;
  health)    languagetool_health    ;;
  status)    languagetool_status    ;;
  destroy)   languagetool_destroy   ;;
  default)   languagetool_install; languagetool_configure; languagetool_start; languagetool_health ;;
esac
