# Faster-Whisper References

Last updated: 2026-04-15

## Upstream

- [GitHub — SYSTRAN/faster-whisper](https://github.com/SYSTRAN/faster-whisper)
- [GitHub — speaches-ai/speaches](https://github.com/speaches-ai/speaches)
  (OpenAI-compat wrapper used in this stack)

## Official documentation

- [Faster-Whisper README](https://github.com/SYSTRAN/faster-whisper#readme)
- [speaches README](https://github.com/speaches-ai/speaches#readme)

## Related

- See [FEATURE-026](../../../docs/development/features/FEATURE-026.md)
  for the original feature proposal.
