$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/coqui-tts'
    $script:ComponentScript = Join-Path $script:ComponentDir 'coqui-tts.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'coqui-tts.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'coqui-tts file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'coqui-tts manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is coqui-tts' {
        $script:Manifest.id | Should -Be 'coqui-tts'
    }

    It 'category is audio' {
        $script:Manifest.category | Should -Be 'audio'
    }

    It 'profile is coqui-tts' {
        $script:Manifest.profile | Should -Be 'coqui-tts'
    }

    It 'dashboard port is 5002' {
        [int]$script:Manifest.dashboard.port | Should -Be 5002
    }

    It 'health URL targets healthcheck endpoint' {
        $script:Manifest.health.url | Should -Match 'healthcheck'
    }

    It 'script path points to component subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/coqui-tts/coqui-tts.sh'
    }

    It 'install_type is compose' {
        $script:Manifest.install_type | Should -Be 'compose'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'coqui-tts port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 5002 is registered in portmap.json' {
        $script:Portmap.ports.'5002' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'5002'.service | Should -Be 'coqui-tts'
    }
}

# ── CLI flags ────────────────────────────────────────────────────────────────

Describe 'coqui-tts CLI flags' {

    BeforeAll {
        $script:ScriptContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'supports --install flag' {
        $script:ScriptContent | Should -Match '--install'
    }

    It 'supports --configure flag' {
        $script:ScriptContent | Should -Match '--configure'
    }

    It 'supports --start flag' {
        $script:ScriptContent | Should -Match '--start'
    }

    It 'supports --stop flag' {
        $script:ScriptContent | Should -Match '--stop'
    }

    It 'supports --restart flag' {
        $script:ScriptContent | Should -Match '--restart'
    }

    It 'supports --health flag' {
        $script:ScriptContent | Should -Match '--health'
    }

    It 'supports --status flag' {
        $script:ScriptContent | Should -Match '--status'
    }

    It 'supports --destroy flag' {
        $script:ScriptContent | Should -Match '--destroy'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'coqui-tts compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'coqui-tts service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'coqui-tts:'
    }

    It 'uses coqui-tts profile' {
        $script:ComposeContent | Should -Match 'coqui-tts'
    }

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/coqui-tts/Dockerfile' | Should -Exist
    }
}
