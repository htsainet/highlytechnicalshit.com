# Ollama Component

Last updated: 2026-04-15

## What happens here

Ollama is the primary local LLM runtime for the stack. It downloads,
manages, and serves large language models with GPU acceleration via
CUDA. All chat and inference traffic routes through Ollama.

## Files and structure

| File | Purpose |
|------|---------|
| `ollama.sh` | Full lifecycle: install, configure, start, stop, health, pull-models, swap |
| `ollama.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
