#!/usr/bin/env bash
# 06-start-stack.sh — Thin orchestrator: delegates to component scripts.
#
# Usage:
#   ./06-start-stack.sh                 # default: --chat mean
#   ./06-start-stack.sh --chat lean     # smollm2:135m, ~500MB VRAM
#   ./06-start-stack.sh --chat mean     # gemma4:e4b, ~7-8GB VRAM (default)
#   ./06-start-stack.sh --chat claw     # deepseek-r1:14b, ~9GB VRAM, reasoning/agent
#
# Stack: dashboard (first) + ollama/bitnet + open-webui + NemoClaw + monitoring + portainer
#
# Backend selection:
#   Set BACKEND_ENGINE=ollama (default) or BACKEND_ENGINE=bitnet in .env

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"
source "$REPO_DIR/scripts/lib/installstatus.sh"

banner "06 — Start Stack"

warn "DEPRECATED: 06-start-stack.sh is no longer the authoritative runtime path."
warn "Use scripts/utils/converge.sh for stack management instead."
warn "This script is retained for initial install pipeline compatibility only."
echo ""

# ── Parse --chat flag ─────────────────────────────────────────────────────────
CHAT_MODE="mean"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --chat)
      [[ $# -ge 2 ]] || { fail "--chat requires lean|mean|claw"; exit 1; }
      CHAT_MODE="$2"; shift 2 ;;
    *) fail "Unknown argument: $1"; exit 1 ;;
  esac
done
case "$CHAT_MODE" in lean|mean|claw) ;; *) fail "--chat must be lean, mean, or claw"; exit 1 ;; esac

# ── Load config ───────────────────────────────────────────────────────────────
load_env
BACKEND_ENGINE="${BACKEND_ENGINE:-ollama}"
INSTANCE_MODE="${INSTANCE_MODE:-single}"
SANDBOX_ENGINE="${SANDBOX_ENGINE:-nemoclaw}"
DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-true}"
MONITORING_ENABLED="${MONITORING_ENABLED:-false}"
PORTAINER_ENABLED="${PORTAINER_ENABLED:-false}"

echo ""
info "Backend: ${CYAN}${BACKEND_ENGINE}${NC}  Chat: ${CYAN}${CHAT_MODE}${NC}  Sandbox: ${CYAN}${SANDBOX_ENGINE}${NC}"
echo ""

# ── Source component scripts ──────────────────────────────────────────────────
source "$REPO_DIR/scripts/components/ollama/ollama.sh"
source "$REPO_DIR/scripts/components/bitnet/bitnet.sh"
source "$REPO_DIR/scripts/components/llama-swap/llama-swap.sh"
source "$REPO_DIR/scripts/components/open-webui/open-webui.sh"
source "$REPO_DIR/scripts/components/dashboard/dashboard.sh"
source "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh"
source "$REPO_DIR/scripts/components/htsclaw/htsclaw.sh"

# ── Build service manifest for install-status ─────────────────────────────────
# Determine which services will be started based on config
INSTALL_SVCS=()
[[ "$DASHBOARD_ENABLED"  == "true" ]] && INSTALL_SVCS+=("dashboard")
if [[ "$BACKEND_ENGINE" == "dual" ]]; then
  INSTALL_SVCS+=("ollama" "bitnet" "llama-swap")
elif [[ "$BACKEND_ENGINE" == "bitnet" ]]; then
  INSTALL_SVCS+=("bitnet")
else
  INSTALL_SVCS+=("ollama")
  [[ "$BACKEND_ENGINE" == "dual" ]] && INSTALL_SVCS+=("llama-swap")
fi
INSTALL_SVCS+=("open-webui")
case "$SANDBOX_ENGINE" in
  htsclaw)  INSTALL_SVCS+=("htsclaw") ;;
  nemoclaw) INSTALL_SVCS+=("nemoclaw") ;;
  both)     INSTALL_SVCS+=("htsclaw" "nemoclaw") ;;
esac
[[ "$MONITORING_ENABLED" == "true" ]] && INSTALL_SVCS+=("prometheus" "grafana")
[[ "$PORTAINER_ENABLED"  == "true" ]] && INSTALL_SVCS+=("portainer")

# Initialize install-status.json (all services → pending)
install_status_init "${INSTALL_SVCS[@]}"

# ── Step 1: Dashboard (first — shows install progress) ───────────────────────
if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  install_status_set "dashboard" "installing"
  dashboard_start
  dashboard_health
  install_status_set "dashboard" "running"
else
  info "Dashboard disabled — install progress not visible in browser."
fi

# ── Step 2: Start backend ────────────────────────────────────────────────────
if [[ "$BACKEND_ENGINE" == "dual" ]]; then
  # Dual-inference: GPU Ollama + CPU BitNet fronted by llama-swap
  install_status_set "ollama" "installing"
  install_status_msg "ollama" "Starting container…"
  ollama_start
  ollama_health
  install_status_msg "ollama" "Loading model ${OLLAMA_MODEL:-gemma4:e4b}…"
  ollama_swap_model "${OLLAMA_MODEL:-gemma4:e4b}"
  install_status_msg "ollama" ""
  install_status_set "ollama" "running"

  install_status_set "bitnet" "installing"
  install_status_msg "bitnet" "Starting container…"
  bitnet_start
  bitnet_health
  install_status_msg "bitnet" ""
  install_status_set "bitnet" "running"

  install_status_set "llama-swap" "installing"
  install_status_msg "llama-swap" "Starting router…"
  llamaswap_start
  llamaswap_health
  install_status_msg "llama-swap" ""
  install_status_set "llama-swap" "running"
elif [[ "$BACKEND_ENGINE" == "bitnet" ]]; then
  install_status_set "bitnet" "installing"
  install_status_msg "bitnet" "Starting container…"
  bitnet_start
  bitnet_health
  install_status_msg "bitnet" ""
  install_status_set "bitnet" "running"
else
  install_status_set "ollama" "installing"
  install_status_msg "ollama" "Starting container…"
  ollama_start
  ollama_health

  # Swap model for chat mode
  if [[ "$CHAT_MODE" == "lean" ]]; then
    install_status_msg "ollama" "Loading model smollm2:135m…"
    ollama_swap_model "smollm2:135m"
  elif [[ "$CHAT_MODE" == "claw" ]]; then
    install_status_msg "ollama" "Loading model ${CLAW_MODEL:-deepseek-r1:14b}…"
    ollama_swap_model "${CLAW_MODEL:-deepseek-r1:14b}"
  else
    install_status_msg "ollama" "Loading model ${OLLAMA_MODEL:-gemma4:e4b}…"
    ollama_swap_model "${OLLAMA_MODEL:-gemma4:e4b}"
  fi
  install_status_msg "ollama" ""
  install_status_set "ollama" "running"
fi

# ── Step 3: Start Open WebUI ─────────────────────────────────────────────────
install_status_set "open-webui" "installing"
openwebui_install   # ensures external volume exists
openwebui_start
openwebui_health
openwebui_bootstrap_api_key
if [[ "${MODEL_AUDIT_ENABLED:-true}" == "true" ]]; then
  openwebui_provision_functions
fi
install_status_set "open-webui" "running"

# ── Step 4: Sandbox engines ───────────────────────────────────────────────────
case "$SANDBOX_ENGINE" in
  htsclaw)
    install_status_set "htsclaw" "installing"
    htsclaw_start
    htsclaw_health
    install_status_set "htsclaw" "running"
    ;;
  nemoclaw)
    install_status_set "nemoclaw" "installing"
    nemoclaw_start
    nemoclaw_health
    install_status_set "nemoclaw" "running"
    ;;
  both)
    install_status_set "htsclaw" "installing"
    htsclaw_start
    htsclaw_health
    install_status_set "htsclaw" "running"

    install_status_set "nemoclaw" "installing"
    nemoclaw_start
    nemoclaw_health
    install_status_set "nemoclaw" "running"
    ;;
  none)
    info "Skipping sandbox engines (SANDBOX_ENGINE=none)."
    ;;
  *)
    info "Skipping sandbox (unknown SANDBOX_ENGINE=${SANDBOX_ENGINE})."
    ;;
esac

# ── Step 5: Monitoring (if enabled) ──────────────────────────────────────────
if [[ "$MONITORING_ENABLED" == "true" ]]; then
  install_status_set "prometheus" "installing"
  install_status_set "grafana" "installing"
  compose_up --profile monitoring
  health_probe "Prometheus :9090" "http://localhost:9090/-/ready" || true
  install_status_set "prometheus" "running"
  health_probe "Grafana :3001" "http://localhost:3001/api/health" || true
  install_status_set "grafana" "running"
  ok "Monitoring stack started (Prometheus + cAdvisor + Grafana)."
else
  info "Monitoring disabled."
fi

# ── Step 6: Portainer (if enabled) ───────────────────────────────────────────
if [[ "$PORTAINER_ENABLED" == "true" ]]; then
  install_status_set "portainer" "installing"
  compose_up --profile portainer
  health_probe "Portainer :9443" "https://localhost:9443" || true
  install_status_set "portainer" "running"
  ok "Portainer started on :9443 (HTTPS)."
else
  info "Portainer disabled."
fi

# ── Done ──────────────────────────────────────────────────────────────────────
install_status_complete

echo ""
ok "Stack up — backend:${BACKEND_ENGINE} chat:${CHAT_MODE}"
echo ""
if [[ "$BACKEND_ENGINE" == "dual" ]]; then
  echo "  Dual-inference active: Ollama (GPU) + BitNet (CPU) via llama-swap"
  echo "  Router: http://localhost:${LLAMA_SWAP_PORT:-8081}"
  echo ""
fi
[[ "$DASHBOARD_ENABLED"  == "true" ]] && echo "  Dashboard:  http://localhost:${DASHBOARD_PORT:-80}"
[[ "$MONITORING_ENABLED" == "true" ]] && echo "  Grafana:    http://localhost:3001  (admin/changeme)"
[[ "$PORTAINER_ENABLED"  == "true" ]] && echo "  Portainer:  https://localhost:9443"
echo ""
echo "  ./06-start-stack.sh              # chat:mean  (~7-8GB, default)"
echo "  ./06-start-stack.sh --chat claw  # chat:claw  (~9GB, reasoning)"
echo "  ./06-start-stack.sh --chat lean  # chat:lean  (~500MB, dev/test)"
echo ""
echo "  Set BACKEND_ENGINE=dual|ollama|bitnet in .env to switch backends"

