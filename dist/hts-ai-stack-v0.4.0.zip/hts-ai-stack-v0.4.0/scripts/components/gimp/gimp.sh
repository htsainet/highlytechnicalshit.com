#!/usr/bin/env bash
# scripts/components/gimp/gimp.sh — GIMP: install, configure, health
#
# Host-native installer for GIMP (GNU Image Manipulation Program).
# Professional photo editing, compositing, image authoring, and digital painting.
#
# Standalone usage:
#   ./scripts/components/gimp/gimp.sh              # full: install + configure + health
#   ./scripts/components/gimp/gimp.sh --install    # install only
#   ./scripts/components/gimp/gimp.sh --configure  # configure only
#   ./scripts/components/gimp/gimp.sh --start      # no-op (desktop app)
#   ./scripts/components/gimp/gimp.sh --stop       # no-op (desktop app)
#   ./scripts/components/gimp/gimp.sh --restart    # no-op (desktop app)
#   ./scripts/components/gimp/gimp.sh --health     # health check only
#   ./scripts/components/gimp/gimp.sh --status     # show status + health
#   ./scripts/components/gimp/gimp.sh --destroy    # uninstall GIMP
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# ── Functions ────────────────────────────────────────────────────────────────

gimp_install() {
  step "GIMP — install"
  if command -v gimp &>/dev/null; then
    skip "GIMP already installed."
  else
    info "Installing GIMP via snap (latest stable)..."
    sudo snap install gimp
    ok "GIMP installed."
  fi
}

gimp_configure() {
  step "GIMP — configure"
  info "GIMP is a desktop application — no service configuration needed."
  ok "GIMP configured."
}

gimp_start() {
  step "GIMP — start"
  info "GIMP is a desktop application. Launch from your application menu."
}

gimp_stop() {
  step "GIMP — stop"
  info "GIMP is a desktop application. Close it from the window."
}

gimp_restart() {
  gimp_stop
  gimp_start
}

gimp_health() {
  step "GIMP — health"
  if command -v gimp &>/dev/null; then
    local ver
    ver=$(gimp --version 2>/dev/null | head -1 || echo "unknown")
    ok "GIMP is installed: $ver"
    return 0
  else
    warn "GIMP is not installed."
    return 1
  fi
}

gimp_status() {
  step "GIMP — status"
  gimp_health
}

gimp_destroy() {
  step "GIMP — destroy"
  if snap list gimp &>/dev/null 2>&1; then
    info "Removing GIMP snap..."
    sudo snap remove gimp
    ok "GIMP removed."
  elif dpkg -l gimp &>/dev/null 2>&1; then
    info "Removing GIMP apt package..."
    sudo apt-get remove -y gimp
    ok "GIMP removed."
  else
    skip "GIMP is not installed."
  fi
}

# ── CLI entry point ──────────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  case "${1:-}" in
    --install)   gimp_install   ;;
    --configure) gimp_configure ;;
    --start)     gimp_start     ;;
    --stop)      gimp_stop      ;;
    --restart)   gimp_restart   ;;
    --health)    gimp_health    ;;
    --status)    gimp_status    ;;
    --destroy)   gimp_destroy   ;;
    *)
      gimp_install
      gimp_configure
      gimp_health
      ;;
  esac
fi
