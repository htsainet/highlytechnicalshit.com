# KoboldCpp — Source-Built Container Plan

## Motivation

KoboldAI publishes only `koboldai/koboldcpp:latest` to Docker Hub. We currently
pin a digest in `docker/koboldcpp/Dockerfile`, which gives us *a* fixed image,
but every intentional refresh forces us to chase whatever `:latest` happens to
point at — there is no semver tag to reason about, no signed release, and no
SBOM.

Building from upstream source (LostRuins/koboldcpp at a pinned git tag) gives
us:

1. **Reproducible provenance** — pinned to a release tag + commit SHA, not an
   opaque downstream rebuild of `:latest`.
2. **Reduced runtime fetch** — the upstream image's `docker-helper.sh` fetches
   the prebuilt koboldcpp release binary at container start. Source-build bakes
   the binary in, removing one network dependency and shortening healthcheck
   `start_period`.
3. **Smaller attack surface in the image** — drop `docker-helper.sh`, the
   Cloudflare tunnel client, and aria2 (we already disable the tunnel via
   `KCPP_DONT_TUNNEL=true`, but the binary is still present).

This is a **deviation** from the upstream-recommended install path (KoboldAI's
prebuilt image). Per repo policy it requires a `DEVIATIONS.md` entry and a
`REFERENCES.md` update before merge.

## Scope

- In: replace `docker/koboldcpp/Dockerfile` with a multi-stage source build;
  update manifest `upstream` block; update `DEVIATIONS.md` and
  `REFERENCES.md`; minimal touch-up to `koboldcpp.sh`.
- Out: changing how the component is wired into compose, env-var contract,
  health URL, dashboard tile, or the wizard flow.

## Upstream pin

Decide and record before the first build:

- `pinned_version`: a koboldcpp release tag (e.g. `v1.XX.Y`) — must be picked
  from <https://github.com/LostRuins/koboldcpp/releases> at plan-execution
  time, not now.
- `commit_sha`: the SHA the tag resolves to (recorded in the Dockerfile as a
  comment alongside the `git checkout`).
- `install_method`: `docker-build`.
- `install_docs`: <https://github.com/LostRuins/koboldcpp#compiling-on-linux-using-make-recommended>

**Action item before build:** verify the chosen tag's `Makefile` for current
flag names — koboldcpp has migrated `LLAMA_CUBLAS` → `LLAMA_CUDA` and is moving
toward `GGML_CUDA`. Plan must use whatever the pinned tag actually exposes; do
not copy flag names from older docs.

## Manifest changes

Update `scripts/components/koboldcpp/koboldcpp.manifest.json` `upstream` block
to the full schema from `scripts/components/CONTEXT.md`:

```json
"upstream": {
  "vendor":         "LostRuins",
  "repo":           "https://github.com/LostRuins/koboldcpp",
  "docs":           "https://github.com/LostRuins/koboldcpp/wiki",
  "install_docs":   "https://github.com/LostRuins/koboldcpp#compiling-on-linux-using-make-recommended",
  "install_method": "docker-build",
  "image":          "hts-ai-koboldcpp",
  "pinned_version": "<TBD release tag>"
}
```

`install_type` stays `"compose"` — `compose_build` still drives the build,
the Dockerfile just changes shape. No change to `koboldcpp.sh` lifecycle
functions is required for the build mechanism.

## Dockerfile design

Two stages, single file at `docker/koboldcpp/Dockerfile`.

### Stage 1 — `builder`

- Base: `nvidia/cuda:12.4.1-devel-ubuntu22.04` (devel variant — has nvcc and
  CUDA headers; pulled from NVIDIA, not apt's outdated `nvidia-cuda-toolkit`).
- Install: `build-essential cmake git python3 python3-pip ca-certificates`.
- Vulkan path is deferred — CPU + CUDA only for the first cut. (Adding Vulkan
  multiplies the build matrix and we have no consumer asking for it.)
- `git clone --depth 1 --branch <tag> https://github.com/LostRuins/koboldcpp`,
  then `git rev-parse HEAD` baked into an image label for traceability.
- Build with `make -j"$(nproc) LLAMA_PORTABLE=1 LLAMA_CUDA=1 LLAMA_OPENBLAS=1`
  (exact flag set pinned to the chosen tag's Makefile — verify before
  hard-coding).
- Resulting artifact set: `koboldcpp.py`, `koboldcpp_default.so`,
  `koboldcpp_cublas.so` (and any other `.so` the chosen tag produces under
  the configured flags), plus the `kcpp_*` Python helper modules.

> KoboldCpp is **not** a single static binary. The runtime needs Python plus
> the compiled shared libraries. Plan for that explicitly.

### Stage 2 — `runtime`

- Base: `nvidia/cuda:12.4.1-runtime-ubuntu22.04` (runtime, not devel).
- Install: `python3 python3-pip curl ca-certificates` and the minimum
  CUDA runtime libs not already in the base (cuBLAS).
- Copy from `builder`: koboldcpp source tree minus `.git` and build artefacts
  we don't need (intermediate `.o`, test data).
- Create non-root user `kobold` (uid 1000), `chown` the install path.
- `EXPOSE 5001`.
- `HEALTHCHECK --start-period=120s` (down from 600s — only the GGUF model
  download remains; binary is baked in).
- `ENTRYPOINT ["python3", "koboldcpp.py"]`. Args supplied by compose via
  `KCPP_ARGS` (preserve current contract).

### Image size expectation

The "<500 MB CPU-only" target from the prior plan is unrealistic given
Python plus the CUDA runtime. Realistic targets: ~300–400 MB CPU-only on
`debian:bookworm-slim`, ~2–3 GB for the CUDA-enabled image (CUDA runtime
alone is ~1.5 GB). Document actual sizes after the first build; don't promise
a number in advance.

## Compose / env contract

No changes. Existing `KOBOLDCPP_*` env vars in `koboldcpp.sh` (lines 28–34,
58–63) and `KCPP_MODEL` / `KCPP_ARGS` / `KCPP_DONT_TUNNEL` in compose stay as
they are. The new image still consumes them.

`KCPP_DONT_TUNNEL=true` becomes redundant (we don't ship the tunnel binary at
all in the source build) but harmless — leave it in compose for defence in
depth.

## `koboldcpp.sh` changes

Minimal:

- Update the header comment block to reflect source-build provenance.
- No new helper functions. **Do not** add `koboldcpp_detect_gpu_capability` —
  reuse `scripts/lib/gpu.sh::get_gpu_vram_gb` if VRAM gating is wanted in
  `koboldcpp_configure`. (Currently configure just seeds env defaults; that's
  fine.)
- Keep `install_type: "compose"` and the existing `compose_build --profile
  koboldcpp` call; nothing in the lifecycle changes.

## DEVIATIONS.md entry

Add an entry under the koboldcpp component using the existing template:

- **What:** Building koboldcpp from upstream source instead of using
  `koboldai/koboldcpp` per the manifest's nominal install path.
- **Why:** KoboldAI ships only `:latest` (no semver tags, no signed releases,
  no SBOM). Source-build at a pinned LostRuins tag gives reproducible
  provenance and removes the runtime binary fetch + tunnel client.
- **Revisit when:** KoboldAI starts publishing tagged immutable images, or
  LostRuins publishes an official Docker image directly.

## REFERENCES.md updates

- Add koboldcpp source repo, install docs URL, pinned tag, and the Makefile
  flag reference under the koboldcpp section.
- Confirm port 5001 is still uncontested in the Host Port Map (it currently
  is — no change expected, just verify).

## Validation

1. `compose_build --profile koboldcpp` succeeds on the build host.
2. CPU-only run (`KOBOLDCPP_GPU_LAYERS=0`) loads default Phi-3.5-mini-Q4_K_M,
   `/v1/models` returns 200 within `start_period`.
3. GPU run (`KOBOLDCPP_GPU_LAYERS=99`, ollama stopped) shows VRAM use on
   `nvidia-smi` and `/v1/models` returns 200.
4. `docker image inspect hts-ai-koboldcpp` shows the commit-SHA label.
5. No outbound connections to Cloudflare / aria2 mirrors during start
   (verify with `docker exec … ss -tnp` or container netstat).
6. `markdownlint-cli2` passes on this file, `DEVIATIONS.md`, and
   `REFERENCES.md` after edits.

## Risks

| Risk | Mitigation |
|------|------------|
| Pinned-tag Makefile flags drift between releases | Verify flag names against the chosen tag's `Makefile` at build time; don't copy from old docs. |
| CUDA arch mismatch (image built for arches we don't run) | Set `CMAKE_CUDA_ARCHITECTURES` / `LLAMA_CUDA_DMMV_Y` etc. only after confirming target GPU compute capability; otherwise let upstream defaults stand. |
| Larger build context / longer `compose_build` | Acceptable — runs only on intentional refresh, not per-deploy. |
| Upstream removes a flag we depend on | Pinned tag means we choose when to upgrade; revisit during the planned refresh cadence. |

## Out of scope (explicit)

- Vulkan / ROCm / OpenCL build variants.
- Switching off NVIDIA's CUDA base image to a slimmer Debian + CUDA-libs
  layout (revisit if image size becomes a real problem).
- Replacing compose-driven lifecycle with anything else.
- SBOM generation tooling — track separately under the release workflow, not
  per-component.
