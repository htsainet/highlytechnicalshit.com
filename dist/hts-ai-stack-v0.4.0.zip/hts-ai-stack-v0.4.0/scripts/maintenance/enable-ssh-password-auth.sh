#!/usr/bin/env bash
# enable-ssh-password-auth.sh
#
# Enables password-based SSH authentication via a drop-in config file.
# Uses a "10-" prefix so it overrides distro/cloud-init drop-ins (e.g.
# /etc/ssh/sshd_config.d/50-cloud-init.conf) that disable passwords.
#
# Idempotent: rewrites the drop-in each run, validates with `sshd -t`,
# and only reloads sshd if validation passes.
#
# Usage:
#   sudo ./enable-ssh-password-auth.sh           # enable
#   sudo ./enable-ssh-password-auth.sh --disable # remove the drop-in
#   sudo ./enable-ssh-password-auth.sh --status  # show effective settings

set -euo pipefail

DROPIN_DIR="/etc/ssh/sshd_config.d"
DROPIN_FILE="${DROPIN_DIR}/10-password-auth.conf"
ACTION="${1:-enable}"

require_root() {
  if [[ $EUID -ne 0 ]]; then
    echo "ERROR: must run as root (use sudo)" >&2
    exit 1
  fi
}

ssh_service_name() {
  if systemctl list-unit-files | grep -q '^ssh\.service'; then
    echo "ssh"
  elif systemctl list-unit-files | grep -q '^sshd\.service'; then
    echo "sshd"
  else
    echo "ssh"
  fi
}

show_status() {
  echo "== Effective sshd settings =="
  sshd -T 2>/dev/null | grep -Ei '^(passwordauthentication|kbdinteractiveauthentication|challengeresponseauthentication|usepam) '
  echo
  echo "== Drop-ins in ${DROPIN_DIR} =="
  ls -1 "${DROPIN_DIR}" 2>/dev/null || echo "(none)"
  if [[ -f "${DROPIN_FILE}" ]]; then
    echo
    echo "== ${DROPIN_FILE} =="
    cat "${DROPIN_FILE}"
  fi
}

case "${ACTION}" in
  --status|status)
    show_status
    exit 0
    ;;
  --disable|disable)
    require_root
    if [[ -f "${DROPIN_FILE}" ]]; then
      rm -f "${DROPIN_FILE}"
      echo "Removed ${DROPIN_FILE}"
    else
      echo "No drop-in at ${DROPIN_FILE}; nothing to remove."
    fi
    sshd -t
    systemctl reload "$(ssh_service_name)"
    echo "sshd reloaded."
    show_status
    exit 0
    ;;
  enable|--enable|"")
    require_root
    ;;
  -h|--help)
    sed -n '2,20p' "$0"
    exit 0
    ;;
  *)
    echo "Unknown argument: ${ACTION}" >&2
    echo "Usage: $0 [enable|--disable|--status]" >&2
    exit 2
    ;;
esac

mkdir -p "${DROPIN_DIR}"
chmod 755 "${DROPIN_DIR}"

TMP="$(mktemp)"
cat > "${TMP}" <<'EOF'
# Managed by scripts/maintenance/enable-ssh-password-auth.sh
# Drop-in prefix "10-" ensures this loads before distro defaults
# (e.g. 50-cloud-init.conf) so these settings win.
PasswordAuthentication yes
KbdInteractiveAuthentication yes
UsePAM yes
EOF
chmod 644 "${TMP}"
mv "${TMP}" "${DROPIN_FILE}"
echo "Wrote ${DROPIN_FILE}"

echo "Validating sshd config..."
if ! sshd -t; then
  echo "ERROR: sshd config validation failed; rolling back." >&2
  rm -f "${DROPIN_FILE}"
  exit 1
fi

SVC="$(ssh_service_name)"
echo "Reloading ${SVC}..."
systemctl reload "${SVC}"

echo
show_status
echo
echo "Done. Password-based SSH is enabled."
