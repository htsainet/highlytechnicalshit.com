"""Open-Sora — Gradio web UI for text-to-video generation.

⚠️ Requires ≥24GB VRAM. This app will fail to load models on GPUs
with insufficient memory. The component install script gates on VRAM
before building/starting this container.
"""

import os
import gradio as gr

PORT = int(os.environ.get("OPEN_SORA_PORT", "7862"))

# Lazy-load to allow container to start and serve health checks
# before loading the full model into VRAM
model = None


def load_model():
    global model
    if model is None:
        try:
            import torch
            from opensora.serve.gradio_utils import load_opensora_pipeline

            model = load_opensora_pipeline()
        except ImportError:
            # Fallback: use diffusers-based pipeline if opensora serve utils unavailable
            from diffusers import DiffusionPipeline
            import torch

            model = DiffusionPipeline.from_pretrained(
                "hpcai-tech/OpenSora-STDiT-v3",
                torch_dtype=torch.float16,
            ).to("cuda")
    return model


def generate_video(prompt: str, num_frames: int = 51, resolution: str = "480p"):
    """Generate a video from a text description."""
    pipe = load_model()

    res_map = {"240p": (240, 426), "360p": (360, 640), "480p": (480, 854)}
    h, w = res_map.get(resolution, (480, 854))

    if hasattr(pipe, "generate"):
        # Open-Sora native API
        video_path = pipe.generate(
            prompt=prompt,
            num_frames=min(num_frames, 51),
            resolution=f"{h}x{w}",
        )
    else:
        # Diffusers fallback
        import imageio

        result = pipe(prompt=prompt, num_frames=min(num_frames, 51)).frames[0]
        video_path = "/tmp/opensora_output.mp4"
        imageio.mimsave(video_path, result, fps=24, codec="libx264")

    return video_path


with gr.Blocks(title="Open-Sora") as app:
    gr.Markdown("# 🎬 Open-Sora")
    gr.Markdown("Text-to-video generation — **requires ≥24GB VRAM**")

    prompt_input = gr.Textbox(
        label="Describe the video you want",
        placeholder="e.g., A time-lapse of a city skyline transitioning from day to night",
    )
    with gr.Row():
        frames_input = gr.Slider(
            minimum=9, maximum=51, value=51, step=6, label="Frames"
        )
        resolution_input = gr.Dropdown(
            choices=["240p", "360p", "480p"], value="480p", label="Resolution"
        )
    generate_btn = gr.Button("Generate Video", variant="primary")
    video_output = gr.Video(label="Generated Video")
    generate_btn.click(
        generate_video,
        inputs=[prompt_input, frames_input, resolution_input],
        outputs=video_output,
    )

if __name__ == "__main__":
    app.launch(server_name="0.0.0.0", server_port=PORT)
