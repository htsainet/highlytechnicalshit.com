# Krita — References

## Upstream

- **Homepage**: <https://krita.org/>
- **Source**: <https://invent.kde.org/graphics/krita>
- **Snap package**: <https://snapcraft.io/krita>
- **Documentation**: <https://docs.krita.org/>

## Notes

- GPLv3 license
- Snap provides latest stable without PPA management
- Supports PSD import/export and OpenEXR
