#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
# shellcheck source=scripts/install/tooling/ui.sh
source "$REPO_DIR/scripts/install/tooling/ui.sh"

htsai_banner "03 — Setup Models"

# ─────────────────────────────────────────────────────────────────────────────
# 03-setup-models.sh
# Master model setup script — calls prod and test in order.
#
# After completion:
#   ollama-prod           ✅ running  (NemoClaw prod default)
#   stable-diffusion-prod ✅ running  (factory defaults)
#   ollama-test           ⏹ stopped  (start manually to evaluate)
#   stable-diffusion-test ⏹ stopped
#
# You can also run each script independently:
#   ./scripts/install/models/prod.sh
#   ./scripts/install/models/test.sh
# ─────────────────────────────────────────────────────────────────────────────

if [[ -f "${REPO_DIR}/scripts/install/models/helpers.sh" ]]; then
  source "${REPO_DIR}/scripts/install/models/helpers.sh"
else
  echo "[FAIL] scripts/install/models/helpers.sh not found in ${REPO_DIR}" >&2
  exit 1
fi

# ── Pre-run checklist ─────────────────────────────────────────────────────────
checklist_start
checklist_item false "1. Pull prod models (Ollama, Stable Diffusion)"
checklist_item false "2. Pull test models (optional evaluation)"
checklist_end

# ── Parse flags & read config ──────────────────────────────────────────────────
# Start with defaults based on INSTANCE_MODE from .env
RUN_PROD=true
RUN_TEST=false
BACKEND_ENGINE="ollama"
if [[ -f "$REPO_DIR/.env" ]]; then
  INSTANCE_MODE=$(grep "^INSTANCE_MODE=" "$REPO_DIR/.env" | cut -d= -f2)
  BACKEND_ENGINE=$(grep "^BACKEND_ENGINE=" "$REPO_DIR/.env" | cut -d= -f2 || echo "ollama")
  if [[ "$INSTANCE_MODE" == "prod_test" ]]; then
    RUN_TEST=true
  fi
fi

# Dual backend: pull into ollama-gpu only, no test instance, BitNet baked in
if [[ "$BACKEND_ENGINE" == "dual" ]]; then
  RUN_TEST=false
fi

for arg in "$@"; do
  case "$arg" in
    --prod-only) RUN_TEST=false ;;
    --test-only) RUN_PROD=false ;;
    --help)
      echo "Usage: $0 [--prod-only] [--test-only]"
      exit 0
      ;;
    *)
      warn "Unknown flag: $arg — ignoring."
      ;;
  esac
done

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}╔══════════════════════════════════════╗${NC}"
echo -e "${CYAN}║       03-setup-models.sh             ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════╝${NC}"
echo ""
if [[ "$BACKEND_ENGINE" == "dual" ]]; then
  info "Backend: dual (Ollama GPU + BitNet CPU via llama-swap)"
  info "  BitNet models are baked into the image — no pull needed."
fi
info "Will run:"
$RUN_PROD && info "  ✔ prod  (ollama-prod + sd-prod)"   || warn "  ✗ prod  (skipped)"
$RUN_TEST && info "  ✔ test  (ollama-test + sd-test)"   || warn "  ✗ test  (skipped)"
echo ""

# ── Run scripts ───────────────────────────────────────────────────────────────
if $RUN_PROD; then
  step "PROD environment"
  bash "${REPO_DIR}/scripts/install/models/prod.sh"
fi

if $RUN_TEST; then
  step "TEST environment"
  bash "${REPO_DIR}/scripts/install/models/test.sh"
fi

# ── Final summary ─────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}══════════════════════════════════════════${NC}"
ok "All requested environments seeded."
echo ""
if [[ "$BACKEND_ENGINE" == "dual" ]]; then
  info "Dual-inference services:"
  info "  ollama-gpu   → http://localhost:11434  (GPU models)"
  info "  bitnet-cpu   → http://localhost:8080   (CPU models, baked in)"
  info "  llama-swap   → http://localhost:8080   (unified router)"
else
  info "Running services:"
  info "  ollama-prod           → http://localhost:11434"
  info "  stable-diffusion-prod → http://localhost:7860"
  echo ""
  info "Stopped (start manually when needed):"
  info "  docker compose -f instances/test/docker-compose.yml up -d ollama-test stable-diffusion-test"
  echo ""
  info "Ports when running:"
  info "  ollama-test    → http://localhost:11435"
  info "  sd-test        → http://localhost:7861"
fi
echo -e "${CYAN}══════════════════════════════════════════${NC}"
