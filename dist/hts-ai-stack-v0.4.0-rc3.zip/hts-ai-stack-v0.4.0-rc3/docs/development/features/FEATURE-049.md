# FEATURE-049 — Claude-Mem Persistent Memory

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | LOW |
| **Effort** | < 15 minutes |
| **Risk** | Low — Node plugin only, no infrastructure changes |
| **Target Release** | v0.5.0 |
| **Depends on** | Nothing |
| **Blocks** | Nothing |

## Problem

Claude Code sessions lose context when they end or reconnect. Project-specific knowledge, past decisions, and observations must be re-explained each time. This wastes tokens and developer time.

## Solution

Install [claude-mem](https://github.com/thedotmack/claude-mem) — a persistent memory compression system that auto-captures tool usage observations, generates semantic summaries, and makes them available to future Claude Code sessions.

### Implementation (complete)

Added install step in `scripts/host/tools.sh` (dev-tools section):

- Runs `npx claude-mem install` to register the plugin
- Idempotent: checks for `~/.claude-mem` or `~/.claude/plugins/claude-mem`
- Gracefully skips on failure (requires Node 18+)

### Features

- **Automatic capture** — records tool usage and observations during sessions
- **Semantic compression** — summarizes context to stay within token limits
- **Cross-session persistence** — knowledge carries forward without manual effort
- **Search tools** — MCP-based semantic search across stored memories

## Acceptance criteria

- [x] Install step added to `scripts/host/tools.sh` under dev tools
- [x] Idempotent check before install
- [ ] Verified install completes and plugin registers with Claude Code

## Upstream

| Resource | Link |
|----------|------|
| GitHub | <https://github.com/thedotmack/claude-mem> |
| npm | <https://www.npmjs.com/package/claude-mem> |

## Notes

- Plugin only — no containers, no ports, no compose services
- Works alongside `anthropic.claude-code` VS Code extension already in the stack
- Also supports Gemini CLI if needed in future
