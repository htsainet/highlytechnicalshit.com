#!/usr/bin/env bash
# =============================================================================
# ollama-safe-pull
# A wrapper around `ollama pull` that auto-patches Modelfiles with correct
# TEMPLATE and PARAMETER stop tokens for the detected model family.
#
# Usage:
#   ollama-safe-pull <model>[:<tag>]
#
# Examples:
#   ollama-safe-pull llama3
#   ollama-safe-pull mistral:7b
#   ollama-safe-pull phi3:mini
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
SCRIPT_NAME="$(basename "$0")"
VERSION="1.0.0"

# ---------------------------------------------------------------------------
# Logging helpers
# ---------------------------------------------------------------------------
info()    { printf '\033[0;34m[INFO]\033[0m  %s\n' "$*"; }
success() { printf '\033[0;32m[OK]\033[0m    %s\n' "$*"; }
warn()    { printf '\033[0;33m[WARN]\033[0m  %s\n' "$*"; }
error()   { printf '\033[0;31m[ERROR]\033[0m %s\n' "$*" >&2; }
die()     { error "$*"; exit 1; }

# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------
usage() {
  cat <<EOF
${SCRIPT_NAME} v${VERSION}

USAGE:
  ${SCRIPT_NAME} <model>[:<tag>]

DESCRIPTION:
  Pulls an Ollama model, detects its family, then creates a patched copy
  with a correct TEMPLATE and PARAMETER stop tokens so the model never
  talks to itself.

  The patched model is registered under the same name, replacing the
  original Modelfile configuration. The model weights are NOT re-downloaded.

EXAMPLES:
  ${SCRIPT_NAME} llama3
  ${SCRIPT_NAME} mistral:7b-instruct
  ${SCRIPT_NAME} phi3:mini
  ${SCRIPT_NAME} gemma2:9b

SUPPORTED MODEL FAMILIES:
  llama3 / llama3.1 / llama3.2 / llama3.3
  llama2 / llama2-chat
  mistral / mixtral
  phi3 / phi3.5
  gemma / gemma2
  qwen2 / qwen2.5
  deepseek / deepseek-r1
  command-r (Cohere)
  (fallback: generic chatml for anything else)

EOF
  exit 0
}

# ---------------------------------------------------------------------------
# Dependency check
# ---------------------------------------------------------------------------
check_dependencies() {
  if ! command -v ollama &>/dev/null; then
    die "ollama is not installed or not in PATH. See https://ollama.com/download"
  fi
}

# ---------------------------------------------------------------------------
# Detect model family from model name string
# Returns a family key used in get_template / get_stop_params
# ---------------------------------------------------------------------------
detect_family() {
  local model_name="${1,,}"   # lowercase

  case "$model_name" in
    *llama3.3*|*llama-3.3*) echo "llama3" ;;
    *llama3.2*|*llama-3.2*) echo "llama3" ;;
    *llama3.1*|*llama-3.1*) echo "llama3" ;;
    *llama3*|*llama-3*)     echo "llama3" ;;
    *llama2*|*llama-2*)     echo "llama2" ;;
    *mistral*|*mixtral*)    echo "mistral" ;;
    *phi3.5*|*phi-3.5*)     echo "phi3"   ;;
    *phi3*|*phi-3*)         echo "phi3"   ;;
    *gemma2*|*gemma-2*)     echo "gemma2" ;;
    *gemma*)                echo "gemma"  ;;
    *qwen2.5*|*qwen-2.5*)   echo "qwen2"  ;;
    *qwen2*|*qwen-2*)       echo "qwen2"  ;;
    *deepseek*)             echo "deepseek" ;;
    *command-r*)            echo "command-r" ;;
    *)                      echo "chatml"  ;;
  esac
}

# ---------------------------------------------------------------------------
# Return the correct TEMPLATE block for a given family
# ---------------------------------------------------------------------------
get_template() {
  local family="$1"

  case "$family" in
    llama3)
      cat <<'TMPL'
{{ if .System }}<|start_header_id|>system<|end_header_id|>

{{ .System }}<|eot_id|>{{ end }}{{ if .Prompt }}<|start_header_id|>user<|end_header_id|>

{{ .Prompt }}<|eot_id|>{{ end }}<|start_header_id|>assistant<|end_header_id|>

{{ .Response }}<|eot_id|>
TMPL
      ;;

    llama2)
      cat <<'TMPL'
[INST] {{ if .System }}<<SYS>>
{{ .System }}
<</SYS>>

{{ end }}{{ .Prompt }} [/INST] {{ .Response }} </s>
TMPL
      ;;

    mistral)
      cat <<'TMPL'
[INST] {{ if .System }}{{ .System }}

{{ end }}{{ .Prompt }}[/INST] {{ .Response }}</s>
TMPL
      ;;

    phi3)
      cat <<'TMPL'
{{ if .System }}<|system|>
{{ .System }}<|end|>
{{ end }}<|user|>
{{ .Prompt }}<|end|>
<|assistant|>
{{ .Response }}<|end|>
TMPL
      ;;

    gemma|gemma2)
      cat <<'TMPL'
<start_of_turn>user
{{ if .System }}{{ .System }}

{{ end }}{{ .Prompt }}<end_of_turn>
<start_of_turn>model
{{ .Response }}<end_of_turn>
TMPL
      ;;

    qwen2)
      cat <<'TMPL'
<|im_start|>system
{{ if .System }}{{ .System }}{{ else }}You are a helpful assistant.{{ end }}<|im_end|>
<|im_start|>user
{{ .Prompt }}<|im_end|>
<|im_start|>assistant
{{ .Response }}<|im_end|>
TMPL
      ;;

    deepseek)
      cat <<'TMPL'
{{ if .System }}<｜system｜>{{ .System }}{{ end }}<｜User｜>{{ .Prompt }}<｜Assistant｜>{{ .Response }}<｜end▁of▁sentence｜>
TMPL
      ;;

    command-r)
      cat <<'TMPL'
<BOS_TOKEN><|START_OF_TURN_TOKEN|><|SYSTEM_TOKEN|>{{ if .System }}{{ .System }}{{ end }}<|END_OF_TURN_TOKEN|><|START_OF_TURN_TOKEN|><|USER_TOKEN|>{{ .Prompt }}<|END_OF_TURN_TOKEN|><|START_OF_TURN_TOKEN|><|CHATBOT_TOKEN|>{{ .Response }}<|END_OF_TURN_TOKEN|>
TMPL
      ;;

    chatml|*)
      cat <<'TMPL'
<|im_start|>system
{{ if .System }}{{ .System }}{{ else }}You are a helpful assistant.{{ end }}<|im_end|>
<|im_start|>user
{{ .Prompt }}<|im_end|>
<|im_start|>assistant
{{ .Response }}<|im_end|>
TMPL
      ;;
  esac
}

# ---------------------------------------------------------------------------
# Return PARAMETER stop lines for a given family
# Each line is a complete "PARAMETER stop ..." directive
# ---------------------------------------------------------------------------
get_stop_params() {
  local family="$1"

  case "$family" in
    llama3)
      printf 'PARAMETER stop "<|start_header_id|>"\n'
      printf 'PARAMETER stop "<|end_header_id|>"\n'
      printf 'PARAMETER stop "<|eot_id|>"\n'
      ;;

    llama2)
      printf 'PARAMETER stop "[INST]"\n'
      printf 'PARAMETER stop "[/INST]"\n'
      printf 'PARAMETER stop "<<SYS>>"\n'
      printf 'PARAMETER stop "<</SYS>>"\n'
      printf 'PARAMETER stop "</s>"\n'
      ;;

    mistral)
      printf 'PARAMETER stop "[INST]"\n'
      printf 'PARAMETER stop "[/INST]"\n'
      printf 'PARAMETER stop "</s>"\n'
      ;;

    phi3)
      printf 'PARAMETER stop "<|end|>"\n'
      printf 'PARAMETER stop "<|user|>"\n'
      printf 'PARAMETER stop "<|system|>"\n'
      printf 'PARAMETER stop "<|assistant|>"\n'
      ;;

    gemma|gemma2)
      printf 'PARAMETER stop "<end_of_turn>"\n'
      printf 'PARAMETER stop "<start_of_turn>"\n'
      ;;

    qwen2)
      printf 'PARAMETER stop "<|im_end|>"\n'
      printf 'PARAMETER stop "<|im_start|>"\n'
      ;;

    deepseek)
      printf 'PARAMETER stop "<｜end▁of▁sentence｜>"\n'
      printf 'PARAMETER stop "<｜User｜>"\n'
      printf 'PARAMETER stop "<｜Assistant｜>"\n'
      ;;

    command-r)
      printf 'PARAMETER stop "<|END_OF_TURN_TOKEN|>"\n'
      printf 'PARAMETER stop "<|START_OF_TURN_TOKEN|>"\n'
      ;;

    chatml|*)
      printf 'PARAMETER stop "<|im_end|>"\n'
      printf 'PARAMETER stop "<|im_start|>"\n'
      ;;
  esac
}

# ---------------------------------------------------------------------------
# Build a patched Modelfile, preserving any existing SYSTEM and PARAMETER
# lines (except TEMPLATE and stop, which we replace entirely).
# ---------------------------------------------------------------------------
build_modelfile() {
  local base_model="$1"
  local family="$2"
  local existing_modelfile="$3"   # path to temp file with current Modelfile

  local template stop_params system_line=""

  template="$(get_template "$family")"
  stop_params="$(get_stop_params "$family")"

  # Extract existing SYSTEM line if present (preserve user customisations)
  if grep -qi '^SYSTEM ' "$existing_modelfile" 2>/dev/null; then
    system_line="$(grep -i '^SYSTEM ' "$existing_modelfile" | head -1)"
  fi

  # Extract any non-stop PARAMETER lines from existing Modelfile
  # (temperature, num_ctx, etc.) – strip TEMPLATE and stop lines
  local extra_params=""
  if [[ -f "$existing_modelfile" ]]; then
    extra_params="$(grep -i '^PARAMETER ' "$existing_modelfile" \
      | grep -iv 'stop' \
      || true)"
  fi

  # Compose the new Modelfile
  cat <<EOF
# Generated by ${SCRIPT_NAME} v${VERSION}
# Model family : ${family}
# Base model   : ${base_model}
# Patched on   : $(date -u '+%Y-%m-%d %H:%M:%S UTC')

FROM ${base_model}

TEMPLATE """${template}"""

${stop_params}
EOF

  [[ -n "$extra_params" ]] && printf '%s\n' "$extra_params"
  [[ -n "$system_line"  ]] && printf '%s\n' "$system_line"
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
  [[ $# -eq 0 ]] && usage
  [[ "$1" == "-h" || "$1" == "--help" ]] && usage

  local model_ref="$1"
  check_dependencies

  # ── 1. Pull the model ──────────────────────────────────────────────────
  info "Pulling model: ${model_ref}"
  ollama pull "$model_ref"
  success "Pull complete: ${model_ref}"

  # ── 2. Detect family ──────────────────────────────────────────────────
  local family
  family="$(detect_family "$model_ref")"
  info "Detected model family: ${family}"

  # ── 3. Fetch existing Modelfile ───────────────────────────────────────
  local tmp_modelfile
  tmp_modelfile="$(mktemp /tmp/ollama-modelfile.XXXXXX)"
  trap 'rm -f "$tmp_modelfile"' EXIT

  if ollama show --modelfile "$model_ref" >"$tmp_modelfile" 2>/dev/null; then
    info "Fetched existing Modelfile for ${model_ref}"
  else
    warn "Could not fetch existing Modelfile – starting from scratch"
    # Write a minimal base so build_modelfile still works
    printf 'FROM %s\n' "$model_ref" >"$tmp_modelfile"
  fi

  # ── 4. Build patched Modelfile ────────────────────────────────────────
  local patched_modelfile
  patched_modelfile="$(mktemp /tmp/ollama-patched.XXXXXX)"
  trap 'rm -f "$tmp_modelfile" "$patched_modelfile"' EXIT

  build_modelfile "$model_ref" "$family" "$tmp_modelfile" >"$patched_modelfile"

  info "Patched Modelfile written (preview below)"
  printf '\n──────────────────────────────────────────────\n'
  cat "$patched_modelfile"
  printf '──────────────────────────────────────────────\n\n'

  # ── 5. Re‑register the model with the patched Modelfile ──────────────
  # Strip the tag from the model name so `ollama create` uses a clean name
  local model_name="${model_ref%%:*}"
  local model_tag="${model_ref#*:}"
  [[ "$model_tag" == "$model_ref" ]] && model_tag="latest"

  local create_target="${model_name}:${model_tag}"

  info "Registering patched model as: ${create_target}"
  ollama create "$create_target" -f "$patched_modelfile"
  success "Model ${create_target} is ready with correct TEMPLATE + stop tokens."
  info "Run it with:  ollama run ${create_target}"
}

main "$@"
