# NVIDIA/NemoClaw#1641 — nemoclaw list resurrects destroyed sandboxes

| Field | Value |
|-------|-------|
| **Repo** | [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) |
| **Issue** | [#1641](https://github.com/NVIDIA/NemoClaw/issues/1641) |
| **State** | OPEN |
| **Severity** | medium |
| **Labels** | bug, Platform: Ubuntu, NemoClaw CLI, NV QA, UAT |
| **Opened** | 2026-04-08 |
| **Subscribed** | No |

## Impact on us

After destroying a sandbox, `nemoclaw list` still shows it due to stale onboard-session metadata. The sandbox is inaccessible but appears alive. This causes confusion when managing multiple sandboxes and could lead to attempts to forward ports to non-existent sandboxes.

Affected files:

- `scripts/components/nemoclaw.sh` — sandbox lifecycle management
- `scripts/utils/upgrade-nemoclaw.sh` — sandbox enumeration during upgrades

## Workaround

Ignore ghost entries in `nemoclaw list` output. The fix is reportedly on `main` but not in the CLI release we're running (v0.0.10).

## Action when resolved

1. Upgrade NemoClaw CLI to the fixed version
2. Run `nemoclaw list` and confirm destroyed sandboxes no longer appear
3. Clean up any stale onboard-session metadata if a migration script is provided

## Status log

- **2026-04-08** — Reported upstream. Fix confirmed on main branch but not yet in a release.
- **2026-04-08** — Identified during our upstream issue scan.
