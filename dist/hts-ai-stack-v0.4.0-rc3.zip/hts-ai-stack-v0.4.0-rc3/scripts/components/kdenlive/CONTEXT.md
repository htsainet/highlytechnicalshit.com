# Kdenlive Component

Last updated: 2026-04-17

## What happens here

Kdenlive is KDE's non-linear video editor. Full-featured timeline
editing with multi-track video/audio, effects, transitions, keyframe
animation, and titling.

## Files and structure

| File | Purpose |
|------|---------|
| `kdenlive.sh` | Full lifecycle: install, configure, start, stop, health |
| `kdenlive.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- Host-native desktop application — no Docker container or web UI
- Requires a desktop session (X11 or Wayland) to run
- Supports MLT framework for video processing
- GPU-accelerated rendering via OpenGL
