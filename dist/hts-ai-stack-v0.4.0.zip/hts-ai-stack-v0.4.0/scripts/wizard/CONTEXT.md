# Installer Wizard — CONTEXT

Last updated: 2026-04-21

## What happens here

Shared wizard logic that is **sourced** (not executed) by the installer
entry points. These files encapsulate interactive selection and
non-interactive pull / apply logic for the two axes the user is asked
about during install or day-2 reconfiguration:

1. **Inference profile** — which inference backend(s) to run
   (Ollama only, Ollama + BitNet + llama-swap, LocalAI, etc.)
2. **Model selection** — which Ollama model tags to pull into the
   active backend

Keeping this logic in one place means `install.sh`, `configure.sh`,
`reconfigure.sh`, and the standalone component scripts all see the same
prompts, the same defaults, and the same pull logic.

## Process / Workflow

1. Caller sources `scripts/lib/common.sh` (for `info`/`ok`/`warn`/etc.).
2. Caller sources one or both wizard files:
   - `inference-profile.sh` — run `select_inference_profile` (interactive)
     or `check_inference_profile` (non-interactive validation).
   - `model-select.sh` — run `select_model` (interactive menu) or
     `pull_selected_models` / `pull_coding_tier` (non-interactive pulls).
3. Functions export their choices as environment variables
   (`BACKEND`, `MODEL`, `PULL_ALL_MODELS`, `INFERENCE_BITNET_MODEL`, …)
   which the caller then writes into `stack.json` / `.env`.
4. Wizard files never run standalone — they have no `main` block.

## Files and structure

| File | Purpose |
|------|---------|
| `inference-profile.sh` | `select_inference_profile` (whiptail menu) + `check_inference_profile` (non-interactive validator). Profiles → BACKEND mapping, LM Studio peer toggles. |
| `model-select.sh` | `select_model` (interactive model menu, VRAM-aware). `pull_selected_models` (pulls the selected `MODEL` / curated set). `pull_coding_tier` (FEATURE-067 — pulls the Aider architect+editor tier). Helpers: `_ollama_exec`, `_ollama_has_model`. |
| `CONTEXT.md` | This file. |
| `REFERENCES.md` | Related features, entry points, and upstream links. |

## Key conventions

- **No side effects on source.** Sourcing a wizard file must not pull
  models, write to `stack.json`, or prompt. All action is gated behind
  explicit function calls.
- **All Ollama operations go through the container.** `model-select.sh`
  routes every `ollama` invocation through `_ollama_exec`, which runs
  `docker exec "$OLLAMA_CONTAINER" ollama …` against the live container
  (`hts-ai-ollama` by default). The host `ollama` CLI is **not**
  installed by `bootstrap.sh`, so a direct `command -v ollama` check
  would fail on a fresh host. A host-CLI fallback exists for dev
  environments where the container isn't up.
- **NAS cache is a volume-restore concern, not a per-tag import.** The
  NAS share at `${NAS_MODEL_CACHE:-/mnt/htsai-model-backup/ollama/…}`
  is a snapshot of Ollama's `models/{blobs,manifests}` tree produced by
  `scripts/utils/seed-model-cache.sh`. Re-hydrating the live
  `ollama_data` volume from that snapshot is the job of volume-restore
  tooling. These wizard functions just ask the live service whether it
  already has the tag (`ollama list`) and skip the pull if so.
- **VRAM gating lives in the pull function.** `pull_coding_tier`
  refuses on `< 8 GB` GPUs and warns on `8–12 GB` before touching the
  network; the interactive `select_model` menu uses the same budget to
  recommend a default model.

## What good looks like

- Both files start with `#!/usr/bin/env bash` and `set -euo pipefail`.
- Every exported function has a header comment listing its inputs
  (env vars it reads) and outputs (env vars it writes).
- Interactive prompts degrade gracefully when `whiptail` is missing
  (fall back to numbered `select` / `read`).
- Every Ollama op flows through `_ollama_exec` — no direct
  `ollama pull` / `ollama list` calls.
- New model presets (like FEATURE-067's coder tier) get a dedicated
  `pull_<preset>` function rather than overloading `pull_selected_models`.

## Tools and skills

- **Bash** — all wizard files are bash with `set -euo pipefail`.
- **whiptail** — primary interactive UI (installed by `bootstrap.sh`).
- **jq** — used by `inference-profile.sh` to read/write `stack.json`.
- **Docker CLI** — `_ollama_exec` shells into the running Ollama container.
