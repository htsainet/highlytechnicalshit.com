#!/usr/bin/env bash
# scripts/components/stable-diffusion/rebuild.sh — Force a clean rebuild of
# the Stable Diffusion image when it has drifted from the current Dockerfile.
#
# Why this exists: `docker compose up -d` reuses the existing
# `hts-ai-stable-diffusion` image if one is present, even when the Dockerfile
# has been updated (e.g. the git >= 2.38 PPA fix in commit bd58418, or the
# switch to a full-history `generative-models` clone). A plain rebuild will
# also happily reuse cached layers above the changed line, so we force
# --no-cache when the user explicitly runs this script.
#
# Usage:
#   ./scripts/components/stable-diffusion/rebuild.sh              # full clean rebuild + start + health
#   ./scripts/components/stable-diffusion/rebuild.sh --keep-models # same, but preserve sd_models/sd_outputs volumes (default)
#   ./scripts/components/stable-diffusion/rebuild.sh --wipe        # also delete sd_models + sd_outputs volumes
#
# Safe to run repeatedly. Does not touch other components.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/compose.sh"
# shellcheck source=/dev/null
source "$REPO_DIR/scripts/components/stable-diffusion/stable-diffusion.sh"

WIPE=false
for arg in "$@"; do
  case "$arg" in
    --wipe)        WIPE=true ;;
    --keep-models) WIPE=false ;;
    *) warn "Unknown arg: $arg (ignored)" ;;
  esac
done

step "Stable Diffusion — stop container (if running)"
compose_down --profile sd || true

if [[ "$WIPE" == "true" ]]; then
  step "Stable Diffusion — wiping sd_models + sd_outputs volumes"
  # Volume names are prefixed with the compose project (hts-ai-stack_).
  for vol in hts-ai-stack_sd_models hts-ai-stack_sd_outputs; do
    if docker volume inspect "$vol" >/dev/null 2>&1; then
      docker volume rm "$vol" && ok "Removed volume $vol"
    fi
  done
else
  info "Keeping sd_models + sd_outputs volumes (use --wipe to reset)."
fi

step "Stable Diffusion — remove stale image"
if docker image inspect hts-ai-stable-diffusion >/dev/null 2>&1; then
  docker image rm -f hts-ai-stable-diffusion && ok "Removed image hts-ai-stable-diffusion"
else
  info "No existing image to remove."
fi

step "Stable Diffusion — rebuild (no cache)"
# Pass --no-cache through compose_build so every RUN (including the PPA
# install and the prebaked repo clones) re-executes.
compose_build --profile sd --no-cache

step "Stable Diffusion — start"
sd_start

step "Stable Diffusion — health"
sd_health || {
  warn "Healthcheck did not pass in budget. Dumping diagnostics..."
  "$SCRIPT_DIR/diag.sh" --save || true
  exit 1
}

ok "Stable Diffusion rebuilt and healthy."
