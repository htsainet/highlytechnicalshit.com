# helpers.sh — Shared Shell Functions

A sourced library of shared functions used by the `scripts/install/models/` scripts.
Not intended to be run directly.

---

## Usage

Source at the top of any setup script:

```bash
source "$(dirname "$0")/helpers.sh"
```

---

## Functions

### Logging

| Function | Output |
|----------|--------|
| `info "msg"` | Green `[INFO]` prefix |
| `warn "msg"` | Yellow `[WARN]` prefix |
| `skip "msg"` | Yellow `[SKIP]` prefix + "already present" |
| `step "msg"` | Cyan section header with `══` borders |
| `fail "msg"` | Red `[FAIL]` prefix |
| `ok "msg"` | Green `[OK]` prefix |

---

### `wait_for_ollama <container> <port>`

Blocks until the Ollama API returns a successful response on the given port.
Retries every 2 seconds, times out after 60 seconds (30 attempts).

```bash
wait_for_ollama ollama-prod 11434
```

---

### `start_container <service>`

Starts a docker compose service in detached mode.

```bash
start_container ollama-prod
```

---

### `stop_container <service>`

Stops a docker compose service gracefully.

```bash
stop_container ollama-prod
```

---

### `pull_ollama_if_missing <container> <port> <model>`

Pulls a model into Ollama only if it is not already present. Checks via the
`/api/tags` endpoint — skips silently if the model base name is found.

```bash
pull_ollama_if_missing ollama-prod 11434 mistral-nemo:latest
```

---

### `set_ollama_default <container> <model>`

Creates a `default` alias inside the Ollama container pointing to the given
model using a one-line Modelfile (`FROM <model>`). Allows OpenClaw and other
tools to reference `default` without hardcoding a model name.

```bash
set_ollama_default ollama-prod mistral-nemo:latest
```

---

## Used By

- `03-setup-models.sh`
- `scripts/install/models/prod.sh`
- `scripts/install/models/test.sh`
