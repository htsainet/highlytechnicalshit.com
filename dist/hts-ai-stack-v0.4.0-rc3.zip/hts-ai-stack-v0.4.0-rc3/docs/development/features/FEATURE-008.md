# Goose — General-Purpose AI Agent Runtime

**Priority:** LOW
**Target Release:** v0.6.0+
**Effort:** 4-6 hours (Rust binary, headless config, MCP client wiring)
**Risk:** Medium — headless/ACP mode is secondary to desktop UX; overlaps with
existing OpenClaw agent runtime
**Depends on:** FEATURE-007 (code-review-graph) recommended first — Goose can
consume it as an MCP client
**Blocks:** Nothing

## Scope

Add [Goose](https://github.com/aaif-goose/goose) (AAIF / Linux Foundation) as
an optional AI agent runtime that runs alongside OpenClaw, DeerFlow, and
OpenSpace. Goose is a Rust-based general-purpose agent with desktop app, CLI,
and API. Its primary value in this stack is as an **MCP client** that can
orchestrate calls across multiple MCP servers (OpenSpace, code-review-graph).

### Use Cases

- **MCP orchestration** — Goose consumes 70+ MCP extensions and can chain
  calls across OpenSpace (5000), code-review-graph (5001), and any future
  MCP servers in the stack
- **Alternative agent interface** — ACP API for programmatic agent access
  beyond Open WebUI's chat-based UX
- **Provider flexibility** — supports 15+ LLM providers; can route through
  llama-swap for local inference or fall back to cloud providers
- **Custom distributions** — Goose supports building preconfigured distros
  with specific extensions and branding

### Trade-offs

| Pro | Con |
|-----|-----|
| MCP client — can orchestrate your MCP servers | Duplicates agent orchestration (OpenClaw already does this) |
| Rust — fast, small memory | Desktop/CLI-first — headless Docker is secondary |
| 39k stars, 439 contributors, AAIF governance | Fast-moving upstream — harder to pin stable images |
| Supports Ollama as provider | ACP API less mature than chat UX |
| Apache 2.0 license | No GPU needs — pure orchestration overhead |

### When to Prioritize

- You need programmatic (non-chat) agent access via API
- You want to chain multiple MCP servers in a single agent workflow
- A Goose-specific extension becomes relevant to the stack
- The ACP API matures into a stable headless mode

## Implementation Notes

### Docker approach

```yaml
# docker-compose.yml
goose:
  build: ./docker/goose
  image: hts-ai-goose
  container_name: hts-ai-goose
  profiles: [goose]
  ports:
    - "${GOOSE_PORT:-3003}:3000"    # ACP API
  volumes:
    - goose_data:/app/data
    - goose_config:/app/config
  networks:
    - ai-network
  environment:
    - GOOSE_PROVIDER=ollama
    - OLLAMA_HOST=http://hts-ai-llama-swap:8080
```

### Dockerfile options

1. **Prebuilt binary** (preferred) — download release from GitHub Releases,
   copy into slim base image. Fast build, no Rust toolchain needed.

2. **Build from source** — requires Rust toolchain, protoc, 8GB+ RAM,
   45+ minute build. Only if patching upstream.

### Port allocation

| Host Port | Service | Container | Profile | Env Override |
|-----------|---------|-----------|---------|-------------|
| 3003 | Goose ACP API | hts-ai-goose | goose | `GOOSE_PORT` |

### MCP client configuration

Goose needs a config pointing at the stack's MCP servers:

```yaml
# .goose/config.yaml (inside container)
extensions:
  openspace:
    type: sse
    uri: http://hts-ai-openspace:5000/sse
  code-review-graph:
    type: sse
    uri: http://hts-ai-code-review-graph:5001/sse
```

### LLM routing

Point Goose at llama-swap as an Ollama-compatible endpoint. Goose supports
Ollama as a first-class provider — no wrapper needed.

## Acceptance Criteria

- ACP API responds on port 3003
- Goose connects to llama-swap and can complete a simple prompt
- MCP client discovers OpenSpace tools (if OpenSpace is running)
- MCP client discovers code-review-graph tools (if FEATURE-007 is deployed)
- Container runs headless without TTY

## References

- Repo: <https://github.com/aaif-goose/goose>
- Docs: <https://goose-docs.ai/>
- ACP protocol: <https://goose-docs.ai/docs/guides/acp-providers>
- AAIF (Linux Foundation): <https://aaif.io/>
- MCP: <https://modelcontextprotocol.io/>
