#!/usr/bin/env bash
# Quick diagnostic for audio-flamingo container
set -euo pipefail

CONTAINER="hts-ai-audio-flamingo"

echo "=== Container Status ==="
docker ps -a --filter "name=$CONTAINER" --format "Status: {{.Status}}"

echo ""
echo "=== Restart Count ==="
docker inspect "$CONTAINER" --format '{{.RestartCount}}' 2>/dev/null || echo "Container not found"

echo ""
echo "=== GPU VRAM (nvidia-smi) ==="
nvidia-smi --query-gpu=name,memory.total,memory.free,memory.used \
  --format=csv,noheader 2>/dev/null || echo "nvidia-smi not available"

echo ""
echo "=== Key Log Lines ==="
docker logs "$CONTAINER" 2>&1 | grep -iE 'ERROR|Exception|Traceback|VRAM|quantize|loaded|startup|device|AF_DEVICE|memory|OOM|killed' | tail -20

echo ""
echo "=== Last 10 Log Lines ==="
docker logs "$CONTAINER" --tail 10 2>&1

echo ""
echo "=== Health Check ==="
curl -sf http://localhost:8601/health 2>/dev/null && echo "" || echo "Not responding"
