#!/usr/bin/env bash
# scripts/utils/test-claw-isolation.sh — Isolation test for nemoclaw & htsclaw
#
# Destroys both claw instances, then brings each up individually to verify
# they work in isolation, then brings both up together.
#
# Usage:
#   ./scripts/utils/test-claw-isolation.sh              # full test (all 3 phases)
#   ./scripts/utils/test-claw-isolation.sh --phase1     # nemoclaw only
#   ./scripts/utils/test-claw-isolation.sh --phase2     # htsclaw only
#   ./scripts/utils/test-claw-isolation.sh --phase3     # both together
#   ./scripts/utils/test-claw-isolation.sh --nuke-only  # destroy both, stop
#
# Prerequisites:
#   - llama-swap must be running (port 8081)
#   - Docker must be running
#   - openshell + nemoclaw CLIs must be on PATH
#   - Run from the repo root, or set REPO_DIR
#
# The script is non-interactive: it forces --yes / --non-interactive where
# possible and auto-selects "overwrite" when sandboxes already exist.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${REPO_DIR:-$(cd "$SCRIPT_DIR/../.." && pwd)}"
LOG_DIR="$REPO_DIR/logs"
LOG_FILE="$LOG_DIR/test-claw-isolation-$(date +%Y%m%d-%H%M%S).log"
mkdir -p "$LOG_DIR"

source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
load_env

# ── Configuration ────────────────────────────────────────────────────────────
NEMOCLAW_SANDBOX="hts-ai-openshell-nemoclaw"
NEMOCLAW_PORT="${NEMOCLAW_PORT:-18789}"
HTSCLAW_SANDBOX="${HTSCLAW_SANDBOX_NAME:-hts-ai-openshell-htsclaw-gpu}"
HTSCLAW_PORT="${HTSCLAW_PORT:-18790}"
LLAMA_SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"
OLLAMA_MODEL="${OLLAMA_MODEL:-gemma4:e4b}"

# Results tracking
declare -A RESULTS
PASS=0
FAIL=0

# ── Helpers ──────────────────────────────────────────────────────────────────

_log_and_echo() {
  echo -e "$*"
  echo "[$(date '+%F %T')] $*" >> "$LOG_FILE"
}

_separator() {
  local msg="$1"
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  _log_and_echo "${CYAN}${BOLD}  $msg${NC}"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
}

_record() {
  local test_name="$1" result="$2"
  RESULTS["$test_name"]="$result"
  if [[ "$result" == "PASS" ]]; then
    PASS=$((PASS + 1))
    _log_and_echo "${GREEN}  ✔ ${test_name}: PASS${NC}"
  else
    FAIL=$((FAIL + 1))
    _log_and_echo "${RED}  ✘ ${test_name}: FAIL${NC}"
  fi
}

_preflight() {
  _separator "Pre-flight checks"

  local ok=true

  # Docker
  if docker info &>/dev/null; then
    info "Docker: running"
  else
    fail "Docker is not running — start it first."
  fi

  # openshell
  if command -v openshell &>/dev/null; then
    info "openshell: $(openshell --version 2>/dev/null || echo 'found')"
  else
    fail "openshell CLI not found on PATH."
  fi

  # nemoclaw
  if command -v nemoclaw &>/dev/null; then
    info "nemoclaw: $(nemoclaw --version 2>/dev/null || echo 'found')"
  else
    warn "nemoclaw CLI not found — nemoclaw phase will be skipped."
    ok=false
  fi

  # llama-swap
  if curl -sf "http://localhost:${LLAMA_SWAP_PORT}/health" >/dev/null 2>&1; then
    info "llama-swap (:${LLAMA_SWAP_PORT}): healthy"
  else
    fail "llama-swap (:${LLAMA_SWAP_PORT}) is not reachable — start the stack first."
  fi

  echo ""
}

# ── Nuke: destroy both instances ─────────────────────────────────────────────

_nuke_both() {
  _separator "NUKE — Destroying both nemoclaw and htsclaw"

  # ── Destroy NemoClaw ──
  step "Destroying NemoClaw sandbox '${NEMOCLAW_SANDBOX}'..."
  if command -v nemoclaw &>/dev/null; then
    # Stop openshell forward first
    openshell -g nemoclaw forward stop "$NEMOCLAW_PORT" 2>/dev/null || true

    # Destroy via nemoclaw CLI
    if nemoclaw list 2>/dev/null | grep -q "$NEMOCLAW_SANDBOX"; then
      NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$NEMOCLAW_SANDBOX" destroy --yes 2>/dev/null || {
        warn "nemoclaw destroy failed — trying openshell fallback..."
        openshell -g nemoclaw sandbox delete "$NEMOCLAW_SANDBOX" 2>/dev/null || true
      }
    else
      info "NemoClaw sandbox not found — already destroyed."
    fi

    # Stop the nemoclaw gateway container entirely
    local nemoclaw_cluster
    nemoclaw_cluster=$(docker ps --format '{{.Names}}' 2>/dev/null | grep '^openshell-cluster-nemoclaw$' || true)
    if [[ -n "$nemoclaw_cluster" ]]; then
      info "Stopping nemoclaw cluster container: ${nemoclaw_cluster}"
      docker rm -f "$nemoclaw_cluster" 2>/dev/null || true
    fi
  else
    info "nemoclaw CLI not available — skipping."
  fi

  # Disable nemoclaw health timer
  sudo systemctl disable --now hts-nemoclaw-health.timer 2>/dev/null || true
  ok "NemoClaw destroyed."

  # ── Destroy htsclaw ──
  step "Destroying htsclaw sandbox '${HTSCLAW_SANDBOX}'..."
  if command -v openshell &>/dev/null; then
    # Stop forward
    openshell forward stop -g htsclaw "$HTSCLAW_PORT" 2>/dev/null || true

    # Delete sandbox
    if openshell sandbox get "$HTSCLAW_SANDBOX" &>/dev/null 2>&1; then
      openshell sandbox delete -g htsclaw "$HTSCLAW_SANDBOX" 2>/dev/null || {
        warn "Failed to delete htsclaw sandbox."
      }
    else
      info "htsclaw sandbox not found — already destroyed."
    fi

    # Stop the htsclaw gateway container (check all containers, not just running)
    local htsclaw_cluster
    htsclaw_cluster=$(docker ps -a --format '{{.Names}}' 2>/dev/null | grep '^openshell-cluster-htsclaw$' || true)
    if [[ -n "$htsclaw_cluster" ]]; then
      info "Stopping htsclaw cluster container: ${htsclaw_cluster}"
      docker rm -f "$htsclaw_cluster" 2>/dev/null || true
    fi
  fi

  # Disable htsclaw health timer
  sudo systemctl disable --now hts-htsclaw-health.timer 2>/dev/null || true
  ok "htsclaw destroyed."

  # ── Verify both are gone ──
  step "Verifying clean state..."
  local stale_containers
  stale_containers=$(docker ps -a --format '{{.Names}}' 2>/dev/null | grep 'openshell-cluster-\(nemoclaw\|htsclaw\)' || true)
  if [[ -n "$stale_containers" ]]; then
    warn "Stale cluster containers still present:"
    echo "$stale_containers"
    echo "$stale_containers" | xargs docker rm -f 2>/dev/null || true
  fi

  # Verify ports are free
  local port_ok=true
  if ss -tln 2>/dev/null | grep -q ":${NEMOCLAW_PORT} "; then
    warn "Port ${NEMOCLAW_PORT} still in use!"
    port_ok=false
  fi
  if ss -tln 2>/dev/null | grep -q ":${HTSCLAW_PORT} "; then
    warn "Port ${HTSCLAW_PORT} still in use!"
    port_ok=false
  fi

  if [[ "$port_ok" == "true" ]]; then
    ok "Clean state verified — ports ${NEMOCLAW_PORT} and ${HTSCLAW_PORT} are free."
  else
    warn "Ports not fully free — waiting 10s for cleanup..."
    sleep 10
  fi

  echo ""
}

# ── Health check helper ──────────────────────────────────────────────────────

_wait_and_check_health() {
  local label="$1" port="$2" healthz_path="${3:-/healthz}" max_wait="${4:-120}"
  local elapsed=0

  info "Waiting for ${label} health on :${port}${healthz_path} (max ${max_wait}s)..."
  while [[ $elapsed -lt $max_wait ]]; do
    if curl -sf "http://localhost:${port}${healthz_path}" >/dev/null 2>&1; then
      ok "${label} is healthy on :${port}."
      return 0
    fi
    sleep 5
    elapsed=$((elapsed + 5))
    printf "  %ds..." "$elapsed"
  done
  echo ""
  warn "${label} did NOT become healthy within ${max_wait}s."
  return 1
}

# Also test inference (actually send a prompt)
_test_inference() {
  local label="$1" port="$2" model="$3"
  info "Testing inference through ${label} on :${port} (model: ${model})..."
  local response
  response=$(curl -sf --max-time 60 "http://localhost:${port}/v1/chat/completions" \
    -H "Content-Type: application/json" \
    -d "{\"model\":\"${model}\",\"messages\":[{\"role\":\"user\",\"content\":\"Say hello in one word.\"}],\"max_tokens\":5}" \
    2>&1) || {
    warn "Inference request failed for ${label}."
    return 1
  }

  if echo "$response" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['choices'][0]['message']['content'])" 2>/dev/null; then
    ok "Inference via ${label} succeeded."
    return 0
  else
    warn "Inference response malformed for ${label}: ${response:0:200}"
    return 1
  fi
}

# ── Phase 1: NemoClaw only ───────────────────────────────────────────────────

_phase1_nemoclaw() {
  _separator "PHASE 1 — NemoClaw only"

  if ! command -v nemoclaw &>/dev/null; then
    warn "nemoclaw CLI not available — skipping Phase 1."
    _record "phase1/nemoclaw-cli" "FAIL"
    return 1
  fi

  # Source NVM so node/npm are available
  local NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
  if [[ -s "$NVM_DIR/nvm.sh" ]]; then
    set +eu; source "$NVM_DIR/nvm.sh"; set -eu
  fi

  step "Phase 1: Onboarding NemoClaw..."
  local log_file="$LOG_DIR/nemoclaw-phase1-$(date +%Y%m%d-%H%M%S).log"

  # Warm up model first
  info "Warming up model '${OLLAMA_MODEL}' via llama-swap..."
  python3 -c "
import urllib.request, json, sys
req = urllib.request.Request(
    'http://localhost:${LLAMA_SWAP_PORT}/v1/chat/completions',
    data=json.dumps({
        'model': '${OLLAMA_MODEL}',
        'messages': [{'role': 'user', 'content': 'hi'}],
        'max_tokens': 1, 'stream': False
    }).encode(),
    headers={'Content-Type': 'application/json'}
)
try:
    r = urllib.request.urlopen(req, timeout=120)
    sys.exit(0 if r.status < 500 else 1)
except Exception as e:
    print(f'Warm-up: {e}', file=sys.stderr)
    sys.exit(0)
" 2>&1 || true

  # Keep model warm during onboard (gateway startup takes 8+ min and the
  # NemoClaw CLI validates the endpoint with a 15s timeout at step 3/8).
  # This background loop pings llama-swap every 60s to prevent model eviction.
  _start_model_keepalive() {
    while true; do
      curl -sf --max-time 30 "http://localhost:${LLAMA_SWAP_PORT}/v1/chat/completions" \
        -H "Content-Type: application/json" \
        -d "{\"model\":\"${OLLAMA_MODEL}\",\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}],\"max_tokens\":1}" \
        >/dev/null 2>&1 || true
      sleep 60
    done
  }
  _start_model_keepalive &
  local keepalive_pid=$!

  # Onboard via nemoclaw CLI
  timeout 600 bash -c "
    NEMOCLAW_EXPERIMENTAL=1 \
    NEMOCLAW_ACCEPT_THIRD_PARTY_SOFTWARE=1 \
    NEMOCLAW_RECREATE_SANDBOX=1 \
    NEMOCLAW_SANDBOX_NAME='${NEMOCLAW_SANDBOX}' \
    NEMOCLAW_PROVIDER='custom' \
    NEMOCLAW_ENDPOINT_URL='http://localhost:${LLAMA_SWAP_PORT}/v1' \
    COMPATIBLE_API_KEY='not-needed' \
    NEMOCLAW_MODEL='${OLLAMA_MODEL}' \
    NEMOCLAW_POLICY_PRESETS=npm,pypi,telegram,huggingface \
      nemoclaw onboard --non-interactive
  " </dev/null 2>>"$log_file"
  local onboard_rc=$?

  # Stop keepalive
  kill "$keepalive_pid" 2>/dev/null || true
  wait "$keepalive_pid" 2>/dev/null || true

  if [[ $onboard_rc -ne 0 ]]; then
    _record "phase1/nemoclaw-onboard" "FAIL"
    warn "NemoClaw onboard failed (exit ${onboard_rc}). Log: ${log_file}"
    info "Attempting to diagnose..."
    nemoclaw list 2>/dev/null || true
    docker ps --filter "name=openshell" --format "table {{.Names}}\t{{.Status}}" 2>/dev/null || true
    return 1
  fi
  _record "phase1/nemoclaw-onboard" "PASS"

  # Set up provider for in-sandbox access
  step "Phase 1: Configuring provider..."
  source "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh" 2>/dev/null || true
  if type _setup_provider &>/dev/null; then
    _setup_provider 2>&1 || warn "Provider setup had warnings."
  fi

  # Ensure port forward
  step "Phase 1: Setting up port forward..."
  openshell -g nemoclaw forward stop "$NEMOCLAW_PORT" 2>/dev/null || true
  openshell -g nemoclaw forward start "$NEMOCLAW_PORT" "$NEMOCLAW_SANDBOX" --background 2>/dev/null || {
    warn "Forward start failed — sandbox may not be ready yet."
  }
  _record "phase1/nemoclaw-forward" "PASS"

  # Health check
  step "Phase 1: Health check..."
  if _wait_and_check_health "NemoClaw" "$NEMOCLAW_PORT" "/healthz" 120; then
    _record "phase1/nemoclaw-health" "PASS"
  else
    _record "phase1/nemoclaw-health" "FAIL"
    # Diagnostic: check sandbox phase
    info "Sandbox status:"
    nemoclaw list 2>/dev/null || true
    NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$NEMOCLAW_SANDBOX" status 2>/dev/null || true
    openshell -g nemoclaw forward list 2>/dev/null || true
  fi

  # Verify htsclaw port is NOT in use (isolation check)
  step "Phase 1: Isolation check — htsclaw port should be free..."
  if ss -tln 2>/dev/null | grep -q ":${HTSCLAW_PORT} "; then
    _record "phase1/htsclaw-port-free" "FAIL"
    warn "Port ${HTSCLAW_PORT} is in use — htsclaw may not be fully destroyed!"
  else
    _record "phase1/htsclaw-port-free" "PASS"
  fi

  ok "Phase 1 complete."
}

# ── Phase 2: htsclaw only ────────────────────────────────────────────────────

_phase2_htsclaw() {
  _separator "PHASE 2 — htsclaw only"

  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not available — cannot run Phase 2."
    _record "phase2/openshell-cli" "FAIL"
    return 1
  fi

  step "Phase 2: Starting htsclaw..."

  # Use the component script directly
  local htsclaw_script="$REPO_DIR/scripts/components/htsclaw/htsclaw.sh"
  if [[ ! -f "$htsclaw_script" ]]; then
    _record "phase2/htsclaw-script" "FAIL"
    fail "htsclaw.sh not found at ${htsclaw_script}"
  fi

  # Run htsclaw start (configure + create sandbox + forward + health)
  # Pipe 'o' to auto-select overwrite if sandbox already exists
  echo "o" | bash "$htsclaw_script" --start 2>&1 | tee -a "$LOG_FILE"
  local start_rc=${PIPESTATUS[1]}

  if [[ $start_rc -ne 0 ]]; then
    _record "phase2/htsclaw-start" "FAIL"
    warn "htsclaw start failed (exit ${start_rc})."
    # Diagnostic
    openshell sandbox list 2>/dev/null || true
    openshell -g htsclaw forward list 2>/dev/null || true
    docker ps --filter "name=openshell" --format "table {{.Names}}\t{{.Status}}" 2>/dev/null || true
  else
    _record "phase2/htsclaw-start" "PASS"
  fi

  # Health check
  step "Phase 2: Health check..."
  if _wait_and_check_health "htsclaw" "$HTSCLAW_PORT" "/healthz" 120; then
    _record "phase2/htsclaw-health" "PASS"
  else
    _record "phase2/htsclaw-health" "FAIL"
    # Diagnostic
    info "Sandbox status:"
    openshell sandbox get "$HTSCLAW_SANDBOX" 2>/dev/null || true
    openshell -g htsclaw forward list 2>/dev/null || true
    # Check gateway log inside sandbox
    openshell sandbox exec -g htsclaw -n "$HTSCLAW_SANDBOX" \
      -- cat /tmp/openclaw-gw.log 2>/dev/null || true
  fi

  # Verify nemoclaw port is NOT in use (isolation check)
  step "Phase 2: Isolation check — nemoclaw port should be free..."
  if ss -tln 2>/dev/null | grep -q ":${NEMOCLAW_PORT} "; then
    _record "phase2/nemoclaw-port-free" "FAIL"
    warn "Port ${NEMOCLAW_PORT} is in use — nemoclaw may not be fully destroyed!"
  else
    _record "phase2/nemoclaw-port-free" "PASS"
  fi

  ok "Phase 2 complete."
}

# ── Phase 3: Both together ───────────────────────────────────────────────────

_phase3_both() {
  _separator "PHASE 3 — Both nemoclaw + htsclaw together"

  local nemo_ok=false
  local hts_ok=false

  # ── Bring up NemoClaw ──
  step "Phase 3: Onboarding NemoClaw..."
  if command -v nemoclaw &>/dev/null; then
    local NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
    if [[ -s "$NVM_DIR/nvm.sh" ]]; then
      set +eu; source "$NVM_DIR/nvm.sh"; set -eu
    fi

    local log_file="$LOG_DIR/nemoclaw-phase3-$(date +%Y%m%d-%H%M%S).log"

    # Keep model warm during onboard (same as Phase 1)
    _start_model_keepalive() {
      while true; do
        curl -sf --max-time 30 "http://localhost:${LLAMA_SWAP_PORT}/v1/chat/completions" \
          -H "Content-Type: application/json" \
          -d "{\"model\":\"${OLLAMA_MODEL}\",\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}],\"max_tokens\":1}" \
          >/dev/null 2>&1 || true
        sleep 60
      done
    }
    _start_model_keepalive &
    local keepalive_pid=$!

    timeout 600 bash -c "
      NEMOCLAW_EXPERIMENTAL=1 \
      NEMOCLAW_ACCEPT_THIRD_PARTY_SOFTWARE=1 \
      NEMOCLAW_RECREATE_SANDBOX=1 \
      NEMOCLAW_SANDBOX_NAME='${NEMOCLAW_SANDBOX}' \
      NEMOCLAW_PROVIDER='custom' \
      NEMOCLAW_ENDPOINT_URL='http://localhost:${LLAMA_SWAP_PORT}/v1' \
      COMPATIBLE_API_KEY='not-needed' \
      NEMOCLAW_MODEL='${OLLAMA_MODEL}' \
      NEMOCLAW_POLICY_PRESETS=npm,pypi,telegram,huggingface \
        nemoclaw onboard --non-interactive
    " </dev/null 2>>"$log_file"

    # Stop keepalive
    kill "$keepalive_pid" 2>/dev/null || true
    wait "$keepalive_pid" 2>/dev/null || true

    if [[ $? -eq 0 ]]; then
      _record "phase3/nemoclaw-onboard" "PASS"
      nemo_ok=true
      # Provider + forward
      source "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh" 2>/dev/null || true
      if type _setup_provider &>/dev/null; then _setup_provider 2>&1 || true; fi
      openshell -g nemoclaw forward stop "$NEMOCLAW_PORT" 2>/dev/null || true
      openshell -g nemoclaw forward start "$NEMOCLAW_PORT" "$NEMOCLAW_SANDBOX" --background 2>/dev/null || true
    else
      _record "phase3/nemoclaw-onboard" "FAIL"
      warn "NemoClaw onboard failed in Phase 3. Log: ${log_file}"
    fi
  else
    warn "nemoclaw CLI not available."
    _record "phase3/nemoclaw-onboard" "FAIL"
  fi

  # ── Bring up htsclaw immediately after ──
  step "Phase 3: Starting htsclaw (right after nemoclaw)..."
  echo "o" | bash "$REPO_DIR/scripts/components/htsclaw/htsclaw.sh" --start 2>&1 | tee -a "$LOG_FILE"
  if [[ ${PIPESTATUS[1]} -eq 0 ]]; then
    _record "phase3/htsclaw-start" "PASS"
    hts_ok=true
  else
    _record "phase3/htsclaw-start" "FAIL"
  fi

  # ── Wait for both to be healthy ──
  step "Phase 3: Health checks (both)..."

  if [[ "$nemo_ok" == "true" ]]; then
    if _wait_and_check_health "NemoClaw" "$NEMOCLAW_PORT" "/healthz" 120; then
      _record "phase3/nemoclaw-health" "PASS"
    else
      _record "phase3/nemoclaw-health" "FAIL"
    fi
  fi

  if [[ "$hts_ok" == "true" ]]; then
    if _wait_and_check_health "htsclaw" "$HTSCLAW_PORT" "/healthz" 120; then
      _record "phase3/htsclaw-health" "PASS"
    else
      _record "phase3/htsclaw-health" "FAIL"
    fi
  fi

  # ── Coexistence check ──
  step "Phase 3: Coexistence check..."
  local both_listening=true
  if ! ss -tln 2>/dev/null | grep -q ":${NEMOCLAW_PORT} "; then
    warn "NemoClaw port ${NEMOCLAW_PORT} not listening."
    both_listening=false
  fi
  if ! ss -tln 2>/dev/null | grep -q ":${HTSCLAW_PORT} "; then
    warn "htsclaw port ${HTSCLAW_PORT} not listening."
    both_listening=false
  fi
  if [[ "$both_listening" == "true" ]]; then
    _record "phase3/coexistence" "PASS"
    ok "Both services listening on their expected ports."
  else
    _record "phase3/coexistence" "FAIL"
  fi

  # ── Docker container state ──
  step "Phase 3: Container inventory..."
  docker ps --filter "name=openshell" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null || true

  ok "Phase 3 complete."
}

# ── Summary ──────────────────────────────────────────────────────────────────

_summary() {
  _separator "TEST RESULTS SUMMARY"

  for test_name in $(echo "${!RESULTS[@]}" | tr ' ' '\n' | sort); do
    local result="${RESULTS[$test_name]}"
    if [[ "$result" == "PASS" ]]; then
      echo -e "  ${GREEN}✔${NC} ${test_name}"
    else
      echo -e "  ${RED}✘${NC} ${test_name}"
    fi
  done

  echo ""
  echo -e "  ${BOLD}Total: $((PASS + FAIL)) tests — ${GREEN}${PASS} passed${NC}, ${RED}${FAIL} failed${NC}${NC}"
  echo ""
  info "Full log: ${LOG_FILE}"

  if [[ $FAIL -gt 0 ]]; then
    return 1
  fi
}

# ── Main ─────────────────────────────────────────────────────────────────────

main() {
  local run_phase1=false run_phase2=false run_phase3=false nuke_only=false

  if [[ $# -eq 0 ]]; then
    # Default: run all phases
    run_phase1=true; run_phase2=true; run_phase3=true
  fi

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --phase1)    run_phase1=true; shift ;;
      --phase2)    run_phase2=true; shift ;;
      --phase3)    run_phase3=true; shift ;;
      --nuke-only) nuke_only=true; shift ;;
      --help|-h)
        echo "Usage: $0 [--phase1] [--phase2] [--phase3] [--nuke-only]"
        echo ""
        echo "  --phase1     NemoClaw only (destroy both → bring up nemoclaw → test)"
        echo "  --phase2     htsclaw only  (destroy both → bring up htsclaw  → test)"
        echo "  --phase3     Both together (destroy both → bring up both     → test)"
        echo "  --nuke-only  Destroy both and stop"
        echo ""
        echo "  No flags = run all 3 phases sequentially"
        exit 0 ;;
      *) shift ;;
    esac
  done

  _separator "HTS AI Stack — Claw Isolation Test"
  info "Log file: ${LOG_FILE}"
  info "Date: $(date -Iseconds)"
  echo ""

  _preflight

  if [[ "$nuke_only" == "true" ]]; then
    _nuke_both
    ok "Nuke complete. Both nemoclaw and htsclaw are destroyed."
    exit 0
  fi

  # ── Phase 1: NemoClaw only ──
  if [[ "$run_phase1" == "true" ]]; then
    _nuke_both
    _phase1_nemoclaw || true
    echo ""
    info "Phase 1 done. Nuking before next phase..."
    _nuke_both
  fi

  # ── Phase 2: htsclaw only ──
  if [[ "$run_phase2" == "true" ]]; then
    if [[ "$run_phase1" != "true" ]]; then
      _nuke_both
    fi
    _phase2_htsclaw || true
    echo ""
    info "Phase 2 done. Nuking before next phase..."
    _nuke_both
  fi

  # ── Phase 3: Both together ──
  if [[ "$run_phase3" == "true" ]]; then
    if [[ "$run_phase1" != "true" && "$run_phase2" != "true" ]]; then
      _nuke_both
    fi
    _phase3_both || true
  fi

  _summary
}

main "$@"
