#!/usr/bin/env bash
# scripts/lib/model.sh – generic model handling utilities.
# -------------------------------------------------------------
# Centralised helper for components that need to fetch models.
# Reads the top‑level `model-registry.json` (repo root) to obtain URLs
# and optional metadata (license, trust).  Functions provided:
#   model_get_url <service> <type> <filename>
#   model_download_if_missing <service> <type> <filename> <volume> <nas_dir>
# -------------------------------------------------------------

# Resolve repository root (most scripts set REPO_DIR; fallback to script location).
if [[ -z "${REPO_DIR:-}" ]]; then
  REPO_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
fi

MODEL_REGISTRY="${REPO_DIR}/model-registry.json"

# model_get_url: return the download URL for a given model entry, or empty string.
model_get_url() {
  local svc="$1" type="$2" fn="$3"
  if [[ ! -f "$MODEL_REGISTRY" ]]; then
    echo ""; return 1
  fi
  jq -r --arg svc "$svc" --arg type "$type" --arg fn "$fn" \
    ".[$svc][$type].options[$fn].url // empty" "$MODEL_REGISTRY"
}

# model_download_if_missing: generic helper to fetch a model file into a Docker volume.
# It checks the volume for the file, then tries a NAS cache, and finally downloads from the URL.
# Returns 0 on success (file present after the call) or 1 on failure.
model_download_if_missing() {
  local svc="$1" type="$2" fn="$3" vol="$4" nas_dir="$5"

  # Resolve the download URL from the registry
  local url
  url=$(model_get_url "$svc" "$type" "$fn")
  if [[ -z "$url" ]]; then
    warn "No URL found for ${svc}/${type}/${fn} – skipping."
    return 1
  fi

  # Determine target sub‑directory inside the volume.
  # Stable Diffusion expects files under /models/Stable-diffusion/
  # Use that convention when the service is stable_diffusion, otherwise use the service name.
  local subdir
  if [[ "$svc" == "stable_diffusion" ]]; then
    subdir="Stable-diffusion"
  else
    subdir="${svc}"
  fi

  # 0️⃣ Check if the file already exists in the volume
  local already_exists
  already_exists=$(docker run --rm -v "${vol}:/models" alpine sh -c "[ -f /models/${subdir}/${fn} ] && echo yes || echo no")
  if [[ "$already_exists" == "yes" ]]; then
    info "${svc}/${type}: ${fn} already present in volume."
    return 0
  fi

  # 1️⃣ Try NAS cache if provided
  if [[ -n "$nas_dir" && -d "$nas_dir" ]]; then
    local nas_file="${nas_dir}/${fn}"
    if [[ -f "$nas_file" ]]; then
      local size
      size=$(stat -c%s "$nas_file" 2>/dev/null || echo 0)
      if (( size > 1000000 )); then
        info "Copying ${fn} from NAS cache..."
        docker run --rm \
          -v "${vol}:/models" \
          -v "${nas_dir}:/nas-cache:ro" \
          alpine sh -c "
            mkdir -p /models/${subdir}
            cp /nas-cache/${fn} /models/${subdir}/${fn}
          " && ok "Copied ${fn} from NAS." && return 0
        warn "Failed to copy ${fn} from NAS cache."
      else
        warn "NAS file ${fn} is too small (${size} bytes) – treating as incomplete."
      fi
    fi
  fi

  # 2️⃣ Download from the internet
  info "Downloading ${fn} from $url..."
  local tmp_dir=$(mktemp -d)
  local tmp_file="${tmp_dir}/${fn}"
  if curl -fSL --retry 3 --retry-delay 5 --progress-bar -o "$tmp_file" "$url"; then
    info "Copying ${fn} into volume..."
    docker run --rm \
      -v "${vol}:/models" \
      -v "${tmp_dir}:/downloads:ro" \
      alpine sh -c "
        mkdir -p /models/${subdir}
        cp /downloads/${fn} /models/${subdir}/${fn}
      " && ok "${fn} downloaded and stored." && rm -rf "$tmp_dir" && return 0
    warn "Failed to copy ${fn} into volume after download."
  else
    warn "Failed to download ${fn} from $url."
  fi
  rm -rf "$tmp_dir"
  return 1
}
