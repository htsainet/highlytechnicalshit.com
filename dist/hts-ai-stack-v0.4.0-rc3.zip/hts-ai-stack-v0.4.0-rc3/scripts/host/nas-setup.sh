#!/usr/bin/env bash
# scripts/host/nas-setup.sh — Interactive NAS configuration
#
# Configures:
#   1. Docker registry mirror (optional — for local image pulls)
#   2. NFS share mounts (model backup, docker volume backup, timeshift)
#
# Writes NAS settings to ~/.config/htsai/nas.env (survives repo nuke-and-pave).
# Docker MIRROR setting is written to the repo .env (build concern only).
#
# Usage:
#   ./scripts/host/nas-setup.sh          # interactive menu
#   ./scripts/host/nas-setup.sh --skip   # non-interactive (use existing config)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

REPO_ENV_FILE="$REPO_DIR/.env"
# When run with sudo, use the real user's home
_REAL_HOME="${HOME}"
if [[ -n "${SUDO_USER:-}" ]]; then
  _REAL_HOME=$(eval echo "~${SUDO_USER}")
fi
NAS_ENV_DIR="${_REAL_HOME}/.config/htsai"
NAS_ENV_FILE="${NAS_ENV_DIR}/nas.env"
mkdir -p "$NAS_ENV_DIR"
W=72   # dialog width

# ── Ensure whiptail is available ─────────────────────────────────────────────
if ! command -v whiptail &>/dev/null; then
  fail "whiptail is required but not installed. Run: sudo apt-get install -y whiptail"
fi

# ── Ensure nfs-common is available (needed for NFS mounts) ───────────────────
if ! dpkg -s nfs-common &>/dev/null; then
  info "Installing nfs-common (required for NFS mounts)..."
  apt-get install -y nfs-common
fi

# ── Load existing nas.env if present ──────────────────────────────────────────
NAS_ENABLED="${NAS_ENABLED:-false}"
NAS_HOST="${NAS_HOST:-}"
NAS_NFS4_DOMAIN="${NAS_NFS4_DOMAIN:-htsai}"
MIRROR="${MIRROR:-}"

NAS_MODEL_CACHE_SHARE="${NAS_MODEL_CACHE_SHARE:-}"
NAS_MODEL_CACHE_MOUNT="${NAS_MODEL_CACHE_MOUNT:-/mnt/htsai-model-backup}"
NAS_DOCKER_BACKUP_SHARE="${NAS_DOCKER_BACKUP_SHARE:-}"
NAS_DOCKER_BACKUP_MOUNT="${NAS_DOCKER_BACKUP_MOUNT:-/mnt/htsai-docker-volume-backup}"
NAS_TIMESHIFT_SHARE="${NAS_TIMESHIFT_SHARE:-}"
NAS_TIMESHIFT_MOUNT="${NAS_TIMESHIFT_MOUNT:-/mnt/htsai-timeshift-backup}"

if [[ -f "$NAS_ENV_FILE" ]]; then
  load_env "$NAS_ENV_FILE"
fi
if [[ -f "$REPO_ENV_FILE" ]]; then
  # Only load MIRROR from repo .env
  MIRROR=$(grep '^MIRROR=' "$REPO_ENV_FILE" 2>/dev/null | cut -d= -f2-) || true
fi

# ── Helper: whiptail wrappers ────────────────────────────────────────────────
wt_yesno() {
  local title="$1" text="$2" default="${3:-no}"
  local flags=()
  [[ "$default" == "yes" ]] || flags+=(--defaultno)
  if whiptail --title "$title" --yesno "$text" 10 $W "${flags[@]}" 3>&1 1>&2 2>&3; then
    echo "true"
  else
    echo "false"
  fi
}

wt_input() {
  local title="$1" text="$2" default="${3:-}"
  whiptail --title "$title" --inputbox "$text" 10 $W "$default" 3>&1 1>&2 2>&3
}

# ── Write a key=value to nas.env (idempotent) + set in current shell ─────────
env_set() {
  local key="$1" value="$2" file="${3:-$NAS_ENV_FILE}"
  # Set in current shell so later code sees it
  export "${key}=${value}"
  touch "$file"
  if grep -q "^${key}=" "$file" 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$file"
  else
    echo "${key}=${value}" >> "$file"
  fi
}

# ══════════════════════════════════════════════════════════════════════════════
# Step 1: Docker Registry Mirror
# ══════════════════════════════════════════════════════════════════════════════
step "NAS Setup — Docker Registry Mirror"

_HAS_MIRROR=$(wt_yesno "Docker Mirror" \
  "Do you have a local Docker registry mirror?\n\n(A registry running on your NAS that caches images\nfor faster builds and offline use.)" "no")

if [[ "$_HAS_MIRROR" == "true" ]]; then
  _MIRROR_HOST=$(wt_input "Docker Mirror — Host" \
    "Registry hostname or IP with port:\n\n  Examples:\n    my-nas:5000\n    192.168.1.50:5000\n    synology.local:5000" \
    "${MIRROR:-}")

  # Ensure trailing slash
  _MIRROR_HOST="${_MIRROR_HOST%/}/"

  # Validate connectivity
  _MIRROR_BASE="${_MIRROR_HOST%/}"
  _MIRROR_IP="${_MIRROR_BASE%%:*}"
  if ping -c 1 -W 2 "$_MIRROR_IP" &>/dev/null; then
    ok "Mirror host ${_MIRROR_IP} is reachable."
  else
    warn "Cannot reach ${_MIRROR_IP} — mirror may not work until host is online."
  fi

  MIRROR="$_MIRROR_HOST"
  env_set "MIRROR" "$MIRROR" "$REPO_ENV_FILE"

  # Remind about insecure-registries if using HTTP
  echo ""
  info "If this registry uses HTTP (not HTTPS), add it to your Docker daemon:"
  echo ""
  echo "    /etc/docker/daemon.json:"
  echo "    { \"insecure-registries\": [\"${_MIRROR_BASE}\"] }"
  echo ""
  echo "    Then: sudo systemctl restart docker"
  echo ""
else
  MIRROR=""
  env_set "MIRROR" "" "$REPO_ENV_FILE"
  info "No mirror configured — images will pull from upstream registries."
fi

# ══════════════════════════════════════════════════════════════════════════════
# Step 2: NAS / NFS Shares
# ══════════════════════════════════════════════════════════════════════════════
step "NAS Setup — NFS Shares"

_HAS_NAS=$(wt_yesno "NAS — NFS Shares" \
  "Do you have a NAS with NFS shares for backups and model storage?\n\nExpected shares:\n  • htsai-model-backup\n  • htsai-docker-volume-backup\n  • htsai-timeshift-backup" "no")

if [[ "$_HAS_NAS" == "true" ]]; then
  NAS_ENABLED="true"

  # ── NAS hostname ──────────────────────────────────────────────────────────
  # Auto-discover via arp-scan if available
  _ARP_ITEMS=()
  if command -v arp-scan &>/dev/null; then
    _ARP_RAW=""
    _ARP_SCAN_CMD=()

    if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
      _ARP_SCAN_CMD=(arp-scan -l)
    elif command -v sudo &>/dev/null && sudo -n true 2>/dev/null; then
      _ARP_SCAN_CMD=(sudo -n arp-scan -l)
    fi

    if [[ ${#_ARP_SCAN_CMD[@]} -gt 0 ]]; then
      info "Scanning local network for NAS devices..."
      _ARP_RAW=$(timeout 8s "${_ARP_SCAN_CMD[@]}" 2>/dev/null | grep -E '^[0-9]' | sort -t. -k4 -n) || true
    fi

    while IFS=$'\t' read -r ip mac vendor; do
      [[ -z "$ip" ]] && continue
      _ARP_ITEMS+=("$ip" "${vendor:-$mac}")
    done <<< "$_ARP_RAW"
  fi

  if [[ ${#_ARP_ITEMS[@]} -gt 0 ]]; then
    NAS_HOST=$(whiptail --title "NAS — Select Device" \
      --menu "Select your NAS (or Cancel to enter manually):" \
      18 $W 10 "${_ARP_ITEMS[@]}" \
      3>&1 1>&2 2>&3) || NAS_HOST=""
  fi

  if [[ -z "$NAS_HOST" ]]; then
    NAS_HOST=$(wt_input "NAS — Hostname" \
      "NAS hostname or IP address:" "${NAS_HOST:-}")
  fi

  env_set "NAS_HOST" "$NAS_HOST"
  env_set "NAS_ENABLED" "true"

  # ── NFSv4.1 domain ───────────────────────────────────────────────────────
  NAS_NFS4_DOMAIN=$(wt_input "NAS — NFSv4.1 Domain" \
    "NFSv4.1 domain name\n\n(Synology: Control Panel → File Services → NFS\n → Advanced → NFSv4/4.1 domain)" \
    "${NAS_NFS4_DOMAIN:-htsai}")
  env_set "NAS_NFS4_DOMAIN" "$NAS_NFS4_DOMAIN"

  # ── Share detection + selection ──────────────────────────────────────────
  _S_NAMES=("htsai-model-backup"       "htsai-docker-volume-backup" "htsai-timeshift-backup")
  _S_VARS_SHARE=("NAS_MODEL_CACHE_SHARE" "NAS_DOCKER_BACKUP_SHARE"  "NAS_TIMESHIFT_SHARE")
  _S_VARS_MOUNT=("NAS_MODEL_CACHE_MOUNT" "NAS_DOCKER_BACKUP_MOUNT"  "NAS_TIMESHIFT_MOUNT")
  _S_LABELS=("Model backup (AI models)" "Docker volume backups"     "Timeshift system backups")
  _S_DEFAULTS_MOUNT=("/mnt/htsai-model-backup" "/mnt/htsai-docker-volume-backup" "/mnt/htsai-timeshift-backup")

  # Probe NFS exports
  _EXPORTS=""
  if command -v showmount &>/dev/null && [[ -n "$NAS_HOST" ]]; then
    info "Probing NFS exports on ${NAS_HOST}..."
    _EXPORTS=$(showmount -e "$NAS_HOST" 2>/dev/null | awk '{print $1}') || true
  fi

  for i in "${!_S_NAMES[@]}"; do
    _SHARE_NAME="${_S_NAMES[$i]}"
    _LABEL="${_S_LABELS[$i]}"
    _VAR_SHARE="${_S_VARS_SHARE[$i]}"
    _VAR_MOUNT="${_S_VARS_MOUNT[$i]}"
    _DEFAULT_MOUNT="${_S_DEFAULTS_MOUNT[$i]}"

    # Check if share exists on NAS
    _DETECTED=""
    if echo "$_EXPORTS" | grep -qE "/${_SHARE_NAME}$"; then
      _DETECTED=$(echo "$_EXPORTS" | grep -E "/${_SHARE_NAME}$" | head -1)
      ok "Found: ${_DETECTED}"
    else
      warn "Not found: /volume1/${_SHARE_NAME}"
    fi

    _ENABLE=$(wt_yesno "NAS — ${_LABEL}" \
      "Enable ${_LABEL}?\n\nShare: ${_DETECTED:-/volume1/${_SHARE_NAME}}" "yes")

    if [[ "$_ENABLE" == "true" ]]; then
      _SHARE_PATH=$(wt_input "NAS — ${_LABEL}" \
        "NFS share path:" "${_DETECTED:-/volume1/${_SHARE_NAME}}")
      _MOUNT_PATH=$(wt_input "NAS — ${_LABEL}" \
        "Local mount point:" "${_DEFAULT_MOUNT}")

      env_set "$_VAR_SHARE" "$_SHARE_PATH"
      env_set "$_VAR_MOUNT" "$_MOUNT_PATH"
      ok "${_SHARE_NAME} → ${_MOUNT_PATH}"
    else
      env_set "$_VAR_SHARE" ""
      env_set "$_VAR_MOUNT" ""
      info "Skipped ${_SHARE_NAME}"
    fi
  done

  # ── Apply NFS configuration ──────────────────────────────────────────────
  _APPLY=$(wt_yesno "NAS — Apply Now" \
    "Configure idmapd and fstab now?\n\n(This will update /etc/idmapd.conf and /etc/fstab\nand mount the shares immediately.)" "yes")

  if [[ "$_APPLY" == "true" ]]; then
    # Update stack.json so nas.sh can read the config
    python3 - "$REPO_DIR/config/stack.json" "$NAS_HOST" "$NAS_NFS4_DOMAIN" \
      "${NAS_MODEL_CACHE_SHARE:-}" "${NAS_MODEL_CACHE_MOUNT:-}" \
      "${NAS_DOCKER_BACKUP_SHARE:-}" "${NAS_DOCKER_BACKUP_MOUNT:-}" \
      "${NAS_TIMESHIFT_SHARE:-}" "${NAS_TIMESHIFT_MOUNT:-}" <<'PYEOF'
import json, sys
path, host, domain = sys.argv[1], sys.argv[2], sys.argv[3]
model_share, model_mount = sys.argv[4], sys.argv[5]
docker_share, docker_mount = sys.argv[6], sys.argv[7]
ts_share, ts_mount = sys.argv[8], sys.argv[9]

with open(path) as f:
    cfg = json.load(f)

uses = []
if model_share:  uses.append("model_cache")
if docker_share: uses.append("docker_backups")
if ts_share:     uses.append("timeshift")

cfg["nas"] = {
    "enabled": True,
    "host": host,
    "nfs4_domain": domain,
    "uses": uses,
    "model_cache_share": model_share,
    "model_cache_mount": model_mount or "/mnt/htsai-model-backup",
    "docker_backup_share": docker_share,
    "docker_backup_mount": docker_mount or "/mnt/htsai-docker-volume-backup",
    "timeshift_share": ts_share,
    "timeshift_mount": ts_mount or "/mnt/htsai-timeshift-backup",
}

with open(path, "w") as f:
    json.dump(cfg, f, indent=2)
    f.write("\n")
PYEOF
    ok "stack.json updated with NAS config"

    info "Applying NFS configuration via scripts/host/nas.sh..."
    bash "$REPO_DIR/scripts/host/nas.sh"
  else
    info "Skipped — apply later with: ./scripts/host/nas.sh"
  fi
else
  NAS_ENABLED="false"
  env_set "NAS_ENABLED" "false"
  info "NAS not configured — NFS shares skipped."
fi

# ══════════════════════════════════════════════════════════════════════════════
# Summary
# ══════════════════════════════════════════════════════════════════════════════
echo ""
step "NAS Setup — Complete"
echo ""

if [[ -n "$MIRROR" ]]; then
  info "Docker mirror:  ${MIRROR}"
else
  info "Docker mirror:  (none — pulling from upstream)"
fi

if [[ "$NAS_ENABLED" == "true" ]]; then
  info "NAS host:       ${NAS_HOST}"
  info "NFSv4 domain:   ${NAS_NFS4_DOMAIN}"
  [[ -n "${NAS_MODEL_CACHE_SHARE:-}" ]]  && info "Model backup:   ${NAS_HOST}:${NAS_MODEL_CACHE_SHARE} → ${NAS_MODEL_CACHE_MOUNT}"
  [[ -n "${NAS_DOCKER_BACKUP_SHARE:-}" ]] && info "Docker backup:  ${NAS_HOST}:${NAS_DOCKER_BACKUP_SHARE} → ${NAS_DOCKER_BACKUP_MOUNT}"
  [[ -n "${NAS_TIMESHIFT_SHARE:-}" ]]    && info "Timeshift:      ${NAS_HOST}:${NAS_TIMESHIFT_SHARE} → ${NAS_TIMESHIFT_MOUNT}"
else
  info "NAS:            (not configured)"
fi

echo ""
info "Settings saved to: ${NAS_ENV_FILE}"
[[ -n "$MIRROR" ]] && info "Docker mirror saved to: ${REPO_ENV_FILE}"
echo ""
