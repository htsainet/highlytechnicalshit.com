# Tailscale References

Last updated: 2026-04-15

## Upstream

- [GitHub — tailscale/tailscale](https://github.com/tailscale/tailscale)

## Official documentation

- [Tailscale Docs](https://tailscale.com/kb)
- [Tailscale CLI Reference](https://tailscale.com/kb/1080/cli)
