#!/usr/bin/env bash
# scripts/lib/assert-postcondition.sh — "success print ≠ invariant met" helper.
# Source this file; do NOT run directly.
#
# The recurring bug class this helper addresses:
#   - `docker compose up -d` prints success while the image is stale.
#   - `converge.sh` reports `success` for Ollama while `/api/tags` is empty.
#   - `openshell provider update ... → ✓ Updated` while the provider isn't
#     actually reachable from the sandbox.
#
# Usage (component scripts):
#
#   source "${REPO_DIR}/scripts/lib/assert-postcondition.sh"
#
#   _probe_models_pulled() {
#     curl -fsS --max-time 5 http://localhost:11434/api/tags \
#       | grep -q '"name":"smollm2:135m"'
#   }
#   assert_postcondition "starter model present in /api/tags" _probe_models_pulled
#
# Contract:
#   assert_postcondition <human-label> <check-fn-or-cmd> [args...]
#     - <check-fn-or-cmd> is a bash function name OR an argv array.
#     - Exit 0  = invariant satisfied; prints "[verified] <label>".
#     - Exit !0 = invariant NOT met; prints label, the check command, and
#                 the captured stderr tail, then exits with code 2.
#
# No deps, no sed/awk. Safe to source multiple times.

# ── Guard against double-source ───────────────────────────────────────────────
if [[ -n "${_ASSERT_POSTCONDITION_LOADED:-}" ]]; then
  return 0 2>/dev/null || true
fi
_ASSERT_POSTCONDITION_LOADED=1

# Colors — only set if caller hasn't already sourced common.sh.
: "${GREEN:=\033[0;32m}"
: "${RED:=\033[0;31m}"
: "${YELLOW:=\033[1;33m}"
: "${NC:=\033[0m}"

# Max stderr lines to show on failure.
: "${ASSERT_POSTCONDITION_STDERR_LINES:=20}"

# assert_postcondition <label> <check> [args...]
#
# Runs the check with stderr captured to a tempfile. stdout from the check
# is discarded (checks are assertions, not producers). On failure, the
# captured stderr tail is printed to stderr along with the label and the
# argv that was invoked, and the helper exits 2.
assert_postcondition() {
  if [[ $# -lt 2 ]]; then
    echo -e "${RED}[assert_postcondition] internal error: need <label> <check> [args...]${NC}" >&2
    exit 2
  fi
  local label="$1"; shift

  local stderr_file
  stderr_file="$(mktemp -t assert-postcondition-XXXXXX.err)" || {
    echo -e "${RED}[assert_postcondition] could not create tempfile${NC}" >&2
    exit 2
  }
  # Ensure cleanup even on signal.
  local _ap_trap_prev
  _ap_trap_prev="$(trap -p EXIT 2>/dev/null || true)"
  trap 'rm -f "${stderr_file:-}"' EXIT

  local rc=0
  if "$@" >/dev/null 2>"$stderr_file"; then
    rc=0
  else
    rc=$?
  fi

  if (( rc == 0 )); then
    echo -e "${GREEN}[verified]${NC} $label" >&2
    rm -f "$stderr_file"
    # Restore previous EXIT trap if any.
    if [[ -n "$_ap_trap_prev" ]]; then eval "$_ap_trap_prev"; else trap - EXIT; fi
    return 0
  fi

  # Failure path — render a readable diagnostic and exit 2.
  {
    echo ""
    echo -e "${RED}[postcondition FAILED]${NC} ${label}"
    echo -e "  ${YELLOW}check${NC}: $*"
    echo -e "  ${YELLOW}exit ${NC}: $rc"
    if [[ -s "$stderr_file" ]]; then
      echo -e "  ${YELLOW}stderr (last ${ASSERT_POSTCONDITION_STDERR_LINES} lines)${NC}:"
      tail -n "$ASSERT_POSTCONDITION_STDERR_LINES" "$stderr_file" | while IFS= read -r line; do
        echo "    $line"
      done
    else
      echo -e "  ${YELLOW}stderr${NC}: (empty)"
    fi
    echo ""
  } >&2

  rm -f "$stderr_file"
  if [[ -n "$_ap_trap_prev" ]]; then eval "$_ap_trap_prev"; else trap - EXIT; fi
  exit 2
}

# Convenience: same as assert_postcondition but returns instead of exiting.
# Useful in loops where the caller wants to aggregate multiple failures.
# Returns 0 on pass, 2 on fail.
check_postcondition() {
  # Run assert_postcondition in a subshell so its exit 2 doesn't kill the caller.
  ( assert_postcondition "$@" )
}
