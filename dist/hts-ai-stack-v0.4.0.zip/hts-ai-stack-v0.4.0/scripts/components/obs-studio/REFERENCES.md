# OBS Studio References

Last updated: 2026-04-17

## Upstream

- [OBS Studio](https://obsproject.com/)
- [OBS Studio Wiki](https://obsproject.com/wiki/)
- [GitHub — obsproject/obs-studio](https://github.com/obsproject/obs-studio)

## PPA

- Official PPA: `ppa:obsproject/obs-studio`

## Package

- Ubuntu package: `obs-studio`
