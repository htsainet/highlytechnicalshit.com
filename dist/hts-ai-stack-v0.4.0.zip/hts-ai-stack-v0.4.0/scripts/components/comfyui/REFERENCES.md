# ComfyUI References

Last updated: 2026-04-15

## Upstream

- [GitHub — comfyanonymous/ComfyUI](https://github.com/comfyanonymous/ComfyUI)

## Official documentation

- [ComfyUI README](https://github.com/comfyanonymous/ComfyUI#readme)
- [ComfyUI Examples](https://comfyanonymous.github.io/ComfyUI_examples/)
