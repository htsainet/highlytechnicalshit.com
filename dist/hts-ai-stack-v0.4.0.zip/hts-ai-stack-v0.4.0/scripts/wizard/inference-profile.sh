#!/usr/bin/env bash
# scripts/wizard/inference-profile.sh — Inference stack profile selection
#
# PURPOSE
#   Encapsulates all inference backend selection logic so it can be called
#   from multiple entry points without duplication:
#
#     install.sh       → first-time setup
#     configure.sh     → day-2 reconfiguration (standalone: change backend)
#     reconfigure.sh   → wizard re-run (sources this file)
#
# USAGE (sourced — do NOT run directly)
#
#   source "$REPO_DIR/scripts/wizard/inference-profile.sh"
#
#   select_inference_profile        # interactive: shows whiptail profile menu
#   check_inference_profile         # non-interactive: validates current config
#
# OUTPUTS (env vars exported after select_inference_profile)
#
#   INFERENCE_PROFILE     — selected profile id:
#                             "ollama"     Ollama only
#                             "dual"       Ollama + BitNet + llama-swap   ← default
#                             "dual-lms"   Dual + LM Studio peer
#                             "localai"    LocalAI only (requires 16GB+ VRAM)
#                             "custom"     Manual component selection
#   BACKEND               — internal backend identifier written to stack.json:
#                             "ollama" | "dual" | "localai" | "custom"
#   LMSTUDIO_INSTALL      — "true" if LM Studio should be installed
#   LMSTUDIO_ENABLED      — "true" if LM Studio should be peered into llama-swap
#   LMSTUDIO_URL          — URL of LM Studio server (default: http://localhost:1234)
#
# PROFILE → COMPONENT MAPPING
#
#   Profile       BACKEND   ollama  bitnet  llama-swap  localai  lmstudio-peer
#   ──────────────────────────────────────────────────────────────────────────
#   ollama        ollama      ✓       ✗         ✗          ✗         ✗
#   dual          dual        ✓       ✓         ✓          ✗         ✗
#   dual-lms      dual        ✓       ✓         ✓          ✗         ✓
#   localai       localai     ✗       ✗         ✗          ✓         ✗
#   custom        *           user-selected in manifest checklist
#
# VRAM GATING
#
#   Profiles are shown or annotated based on GPU_VRAM_TOTAL (MiB):
#
#   Profile     Minimum VRAM   Behaviour if below threshold
#   ──────────────────────────────────────────────────────────────────────────
#   ollama      0              Always available
#   dual        0              Always available (BitNet runs on CPU)
#   dual-lms    0              Always available; LM Studio runs on host
#   localai     16384 (16GB)   Hidden from menu / shows [requires 16GB+ VRAM]
#   custom      0              Always available
#
#   GPU_VRAM_TOTAL must be set before calling select_inference_profile.
#   The wizard (ai_stack_setup.sh) sets it at startup via nvidia-smi.
#
# LM STUDIO HANDLING (dual-lms profile)
#
#   1. If LM Studio is already installed (dpkg -s lmstudio): skip install,
#      auto-enable peer, prompt for URL confirmation.
#   2. If not installed: offer to install it (LMSTUDIO_INSTALL=true),
#      then auto-enable peer.
#   3. User is prompted for the LM Studio URL (default :1234).
#
# DEPENDENCIES
#   - common.sh (for step/info/ok/warn helpers)
#   - GPU_VRAM_TOTAL must be set in calling scope
#   - whiptail must be available
#
# STATUS: STUB — function signatures and documentation complete.
#         Implementation pending (see docs/development/features/).
#         Currently the equivalent logic lives inline in:
#           config/wizard/ai_stack_setup.sh  lines 278–393
#         That inline code will be replaced by calls to this file.
# ─────────────────────────────────────────────────────────────────────────────

# Guard: must be sourced, not executed
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  echo "[ERROR] inference-profile.sh must be sourced, not executed directly." >&2
  exit 1
fi

# ── Defaults ─────────────────────────────────────────────────────────────────
INFERENCE_PROFILE="${INFERENCE_PROFILE:-dual}"
BACKEND="${BACKEND:-dual}"
LMSTUDIO_INSTALL="${LMSTUDIO_INSTALL:-false}"
LMSTUDIO_ENABLED="${LMSTUDIO_ENABLED:-false}"
LMSTUDIO_URL="${LMSTUDIO_URL:-http://localhost:1234}"

# ── select_inference_profile ─────────────────────────────────────────────────
# Interactive: show whiptail profile menu and set all output env vars.
# Re-prompts if user selects an unavailable profile (e.g. localai on <16GB).
#
# Reads:  GPU_VRAM_TOTAL, GPU_AVAILABLE, HTSAI_DETECTED_OLLAMA,
#         HTSAI_DETECTED_BITNET (from detect file)
# Writes: INFERENCE_PROFILE, BACKEND, LMSTUDIO_INSTALL, LMSTUDIO_ENABLED,
#         LMSTUDIO_URL
select_inference_profile() {
  GPU_VRAM_TOTAL="${GPU_VRAM_TOTAL:-0}"
  INFERENCE_PROFILE="${INFERENCE_PROFILE:-dual}"

  case "${INFERENCE_PROFILE}" in
    ollama)
      BACKEND="ollama"
      ;;
    dual)
      BACKEND="dual"
      ;;
    dual-lms)
      BACKEND="dual"
      LMSTUDIO_INSTALL="true"
      LMSTUDIO_ENABLED="true"
      ;;
    localai)
      if (( GPU_VRAM_TOTAL < 16384 )); then
        echo "[WARN] localai requires >=16GB VRAM (detected ${GPU_VRAM_TOTAL} MiB). Falling back to 'dual'." >&2
        INFERENCE_PROFILE="dual"
        BACKEND="dual"
      else
        BACKEND="localai"
      fi
      ;;
    custom)
      BACKEND="custom"
      ;;
    *)
      BACKEND="dual"
      INFERENCE_PROFILE="dual"
      ;;
  esac

  export INFERENCE_PROFILE BACKEND LMSTUDIO_INSTALL LMSTUDIO_ENABLED LMSTUDIO_URL
  echo "[INFO] Selected profile=${INFERENCE_PROFILE}, BACKEND=${BACKEND}" >&2
}

# ── check_inference_profile ──────────────────────────────────────────────────
# Non-interactive: validate current stack.json inference config against hardware.
# Prints warnings if the config is not achievable on this machine.
# Returns 0 if valid, 1 if misconfigured.
#
# Reads:  stack.json (via STACK_JSON), GPU_VRAM_TOTAL
# Prints: warnings to stderr
check_inference_profile() {
  GPU_VRAM_TOTAL="${GPU_VRAM_TOTAL:-0}"

  # If STACK_JSON specified, try to read backend from it (best-effort)
  if [[ -n "${STACK_JSON:-}" && -f "${STACK_JSON}" ]]; then
    local cfg_backend
    cfg_backend=$(python3 - <<PY
import json,sys
try:
  j=json.load(open(sys.argv[1]))
  inf=j.get('inference',{})
  b=inf.get('backend') or inf.get('profile') or ''
  print(b)
except Exception:
  pass
PY
 "$STACK_JSON" 2>/dev/null)
    cfg_backend="${cfg_backend:-}"
    if [[ -n "$cfg_backend" ]]; then
      BACKEND="$cfg_backend"
    fi
  fi

  if [[ "$BACKEND" == "localai" && "${GPU_VRAM_TOTAL:-0}" -lt 16384 ]]; then
    echo "[ERROR] Config requests 'localai' but GPU VRAM < 16GB (${GPU_VRAM_TOTAL} MiB)" >&2
    return 1
  fi

  return 0
}

# ── _handle_lmstudio_peer ────────────────────────────────────────────────────
# Internal: handle LM Studio install + peer config for dual-lms profile.
_handle_lmstudio_peer() {
  # Detect whether LM Studio is installed and set flags accordingly (best-effort)
  if command -v lmstudio >/dev/null 2>&1 || (command -v dpkg >/dev/null 2>&1 && dpkg -s lmstudio >/dev/null 2>&1 2>/dev/null); then
    LMSTUDIO_ENABLED="true"
    LMSTUDIO_INSTALL="false"
  else
    LMSTUDIO_INSTALL="${LMSTUDIO_INSTALL:-false}"
  fi
  export LMSTUDIO_INSTALL LMSTUDIO_ENABLED
}

# ── _ask_lmstudio_optional ───────────────────────────────────────────────────
# Internal: offer LM Studio as optional peer for plain dual profile.
_ask_lmstudio_optional() {
  # Offer LM Studio as optional peer in interactive mode
  if command -v whiptail >/dev/null 2>&1 && [ -t 1 ]; then
    if whiptail --yesno "Install and peer LM Studio for LM-backed workflows?" 8 60; then
      LMSTUDIO_INSTALL="true"
    fi
  fi
  export LMSTUDIO_INSTALL
}
