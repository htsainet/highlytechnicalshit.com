#!/usr/bin/env bash
# issue-034-pre-reboot.sh — Pre-reboot baseline for ISSUE-034
#
# Purpose
#   Establishes a known-good baseline before rebooting, so that
#   `diag-issue-034-boot.sh` (run AFTER reboot) actually tests the
#   boot-resilience hypothesis rather than some unrelated breakage.
#
#   This script is read-only by default. It refuses to mutate state;
#   if the sandbox is missing, it tells you exactly which vendor
#   `nemoclaw onboard` command to run and exits non-zero.
#
# How to use
#   1. Run: ./scripts/components/nemoclaw/issue-034-pre-reboot.sh
#   2. Read the verdict — green means safe to reboot.
#   3. After reboot, run: ./scripts/components/nemoclaw/diag-issue-034-boot.sh
#
# Side effects: NONE. Read-only diagnostic.
#
# References
#   - docs/development/issues/ISSUE-034.md
#   - docs/planning/ACTIVE.md (rules of engagement)

set -euo pipefail

# ── pretty printers ──────────────────────────────────────────────────────────
bold()   { printf '\033[1m%s\033[0m\n' "$*"; }
green()  { printf '\033[32m%s\033[0m\n' "$*"; }
yellow() { printf '\033[33m%s\033[0m\n' "$*"; }
red()    { printf '\033[31m%s\033[0m\n' "$*"; }
hr()     { printf '── %s %s\n' "$*" "$(printf '─%.0s' $(seq 1 $((70 - ${#1} - 4))))"; }

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"

# ── 1. Resolve sandbox + gateway names from .env (fall back to manifest defaults)
GATEWAY_NAME="${NEMOCLAW_GATEWAY_NAME:-nemoclaw}"
SANDBOX_NAME="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"
if [[ -f "$REPO_ROOT/.env" ]]; then
  # shellcheck disable=SC1091
  set +u
  source "$REPO_ROOT/.env" 2>/dev/null || true
  set -u
fi
GATEWAY_NAME="${NEMOCLAW_GATEWAY_NAME:-nemoclaw}"
SANDBOX_NAME="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"

UNIT="hts-nemoclaw-dashboard-forward.service"
PORT=18789

hr "Context"
printf '  gateway:  %s\n' "$GATEWAY_NAME"
printf '  sandbox:  %s\n' "$SANDBOX_NAME"
printf '  unit:     %s\n' "$UNIT"
printf '  port:     %s\n' "$PORT"

# ── 2. Vendor CLI present? ───────────────────────────────────────────────────
hr "Vendor CLIs"
missing=0
for bin in nemoclaw openshell; do
  if command -v "$bin" >/dev/null 2>&1; then
    printf '  %-10s %s\n' "$bin" "$(command -v "$bin")"
  else
    red "  $bin: NOT FOUND"
    missing=1
  fi
done
if (( missing )); then
  red "🔴 Required vendor CLIs missing. Install via NVIDIA NemoClaw quickstart."
  exit 10
fi

# ── 3. Sandbox state ─────────────────────────────────────────────────────────
hr "Sandbox state"
sandbox_present=0
if openshell sandbox get "$SANDBOX_NAME" -g "$GATEWAY_NAME" >/dev/null 2>&1; then
  sandbox_present=1
  green "  ✅ sandbox '$SANDBOX_NAME' exists on gateway '$GATEWAY_NAME'"
  if nemoclaw "$SANDBOX_NAME" status 2>/dev/null | sed 's/^/    /'; then
    :
  else
    yellow "    (nemoclaw status returned non-zero — sandbox exists but may not be Ready)"
  fi
else
  red "  ❌ sandbox '$SANDBOX_NAME' NOT FOUND on gateway '$GATEWAY_NAME'"
fi

if (( sandbox_present == 0 )); then
  echo
  red "🔴 Sandbox absent — reboot test would be inconclusive."
  bold "Vendor recovery (run manually, then re-run this script):"
  echo "    ./scripts/components/nemoclaw/nemoclaw.sh --onboard-fresh"
  echo
  bold "(That wrapper invokes 'nemoclaw onboard --non-interactive --fresh'"
  bold " with the full env set — sandbox name, gateway, provider, endpoint,"
  bold " model, policy presets — wired from .env + the manifest pin.)"
  echo
  bold "Do NOT run 'nemoclaw rebuild' or 'openshell sandbox create' directly."
  bold "See docs/planning/ACTIVE.md → ISSUE-034 rules of engagement."
  exit 20
fi

# ── 4. Manual start brings :18789 up? ────────────────────────────────────────
hr "Manual --start baseline"
echo "  Running: ./scripts/components/nemoclaw/nemoclaw.sh --start"
echo "  (this is the documented recovery path; ensures baseline works"
echo "   before we trust the boot-unit to do the same thing)"
echo
if ! "$REPO_ROOT/scripts/components/nemoclaw/nemoclaw.sh" --start; then
  red "🔴 Manual --start failed. Boot test would also fail."
  bold "Investigate with: nemoclaw $SANDBOX_NAME logs --follow"
  bold "Do NOT run nemoclaw rebuild — see ACTIVE.md rules of engagement."
  exit 30
fi

# ── 5. Listener check ───────────────────────────────────────────────────────
hr "Port :$PORT after manual start"
sleep 2
if ss -tlnp 2>/dev/null | awk -v p=":$PORT" '$4 ~ p {found=1} END {exit !found}'; then
  green "  ✅ :$PORT is listening"
else
  red "  ❌ :$PORT is NOT listening despite --start succeeding."
  bold "  This is a different bug than ISSUE-034. Stop and investigate."
  exit 40
fi

# ── 6. Boot unit installed? ─────────────────────────────────────────────────
hr "Boot unit"
if systemctl list-unit-files "$UNIT" 2>/dev/null | grep -q "$UNIT"; then
  state="$(systemctl is-enabled "$UNIT" 2>/dev/null || echo unknown)"
  green "  ✅ $UNIT is installed (is-enabled: $state)"
else
  yellow "  ⚠ $UNIT is NOT installed."
  bold "  --start should have installed it. Re-run with NEMOCLAW_DEBUG=1 if missing."
  exit 50
fi

# ── Verdict ──────────────────────────────────────────────────────────────────
echo
hr "Verdict"
green "🟢 BASELINE OK — sandbox present, manual --start works, :$PORT up, boot unit installed."
echo
bold "You may now reboot."
echo
bold "After reboot (login + wait ~2 min for systemd to settle), run:"
echo "    ./scripts/components/nemoclaw/diag-issue-034-boot.sh"
echo
bold "Then bring the diag output back to this session for triage."
echo
exit 0
