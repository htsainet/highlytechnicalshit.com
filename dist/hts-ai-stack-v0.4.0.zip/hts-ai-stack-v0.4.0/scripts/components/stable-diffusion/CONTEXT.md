# Stable Diffusion Component

Last updated: 2026-04-17

## What happens here

Stable Diffusion WebUI (AUTOMATIC1111) provides a browser-based interface
for AI image generation. Used in the stack as an alternative to ComfyUI
with GPU acceleration via CUDA.

## Files and structure

| File | Purpose |
|------|---------|
| `stable-diffusion.sh` | Full lifecycle: install, configure, start, stop, health, download |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Upstream repo redirect

`Stability-AI/stablediffusion` was deleted from GitHub in late 2025
(A1111 issues #17204, #17235, #17309). `launch.py` honours the
`STABLE_DIFFUSION_REPO` env var as an override. We set it in **two**
places, both pointing at the maintained `w-e-w/stablediffusion` mirror
(preserves the pinned commit SHAs A1111 expects):

1. `docker/stable-diffusion/Dockerfile` (`ENV STABLE_DIFFUSION_REPO=...`)
   — so the build-time `prepare_environment()` clones the mirror.
2. `docker-compose.yml` `stable-diffusion.environment` — belt-and-
   suspenders for standalone `docker run` use of the image.

The other three repos (`generative-models`, `k-diffusion`, `BLIP`)
still resolve at their default URLs and are cloned **at build time**
by `prepare_environment()`. At runtime the Dockerfile's CMD passes
`--skip-prepare-environment` so launch.py never touches git on the
hot path. Compose **must not** override the CMD or it strips that
flag and runtime re-does the clone.

## Attention backend

Uses `--opt-sdp-attention` (PyTorch native SDP) instead of xformers.
xFormers PyPI wheels target CUDA 12.4 but the container runs CUDA 12.6,
causing a symbol mismatch at runtime. SDP attention is built into PyTorch
and works with any CUDA version.

## COMMANDLINE_ARGS gotcha

AUTOMATIC1111's `launch.py` **appends** the `COMMANDLINE_ARGS` environment
variable to `sys.argv`. This means if you set flags via both `environment:`
and `command:` in docker-compose, BOTH sets of flags are active. Always use
`command:` in compose to fully override the Dockerfile CMD — don't rely on
the env var alone.

See [usage.md](./usage.md) for command usage.
