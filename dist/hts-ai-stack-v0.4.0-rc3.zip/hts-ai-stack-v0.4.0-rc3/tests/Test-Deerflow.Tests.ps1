$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/deerflow'
    $script:ComponentScript = Join-Path $script:ComponentDir 'deerflow.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'deerflow.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'deerflow file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'deerflow manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is deerflow' {
        $script:Manifest.id | Should -Be 'deerflow'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/deerflow/deerflow.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is deerflow' {
        $script:Manifest.func_prefix | Should -Be 'deerflow'
    }

    It 'dashboard port is 3002' {
        [int]$script:Manifest.dashboard.port | Should -Be 3002
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'deerflow component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines deerflow_install function' {
        $script:ComponentContent | Should -Match 'deerflow_install\s*\(\)'
    }

    It 'defines deerflow_configure function' {
        $script:ComponentContent | Should -Match 'deerflow_configure\s*\(\)'
    }

    It 'defines deerflow_start function' {
        $script:ComponentContent | Should -Match 'deerflow_start\s*\(\)'
    }

    It 'defines deerflow_stop function' {
        $script:ComponentContent | Should -Match 'deerflow_stop\s*\(\)'
    }

    It 'defines deerflow_health function' {
        $script:ComponentContent | Should -Match 'deerflow_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/deerflow/deerflow\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'deerflow port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 3002 is registered in portmap.json' {
        $script:Portmap.ports.'3002' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'3002'.service | Should -Be 'deerflow'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'deerflow no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/deerflow\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/deerflow/deerflow\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
