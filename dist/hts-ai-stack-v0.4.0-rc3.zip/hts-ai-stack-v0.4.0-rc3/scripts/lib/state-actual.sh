#!/usr/bin/env bash
# scripts/lib/state-actual.sh — Probe runtime state of components
# Source this file; do NOT run directly.
#
# Determines the actual running state of each component by probing
# Docker containers, systemd services, and health endpoints.
#
# Used by: converge.sh (FEATURE-009)
# Requires: common.sh, component-registry.sh sourced first

# ── Actual state array ────────────────────────────────────────────────────────
# Populated by actual_state_load()
# Keys: component IDs from COMPONENT_ORDER
# Values: "running" | "stopped" | "missing" | "degraded"
declare -gA ACTUAL

# ── Container name mapping ────────────────────────────────────────────────────
# Maps component ID to Docker compose service name.
# After service rename (ollama-gpu→ollama, bitnet-cpu→bitnet) all component IDs
# match service names. Actual container name is resolved at probe time via label
# lookup so it is resilient to COMPOSE_PROJECT_NAME changes.
declare -gA COMPONENT_CONTAINER=(
  [flowise]="flowise"
  [dashboard]="dashboard"
  [ollama]="ollama"
  [bitnet]="bitnet"
  [llama-swap]="llama-swap"
  [open-webui]="open-webui"
  [prometheus]="prometheus"
  [grafana]="grafana"
  [portainer]="portainer"
  [openspace]="openspace"
  [deerflow]="deerflow"
  [gvisor-sandbox]="gvisor-sandbox"
  [duplicati]="duplicati"
  [sillytavern]="sillytavern"
  [comfyui]="comfyui"
  [unsloth]="unsloth"
  [telegram]="telegram"
  [signal]="signal"
  [n8n]="n8n"
  [pipelines]="pipelines"
  [searxng]="searxng"
  [langflow]="langflow"
)


# COMPONENT_HEALTH_URL and COMPONENT_HEALTH_TIMEOUT are now defined in
# each component's .manifest.json and loaded by manifest-loader.sh via
# component-registry.sh. They are available as global associative arrays
# before this file is sourced — no local declaration needed here.

# ── Actual state loader ───────────────────────────────────────────────────────

# actual_state_load
# Probes each component and populates the ACTUAL array.
actual_state_load() {
  local component
  for component in "${COMPONENT_ORDER[@]}"; do
    ACTUAL[$component]=$(_probe_component "$component")
  done
}

# _probe_component <component_id>
# Returns the runtime state of a single component.
_probe_component() {
  local component="$1"
  
  case "$component" in
    # Special cases: non-Docker components
    htsclaw)
      _probe_htsclaw
      ;;
    nemoclaw)
      _probe_nemoclaw
      ;;
    tailscale)
      _probe_tailscale
      ;;
    lmstudio)
      _probe_lmstudio
      ;;
    # Docker-based components
    *)
      _probe_docker_component "$component"
      ;;
  esac
}

# _probe_docker_component <component_id>
# Probes a Docker container-based component.
# Uses Docker's built-in healthcheck status as primary signal — avoids
# false positives from probing SSE endpoints or wrong URLs directly.
_probe_docker_component() {
  local component="$1"
  local service="${COMPONENT_CONTAINER[$component]:-$component}"
  local health_url="${COMPONENT_HEALTH_URL[$component]:-}"

  # Resolve actual container name via compose service label
  local container
  container=$(docker ps -a \
    --filter "label=com.docker.compose.service=${service}" \
    --filter "label=com.docker.compose.project=hts-ai" \
    --format "{{.Names}}" 2>/dev/null | head -1)

  # No container found — assume missing
  if [[ -z "$container" ]]; then
    echo "missing"
    return
  fi

  # Check if container exists and is running
  local state
  state=$(docker inspect --format='{{.State.Status}}' "$container" 2>/dev/null || echo "missing")

  case "$state" in
    running)
      # Prefer Docker's own healthcheck status (avoids URL probe false positives)
      local health
      health=$(docker inspect --format='{{.State.Health.Status}}' "$container" 2>/dev/null || echo "")
      case "$health" in
        healthy)   echo "running" ;;
        unhealthy) echo "degraded" ;;
        *)
          # No Docker healthcheck defined — fall back to URL probe
          if [[ -n "$health_url" ]]; then
            if _http_probe "$health_url"; then
              echo "running"
            else
              echo "degraded"
            fi
          else
            echo "running"
          fi
          ;;
      esac
      ;;
    exited|created|paused|dead)
      echo "stopped"
      ;;
    *)
      echo "missing"
      ;;
  esac
}

# _http_probe <url> [timeout]
# Returns 0 if URL returns HTTP 2xx, 1 otherwise.
_http_probe() {
  local url="$1"
  local timeout="${2:-3}"
  curl -sf --max-time "$timeout" "$url" >/dev/null 2>&1
}

# ── Non-Docker component probes ───────────────────────────────────────────────

# _probe_htsclaw
# htsclaw uses OpenShell sandboxes, not Docker containers.
_probe_htsclaw() {
  # Check if openshell CLI is available
  if command -v openshell &>/dev/null; then
    local sandbox_name="${HTSCLAW_SANDBOX_NAME:-hts-ai-openshell-htsclaw-gpu}"
    if openshell sandbox get "$sandbox_name" &>/dev/null 2>&1; then
      local port="${HTSCLAW_PORT:-18790}"
      if _http_probe "http://localhost:${port}/healthz"; then
        echo "running"
      else
        echo "degraded"
      fi
      return
    fi
  fi

  # Fallback: check for Docker container directly (openshell CLI may not be installed)
  if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "openshell-cluster-htsclaw"; then
    local port="${HTSCLAW_PORT:-18790}"
    if _http_probe "http://localhost:${port}/healthz"; then
      echo "running"
    else
      echo "degraded"
    fi
  elif docker ps -a --format '{{.Names}}' 2>/dev/null | grep -q "openshell-cluster-htsclaw"; then
    echo "stopped"
  else
    echo "missing"
  fi
}

# _probe_nemoclaw
# NemoClaw uses OpenShell sandboxes via the nemoclaw CLI.
_probe_nemoclaw() {
  # Check if nemoclaw CLI is available
  if command -v nemoclaw &>/dev/null; then
    local sandbox_list
    sandbox_list=$(nemoclaw sandbox ls --json 2>/dev/null || echo "[]")

    if echo "$sandbox_list" | jq -e 'length > 0' >/dev/null 2>&1; then
      local port="${NEMOCLAW_PORT:-18789}"
      if _http_probe "http://localhost:${port}/healthz"; then
        echo "running"
      else
        if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "openshell-cluster-nemoclaw"; then
          echo "degraded"
        else
          echo "stopped"
        fi
      fi
      return
    fi
  fi

  # Fallback: check for Docker container directly (nemoclaw CLI may not be installed)
  if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "openshell-cluster-nemoclaw"; then
    local port="${NEMOCLAW_PORT:-18789}"
    if _http_probe "http://localhost:${port}/healthz"; then
      echo "running"
    else
      echo "degraded"
    fi
  elif docker ps -a --format '{{.Names}}' 2>/dev/null | grep -q "openshell-cluster-nemoclaw"; then
    echo "stopped"
  else
    echo "missing"
  fi
}

# _probe_tailscale
# Tailscale is a host service, not a Docker container.
_probe_tailscale() {
  # Check if tailscale CLI is available
  if ! command -v tailscale &>/dev/null; then
    echo "missing"
    return
  fi
  
  # Check connection status
  local status
  status=$(tailscale status 2>&1 || echo "")
  
  if echo "$status" | grep -qE "^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"; then
    echo "running"
  elif systemctl is-active --quiet tailscaled 2>/dev/null; then
    echo "stopped"
  else
    echo "missing"
  fi
}

# _probe_lmstudio
# LM Studio is a host application (AppImage or .deb).
_probe_lmstudio() {
  # Check if lmstudio is installed
  if command -v lmstudio &>/dev/null || dpkg -s lmstudio &>/dev/null 2>&1; then
    # Check if the LM Studio server is responding
    local port="${LMSTUDIO_PORT:-1234}"
    if _http_probe "http://localhost:${port}/v1/models"; then
      echo "running"
    else
      echo "stopped"
    fi
  else
    echo "missing"
  fi
}

# ── Debug output ──────────────────────────────────────────────────────────────

# actual_state_dump
# Prints the current ACTUAL state for debugging.
actual_state_dump() {
  local component
  echo "Actual state:"
  for component in "${COMPONENT_ORDER[@]}"; do
    printf "  %-20s %s\n" "$component" "${ACTUAL[$component]:-unknown}"
  done
}

# actual_state_running_list
# Prints components that are currently running.
actual_state_running_list() {
  local component
  for component in "${COMPONENT_ORDER[@]}"; do
    if [[ "${ACTUAL[$component]:-}" == "running" ]]; then
      echo "$component"
    fi
  done
}

# actual_state_stopped_list
# Prints components that are stopped or missing.
actual_state_stopped_list() {
  local component
  for component in "${COMPONENT_ORDER[@]}"; do
    local state="${ACTUAL[$component]:-missing}"
    if [[ "$state" == "stopped" || "$state" == "missing" ]]; then
      echo "$component"
    fi
  done
}
