# Installer Wizard — REFERENCES

## Related features

- FEATURE-064 — Starter Model Pull + Day-2 Upgrade Command
  (`scripts/wizard/model-select.sh` is the canonical implementation)
- FEATURE-067 — Aider Coding-Tier Preset (adds `pull_coding_tier` +
  `_ollama_exec` / `_ollama_has_model` helpers to `model-select.sh`)
- FEATURE-054 — Developer Tools Suite (consumes `pull_coding_tier` via
  `scripts/components/aider/aider.sh`)

## Entry points that source these files

- `install.sh` — first-time install flow
- `configure.sh` — day-2 standalone reconfiguration (backend change,
  model switch)
- `reconfigure.sh` — wizard re-run
- `scripts/components/ollama/ollama.sh` — standalone model pull/switch
- `scripts/components/aider/aider.sh` — docstring refers users to
  `source scripts/wizard/model-select.sh && pull_coding_tier`

## Downstream outputs

- `stack.json` — `inference-profile.sh` writes the selected profile and
  LM Studio peer toggle; `model-select.sh` writes `MODEL` /
  `PULL_ALL_MODELS`.
- `.env` — `LMSTUDIO_URL`, `LMSTUDIO_ENABLED`, `INFERENCE_BITNET_MODEL`.
- `ollama_data` Docker volume — populated by `_ollama_exec pull …`
  inside the `hts-ai-ollama` container.

## Related components in this stack

- Ollama — model backend (`scripts/components/ollama/`); every pull
  lands in its `ollama_data` volume.
- llama-swap — router in front of Ollama
  (`scripts/components/llama-swap/`); model tags must also be
  registered in `config/llama-swap.yaml` to be routable over the
  OpenAI-compatible endpoint.
- BitNet — optional 1-bit LLM peer (only when `BACKEND=dual`).
- LocalAI — alternative backend (`BACKEND=localai`).

## Upstream references

- Ollama CLI reference: <https://github.com/ollama/ollama/blob/main/docs/README.md>
- `ollama list` / `ollama pull`: <https://github.com/ollama/ollama#quickstart>
- whiptail (newt) docs: <https://en.wikibooks.org/wiki/Bash_Shell_Scripting/Whiptail>
- `docker exec` reference: <https://docs.docker.com/reference/cli/docker/container/exec/>

## Vendor-instruction deviations

None. All Ollama commands issued by these wizard scripts use the
documented Ollama CLI. No entry in `/DEVIATIONS.md` is required.
