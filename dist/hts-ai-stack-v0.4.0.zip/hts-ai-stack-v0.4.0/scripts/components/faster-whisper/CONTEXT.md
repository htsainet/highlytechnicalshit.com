# Faster-Whisper Component

Last updated: 2026-04-15

## What happens here

Faster-Whisper provides GPU-accelerated speech-to-text transcription using
CTranslate2-optimized Whisper models. Wrapped by speaches to expose an
OpenAI-compatible `/v1/audio/transcriptions` API endpoint.

## Files and structure

| File | Purpose |
|------|---------|
| `faster-whisper.sh` | Full lifecycle: install, configure, start, stop, health |
| `faster-whisper.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- OpenAI-compatible API — drop-in replacement for `whisper-1` endpoint
- GPU primary (CUDA 12), CPU int8 fallback available
- Supports large-v3, medium, small, base, tiny models
- 4x faster than original Whisper with lower memory usage

See [usage.md](./usage.md) for command usage.
