# FEATURE-041 — Component Manifests (Single Source of Truth)

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | HIGH |
| **Effort** | 2 days |
| **Risk** | Low — manifests replace hardcoded data; all arrays verified identical |
| **Target Release** | v0.7.0 |
| **Depends on** | FEATURE-009 (Config-Driven Convergence) |
| **Blocks** | FEATURE-040 (Interactive Reconfigure) |

## Problem

Component metadata was scattered across six parallel arrays in
`component-registry.sh`, health URLs and timeouts in `state-actual.sh`,
and hardcoded prompts in individual install scripts. Adding a component
required editing five files. `reconfigure.sh` would have required a sixth.

## Solution

Each component gets a single `scripts/components/<id>.manifest.json` that
declares everything — identity, config semantics, health probing, and user
prompts. A generic loader and menu handler read these at runtime.

### Manifest Schema

```json
{
  "id": "comfyui",
  "display_name": "ComfyUI (GPU Image Generation)",
  "order": 180,
  "category": "images",
  "requires_gpu": true,
  "script": "scripts/components/comfyui/comfyui.sh",
  "func_prefix": "comfyui",
  "profile": "comfyui",
  "config": {
    "type": "enum",
    "read_path": ".images.engine",
    "match_values": ["comfyui"],
    "toggleable": true,
    "write_rules": [
      { "path": ".images.enabled", "on_enable": true, "on_disable": false },
      { "path": ".images.engine",  "on_enable": "comfyui", "on_disable": "" }
    ]
  },
  "health": {
    "url": "http://localhost:8188/",
    "timeout": 660
  },
  "prompts": [
    {
      "key": "gpu_layers",
      "type": "input",
      "label": "GPU layers (leave empty for auto)",
      "default": "",
      "write_target": "stack.json",
      "write_path": ".images.gpu_layers"
    }
  ]
}
```

### Config Types

| type | Derivation | Example config\_key |
|------|-----------|-------------------|
| `always` | literal | `always` |
| `boolean` | `.read_path` stripped | `dashboard.enabled` |
| `enum` | `.read_path:match_values` | `backend:ollama,dual` |
| `array_member` | `.read_path:member_value` | `extras.components:duplicati` |

Config keys are backward-compatible with `state-desired.sh` — no changes
required there.

### Prompt Types

| type | Dialog | Writes to |
|------|--------|-----------|
| `input` | `--inputbox` | stack.json or .env |
| `secret` | `--passwordbox` | .env only |
| `yesno` | `--yesno` | stack.json |
| `checklist` | `--checklist` | stack.json |
| `radiolist` | `--radiolist` | stack.json |
| `custom` | calls named function | — |

### All 21 Components

| Component | config.type | toggleable | Prompts |
|-----------|------------|-----------|---------|
| dashboard | boolean | yes | — |
| ollama | enum | no | — |
| bitnet | enum | no | — |
| llama-swap | enum | no | — |
| open-webui | always | no | — |
| htsclaw | enum | no | — |
| nemoclaw | enum | no | — |
| prometheus | boolean | yes (group: monitoring) | — |
| grafana | boolean | no (group: monitoring) | — |
| portainer | boolean | yes | — |
| openspace | boolean | yes | — |
| deerflow | boolean | yes | — |
| gvisor-sandbox | boolean | yes | — |
| duplicati | array\_member | yes | — |
| tailscale | array\_member | yes | secret: auth\_key |
| lmstudio | boolean | yes | — |
| sillytavern | array\_member | yes | — |
| comfyui | enum | yes | input: gpu\_layers, port |
| unsloth | boolean | yes | — |
| telegram | boolean | yes | secret: bot\_token |
| signal | boolean | yes | input: phone + custom |

## Architecture

```text
*.manifest.json
    │
    ▼
manifest-loader.sh          ← populates COMPONENT_* arrays + health maps
    │
    ├── component-registry.sh   ← thin shim (backward compat)
    │       └── converge.sh
    │
    └── menu-handler.sh         ← generic whiptail handler
            └── reconfigure.sh
```

## Files

| File | Purpose |
|------|---------|
| `scripts/components/*.manifest.json` | 21 per-component declarations |
| `scripts/lib/manifest-loader.sh` | Loads all manifests into bash arrays |
| `scripts/lib/menu-handler.sh` | Generic whiptail menu handler |
| `scripts/lib/component-registry.sh` | Thin shim — sources manifest-loader |
| `scripts/lib/state-actual.sh` | Health URL/timeout maps removed (now in manifests) |

## Adding a New Component

1. Create `scripts/components/<id>.manifest.json`
2. Create `scripts/components/<id>.sh` lifecycle script
3. Add Docker Compose service to `docker-compose.yml`

No other files need editing.

## Verification

After loading, all derived arrays were diffed against the legacy hardcoded
arrays. Zero mismatches across all 21 components for:

- `COMPONENT_CONFIG_KEY` — all 21 config keys
- `COMPONENT_ORDER` — execution order
- `COMPONENT_FUNC_PREFIX` — lifecycle function names
- `COMPONENT_HEALTH_URL` — health probe URLs
- `COMPONENT_HEALTH_TIMEOUT` — per-component timeouts
