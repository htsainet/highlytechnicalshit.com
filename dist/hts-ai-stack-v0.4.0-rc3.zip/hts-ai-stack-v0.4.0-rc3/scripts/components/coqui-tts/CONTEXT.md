# Coqui TTS Component

Last updated: 2026-04-15

## What happens here

Coqui TTS provides high-quality text-to-speech synthesis with XTTS v2,
supporting multilingual output and zero-shot voice cloning from short
audio samples. GPU-accelerated via CUDA with CPU fallback.

## Files and structure

| File | Purpose |
|------|---------|
| `coqui-tts.sh` | Full lifecycle: install, configure, start, stop, health |
| `coqui-tts.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Entrypoint override

The official `ghcr.io/coqui-ai/tts` image sets its entrypoint to the
`tts` CLI (command-line synthesis), not the HTTP server. The compose
file overrides the entrypoint to run the TTS server:

```yaml
entrypoint: ["python3", "-m", "TTS.server.server"]
command: ["--model_name", "tts_models/en/ljspeech/tacotron2-DDC"]
```

The tacotron2-DDC model is used as the default for fast startup.
XTTS v2 can be selected by changing the model name but requires
more VRAM.

## Notes

- REST API on port 5002 (OpenAI-compatible TTS endpoint planned)
- Supports voice cloning from ~6 seconds of reference audio
- XTTS v2 supports 17 languages
- GPU recommended but CPU fallback works (slower)
