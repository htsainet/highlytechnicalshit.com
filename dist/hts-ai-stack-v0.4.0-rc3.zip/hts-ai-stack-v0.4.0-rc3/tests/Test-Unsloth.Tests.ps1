$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/unsloth'
    $script:ComponentScript = Join-Path $script:ComponentDir 'unsloth.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'unsloth.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'unsloth file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'unsloth manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is unsloth' {
        $script:Manifest.id | Should -Be 'unsloth'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/unsloth/unsloth.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is unsloth' {
        $script:Manifest.func_prefix | Should -Be 'unsloth'
    }

    It 'dashboard port is 8888' {
        [int]$script:Manifest.dashboard.port | Should -Be 8888
    }

    It 'category is training' {
        $script:Manifest.category | Should -Be 'training'
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'unsloth component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines unsloth_install function' {
        $script:ComponentContent | Should -Match 'unsloth_install\s*\(\)'
    }

    It 'defines unsloth_configure function' {
        $script:ComponentContent | Should -Match 'unsloth_configure\s*\(\)'
    }

    It 'defines unsloth_start function' {
        $script:ComponentContent | Should -Match 'unsloth_start\s*\(\)'
    }

    It 'defines unsloth_stop function' {
        $script:ComponentContent | Should -Match 'unsloth_stop\s*\(\)'
    }

    It 'defines unsloth_health function' {
        $script:ComponentContent | Should -Match 'unsloth_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/unsloth/unsloth\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'unsloth port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8888 is registered in portmap.json for unsloth' {
        $entries = $script:Portmap.ports.PSObject.Properties |
            Where-Object { $_.Value.service -eq 'unsloth' }
        $matchedPorts = $entries | ForEach-Object { [int]$_.Name }
        $matchedPorts | Should -Contain 8888
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'unsloth no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/unsloth\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/unsloth/unsloth\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
