# n8n — Workflow Automation Service

**Priority:** MEDIUM
**Effort:** 4–6 hours
**Risk:** Low — standard Docker service with well-documented deployment.
**Target Release:** v0.6.0
**Depends on:** Nothing
**Blocks:** Nothing

## Problem

The stack lacks a workflow automation layer for orchestrating tasks across
services. Manual steps are required for common flows like model updates,
backup triggers, health check escalations, and notification routing.

## Solution

Deploy **n8n** as a self-hosted workflow automation service in the root
Docker Compose. n8n provides a visual workflow editor with 400+ integrations,
webhook triggers, and a JavaScript/Python code node for custom logic.

### Why n8n

- Self-hosted, open source (fair-code license)
- Visual workflow builder — low barrier for new automations
- Native Docker deployment with persistent SQLite/Postgres storage
- Webhook and cron triggers for event-driven and scheduled workflows
- REST API and code nodes for integration with llama-swap, Ollama, etc.

## Implementation Steps

### Phase 1 — Docker Service

Add n8n to `docker-compose.yml`:

- Image: `docker.n8n.io/n8nio/n8n:latest`
- Port: 5678 (per Host Port Map in REFERENCES.md)
- Volume: `n8n_data` for workflow persistence
- Network: `ai-network`
- Environment: timezone, webhook URL, basic auth

### Phase 2 — Component Script

New file: `scripts/components/n8n/n8n.sh`

- Pre-flight: check port 5678 availability
- Deploy service via Docker Compose
- Wait for health check
- Print access URL

### Phase 3 — Dashboard Integration

Add n8n card to `resources/dashboard/index.html` with link to port 5678.

### Phase 4 — Starter Workflows (stretch)

Create example workflow templates:

- Health check → notification (webhook to Discord/Slack)
- Scheduled model cache cleanup
- Backup trigger on volume threshold

## Port Allocation

| Host Port | Service | Notes |
|-----------|---------|-------|
| 5678 | n8n | Already reserved in REFERENCES.md Host Port Map |

## Acceptance Criteria

- [ ] n8n service starts and is accessible on port 5678
- [ ] Workflows persist across container restarts
- [ ] Dashboard links to n8n instance
- [ ] Component script handles install and health check
