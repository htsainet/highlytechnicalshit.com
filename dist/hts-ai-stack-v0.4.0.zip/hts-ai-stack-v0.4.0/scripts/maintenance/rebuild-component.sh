#!/usr/bin/env bash
# scripts/maintenance/rebuild-component.sh — Force a clean --no-cache rebuild
# of a single compose-based component when its image has drifted from the
# current Dockerfile (e.g. the Stable Diffusion `git --refetch` regression
# on 2026-04-23, or Open-LLM-VTuber's `main.py` → `run_server.py` rename).
#
# This is the manual counterpart to the structural fix tracked in
# `docs/planning/image-freshness-invariant-plan.md`. Once that lands,
# converge.sh will auto-rebuild on Dockerfile-hash drift and this script
# becomes a rarely-used manual override.
#
# Usage:
#   ./scripts/maintenance/rebuild-component.sh <component-id> [--wipe-volumes]
#
# Safe to run repeatedly. Only touches the named component.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/compose.sh"

ID=""
WIPE=false
for arg in "$@"; do
  case "$arg" in
    --wipe-volumes) WIPE=true ;;
    -*) warn "Unknown flag: $arg (ignored)" ;;
    *)  [[ -z "$ID" ]] && ID="$arg" || { fail "Too many args: $arg"; exit 2; } ;;
  esac
done

if [[ -z "$ID" ]]; then
  printf 'Usage: %s <component-id> [--wipe-volumes]\n' "$0" >&2
  exit 2
fi

manifest="$REPO_DIR/scripts/components/$ID/$ID.manifest.json"
[[ -f "$manifest" ]] || { fail "No manifest at $manifest"; exit 1; }

profile=$(jq -r '.profile // empty' "$manifest")
image=$(jq -r '.upstream.image // empty' "$manifest")
[[ -z "$profile" ]] && { fail "Manifest $manifest has no .profile (non-compose component?)"; exit 1; }
[[ -z "$image" ]] && image="hts-ai-${ID}"

step "$ID — stop container"
compose_down --profile "$profile" || true

if [[ "$WIPE" == "true" ]]; then
  step "$ID — wiping named volumes declared for this service"
  # Pull all volume names from the resolved compose config for this service.
  vols=$(docker compose config --format json 2>/dev/null \
    | jq -r --arg svc "$ID" '.services[$svc].volumes // [] | .[] | select(.type=="volume") | .source' \
    | sort -u)
  if [[ -n "$vols" ]]; then
    while IFS= read -r v; do
      [[ -z "$v" ]] && continue
      # Compose prefixes named volumes with the project name (hts-ai-stack_).
      full="hts-ai-stack_${v}"
      if docker volume inspect "$full" >/dev/null 2>&1; then
        docker volume rm "$full" && ok "Removed volume $full"
      fi
    done <<< "$vols"
  else
    info "No named volumes to wipe."
  fi
else
  info "Keeping named volumes (use --wipe-volumes to reset)."
fi

step "$ID — remove stale image"
if docker image inspect "$image" >/dev/null 2>&1; then
  docker image rm -f "$image" && ok "Removed image $image"
else
  info "No existing image $image to remove."
fi

step "$ID — rebuild (no cache)"
compose_build --profile "$profile" --no-cache "$ID"

step "$ID — start"
_compose_base --profile "$profile" up -d "$ID"

ok "$ID rebuilt and started. Run ./scripts/maintenance/component-diag.sh $ID to verify health."
