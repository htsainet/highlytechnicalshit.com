# stable-diffusion repositories/

Intentionally empty in the release snapshot. The stable-diffusion-webui
container clones BLIP, CodeFormer, generative-models, k-diffusion, and
stable-diffusion-stability-ai into this directory on first launch.
