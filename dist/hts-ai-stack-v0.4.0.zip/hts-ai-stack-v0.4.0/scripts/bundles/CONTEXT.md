# Bundle Scripts

Last updated: 2026-04-16 12:00:00

## What happens here

Bundle scripts orchestrate groups of component scripts into deployable feature sets. Each bundle represents a user-facing capability (chat, image generation, voice, etc.) and handles the correct install order, dependency wiring, and health verification for all services in the group.

> **Note:** As of April 2026, `converge.sh` is the primary orchestrator for all
> Docker services. `full-stack.sh` is deprecated — `install.sh` now calls host
> setup scripts directly and delegates all service deployment to `converge.sh`.
> Feature-specific bundles (chat, voice, etc.) remain useful for standalone
> partial deployments.

## Process / Workflow

1. User invokes a bundle: `./scripts/bundles/chat.sh`
2. Bundle sources `lib/common.sh`, calls `banner()` and `load_env()`
3. Bundle sources and calls the component scripts it needs, in dependency order
4. After all components are installed/started, bundle runs aggregate health checks
5. Bundle reports final status

## Files and structure

| File | Bundle | Status |
|------|--------|--------|
| `chat.sh` | Core chat | Active — ollama, open-webui, dashboard |
| `deerflow.sh` | Research agent | Active — deerflow + chat deps |
| `full-stack.sh` | ~~Everything~~ | **Deprecated** — stub pointing to `install.sh` / `converge.sh` |
| `image-gen.sh` | Image generation | Active — stable-diffusion and/or comfyui |
| `nemoclaw.sh` | Sandbox security | Active — nemoclaw, bitnet, llama-swap |
| `openspace.sh` | Agent skills | Active — openspace + chat deps |
| `voice.sh` | Voice pipeline | Active — Voice services + chat deps |

## What good looks like

- Bundle names match their feature set
- Always source `lib/common.sh` first
- Call components in dependency order (e.g. ollama before open-webui)
- Idempotent — safe to re-run
- No direct `docker compose` calls — delegate to component scripts
- Exit with clear success/failure status

## Tools and skills

- **Component scripts** — `scripts/components/*.sh` provide per-service lifecycle
- **lib/common.sh** — `banner()`, `load_env()`, logging functions
- **lib/compose.sh** — Docker Compose wrappers (used indirectly via components)
