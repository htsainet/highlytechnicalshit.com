# OpenSpace References

Last updated: 2026-04-15

## Upstream

- [GitHub — OpenSpace/OpenSpace](https://github.com/OpenSpace/OpenSpace)

## Official documentation

- [OpenSpace Docs](https://docs.openspaceproject.com/)
