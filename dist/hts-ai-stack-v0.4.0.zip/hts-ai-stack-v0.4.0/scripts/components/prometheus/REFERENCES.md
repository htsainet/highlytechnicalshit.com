# Prometheus References

Last updated: 2026-04-15

## Upstream

- [GitHub — prometheus/prometheus](https://github.com/prometheus/prometheus)

## Official documentation

- [Prometheus Docs](https://prometheus.io/docs/introduction/overview/)
- [PromQL Query Language](https://prometheus.io/docs/prometheus/latest/querying/basics/)
