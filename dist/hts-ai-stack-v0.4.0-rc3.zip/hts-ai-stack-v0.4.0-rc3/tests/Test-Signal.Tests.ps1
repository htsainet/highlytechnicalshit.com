$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/signal'
    $script:ComponentScript = Join-Path $script:ComponentDir 'signal.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'signal.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'signal file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'signal manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is signal' {
        $script:Manifest.id | Should -Be 'signal'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/signal/signal.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is signal' {
        $script:Manifest.func_prefix | Should -Be 'signal'
    }

    It 'category is comms' {
        $script:Manifest.category | Should -Be 'comms'
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'signal component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines signal_install function' {
        $script:ComponentContent | Should -Match 'signal_install\s*\(\)'
    }

    It 'defines signal_configure function' {
        $script:ComponentContent | Should -Match 'signal_configure\s*\(\)'
    }

    It 'defines signal_start function' {
        $script:ComponentContent | Should -Match 'signal_start\s*\(\)'
    }

    It 'defines signal_stop function' {
        $script:ComponentContent | Should -Match 'signal_stop\s*\(\)'
    }

    It 'defines signal_health function' {
        $script:ComponentContent | Should -Match 'signal_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/signal/signal\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'signal no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/signal\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/signal/signal\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
