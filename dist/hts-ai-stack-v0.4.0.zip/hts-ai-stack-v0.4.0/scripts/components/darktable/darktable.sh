#!/usr/bin/env bash
# scripts/components/darktable/darktable.sh — Darktable: install, configure, health
#
# Host-native installer for Darktable, an open-source photography workflow
# application and raw developer. Non-destructive RAW editing with GPU
# acceleration via OpenCL.
#
# Standalone usage:
#   ./scripts/components/darktable/darktable.sh              # full: install + configure + health
#   ./scripts/components/darktable/darktable.sh --install    # install only
#   ./scripts/components/darktable/darktable.sh --configure  # configure only
#   ./scripts/components/darktable/darktable.sh --start      # no-op (desktop app)
#   ./scripts/components/darktable/darktable.sh --stop       # no-op (desktop app)
#   ./scripts/components/darktable/darktable.sh --restart    # no-op (desktop app)
#   ./scripts/components/darktable/darktable.sh --health     # health check only
#   ./scripts/components/darktable/darktable.sh --status     # show status + health
#   ./scripts/components/darktable/darktable.sh --destroy    # uninstall Darktable
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

load_env

darktable_install() {
  step "Darktable — install"
  if command -v darktable &>/dev/null; then
    skip "Darktable already installed."
  else
    info "Installing Darktable via snap (latest stable)..."
    sudo snap install darktable
    ok "Darktable installed."
  fi
}

darktable_configure() {
  step "Darktable — configure"
  info "Darktable is a desktop application — no service configuration needed."
  info "OpenCL GPU acceleration is enabled automatically if drivers are present."
  ok "Darktable configured."
}

darktable_start() {
  step "Darktable — start"
  info "Darktable is a desktop application. Launch from your application menu."
}

darktable_stop() {
  step "Darktable — stop"
  info "Darktable is a desktop application. Close it from the window."
}

darktable_restart() { darktable_stop; darktable_start; }

darktable_health() {
  step "Darktable — health"
  if command -v darktable &>/dev/null; then
    local ver
    ver=$(darktable --version 2>/dev/null | head -1 || echo "unknown")
    ok "Darktable is installed: $ver"
    return 0
  else
    warn "Darktable is not installed."
    return 1
  fi
}

darktable_status() { step "Darktable — status"; darktable_health; }

darktable_destroy() {
  step "Darktable — destroy"
  if snap list darktable &>/dev/null 2>&1; then
    info "Removing Darktable snap..."
    sudo snap remove darktable
    ok "Darktable removed."
  elif dpkg -l darktable &>/dev/null 2>&1; then
    info "Removing Darktable apt package..."
    sudo apt-get remove -y darktable
    ok "Darktable removed."
  else
    skip "Darktable is not installed."
  fi
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  case "${1:-}" in
    --install)   darktable_install   ;;
    --configure) darktable_configure ;;
    --start)     darktable_start     ;;
    --stop)      darktable_stop      ;;
    --restart)   darktable_restart   ;;
    --health)    darktable_health    ;;
    --status)    darktable_status    ;;
    --destroy)   darktable_destroy   ;;
    *)
      darktable_install
      darktable_configure
      darktable_health
      ;;
  esac
fi
