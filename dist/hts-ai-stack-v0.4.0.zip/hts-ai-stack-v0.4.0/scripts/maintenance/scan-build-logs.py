#!/usr/bin/env python3
"""scan-build-logs.py — Scan Docker build / converge logs for supply-chain issues.

Detects:
  - Yanked PyPI packages (pip)
  - "Update available" notices (npm / pnpm / corepack)
  - Deprecated packages and subdependencies (npm / pnpm / pip)
  - Unpinned :latest / :main / @latest tags
  - npm audit / security vulnerability warnings
  - CVE references
  - Apt held-back or obsolete packages

Usage:
  # Scan most recent converge log
  ./scripts/maintenance/scan-build-logs.py

  # Scan a specific log file
  ./scripts/maintenance/scan-build-logs.py logs/converge-20260419-233424.log

  # Scan all logs from today
  ./scripts/maintenance/scan-build-logs.py logs/converge-20260420-*.log

  # Scan from stdin (e.g. piped docker build)
  docker compose build foo 2>&1 | ./scripts/maintenance/scan-build-logs.py -

Exit codes:
  0 = clean (only informational findings)
  1 = warnings found (yanked, CVE, vulnerability)
  2 = no log files found
"""

import re
import sys
import glob
import os
from dataclasses import dataclass, field
from pathlib import Path

# ── Finding categories ────────────────────────────────────────────────────────

SEVERITY_CRITICAL = "CRITICAL"
SEVERITY_WARNING = "WARNING"
SEVERITY_INFO = "INFO"

# ANSI colors (disabled when piped)
USE_COLOR = sys.stdout.isatty()


def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def red(t):
    return _c("1;31", t)


def yellow(t):
    return _c("0;33", t)


def dim(t):
    return _c("2", t)


def bold(t):
    return _c("1", t)


def cyan(t):
    return _c("0;36", t)


@dataclass
class Finding:
    severity: str
    category: str
    message: str
    source_file: str = ""
    line_number: int = 0
    raw_line: str = ""


# ── Pattern definitions ──────────────────────────────────────────────────────

PATTERNS = [
    # pip: yanked package
    {
        "name": "yanked-package",
        "severity": SEVERITY_CRITICAL,
        "category": "Yanked Package (pip)",
        "pattern": re.compile(
            r"yanked version: '([^']+)' candidate \(version ([^\s)]+)",
            re.IGNORECASE,
        ),
        "message": lambda m: f"Yanked from PyPI: {m.group(1)}=={m.group(2)}",
    },
    # pip: yanked reason (supplement — attach to previous)
    {
        "name": "yanked-reason",
        "severity": SEVERITY_CRITICAL,
        "category": "Yanked Package (pip)",
        "pattern": re.compile(
            r"Reason for being yanked:\s*(.+)", re.IGNORECASE
        ),
        "message": lambda m: f"Yank reason: {m.group(1).strip()}",
    },
    # npm/pnpm: "Update available! X → Y"
    {
        "name": "update-available",
        "severity": SEVERITY_INFO,
        "category": "Update Available (npm/pnpm)",
        "pattern": re.compile(
            r"Update available!\s*([\d.]+)\s*→\s*([\d.]+)", re.IGNORECASE
        ),
        "message": lambda m: f"Update available: {m.group(1)} → {m.group(2)}",
    },
    # npm/pnpm: deprecated package
    {
        "name": "deprecated-package",
        "severity": SEVERITY_WARNING,
        "category": "Deprecated Package (npm/pnpm)",
        "pattern": re.compile(
            r"WARN\s+deprecated\s+(\S+)", re.IGNORECASE
        ),
        "message": lambda m: f"Deprecated: {m.group(1)}",
    },
    # npm/pnpm: deprecated subdependencies (batch)
    {
        "name": "deprecated-subdeps",
        "severity": SEVERITY_WARNING,
        "category": "Deprecated Subdependencies (npm/pnpm)",
        "pattern": re.compile(
            r"WARN\s+(\d+)\s+deprecated subdependencies found:\s*(.+)",
            re.IGNORECASE,
        ),
        "message": lambda m: f"{m.group(1)} deprecated subdeps: {m.group(2).strip()}",
    },
    # npm audit: vulnerabilities
    {
        "name": "npm-audit-vuln",
        "severity": SEVERITY_WARNING,
        "category": "Vulnerability (npm audit)",
        "pattern": re.compile(
            r"(\d+)\s+(high|critical|moderate)\s+severity\s+vulnerabilit",
            re.IGNORECASE,
        ),
        "message": lambda m: f"{m.group(1)} {m.group(2)}-severity vulnerabilities",
    },
    # CVE reference
    {
        "name": "cve-reference",
        "severity": SEVERITY_CRITICAL,
        "category": "CVE Reference",
        "pattern": re.compile(r"(CVE-\d{4}-\d{4,})", re.IGNORECASE),
        "message": lambda m: f"CVE mentioned: {m.group(1)}",
    },
    # pip: deprecation warnings
    {
        "name": "pip-deprecation",
        "severity": SEVERITY_WARNING,
        "category": "Deprecation (pip)",
        "pattern": re.compile(
            r"DEPRECATION:\s*(.+)", re.IGNORECASE
        ),
        "message": lambda m: f"{m.group(1).strip()[:120]}",
    },
    # apt: held-back packages
    {
        "name": "apt-held-back",
        "severity": SEVERITY_INFO,
        "category": "Held-back Packages (apt)",
        "pattern": re.compile(
            r"The following packages have been kept back:\s*$", re.IGNORECASE
        ),
        "message": lambda _m: "apt has held-back packages (check next line)",
    },
    # Dockerfile: unpinned FROM (only in docker build output context)
    {
        "name": "unpinned-from",
        "severity": SEVERITY_WARNING,
        "category": "Unpinned Base Image",
        "pattern": re.compile(
            r"FROM\s+\S+:(latest|main|master|dev|nightly)\s", re.IGNORECASE
        ),
        "message": lambda m: f"Unpinned base image tag: :{m.group(1)}",
    },
    # Go: retracted module version
    {
        "name": "go-retracted",
        "severity": SEVERITY_CRITICAL,
        "category": "Retracted Module (Go)",
        "pattern": re.compile(
            r"retracted by module author", re.IGNORECASE
        ),
        "message": lambda _m: "Go module version retracted by author",
    },
]

# Lines matching these are noise — skip them entirely
NOISE_FILTERS = [
    re.compile(r"deb\.debian\.org/debian-security", re.IGNORECASE),
    re.compile(r"Running pip as the 'root' user", re.IGNORECASE),
    re.compile(r"Use the --root-user-action option", re.IGNORECASE),
    re.compile(r"use a virtual environment instead", re.IGNORECASE),
]


# ── Scanner ──────────────────────────────────────────────────────────────────


def scan_lines(lines, source_file="<stdin>"):
    """Scan lines and return list of Finding objects."""
    findings = []
    seen = set()

    for line_num, raw_line in enumerate(lines, 1):
        line = raw_line.rstrip()

        # Skip known noise
        if any(nf.search(line) for nf in NOISE_FILTERS):
            continue

        for pat in PATTERNS:
            match = pat["pattern"].search(line)
            if not match:
                continue

            msg = pat["message"](match)
            dedup_key = (pat["name"], msg)
            if dedup_key in seen:
                continue
            seen.add(dedup_key)

            findings.append(
                Finding(
                    severity=pat["severity"],
                    category=pat["category"],
                    message=msg,
                    source_file=source_file,
                    line_number=line_num,
                    raw_line=line.strip()[:200],
                )
            )

    return findings


def scan_file(filepath):
    """Scan a single log file."""
    try:
        with open(filepath, "r", errors="replace") as f:
            return scan_lines(f, source_file=filepath)
    except (OSError, IOError) as e:
        print(f"  Error reading {filepath}: {e}", file=sys.stderr)
        return []


# ── Output formatting ────────────────────────────────────────────────────────


def format_findings(findings, source_label=""):
    """Pretty-print findings grouped by severity."""
    if not findings:
        return

    by_severity = {SEVERITY_CRITICAL: [], SEVERITY_WARNING: [], SEVERITY_INFO: []}
    for f in findings:
        by_severity.get(f.severity, by_severity[SEVERITY_INFO]).append(f)

    for severity in (SEVERITY_CRITICAL, SEVERITY_WARNING, SEVERITY_INFO):
        group = by_severity[severity]
        if not group:
            continue

        if severity == SEVERITY_CRITICAL:
            header = red(f"  ✖ {severity} ({len(group)})")
        elif severity == SEVERITY_WARNING:
            header = yellow(f"  ⚠ {severity} ({len(group)})")
        else:
            header = dim(f"  ▸ {severity} ({len(group)})")

        print(header)
        for f in group:
            loc = f"L{f.line_number}" if f.line_number else ""
            print(f"    {f.category}: {f.message}  {dim(loc)}")
        print()


def write_report(findings, report_path):
    """Write machine-readable report (tab-separated)."""
    with open(report_path, "w") as f:
        f.write("severity\tcategory\tmessage\tfile\tline\n")
        for finding in findings:
            f.write(
                f"{finding.severity}\t{finding.category}\t{finding.message}"
                f"\t{finding.source_file}\t{finding.line_number}\n"
            )


# ── Main ─────────────────────────────────────────────────────────────────────


def find_latest_log(logs_dir):
    """Find the most recent converge or install log."""
    patterns = [
        os.path.join(logs_dir, "converge-*.log"),
        os.path.join(logs_dir, "install-*.log"),
    ]
    all_logs = []
    for p in patterns:
        all_logs.extend(glob.glob(p))
    if not all_logs:
        return None
    return max(all_logs, key=os.path.getmtime)


def main():
    # Determine repo root
    script_dir = Path(__file__).resolve().parent
    repo_root = script_dir.parent.parent
    logs_dir = repo_root / "logs"

    # Determine input sources
    if len(sys.argv) > 1:
        if sys.argv[1] == "-":
            # Read from stdin
            sources = [("<stdin>", sys.stdin.readlines())]
        else:
            # Expand globs from command line args
            files = []
            for arg in sys.argv[1:]:
                expanded = glob.glob(arg)
                files.extend(expanded if expanded else [arg])
            sources = [(f, None) for f in files]
    else:
        # Auto-detect latest log
        latest = find_latest_log(str(logs_dir))
        if not latest:
            print(red("  ✖ No log files found in logs/"))
            sys.exit(2)
        sources = [(latest, None)]

    # Run scan
    all_findings = []
    files_scanned = 0

    print()
    print(bold("  Build Log Scanner"))
    print(f"  {'─' * 40}")

    for source_path, lines in sources:
        files_scanned += 1
        if lines is not None:
            findings = scan_lines(lines, source_file=source_path)
        else:
            findings = scan_file(source_path)
        all_findings.extend(findings)

        if len(sources) > 1 and findings:
            basename = os.path.basename(source_path)
            print(f"\n  {cyan(basename)}")
            format_findings(findings)

    if len(sources) == 1:
        basename = os.path.basename(sources[0][0])
        print(f"  Source: {dim(basename)}")
        print()
        format_findings(all_findings)

    # Summary
    crits = sum(1 for f in all_findings if f.severity == SEVERITY_CRITICAL)
    warns = sum(1 for f in all_findings if f.severity == SEVERITY_WARNING)
    infos = sum(1 for f in all_findings if f.severity == SEVERITY_INFO)

    if not all_findings:
        print(f"  {bold('✓')} Clean — no issues found across {files_scanned} log(s)")
    else:
        parts = []
        if crits:
            parts.append(red(f"{crits} critical"))
        if warns:
            parts.append(yellow(f"{warns} warning"))
        if infos:
            parts.append(dim(f"{infos} info"))
        print(f"  Found {', '.join(parts)} across {files_scanned} log(s)")

    # Write report if findings exist
    if all_findings:
        report_path = logs_dir / "scan-report.tsv"
        write_report(all_findings, str(report_path))
        print(f"  Report: {dim(str(report_path))}")

    print()

    # Exit code: 1 if critical or warning findings
    sys.exit(1 if (crits or warns) else 0)


if __name__ == "__main__":
    main()
