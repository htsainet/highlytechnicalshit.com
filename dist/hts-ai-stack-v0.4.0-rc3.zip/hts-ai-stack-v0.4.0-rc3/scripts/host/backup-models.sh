#!/usr/bin/env bash
# scripts/host/backup-models.sh — Sync local model volumes to NAS
#
# Uses rsync WITHOUT --delete so nothing on the NAS is removed.
# Only new/updated files are copied.
#
# Usage:  sudo ./scripts/host/backup-models.sh

set -euo pipefail

NAS_MOUNT="/mnt/htsai-model-backup"

# ── Preflight checks ────────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
  echo "[ERROR] Run with sudo: sudo $0"
  exit 1
fi

if ! mountpoint -q "$NAS_MOUNT" 2>/dev/null; then
  echo "[ERROR] $NAS_MOUNT is not mounted. Run: sudo mount -a"
  exit 1
fi

if ! command -v docker &>/dev/null; then
  echo "[ERROR] docker not found."
  exit 1
fi

# ── Detect compose project prefix ────────────────────────────────────────────
PROJECT_PREFIX=$(docker volume ls --format '{{.Name}}' | grep '_ollama_data$' | sed 's/_ollama_data$//' || true)
if [[ -z "$PROJECT_PREFIX" ]]; then
  PROJECT_PREFIX="hts-ai-stack"
  echo "[INFO] Could not auto-detect prefix, using: $PROJECT_PREFIX"
else
  echo "[INFO] Detected compose project prefix: $PROJECT_PREFIX"
fi

# ── Helper: sync a Docker volume to a NAS subfolder ─────────────────────────
sync_volume() {
  local vol_name="${PROJECT_PREFIX}_$1"
  local nas_subdir="$2"

  local mp
  mp=$(docker volume inspect "$vol_name" --format '{{.Mountpoint}}' 2>/dev/null) || true

  if [[ -z "$mp" || ! -d "$mp" ]]; then
    echo "[SKIP] Volume '$vol_name' not found or empty."
    return
  fi

  local dest="${NAS_MOUNT}/${nas_subdir}"
  mkdir -p "$dest"

  echo ""
  echo "══ Syncing $vol_name → $dest ══"
  rsync -av --no-owner --no-group --progress "$mp/" "$dest/"
  echo "[OK] $vol_name synced."
}

# ── Sync all model volumes ──────────────────────────────────────────────────
echo "═══════════════════════════════════════════"
echo "  Model Backup → NAS ($NAS_MOUNT)"
echo "═══════════════════════════════════════════"

sync_volume "ollama_data"        "ollama/models"
sync_volume "sd_models"          "stable-diffusion/checkpoints"
sync_volume "comfyui_models"     "comfyui/models"
sync_volume "comfyui_custom_nodes" "comfyui/custom_nodes"
sync_volume "comfyui_output"     "comfyui/output"
sync_volume "bitnet_models"      "bitnet/models"
sync_volume "localai_models"     "localai/models"
sync_volume "coqui_tts_models"   "coqui-tts/models"
sync_volume "vosk_models"        "vosk/models"

# ── Check if sd_models has lora/embedding/vae subdirs ───────────────────────
sd_mp=$(docker volume inspect "${PROJECT_PREFIX}_sd_models" --format '{{.Mountpoint}}' 2>/dev/null) || true
if [[ -n "$sd_mp" && -d "$sd_mp" ]]; then
  for subdir in loras embeddings vae; do
    if [[ -d "$sd_mp/$subdir" ]]; then
      dest="${NAS_MOUNT}/stable-diffusion/${subdir}"
      mkdir -p "$dest"
      echo ""
      echo "══ Syncing sd_models/$subdir → $dest ══"
      rsync -av --no-owner --no-group --progress "$sd_mp/$subdir/" "$dest/"
      echo "[OK] sd-${subdir} synced."
    fi
  done
fi

echo ""
echo "═══════════════════════════════════════════"
echo "  Backup complete!"
echo "═══════════════════════════════════════════"
