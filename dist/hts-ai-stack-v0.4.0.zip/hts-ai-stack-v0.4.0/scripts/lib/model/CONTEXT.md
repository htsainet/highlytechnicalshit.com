# Model Library Context

This folder provides a **centralized model handling library** (`model.sh`) that all component scripts can source. It offers:

* A single source of truth for model URLs, licenses, and trust levels (`model-registry.json`).
* Helper functions to retrieve a model’s download URL (`model_get_url`) and optionally its license.
* A generic download stub (`model_download_if_missing`) that component scripts can wrap or extend for their own volume/NAS handling.

The goal is to eliminate duplicated model‑download code across components (Stable Diffusion, Whisper, Open‑LLM‑VTuber, etc.) and to make model selection **wizard‑driven** via the manifest’s `options_source`/`default_source` fields.
