#!/usr/bin/env python3
"""registry-llama-swap-check.py — verify registry.json ↔ llama-swap.yaml symmetry.

Invariant:
    Every Ollama model routed by config/llama-swap.yaml MUST exist in
    scripts/install/models/registry.json so that `ollama.sh --pull-models`
    can pull it.

    Every prod-env Ollama model in registry.json SHOULD be routable via
    config/llama-swap.yaml (otherwise it gets pulled but is unreachable).
    This direction is reported as a warning rather than a hard failure,
    because some prod entries are deliberately not routed (staging /
    pull-for-disk-cache / tool-specific).

Usage:
    scripts/maintenance/registry-llama-swap-check.py            # report only
    scripts/maintenance/registry-llama-swap-check.py --strict   # exit 1 on any drift

Exit codes:
    0 = symmetric, OR drift-present in report-only mode (default)
    1 = --strict AND drift present (either direction)
    2 = file / parse error
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.stderr.write("PyYAML required: pip install pyyaml\n")
    sys.exit(2)

REPO = Path(__file__).resolve().parents[2]
REGISTRY = REPO / "scripts/install/models/registry.json"
LLAMA_SWAP = REPO / "config/llama-swap.yaml"


def load_registry() -> dict[str, dict]:
    try:
        data = json.loads(REGISTRY.read_text())
    except Exception as exc:
        sys.stderr.write(f"ERROR reading {REGISTRY}: {exc}\n")
        sys.exit(2)
    return {m["model"]: m for m in data.get("ollama", [])}


def load_llama_swap_ollama_models() -> set[str]:
    try:
        data = yaml.safe_load(LLAMA_SWAP.read_text())
    except Exception as exc:
        sys.stderr.write(f"ERROR reading {LLAMA_SWAP}: {exc}\n")
        sys.exit(2)
    peers = (data or {}).get("peers") or {}
    ollama_peer = peers.get("ollama") or {}
    return set(ollama_peer.get("models") or [])


def main() -> int:
    strict = "--strict" in sys.argv[1:]

    reg = load_registry()
    reg_prod = {name for name, m in reg.items() if "prod" in (m.get("env") or [])}
    swap_models = load_llama_swap_ollama_models()

    routed_not_pullable = swap_models - set(reg.keys())
    prod_not_routed = reg_prod - swap_models

    errs = 0
    if routed_not_pullable:
        print(f"✗ Routed by llama-swap but MISSING from registry.json ({len(routed_not_pullable)}):")
        for m in sorted(routed_not_pullable):
            print(f"    - {m}")
        print("  → Add each to the `ollama` array in scripts/install/models/registry.json")
        print("    so ollama.sh --pull-models will pull them.")
        errs += len(routed_not_pullable)

    if prod_not_routed:
        print(f"⚠ prod-env in registry.json but NOT routed by llama-swap.yaml ({len(prod_not_routed)}):")
        for m in sorted(prod_not_routed):
            notes = reg[m].get("notes", "")
            print(f"    - {m}" + (f"    ({notes})" if notes else ""))
        print("  → Either uncomment in config/llama-swap.yaml (peers.ollama.models)")
        print("    or drop 'prod' from the model's env in registry.json.")

    if not routed_not_pullable and not prod_not_routed:
        print(
            f"✓ registry.json ↔ llama-swap.yaml symmetric "
            f"({len(swap_models)} routed, {len(reg)} registered)."
        )
        return 0

    if strict and (routed_not_pullable or prod_not_routed):
        return 1
    # report-only mode: warnings are fine
    if errs and strict:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
