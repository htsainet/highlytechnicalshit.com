# LocalAI References

Last updated: 2026-04-15

## Upstream

- [GitHub — mudler/LocalAI](https://github.com/mudler/LocalAI)

## Official documentation

- [LocalAI docs](https://localai.io)
- [Container deployment](https://localai.io/basics/container/)
- [Model gallery](https://localai.io/models/)

## Container images

- GPU (CUDA 12): `quay.io/go-skynet/local-ai:latest-gpu-nvidia-cuda-12`
- CPU only: `quay.io/go-skynet/local-ai:latest`

## Related

- [OpenAI API specification](https://platform.openai.com/docs/api-reference) — API compatibility target
