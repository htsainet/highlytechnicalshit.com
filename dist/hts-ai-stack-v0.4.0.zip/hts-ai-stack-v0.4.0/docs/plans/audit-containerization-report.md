# Audit: Containerization coverage (scripts/components)

Generated: via automated repo audit

Summary:

- Total components scanned: 65
- Components with Dockerfile or docker/ subdir: 1
- Components missing Docker packaging: 64

This quick audit scanned scripts/components for the presence of a Dockerfile or a docker/ directory (also checks `../docker/<component>` paths).

Findings (MISSING means no Dockerfile/docker directory found):

```text
$(cat /tmp/audit_containerization_list.txt)
```

Recommendations:

1. Prioritize containerizing core infra and inference components first:
   - llama-swap, ollama, nemoclaw, prometheus, grafana
2. For each component, add either a Dockerfile or a docker/ directory that builds a reproducible image.
3. Add a repo-level CI job that builds the image for each component that changed and publishes SBOMs + checksums.
4. For components that are intended to run only on host (e.g., heavy GPU tools), consider an OpenShell sandbox or dedicated VM image instead of pip install on the host.

Next steps (proposed):

- Create a prioritized list (top 10) of components to containerize and create GH Actions to build them.
- Start with: ollama, llama-swap, nemoclaw, prometheus, grafana, paperclip (already has Docker), dashboard, openshell gateway, bitnet.

Notes:

- This is a shallow scan — some components may use centralized images stored under /docker/ or use upstream images; refine by checking docker/ and docker-compose.yml mapping.
- The audit is intentionally conservative: it flags anything without a Dockerfile or docker/ folder.
