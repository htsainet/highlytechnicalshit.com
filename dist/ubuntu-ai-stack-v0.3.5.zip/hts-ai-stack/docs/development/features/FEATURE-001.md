# Docker Isolated Network Mode

**Priority:** LOW (evaluation/testing feature)
**Effort:** ~30-45 minutes
**Risk:** Low — additive feature, no impact on existing deployment modes
**Depends on:** Nothing — can be built independently
**Blocks:** Nothing

## Problem

When evaluating the AI stack before full installation, users currently expose services to the host and localhost. This makes it difficult to assess the stack in a completely isolated state or understand port conflicts and network dependencies before production deployment.

Users need a way to:

- Test the entire stack without any services accessible from the host
- Verify inter-container networking works correctly in isolation
- Access stack services safely for evaluation without exposing them broadly
- Understand service dependencies and communication patterns

## Solution

Implement an **isolated network mode** configuration option that:

1. Creates a dedicated Docker bridge network for stack evaluation
2. Runs all containers on this isolated network (no exposed ports to host)
3. Provides a single **gateway container** (reverse proxy) as the only service with a host port exposed
4. Uses the gateway to access other services during evaluation (forwarding requests through the isolated network)

This allows full stack testing in a sandbox before committing to production installation.

## Implementation Steps

### 1. Design the gateway container

Choose a lightweight reverse proxy:

- **nginx** (lightweight, widely available) — recommended for simplicity
- **traefik** (auto-discovery, more features) — if dynamic service registration is valuable
- **caddy** (auto HTTPS, simpler config) — alternative

Recommendation: Start with **nginx** for minimal complexity.

### 2. Create docker-compose configuration for isolated mode

Add a new compose file: `docker-compose.isolated.yml` or similar

```yaml
version: '3.8'

networks:
  isolated-eval:
    driver: bridge

services:
  gateway:
    image: nginx:alpine
    container_name: stack-gateway
    ports:
      - "8888:80"  # Single exposed port (configurable)
    volumes:
      - ./gateway-nginx.conf:/etc/nginx/nginx.conf:ro
    networks:
      - isolated-eval
    depends_on:
      - ollama
      - webui
      # ... other services

  ollama:
    image: ollama/ollama:latest
    container_name: stack-ollama
    networks:
      - isolated-eval
    # NO ports exposed to host
    # Services access via internal network: http://ollama:11434

  webui:
    image: open-webui:latest
    container_name: stack-webui
    networks:
      - isolated-eval
    # NO ports exposed to host

  # ... other services (all on isolated-eval network, no exposed ports)
```

### 3. Create nginx gateway configuration

File: `gateway-nginx.conf`

```nginx
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;

    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;

    # Upstream services (internal network)
    upstream webui_backend {
        server webui:3000;
    }

    upstream ollama_backend {
        server ollama:11434;
    }

    upstream api_backend {
        server api:8080;
    }

    # HTTP server
    server {
        listen 80;
        server_name _;

        # Web UI
        location / {
            proxy_pass http://webui_backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # Ollama API
        location /ollama/ {
            proxy_pass http://ollama_backend/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }

        # Stack API
        location /api/ {
            proxy_pass http://api_backend/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }

        # Health check
        location /health {
            access_log off;
            return 200 "healthy\n";
            add_header Content-Type text/plain;
        }
    }
}
```

### 4. Update documentation

Add to `docs/deployment/`:

- `ISOLATED_MODE.md` — Quick start for evaluation mode
- Update main README with link to isolation mode instructions
- Add diagram showing gateway → internal network architecture

### 5. Create launch script

Add script: `scripts/stack-isolated.sh` (or PowerShell equivalent)

```bash
#!/bin/bash
# Launch stack in isolated evaluation mode

set -e

PORT="${1:-8888}"  # Default to 8888, allow override
NETWORK="${STACK_NETWORK:-isolated-eval}"

echo "Starting AI stack in ISOLATED MODE..."
echo "Gateway will be available at: http://localhost:$PORT"
echo ""
echo "Services behind gateway:"
echo "  - Web UI:  http://localhost:$PORT"
echo "  - Ollama:  http://localhost:$PORT/ollama/"
echo "  - API:     http://localhost:$PORT/api/"
echo ""
echo "To stop: docker-compose -f docker-compose.isolated.yml down"
echo ""

docker-compose -f docker-compose.isolated.yml up -d

sleep 2

echo "✓ Stack is running in isolated mode"
echo "✓ Check health: curl http://localhost:$PORT/health"
```

### 6. Add convenience commands

Update `Makefile` or `docker-compose.yml` with shortcuts:

```makefile
.PHONY: isolated
isolated:
	docker-compose -f docker-compose.isolated.yml up -d

.PHONY: isolated-down
isolated-down:
	docker-compose -f docker-compose.isolated.yml down

.PHONY: isolated-logs
isolated-logs:
	docker-compose -f docker-compose.isolated.yml logs -f

.PHONY: isolated-status
isolated-status:
	docker-compose -f docker-compose.isolated.yml ps
```

## Validation

### 1. Verify isolation

```bash
# No containers should have ports directly exposed to host
docker-compose -f docker-compose.isolated.yml ps

# Only gateway should have port binding
docker port stack-gateway
# Expected: 80/tcp -> 0.0.0.0:8888
```

### 2. Verify gateway access

```bash
# Gateway health check
curl http://localhost:8888/health

# Access Web UI through gateway
curl http://localhost:8888

# Access Ollama through gateway
curl http://localhost:8888/ollama/api/tags

# Access API through gateway
curl http://localhost:8888/api/status
```

### 3. Verify internal networking

```bash
# Enter gateway container and verify internal DNS
docker exec stack-gateway nslookup ollama
docker exec stack-gateway nslookup webui
docker exec stack-gateway curl http://ollama:11434/api/tags
```

### 4. Verify host isolation

```bash
# These should FAIL (not accessible directly)
curl http://localhost:11434/api/tags 2>&1 | grep -q "refused\|Connection refused"
curl http://localhost:3000 2>&1 | grep -q "refused\|Connection refused"

# Only 8888 should be open
netstat -tuln | grep 8888
```

### 5. Run existing Pester tests

Any existing containerization/networking tests should still pass:

```powershell
Invoke-Pester ./tests/Docker/ -Output Detailed
```

## Future Considerations

- **Multi-gateway option:** Support multiple independent isolated stacks running simultaneously (useful for comparing configurations)
- **Metrics gateway:** Add a second gateway container exposing Prometheus metrics to localhost for evaluation monitoring
- **Environment templating:** Allow users to inject custom nginx configs for different evaluation scenarios (e.g., load balancing, circuit breakers)
- **Automated port selection:** Detect and auto-select a free port instead of hardcoding 8888
- **Isolation verification test:** Write a Pester test that confirms services are NOT accessible directly from host, only through gateway

## Checklist

- [ ] Choose reverse proxy (recommend nginx)
- [ ] Create `docker-compose.isolated.yml` with isolated network
- [ ] Create gateway container configuration (nginx)
- [ ] Create nginx config file with upstream service routing
- [ ] Create `scripts/stack-isolated.sh` launch script
- [ ] Update Makefile with `make isolated`, `make isolated-down`, etc.
- [ ] Create `docs/deployment/ISOLATED_MODE.md` user guide
- [ ] Test gateway access to all services
- [ ] Test host isolation (services NOT accessible directly)
- [ ] Test internal container networking (gateway can reach all services)
- [ ] Verify existing tests still pass
- [ ] Document in README with link to isolated mode guide
