# install-civitai.sh — CivitAI Shortcut (Stable Diffusion extension)

Installs the [CivitAI Shortcut](https://github.com/sunnyark/civitai-shortcut)
extension into each existing Stable Diffusion WebUI container
(`stable-diffusion-*`). Run once — safe to re-run (skips if already installed).

```bash
bash setup/tooling/install-civitai.sh
```

> Detects all existing containers that match `stable-diffusion-*`.
> If a container is stopped, the script starts it temporarily, installs the
> extension, then restores it to stopped.

---

## What it does

| Step | Action |
|---|---|
| 1 | Finds all existing containers named `stable-diffusion-*` |
| 2 | Installs the extension in each container's persistent extensions volume (skipped if present) |
| 3 | Restarts containers that were already running; stops containers that were initially stopped |
| 4 | Prints per-container access URLs using each mapped host port |

The extension is cloned into each container's `extensions` volume (for example:
`sd_extensions_prod`, `sd_extensions_test`), so it
persists across container restarts and image upgrades. You only need to run
this script once per container lifecycle.

---

## After setup

Open SD WebUI (~30 seconds after restart):

```text
http://<server-ip>:7860   (prod)
http://<server-ip>:7861   (test)
```

The CivitAI icon appears in the top navigation bar. From there you can:

- Browse and search [civitai.com](https://civitai.com) models
- Download checkpoints, LoRAs, embeddings, and VAEs directly into your model volumes
- Manage model metadata and preview images

---

## Updating the extension

```bash
for c in stable-diffusion-prod stable-diffusion-test; do
  docker inspect "$c" >/dev/null 2>&1 || continue
  was_running=false
  docker inspect --format '{{.State.Running}}' "$c" | grep -q true && was_running=true

  $was_running || docker start "$c" >/dev/null
  docker exec "$c" git -C /app/stable-diffusion-webui/extensions/civitai-shortcut pull || true

  if $was_running; then
    docker restart "$c" >/dev/null
  else
    docker stop "$c" >/dev/null
  fi
done
```
