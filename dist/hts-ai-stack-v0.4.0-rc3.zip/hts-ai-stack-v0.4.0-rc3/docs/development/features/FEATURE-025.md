# Coqui TTS — Text-to-Speech Service

**Priority:** MEDIUM
**Effort:** 3–4 hours
**Risk:** Medium — MPL-2.0 copyleft (modifications must be open-sourced); model first-run download ~1.8GB.
**Target Release:** v0.6.0
**Depends on:** llama-swap (no dependency — TTS is standalone)
**Blocks:** Voice pipeline completeness (pairs with FEATURE-026 STT)

## Problem

The stack has no GPU-accelerated TTS capability. Text-to-speech is needed for voice
output in the assistant pipeline and for creative audio generation workflows.

## Current State

No TTS service in the stack. `coqui-ai/TTS` upstream is archived.
The active community fork `idiap/coqui-ai-TTS` (MIT/MPL-2.0) is the recommended deployment path.

## License Note

`idiap/coqui-ai-TTS` is dual-licensed:

- Core library: **MPL-2.0** — modifications to the library source must be open-sourced.
  Unmodified use in a private stack does not trigger copyleft.
- Some model weights: MIT — check individual model licenses before redistribution.

## Architecture

GPU-accelerated TTS REST server on port 5002.
CUDA 12 primary path; automatic CPU fallback when no GPU is available.
XTTS v2 model is the recommended voice (~1.8GB, downloads on first run).

## Implementation Steps

### P0 — Service

- [ ] **1. Docker compose service**
  Add `coqui-tts` service under `profiles: [coqui-tts]`.

  ```yaml
  coqui-tts:
    image: ghcr.io/idiap/coqui-ai-tts:latest
    container_name: hts-ai-coqui-tts
    profiles: [coqui-tts]
    restart: unless-stopped
    ports:
      - "${COQUI_TTS_PORT:-5002}:5002"
    environment:
      - COQUI_TTS_MODEL=${COQUI_TTS_MODEL:-tts_models/multilingual/multi-dataset/xtts_v2}
    volumes:
      - coqui-tts-models:/root/.local/share/tts
    networks:
      - ai-network
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    healthcheck:
      test: ["CMD", "curl", "-sf", "http://localhost:5002/health"]
      interval: 30s
      timeout: 15s
      retries: 5
      start_period: 120s
  ```

  > **Note:** Verify GHCR image `ghcr.io/idiap/coqui-ai-tts:latest` exists.
  > If not published, build from `https://github.com/idiap/coqui-ai-TTS` Dockerfile.

- [ ] **2. Component script**
  Create `scripts/components/coqui-tts/coqui-tts.sh` implementing:
  - `coqui_tts_install` — pull image or build from source
  - `coqui_tts_configure` — validate `COQUI_TTS_MODEL` env var
  - `coqui_tts_start` — start service + wait for health (allow 120s for model load)
  - `coqui_tts_health` — `curl -sf http://localhost:${COQUI_TTS_PORT}/health`
  - `coqui_tts_stop` — stop service

  Add VRAM check: if GPU VRAM < 4GB, warn and suggest `--device cpu` override.

- [ ] **3. Env vars**
  Add to `.env.example`:

  ```text
  COQUI_TTS_PORT=5002
  COQUI_TTS_MODEL=tts_models/multilingual/multi-dataset/xtts_v2
  ```

### P1 — Registration

- [ ] **4. Port map** — Add port 5002 to `REFERENCES.md` Host Port Map table.
- [ ] **5. Feature index** — Add row to `docs/development/features/REFERENCES.md`.

### P2 — CPU fallback

If no NVIDIA GPU is available, the image should fall back to CPU inference automatically.
Document in component script: generate a `--device cpu` override Docker command for
users without a GPU, with a warning that XTTS v2 will be slow on CPU (~20–40s per sentence).

## Acceptance Criteria

- `docker compose --profile coqui-tts up` starts the service
- REST endpoint `POST http://localhost:5002/api/tts` returns synthesised audio
- `coqui_tts_health` returns success
- XTTS v2 model downloads on first run and persists in volume `coqui-tts-models`
- GPU inference confirmed when RTX card is present (check `nvidia-smi` during synthesis)

## Related

- [FEATURE-026](FEATURE-026.md) — Faster-Whisper STT (voice pipeline pair)
- [FEATURE-027](FEATURE-027.md) — Nerd Dictation (host-side voice input)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md) — row: `idiap/coqui-ai-TTS`
