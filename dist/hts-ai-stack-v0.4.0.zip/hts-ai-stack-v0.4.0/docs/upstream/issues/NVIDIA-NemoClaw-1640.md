# NVIDIA/NemoClaw#1640 — Sandbox image missing gnupg package

| Field | Value |
|-------|-------|
| **Repo** | [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) |
| **Issue** | [#1640](https://github.com/NVIDIA/NemoClaw/issues/1640) |
| **State** | OPEN |
| **Severity** | high |
| **Labels** | bug, Platform: DGX Spark, Local Models, priority: high, NV QA, UAT |
| **Opened** | 2026-04-08 |
| **Subscribed** | No |

## Impact on us

Any sandbox operation requiring GPG (package signature verification, key imports) will fail with `gpg: command not found`. This affects package installs inside sandboxes and could break skill installations that need to add apt repositories.

Affected files:

- `scripts/components/nemoclaw/nemoclaw.sh` — sandbox provisioning may silently skip GPG-dependent steps

## Workaround

None documented. Could potentially `apt-get install gnupg` inside a running sandbox as a post-onboard step, but this would not persist across sandbox rebuilds.

## Action when resolved

1. Pull updated sandbox image
2. Re-onboard affected sandboxes
3. Verify `gpg --version` works inside sandbox

## Status log

- **2026-04-08** — Reported upstream. Marked priority: high by NVIDIA QA.
- **2026-04-08** — Identified during our upstream issue scan.
