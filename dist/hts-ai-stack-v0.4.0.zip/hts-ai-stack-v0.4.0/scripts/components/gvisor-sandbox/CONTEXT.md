# gVisor Sandbox Component

Last updated: 2026-04-15

## What happens here

gVisor provides a sandboxed container runtime (runsc) that adds an
application-level kernel for security isolation. Used in the stack
alongside OpenClaw for hardened container execution.

## Files and structure

| File | Purpose |
|------|---------|
| `gvisor-sandbox.sh` | Full lifecycle: install, start, stop, health |
| `gvisor-sandbox.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

See [usage.md](./usage.md) for command usage.
