BeforeAll {
    $RepoRoot = Split-Path -Parent $PSScriptRoot
    $AgentsDir = Join-Path $RepoRoot 'resources' 'agents'
}

Describe 'Agent persona safety checks' {

    Context 'Persona files contain no prompt-injection patterns' {
        BeforeAll {
            $script:Violations = [System.Collections.Generic.List[string]]::new()

            $PersonaFiles = @(
                Get-ChildItem -Path $AgentsDir -Recurse -Include '*.md' -ErrorAction SilentlyContinue
            )

            # Patterns that should never appear in a persona file.
            # Catches common prompt injection, code execution, and data exfil attempts.
            $DangerPatterns = @(
                'ignore\s+(all\s+)?previous\s+instructions'
                'ignore\s+(all\s+)?prior\s+instructions'
                'disregard\s+(all\s+)?previous'
                'you\s+are\s+now\s+DAN'
                'jailbreak'
                '\bcurl\s+-'
                '\bwget\s+'
                '\bbase64\s'
                '\beval\s*\('
                '\bexec\s*\('
                '\bos\.system\s*\('
                '\bsubprocess\b'
                '\bchmod\s+'
                '\brm\s+-rf'
                'data:\s*text/html'
                '<script[\s>]'
            )

            $CombinedPattern = $DangerPatterns -join '|'

            foreach ($File in $PersonaFiles) {
                $Content = Get-Content $File.FullName -Raw
                $Matches = [regex]::Matches($Content, $CombinedPattern, 'IgnoreCase')
                foreach ($Match in $Matches) {
                    $RelPath = $File.FullName.Substring($RepoRoot.Length + 1)
                    $script:Violations.Add("$RelPath : matched '$($Match.Value)'")
                }
            }
        }

        It 'no suspicious patterns found in agent persona files' {
            $Because = if ($script:Violations.Count -gt 0) {
                "Prompt-injection / code-exec patterns detected:`n$($script:Violations -join "`n")"
            } else { 'persona files should not contain prompt injection or code execution patterns' }
            $script:Violations | Should -BeNullOrEmpty -Because $Because
        }
    }
}
