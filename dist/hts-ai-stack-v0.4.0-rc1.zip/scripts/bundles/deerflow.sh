#!/usr/bin/env bash
# scripts/bundles/deerflow.sh — DeerFlow agent harness bundle
#
# Chat bundle + Gitea + NemoClaw + DeerFlow (alternative agent harness).
#
# Usage:
#   ./scripts/bundles/deerflow.sh [--chat mean|claw]
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "DeerFlow Bundle"
load_env

CHAT_MODE="mean"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --chat) CHAT_MODE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-false}"

# ── Chat layer (dual-backend + llama-swap) ─────────────────────────────────────
step "Backend + Chat"
bash "$REPO_DIR/scripts/components/ollama.sh" --swap "$CHAT_MODE"
bash "$REPO_DIR/scripts/components/bitnet.sh"
bash "$REPO_DIR/scripts/components/llama-swap.sh"
bash "$REPO_DIR/scripts/components/open-webui.sh"

# ── Agent services ────────────────────────────────────────────────────────────
step "Agent services"
bash "$REPO_DIR/scripts/components/nemoclaw.sh"
bash "$REPO_DIR/scripts/components/deerflow.sh"

if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/components/dashboard.sh"
fi

echo ""
ok "DeerFlow bundle ready — dual-backend (GPU+CPU) chat:${CHAT_MODE}"
