$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/claw3d'
    $script:ComponentScript = Join-Path $script:ComponentDir 'claw3d.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'claw3d.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'claw3d file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'claw3d manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is claw3d' {
        $script:Manifest.id | Should -Be 'claw3d'
    }

    It 'category is agents' {
        $script:Manifest.category | Should -Be 'agents'
    }

    It 'profile is claw3d' {
        $script:Manifest.profile | Should -Be 'claw3d'
    }

    It 'dashboard port is 3006' {
        [int]$script:Manifest.dashboard.port | Should -Be 3006
    }

    It 'script path points to component subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/claw3d/claw3d.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'claw3d port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 3006 is registered in portmap.json' {
        $script:Portmap.ports.'3006' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'3006'.service | Should -Be 'claw3d'
    }
}

# ── CLI flags ────────────────────────────────────────────────────────────────

Describe 'claw3d CLI flags' {

    BeforeAll {
        $script:ScriptContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'supports --install flag' {
        $script:ScriptContent | Should -Match '--install'
    }

    It 'supports --configure flag' {
        $script:ScriptContent | Should -Match '--configure'
    }

    It 'supports --start flag' {
        $script:ScriptContent | Should -Match '--start'
    }

    It 'supports --stop flag' {
        $script:ScriptContent | Should -Match '--stop'
    }

    It 'supports --restart flag' {
        $script:ScriptContent | Should -Match '--restart'
    }

    It 'supports --health flag' {
        $script:ScriptContent | Should -Match '--health'
    }

    It 'supports --status flag' {
        $script:ScriptContent | Should -Match '--status'
    }

    It 'supports --destroy flag' {
        $script:ScriptContent | Should -Match '--destroy'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'claw3d compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'claw3d service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'claw3d:'
    }

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/claw3d/Dockerfile' | Should -Exist
    }

    It 'compose sets STUDIO_ACCESS_TOKEN' {
        $script:ComposeContent | Should -Match 'STUDIO_ACCESS_TOKEN'
    }
}

# ── Claw3d cookieAuth in services.json ───────────────────────────────────────

Describe 'claw3d cookieAuth in services.json' {

    BeforeAll {
        $script:Services = Get-Content -Path (
            Join-Path $script:RepoRoot 'resources/dashboard/services.json') -Raw | ConvertFrom-Json
    }

    It 'claw3d entry has cookieAuth field' {
        $found = $false
        foreach ($section in $script:Services) {
            foreach ($svc in $section.items) {
                if ($svc.service -eq 'claw3d' -and $svc.cookieAuth) {
                    $found = $true
                }
            }
        }
        $found | Should -Be $true -Because 'claw3d needs cookieAuth for dashboard proxy'
    }
}
