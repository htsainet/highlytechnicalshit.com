#!/usr/bin/env bash
# scripts/htsclaw/dashboard/origins.sh — Patch controlUi.allowedOrigins
#
# Updates openclaw.json inside the sandbox so the Control UI accepts
# connections from localhost on the htsclaw port. Without this, the
# dashboard gets CORS errors when embedding the OpenClaw iframe.
# Ported from NemoClaw's _fix_sandbox_origins().
#
# Can be sourced or run standalone.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
HTSCLAW_SANDBOX_NAME="${HTSCLAW_SANDBOX_NAME:-hts-ai-openshell-htsclaw-gpu}"
HTSCLAW_PORT="${HTSCLAW_PORT:-18792}"
HTSCLAW_GATEWAY_NAME="htsclaw"
HTSCLAW_CLUSTER_CONTAINER="openshell-cluster-${HTSCLAW_GATEWAY_NAME}"

# ── Internal helpers (root exec) ─────────────────────────────────────────────

# _htsclaw_root_exec — Execute as root (uid 0) inside the sandbox.
# openclaw.json is root-owned; we need containerd exec to modify it.
_htsclaw_root_exec() {
  local sandbox="$1" exec_prefix="$2"; shift 2

  if ! docker inspect "$HTSCLAW_CLUSTER_CONTAINER" &>/dev/null; then
    warn "Cluster container '${HTSCLAW_CLUSTER_CONTAINER}' not found."
    return 1
  fi

  local ctr_id
  ctr_id=$(docker exec "$HTSCLAW_CLUSTER_CONTAINER" \
    /bin/sh -c "ctr -n k8s.io tasks list 2>/dev/null | awk '{print \$1}'" \
    | while read -r id; do
        local hn
        hn=$(docker exec "$HTSCLAW_CLUSTER_CONTAINER" \
          ctr -n k8s.io tasks exec --exec-id "hn-${id:0:8}" --user 0 "$id" \
          hostname 2>/dev/null) || continue
        if [[ "$hn" == "$sandbox" ]]; then echo "$id"; break; fi
      done)

  if [[ -z "${ctr_id:-}" ]]; then
    warn "Could not find containerd task for '${sandbox}'."
    return 1
  fi

  docker exec "$HTSCLAW_CLUSTER_CONTAINER" \
    ctr -n k8s.io tasks exec \
      --exec-id "${exec_prefix}-${sandbox:0:8}" --user 0 "$ctr_id" \
      "$@"
}

# _htsclaw_restart_gateway — Kill the gateway so PID 1 restarts it with new config
_htsclaw_restart_gateway() {
  local sandbox="$1"
  _htsclaw_root_exec "$sandbox" "gw" \
    /bin/sh -c "kill \$(cat /tmp/openclaw-gateway.pid 2>/dev/null) 2>/dev/null || pkill -f 'openclaw.*gateway' 2>/dev/null || true" \
    2>/dev/null || true
  sleep 3
}

# ── Origins patching ─────────────────────────────────────────────────────────

# htsclaw_fix_origins — Patch controlUi.allowedOrigins in openclaw.json
htsclaw_fix_origins() {
  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not found — skipping origins fix."
    return 0
  fi

  step "htsclaw — fix allowedOrigins"

  local sandbox="$HTSCLAW_SANDBOX_NAME"
  local port="$HTSCLAW_PORT"

  if ! openshell sandbox get "$sandbox" &>/dev/null 2>&1; then
    warn "Sandbox '${sandbox}' not found — skipping origins fix."
    return 0
  fi

  info "Fixing allowedOrigins for '${sandbox}' → :${port}..."

  local fix_script
  fix_script="import json,pathlib;p=pathlib.Path('/sandbox/.openclaw/openclaw.json');d=json.loads(p.read_text());d.setdefault('gateway',{}).setdefault('controlUi',{})['allowedOrigins']=['http://127.0.0.1:${port}','http://localhost:${port}'];p.write_text(json.dumps(d,indent=2));print('OK')"

  local result
  result=$(_htsclaw_root_exec "$sandbox" "fix" python3 -c "$fix_script" 2>&1) || {
    warn "Failed to fix allowedOrigins for '${sandbox}': ${result}"
    return 1
  }

  _htsclaw_restart_gateway "$sandbox"
  ok "allowedOrigins patched for '${sandbox}' (:${port})."
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  htsclaw_fix_origins
fi
