# FEATURE-056 — L3 Microsegmentation (Per-Service Spoke Networks)

| Field | Value |
|-------|-------|
| Status | Proposed (Future) |
| Category | Security / Networking |
| Target Release | v0.6.0+ (after FEATURE-055 lands + operational data collected) |
| Priority | MEDIUM |
| Effort | XL (touches every manifest, new generator, extensive testing) |
| Components | All (manifest extension); new helper generator |
| Dependencies | **FEATURE-055 (Authelia SSO + Traefik)** must ship first |
| Related | SECURITY-000 (UFW), SECURITY-001 (Tailscale ACL) |

## Summary

Layer Docker-native **zero-trust network microsegmentation** on top of
the Authelia + Traefik SSO foundation from FEATURE-055.

Each service gets its own "spoke" network(s):
- One leg on `traefik_proxy` for public ingress (if it has a UI).
- Additional pair-wise / small-cluster networks ONLY for services that
  genuinely need to talk to each other at L3 (e.g., `grafana ↔ prometheus`,
  `open-webui ↔ ollama`, `n8n ↔ postgres-n8n`).

Result: if any single container is compromised, the attacker's lateral
movement is limited to the explicit dependency graph — not "every other
container on the box".

```
[traefik_proxy]  ← shared ingress hub (all UI-exposing services)

[grafana]  ←→ [prometheus]          ← private pair net
[open-webui]  ←→ [ollama]           ← private pair net
[n8n]  ←→ [postgres-n8n]            ← private pair net
[gitea]  ←→ [gitea-db]  ←→ [gitea-runner]  ← private triangle net
```

## Why v2 (not v1)

Deferred to a later release because:

1. FEATURE-055 delivers the big security win (2FA + SSO) fastest without
   this complexity.
2. v1 validates the manifest-generator pattern (Traefik labels, Authelia
   ACL). v2 reuses that exact generator pipeline for network dependencies.
3. Real operational data from v1 tells us which services actually talk
   to which — guessing the dependency graph up front = wrong half the time.
4. Scope is large: ~60 manifests to annotate, new generator, new tests,
   new debugging docs.

## Security model

| Layer | Control | Provided by |
|---|---|---|
| L7 (application) | Who can call what URL | Authelia (FEATURE-055) |
| L4 (transport) | TLS + session cookies | Traefik (FEATURE-055) |
| **L3 (network)** | **Who can even *reach* what at IP level** | **This feature** |
| Host firewall | Inbound port allowlist | SECURITY-000 (UFW) |

Together = true defense-in-depth. Bypass Authelia → still hit a network wall.

## Manifest extension

Extend the `auth` block (or introduce sibling `network` block):

```json
"network": {
  "ingress": true,
  "needs": ["prometheus", "loki"],
  "serves": [],
  "isolation": "strict"
}
```

- `ingress`: true → join `traefik_proxy` network
- `needs`: list of component IDs this service initiates connections to
- `serves`: reverse index (who depends on me) — optional, for clarity
- `isolation`: `strict` (only declared deps) | `relaxed` (share a tier net)

Generator walks the graph, deduplicates edges, emits
`docker-compose.override.networks.yml` with exactly the networks needed
and assigns each service to its proper set.

## Phases

### Phase 1 — Dependency modelling
- Define `network` schema (additions to manifest JSON schema)
- Walk every component, populate `needs` from real observation
  (read `depends_on` in docker-compose, scan configs for hostnames,
  interview the existing stack)

### Phase 2 — Generator
- `scripts/wizard/generate-network-topology.sh`
  - Reads manifests
  - Builds dependency graph
  - Deduplicates pair networks (grafana→prom and prom→grafana = one net)
  - Emits `docker-compose.override.networks.yml`
  - Emits a Graphviz `.dot` rendering for review

### Phase 3 — Rollout flag
- New stack setting `network.microsegmentation = off | tier | strict`
  - `off`: one shared `traefik_proxy` network (FEATURE-055 default)
  - `tier`: frontend / admin / api / data tier networks (5ish networks)
  - `strict`: full per-dependency spoke networks (this feature)
- Gives users a migration ramp and easy rollback.

### Phase 4 — Diagnostics
- `scripts/diag/network-topology.sh` → prints graph, checks for orphans,
  verifies each service can reach its declared deps.
- Update troubleshooting docs: "why can't X reach Y" runbook (almost
  always = missing `needs` entry in manifest).

### Phase 5 — Tests & docs
- `tests/network/test-isolation.sh` — for each service, verify it
  CAN reach declared deps and CANNOT reach undeclared ones.
- `docs/network-architecture.md` — topology, philosophy, debugging.
- Rendered dependency graph committed to repo (auto-regenerated on change).

## Downsides to design around

| Cost | Mitigation |
|---|---|
| ~100+ Docker networks at `strict` setting | Startup time +15–30s; acceptable. |
| iptables rule explosion | Monitor `iptables -L -n | wc -l`; document. |
| DNS resolution gotcha (services only resolve neighbors on shared nets) | Dedicated diag script + error messages that suggest the fix. |
| Refactor churn when adding deps | Generator-driven, single-line manifest edit. |
| Compose complexity | Never hand-edit generated file; manifests are source of truth. |

## Open questions

- Should networks be `internal: true` by default (no outbound internet)?
  Probably yes for pair networks; no for the ingress hub.
- How do we handle services that need egress to the public internet
  (web scrapers, update checkers)? → Separate `egress` network flag.
- Do we expose a `kubernetes NetworkPolicy` equivalent for future K8s
  migration, or stay Docker-compose-only? → TBD.

## Acceptance criteria (v2)

- [ ] `network.microsegmentation=off` behaves identically to FEATURE-055 baseline.
- [ ] `network.microsegmentation=strict` produces per-dependency spoke networks
      with every service having at most: ingress + its declared deps.
- [ ] All 60+ components have a validated `network` block.
- [ ] Isolation tests prove each service cannot reach undeclared services.
- [ ] Debug/diagnostic tooling lets an operator answer "why can't A reach B"
      without reading the generator script.
- [ ] Rendered dependency graph is part of the repo and auto-updates on
      manifest changes.
