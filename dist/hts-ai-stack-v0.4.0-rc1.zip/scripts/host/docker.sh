#!/usr/bin/env bash
# scripts/host/docker.sh — Docker Engine, Compose plugin, and group setup
# Independently runnable. Idempotent — skips already-installed components.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/manifest.sh"

# ── Helper: Docker group awareness ───────────────────────────────────────────
session_has_docker_group()          { id -nG | grep -qw docker; }
user_configured_for_docker_group()  { id -nG "$USER" | grep -qw docker; }
run_docker() {
  if session_has_docker_group; then
    docker "$@"
    return
  fi
  local cmd=()
  for arg in docker "$@"; do
    cmd+=("$(printf '%q' "$arg")")
  done
  sg docker -c "${cmd[*]}"
}

step "Docker group"

if getent group docker >/dev/null 2>&1; then
  info "docker group already exists."
else
  info "Creating docker group..."
  sudo groupadd docker
fi

if user_configured_for_docker_group; then
  info "docker group membership OK for $USER."
else
  info "Adding $USER to docker group..."
  sudo usermod -aG docker "$USER"
fi

if session_has_docker_group; then
  info "Current shell already has docker group access."
else
  warn "Current shell has not picked up docker group membership yet."
  warn "Using 'sg docker' for Docker commands in this run; future shells will work after logout/login."
fi

step "Docker Engine"

if docker --version &>/dev/null; then
  info "Docker already installed ($(docker --version | awk '{print $3}' | tr -d ','))"
else
  info "Installing Docker prerequisites..."
  sudo apt update
  sudo apt install -y ca-certificates curl gnupg

  sudo install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
    sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  sudo chmod a+r /etc/apt/keyrings/docker.gpg

  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
    https://download.docker.com/linux/ubuntu \
    $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
    sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

  sudo apt update
  sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

step "Docker validation"

if docker --version &>/dev/null; then
  ok "Docker: $(docker --version)"
  ok "Compose: $(run_docker compose version)"
  manifest_add "docker-ce" "apt" "$(docker --version | awk '{print $3}' | tr -d ',')"
  manifest_add "docker-compose-plugin" "apt" "$(run_docker compose version 2>&1 | awk '{print $NF}')"
else
  warn "Docker not found — check the installation steps above."
fi

info "Docker setup complete."
