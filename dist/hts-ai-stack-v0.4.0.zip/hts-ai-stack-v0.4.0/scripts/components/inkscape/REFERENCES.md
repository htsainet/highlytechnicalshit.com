# Inkscape — References

## Upstream

- **Homepage**: <https://inkscape.org/>
- **Source**: <https://gitlab.com/inkscape/inkscape>
- **Snap package**: <https://snapcraft.io/inkscape>
- **Documentation**: <https://inkscape-manuals.readthedocs.io/>

## Notes

- GPLv2+ license
- SVG 1.1 compliant with extensions
- Supports batch processing via command line
