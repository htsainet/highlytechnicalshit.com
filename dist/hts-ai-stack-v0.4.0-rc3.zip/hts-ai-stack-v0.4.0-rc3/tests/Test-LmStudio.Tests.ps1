$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/lmstudio'
    $script:ComponentScript = Join-Path $script:ComponentDir 'lmstudio.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'lmstudio.manifest.json'
    $script:ToolingScript = Join-Path $script:RepoRoot 'scripts/install/tooling/install-lmstudio.sh'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'lmstudio file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists (TDD — needs creation)' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }

    It 'tooling installer script exists' {
        $script:ToolingScript | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'lmstudio manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is lmstudio' {
        $script:Manifest.id | Should -Be 'lmstudio'
    }

    It 'install_type is host-interactive' {
        $script:Manifest.install_type | Should -Be 'host-interactive'
    }

    It 'dashboard port is 1234' {
        [int]$script:Manifest.dashboard.port | Should -Be 1234
    }

    It 'script path should point to component subfolder (TDD)' {
        $script:Manifest.script | Should -Be 'scripts/components/lmstudio/lmstudio.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'lmstudio port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 1234 is registered in portmap.json' {
        $script:Portmap.ports.'1234' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'1234'.service | Should -Be 'lmstudio'
    }
}
