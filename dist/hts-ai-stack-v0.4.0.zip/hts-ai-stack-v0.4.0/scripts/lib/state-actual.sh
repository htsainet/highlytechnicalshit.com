#!/usr/bin/env bash
# scripts/lib/state-actual.sh — Probe runtime state of components
# Source this file; do NOT run directly.
#
# Determines the actual running state of each component by probing
# Docker containers, systemd services, and health endpoints.
#
# Used by: converge.sh (FEATURE-009)
# Requires: common.sh, component-registry.sh sourced first

# ── Actual state array ────────────────────────────────────────────────────────
# Populated by actual_state_load()
# Keys: component IDs from COMPONENT_ORDER
# Values: "running" | "stopped" | "missing" | "degraded"
declare -gA ACTUAL

# ── Container name mapping ────────────────────────────────────────────────────
# Container names follow the convention: hts-ai-<component-id>
# This matches the container_name: values set in docker-compose.yml.
# No hardcoded map needed — component ID == service name for all current
# components. If a component ever needs an override, add a manifest field.


# COMPONENT_HEALTH_URL and COMPONENT_HEALTH_TIMEOUT are now defined in
# each component's .manifest.json and loaded by manifest-loader.sh via
# component-registry.sh. They are available as global associative arrays
# before this file is sourced — no local declaration needed here.

# ── Actual state loader ───────────────────────────────────────────────────────

# actual_state_load
# Probes each component and populates the ACTUAL array.
actual_state_load() {
  local component
  for component in "${COMPONENT_ORDER[@]}"; do
    ACTUAL[$component]=$(_probe_component "$component")
  done
}

# _probe_component <component_id>
# Returns the runtime state of a single component.
_probe_component() {
  local component="$1"
  
  case "$component" in
    # Special cases: non-Docker components
    nemoclaw)
      _probe_nemoclaw
      ;;
    tailscale)
      _probe_tailscale
      ;;
    lmstudio)
      _probe_lmstudio
      ;;
    # Docker-based components
    *)
      _probe_docker_component "$component"
      ;;
  esac
}

# _probe_docker_component <component_id>
# Probes a Docker container-based component.
# Uses Docker's built-in healthcheck status as primary signal — avoids
# false positives from probing SSE endpoints or wrong URLs directly.
_probe_docker_component() {
  local component="$1"
  local health_url="${COMPONENT_HEALTH_URL[$component]:-}"

  # All compose services use explicit container_name: hts-ai-<component-id>.
  # Component IDs match Compose service names for all current components.
  local container="hts-ai-${component}"
  if ! docker inspect "$container" &>/dev/null 2>&1; then
    echo "missing"
    return
  fi

  # Check if container exists and is running
  local state
  state=$(docker inspect --format='{{.State.Status}}' "$container" 2>/dev/null || echo "missing")

  case "$state" in
    running)
      # Prefer Docker's own healthcheck status (avoids URL probe false positives)
      local health
      health=$(docker inspect --format='{{.State.Health.Status}}' "$container" 2>/dev/null || echo "")
      case "$health" in
        healthy)   echo "running" ;;
        unhealthy) echo "degraded" ;;
        starting)
          # Container is running — healthcheck hasn't fired yet (normal after boot).
          # Treat as running; the post-install health check will catch real failures.
          echo "running"
          ;;
        *)
          # No Docker healthcheck defined — fall back to URL probe.
          # Use the manifest-defined probe_timeout (default 5s if unset).
          if [[ -n "$health_url" ]]; then
            local probe_timeout="${COMPONENT_HEALTH_PROBE_TIMEOUT[$component]:-5}"
            if _http_probe "$health_url" "$probe_timeout"; then
              echo "running"
            else
              echo "degraded"
            fi
          else
            echo "running"
          fi
          ;;
      esac
      ;;
    exited|created|paused|dead)
      echo "stopped"
      ;;
    *)
      echo "missing"
      ;;
  esac
}

# _http_probe <url> [timeout]
# Returns 0 if URL returns HTTP 2xx, 1 otherwise.
_http_probe() {
  local url="$1"
  local timeout="${2:-3}"
  curl -sf --max-time "$timeout" "$url" >/dev/null 2>&1
}

# ── Non-Docker component probes ───────────────────────────────────────────────

# _probe_nemoclaw
# NemoClaw runs inside an OpenShell sandbox — check via openshell CLI.
_probe_nemoclaw() {
  local sandbox_name="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"
  local port="${NEMOCLAW_PORT:-18789}"

  if command -v openshell &>/dev/null; then
    if openshell sandbox get "$sandbox_name" -g nemoclaw &>/dev/null 2>&1; then
      if _http_probe "http://localhost:${port}/healthz"; then
        echo "running"
      else
        echo "degraded"
      fi
    elif docker ps --format '{{.Names}}' 2>/dev/null | grep -q "openshell-cluster-hts-ai-openshell-nemoclaw"; then
      echo "degraded"  # gateway up but sandbox missing
    else
      echo "missing"
    fi
    return
  fi

  if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "openshell-cluster-hts-ai-openshell-nemoclaw"; then
    if _http_probe "http://localhost:${port}/healthz"; then
      echo "running"
    else
      echo "degraded"
    fi
  elif docker ps -a --format '{{.Names}}' 2>/dev/null | grep -q "openshell-cluster-hts-ai-openshell-nemoclaw"; then
    echo "stopped"
  else
    echo "missing"
  fi
}

# _probe_tailscale
# Tailscale is a host service, not a Docker container.
_probe_tailscale() {
  # Check if tailscale CLI is available
  if ! command -v tailscale &>/dev/null; then
    echo "missing"
    return
  fi
  
  # Check connection status
  local status
  status=$(tailscale status 2>&1 || echo "")
  
  if echo "$status" | grep -qE "^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"; then
    echo "running"
  elif systemctl is-active --quiet tailscaled 2>/dev/null; then
    echo "stopped"
  else
    echo "missing"
  fi
}

# _probe_lmstudio
# LM Studio is a host application (AppImage or .deb).
_probe_lmstudio() {
  # Check if lmstudio is installed
  if command -v lmstudio &>/dev/null || dpkg -s lmstudio &>/dev/null 2>&1; then
    # Check if the LM Studio server is responding
    local port="${LMSTUDIO_PORT:-1234}"
    if _http_probe "http://localhost:${port}/v1/models"; then
      echo "running"
    else
      echo "stopped"
    fi
  else
    echo "missing"
  fi
}

# ── Debug output ──────────────────────────────────────────────────────────────

# actual_state_dump
# Prints the current ACTUAL state for debugging.
actual_state_dump() {
  local component
  echo "Actual state:"
  for component in "${COMPONENT_ORDER[@]}"; do
    printf "  %-20s %s\n" "$component" "${ACTUAL[$component]:-unknown}"
  done
}

# actual_state_running_list
# Prints components that are currently running.
actual_state_running_list() {
  local component
  for component in "${COMPONENT_ORDER[@]}"; do
    if [[ "${ACTUAL[$component]:-}" == "running" ]]; then
      echo "$component"
    fi
  done
}

# actual_state_stopped_list
# Prints components that are stopped or missing.
actual_state_stopped_list() {
  local component
  for component in "${COMPONENT_ORDER[@]}"; do
    local state="${ACTUAL[$component]:-missing}"
    if [[ "$state" == "stopped" || "$state" == "missing" ]]; then
      echo "$component"
    fi
  done
}
