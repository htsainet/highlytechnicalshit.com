# Setup Issues

Use this file to capture problems that need follow-up while you work through the setup.
This is for actionable defects, missing steps, confusing docs, broken assumptions, and cleanup items.

---

## Issue Template

### ISSUE-000

- Date:
- Area:
- Symptom:
- Reproduction:
- Suspected cause:
- Workaround:
- Fix needed:
- Status: open

---

## Open Issues

### FEATURE-ADD-003

- Date: 2026-03-29
- Area: install
- Symptom:
- Reproduction:
- Suspected cause:
- Workaround:
- Fix needed: add logging
- Status: open

---

### FEATURE-ADD-002

- Date: 2026-03-28
- Area: missing feature
- Symptom: no nim container
- Reproduction: try to run nim
- Suspected cause: not configured
- Workaround: nothing yet
- Fix needed: get nvidia developers key (prompt during setup for nim?)
- Status: open

Steps to Get an NVIDIA API Key

    Visit the NVIDIA API Catalog: Go to build.nvidia.com.
    Select a Model: Choose any AI model you wish to use (e.g., Llama 3, Mixtral).
    Click "Get API Key": Click on the "Get API Key" button in the right-hand pane.
    Sign In/Register: If you don't have an account, you will be prompted to create one, which automatically signs you up for the NVIDIA Developer Program.
    Generate Key: Once signed in, click "Generate API Key".
    Save Key: Copy and securely store your key immediately. It will only be shown once. 

Alternative Method (NGC Registry)
If you need an API key for Docker access or older NVIDIA GPU Cloud (NGC) services:

    Go to ngc.nvidia.com and log in.
    Click on your profile icon in the top right and select Setup.
    Click Generate API Key. 

Important Notes

    Cost: Access to NIM microservices via the NVIDIA API Catalog is free for research, development, and testing.
    Key Security: Do not share your API key, as it provides access to your account's resources. If lost, you must generate a new one, which invalidates the old one.
    Usage: To use the key in your code, set it as an environment variable: export NVIDIA_API_KEY=<your API key>.

### ISSUE-001

- Date: 2026-03-26
- Area: NemoClaw onboarding
- Symptom: Onboard flow appears oriented around local Ollama or hosted NVIDIA API usage, not a custom local NIM endpoint
- Reproduction: Review `04-setup-nemoclaw.sh` prompt guidance and current stack assumptions
- Suspected cause: NemoClaw onboarding likely hardcodes inference backend choices
- Workaround: Use `local-ollama` during onboard and run NIM separately for direct testing
- Fix needed: Verify whether NemoClaw can target a custom OpenAI-compatible local endpoint after onboarding
- Status: partially fixed — NemoClaw supports "Other OpenAI-compatible endpoint" during onboard; docs and script updated to reflect this. Post-onboard inference reconfiguration not supported by CLI.

---

## Closed Issues

### ISSUE-003

- Date: 2026-03-26
- Area: Onboarding
- Symptom: Cannot run new shell scripts
- Reproduction:
- Suspected cause: were not marked as executable before git commit
- Workaround:
- Fix needed: chmod +x *.sh
- Status: Fixed - execute permissions added and committed to repo

### ISSUE-004

- Date: 2026-03-26
- Area: QOL
- Symptom: No Remote Desktop Client
- Reproduction:
- Suspected cause: missing package
- Workaround: Install Remmina from App Store
- Fix need-ed: Determine if we can make this part of bootstrap
- Status: Fixed — remmina added to 01-autoinstall.sh step 0

### ISSUE-005

- Date: 2026-03-26
- Area: QOL
- Symptom: No WireGuard Client
- Reproduction:
- Suspected cause: missing package
- Workaround: sudo apt install wireguard
- Fix needed: Determine if we can make this part of bootstrap
- Status: Fixed — wireguard added to 01-autoinstall.sh step 0

### ISSUE-006

- Date: 2026-03-26
- Area: Dashboard
- Symptom: `http://127.0.0.1` returns `403 Forbidden` from nginx
- Reproduction: Start stack and open dashboard on port 80
- Suspected cause: dashboard container had a stale bind mount to an empty host directory (`./dashboard`) instead of `./resources/dashboard`
- Workaround: Recreate the dashboard service
- Fix needed: Ensure dashboard container is recreated when compose bind path changes
- Status: Fixed — recreated `dashboard` with `docker compose up -d --force-recreate dashboard`, mount now points to `resources/dashboard`, and root URL returns 200

### ISSUE-007

- Date: 2026-03-28
- Area: nemoclaw setup
- Symptom: onboarding screen missing a step
- Reproduction: run 04-setup-nemoclaw.sh
- Suspected cause: simple text edit to policy section
- Workaround: ignore the prompts in 04-setup-nemoclaw.sh
- Fix needed: docker,npm,pypi,telegram,huggingface
- Status: fixed manually

### ISSUE-008

- Date: 2026-03-28
- Area: 02-setup-docker
- Symptom: no containers spin up
- Reproduction: docker compose up from root
- Suspected cause: missing variable
- Workaround: manual export WEBUI_SECRET_KEY from .env
- Fix: 06-start-stack.sh now sources .env before docker compose calls; for
  manual runs use: source .env && docker compose … (root) or
  docker compose --env-file ../../.env up (instances/prod)
- Status: fixed 2026-03-29

### ISSUE-009

- Date: 2026-03-28
- Area: prod docker instances
- Symptom: script aborts mid run
- Reproduction: /instances/prod$ docker compose up
- Suspected cause: missing variable
- Workaround: manual export WEBUI_SECRET_KEY from .env
- Fix: 06-start-stack.sh now sources .env before docker compose calls; for
  manual runs use: docker compose --env-file ../../.env up
- Status: fixed 2026-03-29

### ISSUE-016

- Date: 2026-03-28
- Area: ollama test instance
- Symptom: external volume "ollama_test" not found
- Reproduction: model setup script
- Suspected cause: volumes were declared with `external: true` but had never been pre-created
- Workaround: remove external tag from all volumes; /instance/test/docker compose up
- Fix: removed `external: true` from all volume declarations in `instances/test/docker-compose.yml`;
  volumes are now compose-managed and created automatically on first `up`
- Status: fixed 2026-03-29

### ISSUE-002

- Date: 2026-03-26
- Area: Onboarding
- Symptom: Need to manually run 00, 01, 02 several times to finish
- Reproduction:
- Suspected cause: ntp service hangs, nvidia needs reboot, probably more
- Workaround:
- Fix needed: Determine if we can split these scripts into smaller pieces or make them more intelligent
- Status: fixed syntax issues, service name, invoke sudo as needed

### ISSUE-010

- Date: 2026-03-27
- Area: bootstrap
- Symptom: no SSH server
- Reproduction:
- Suspected cause: not installed
- Workaround: sudo apt install openssh-server && sudo systemctl status ssh
- Fix: added `openssh-server` to Step 1 apt install in `00-bootstrap.sh`;
  `systemctl enable --now ssh` runs immediately after install
- Status: fixed 2026-03-29

### ISSUE-015

- Date: 2026-03-28
- Area: bootstrap
- Symptom: curl not found
- Reproduction: try to run 00-bootstrap.sh on bare ubuntu
- Suspected cause: curl not present on minimal Ubuntu install
- Workaround: sudo apt install curl
- Fix: added pre-flight block at top of `00-bootstrap.sh` that installs curl
  via apt if not already present, before any other step runs
- Status: fixed 2026-03-29

### ISSUE-013

- Date: 2026-03-28
- Area: docker prod instances
- Symptom: external volume "sd_outputs_prod" not found
- Reproduction: /instances/prod$ docker compose up
- Suspected cause: volumes declared with `external: true` but never pre-created
- Workaround: skip stable diffusion for now
- Fix: removed `external: true` from all volume declarations in `instances/prod/docker-compose.yml`;
  volumes are now compose-managed and created automatically on first `up`
- Status: fixed 2026-03-29

### ISSUE-014

- Date: 2026-03-28
- Area: bootstrap
- Symptom: browser launches during setup but it doesn't retain token properly
- Reproduction: try to run 00-bootstrap.sh on bare ubuntu
- Suspected cause: logic flow / UX confusion between github.com login and gh CLI OAuth flow
- Workaround: manual auth
- Fix: Step 3 Firefox launch is now gated on `gh auth status`; pre-run checklist
  (ISSUE-017) tells the user upfront that Step 4 requires a browser OAuth sign-in;
  Step 4 `gh auth login --web` skipped if already authenticated
- Status: fixed 2026-03-29

### ISSUE-017

- Date: 2026-03-29
- Area: bootstrap
- Symptom: poor UX on re-runs; no visual branding
- Reproduction: try to run 00-bootstrap.sh
- Suspected cause: missing communication; no idempotency guards
- Workaround:
- Fix: added HTS AI ASCII art banner; pre-run checklist showing [x]/[ ] status
  for each of the 8 steps; Firefox login launch now skipped if GitHub is already
  authenticated (idempotency guard for Step 3)
- Status: fixed 2026-03-29

### ISSUE-012

- Date: 2026-03-28
- Area: 03-setup-models
- Symptom: "network ubuntu-ai-stack_ai-network declared as external, but could not be found"
- Reproduction: run 03-setup-models.sh
- Suspected cause: network created by root compose but instance compose files use
  `external: true` — network absent if root stack never ran
- Workaround: don't pull test models until fixed
- Fix: added `ensure_ai_network` helper in `setup/models/helpers.sh`; called
  at startup of both `prod.sh` and `test.sh` — creates `ubuntu-ai-stack_ai-network`
  if it doesn't exist before any `docker compose up`
- Status: fixed 2026-03-29
