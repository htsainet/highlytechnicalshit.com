// resources/htsclaw/dns-hook.js — DNS resolution hook for OpenClaw sandbox
//
// OpenClaw's SSRF guard (STRICT mode) requires DNS resolution before allowing
// requests. Inside the OpenShell sandbox, `inference.local` is only reachable
// through the privacy router proxy — it has no DNS entry. This hook makes
// `inference.local` resolvable so the SSRF guard passes, while the actual
// connection still routes through the env proxy to the privacy router.
//
// Usage: NODE_OPTIONS="--require /sandbox/dns-hook.js" openclaw gateway run ...
//
// The resolved IP (proxy gateway 10.200.0.1) is used only to satisfy the SSRF
// guard's DNS pinning. The EnvHttpProxyAgent sends the request through the
// HTTPS_PROXY tunnel, which routes to the privacy router by hostname.

'use strict';

const INFERENCE_HOST = 'inference.local';
const INFERENCE_IP = '10.200.0.1';

const dns = require('dns');
const origLookup = dns.lookup;

dns.lookup = function patchedLookup(hostname, options, callback) {
  if (typeof options === 'function') {
    callback = options;
    options = {};
  }

  if (hostname.toLowerCase() === INFERENCE_HOST) {
    const result = { address: INFERENCE_IP, family: 4 };
    if (options && options.all) {
      callback(null, [result]);
    } else {
      callback(null, result.address, result.family);
    }
    return;
  }

  return origLookup.call(dns, hostname, options, callback);
};

const dnsPromises = require('dns/promises');
const origLookupPromises = dnsPromises.lookup;

dnsPromises.lookup = async function patchedLookupPromises(hostname, options) {
  if (hostname.toLowerCase() === INFERENCE_HOST) {
    const result = { address: INFERENCE_IP, family: 4 };
    if (options && options.all) {
      return [result];
    }
    return result;
  }

  return origLookupPromises.call(dnsPromises, hostname, options);
};
