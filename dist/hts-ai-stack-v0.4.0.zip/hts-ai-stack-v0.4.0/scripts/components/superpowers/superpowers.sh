#!/usr/bin/env bash
# Superpowers – host tool for agentic skills & workflow methodology
# Provides install, configure, health, and destroy lifecycle functions.
# No long‑running service – users invoke the CLI directly (e.g. `superpowers` script from repo or via npx).

set -euo pipefail

# Resolve repo root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# Load shared helpers
# shellcheck source=scripts/lib/common.sh
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=scripts/lib/health.sh
source "$REPO_DIR/scripts/lib/health.sh"

# ── Lifecycle functions ──

superpowers_install() {
  info "Installing Superpowers …"
  if command -v superpowers &>/dev/null; then
    ok "Superpowers already installed (found in PATH)"
    return 0
  fi

  if command -v npm &>/dev/null; then
    npm install -g superpowers || true
  else
    warn "npm not available – fallback to npx (no permanent install)"
    ok "Superpowers will be invoked via npx"
    return 0
  fi

  if command -v superpowers &>/dev/null; then
    ok "Superpowers installed successfully"
  else
    warn "Superpowers binary not found after install"
    return 1
  fi
}

superpowers_configure() {
  info "Superpowers requires no configuration"
}

superpowers_start() {
  info "Superpowers is a CLI tool – run it directly, e.g. 'superpowers' or 'npx superpowers@latest'"
}

superpowers_stop() { :; }

superpowers_restart() { superpowers_stop && superpowers_start; }

superpowers_health() {
  if command -v superpowers &>/dev/null; then
    ok "Superpowers binary found: $(command -v superpowers)"
    return 0
  else
    warn "Superpowers not found in PATH"
    return 1
  fi
}

superpowers_destroy() {
  info "Removing Superpowers …"
  if command -v npm &>/dev/null; then
    npm uninstall -g superpowers || true
  fi
  ok "Superpowers removal complete (if installed via npm)"
}

superpowers_status() {
  if command -v superpowers &>/dev/null; then
    echo "installed"
  else
    echo "not_installed"
  fi
}

# ── Standalone execution handling ──
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)    ACTION="install"; shift ;;
      --configure)  ACTION="configure"; shift ;;
      --start)      ACTION="start"; shift ;;
      --stop)       ACTION="stop"; shift ;;
      --restart)    ACTION="restart"; shift ;;
      --health)     ACTION="health"; shift ;;
      --destroy)    ACTION="destroy"; shift ;;
      --status)     ACTION="status"; shift ;;
      *) shift ;;
    esac
  done
  case "$ACTION" in
    install)   superpowers_install   ;;
    configure) superpowers_configure ;;
    start)     superpowers_start     ;;
    stop)      superpowers_stop      ;;
    restart)   superpowers_restart   ;;
    health)    superpowers_health    ;;
    status)    superpowers_status    ;;
    destroy)   superpowers_destroy   ;;
    default)
      superpowers_install
      superpowers_configure
      superpowers_start
      superpowers_health
      ;;
  esac
fi
