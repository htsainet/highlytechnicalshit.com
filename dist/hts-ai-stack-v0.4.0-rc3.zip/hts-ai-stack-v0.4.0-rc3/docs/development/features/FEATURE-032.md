# Agnai — Multi-User AI Roleplay Chat

**Priority:** LOW
**Effort:** 2–3 hours
**Risk:** Medium — AGPLv3 license; MongoDB optional but needed for multi-user persistence.
**Target Release:** v0.6.0
**Depends on:** KoboldCpp (FEATURE-031) for RP inference backend
**Blocks:** Nothing

> **Evaluation context:** Tracked alongside SillyTavern (FEATURE-005) as an alternative
> RP/creative chat frontend. Both wire to KoboldCpp. Evaluate both before committing to one.
> See [Comparison](#comparison-with-sillytavern-feature-005) section below.

## License Note

> **⚠️ AGPLv3 License**
>
> `agnaistic/agnai` is licensed under **AGPLv3**. As a network-accessible web app, AGPL
> requires the source of the running service be made available to users who interact
> with it over the network.
>
> Unmodified self-hosted private use is acceptable. Flag before any public or multi-tenant
> deployment.

## Problem

The stack has SillyTavern planned (FEATURE-005) as the RP/creative frontend, but no
evaluation has been done against alternatives. Agnai is the primary open-source competitor:
multi-user capable, native KoboldCpp support, built-in lore/memory books, persona schemas,
and a Docker image that runs without MongoDB in guest-mode (localStorage persistence).

## Current State

Not in the stack. No FEATURE file. Added to `docs/planning/feature-repos/REFERENCES.md`
during this session.

## Architecture

Guest mode (no database, single-user, localStorage persistence):

```text
  Browser → Agnai :3003
               │
           KoboldCpp :5001  (FEATURE-031)
           llama-swap :8081  (OpenAI-compat fallback)
```

Full multi-user mode (adds MongoDB + Redis):

```text
  Browser (multiple users) → Agnai :3003
               │
           MongoDB :27017  (user accounts, chats, personas)
           Redis :6379      (websocket pub/sub)
               │
           KoboldCpp :5001
```

## Implementation Steps

### P0 — Guest mode service (no database)

- [ ] **1. Docker compose service**
  Add `agnai` service under `profiles: [agnai]`.

  ```yaml
  agnai:
    image: ghcr.io/agnaistic/agnaistic:latest
    container_name: hts-ai-agnai
    profiles: [agnai]
    restart: unless-stopped
    ports:
      - "${AGNAI_PORT:-3003}:3001"
    networks:
      - ai-network
    healthcheck:
      test: ["CMD", "curl", "-sf", "http://localhost:3001"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 30s
  ```

  > Without MongoDB, Agnai runs in guest-only mode. All data is stored in the browser's
  > local storage. Clearing browser data will delete all chats and personas.

- [ ] **2. Component script**
  Create `scripts/components/agnai/agnai.sh` implementing:
  - `agnai_install` — pull GHCR image
  - `agnai_configure` — print KoboldCpp connection instructions
  - `agnai_start` — start service + health check
  - `agnai_health` — `curl -sf http://localhost:${AGNAI_PORT}`
  - `agnai_stop` — stop service

- [ ] **3. Env vars**
  Add to `.env.example`:

  ```text
  AGNAI_PORT=3003
  ```

### P1 — Wire to KoboldCpp

After starting Agnai, configure the KoboldCpp backend in the UI:

- Settings → AI → Service: **Kobold**
- Kobold URL: `http://hts-ai-koboldcpp:5001`

Or via `settings.json` to pre-configure the default service.

### P2 — Registration

- [ ] **4. Port map** — Add port 3003 to `REFERENCES.md` Host Port Map table.
- [ ] **5. Feature index** — Add row to `docs/development/features/REFERENCES.md`.

### P3 — Multi-user mode (optional)

If multi-user persistence is needed:

```yaml
  agnai-db:
    image: mongo:7
    container_name: hts-ai-agnai-db
    profiles: [agnai]
    restart: unless-stopped
    volumes:
      - agnai-db:/data/db
    networks:
      - ai-network
```

Set `MONGODB_URI=mongodb://hts-ai-agnai-db:27017/agnai` in the Agnai service.
Adds ~250MB memory overhead. Evaluate against actual multi-user need.

## Comparison with SillyTavern (FEATURE-005)

| Capability | Agnai | SillyTavern |
|---|---|---|
| **License** | ⚠️ AGPLv3 | ⚠️ AGPLv3 |
| **Multi-user** | ✅ (with MongoDB) | ❌ single-user only |
| **Guest mode (no DB)** | ✅ localStorage | ✅ local files |
| **KoboldCpp native** | ✅ | ✅ |
| **OpenAI-compat** | ✅ | ✅ |
| **Character formats** | W++, SBF, Boostyle, plain | All major formats |
| **Lore / memory books** | ✅ built-in | ✅ built-in |
| **Extensions / plugins** | Limited | Very large ecosystem |
| **Image generation** | ✅ (third-party APIs) | ✅ (SD, Comfy) |
| **Pipeline / long-term memory** | ✅ (opt-in) | Via extensions |
| **Docker image** | ✅ GHCR, no-DB guest mode | ✅ but more config |
| **Stars** | 714 | ~13k |
| **Last activity** | 2026-03 (~active) | Active |

**Recommendation:** Deploy Agnai in guest mode first (no MongoDB, minimal effort).
Use SillyTavern if you need a mature extension ecosystem or have existing character cards.
Keep both if multi-user is a future requirement.

## Acceptance Criteria

- `docker compose --profile agnai up` starts the service
- UI accessible at `http://localhost:3003`
- KoboldCpp backend connected in Agnai settings
- `agnai_health` returns success
- Port 3003 conflict-free per `REFERENCES.md` map

## Related

- [FEATURE-005](FEATURE-005.md) — SillyTavern (alternative RP frontend)
- [FEATURE-031](FEATURE-031.md) — KoboldCpp (shared inference backend)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md) — row: `agnaistic/agnai`
