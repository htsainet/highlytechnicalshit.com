# Gitea Component

Last updated: 2026-04-15

## What happens here

Gitea is a lightweight, self-hosted Git service. Used in the stack for
local version control, code hosting, and CI integration without relying
on external services.

## Files and structure

| File | Purpose |
|------|---------|
| `gitea.sh` | Full lifecycle: install, configure, start, stop, health |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
