#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
# shellcheck source=scripts/install/tooling/ui.sh
source "$REPO_DIR/scripts/install/tooling/ui.sh"

htsai_banner "03 — Setup Models"

# ─────────────────────────────────────────────────────────────────────────────
# 03-setup-models.sh
# Master model setup script — calls prod and test in order.
#
# After completion:
#   ollama-prod           ✅ running  (NemoClaw prod default)
#   stable-diffusion-prod ✅ running  (factory defaults)
#   ollama-test           ⏹ stopped  (start manually to evaluate)
#   stable-diffusion-test ⏹ stopped
#
# You can also run each script independently:
#   ./scripts/install/models/prod.sh
#   ./scripts/install/models/test.sh
# ─────────────────────────────────────────────────────────────────────────────

if [[ -f "${REPO_DIR}/scripts/install/models/helpers.sh" ]]; then
  source "${REPO_DIR}/scripts/install/models/helpers.sh"
else
  echo "[FAIL] scripts/install/models/helpers.sh not found in ${REPO_DIR}" >&2
  exit 1
fi

# ── Pre-run checklist ─────────────────────────────────────────────────────────
checklist_start
checklist_item false "1. Pull prod models (Ollama, Stable Diffusion)"
checklist_item false "2. Pull test models (optional evaluation)"
checklist_end

# ── Parse flags ───────────────────────────────────────────────────────────────
RUN_PROD=true
RUN_TEST=true

for arg in "$@"; do
  case "$arg" in
    --prod-only) RUN_TEST=false ;;
    --test-only) RUN_PROD=false ;;
    --help)
      echo "Usage: $0 [--prod-only] [--test-only]"
      exit 0
      ;;
    *)
      warn "Unknown flag: $arg — ignoring."
      ;;
  esac
done

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}╔══════════════════════════════════════╗${NC}"
echo -e "${CYAN}║       03-setup-models.sh             ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════╝${NC}"
echo ""
info "Will run:"
$RUN_PROD && info "  ✔ prod  (ollama-prod + sd-prod)"   || warn "  ✗ prod  (skipped)"
$RUN_TEST && info "  ✔ test  (ollama-test + sd-test)"   || warn "  ✗ test  (skipped)"
echo ""

# ── Run scripts ───────────────────────────────────────────────────────────────
if $RUN_PROD; then
  step "PROD environment"
  bash "${REPO_DIR}/scripts/install/models/prod.sh"
fi

if $RUN_TEST; then
  step "TEST environment"
  bash "${REPO_DIR}/scripts/install/models/test.sh"
fi

# ── Final summary ─────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}══════════════════════════════════════════${NC}"
ok "All requested environments seeded."
echo ""
info "Running services:"
info "  ollama-prod           → http://localhost:11434"
info "  stable-diffusion-prod → http://localhost:7860"
echo ""
info "Stopped (start manually when needed):"
info "  docker compose -f instances/test/docker-compose.yml up -d ollama-test stable-diffusion-test"
echo ""
info "Ports when running:"
info "  ollama-test    → http://localhost:11435"
info "  sd-test        → http://localhost:7861"
echo -e "${CYAN}══════════════════════════════════════════${NC}"
