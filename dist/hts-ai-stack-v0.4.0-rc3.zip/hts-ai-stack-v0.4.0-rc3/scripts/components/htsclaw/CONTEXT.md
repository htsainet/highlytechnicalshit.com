# htsclaw Component

Last updated: 2026-04-15

## What happens here

htsclaw is the stack's self-managed sandbox engine — a custom-built
alternative to NemoClaw that runs directly on the host. It manages
firewall rules, health timers, dashboard integration, and container
lifecycle without depending on NVIDIA tooling.

## Files and structure

| File | Purpose |
|------|---------|
| `htsclaw.sh` | Full lifecycle: install, configure, start, stop, health, destroy |
| `htsclaw.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
