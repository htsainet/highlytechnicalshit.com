$ErrorActionPreference = 'SilentlyContinue'

Describe 'npm audit security checks' {
    BeforeAll {
        $ErrorActionPreference = 'Stop'
        # Get repo root from PSScriptRoot
        $script:RepoRoot = (Split-Path -Parent $PSScriptRoot)
        $script:NemoClawSrc = "$env:HOME/.nemoclaw/source"
        $script:NemoClawPlugin = "$script:NemoClawSrc/nemoclaw"
    }

    Context 'root stack dependencies' {
        It 'no unresolved HIGH/CRITICAL vulnerabilities' {
            $packageJson = "$script:RepoRoot/package.json"

            if (-not (Test-Path $packageJson)) {
                Set-ItResult -Skipped -Because "No package.json found"
                return
            }

            Push-Location $script:RepoRoot
            try {
                $auditJson = npm audit --json 2>&1
                if (-not $auditJson) {
                    Write-Host "✓ No audit output (likely no vulns)"
                    return
                }

                $audit = $auditJson | ConvertFrom-Json -ErrorAction SilentlyContinue
                if (-not $audit) { return }

                $vulns = $audit.vulnerabilities
                if (-not $vulns) { return }

                # Look for HIGH/CRITICAL with fixes
                $fixable = @()
                $vulns.PSObject.Properties | ForEach-Object {
                    if ($_.Value.severity -in @('high', 'critical') -and $_.Value.fixAvailable) {
                        $fixable += $_.Name
                    }
                }

                if ($fixable.Count -gt 0) {
                    Write-Host "Found fixable HIGH/CRITICAL: $($fixable -join ', ')"
                    $true | Should -Be $false
                }
            }
            finally {
                Pop-Location
            }
        }
    }

    Context 'NemoClaw dependencies' -Skip:(-not (Test-Path $script:NemoClawSrc)) {
        It 'no fixable HIGH/CRITICAL vulnerabilities' {
            if (-not (Test-Path $script:NemoClawSrc)) {
                Set-ItResult -Skipped -Because "NemoClaw not installed"
                return
            }

            Push-Location $script:NemoClawSrc
            try {
                $auditJson = npm audit --json 2>&1
                if (-not $auditJson) { return }

                $audit = $auditJson | ConvertFrom-Json -ErrorAction SilentlyContinue
                if (-not $audit -or -not $audit.vulnerabilities) { return }

                $fixable = @()
                $audit.vulnerabilities.PSObject.Properties | ForEach-Object {
                    if ($_.Value.severity -in @('high', 'critical') -and $_.Value.fixAvailable) {
                        $fixable += $_.Name
                    }
                }

                if ($fixable.Count -gt 0) {
                    Write-Host "Found $($fixable.Count) fixable HIGH/CRITICAL vulns in NemoClaw"
                    $true | Should -Be $false
                } else {
                    Write-Host "✓ No fixable HIGH/CRITICAL vulns in NemoClaw"
                }
            }
            finally {
                Pop-Location
            }
        }
    }

    Context 'version constraints safety' {
        It 'no overly permissive version specs' {
            $packageJson = "$script:RepoRoot/package.json"

            if (-not (Test-Path $packageJson)) {
                Set-ItResult -Skipped
                return
            }

            $pkg = Get-Content $packageJson | ConvertFrom-Json

            $risky = @()
            @($pkg.dependencies.PSObject.Properties) + @($pkg.devDependencies.PSObject.Properties) |
                Where-Object { $_.Value -match '^\*$|^x\.|latest' } |
                ForEach-Object { $risky += "$($_.Name): $($_.Value)" }

            if ($risky.Count -gt 0) {
                Write-Host "⚠ Found permissive versions: $($risky -join '; ')"
            }
            $risky.Count | Should -Be 0
        }
    }
}
