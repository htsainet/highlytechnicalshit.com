# Stable Diffusion References

Last updated: 2026-04-15

## Upstream

- [GitHub — AUTOMATIC1111/stable-diffusion-webui](https://github.com/AUTOMATIC1111/stable-diffusion-webui)

## Official documentation

- [Stable Diffusion WebUI Wiki](https://github.com/AUTOMATIC1111/stable-diffusion-webui/wiki)

## Related

- [Stability AI](https://stability.ai/) — creators of the Stable Diffusion model
