#!/usr/bin/env bash
# scripts/utils/ssh.sh — Manage SSH settings via interactive menu
#
# Checks and controls:
#   • SSH server enabled (systemctl)
#   • SSH port configured (persistent)
#   • Key-based auth preferred (persistent)
#   • Root login disabled (persistent)
#   • Password auth disabled (persistent)
#
# Usage:
#   ./ssh.sh                 # Opens interactive menu
#   ./ssh.sh --help          # Show this help
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source common logging functions
# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/common.sh" || {
  # Fallback if common.sh not available
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  RED='\033[0;31m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
}

SSH_CONFIG="/etc/ssh/sshd_config.d/99-ai-stack.conf"
SSH_DEFAULT_PORT=22
SSH_CUSTOM_PORT=2222

# ── Tailscale detection ──────────────────────────────────────────────────────

is_tailscale_available() {
  command -v tailscale >/dev/null 2>&1 && echo "yes" || echo "no"
}

is_tailscale_active() {
  if systemctl is-active tailscaled >/dev/null 2>&1; then
    echo "yes"
  else
    echo "no"
  fi
}

get_tailscale_ip() {
  if [[ $(is_tailscale_active) == "yes" ]]; then
    tailscale ip -4 2>/dev/null | head -1
  else
    echo ""
  fi
}

is_ssh_tailscale_only() {
  if [[ -f "$SSH_CONFIG" ]]; then
    grep -q "ListenAddress 100.64" "$SSH_CONFIG" 2>/dev/null && echo "yes" || echo "no"
  else
    echo "no"
  fi
}

# ── Helper functions ──────────────────────────────────────────────────────

# Check if SSH server is enabled and running
is_ssh_enabled() {
  systemctl is-enabled ssh >/dev/null 2>&1 && echo "yes" || echo "no"
}

# Check if SSH is currently active
is_ssh_active() {
  systemctl is-active ssh >/dev/null 2>&1 && echo "yes" || echo "no"
}

# Get current SSH listening port
get_ssh_port() {
  local port="$SSH_DEFAULT_PORT"
  if [[ -f "$SSH_CONFIG" ]]; then
    port=$(grep "^Port " "$SSH_CONFIG" 2>/dev/null | awk '{print $NF}' | head -1 || echo "$SSH_DEFAULT_PORT")
  fi
  if [[ -z "$port" ]]; then
    port=$(grep "^Port " /etc/ssh/sshd_config 2>/dev/null | awk '{print $NF}' | head -1 || echo "$SSH_DEFAULT_PORT")
  fi
  echo "${port:-$SSH_DEFAULT_PORT}"
}

# Check if key-based auth is the only method
is_pubkey_only() {
  if [[ -f "$SSH_CONFIG" ]]; then
    grep -q "^PubkeyAuthentication yes" "$SSH_CONFIG" 2>/dev/null && \
    grep -q "^PasswordAuthentication no" "$SSH_CONFIG" 2>/dev/null && \
    echo "yes" || echo "no"
  else
    echo "no"
  fi
}

# Check if root login is disabled
is_root_login_disabled() {
  if [[ -f "$SSH_CONFIG" ]]; then
    grep -q "^PermitRootLogin no" "$SSH_CONFIG" 2>/dev/null && echo "yes" || echo "no"
  else
    echo "no"
  fi
}

# Enable SSH server
enable_ssh() {
  sudo systemctl enable ssh || {
    echo -e "${RED}Failed to enable SSH${NC}"
    return 1
  }
  sudo systemctl start ssh || {
    echo -e "${RED}Failed to start SSH${NC}"
    return 1
  }
  info "SSH enabled and started"
}

# Disable SSH server
disable_ssh() {
  sudo systemctl stop ssh || {
    echo -e "${RED}Failed to stop SSH${NC}"
    return 1
  }
  sudo systemctl disable ssh || {
    echo -e "${RED}Failed to disable SSH${NC}"
    return 1
  }
  info "SSH disabled and stopped"
}

# Configure SSH port
set_ssh_port() {
  local new_port="$1"
  
  if ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1024 ] || [ "$new_port" -gt 65535 ]; then
    echo -e "${RED}Invalid port: $new_port (must be 1024-65535)${NC}"
    return 1
  fi

  sudo mkdir -p "$(dirname "$SSH_CONFIG")"
  
  # Create or update config
  if [[ -f "$SSH_CONFIG" ]]; then
    sudo sed -i "/^Port /d" "$SSH_CONFIG"
  fi
  echo "Port $new_port" | sudo tee -a "$SSH_CONFIG" >/dev/null
  
  # Check syntax and reload
  if sudo sshd -t 2>/dev/null; then
    sudo systemctl reload ssh || sudo systemctl restart ssh
    info "SSH port set to: $new_port"
  else
    echo -e "${RED}SSH config syntax error — reverting${NC}"
    sudo sed -i "/^Port $new_port/d" "$SSH_CONFIG"
    return 1
  fi
}

# Enable pubkey-only auth (disable passwords)
set_pubkey_only() {
  local enable="$1"  # "true" or "false"
  
  sudo mkdir -p "$(dirname "$SSH_CONFIG")"

  # Remove existing lines
  sudo sed -i '/^PubkeyAuthentication /d; /^PasswordAuthentication /d' "$SSH_CONFIG" 2>/dev/null || true

  if [[ "$enable" == "true" ]]; then
    echo "PubkeyAuthentication yes" | sudo tee -a "$SSH_CONFIG" >/dev/null
    echo "PasswordAuthentication no" | sudo tee -a "$SSH_CONFIG" >/dev/null
    info "Pubkey-only auth enabled (passwords disabled)"
  else
    echo "PubkeyAuthentication yes" | sudo tee -a "$SSH_CONFIG" >/dev/null
    echo "PasswordAuthentication yes" | sudo tee -a "$SSH_CONFIG" >/dev/null
    info "Pubkey-only auth disabled (passwords allowed)"
  fi

  if sudo sshd -t 2>/dev/null; then
    sudo systemctl reload ssh || sudo systemctl restart ssh
  else
    echo -e "${RED}SSH config syntax error${NC}"
    return 1
  fi
}

# Disable root login
set_root_login_disabled() {
  local disable="$1"  # "true" or "false"

  sudo mkdir -p "$(dirname "$SSH_CONFIG")"
  sudo sed -i '/^PermitRootLogin /d' "$SSH_CONFIG" 2>/dev/null || true

  if [[ "$disable" == "true" ]]; then
    echo "PermitRootLogin no" | sudo tee -a "$SSH_CONFIG" >/dev/null
    info "Root login disabled"
  else
    echo "PermitRootLogin yes" | sudo tee -a "$SSH_CONFIG" >/dev/null
    info "Root login enabled"
  fi

  if sudo sshd -t 2>/dev/null; then
    sudo systemctl reload ssh || sudo systemctl restart ssh
  else
    echo -e "${RED}SSH config syntax error${NC}"
    return 1
  fi
}

# Restrict SSH to Tailscale network only
set_ssh_tailscale_only() {
  local enable="$1"  # "true" or "false"
  
  sudo mkdir -p "$(dirname "$SSH_CONFIG")"
  
  # Remove existing ListenAddress lines
  sudo sed -i '/^ListenAddress /d' "$SSH_CONFIG" 2>/dev/null || true

  if [[ "$enable" == "true" ]]; then
    # Listen on Tailscale subnet only (100.64.0.0/10 is Tailscale's range)
    # We need to get the specific Tailscale IP and listen on that
    local ts_ip
    ts_ip=$(get_tailscale_ip)
    if [[ -n "$ts_ip" ]]; then
      echo "ListenAddress $ts_ip" | sudo tee -a "$SSH_CONFIG" >/dev/null
      info "SSH restricted to Tailscale only: $ts_ip"
    else
      echo -e "${RED}Could not get Tailscale IP${NC}"
      return 1
    fi
  else
    # Listen on all interfaces (default)
    echo "ListenAddress 0.0.0.0" | sudo tee -a "$SSH_CONFIG" >/dev/null
    echo "ListenAddress ::" | sudo tee -a "$SSH_CONFIG" >/dev/null
    info "SSH listening on all interfaces"
  fi

  if sudo sshd -t 2>/dev/null; then
    sudo systemctl reload ssh || sudo systemctl restart ssh
  else
    echo -e "${RED}SSH config syntax error — reverting${NC}"
    sudo sed -i '/^ListenAddress /d' "$SSH_CONFIG" 2>/dev/null || true
    return 1
  fi
}

# Display status with color coding
show_status() {
  local label="$1"
  local value="$2"
  local color="${GREEN}"
  [[ "$value" == "no" ]] && color="${RED}"
  printf "  %-40s ${color}%-8s${NC}\n" "$label" "$value"
}

# ── Main Menu ─────────────────────────────────────────────────────────────

show_main_menu() {
  local ssh_en=$(is_ssh_enabled)
  local ssh_act=$(is_ssh_active)
  local ssh_port=$(get_ssh_port)
  local pubkey=$(is_pubkey_only)
  local root=$(is_root_login_disabled)
  local ts_available=$(is_tailscale_available)
  local ts_active=$(is_tailscale_active)
  local ts_only=$(is_ssh_tailscale_only)

  # Build status display for the menu
  local status_text="SSH Status:\n\n"
  status_text+="  Enabled: $ssh_en  Active: $ssh_act\n"
  status_text+="  Port: $ssh_port\n"
  status_text+="  Pubkey-only: $pubkey\n"
  status_text+="  Root login disabled: $root\n"
  
  if [[ "$ts_available" == "yes" && "$ts_active" == "yes" ]]; then
    local ts_ip
    ts_ip=$(get_tailscale_ip)
    status_text+="  Tailscale: $ts_ip  Restricted: $ts_only\n"
  fi
  
  status_text+="\nChoose an action:"

  # Build menu options
  local ssh_state=$(is_ssh_enabled)
  local pubkey_state=$(is_pubkey_only)
  local root_state=$(is_root_login_disabled)

  local ssh_toggle="Enable" || ssh_toggle="Disable"
  [[ "$ssh_state" == "yes" ]] && ssh_toggle="Disable" || ssh_toggle="Enable"

  local pubkey_toggle="Enable" || pubkey_toggle="Disable"
  [[ "$pubkey_state" == "yes" ]] && pubkey_toggle="Disable" || pubkey_toggle="Enable"

  local root_toggle="Re-enable" || root_toggle="Disable"
  [[ "$root_state" == "yes" ]] && root_toggle="Re-enable" || root_toggle="Disable"

  # Build menu items array
  local -a menu_items=("1" "$ssh_toggle SSH server"
                       "2" "Change SSH port"
                       "3" "$pubkey_toggle Pubkey-only auth"
                       "4" "$root_toggle root login"
                       "5" "Show detailed settings"
                       "6" "Apply security hardening")
  
  # Add Tailscale option if available
  if [[ "$ts_available" == "yes" && "$ts_active" == "yes" ]]; then
    local ts_toggle="Restrict"
    [[ "$ts_only" == "yes" ]] && ts_toggle="Unrestrict"
    menu_items+=("7" "$ts_toggle to Tailscale only")
    menu_items+=("8" "Reset to defaults")
  else
    menu_items+=("7" "Reset to defaults")
  fi

  # Present menu with embedded status
  local choice
  choice=$(whiptail --title "SSH Server Configuration" \
    --menu "$status_text" 0 0 0 \
    "${menu_items[@]}" \
    3>&1 1>&2 2>&3) || return 0  # Exit if user clicks Cancel

  handle_menu_choice "$choice"
}

# ── Menu handlers ─────────────────────────────────────────────────────────

handle_menu_choice() {
  local choice="$1"

  case "$choice" in
    1)
      toggle_ssh_menu
      ;;
    2)
      change_port_menu
      ;;
    3)
      toggle_pubkey_auth_menu
      ;;
    4)
      toggle_root_login_menu
      ;;
    5)
      show_detailed_settings
      ;;
    6)
      apply_security_hardening
      ;;
    7)
      # Could be Tailscale option or Reset depending on availability
      if [[ $(is_tailscale_available) == "yes" && $(is_tailscale_active) == "yes" ]]; then
        toggle_tailscale_restricted_menu
      else
        confirm_reset_all
      fi
      ;;
    8)
      # Reset to defaults (only if Tailscale option exists)
      if [[ $(is_tailscale_available) == "yes" && $(is_tailscale_active) == "yes" ]]; then
        confirm_reset_all
      fi
      ;;
    *)
      ;;
  esac
}

toggle_ssh_menu() {
  local current=$(is_ssh_enabled)
  local new_state="false"
  [[ "$current" == "no" ]] && new_state="true"

  local action="disable"
  [[ "$new_state" == "true" ]] && action="enable"

  sudo_or_warn "toggle SSH" || return 0

  if whiptail --yesno "Toggle SSH to: $new_state\n\nThis ${action}s SSH server at startup.\nWARNING: Requires sudo to modify systemd." 0 0; then
    if [[ "$new_state" == "true" ]]; then
      enable_ssh
    else
      disable_ssh
    fi
    whiptail --msgbox "✓ SSH is now: $new_state (persistent)" 8 40
  fi
  show_main_menu
}

change_port_menu() {
  sudo_or_warn "change SSH port" || return 0

  local current_port=$(get_ssh_port)
  local new_port
  new_port=$(whiptail --title "Change SSH Port" \
    --inputbox "Current port: $current_port\n\nNew port (1024-65535):" 10 45 "$SSH_CUSTOM_PORT" \
    3>&1 1>&2 2>&3) || return 0

  if whiptail --yesno "Change SSH port from $current_port to $new_port?\n\nWARNING: Ensure firewall allows new port." 0 0; then
    if set_ssh_port "$new_port"; then
      whiptail --msgbox "✓ SSH port changed to: $new_port" 8 40
    else
      whiptail --msgbox "✗ Failed to change SSH port" 8 40
    fi
  fi
  show_main_menu
}

toggle_pubkey_auth_menu() {
  local current=$(is_pubkey_only)
  local new_state="false"
  [[ "$current" == "no" ]] && new_state="true"

  local action="force"
  [[ "$new_state" == "true" ]] && action="allow only" || action="allow"

  sudo_or_warn "change auth method" || return 0

  if whiptail --yesno "Toggle pubkey-only auth to: $new_state\n\nThis will ${action} key-based authentication.\nWARNING: Ensure you have SSH keys configured!" 0 0; then
    set_pubkey_only "$new_state"
    whiptail --msgbox "✓ Auth method updated" 8 40
  fi
  show_main_menu
}

toggle_root_login_menu() {
  local current=$(is_root_login_disabled)
  local new_state="false"
  [[ "$current" == "yes" ]] && new_state="true"

  local action="allow"
  [[ "$new_state" == "true" ]] && action="block" || action="allow"

  sudo_or_warn "modify root login policy" || return 0

  if whiptail --yesno "Toggle root login to: disabled=$new_state\n\nThis will ${action} root SSH login." 0 0; then
    set_root_login_disabled "$new_state"
    whiptail --msgbox "✓ Root login policy updated" 8 40
  fi
  show_main_menu
}

toggle_tailscale_restricted_menu() {
  local current=$(is_ssh_tailscale_only)
  local new_state="false"
  [[ "$current" == "no" ]] && new_state="true"

  local action="restrict"
  [[ "$new_state" == "true" ]] && action="restrict to Tailscale" || action="open to all networks"

  sudo_or_warn "restrict SSH access" || return 0

  local ts_ip
  ts_ip=$(get_tailscale_ip)
  
  if whiptail --yesno "Toggle SSH Tailscale restriction to: $new_state\n\nYour Tailscale IP: $ts_ip\n\nThis will ${action}." 0 0; then
    if set_ssh_tailscale_only "$new_state"; then
      if [[ "$new_state" == "true" ]]; then
        whiptail --msgbox "✓ SSH is now restricted to Tailscale only\n\nListening on: $ts_ip" 8 50
      else
        whiptail --msgbox "✓ SSH is now open to all interfaces\n\nListening on: 0.0.0.0 and ::" 8 50
      fi
    else
      whiptail --msgbox "✗ Failed to update SSH access restriction" 8 40
    fi
  fi
  show_main_menu
}

show_detailed_settings() {
  local ssh_enabled=$(is_ssh_enabled)
  local ssh_active=$(is_ssh_active)
  local port=$(get_ssh_port)
  local pubkey=$(is_pubkey_only)
  local root=$(is_root_login_disabled)

  local msg="DETAILED SETTINGS\n\n"
  msg+="SSH Service\n"
  msg+="  Enabled: $ssh_enabled (systemctl enable ssh)\n"
  msg+="  Active: $ssh_active (systemctl start ssh)\n"
  msg+="  Port: $port\n\n"
  msg+="Authentication\n"
  msg+="  Pubkey only: $pubkey\n"
  msg+="  Root login disabled: $root\n\n"
  msg+="Config file: $SSH_CONFIG\n"

  whiptail --msgbox "$msg" 20 60
  show_main_menu
}

apply_security_hardening() {
  sudo_or_warn "apply hardening" || return 0

  whiptail --yesno "Apply SSH security hardening?\n\nThis will:\n• Enable SSH server\n• Change port to 2222\n• Enable pubkey-only auth\n• Disable root login\n\nWARNING: Ensure SSH keys are configured first!" 0 0 || return 0

  enable_ssh
  set_ssh_port "$SSH_CUSTOM_PORT"
  set_pubkey_only "true"
  set_root_login_disabled "true"

  whiptail --msgbox "✓ SSH hardening applied\n\nRemember to update firewall rules for port $SSH_CUSTOM_PORT" 10 50
  show_main_menu
}

confirm_reset_all() {
  local msg="RESET SSH TO DEFAULTS?\n\n"
  msg+="This will:\n"
  msg+="  • Revert port to 22\n"
  msg+="  • Allow password authentication\n"
  msg+="  • Allow root login\n"
  msg+="  • Keep SSH service enabled\n\n"
  msg+="WARNING: Requires sudo. This is destructive!"

  if whiptail --yesno "$msg" 0 0; then
    if ! sudo -l >/dev/null 2>&1; then
      whiptail --msgbox "ERROR: sudo access required\n\nPlease run: sudo $0" 8 40
      return 1
    fi

    whiptail --infobox "Resetting SSH to defaults...\nPlease wait..." 8 50

    # Remove custom SSH config
    sudo rm -f "$SSH_CONFIG" 2>/dev/null || true
    sudo systemctl reload ssh 2>/dev/null || true

    whiptail --msgbox "✓ SSH reset to defaults\n\nPort: 22\nPassword auth: allowed\nRoot login: allowed" 10 40
  fi
  show_main_menu
}

# ── Utility: Check for sudo or warn ───────────────────────────────────────
sudo_or_warn() {
  local action="${1:-perform action}"
  if ! sudo -l >/dev/null 2>&1; then
    whiptail --msgbox "ERROR: sudo access required to $action\n\nPlease configure sudoers or run with: sudo $0" 8 50
    return 1
  fi
  return 0
}

# ── Help ──────────────────────────────────────────────────────────────────

show_help() {
  cat <<EOF
${CYAN}SSH Server Configuration Manager${NC}

Usage:
  $0                 Opens interactive menu
  $0 --help          Show this help

${BOLD}Features:${NC}
  • Enable/disable SSH server
  • Configure SSH listening port
  • Enforce key-based authentication only
  • Disable root login
  • Apply security hardening

${BOLD}Requirements:${NC}
  • whiptail (usually pre-installed)
  • sudo (for SSH config changes)
  • systemctl (for systemd integration)

${BOLD}Security Best Practices:${NC}
  • Use non-standard port (e.g., 2222) to reduce noise
  • Enforce key-based auth only
  • Disable root login
  • Update firewall after port changes

EOF
}

# ── Entry point ───────────────────────────────────────────────────────────

main() {
  if [[ "${1:-}" == "--help" ]] || [[ "${1:-}" == "-h" ]]; then
    show_help
    exit 0
  fi

  # Check dependencies
  if ! command -v whiptail >/dev/null 2>&1; then
    echo -e "${RED}whiptail not found. Install: sudo apt install whiptail${NC}"
    exit 1
  fi

  if ! command -v systemctl >/dev/null 2>&1; then
    echo -e "${RED}systemctl not found. This tool requires systemd.${NC}"
    exit 1
  fi

  if [[ "$USER" == "root" ]]; then
    echo -e "${YELLOW}WARNING: Running as root. Some operations may not work as expected.${NC}"
  fi

  show_main_menu
}

main "$@"
