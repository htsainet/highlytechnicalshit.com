# Config-Driven Convergence

**Priority:** HIGH
**Effort:** 8-12 hours
**Risk:** Low — dispatches to existing component lifecycle functions; no new service code
**Target Release:** v0.5.0
**Status:** ✅ COMPLETE (April 2026)
**Depends on:** v0.4.0 core stack stable (dual-inference + llama-swap)
**Blocks:** FEATURE-010 (Full Drift Detection)

## Status

Converge.sh is now the **primary orchestrator** for all Docker services.
`full-stack.sh` has been deprecated. `install.sh` calls host setup scripts
directly and delegates all service deployment to `converge.sh --yes`.

The flow is now:
- `bootstrap.sh` → host prereqs + NVIDIA drivers (last — requires reboot)
- `install.sh` → wizard → apply_config → docker/node/tools → `converge.sh --yes`
- `reconfigure.sh` → wizard → `converge.sh` (day-2 changes, no host setup)

## Scope

Add a convergence script (`scripts/utils/converge.sh`) that reads
`config/stack.json`, compares it against a `.last-applied.json` snapshot, and
runs only the component lifecycle functions needed to bring the machine into
the desired state. Supports both unattended and interactive (menu) modes.

### Core Loop

```text
for each service in stack.json:
    desired = stack.json[service]          # enabled? port? model?
    applied = .last-applied.json[service]  # what was last applied?

    if desired == disabled && applied == enabled  → stop service
    if desired == enabled  && applied == missing  → install + start
    if desired == enabled  && applied != desired  → reconfigure + restart
    if desired == enabled  && applied == desired  → health check only
```

### Execution Modes

| Mode | Flag | Behaviour |
|------|------|-----------|
| **Unattended** | `--yes` (default) | Applies all changes without prompting |
| **Interactive** | `--interactive` | Shows diff summary, prompts before applying |
| **Dry-run** | `--dry-run` | Prints planned actions without executing |

### What Gets Compared

- **Services**: enabled/disabled state per `services` and `extras.components`
- **Ports**: port assignments in `services.*` and `inference.*`
- **Backend mode**: `backend` field (ollama-only, bitnet-only, dual)
- **Models**: `inference.ollama_model`, `inference.bitnet_model`
- **NAS mounts**: `nas.enabled` and mount point config
- **Host tools**: `admin.tools` list (tailscale, ssh_server)

### What It Dispatches To

Existing scripts — no new service code:

| Gap detected | Action |
|--------------|--------|
| Service missing | `scripts/components/{service}.sh` (install + start) |
| Service needs stop | `{service}_stop()` via component script |
| Port changed | Re-apply `.env`, restart affected container |
| Model changed | `ollama.sh --swap {mode}` or re-pull |
| NAS mount missing | `scripts/host/nas.sh` |
| Host tool missing | `scripts/host/tools.sh` |

### Snapshot Strategy

After successful convergence, copy `stack.json` → `.last-applied.json` in the
repo root (gitignored). First run without a snapshot treats everything as "new"
and converges the full config.

## Implementation Notes

- ~200-300 lines of bash
- Heavy use of `jq` for JSON diffing
- Sources `lib/common.sh`, `lib/health.sh`, `lib/compose.sh`
- Each service maps to its component script via a lookup table
- Interactive mode uses the same diff logic, just gates on `read -p` prompts
- Ordering: host deps → inference backends → router → frontends → extras
  (same order as existing bundle scripts)

## Acceptance Criteria

- [ ] `converge.sh --dry-run` shows planned actions without side effects
- [ ] `converge.sh --yes` brings a fresh machine to match `stack.json`
- [ ] `converge.sh --interactive` shows diff and prompts before each action
- [ ] Disabling a service in `stack.json` stops its container on next converge
- [ ] Changing a port re-applies `.env` and restarts the affected container
- [ ] `.last-applied.json` is written after successful convergence
- [ ] First run without `.last-applied.json` converges the full config
- [ ] Exit code 0 on success, non-zero on any failed action

## Consolidation Note

As of v0.4.x, service dispatch logic is duplicated across two orchestrators
with inconsistent variable styles:

- `scripts/bundles/full-stack.sh` — 15 individual booleans, subprocess
  invocation
- `scripts/install/06-start-stack.sh` — 6 compound enums, sourced functions

This caused bugs (e.g. htsclaw missing from dashboard — `fd1d31c`). FEATURE-009
has **replaced both** as the single orchestration path. `converge.sh` reads
component manifests and `stack.json` directly — no more `.env` boolean flags
for service enablement.

## Implementation Plan

> [docs/planning/FEATURE-009-convergence-plan.md](../../planning/FEATURE-009-convergence-plan.md)
