#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════╗
# ║       AI STACK — APPLY CONFIG                    ║
# ║       Maps setup menu JSON → .env variables      ║
# ╚══════════════════════════════════════════════════╝
#
# Usage:
#   ./apply_config.sh                          # auto-detect latest ai_stack_config_*.json
#   ./apply_config.sh ai_stack_config_XXX.json # specify a config file
#   ./apply_config.sh --env-file /path/to/.env # specify .env location
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

ok()   { echo -e "${GREEN}  ✓${RESET}  $*"; }
info() { echo -e "${CYAN}  ▸${RESET}  $*"; }
warn() { echo -e "${YELLOW}  ⚠${RESET}  $*"; }
fail() { echo -e "${RED}  ✗${RESET}  $*"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
ENV_FILE="${REPO_ROOT}/.env"
CONFIG_FILE=""

# ── Parse args ────────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --env-file) ENV_FILE="$2"; shift 2 ;;
    *)          CONFIG_FILE="$1"; shift ;;
  esac
done

# ── Find config if not specified ──────────────────────────────────────────────
if [[ -z "$CONFIG_FILE" ]]; then
  # Prefer canonical config/stack.json (written by ai_stack_setup.py)
  if [[ -f "${REPO_ROOT}/config/stack.json" ]]; then
    CONFIG_FILE="${REPO_ROOT}/config/stack.json"
  else
    # Legacy fallback: find latest ai_stack_config_*.json
    CONFIG_FILE=$(find "$SCRIPT_DIR" "$REPO_ROOT" -maxdepth 1 -name 'ai_stack_config_*.json' -printf '%T@\t%p\n' 2>/dev/null | sort -rn | head -1 | cut -f2)
    if [[ -z "$CONFIG_FILE" ]]; then
      fail "No config found. Run ./install.sh or ai_stack_setup.py first."
    fi
  fi
fi

[[ -f "$CONFIG_FILE" ]] || fail "Config file not found: ${CONFIG_FILE}"
info "Config : ${CONFIG_FILE}"
info "Env    : ${ENV_FILE}"
echo ""

# ── Read config and map to .env ───────────────────────────────────────────────
# Uses python3 to parse JSON and emit KEY=VALUE pairs.
ENV_UPDATES=$(python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys

with open(sys.argv[1]) as f:
    cfg = json.load(f)

kvs = []

# Backend engine
backend = cfg.get("backend", "ollama")
kvs.append(("BACKEND_ENGINE", backend))

# Model
model = cfg.get("model", "")
if backend == "dual":
    # Dual-inference: both backends fronted by llama-swap router
    inf = cfg.get("inference", {})
    kvs.append(("OLLAMA_MODEL", inf.get("ollama_model", model or "mistral-nemo:latest")))
    kvs.append(("BITNET_MODEL", inf.get("bitnet_model", "bitnet")))
    kvs.append(("LLAMA_SWAP_PORT", inf.get("router_port", "8081")))
    kvs.append(("OLLAMA_PORT", inf.get("ollama_port", "11434")))
elif backend == "ollama" and model:
    kvs.append(("OLLAMA_MODEL", model))
elif backend == "bitnet" and model:
    kvs.append(("BITNET_MODEL", model))

# Model library size
pull_all = cfg.get("pull_all_models", True)
kvs.append(("PULL_ALL_MODELS", "true" if pull_all else "false"))

# Dashboard
dashboard = cfg.get("dashboard", {})
kvs.append(("DASHBOARD_ENABLED", "true" if dashboard.get("enabled") else "false"))

# Monitoring
monitoring = cfg.get("monitoring", {})
kvs.append(("MONITORING_ENABLED", "true" if monitoring.get("enabled") else "false"))

# Portainer
portainer = cfg.get("portainer", {})
kvs.append(("PORTAINER_ENABLED", "true" if portainer.get("enabled") else "false"))

# OpenSpace
openspace_cfg = cfg.get("openspace", {})
kvs.append(("OPENSPACE_ENABLED", "true" if openspace_cfg.get("enabled") else "false"))

# DeerFlow
deerflow_cfg = cfg.get("deerflow", {})
kvs.append(("DEERFLOW_ENABLED", "true" if deerflow_cfg.get("enabled") else "false"))

# gVisor Sandbox
gvisor_cfg = cfg.get("gvisor_sandbox", {})
kvs.append(("GVISOR_SANDBOX_ENABLED", "true" if gvisor_cfg.get("enabled") else "false"))

# Instances (dual backend always runs single — no prod/test split)
instances = cfg.get("instances", {})
mode = "single" if backend == "dual" else instances.get("mode", "single")
kvs.append(("INSTANCE_MODE", mode))
if mode == "prod_test":
    if instances.get("prod_port"):
        kvs.append(("OLLAMA_PROD_PORT", instances["prod_port"]))
    if instances.get("test_port"):
        kvs.append(("OLLAMA_TEST_PORT", instances["test_port"]))

# Model cache
cache = cfg.get("model_cache", {})
if cache.get("type") == "local" and cache.get("path"):
    kvs.append(("MODEL_CACHE_PATH", cache["path"]))
elif cache.get("type") == "network":
    if cache.get("mount"):
        kvs.append(("MODEL_CACHE_MOUNT", cache["mount"]))
        kvs.append(("NAS_SD_CACHE", f"{cache['mount']}/sd-checkpoints"))
        kvs.append(("OLLAMA_DATA_DIR", f"{cache['mount']}/ollama"))
        kvs.append(("OLLAMA_TEST_DATA_DIR", f"{cache['mount']}/ollama-test"))
    if cache.get("share_path"):
        kvs.append(("MODEL_CACHE_SHARE", cache["share_path"]))

# Docker network
network = cfg.get("network", {})
if network.get("mode"):
    kvs.append(("DOCKER_NETWORK_MODE", network["mode"]))

# Comms tokens
comms = cfg.get("comms", {})
tokens = comms.get("tokens", {})
for key, val in tokens.items():
    if val:
        env_key = key.upper()
        kvs.append((env_key, val))

# Admin: Tailscale
admin = cfg.get("admin", {})
if admin.get("tailscale_authkey"):
    kvs.append(("TAILSCALE_AUTHKEY", admin["tailscale_authkey"]))
if admin.get("ssh_port"):
    kvs.append(("SSH_PORT", admin["ssh_port"]))

# Services: external vs deployed
services = cfg.get("services", {})

# Ollama
ollama_svc = services.get("ollama", {})
if ollama_svc.get("use_external"):
    kvs.append(("OLLAMA_USE_EXTERNAL", "true"))
    ollama_url = ollama_svc.get("external_url", "http://localhost:11434")
    kvs.append(("OLLAMA_BASE_URL", ollama_url))
else:
    kvs.append(("OLLAMA_USE_EXTERNAL", "false"))
    if backend == "ollama":
        kvs.append(("OLLAMA_BASE_URL", "http://ollama:11434"))

# Stable Diffusion
sd_svc = services.get("stable_diffusion", {})
if sd_svc.get("use_external"):
    kvs.append(("SD_USE_EXTERNAL", "true"))
    sd_url = sd_svc.get("external_url", "http://localhost:7860")
    kvs.append(("SD_EXTERNAL_URL", sd_url))
else:
    kvs.append(("SD_USE_EXTERNAL", "false"))

# BitNet
bitnet_svc = services.get("bitnet", {})
if bitnet_svc.get("use_external"):
    kvs.append(("BITNET_USE_EXTERNAL", "true"))
    bitnet_url = bitnet_svc.get("external_url", "http://localhost:8080")
    kvs.append(("OPENAI_API_BASE_URL", bitnet_url + "/v1"))
    kvs.append(("OPENAI_API_KEY", "not-needed"))
elif backend == "bitnet":
    kvs.append(("BITNET_USE_EXTERNAL", "false"))
    kvs.append(("OPENAI_API_BASE_URL", "http://bitnet:8080/v1"))
    kvs.append(("OPENAI_API_KEY", "not-needed"))

# OpenSpace
openspace_svc = services.get("openspace", {})
if openspace_svc.get("use_external"):
    kvs.append(("OPENSPACE_USE_EXTERNAL", "true"))
    openspace_url = openspace_svc.get("external_url", "http://localhost:5000")
    kvs.append(("OPENSPACE_URL", openspace_url))
else:
    kvs.append(("OPENSPACE_USE_EXTERNAL", "false"))

# NemoClaw (legacy — still read for backward compat)
nemoclaw_svc = services.get("nemoclaw", {})
nemoclaw_deploy = nemoclaw_svc.get("deploy", True)
kvs.append(("NEMOCLAW_DEPLOY", "true" if nemoclaw_deploy else "false"))
nemoclaw_personas = nemoclaw_svc.get("agent_personas", True)
kvs.append(("NEMOCLAW_AGENT_PERSONAS", "true" if nemoclaw_personas else "false"))

# Sandbox engine (htsclaw | nemoclaw | both | none)
sandbox_cfg = cfg.get("sandbox", {})
sandbox_engine = sandbox_cfg.get("engine", "")
if not sandbox_engine:
    # Migrate from legacy: if nemoclaw deploy was true, use nemoclaw
    sandbox_engine = "nemoclaw" if nemoclaw_deploy else "none"
kvs.append(("SANDBOX_ENGINE", sandbox_engine))
sandbox_personas = sandbox_cfg.get("agent_personas", True)
kvs.append(("HTSCLAW_AGENT_PERSONAS", "true" if sandbox_personas else "false"))
kvs.append(("HTSCLAW_DEPLOY", "true" if sandbox_engine in ("htsclaw", "both") else "false"))
kvs.append(("NEMOCLAW_DEPLOY", "true" if sandbox_engine in ("nemoclaw", "both") else "false"))

# LM Studio (host-native model runner)
lmstudio_cfg = cfg.get("lmstudio", {})
kvs.append(("LMSTUDIO_INSTALL", "true" if lmstudio_cfg.get("install") else "false"))
kvs.append(("LMSTUDIO_ENABLED", "true" if lmstudio_cfg.get("peer") else "false"))
if lmstudio_cfg.get("url"):
    kvs.append(("LMSTUDIO_URL", lmstudio_cfg["url"]))

# llama-swap (dual backend router)
llama_swap_svc = services.get("llama_swap", {})
if backend == "dual":
    ls_config = llama_swap_svc.get("config", "config/llama-swap.yaml")
    kvs.append(("LLAMA_SWAP_CONFIG", ls_config))

# Model audit (Open WebUI /audit function)
extras = cfg.get("extras", {})
model_audit = extras.get("model_audit", True)  # default on for backward compat
kvs.append(("MODEL_AUDIT_ENABLED", "true" if model_audit else "false"))

# Upstream issue watcher (daily cron for NemoClaw upstream issues)
components = extras.get("components", [])
kvs.append(("UPSTREAM_WATCH_ENABLED", "true" if "upstream_watch" in components else "false"))

# ── Images → SD_ENABLED / COMFYUI_ENABLED ────────────────────────────────────
images = cfg.get("images", {})
if images.get("enabled"):
    engine = images.get("engine", "")
    kvs.append(("SD_ENABLED", "true" if engine == "stable_diffusion" else "false"))
    kvs.append(("COMFYUI_ENABLED", "true" if engine == "comfyui" else "false"))
else:
    kvs.append(("SD_ENABLED", "false"))
    kvs.append(("COMFYUI_ENABLED", "false"))

# ── Comms platforms → TELEGRAM_ENABLED / SIGNAL_ENABLED ───────────────────────
comms = cfg.get("comms", {})
platforms = comms.get("platforms", [])
kvs.append(("TELEGRAM_ENABLED", "true" if "telegram" in platforms else "false"))
kvs.append(("SIGNAL_ENABLED", "true" if "signal" in platforms else "false"))

# ── Admin tools → TAILSCALE_ENABLED ──────────────────────────────────────────
admin = cfg.get("admin", {})
admin_tools = admin.get("tools", [])
kvs.append(("TAILSCALE_ENABLED", "true" if "tailscale" in admin_tools else "false"))

# Handle Open WebUI → LLM endpoint
if backend == "dual":
    kvs.append(("OPENAI_API_BASE_URL", "http://hts-ai-llama-swap:8080/v1"))
    kvs.append(("OPENAI_API_KEY", "not-needed"))
elif not ollama_svc.get("use_external") and backend == "ollama":
    kvs.append(("OPENAI_API_BASE_URL", ""))
elif not bitnet_svc.get("use_external") and backend != "bitnet":
    kvs.append(("OPENAI_API_BASE_URL", ""))

for k, v in kvs:
    print(f"{k}={v}")
PYEOF
)

# ── Upsert each key into .env ────────────────────────────────────────────────
[[ -f "$ENV_FILE" ]] || touch "$ENV_FILE"

while IFS='=' read -r key value; do
  [[ -z "$key" ]] && continue
  if grep -q "^${key}=" "$ENV_FILE"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$ENV_FILE"
    ok "${key}=${value}  (updated)"
  else
    printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
    ok "${key}=${value}  (added)"
  fi
done <<< "$ENV_UPDATES"

echo ""
ok "Config applied to ${ENV_FILE}"

# ── NAS / NFSv4 system config ─────────────────────────────────────────────────
# If NAS is enabled, configure /etc/idmapd.conf so NFSv4 user mapping matches
# the domain set on the Synology (Control Panel → File Services → NFS → Advanced
# Settings → NFSv4/4.1 domain).  Mismatched domains cause files to appear as
# nobody:nogroup on the mounted share.
NAS_CFG=$(python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys
with open(sys.argv[1]) as f:
    nas = json.load(f).get("nas", {})
if nas.get("enabled"):
    print(nas.get("nfs4_domain", "htsai"))
PYEOF
)

if [[ -n "$NAS_CFG" ]]; then
  NFS4_DOMAIN="$NAS_CFG"
  info "NAS enabled — configuring NFSv4 idmapd domain: ${NFS4_DOMAIN}"

  # Ensure nfs-common is installed (provides idmapd)
  if ! command -v idmapd &>/dev/null && ! dpkg -l nfs-common &>/dev/null 2>&1; then
    info "Installing nfs-common ..."
    sudo apt-get install -y nfs-common
  fi

  IDMAPD_CONF="/etc/idmapd.conf"
  if [[ -f "$IDMAPD_CONF" ]]; then
    if grep -q "^Domain" "$IDMAPD_CONF"; then
      sudo sed -i "s|^Domain.*|Domain = ${NFS4_DOMAIN}|" "$IDMAPD_CONF"
    else
      # Insert under [General] section if it exists, else append
      if grep -q "^\[General\]" "$IDMAPD_CONF"; then
        sudo sed -i "/^\[General\]/a Domain = ${NFS4_DOMAIN}" "$IDMAPD_CONF"
      else
        printf '\n[General]\nDomain = %s\n' "$NFS4_DOMAIN" | sudo tee -a "$IDMAPD_CONF" >/dev/null
      fi
    fi
  else
    printf '[General]\nDomain = %s\n' "$NFS4_DOMAIN" | sudo tee "$IDMAPD_CONF" >/dev/null
  fi
  ok "idmapd.conf  Domain = ${NFS4_DOMAIN}"

  # Restart idmapd so the new domain takes effect
  if systemctl is-active --quiet nfs-idmapd 2>/dev/null; then
    sudo systemctl restart nfs-idmapd && ok "nfs-idmapd restarted"
  fi

  # ── /etc/fstab NFS mount entries ────────────────────────────────────────────
  # rsize/wsize 1M: Linux client negotiates the largest block it can use,
  # independent of Synology's UI cap (which only sets the server-side default).
  # nfsvers=4.1: match the Maximum NFS protocol set on the Synology.
  # _netdev: defer mount until network is up; x-systemd.automount: lazy mount.
  NFS_OPTS="nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=5,_netdev,x-systemd.automount"

  NAS_MOUNTS=$(python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys
with open(sys.argv[1]) as f:
    nas = json.load(f).get("nas", {})
if not nas.get("enabled"):
    sys.exit(0)
host = nas.get("host", "")
uses = nas.get("uses", [])
if "model_cache" in uses and nas.get("model_cache_share") and nas.get("model_cache_mount"):
    print(f"{host}:{nas['model_cache_share']} {nas['model_cache_mount']}")
if "docker_backups" in uses and nas.get("docker_backup_share") and nas.get("docker_backup_mount"):
    print(f"{host}:{nas['docker_backup_share']} {nas['docker_backup_mount']}")
if "timeshift" in uses and nas.get("timeshift_share") and nas.get("timeshift_mount"):
    print(f"{host}:{nas['timeshift_share']} {nas['timeshift_mount']}")
PYEOF
  )

  if [[ -n "$NAS_MOUNTS" ]]; then
    info "Configuring NFS mounts in /etc/fstab ..."
    while IFS=' ' read -r share mountpoint; do
      [[ -z "$share" || -z "$mountpoint" ]] && continue
      # Create mount point if missing
      sudo mkdir -p "$mountpoint"
      FSTAB_LINE="${share}  ${mountpoint}  nfs  ${NFS_OPTS}  0  0"
      # Remove any existing entry for this mountpoint then append fresh
      sudo sed -i "\|[[:space:]]${mountpoint}[[:space:]]|d" /etc/fstab
      echo "$FSTAB_LINE" | sudo tee -a /etc/fstab >/dev/null
      ok "fstab: ${share}  →  ${mountpoint}"
    done <<< "$NAS_MOUNTS"
    info "Reloading systemd daemon to recognize new mounts..."
    sudo systemctl daemon-reload
    info "Run 'sudo mount -a' to mount now, or reboot to mount automatically."
  fi
fi

# After NFS mount is active, create subdirectories so Docker doesn't try to chown them
MODEL_CACHE_MOUNT=$(grep "^MODEL_CACHE_MOUNT=" "$ENV_FILE" | cut -d= -f2 || true)
if [[ -n "$MODEL_CACHE_MOUNT" && -d "$MODEL_CACHE_MOUNT" ]]; then
  info "Creating model cache subdirectories..."
  sudo mkdir -p "$MODEL_CACHE_MOUNT"/{ollama,ollama-test,sd-checkpoints}
  sudo chmod 755 "$MODEL_CACHE_MOUNT"/{ollama,ollama-test,sd-checkpoints}
  ok "Model cache subdirectories created"
fi
