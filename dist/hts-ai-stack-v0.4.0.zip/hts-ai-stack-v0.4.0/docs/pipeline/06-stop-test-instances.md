# 06-stop-test-instances.sh — Stop test instance + voice services

Stops the test instance and shared voice services while leaving production
running.

```bash
./06-stop-nonprod.sh
```

---

## What it stops

| Service | Purpose |
|---|---|
| `ollama-test` | Test Ollama instance |
| `stable-diffusion-test` | Test Stable Diffusion WebUI |
| `sillytavern-test` | Test SillyTavern |
| `open-webui-test` | Test Open WebUI |
| `whisper` | Speech-to-text service |
| `xtts` | Text-to-speech service |

---

## What it keeps running

| Service | Purpose |
|---|---|
| `ollama-prod` | Production Ollama instance |
| `stable-diffusion-prod` | Production Stable Diffusion WebUI |
| `sillytavern-prod` | Production SillyTavern |
| `open-webui-prod` | Production Open WebUI |
| `jenkins` | CI/CD server |
| `dashboard`, `dashboard-proxy` | Stack dashboard |

---

## Output

After stopping services, the script prints a status table for the root compose
and prod instance so you can confirm production is still up.

---

## Notes

- Safe to re-run.
- Uses `docker compose stop`, so containers are stopped but not removed.
- NemoClaw sandboxes are host processes — use `nemoclaw <sandbox> down` to stop them separately.
