# fail2ban — SSH + Service Brute Force Protection

**Priority:** MEDIUM
**Effort:** 3-4 hours
**Risk:** Low — additive protection layer. A misconfigured filter bans no IPs (false negative) rather
than blocking legitimate access. Test filters before enabling jails.
**Target Release:** v0.5.0
**Threat:** Brute force and credential stuffing against SSH and authenticated web services
(Open WebUI, Grafana). Repeated failed logins over the Tailscale interface or from a
compromised LAN host can eventually succeed.
**Depends on:** SECURITY-000 (UFW must be active — fail2ban inserts iptables rules that
respect the UFW chain hierarchy)
**Blocks:** Nothing

## Problem

fail2ban monitors logs for repeated failure patterns and bans offending IPs via iptables.
However, **Docker bypasses UFW's `INPUT` chain** — Docker publishes ports via its own
`DOCKER` chain, which runs before `INPUT`. A standard fail2ban ban action (`iptables -I
INPUT`) has no effect on Docker-published ports.

This means:

- **SSH** (port 22, host-managed, not Docker) — standard fail2ban works fine
- **Open WebUI, Grafana** (Docker-published ports) — standard fail2ban does NOT work

The fix requires a custom fail2ban action that inserts bans into the `DOCKER-USER` chain,
which Docker does respect.

## Solution

Deploy fail2ban with:

1. **`sshd` jail** — standard, works immediately
2. **`docker-open-webui` jail** — custom action targeting `DOCKER-USER` chain
3. **`docker-grafana` jail** — custom action targeting `DOCKER-USER` chain

## Implementation Steps

### 1. Add `scripts/components/fail2ban/fail2ban.sh`

```bash
fail2ban_install() {
  sudo apt-get install -y fail2ban
  sudo cp resources/fail2ban/jail.local /etc/fail2ban/jail.local
  sudo cp resources/fail2ban/action.d/docker-action.conf /etc/fail2ban/action.d/
  sudo cp resources/fail2ban/filter.d/open-webui.conf /etc/fail2ban/filter.d/
  sudo cp resources/fail2ban/filter.d/grafana.conf /etc/fail2ban/filter.d/
  sudo systemctl enable --now fail2ban
}
```

### 2. Create `resources/fail2ban/action.d/docker-action.conf`

Custom action targeting the `DOCKER-USER` chain:

```ini
[Definition]
actionstart =
actionstop  =
actioncheck =
actionban   = iptables -I DOCKER-USER -s <ip> -j DROP
actionunban = iptables -D DOCKER-USER -s <ip> -j DROP
```

### 3. Create `resources/fail2ban/filter.d/open-webui.conf`

Filter for Open WebUI failed login attempts (JSON log format from the container):

```ini
[Definition]
failregex = .*"POST /api/auth/signin.*" (401|403) .*<HOST>
ignoreregex =
```

### 4. Create `resources/fail2ban/filter.d/grafana.conf`

Filter for Grafana failed logins:

```ini
[Definition]
failregex = .*Failed to login.*Remote Address: <HOST>
            .*Invalid username or password.*"address":"<HOST>
ignoreregex =
```

### 5. Create `resources/fail2ban/jail.local`

```ini
[DEFAULT]
bantime  = 1h
findtime = 10m
maxretry = 5
backend  = systemd

[sshd]
enabled  = true
port     = ssh
filter   = sshd
backend  = systemd
maxretry = 3
bantime  = 24h

[open-webui]
enabled  = true
port     = 3000
filter   = open-webui
logpath  = /var/lib/docker/containers/*/*-json.log
action   = docker-action
maxretry = 5

[grafana]
enabled  = true
port     = 3100
filter   = grafana
logpath  = /var/lib/docker/containers/*/*-json.log
action   = docker-action
maxretry = 5
```

### 6. Configure Docker log driver

Confirm containers use `json-file` driver (default) so fail2ban can read logs:

```yaml
# docker-compose.yml — add to services with fail2ban jails
logging:
  driver: json-file
  options:
    max-size: "10m"
    max-file: "3"
```

## Testing

Test filter regex against real log lines before enabling:

```bash
sudo fail2ban-regex /var/lib/docker/containers/<id>/*-json.log /etc/fail2ban/filter.d/open-webui.conf
```

Simulate a ban manually:

```bash
sudo fail2ban-client set open-webui banip 10.0.0.99
sudo iptables -L DOCKER-USER -n   # should show 10.0.0.99 DROP
sudo fail2ban-client set open-webui unbanip 10.0.0.99
```

## Acceptance Criteria

- `sudo fail2ban-client status` shows all three jails active
- 6 failed SSH logins from a test IP results in a ban visible in `ufw status`
- 6 failed Open WebUI logins results in an `iptables -L DOCKER-USER` DROP entry
- Legitimate logins still work from a non-banned IP
- Ban entries appear in `/var/log/fail2ban.log`
