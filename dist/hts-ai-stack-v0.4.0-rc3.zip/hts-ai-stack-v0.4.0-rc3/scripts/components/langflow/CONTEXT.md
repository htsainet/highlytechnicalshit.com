# LangFlow Component

Last updated: 2026-04-15

## What happens here

LangFlow is a visual framework for building multi-agent and RAG
applications with a drag-and-drop interface. Used in the stack as
an alternative to Flowise for LLM workflow orchestration.

## Files and structure

| File | Purpose |
|------|---------|
| `langflow.sh` | Full lifecycle: install, configure, start, stop, health |
| `langflow.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
