# Disaster Recovery — Nuke and Pave Runbook

How to back up everything, reinstall Ubuntu, and restore the AI stack.

---

## Backup Layers

| Layer | Tool | Destination | What it covers |
|-------|------|-------------|----------------|
| OS snapshot | Timeshift | `/mnt/htsai-timeshift-backup` | System packages, drivers, configs |
| Docker state | backup-volumes.sh | `/mnt/htsai-docker-volume-backup/volumes/` | Chat history, workflows, repos, settings |
| Model weights | backup-models.sh | `/mnt/htsai-model-backup/` | Ollama, SD, ComfyUI, TTS, Vosk models |
| System configs | pre-nuke-checklist.sh | `/mnt/htsai-docker-volume-backup/configs/` | .env, fstab, daemon.json, stack.json |
| Full disk | backup-disk.sh | `/mnt/htsai-disk-image/` | Byte-for-byte clone (nuclear option) |
| Source code | Git | Remote origin | All scripts, manifests, docs |

---

## Before You Nuke

### Quick version

```bash
sudo ./backups/pre-nuke-checklist.sh --disk
```

This runs all backup layers in sequence. Add `--dry-run` to preview.

### Manual version

```bash
# 1. Verify NAS is mounted
mount | grep htsai

# 2. Timeshift snapshot
sudo timeshift --create --comments "Pre-nuke" --tags O --scripted

# 3. Docker volume backups
sudo ./backups/docker/backup-volumes.sh

# 4. Model weight sync
sudo ./scripts/host/backup-models.sh

# 5. System config backup (manual)
sudo cp /etc/docker/daemon.json /mnt/htsai-docker-volume-backup/configs/
sudo cp /etc/fstab /mnt/htsai-docker-volume-backup/configs/
sudo cp .env /mnt/htsai-docker-volume-backup/configs/stack.env

# 6. Full disk image (optional, takes 30-90 min)
sudo ./backups/disk-image/backup-disk.sh --verify

# 7. Push all git branches
git push --all origin
```

### Checklist

- [ ] All NAS mounts responding
- [ ] Timeshift snapshot created
- [ ] Docker volumes archived
- [ ] Model weights synced
- [ ] .env and stack.json backed up
- [ ] nvidia-smi output saved (driver version)
- [ ] All git branches pushed
- [ ] DHCP reservation set on router

---

## Reinstall Ubuntu

1. Boot from USB installer (already on `/dev/sdb`)
2. Install Ubuntu 24.04.
   - **Hostname**: up to you. Nothing in the stack depends on the host
     name; it only affects cosmetic labels (Tailscale node name,
     Prometheus `instance` label, backup filenames). Reuse the old
     name if you want alert/dashboard history to look continuous —
     otherwise pick whatever.
   - **Username**: anything works. No path in the repo is pinned to a
     specific username.
3. Format `/dev/sda2` as ext4 (single root partition + EFI)

---

## Restore Sequence

### Step 1 — Network and NAS

```bash
# Set up NFS client
sudo apt install -y nfs-common

# Configure idmapd
echo -e "[General]\nDomain = htsai" | sudo tee /etc/idmapd.conf

# Mount NAS shares
sudo mkdir -p /mnt/htsai-{model-backup,docker-volume-backup,timeshift-backup,disk-image}

sudo mount -t nfs <nas>:/volume1/htsai-model-backup /mnt/htsai-model-backup
sudo mount -t nfs <nas>:/volume1/htsai-docker-volume-backup /mnt/htsai-docker-volume-backup
sudo mount -t nfs <nas>:/volume1/htsai-timeshift-backup /mnt/htsai-timeshift-backup
```

### Step 2 — Restore system configs

```bash
# Find latest config backup
ls /mnt/htsai-docker-volume-backup/configs/

# Restore fstab (NAS mounts will persist across reboots)
sudo cp /mnt/htsai-docker-volume-backup/configs/<timestamp>/fstab /etc/fstab
sudo systemctl daemon-reload
sudo mount -a
```

### Step 3 — Clone repo and install

```bash
cd ~
mkdir -p hts && cd hts
git clone <repo-url> hts-ai-stack
cd hts-ai-stack

# Restore .env
cp /mnt/htsai-docker-volume-backup/configs/<timestamp>/stack.env .env

# Run installer (uses saved stack.json, installs Docker + NVIDIA + stack)
./install.sh
```

### Step 4 — Restore Docker volumes

```bash
# Find the latest backup timestamp
ls /mnt/htsai-docker-volume-backup/volumes/ | head -20

# Restore a volume (example: gitea_data)
docker volume create gitea_data
docker run --rm \
  -v gitea_data:/data \
  -v /mnt/htsai-docker-volume-backup/volumes:/backup:ro \
  alpine \
  tar xzf /backup/gitea_data_<TIMESTAMP>.tar.gz -C /data

# Repeat for each volume you want to restore
# Priority order: gitea_data, open_webui_data, sillytavern_*,
#                 flowise_data, n8n_data, grafana_data
```

### Step 5 — Restore from full disk image (alternative)

If the incremental restore above fails, the dd image restores everything:

```bash
# Boot from USB installer → open terminal
sudo mount -t nfs <nas>:/volume1/htsai-disk-image /mnt

# Find your image
ls -lh /mnt/*.img.gz
cat /mnt/*.meta.txt

# DANGER: This overwrites the ENTIRE disk
gunzip -c /mnt/<hostname>-sda-<TIMESTAMP>.img.gz | sudo dd of=/dev/sda bs=64K status=progress

# Reboot
sudo reboot
```

---

## NAS Share Reference

| Share | Mount Point | NFS Export |
|-------|-------------|------------|
| `htsai-model-backup` | `/mnt/htsai-model-backup` | `<nas>:/volume1/htsai-model-backup` |
| `htsai-docker-volume-backup` | `/mnt/htsai-docker-volume-backup` | `<nas>:/volume1/htsai-docker-volume-backup` |
| `htsai-timeshift-backup` | `/mnt/htsai-timeshift-backup` | `<nas>:/volume1/htsai-timeshift-backup` |
| `htsai-disk-image` | `/mnt/htsai-disk-image` | `<nas>:/volume1/htsai-disk-image` |

**NAS IP:** Resolve via `<nas>` hostname or `<nas-ip>`
**This machine IP:** `192.168.77.152` (ensure DHCP reservation is set)

---

## Verifying Backups

```bash
# List Timeshift snapshots
sudo timeshift --list

# List volume archives
ls -lh /mnt/htsai-docker-volume-backup/volumes/

# Check disk images
ls -lh /mnt/htsai-disk-image/
cat /mnt/htsai-disk-image/*.meta.txt

# Check model backup size
du -sh /mnt/htsai-model-backup/*

# Check config backups
ls /mnt/htsai-docker-volume-backup/configs/
```
