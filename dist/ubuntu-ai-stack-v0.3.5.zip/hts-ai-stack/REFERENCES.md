# References

## Core Services

- **OpenClaw**: https://openclaw.ai/
- **NemoClaw**: https://www.nvidia.com/en-us/ai/nemoclaw/
- **OpenShell**: https://docs.nvidia.com/openshell/latest/index.html
- **Ollama**: https://ollama.com/

## Folder Architecture

```text
hts-ai-stack/
│
├── bootstrap.sh                 # Entry point — curl | bash target; installs prereqs,
│                                #   clones repo, installs NVIDIA drivers (requires reboot)
├── install.sh                   # Wizard-style installer; runs after reboot from repo root
├── setup.sh                     # Supporting setup steps
├── docker-compose.yml           # Convenience root-level compose (delegates to docker/)
│
├── CLAUDE.md                    # AI assistant identity, rules, and routing
├── CONTEXT.md                   # Project overview and goals
├── REFERENCES.md                # Architecture, services, and key links (this file)
├── README.md                    # Public-facing project documentation
│
├── backups/                     # Backup automation scripts
│   ├── docker/                  #   Docker volume backup scripts
│   ├── synology/                #   Synology NAS mount + ActiveProtect agent setup
│   └── timeshift/               #   Timeshift snapshot configuration
│
├── config/                      # Runtime and wizard-generated configuration
│   ├── stack.json               #   Primary stack configuration
│   ├── tailscale-acl-policy.jsonc #  Tailscale ACL policy definition
│   ├── backups/                 #   Auto-generated timestamped config snapshots
│   │                            #     (one folder per install.sh run: YYYYMMDD-HHMMSS/)
│   └── wizard/                  #   Interactive wizard scripts for config generation
│
├── docker/                      # Docker Compose definitions and service configs
│   ├── docker-compose.yml       #   Primary compose file
│   ├── compose/                 #   Environment-specific overrides
│   │   ├── prod.yml             #     Production profile
│   │   ├── test.yml             #     Test profile
│   │   └── rtx3060.yml          #     RTX 3060 GPU profile
│   ├── deerflow/                #   DeerFlow service compose / config
│   └── modelfiles/              #   Ollama Modelfiles for custom model builds
│
├── docs/                        # All documentation
│   ├── CONTEXT.md               #   Documentation hub — routes to sub-folders
│   ├── DEPLOYMENT_VARIANTS.md   #   Deployment configuration options
│   ├── development/             #   Active development tracking
│   │   ├── testing-log.md       #     Manual test run log
│   │   ├── features/            #     Feature tracker — one FEATURE-###.md per feature
│   │   │   └── CONTEXT.md       #     Feature tracker conventions
│   │   └── issues/              #     In-flight issue notes
│   ├── guides/                  #   How-to guides (Tailscale, Signal, Telegram,
│   │                            #     Docker Model Engine, NFS, etc.)
│   ├── pipeline/                #   Step-by-step guides mirroring install script sequence
│   │                            #     (00-bootstrap → 07-setup-connectivity)
│   ├── planning/                #   Strategic planning and research
│   │   ├── CONTEXT.md           #     Planning hub — routes to sub-folders
│   │   ├── TODO.md              #     Backlog and priorities
│   │   ├── feature-repos/       #     Non-security repo tracking & review artifacts
│   │   │   ├── CONTEXT.md       #       Review workflow for feature repos
│   │   │   └── REFERENCES.md    #       Tracking table (agents, memory, platforms, etc.)
│   │   ├── repo-review/         #     Ecosystem repo review session state
│   │   │   ├── CONTEXT.md       #       Session handoff / review workflow
│   │   │   └── REFERENCES.md    #       Master curated repo list (all categories)
│   │   ├── security-repos/      #     Security repo tracking & review artifacts
│   │   │   ├── CONTEXT.md       #       Review workflow for security repos
│   │   │   ├── REFERENCES.md    #       ~45 security repos tracking table
│   │   │   └── results/         #       Per-repo review artifacts (owner-reponame.md)
│   │   ├── security-review/     #     Security architecture review session state
│   │   │   ├── CONTEXT.md       #       Threat model, findings, completed deliverables
│   │   │   └── REFERENCES.md    #       Complete threat model and findings
│   │   └── security-whitepapers/ #    arXiv paper tracking & review artifacts
│   │       ├── CONTEXT.md       #       Paper review workflow
│   │       └── REFERENCES.md    #       12 papers tracking table
│   └── refs/                    #   Legacy per-repo notes (see planning sub-folders)
│
├── instances/                   # Per-environment runtime configs
│   ├── prod/                    #   Production compose + model list
│   └── test/                    #   Test compose + model list
│
├── logs/                        # Runtime logs (gitignored)
│
├── resources/                   # Static assets served by the stack
│   ├── dashboard/               #   Nginx dashboard landing page (index.html)
│   └── nginx/                   #   Nginx configuration (robots.txt, robots.conf)
│
├── scripts/                     # Installation and utility scripts
│   ├── CONTEXT.md               #   Script goals and conventions
│   ├── bootstrap.sh             #   Repo-local copy of the bootstrap entry point
│   ├── build.sh                 #   Build script
│   ├── install.sh               #   Main installer (wizard-style)
│   ├── config/                  #   Script-side config storage (mirrors /config)
│   ├── install/                 #   Numbered install step scripts
│   │   ├── 01-autoinstall.sh    #     System auto-install / pre-config
│   │   ├── 02-setup-docker.sh   #     Docker + NVIDIA Container Toolkit setup
│   │   ├── 03-setup-models.sh   #     Ollama model download and configuration
│   │   ├── 04-setup-nemoclaw.sh #     NemoClaw sandbox setup
│   │   ├── 06-start-stack.sh    #     Start all services
│   │   ├── 06-stop-test-instances.sh # Stop test instances
│   │   ├── 07-setup-connectivity.sh  # Tailscale / networking finish
│   │   ├── comms/               #     Communication service setup (Signal, Telegram)
│   │   ├── models/              #     Model-specific download/config helpers
│   │   ├── networking/          #     Networking helpers
│   │   ├── system/              #     OS-level setup helpers
│   │   └── tooling/             #     Dev/ops tooling installation
│   ├── issuefixers/             #   One-off scripts to remediate known issues
│   ├── logs/                    #   Script execution logs
│   └── utils/                   #   Operator utilities
│                                #     reset-stack.sh (canonical),
│                                #     nuke-stack.sh (legacy shim), seed-model-cache.sh,
│                                #     teardown.sh, verify.sh
│
├── services/                    # Service-specific source / config outside Docker
│   └── bitnet/                  #   BitNet model service files
│
└── tests/                       # Pester test suite (PowerShell 7.6 / Pester 5.7.1)
    ├── CONTEXT.md               #   Test conventions and goals
    ├── Install-GitHooks.ps1     #   Git hook installer
    ├── Invoke-RepoChecks.ps1    #   Repo health check runner
    ├── Test-FrameworkStructure.Tests.ps1
    ├── Test-WorkspaceValidation.Tests.ps1
    ├── Test-ModelCache.Tests.ps1
    ├── Test-RepoChecks.Tests.ps1
    ├── Test-StackValidation.Tests.ps1
    └── validate-config-files.cjs #  Node.js config file validator
```
