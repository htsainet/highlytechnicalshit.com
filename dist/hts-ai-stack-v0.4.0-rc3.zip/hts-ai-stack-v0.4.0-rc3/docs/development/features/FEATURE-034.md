# FEATURE-034 — text-generation-webui (oobabooga)

## Metadata

| Field | Value |
|-------|-------|
| **Feature ID** | FEATURE-034 |
| **Title** | text-generation-webui — Local Inference Backend + Training UI |
| **Priority** | MEDIUM |
| **Effort** | 3–5 hours |
| **Risk** | Medium (AGPLv3; inference peer conflicts with Ollama on 12GB VRAM) |
| **Status** | Proposed |
| **Target** | v0.6.0 |
| **Depends on** | llama-swap routing (FEATURE-003) |
| **Blocks** | nothing |
| **Repo** | [oobabooga/text-generation-webui](https://github.com/oobabooga/text-generation-webui) |
| **License** | ⚠️ AGPLv3 |
| **Stars** | 46,474 |
| **Language** | Python (Gradio) |
| **Docker image** | Built from repo — `docker/nvidia/` |
| **UI port** | 7864 (remapped; default 7860 = Stable Diffusion) |
| **API port** | 5003 (remapped; default 5000 = OpenSpace MCP, 5001 = KoboldCpp) |

---

## Problem / Rationale

text-generation-webui (commonly "ooba") is the original local LLM GUI with
46k+ stars and daily commits. It is not simply a chat frontend — it is a
full **inference backend + training workbench + UI** with capabilities no other
component in the stack currently provides:

- **LoRA fine-tuning** — train task-specific adapters on local models
- **ExLlamaV3 backend** — faster GGUF inference than base llama.cpp for some
  models
- **HuggingFace Transformers backend** — load HF-format models directly without
  GGUF conversion or Ollama modelfiles
- **TensorRT-LLM backend** — maximum NVIDIA throughput (heavy; may not be
  worth deploying on RTX 3060 12GB)
- **Extensive extension ecosystem** — voice, translation, image gen, etc.
- OpenAI + Anthropic compatible API — peerable into llama-swap

---

## Stack Position

```text
Inference Tier (GPU — mutually exclusive on RTX 3060 12GB)
  ├─ Ollama          — production agent/chat workloads      (FEATURE-001)
  ├─ KoboldCpp       — creative/RP, Mirostat, long ctx      (FEATURE-031)
  └─ ooba            — fine-tuning, ExLlamaV3, HF models    (FEATURE-034)
        │
        └─ API (:5003/v1) → llama-swap peer (when active)

UI Tier (all point at llama-swap or direct)
  ├─ Open WebUI      (:3000)  FEATURE-001
  ├─ LibreChat       (:3080)  FEATURE-033
  └─ ooba Gradio UI  (:7864)  FEATURE-034  ← also a standalone UI
```

**Key distinction:** Unlike Open WebUI or LibreChat, ooba manages and runs its
own inference — it does not proxy to Ollama. It competes with Ollama for VRAM.
Profile-gated mutual exclusion (same pattern as KoboldCpp vs Ollama) is
required.

### Profile Strategy

| Profile | Containers up | Use case |
|---------|--------------|----------|
| `agent` | Ollama GPU | Day-to-day chat / agent workflows |
| `creative` | KoboldCpp | RP / long-context creative writing |
| `finetune` | ooba (GPU) | LoRA training / ExLlamaV3 / HF models |

---

## Capability Overview

| Capability | Detail |
|---|---|
| **LoRA fine-tuning** | Multi-turn chat or raw text datasets; resumable runs |
| **Inference backends** | llama.cpp, ik_llama.cpp, ExLlamaV3, HF Transformers, TensorRT-LLM |
| **OpenAI-compat API** | Chat, Completions, Messages + tool-calling |
| **Anthropic-compat API** | Messages endpoint |
| **MCP support** | Yes (tool-calling tutorial) |
| **Tool-calling** | Custom `.py` tools — web search, page fetch, math, etc. |
| **Vision** | Attach images for multimodal understanding |
| **File attachments** | PDF, DOCX, plain text |
| **Image generation** | `diffusers` tab — Z-Image-Turbo, 4-bit/8-bit quant |
| **Training tab** | LoRA adapter training on HF/GGUF base models |
| **Extensions** | TTS, STT, voice input, translation, etc. |
| **Model switching** | Switch models + backends without restart |
| **100% offline** | Zero telemetry, no remote resources |

---

## Architecture

```text
Browser → ooba Gradio UI (:7864)
                │
                └─ Python server
                      ├─ llama.cpp backend (GGUF)
                      ├─ ExLlamaV3 backend (GGUF/EXL2)
                      ├─ HF Transformers backend (FP16/4-bit)
                      └─ OpenAI-compat API (:5003/v1)
                                │
                          (when active)
                                └─ llama-swap peer → hts-ai-llama-swap:8081/v1
```

---

## Port Assignment

| Port | Purpose |
|------|---------|
| 7864 | ooba Gradio web UI |
| 5003 | ooba OpenAI-compat API |

Both ports are clear in the Host Port Map (checked 2026-04-12).

---

## Docker Service Sketch

```yaml
hts-ai-ooba:
  build:
    context: .
    dockerfile: docker/nvidia/Dockerfile
  container_name: hts-ai-ooba
  profiles: [finetune]
  ports:
    - "${OOBA_UI_PORT:-7864}:7860"
    - "${OOBA_API_PORT:-5003}:5000"
  environment:
    EXTRA_LAUNCH_OPTIONS: "--api --listen --listen-port 7860 --api-port 5000"
  volumes:
    - ooba-models:/app/models
    - ooba-loras:/app/loras
    - ooba-characters:/app/characters
    - ooba-user-data:/app/user_data
  deploy:
    resources:
      reservations:
        devices:
          - driver: nvidia
            count: 1
            capabilities: [gpu]
  restart: unless-stopped
```

**Note:** ooba does not have a published Docker image on a registry — it must be
built from the repo. The build is heavy (~10GB with PyTorch). Evaluate whether
a pre-built community image (e.g., `atinoda/text-generation-webui`) is
preferable for the stack.

---

## Implementation Steps

1. Create `docs/development/features/FEATURE-034.md` (this file)
2. Add ports 7864 and 5003 to `REFERENCES.md` Host Port Map
3. Add `FEATURE-034` row to `docs/development/features/REFERENCES.md` v0.6.0 table
4. Add `oobabooga/text-generation-webui` row to `docs/planning/feature-repos/REFERENCES.md`
5. Write `scripts/components/ooba/ooba.sh` — `ooba_install`, `ooba_configure`,
   `ooba_start`, `ooba_stop`, `ooba_health`
6. Add `docker-compose.yml` service `hts-ai-ooba` under profile `finetune`
7. Add llama-swap peer entry for ooba API when `finetune` profile is active
   (conditional; ooba and Ollama are mutually exclusive on 12GB VRAM)
8. Add `.env.example` vars: `OOBA_UI_PORT`, `OOBA_API_PORT`
9. Evaluate community image `atinoda/text-generation-webui` vs building from source
10. Validate: `curl http://localhost:7864` renders Gradio UI;
    `curl http://localhost:5003/v1/models` returns model list

---

## Acceptance Criteria

- [ ] ooba Gradio UI loads on port 7864
- [ ] A GGUF model loads successfully via llama.cpp backend
- [ ] OpenAI-compat API responds at port 5003
- [ ] LoRA training tab is accessible (does not need to complete a full run)
- [ ] `docker compose --profile finetune up` / `down` cycle is clean
- [ ] Ollama is confirmed down when `finetune` profile is active (VRAM guard)

---

## License Note

⚠️ **AGPLv3** — same tier as KoboldCpp (FEATURE-031) and Agnai (FEATURE-032).
Private self-hosted use is acceptable. If the stack is ever exposed publicly
or used in a multi-tenant SaaS context, source disclosure is required.

---

## VRAM Constraint

RTX 3060 = **12GB VRAM**. ooba, Ollama, and KoboldCpp cannot all run
simultaneously. Enforce mutual exclusion via Docker profiles:

```text
finetune profile UP   → ooba active   (Ollama + KoboldCpp must be stopped)
agent profile UP      → Ollama active (ooba + KoboldCpp must be stopped)
creative profile UP   → KoboldCpp     (ooba + Ollama must be stopped)
```

---

## Notes

- **Community Docker image:** `atinoda/text-generation-webui` on Docker Hub
  provides pre-built images and is widely used. Check license compliance before
  adopting.
- **TensorRT-LLM backend:** Extremely high-performance but requires TensorRT
  installation and model compilation. Likely overkill for RTX 3060 12GB;
  skip during initial deployment.
- **llama-swap integration:** ooba's API port can be added as a peer in
  `config/llama-swap.yaml` alongside Ollama and KoboldCpp. Only do this
  when `finetune` profile is active — a dead peer will cause llama-swap 502s.
- **Fine-tuning workflow:** LoRA training runs on GPU. For a 7B model with
  12GB VRAM, expect to use 4-bit quantization (`bnb-4bit`) as the base.
