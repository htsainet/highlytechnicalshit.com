#!/usr/bin/env bash
# NemoClaw -> llama-swap -> Ollama / BitNet wiring guide
# ======================================================
# NemoClaw does NOT talk directly to BitNet.
# The sandbox uses one OpenAI-compatible provider that points at llama-swap:
#
#   sandbox -> host.openshell.internal:8081/v1 -> llama-swap -> Ollama or BitNet
#
# The backend is chosen by model name. Examples:
#   - gemma4:e4b -> Ollama GPU
#   - bitnet     -> BitNet CPU
# ======================================================

SANDBOX="${SANDBOX:-hts-ai-openshell-nemoclaw}"
LLAMA_SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"
HOST_SWAP_URL="http://localhost:${LLAMA_SWAP_PORT}/v1"
SANDBOX_SWAP_URL="http://host.openshell.internal:${LLAMA_SWAP_PORT}/v1"
HOST_TEST_MODEL="${HOST_TEST_MODEL:-smollm2:135m}"
GPU_MODEL="${GPU_MODEL:-gemma4:e4b}"
CPU_MODEL="${CPU_MODEL:-bitnet}"

# 1. VERIFY LLAMA-SWAP ON THE HOST
# ─────────────────────────────────
curl -sf "http://localhost:${LLAMA_SWAP_PORT}/health" && echo "llama-swap OK"

# Minimal completion probe (preferred over /v1/models for auth-sensitive setups):
curl -fsS \
  -H 'Authorization: Bearer not-needed' \
  -H 'Content-Type: application/json' \
  -d "{\"model\":\"${HOST_TEST_MODEL}\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"max_tokens\":1,\"stream\":false}" \
  "${HOST_SWAP_URL}/chat/completions"


# 2. REGISTER / UPDATE THE SANDBOX PROVIDER
# ──────────────────────────────────────────
# Run on the HOST (not inside the sandbox).
# host.openshell.internal resolves to the host from inside the sandbox.

if openshell provider list | grep -q "compatible-endpoint"; then
  openshell provider update compatible-endpoint \
    --config "OPENAI_BASE_URL=${SANDBOX_SWAP_URL}"
fi

if openshell provider list | grep -q "llama-swap-local"; then
  openshell provider update llama-swap-local \
    --config "baseUrl=${SANDBOX_SWAP_URL}"
else
  openshell provider create \
    --name llama-swap-local \
    --type openai \
    --credential OPENAI_API_KEY=not-needed \
    --config "baseUrl=${SANDBOX_SWAP_URL}"
fi

openshell provider list


# 3. ROUTE THE SANDBOX THROUGH LLAMA-SWAP
# ────────────────────────────────────────
# Ollama path (GPU) — selected by model name through llama-swap:
nemoclaw "${SANDBOX}" connect -- \
  openclaw config set agents.defaults.model.primary "llama-swap-local/${GPU_MODEL}"

# BitNet path (CPU) — same provider, different model name:
nemoclaw "${SANDBOX}" connect -- \
  openclaw config set agents.defaults.model.primary "llama-swap-local/${CPU_MODEL}"


# 4. UFW RULES (ONLY IF UFW IS ENABLED)
# ─────────────────────────────────────
# Allow OpenShell / Docker bridge traffic to reach llama-swap on the host.
sudo ufw allow proto tcp from 172.18.0.0/16 to any port "${LLAMA_SWAP_PORT}" comment 'OpenShell -> llama-swap'
sudo ufw allow proto tcp from 172.17.0.0/16 to any port "${LLAMA_SWAP_PORT}" comment 'Docker bridge -> llama-swap'


# 5. NETWORK POLICY ONLY FOR REAL CONNECTIVITY FAILURES
# ──────────────────────────────────────────────────────
# Do NOT treat HTTP 403 from /v1/models as proof that policy is missing.
# Investigate policy only for DNS failures, timeouts, connection refused, or
# explicit policy-block symptoms. If you truly need to add an endpoint rule,
# the shape is:
#
#   - name: llama-swap
#     host: host.openshell.internal
#     port: 8081
#     protocol: rest
#     enforcement: enforce
#     rules:
#       - allow: { method: "*", path: "/v1/**" }
#     binaries:
#       - { path: /usr/local/bin/openclaw }


# 6. TEST THE ACTIVE MODEL PATH
# ─────────────────────────────
nemoclaw "${SANDBOX}" connect -- \
  openclaw agent --agent main --local \
    -m "Reply with the model/provider you are using." \
    --session-id test
