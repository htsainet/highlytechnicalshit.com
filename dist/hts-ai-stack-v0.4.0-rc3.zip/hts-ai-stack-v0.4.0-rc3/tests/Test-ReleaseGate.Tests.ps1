$ErrorActionPreference = 'Stop'

<#
.SYNOPSIS
    Release-gate Pester test — run before tagging a new release.
    Performs a deep documentation and hygiene sweep beyond everyday checks.

.DESCRIPTION
    This test is NOT part of the pre-commit or repo-checks pipeline.
    Run it manually when preparing to ship:

        pwsh -Command "Invoke-Pester tests/Test-ReleaseGate.Tests.ps1 -Output Detailed"

    It validates:
    - Release plan gate checklist is fully checked off
    - Feature files ↔ REFERENCES.md are in sync
    - Feature Target Release metadata matches REFERENCES.md placement
    - No phantom or orphaned features
    - Open issues are acknowledged in the release plan
    - Closed/fixed issues have been archived (removed from repo)
    - CONTEXT.md timestamps are fresh (≤ 30 days)
    - All everyday Pester tests pass (meta-check)
#>

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:FeaturesDir = Join-Path $script:RepoRoot 'docs/development/features'
    $script:FeaturesRef = Join-Path $script:FeaturesDir 'REFERENCES.md'
    $script:IssueFile = Join-Path $script:RepoRoot 'docs/development/issues/setup-issues.md'
    $script:PlanningDir = Join-Path $script:RepoRoot 'docs/planning'
}

Describe 'Release gate' {

    Context 'Release plan readiness' {

        BeforeAll {
            # Find the latest RELEASE-v*.md that is "In Progress"
            $script:ReleasePlan = $null
            $script:ReleasePlanFile = $null
            $script:UncheckedGates = [System.Collections.Generic.List[string]]::new()

            $releasePlans = Get-ChildItem -Path $script:PlanningDir -Filter 'RELEASE-v*.md' -File -ErrorAction SilentlyContinue
            foreach ($plan in $releasePlans) {
                $content = Get-Content $plan.FullName -Raw
                if ($content -match '(?i)\*\*Status:\*\*\s*In\s*Progress') {
                    $script:ReleasePlan = $content
                    $script:ReleasePlanFile = $plan
                    break
                }
            }

            if ($script:ReleasePlan) {
                # Find unchecked gate items: lines matching "- [ ]"
                $lines = Get-Content $script:ReleasePlanFile.FullName
                $inGateSection = $false
                foreach ($line in $lines) {
                    if ($line -match '##.*Gate\s*Checklist') { $inGateSection = $true; continue }
                    if ($line -match '^##\s' -and $inGateSection) { break }
                    if ($inGateSection -and $line -match '^\s*-\s*\[\s\]') {
                        $item = ($line -replace '^\s*-\s*\[\s\]\s*', '').Trim()
                        $script:UncheckedGates.Add($item)
                    }
                }
            }
        }

        It 'an In Progress release plan exists' {
            $script:ReleasePlanFile | Should -Not -BeNullOrEmpty -Because 'there must be a RELEASE-v*.md with Status: In Progress'
        }

        It 'release plan gate checklist is fully checked off' {
            if ($script:UncheckedGates.Count -gt 0) {
                $detail = $script:UncheckedGates -join "`n  "
                "Unchecked gates in $($script:ReleasePlanFile.Name):`n  $detail" |
                    Should -Be '' -Because 'all gate checklist items must be completed before release'
            }
        }
    }

    Context 'Feature ↔ REFERENCES.md sync' {

        BeforeAll {
            $script:OrphanedFeatures = [System.Collections.Generic.List[string]]::new()
            $script:PhantomRefs = [System.Collections.Generic.List[string]]::new()
            $script:MismatchedTargets = [System.Collections.Generic.List[string]]::new()

            # --- Parse REFERENCES.md for feature entries ---
            $script:RefEntries = @{}   # filename → release section
            $currentSection = 'Unknown'

            if (Test-Path $script:FeaturesRef) {
                $refLines = Get-Content $script:FeaturesRef
                foreach ($line in $refLines) {
                    # Track which release section we're in
                    if ($line -match '^##\s+.*\((v\d+\.\d+\.\d+)\)') {
                        $currentSection = $Matches[1]
                    }
                    # Match table rows referencing FEATURE-###.md
                    if ($line -match '\[(FEATURE-\d+\.md)\]') {
                        $script:RefEntries[$Matches[1]] = $currentSection
                    }
                }
            }

            # --- Scan feature files ---
            $featureFiles = Get-ChildItem -Path $script:FeaturesDir -Filter 'FEATURE-*.md' -File -ErrorAction SilentlyContinue

            foreach ($file in $featureFiles) {
                # Orphaned: file exists but not in REFERENCES.md
                if (-not $script:RefEntries.ContainsKey($file.Name)) {
                    $script:OrphanedFeatures.Add($file.Name)
                }

                # Target Release mismatch: file says one version, REFERENCES.md lists under another
                $content = Get-Content $file.FullName -Raw
                if ($content -match '\*?\*?Target Release\*?\*?:\s*.*?(v\d+\.\d+\.\d+)') {
                    $fileTarget = $Matches[1]
                    $refSection = $script:RefEntries[$file.Name]
                    if ($refSection -and $refSection -ne $fileTarget) {
                        $script:MismatchedTargets.Add("$($file.Name): file says $fileTarget but REFERENCES.md has it under $refSection")
                    }
                }
            }

            # Phantom: in REFERENCES.md but file doesn't exist
            foreach ($refFile in $script:RefEntries.Keys) {
                $path = Join-Path $script:FeaturesDir $refFile
                if (-not (Test-Path $path)) {
                    $script:PhantomRefs.Add($refFile)
                }
            }
        }

        It 'REFERENCES.md exists' {
            $script:FeaturesRef | Should -Exist
        }

        It 'no orphaned feature files (missing from REFERENCES.md)' {
            if ($script:OrphanedFeatures.Count -gt 0) {
                $detail = $script:OrphanedFeatures -join ', '
                "Orphaned features not in REFERENCES.md: $detail" |
                    Should -Be '' -Because 'every FEATURE-###.md must be listed in REFERENCES.md'
            }
        }

        It 'no phantom REFERENCES.md entries (file does not exist)' {
            if ($script:PhantomRefs.Count -gt 0) {
                $detail = $script:PhantomRefs -join ', '
                "Phantom entries in REFERENCES.md: $detail" |
                    Should -Be '' -Because 'every REFERENCES.md entry must point to an existing FEATURE-###.md'
            }
        }

        It 'feature Target Release matches REFERENCES.md section placement' {
            if ($script:MismatchedTargets.Count -gt 0) {
                $detail = $script:MismatchedTargets -join "`n  "
                "Mismatched:`n  $detail" |
                    Should -Be '' -Because 'Target Release in the feature file must match the REFERENCES.md release section'
            }
        }
    }

    Context 'Issue hygiene — release readiness' {

        BeforeAll {
            $script:LingeringFixed = [System.Collections.Generic.List[string]]::new()

            if (Test-Path $script:IssueFile) {
                $lines = Get-Content $script:IssueFile
                $current = $null

                foreach ($line in $lines) {
                    if ($line -match '^###\s+((?:ISSUE|FEATURE-ADD)-\d+)\s*$') {
                        if ($current) {
                            # Check: issues with "fixed" status (not pending-review) should be archived
                            if ($current.Status -match '^\s*fixed\b' -and $current.Status -notmatch 'pending-review') {
                                $script:LingeringFixed.Add("$($current.Id) — Status: $($current.Status)")
                            }
                        }
                        $current = @{ Id = $Matches[1]; Status = '' }
                    }
                    if ($current -and $line -match '^\s*-\s*Status:\s*(.+)') {
                        $current.Status = $Matches[1].Trim()
                    }
                }
                # Process last block
                if ($current -and $current.Status -match '^\s*fixed\b' -and $current.Status -notmatch 'pending-review') {
                    $script:LingeringFixed.Add("$($current.Id) — Status: $($current.Status)")
                }
            }
        }

        It 'no resolved issues still lingering in setup-issues.md' {
            if ($script:LingeringFixed.Count -gt 0) {
                $detail = $script:LingeringFixed -join "`n  "
                "Issues that should be archived (removed):`n  $detail" |
                    Should -Be '' -Because 'fixed issues should be removed from setup-issues.md before release — the fix lives in git history'
            }
        }
    }

    Context 'CONTEXT.md freshness (≤ 30 days for release)' {

        BeforeAll {
            $script:StaleContextFiles = [System.Collections.Generic.List[string]]::new()
            $thirtyDaysAgo = (Get-Date).AddDays(-30)

            $allContexts = Get-ChildItem -Path $script:RepoRoot -Filter 'CONTEXT.md*' -Recurse -File
            foreach ($ctx in $allContexts) {
                $content = Get-Content $ctx.FullName -Raw
                if ($content -match 'Last updated[:\s]+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})') {
                    $stamp = [DateTime]::ParseExact($Matches[1], 'yyyy-MM-dd HH:mm:ss', $null)
                    if ($stamp -lt $thirtyDaysAgo) {
                        $relPath = $ctx.FullName.Substring($script:RepoRoot.Length + 1)
                        $daysOld = ([DateTime]::Now.Date - $stamp.Date).Days
                        $script:StaleContextFiles.Add("$relPath — last updated $($Matches[1]) ($daysOld days ago)")
                    }
                }
            }
        }

        It 'all CONTEXT.md timestamps are within 30 days' {
            if ($script:StaleContextFiles.Count -gt 0) {
                $detail = $script:StaleContextFiles -join "`n  "
                "Stale CONTEXT.md files:`n  $detail" |
                    Should -Be '' -Because 'all CONTEXT.md timestamps must be refreshed within 30 days before release'
            }
        }
    }

    Context 'Everyday Pester suite is green' {

        BeforeAll {
            # Run all other test files (excluding this one) to confirm the everyday suite passes
            $script:EverydayTests = @(
                Get-ChildItem -Path $PSScriptRoot -Filter '*.Tests.ps1' -File |
                    Where-Object { $_.Name -ne 'Test-ReleaseGate.Tests.ps1' }
            )

            $script:FailedTests = [System.Collections.Generic.List[string]]::new()

            if ($script:EverydayTests.Count -gt 0) {
                $config = [PesterConfiguration]::Default
                $config.Run.Path = $script:EverydayTests.FullName
                $config.Run.PassThru = $true
                $config.Output.Verbosity = 'None'

                $result = Invoke-Pester -Configuration $config

                foreach ($test in $result.Tests) {
                    if ($test.Result -eq 'Failed') {
                        $script:FailedTests.Add("$($test.ExpandedPath)")
                    }
                }
            }
        }

        It 'all everyday Pester tests pass' {
            if ($script:FailedTests.Count -gt 0) {
                $detail = $script:FailedTests -join "`n  "
                "Failing everyday tests:`n  $detail" |
                    Should -Be '' -Because 'all pre-existing Pester tests must pass before release'
            }
        }
    }
}
