#!/usr/bin/env bash
# scripts/components/flowise/flowise.sh — Flowise LLM workflow builder
#
# Standalone usage:
#   ./scripts/components/flowise/flowise.sh              # full: install + configure + start + health
#   ./scripts/components/flowise/flowise.sh --install    # install only
#   ./scripts/components/flowise/flowise.sh --configure  # configure only
#   ./scripts/components/flowise/flowise.sh --start      # start only
#   ./scripts/components/flowise/flowise.sh --stop       # stop
#   ./scripts/components/flowise/flowise.sh --restart    # restart (stop + start)
#   ./scripts/components/flowise/flowise.sh --health     # health check only
#   ./scripts/components/flowise/flowise.sh --status     # show status + port + health
#   ./scripts/components/flowise/flowise.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

load_env
FLOWISE_PORT="${FLOWISE_PORT:-3005}"
FLOWISE_CONTAINER="${FLOWISE_CONTAINER:-hts-ai-flowise-1}"

# ── Lifecycle functions ───────────────────────────────────────────────────────

flowise_install() {
  step "Flowise — install"
  compose_build --profile flowise flowise
  ok "Flowise image built."
}

flowise_configure() {
  step "Flowise — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^FLOWISE_PORT=" "$env_file" 2>/dev/null; then
    printf 'FLOWISE_PORT=%s\n' "$FLOWISE_PORT" >> "$env_file"
    info "Added FLOWISE_PORT=${FLOWISE_PORT} to .env"
  fi

  ok "Flowise configured (port ${FLOWISE_PORT})."
}

flowise_start() {
  step "Flowise — start"
  compose_up --profile flowise flowise
  ok "Flowise started on port ${FLOWISE_PORT}."
}

flowise_stop() {
  step "Flowise — stop"
  compose_down --profile flowise flowise
  ok "Flowise stopped."
}

flowise_health() {
  health_probe "Flowise :${FLOWISE_PORT}" "http://localhost:${FLOWISE_PORT}/api/v1/ping"
}

flowise_restart() {
  flowise_stop
  flowise_start
}

flowise_destroy() {
  step "Flowise — destroy"
  compose_down --profile flowise flowise -v
  ok "Flowise destroyed."
}

flowise_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=flowise" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Flowise is running (port ${FLOWISE_PORT})"
  else
    warn "Flowise is not running."
  fi
  flowise_health 2>/dev/null || true
}

# ── Standalone execution ──────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   flowise_install   ;;
    configure) flowise_configure ;;
    start)     flowise_start     ;;
    stop)      flowise_stop      ;;
    restart)   flowise_restart   ;;
    health)    flowise_health    ;;
    status)    flowise_status    ;;
    destroy)   flowise_destroy   ;;
    default)
      flowise_install
      flowise_configure
      flowise_start
      flowise_health
      ;;
  esac
fi
