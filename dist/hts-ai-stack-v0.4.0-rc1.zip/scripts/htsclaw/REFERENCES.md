# htsclaw — Architecture and Interoperability Reference

Last updated: 2026-04-11 23:11:00

Quick-reference for how OpenShell, OpenClaw, and htsclaw fit together.
Covers permission models, policy semantics, inference routing, and the
interop lessons learned during integration.

For upstream source-level detail (SSRF guard internals, config schema fields,
debugging commands) see
[docs/guides/htsclaw-integration-reference.md](../../docs/guides/htsclaw-integration-reference.md).

## Three-Layer Security Model

The sandbox enforces security at three independent layers. A request must
pass all three to succeed.

```text
┌─────────────────────────────────────────────────────────┐
│ Layer 1: Landlock LSM (filesystem)                      │
│   Read-only: /usr, /lib, /etc, /proc, /app, /var/log   │
│   Read-write: /sandbox, /tmp, /dev/null                 │
│   Effect: global npm installs fail (EACCES)             │
└──────────────────────────┬──────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────┐
│ Layer 2: OpenShell Proxy (network)                      │
│   Every outbound connection goes through 10.200.0.1     │
│   Matched against network_policies (host+port+binary)   │
│   Unmatched → DENY (fail-closed)                        │
│   inference.local handled separately by privacy router  │
└──────────────────────────┬──────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────┐
│ Layer 3: OpenClaw SSRF Guard (application)              │
│   fetchWithSsrFGuard() wraps every model request        │
│   DNS-resolves hostname → checks against blocklists     │
│   Rejects .local TLDs, private IPs, loopback by default │
│   Bypassed with allowPrivateNetwork + dns-hook.js       │
└─────────────────────────────────────────────────────────┘
```

### Consequence Matrix

What each layer blocks and how we work around it:

| Blocked action | Layer | Symptom | Workaround |
|----------------|-------|---------|------------|
| `npm install -g openclaw` | Landlock | `EACCES /usr/lib/node_modules` | `npm install --prefix /sandbox` |
| Write to `/etc/hosts` | Landlock | `EACCES /etc/hosts` | DNS hook via `NODE_OPTIONS` |
| Connect to `inference.local` | SSRF Guard | `Connection error` (DNS fail) | `dns-hook.js` returns 10.200.0.1 |
| Connect to `.local` TLD | SSRF Guard | `SsrFBlockedError` | `allowPrivateNetwork: true` |
| Connect to private IP | SSRF Guard | `SsrFBlockedError` | `allowPrivateNetwork: true` |
| Route through proxy | SSRF Guard | Direct connect fails | `proxy: { mode: "env-proxy" }` |
| Reach unlisted endpoint | Proxy | `403 connection not allowed by policy` | Add to `openclaw-sandbox.yaml` |
| Reach endpoint from wrong binary | Proxy | `403 connection not allowed by policy` | Add binary path to policy group |

## OpenShell Policy Semantics

### Static vs Dynamic

| Section | When applied | Change method |
|---------|-------------|---------------|
| `filesystem_policy` | Sandbox creation only | Destroy + recreate |
| `landlock` | Sandbox creation only | Destroy + recreate |
| `process` | Sandbox creation only | Destroy + recreate |
| `network_policies` | Hot-reloadable | `openshell policy set --policy <file> <sandbox> --wait` |

### Network Policy Rules

- **Full replacement** — `openshell policy set` replaces ALL groups, not
  additive. Missing a group = removing it.
- **Default deny** — connections to unlisted host:port pairs are blocked.
- **Binary enforcement** — the binary making the connection must match a
  `binaries.path` entry in the same group.
- **Glob paths** — `/**` matches any binary, `/usr/lib/node_modules/openclaw/**`
  matches the full tree.
- **`protocol: rest`** — enables HTTP method/path inspection. The proxy
  auto-terminates TLS to inspect headers. Without this, the TCP stream
  passes through uninspected.
- **Credential injection** — the proxy replaces sentinel tokens with real
  credentials. Only works with `protocol: rest` (needs TLS termination).
- **`inference.local` is special** — handled by the privacy router, NOT
  the network policy engine. It still needs a policy entry because the
  proxy enforces binary allowlists on ALL connections.

### Our Policy Groups

| Group | Purpose | Binary scope |
|-------|---------|--------------|
| `inference_local` | Privacy router virtual host | `/**` (any — OpenClaw spawns subprocesses) |
| `llama-swap` | Direct LLM API on host | `openclaw`, `node`, `curl` |
| `npm-registry` | OpenClaw upgrades (read-only) | `openclaw`, `node` |
| `claude_code` | Sandbox default — Claude Code | `claude`, `node` |
| `github` | Sandbox default — git fetch | `git` |
| `github_rest_api` | Sandbox default — GitHub API | `claude`, `gh` |
| `gitlab` | Sandbox default — GitLab | `glab` |
| `nvidia` | Sandbox default — NVIDIA API | `curl`, `bash`, `opencode` |
| `nvidia_web` | Sandbox default — NVIDIA website | `curl` |

### Binary Path Gotchas

- Sandbox ships OpenClaw at `/usr/bin/openclaw` (v2026.3.11)
- We install locally to `/sandbox/node_modules/.bin/openclaw` (v2026.4.x+)
- Both paths fork to `/usr/bin/node` at runtime
- Policy entries must cover ALL binary paths in the call chain
- When in doubt, `/**` works but is less restrictive

## OpenClaw Permissions (Inside Sandbox)

### User Context

| Process | User | UID:GID |
|---------|------|---------|
| Sandbox agent (`openshell-sandbox`) | root | 0:0 |
| OpenClaw gateway | sandbox | 1000:1000 |
| CLI commands via `openshell sandbox exec` | sandbox | 1000:1000 |
| Root exec via `_htsclaw_root_exec()` | root | 0:0 |

### Filesystem Ownership

| Path | Owner | Why |
|------|-------|-----|
| `/sandbox/.openclaw/openclaw.json` | root | Created by root exec (config patch) |
| `/sandbox/.openclaw/agents/<id>/` | sandbox | **Must be sandbox** — gateway writes sessions here |
| `/sandbox/.openclaw-data/workspace-<agent>/` | sandbox | Persona files uploaded via `openshell upload` |
| `/sandbox/dns-hook.js` | sandbox | Uploaded via `openshell upload` |
| `/sandbox/node_modules/` | sandbox | Created by `npm install --prefix /sandbox` |
| `/tmp/openclaw-gw.log` | sandbox | Gateway stdout/stderr |

### Common Permission Errors

| Error | Cause | Fix |
|-------|-------|-----|
| `EACCES: mkdir sessions` | Agent dir owned by root | `chown -R sandbox:sandbox` after root exec |
| `EACCES: /usr/lib/node_modules` | Landlock read-only | Use `--prefix /sandbox` for npm |
| `EACCES: /etc/hosts` | Landlock read-only | DNS hook via NODE_OPTIONS |
| `Permission denied: /proc/<pid>/environ` | Sandbox user can't read own `/proc` | Use `cat /proc/self/environ` instead |

### Root Exec Pattern

Some operations need root because the sandbox user can't modify
root-owned files (like `openclaw.json`). Use `_htsclaw_root_exec()`:

```bash
_htsclaw_root_exec "$sandbox" "exec-id-prefix" <command> [args...]
```

This finds the containerd task for the sandbox and runs a command as uid 0.
**Always chown created files to sandbox:sandbox** so the gateway can use them.

## Inference Routing — How It Actually Works

```text
OpenClaw SDK request
  → baseURL: https://inference.local/v1
  → dns-hook.js resolves inference.local → 10.200.0.1
  → SSRF guard passes (DNS succeeded + allowPrivateNetwork)
  → EnvHttpProxyAgent sends CONNECT to 10.200.0.1:3128
  → OpenShell proxy checks network_policies (binary + host match)
  → Privacy router intercepts inference.local:
      - Strips sandbox API key (sentinel placeholder)
      - Injects real provider credentials
      - Rewrites model name to configured model
      - Forwards to upstream (host.openshell.internal:8081)
  → llama-swap serves the request
  → Response streams back through the same tunnel
```

### Critical Configuration

| Setting | Value | Why |
|---------|-------|-----|
| `baseUrl` | `https://inference.local/v1` | Must include `/v1` — SDK appends `/responses` |
| `allowPrivateNetwork` | `true` | Bypass SSRF hostname and IP blocklists |
| `proxy.mode` | `env-proxy` | Route through `HTTPS_PROXY` to privacy router |
| `NODE_OPTIONS` | `--require /sandbox/dns-hook.js` | Make `inference.local` DNS-resolvable |
| Provider base URL | `http://host.openshell.internal:8081/v1` | NOT localhost — request comes from gateway container |

### What Happens Without Each Piece

| Missing | Result |
|---------|--------|
| `/v1` in baseUrl | Privacy router gets `/responses` → 404 |
| `allowPrivateNetwork` | SSRF guard blocks `.local` TLD → `SsrFBlockedError` |
| `proxy.mode` | Direct connect attempt → network policy denial |
| DNS hook | DNS lookup fails → `EAI_AGAIN` → `Connection error` |
| `inference_local` policy entry | Proxy blocks connection → `403 policy` |

## OpenClaw Version Interop

| Version | Ships with | Supports |
|---------|-----------|----------|
| 2026.3.11 | Sandbox image (global `/usr/bin/openclaw`) | Basic providers, `api` field |
| 2026.4.x+ | Local install (`/sandbox/node_modules/.bin/openclaw`) | `request.proxy`, `request.allowPrivateNetwork` |

The sandbox image will eventually be updated (tracked in
[NVIDIA/NemoClaw#1685](https://github.com/NVIDIA/NemoClaw/issues/1685)).
Until then, every sandbox creation installs OpenClaw locally.

### Version Check

```bash
# Global (stale)
openshell sandbox exec -g htsclaw -n <sandbox> -- openclaw --version

# Local (current)
openshell sandbox exec -g htsclaw -n <sandbox> -- \
  /sandbox/node_modules/.bin/openclaw --version
```

## Gateway Lifecycle

### Start Sequence

1. Upload `dns-hook.js` to `/sandbox/dns-hook.js`
2. `npm install --prefix /sandbox openclaw@latest` (ensures 2026.4.x+)
3. Set `NODE_OPTIONS="--require /sandbox/dns-hook.js"`
4. Start `/sandbox/node_modules/.bin/openclaw gateway run --port 18792 --bind loopback --auth none`
5. Background the process, record PID
6. Wait for healthcheck at `http://127.0.0.1:18792/healthz`

### Restart Sequence

1. Kill gateway process (via PID or `pkill -f openclaw.*gateway`)
2. Wait 3 seconds (let port release)
3. Repeat start sequence (re-uploads dns-hook, re-installs, re-starts)
4. Wait for healthcheck

### No Supervisor

The gateway has **no process supervisor**. If it crashes or receives SIGTERM,
it stays dead until manually restarted. The health timer in
`scripts/htsclaw/health/` checks liveness and can restart it.

### Gateway Is Not the Sandbox

| Concept | What it is |
|---------|-----------|
| Gateway container | Docker container running k3s (`openshell-cluster-htsclaw`) |
| Sandbox | Pod inside the gateway's k3s cluster |
| OpenClaw gateway | Node.js process inside the sandbox pod |
| Port forward | `openshell forward` maps host:18792 → sandbox:18792 |

Restarting the OpenClaw gateway (Node.js) doesn't affect the sandbox or
gateway container. Restarting the gateway container destroys the sandbox.

## Interop Lessons Learned

### Things That Look Like Bugs But Aren't

- **Ollama probe to 127.0.0.1:11434** — OpenClaw auto-detects local Ollama
  at startup. Harmless, fails silently.
- **`tls: terminate` deprecation warnings** — sandbox defaults use old syntax.
  Functional, just noisy. Tracked in
  [NVIDIA/NemoClaw#1686](https://github.com/NVIDIA/NemoClaw/issues/1686).
- **WebSocket 1006 on CLI agent** — gateway WebSocket closes abnormally for
  CLI-based agent sessions. Falls back to embedded mode (works fine).
- **`openshell sandbox get htsclaw` fails** — must use full name
  `hts-ai-openshell-htsclaw-gpu`, not the gateway name.

### Things That Are Actually Bugs (With Workarounds)

| Issue | Root cause | Workaround |
|-------|-----------|------------|
| Global npm blocked | Landlock on `/usr/lib` | `npm install --prefix /sandbox` |
| `inference.local` DNS fails | No DNS record in sandbox | `dns-hook.js` via NODE_OPTIONS |
| SSRF blocks private IPs | STRICT mode default | `allowPrivateNetwork: true` |
| Agent session dirs EACCES | Root exec creates root-owned dirs | `chown -R sandbox:sandbox` |
| Config changes kill gateway | `SIGUSR1` → restart → sometimes SIGTERM | Health timer restarts dead gateway |
| Stale OpenClaw in image | Image pins 2026.3.11 | Local npm install on every create |

### NemoClaw vs htsclaw

| Aspect | NemoClaw | htsclaw |
|--------|----------|---------|
| CLI | `nemoclaw` wrapper | Direct `openshell` calls |
| Setup | Interactive wizard | Scripted (lifecycle.sh) |
| OpenClaw version | Whatever ships in image | Local install (2026.4.x+) |
| Policy management | Presets | Custom YAML in Git |
| Gateway name | `nemoclaw` | `htsclaw` |
| Default port | 18789 | 18792 |
| Coexistence | Cannot share gateway | Cannot share gateway |
| Inference config | Via wizard | Via `openclaw.json` + provider |
| Can share a host | Yes | Yes (different gateway containers) |
