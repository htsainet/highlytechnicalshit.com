# FEATURE-046 — LanguageTool Grammar & Style Checker

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | MEDIUM |
| **Effort** | 1–2 hours |
| **Risk** | Low — single container, no GPU, no external dependencies |
| **Target Release** | v0.5.0 |
| **Depends on** | Nothing |
| **Blocks** | Nothing |

## Problem

LLM-generated text sometimes contains grammatical errors, awkward phrasing, or style inconsistencies. There is no post-processing step to catch and correct these issues before presenting output to users or downstream systems.

## Solution

Self-host [LanguageTool](https://github.com/languagetool-org/languagetool) as a REST API service for offline grammar, spelling, and style checking. Supports 30+ languages, runs entirely offline, and requires no GPU.

### Implementation (complete)

- **Dockerfile**: `docker/languagetool/Dockerfile` — thin wrapper around `erikvl87/languagetool:latest`
- **Compose service**: profile `languagetool`, port 8010, CPU-only, named volume for n-gram data
- **Component script**: `scripts/components/languagetool/languagetool.sh` — full 8-flag CLI
- **Manifest**: `scripts/components/languagetool/languagetool.manifest.json`
- **Pester test**: `tests/Test-LanguageTool.Tests.ps1`

### Integration points

| Consumer | How |
|----------|-----|
| n8n workflow | HTTP Request node → `POST /v2/check` as post-processing step |
| DeerFlow agent | Tool call to grammar-check agent output before responding |
| Flowise chain | LanguageTool node in output processing chain |
| Open WebUI | Plugin/tool to grammar-check before sending response |
| Chatwoot (future) | Polish outgoing support messages |

### API examples

```bash
# Check text
curl -s http://localhost:8010/v2/check \
  -d "language=en-US" \
  -d "text=This are a test." | jq .

# List supported languages
curl -s http://localhost:8010/v2/languages | jq .
```

## Acceptance criteria

- [x] Dockerfile created
- [x] Docker Compose service with profile `languagetool`
- [x] Component script with full CLI dispatch
- [x] Manifest with correct port and health endpoint
- [x] Port 8010 registered in portmap.json
- [x] Pester test covering file inventory, manifest, CLI flags, compose integration
- [ ] Verified container starts and `/v2/check` returns results
- [ ] Tested in at least one n8n or DeerFlow workflow

## Upstream

| Resource | Link |
|----------|------|
| GitHub | <https://github.com/languagetool-org/languagetool> |
| Docker image | <https://hub.docker.com/r/erikvl87/languagetool> |
| API docs | <https://languagetool.org/http-api/> |

## Notes

- ~500 MB RAM, CPU-only — very lightweight relative to other stack services
- Optional n-gram data can be mounted for improved detection (volume: `languagetool_data`)
- Default config supports English out of the box; additional language packs load automatically
