# KoboldCpp — Local Inference Service (Elevated)

**Priority:** HIGH
**Effort:** 2–4 hours
**Risk:** Low — established project; AGPLv3 license (see note below).
**Target Release:** v0.5.0
**Depends on:** llama-swap routing (merged), CUDA runtime on host
**Blocks:** FEATURE-005 (SillyTavern requires KoboldCpp endpoint)

> **Note:** KoboldCpp was previously tracked as part of FEATURE-005 (Deferred Services, v0.6.0).
> It has been elevated to a standalone v0.5.0 deliverable due to SillyTavern dependency.
> FEATURE-005 retains SillyTavern and other deferred services; KoboldCpp moves here.

## License Note

> **⚠️ AGPLv3 License**
>
> `LostRuins/koboldcpp` is licensed under **AGPLv3**. As a network-accessible inference
> service (HTTP API), AGPL requires that the source code of the running service be made
> available to users who interact with it over the network.
>
> Since we deploy it unmodified and self-host privately, this is acceptable for
> personal/internal use. Flag before any public or multi-tenant deployment.

## Problem

The stack routes inference through llama-swap, but KoboldCpp provides additional
capabilities not available in vanilla GGUF inference: extended context windows,
Mirostat sampling, custom sampler chains, model merging, and a built-in web UI
with memory and author's note support. SillyTavern (FEATURE-005) is wired
to KoboldCpp as its backend.

## Current State

KoboldCpp was planned in FEATURE-002 (KoboldCpp + SillyTavern Bundle) and
carried forward to FEATURE-005. Full design — docker-compose draft, component
script plan, llama-swap routing config, VRAM budget, and bundle design —
already exists in FEATURE-002. This feature formalises the deployment as standalone.

## Architecture

```text
  SillyTavern (FEATURE-005)
        │
        ▼ KoboldCpp API endpoint
  hts-ai-koboldcpp
        │
        ▼
  GGUF model (GPU VRAM + CPU offload)
```

KoboldCpp exposes a KoboldAI API and an OpenAI-compatible API.
llama-swap can route `/kobold/*` paths to KoboldCpp for unified model management.

## Implementation Steps

### P0 — Service

- [ ] **1. Docker compose service**
  Add `koboldcpp` service under `profiles: [koboldcpp]`.

  ```yaml
  koboldcpp:
    image: koboldai/koboldcpp:latest-cuda
    container_name: hts-ai-koboldcpp
    profiles: [koboldcpp]
    restart: unless-stopped
    ports:
      - "${KOBOLDCPP_PORT:-5001}:5001"
    environment:
      - KOBOLDCPP_MODEL=${KOBOLDCPP_MODEL}
      - KOBOLDCPP_THREADS=${KOBOLDCPP_THREADS:-4}
      - KOBOLDCPP_GPULAYERS=${KOBOLDCPP_GPULAYERS:-auto}
    volumes:
      - "${MODELS_DIR:-./models}:/models:ro"
    networks:
      - ai-network
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    healthcheck:
      test: ["CMD", "curl", "-sf", "http://localhost:5001/api/v1/info"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 60s
  ```

- [ ] **2. Component script**
  Create `scripts/components/koboldcpp/koboldcpp.sh` implementing:
  - `koboldcpp_install` — pull CUDA image; validate model path
  - `koboldcpp_configure` — auto-calculate `KOBOLDCPP_GPULAYERS` from VRAM budget;
    write llama-swap routing config entry
  - `koboldcpp_start` — start service + health check
  - `koboldcpp_health` — `curl -sf http://localhost:${KOBOLDCPP_PORT}/api/v1/info`
  - `koboldcpp_stop` — stop service

- [ ] **3. Env vars**
  Add to `.env.example`:

  ```text
  KOBOLDCPP_PORT=5001
  KOBOLDCPP_MODEL=
  KOBOLDCPP_THREADS=4
  KOBOLDCPP_GPULAYERS=auto
  ```

### P1 — llama-swap routing

Add KoboldCpp routing entry to llama-swap config so both services share a unified
OpenAI-compatible API endpoint. See FEATURE-002 for routing config draft.

### P2 — Registration

- [ ] **4. Port map** — Port 5001 for KoboldCpp is in the `Prod Instance` section (Allocated Range Summary).
  Confirm no conflict in main compose; add entry under Main Compose section.
- [ ] **5. Feature index** — Add row to `docs/development/features/REFERENCES.md` (v0.5.0 table).

## Acceptance Criteria

- `docker compose --profile koboldcpp up` starts the service
- KoboldAI API accessible at `http://localhost:5001/api/v1/info`
- OpenAI-compatible endpoint accessible at `http://localhost:5001/v1/chat/completions`
- `koboldcpp_health` returns success
- SillyTavern (FEATURE-005) can connect to KoboldCpp endpoint

## Related

- [FEATURE-002](FEATURE-002.md) — Original KoboldCpp + SillyTavern Bundle design (architecture reference)
- [FEATURE-005](FEATURE-005.md) — SillyTavern and deferred services (blocks on this feature)
