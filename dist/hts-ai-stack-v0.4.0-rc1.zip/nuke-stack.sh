#!/usr/bin/env bash
# nuke-stack.sh — Destroy AI stack resources at configurable depth
#
# Tiers:
#   nuke (default)   Docker-only: containers, volumes, networks, images, build cache
#   pave             Nuke + host cleanup: NemoClaw, htsclaw, OpenShell, signal-cli,
#                    models, .env, node_modules, git hooks, manifest
#                    → returns to post-bootstrap state
#   wipe             Pave then auto-reinstall from existing config/stack.json
#
# Nuke leaves installed: Docker, CUDA, Tailscale, nvm, Ollama binary, packages,
#   NemoClaw source, OpenShell binary, htsclaw config, models, .env, node_modules.
# Pave also removes those items ↑ but leaves Docker, CUDA, Tailscale, nvm, dev tools.
#
# Usage:
#   ./nuke-stack.sh                  # nuke (Docker only), prompts
#   ./nuke-stack.sh --pave           # nuke + host cleanup
#   ./nuke-stack.sh --wipe           # pave + reinstall
#   ./nuke-stack.sh --yes            # skip confirmation
#   ./nuke-stack.sh --pave --yes     # pave without prompt

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$SCRIPT_DIR"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/compose.sh"
source "$REPO_DIR/scripts/lib/teardown.sh"

AUTO_YES=false
TIER="nuke"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --yes|-y)  AUTO_YES=true; shift ;;
    --nuke)    TIER="nuke";   shift ;;
    --pave)    TIER="pave";   shift ;;
    --wipe)    TIER="wipe";   shift ;;
    *) fail "Unknown argument: $1" ;;
  esac
done

banner "nuke-stack"

# ── Preview what will be removed ──────────────────────────────────────────────
_preview_removals() {
  local tier="$1"

  echo -e "${RED}This will destroy:${NC}"
  echo ""

  echo "  ${CYAN}Containers:${NC}"
  echo "    • Docker compose stacks (root, prod, test)"
  echo "    • NemoClaw sandboxes + htsclaw sandboxes + OpenShell cluster containers"

  echo ""
  echo "  ${CYAN}Docker Volumes:${NC}"
  docker volume ls --format "table {{.Name}}" 2>/dev/null \
    | grep -E "hts-ai|ollama|open-webui|whisper|xtts|prod_|test_" \
    | sed 's/^/    • /' || true

  echo ""
  echo "  ${CYAN}Docker Networks, Images & Build Cache:${NC}"
  echo "    • AI-stack networks, built images, dangling images, build cache"

  if [[ "$tier" == "pave" || "$tier" == "wipe" ]]; then
    echo ""
    echo "  ${CYAN}Host software (Pave):${NC}"
    echo "    • NemoClaw source (~/.nemoclaw/) + npm global link"
    echo "    • htsclaw sandbox, systemd health timer, UFW rules"
    echo "    • OpenShell binary (/usr/local/bin/openshell) + config"
    echo "    • signal-cli (/opt/signal-cli)"
    echo "    • Model staging dirs (~/models/approved, ~/models/testing)"
    echo "    • .env, node_modules/, git hooks, install manifest"
  fi

  if [[ "$tier" == "wipe" ]]; then
    echo ""
    echo "  ${CYAN}Then:${NC}"
    echo "    • Full reinstall from existing config/stack.json"
  fi

  echo ""
  echo -e "${GREEN}Left intact:${NC} Docker, CUDA, Tailscale, nvm, dev tools, VS Code, PowerShell"
  echo ""
}

_preview_removals "$TIER"

if [[ "$AUTO_YES" == false ]]; then
  _label=""
  case "$TIER" in
    nuke) _label="Nuke (Docker only)" ;;
    pave) _label="Pave (Docker + host cleanup)" ;;
    wipe) _label="Wipe & Reload (pave + reinstall)" ;;
  esac
  read -r -p "  Proceed with ${_label}? [y/N]: " confirm
  if [[ "${confirm,,}" != "y" && "${confirm,,}" != "yes" ]]; then
    warn "Aborted by user — nothing was changed."
    exit 130
  fi
fi

# ── Execute tiers ─────────────────────────────────────────────────────────────
teardown_nuke

if [[ "$TIER" == "pave" || "$TIER" == "wipe" ]]; then
  teardown_pave
fi

echo ""
case "$TIER" in
  nuke)
    ok "Stack nuked (Docker resources removed)."
    echo ""
    echo "  To rebuild:  ./install.sh"
    ;;
  pave)
    ok "Stack paved (returned to post-bootstrap state)."
    echo ""
    echo "  To rebuild:  ./install.sh"
    ;;
  wipe)
    ok "Stack paved — starting reinstall..."
    echo ""
    exec bash "$REPO_DIR/install.sh"
    ;;
esac
echo ""
