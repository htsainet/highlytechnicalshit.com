#!/usr/bin/env bash
# Switch local repo to main after the nemoclaw PR merge.
# Run on host (not inside snap) so HTTPS works.
set -euo pipefail

cd "$(dirname "$0")/../.."

BRANCH="feature/nemoclaw-nvidia-compliance-and-remove-htsclaw"

echo ">>> Fetching origin..."
git fetch origin --prune

echo ">>> Checking out main..."
git checkout main

echo ">>> Fast-forwarding main..."
git pull --ff-only origin main

if git show-ref --verify --quiet "refs/heads/${BRANCH}"; then
  echo ">>> Deleting local branch ${BRANCH}..."
  if ! git branch -d "${BRANCH}" 2>/dev/null; then
    echo "    (branch not fully merged by name; forcing delete since PR is merged upstream)"
    git branch -D "${BRANCH}"
  fi
else
  echo ">>> Local branch ${BRANCH} already gone."
fi

echo ""
echo ">>> Done. Current state:"
git --no-pager log --oneline -5
echo ""
git --no-pager status
