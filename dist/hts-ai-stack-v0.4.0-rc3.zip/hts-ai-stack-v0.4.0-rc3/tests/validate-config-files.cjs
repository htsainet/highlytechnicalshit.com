#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { parseTree, printParseErrorCode } = require('jsonc-parser');
const YAML = require('yaml');

const files = process.argv.slice(2);

if (files.length === 0) {
  process.exit(0);
}

let hasErrors = false;

for (const file of files) {
  const fullPath = path.resolve(file);
  const content = fs.readFileSync(fullPath, 'utf8');
  const extension = path.extname(file).toLowerCase();

  try {
    if (extension === '.json' || extension === '.jsonc') {
      const errors = [];
      parseTree(content, errors, { allowTrailingComma: true, disallowComments: extension === '.json' });
      if (errors.length > 0) {
        hasErrors = true;
        for (const error of errors) {
          console.error(`${file}: ${printParseErrorCode(error.error)} at offset ${error.offset}`);
        }
      }
      continue;
    }

    if (extension === '.yml' || extension === '.yaml') {
      const doc = YAML.parseDocument(content);
      if (doc.errors.length > 0) {
        hasErrors = true;
        for (const error of doc.errors) {
          console.error(`${file}: ${error.message}`);
        }
      }
      continue;
    }
  }
  catch (error) {
    hasErrors = true;
    console.error(`${file}: ${error.message}`);
  }
}

if (hasErrors) {
  process.exit(1);
}