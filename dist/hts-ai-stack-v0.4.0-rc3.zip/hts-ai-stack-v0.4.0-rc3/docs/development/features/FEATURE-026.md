# Faster-Whisper — GPU Speech-to-Text Service

**Priority:** MEDIUM
**Effort:** 2–3 hours
**Risk:** Low — MIT license, stable release, well-documented speaches wrapper.
**Target Release:** v0.6.0
**Depends on:** Nothing
**Blocks:** Voice pipeline completeness (pairs with FEATURE-025 TTS)

## Problem

The stack has no GPU-accelerated speech recognition service. Faster-Whisper provides
CTranslate2-optimised Whisper inference — up to 4× faster than original Whisper
with int8 quantisation. It completes 13 minutes of audio in 16 seconds on an RTX 3070 Ti.

## Current State

No STT service in the stack. `SYSTRAN/faster-whisper` is not tracked in feature-repos.

## Architecture

Wrapped by **speaches** (`speaches-ai/speaches`) which exposes an
OpenAI-compatible `/v1/audio/transcriptions` REST endpoint on port 8600.
This allows any OpenAI SDK client to transcribe audio without code changes.

```text
  client → POST /v1/audio/transcriptions (port 8600)
               │
           speaches (wrapper)
               │
           faster-whisper (CTranslate2 engine)
               │
           CUDA 12 / CPU int8 fallback
```

GPU-primary path: `nvidia/cuda:12.3.2-cudnn9-runtime-ubuntu22.04`.
CPU fallback: automatic when no GPU detected; int8 quantisation keeps latency reasonable.

## Implementation Steps

### P0 — Service

- [ ] **1. Docker compose service**
  Add `faster-whisper` service under `profiles: [faster-whisper]`.

  ```yaml
  faster-whisper:
    image: ghcr.io/speaches-ai/speaches:latest-cuda
    container_name: hts-ai-faster-whisper
    profiles: [faster-whisper]
    restart: unless-stopped
    ports:
      - "${FASTER_WHISPER_PORT:-8600}:8000"
    environment:
      - WHISPER__MODEL=${FASTER_WHISPER_MODEL:-Systran/faster-whisper-large-v3}
      - WHISPER__INFERENCE_DEVICE=cuda
      - WHISPER__COMPUTE_TYPE=float16
    volumes:
      - faster-whisper-models:/root/.cache/huggingface
    networks:
      - ai-network
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    healthcheck:
      test: ["CMD", "curl", "-sf", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 60s
  ```

- [ ] **2. Component script**
  Create `scripts/components/faster-whisper/faster-whisper.sh` implementing:
  - `faster_whisper_install` — pull speaches CUDA image
  - `faster_whisper_configure` — validate model name env var
  - `faster_whisper_start` — start service + health check
  - `faster_whisper_health` — `curl -sf http://localhost:${FASTER_WHISPER_PORT}/health`
  - `faster_whisper_stop` — stop service

- [ ] **3. Env vars**
  Add to `.env.example`:

  ```text
  FASTER_WHISPER_PORT=8600
  FASTER_WHISPER_MODEL=Systran/faster-whisper-large-v3
  ```

### P1 — Registration

- [ ] **4. Port map** — Add port 8600 to `REFERENCES.md` Host Port Map table.
- [ ] **5. Feature index** — Add row to `docs/development/features/REFERENCES.md`.

### P2 — CPU fallback

For CPU-only hosts, use the non-CUDA image and set `int8` compute type:

```yaml
image: ghcr.io/speaches-ai/speaches:latest
environment:
  - WHISPER__INFERENCE_DEVICE=cpu
  - WHISPER__COMPUTE_TYPE=int8
```

Document CPU fallback command in component script. Expect ~2–4× slower transcription
than GPU path on typical desktop CPU.

## Acceptance Criteria

- `docker compose --profile faster-whisper up` starts the service
- `POST http://localhost:8600/v1/audio/transcriptions` returns transcript JSON
- `faster_whisper_health` returns success
- Model downloads on first run and persists in volume `faster-whisper-models`
- GPU inference active when RTX card is present

## Related

- [FEATURE-025](FEATURE-025.md) — Coqui TTS (voice pipeline pair)
- [FEATURE-027](FEATURE-027.md) — Nerd Dictation (host-side voice input using VOSK)
- [FEATURE-028](FEATURE-028.md) — Vosk API (CPU STT alternative)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md) — row: `SYSTRAN/faster-whisper`
