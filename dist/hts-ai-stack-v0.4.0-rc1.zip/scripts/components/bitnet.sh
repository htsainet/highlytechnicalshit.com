#!/usr/bin/env bash
# scripts/components/bitnet.sh — BitNet 1-bit LLM: install, start, health
#
# Standalone usage:
#   ./scripts/components/bitnet.sh            # install + configure + start + health
#   ./scripts/components/bitnet.sh --health   # health check only
#   ./scripts/components/bitnet.sh --stop     # stop BitNet
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
BITNET_CONTAINER="${BITNET_CONTAINER:-hts-ai-bitnet-cpu}"
BITNET_PORT="${BITNET_PORT:-8080}"
BITNET_MODEL="${BITNET_MODEL:-BitNet-b1.58-2B-4T}"
BITNET_HF_REPO="${BITNET_HF_REPO:-microsoft/BitNet-b1.58-2B-4T-gguf}"

# ── Functions ────────────────────────────────────────────────────────────────

# bitnet_install — Build BitNet image from docker/bitnet/Dockerfile
bitnet_install() {
  step "BitNet — install"
  local dockerfile="$REPO_DIR/docker/bitnet/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    fail "BitNet Dockerfile not found: $dockerfile"
    return 1
  fi
  info "Building BitNet from source (clang-18 + CMake) — this may take a few minutes..."
  info "Model weights download separately on first container start."
  compose_build --profile bitnet-cpu
  ok "BitNet image built."
}

# bitnet_configure — Validate BitNet model configuration
bitnet_configure() {
  step "BitNet — configure"
  info "Model: ${BITNET_MODEL}"
  info "HF repo: ${BITNET_HF_REPO}"
  info "API port: ${BITNET_PORT} (OpenAI-compatible)"
  ok "BitNet configured."
}

# bitnet_start — Bring up BitNet via compose (with exclusivity guard)
bitnet_start() {
  step "BitNet — start"
  compose_up --profile bitnet-cpu
  ok "BitNet started on port ${BITNET_PORT}."
}

# bitnet_stop — Bring down BitNet
bitnet_stop() {
  step "BitNet — stop"
  compose_down --profile bitnet-cpu
  ok "BitNet stopped."
}

# bitnet_health — Probe the BitNet OpenAI-compatible API inside the container
# BitNet has no host port binding (llama-swap proxies); use docker exec.
bitnet_health() {
  local label="BitNet :${BITNET_PORT}"
  printf "  %-35s" "$label"
  if docker exec "${BITNET_CONTAINER}" curl -sf "http://localhost:${BITNET_PORT}/v1/models" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (docker exec ${BITNET_CONTAINER} curl http://localhost:${BITNET_PORT}/v1/models)"
    return 1
  fi
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      bitnet_install
      bitnet_configure
      bitnet_start
      bitnet_health
      ;;
    health)
      bitnet_health
      ;;
    stop)
      bitnet_stop
      ;;
  esac
fi
