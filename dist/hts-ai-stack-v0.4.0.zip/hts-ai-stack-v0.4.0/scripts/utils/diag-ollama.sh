#!/usr/bin/env bash
CONTAINER="hts-ai-ollama"

echo "=== Container status ==="
docker inspect "$CONTAINER" --format '{{.State.Status}} — {{.State.Error}}' 2>/dev/null

echo ""
echo "=== Container logs ==="
docker logs "$CONTAINER" --tail 50 2>/dev/null || echo "(no logs)"

echo ""
echo "=== Attempting to start container ==="
docker start "$CONTAINER" 2>&1 || true
sleep 3
docker ps --filter name="$CONTAINER"

echo ""
echo "=== Logs after start attempt ==="
docker logs "$CONTAINER" --tail 30 2>&1 || true

echo ""
echo "=== nvidia-container-toolkit installed? ==="
dpkg -l nvidia-container-toolkit 2>/dev/null | tail -1 || echo "NOT installed"

echo ""
echo "=== Docker GPU test ==="
docker run --rm --gpus all nvidia/cuda:12.0-base-ubuntu20.04 nvidia-smi 2>&1 | head -10 || echo "GPU test failed"
