#!/usr/bin/env python3
"""htsclaw menu — Python + whiptail interactive sandbox manager.

Presents an interactive TUI for managing htsclaw sandboxes:
  1. Setup     — Create a new sandbox (name, model, policy, personas)
  2. Teardown  — Destroy an existing sandbox
  3. Upgrade   — Upgrade OpenClaw inside a sandbox
  4. Patch     — Run npm audit fix (non-destructive)
  5. Status    — Show health check results

Usage:
  ./scripts/htsclaw/menus/htsclaw-menu.py              # interactive menu
  ./scripts/htsclaw/menus/htsclaw-menu.py --setup       # skip menu, run setup
  ./scripts/htsclaw/menus/htsclaw-menu.py --teardown    # skip menu, run teardown
  ./scripts/htsclaw/menus/htsclaw-menu.py --upgrade     # skip menu, run upgrade
  ./scripts/htsclaw/menus/htsclaw-menu.py --patch       # skip menu, run patch
  ./scripts/htsclaw/menus/htsclaw-menu.py --status      # skip menu, run status
"""

import json
import os
import shutil
import subprocess
import sys
import urllib.request
import urllib.error

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", ".."))
HTSCLAW_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, ".."))

# ── Colors (for non-whiptail fallback) ────────────────────────────────────────
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
CYAN = "\033[0;36m"
BOLD = "\033[1m"
NC = "\033[0m"

# ── Defaults ──────────────────────────────────────────────────────────────────
DEFAULT_SANDBOX = "hts-ai-openshell-htsclaw-gpu"
DEFAULT_PORT = "18792"
DEFAULT_MODEL = "gemma4:e4b"
LLAMA_SWAP_PORT = os.environ.get("LLAMA_SWAP_PORT", "8081")


def has_whiptail() -> bool:
    return shutil.which("whiptail") is not None


def info(msg: str) -> None:
    print(f"{GREEN}[INFO]{NC} {msg}")


def warn(msg: str) -> None:
    print(f"{YELLOW}[WARN]{NC} {msg}")


def fail(msg: str) -> None:
    print(f"{RED}[FAIL]{NC} {msg}", file=sys.stderr)
    sys.exit(1)


# ── Model discovery ──────────────────────────────────────────────────────────


def get_available_models() -> list[str]:
    """Query llama-swap /v1/models for available model names."""
    url = f"http://localhost:{LLAMA_SWAP_PORT}/v1/models"
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = json.loads(resp.read().decode())
            return [m["id"] for m in data.get("data", [])]
    except (urllib.error.URLError, json.JSONDecodeError, OSError):
        return []


# ── Shell script runners ─────────────────────────────────────────────────────


def run_script(script: str, *args: str) -> int:
    """Run a bash script from the htsclaw directory."""
    path = os.path.join(HTSCLAW_DIR, script)
    if not os.path.isfile(path):
        warn(f"Script not found: {path}")
        return 1
    cmd = ["bash", path] + list(args)
    result = subprocess.run(cmd, cwd=REPO_DIR)
    return result.returncode


# ── Whiptail helpers ─────────────────────────────────────────────────────────


def whiptail_input(title: str, prompt: str, default: str = "") -> str | None:
    """Show a whiptail input box. Returns user input or None on cancel."""
    result = subprocess.run(
        ["whiptail", "--title", title, "--inputbox", prompt, "10", "60", default],
        stderr=subprocess.PIPE,
        text=True,
    )
    if result.returncode != 0:
        return None
    return result.stderr.strip()


def whiptail_menu_select(title: str, prompt: str, items: list[tuple[str, str]]) -> str | None:
    """Show a whiptail menu. items = [(tag, description), ...]. Returns tag or None."""
    args = ["whiptail", "--title", title, "--menu", prompt, "20", "72", str(len(items))]
    for tag, desc in items:
        args.extend([tag, desc])
    result = subprocess.run(args, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        return None
    return result.stderr.strip()


def whiptail_yesno(title: str, prompt: str) -> bool:
    """Show a whiptail yes/no dialog. Returns True for yes."""
    result = subprocess.run(
        ["whiptail", "--title", title, "--yesno", prompt, "10", "60"],
    )
    return result.returncode == 0


def whiptail_msgbox(title: str, msg: str) -> None:
    """Show a whiptail message box."""
    subprocess.run(["whiptail", "--title", title, "--msgbox", msg, "12", "60"])


# ── Fallback (plain text) helpers ────────────────────────────────────────────


def fallback_input(prompt: str, default: str = "") -> str | None:
    """Plain-text input with default value."""
    try:
        suffix = f" [{default}]" if default else ""
        value = input(f"  {prompt}{suffix}: ").strip()
        return value if value else default
    except (EOFError, KeyboardInterrupt):
        return None


def fallback_select(prompt: str, items: list[tuple[str, str]]) -> str | None:
    """Plain-text numbered selection."""
    print(f"\n  {prompt}\n")
    for i, (tag, desc) in enumerate(items, 1):
        print(f"    {BOLD}[{i}]{NC} {tag} — {desc}")
    print(f"    {BOLD}[q]{NC} Cancel\n")
    while True:
        try:
            choice = input("  Select: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return None
        if choice in ("q", "quit", ""):
            return None
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(items):
                return items[idx][0]
        except ValueError:
            pass
        print(f"  {YELLOW}Invalid choice{NC}")


# ── Menu actions ─────────────────────────────────────────────────────────────


def action_setup() -> int:
    """Walk user through sandbox creation."""
    print(f"\n{CYAN}{BOLD}══ htsclaw — Setup ══{NC}\n")

    # 1. Sandbox name
    if has_whiptail():
        name = whiptail_input("Sandbox Name", "Enter sandbox name:", DEFAULT_SANDBOX)
    else:
        name = fallback_input("Sandbox name", DEFAULT_SANDBOX)
    if name is None:
        info("Setup cancelled.")
        return 0

    # 2. Model selection
    models = get_available_models()
    if models:
        items = [(m, "") for m in models]
        if has_whiptail():
            model = whiptail_menu_select("Model", "Select inference model:", items)
        else:
            model = fallback_select("Select inference model:", items)
        if model is None:
            model = DEFAULT_MODEL
    else:
        warn(f"Could not query llama-swap (:{ LLAMA_SWAP_PORT}) — using default model.")
        if has_whiptail():
            model = whiptail_input("Model", "Enter model name:", DEFAULT_MODEL)
        else:
            model = fallback_input("Model name", DEFAULT_MODEL)
        if model is None:
            model = DEFAULT_MODEL

    # 3. Agent personas
    if has_whiptail():
        personas = whiptail_yesno("Agent Personas", "Provision agent personas (SOUL.md/IDENTITY.md)?")
    else:
        try:
            reply = input(f"  Provision agent personas? [Y/n]: ").strip().lower()
            personas = reply != "n"
        except (EOFError, KeyboardInterrupt):
            personas = True

    # 4. Confirm
    summary = (
        f"Sandbox:  {name}\n"
        f"Port:     {DEFAULT_PORT}\n"
        f"Model:    {model}\n"
        f"Personas: {'yes' if personas else 'no'}\n"
        f"\nProceed with setup?"
    )
    if has_whiptail():
        if not whiptail_yesno("Confirm Setup", summary):
            info("Setup cancelled.")
            return 0
    else:
        print(f"\n{summary}\n")
        try:
            reply = input("  Proceed? [Y/n]: ").strip().lower()
            if reply == "n":
                info("Setup cancelled.")
                return 0
        except (EOFError, KeyboardInterrupt):
            return 0

    # 5. Execute
    # Set environment for the scripts
    os.environ["HTSCLAW_SANDBOX_NAME"] = name
    os.environ["HTSCLAW_PORT"] = DEFAULT_PORT
    os.environ["OLLAMA_MODEL"] = model
    os.environ["HTSCLAW_AGENT_PERSONAS"] = "true" if personas else "false"

    rc = run_script("sandbox/lifecycle.sh", "--create")
    if rc != 0:
        return rc

    rc = run_script("sandbox/provider.sh")
    if rc != 0:
        return rc

    rc = run_script("sandbox/firewall.sh")
    if rc != 0:
        warn("Firewall setup failed — continuing without firewall rules.")

    if personas:
        rc = run_script("personas/provision.sh")
        if rc != 0:
            warn("Persona provisioning failed — sandbox is still usable.")

    rc = run_script("dashboard/tokens.sh")
    if rc != 0:
        warn("Token extraction failed — dashboard integration may not work.")

    rc = run_script("dashboard/origins.sh")
    if rc != 0:
        warn("Origins patching failed — dashboard embedding may not work.")

    # Install health timer
    run_script("health/health.sh", "--install")

    info(f"Setup complete! OpenClaw UI → http://localhost:{DEFAULT_PORT}")
    return 0


def action_teardown() -> int:
    """Destroy an existing sandbox."""
    print(f"\n{CYAN}{BOLD}══ htsclaw — Teardown ══{NC}\n")

    if has_whiptail():
        name = whiptail_input("Teardown", "Sandbox name to destroy:", DEFAULT_SANDBOX)
    else:
        name = fallback_input("Sandbox name to destroy", DEFAULT_SANDBOX)
    if name is None:
        info("Teardown cancelled.")
        return 0

    confirm_msg = f"Destroy sandbox '{name}'?\n\nThis will stop forwards and delete the sandbox.\nData inside /sandbox is ephemeral and will be lost."
    if has_whiptail():
        if not whiptail_yesno("Confirm Teardown", confirm_msg):
            info("Teardown cancelled.")
            return 0
    else:
        print(f"\n  {RED}{confirm_msg}{NC}\n")
        try:
            reply = input("  Confirm? [y/N]: ").strip().lower()
            if reply != "y":
                info("Teardown cancelled.")
                return 0
        except (EOFError, KeyboardInterrupt):
            return 0

    os.environ["HTSCLAW_SANDBOX_NAME"] = name
    return run_script("sandbox/lifecycle.sh", "--destroy")


def action_upgrade() -> int:
    """Upgrade OpenClaw inside a sandbox."""
    print(f"\n{CYAN}{BOLD}══ htsclaw — Upgrade ══{NC}\n")

    if has_whiptail():
        name = whiptail_input("Upgrade", "Sandbox name to upgrade:", DEFAULT_SANDBOX)
    else:
        name = fallback_input("Sandbox name to upgrade", DEFAULT_SANDBOX)
    if name is None:
        info("Upgrade cancelled.")
        return 0

    if has_whiptail():
        if not whiptail_yesno("Confirm Upgrade", f"Upgrade OpenClaw in '{name}'?\n\nThis runs npm update inside the sandbox."):
            info("Upgrade cancelled.")
            return 0
    else:
        try:
            reply = input(f"  Upgrade OpenClaw in '{name}'? [Y/n]: ").strip().lower()
            if reply == "n":
                info("Upgrade cancelled.")
                return 0
        except (EOFError, KeyboardInterrupt):
            return 0

    os.environ["HTSCLAW_SANDBOX_NAME"] = name
    rc = run_script("sandbox/lifecycle.sh", "--upgrade")

    # Re-extract tokens after upgrade (gateway restart may regenerate them)
    if rc == 0:
        run_script("dashboard/tokens.sh")
        run_script("dashboard/origins.sh")

    return rc


def action_patch() -> int:
    """Run npm audit fix inside a sandbox."""
    print(f"\n{CYAN}{BOLD}══ htsclaw — Patch ══{NC}\n")

    if has_whiptail():
        name = whiptail_input("Patch", "Sandbox name to patch:", DEFAULT_SANDBOX)
    else:
        name = fallback_input("Sandbox name to patch", DEFAULT_SANDBOX)
    if name is None:
        info("Patch cancelled.")
        return 0

    os.environ["HTSCLAW_SANDBOX_NAME"] = name
    return run_script("sandbox/lifecycle.sh", "--patch")


def action_status() -> int:
    """Show health check results."""
    return run_script("health/health.sh")


# ── Main menu ────────────────────────────────────────────────────────────────

MENU_ITEMS = [
    ("setup", "Create a new sandbox"),
    ("teardown", "Destroy an existing sandbox"),
    ("upgrade", "Upgrade OpenClaw inside a sandbox"),
    ("patch", "Run npm audit fix (non-destructive)"),
    ("status", "Show health check results"),
]

ACTIONS = {
    "setup": action_setup,
    "teardown": action_teardown,
    "upgrade": action_upgrade,
    "patch": action_patch,
    "status": action_status,
}


def main_menu() -> str | None:
    """Show the top-level menu."""
    if has_whiptail():
        return whiptail_menu_select(
            "htsclaw — Sandbox Manager",
            "\nManage htsclaw OpenClaw sandboxes:\n",
            MENU_ITEMS,
        )
    else:
        print(f"\n{CYAN}{BOLD}htsclaw — Sandbox Manager{NC}\n")
        return fallback_select("Choose an action:", MENU_ITEMS)


def main() -> int:
    # Direct action via CLI flag
    if len(sys.argv) > 1:
        arg = sys.argv[1].lstrip("-")
        if arg in ACTIONS:
            return ACTIONS[arg]()
        if arg in ("h", "help"):
            print(__doc__)
            return 0
        print(f"{RED}Unknown argument: {sys.argv[1]}{NC}", file=sys.stderr)
        return 1

    # Interactive menu loop
    while True:
        action = main_menu()
        if action is None:
            info("Goodbye.")
            return 0

        handler = ACTIONS.get(action)
        if handler is None:
            warn(f"Unknown action: {action}")
            continue

        rc = handler()
        if rc != 0:
            warn(f"Action '{action}' exited with code {rc}.")

        # Pause before returning to menu
        print()
        try:
            input("  Press Enter to return to menu...")
        except (EOFError, KeyboardInterrupt):
            return 0


if __name__ == "__main__":
    sys.exit(main())
