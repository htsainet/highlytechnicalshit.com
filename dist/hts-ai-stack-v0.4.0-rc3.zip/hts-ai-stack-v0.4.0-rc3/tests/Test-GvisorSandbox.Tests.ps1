$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/gvisor-sandbox'
    $script:ComponentScript = Join-Path $script:ComponentDir 'gvisor-sandbox.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'gvisor-sandbox.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'gvisor-sandbox file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'gvisor-sandbox manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is gvisor-sandbox' {
        $script:Manifest.id | Should -Be 'gvisor-sandbox'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/gvisor-sandbox/gvisor-sandbox.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is gvisor_sandbox' {
        $script:Manifest.func_prefix | Should -Be 'gvisor_sandbox'
    }

    It 'category is sandbox' {
        $script:Manifest.category | Should -Be 'sandbox'
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'gvisor-sandbox component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines gvisor_sandbox_install function' {
        $script:ComponentContent | Should -Match 'gvisor_sandbox_install\s*\(\)'
    }

    It 'defines gvisor_sandbox_start function' {
        $script:ComponentContent | Should -Match 'gvisor_sandbox_start\s*\(\)'
    }

    It 'defines gvisor_sandbox_stop function' {
        $script:ComponentContent | Should -Match 'gvisor_sandbox_stop\s*\(\)'
    }

    It 'defines gvisor_sandbox_health function' {
        $script:ComponentContent | Should -Match 'gvisor_sandbox_health\s*\(\)'
    }

    It 'supports --print-architecture, --health, and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--print-architecture\)'
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/gvisor-sandbox/gvisor-sandbox\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'gvisor-sandbox no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/gvisor-sandbox\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/gvisor-sandbox/gvisor-sandbox\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
