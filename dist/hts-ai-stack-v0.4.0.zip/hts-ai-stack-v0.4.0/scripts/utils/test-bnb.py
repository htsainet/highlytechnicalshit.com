#!/usr/bin/env python3
"""scripts/utils/test_bnb.py
Quick tester for bitsandbytes / transformers model loading on a GPU.
This script is informational — it does not install dependencies. Run inside a venv
with torch + transformers + bitsandbytes installed, or in a container.

Usage:
  python3 scripts/utils/test_bnb.py --model <repo-id> --quant q4
"""

import subprocess
import argparse
import sys


def run(cmd):
    try:
        out = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, text=True)
        return out
    except subprocess.CalledProcessError as e:
        return e.output


def check_nvidia():
    return run('nvidia-smi -L || true')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default='mistralai/Mistral-3B-v1', help='HF repo id or local path')
    parser.add_argument('--quant', choices=['q4', 'fp16'], default='fp16')
    args = parser.parse_args()

    print('=== GPU status ===')
    print(check_nvidia())

    print('\n=== Python libs ===')
    try:
        import torch
        print('torch:', torch.__version__, 'cuda_available:', torch.cuda.is_available())
    except Exception as e:
        print('torch import failed:', e)

    try:
        import transformers
        print('transformers:', transformers.__version__)
    except Exception as e:
        print('transformers import failed:', e)

    try:
        import bitsandbytes as bnb
        print('bitsandbytes:', bnb.__version__)
    except Exception as e:
        print('bitsandbytes import failed:', e)

    print('\nThis script does not auto-install packages. If imports failed, install with:')
    print('  python -m pip install -U "transformers accelerate bitsandbytes"')

    print('\nTo attempt loading the model (only in a prepared environment):')
    print('  from transformers import AutoTokenizer, AutoModelForCausalLM')
    print("  model = AutoModelForCausalLM.from_pretrained(model_id, device_map='auto', load_in_4bit=(args.quant=='q4'))")


if __name__ == '__main__':
    main()
