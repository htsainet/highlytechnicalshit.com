#!/usr/bin/env bash

# Shared terminal UI helpers for installer scripts.
# Colors and logging are provided by lib/common.sh; this file adds
# banner and checklist helpers used by legacy scripts.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# Source shared colour/logging definitions (removes duplication)
# shellcheck source=../../lib/common.sh
source "$REPO_DIR/scripts/lib/common.sh"

htsai_banner() {
  local label="$1"

  cat <<BANNER

  _   _ _____ ____       _    ___
 | | | |_   _/ ___|     / \  |_ _|
 | |_| | | | \___ \    / _ \  | |
 |  _  | | |  ___) |  / ___ \ | |
 |_| |_| |_| |____/  /_/   \_\___|     ubuntu ai stack

            ${label}
  ----------------------------------------
BANNER
}

checklist_start() {
  echo -e "\n  ${GREEN}Setup checklist — already-done steps are marked [x]:${NC}\n"
}

checklist_item() {
  local done="$1"
  local text="$2"

  if [ "$done" = "true" ]; then
    echo -e "  ${GREEN}[x]${NC} ${text}"
  else
    echo -e "  ${YELLOW}[ ]${NC} ${text}"
  fi
}

checklist_end() {
  echo -e "\n ----------------------------------------\n"
}
