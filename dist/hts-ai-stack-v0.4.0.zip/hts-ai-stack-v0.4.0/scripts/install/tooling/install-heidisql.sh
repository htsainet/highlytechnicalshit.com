#!/usr/bin/env bash
# install-heidisql.sh — Install HeidiSQL on Ubuntu 24.04
#
# Ubuntu 24.04 ships without libqt6pas, so we fetch it from the upstream
# release before installing the HeidiSQL .deb.
#
# Usage:
#   ./install-heidisql.sh

set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already installed" >&2; }
fail() { echo -e "${RED}[FAIL]${NC} $*" >&2; exit 1; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

LIBQT6PAS_URL="https://github.com/davidbannon/libqt6pas/releases/download/v6.2.10/libqt6pas6_6.2.10-1_amd64.deb"
LIBQT6PAS_DEB="/tmp/libqt6pas6_6.2.10-1_amd64.deb"

HEIDI_URL="https://github.com/HeidiSQL/HeidiSQL/releases/download/v12.16/heidisql_12.16_amd64.deb"
HEIDI_DEB="/tmp/heidisql_12.16_amd64.deb"

# ── Step 1: libqt6pas dependency ──────────────────────────────────────────────
step "1 — libqt6pas"

if dpkg -s libqt6pas6 &>/dev/null; then
  skip "libqt6pas6"
else
  info "Downloading libqt6pas6..."
  curl -fsSL -o "$LIBQT6PAS_DEB" "$LIBQT6PAS_URL"
  sudo apt install -y "$LIBQT6PAS_DEB"
  rm -f "$LIBQT6PAS_DEB"
  info "libqt6pas6 installed."
fi

# ── Step 2: HeidiSQL ──────────────────────────────────────────────────────────
step "2 — HeidiSQL"

if dpkg -s heidisql &>/dev/null; then
  skip "HeidiSQL ($(dpkg -s heidisql | grep '^Version:' | cut -d' ' -f2))"
else
  info "Downloading HeidiSQL 12.16..."
  curl -fsSL -o "$HEIDI_DEB" "$HEIDI_URL"
  sudo apt install -y "$HEIDI_DEB"
  rm -f "$HEIDI_DEB"
  info "HeidiSQL installed."
fi
