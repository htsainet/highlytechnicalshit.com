"""
title: Model Security Audit
author: hts-ai-stack
version: 0.1.0
description: Type /audit in any chat to scan all pulled Ollama models against HuggingFace security flags and publisher reputation.
"""

import json
import urllib.request
import urllib.error
from typing import Optional


class Pipe:
    """Open WebUI Function — /audit slash command."""

    class Valves:
        """Admin-configurable settings (shown in Open WebUI UI)."""
        OLLAMA_BASE_URL: str = "http://ollama:11434"
        HF_API_TIMEOUT: int = 10

    def __init__(self):
        self.valves = self.Valves()

    def _hf_repo_from_name(self, name: str) -> Optional[str]:
        """Map 'hf.co/user/repo:tag' → 'user/repo'."""
        if not name.startswith("hf.co/"):
            return None
        repo = name[len("hf.co/"):]
        repo = repo.split(":")[0]
        return repo

    def _check_hf(self, repo: str) -> dict:
        """Query HuggingFace API for security + reputation."""
        url = f"https://huggingface.co/api/models/{repo}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "hts-ai-audit/1.0"})
            with urllib.request.urlopen(req, timeout=self.valves.HF_API_TIMEOUT) as resp:
                data = json.loads(resp.read().decode())
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError):
            return {"security": "unavailable", "author": "unknown", "downloads": 0, "likes": 0}

        tags = data.get("tags", [])
        sec_status = data.get("securityStatus", {})
        security = sec_status.get("status", "no-scan-data") if sec_status else "no-scan-data"

        if "unsafe" in str(tags).lower():
            security = "unsafe"

        return {
            "security": security,
            "author": data.get("author", "unknown"),
            "downloads": data.get("downloads", 0),
            "likes": data.get("likes", 0),
        }

    def _format_downloads(self, n: int) -> str:
        if n >= 1_000_000:
            return f"{n // 1_000_000}M"
        if n >= 1_000:
            return f"{n // 1_000}K"
        return str(n)

    def _security_icon(self, status: str) -> str:
        icons = {
            "safe": "✅",
            "no-scan-data": "✅",
            "unsafe": "❌",
            "unavailable": "⚠️",
            "error": "⚠️",
        }
        return icons.get(status, "❓")

    def pipe(self, body: dict) -> str:
        """Called when user types /audit. Returns markdown audit report."""
        ollama_url = self.valves.OLLAMA_BASE_URL

        # Fetch model list from Ollama
        try:
            req = urllib.request.Request(f"{ollama_url}/api/tags")
            with urllib.request.urlopen(req, timeout=10) as resp:
                tags_data = json.loads(resp.read().decode())
        except Exception as e:
            return f"**Error:** Cannot reach Ollama at `{ollama_url}` — {e}"

        models = tags_data.get("models", [])
        if not models:
            return "No models found in Ollama."

        # Build audit table
        rows = []
        pass_count = warn_count = fail_count = 0

        for m in models:
            name = m["name"]
            hf_repo = self._hf_repo_from_name(name)

            if hf_repo:
                info = self._check_hf(hf_repo)
            else:
                info = {"security": "n/a (ollama registry)", "author": "ollama", "downloads": 0, "likes": 0}

            sec = info["security"]
            icon = self._security_icon(sec)

            if sec in ("safe", "no-scan-data", "n/a (ollama registry)"):
                pass_count += 1
            elif sec == "unsafe":
                fail_count += 1
            else:
                warn_count += 1

            # Truncate long names for table readability
            display = name if len(name) <= 55 else f"...{name[-52:]}"

            rows.append(
                f"| {display} | {icon} {sec} | {self._format_downloads(info['downloads'])} | {info['likes']} | {info['author']} |"
            )

        # Assemble markdown report
        header = f"## 🔍 Model Security Audit — {len(models)} models\n\n"
        table_head = "| Model | Security | Downloads | Likes | Author |\n|---|---|---|---|---|\n"
        table_body = "\n".join(rows)
        summary = f"\n\n---\n✅ **{pass_count}** passed  ⚠️ **{warn_count}** warnings  ❌ **{fail_count}** failed\n"

        if fail_count > 0:
            summary += "\n⚠️ **Models flagged as unsafe should be reviewed and potentially removed.**\n"

        return header + table_head + table_body + summary
