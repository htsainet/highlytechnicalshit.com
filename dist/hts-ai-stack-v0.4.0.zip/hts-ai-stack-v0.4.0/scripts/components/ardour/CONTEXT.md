# Ardour Component

Last updated: 2026-04-17

## What happens here

Ardour is a professional digital audio workstation (DAW) for recording,
editing, and mixing multi-track audio. It supports unlimited tracks,
non-destructive editing, and a full plugin architecture.

## Files and structure

| File | Purpose |
|------|---------|
| `ardour.sh` | Full lifecycle: install, configure, start, stop, health |
| `ardour.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- Host-native desktop application — no Docker container or web UI
- Requires a desktop session (X11 or Wayland) to run
- Works best with JACK audio server (installed by ubuntu-audio component)
- Supports LADSPA, LV2, VST2, and VST3 plugins
- Free and open source (GPL) — the Ubuntu package is fully functional

See [usage.md](./usage.md) for command usage.
