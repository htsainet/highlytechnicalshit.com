BeforeAll {
    $RepoRoot = Split-Path -Parent $PSScriptRoot
    $ScriptsRoot = Join-Path $RepoRoot 'scripts'
}

Describe 'Script naming conventions' {

    Context 'scripts/ root — entry points only' {
        BeforeAll {
            $AllowedRootScripts = @('install.sh', 'bootstrap.sh', 'build.sh')
            $RootShFiles = @(Get-ChildItem -Path $ScriptsRoot -Filter '*.sh' -File)
        }

        It 'only contains allowed entry-point scripts' {
            $Violations = @($RootShFiles | Where-Object { $AllowedRootScripts -notcontains $_.Name })
            $Because = if ($Violations.Count -gt 0) {
                "Move to a subfolder: $($Violations.Name -join ', ')"
            } else { 'only entry points should live at scripts/ root' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'install/ — numbered pipeline steps' {
        BeforeAll {
            $InstallDir = Join-Path $ScriptsRoot 'install'
            $InstallScripts = @(Get-ChildItem -Path $InstallDir -Filter '*.sh' -File -ErrorAction SilentlyContinue)
        }

        It 'all top-level install scripts match NN-verb-noun.sh pattern' {
            $Violations = @($InstallScripts | Where-Object {
                $_.Name -notmatch '^\d{2}-[a-z][a-z0-9-]+\.sh$'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Bad names: $($Violations.Name -join ', ')"
            } else { 'install scripts must be NN-verb-noun.sh' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'components/ — service scripts' {
        BeforeAll {
            $CompDir = Join-Path $ScriptsRoot 'components'
            $CompScripts = @(Get-ChildItem -Path $CompDir -Filter '*.sh' -File -ErrorAction SilentlyContinue)
        }

        It 'all component scripts are lowercase kebab-case' {
            $Violations = @($CompScripts | Where-Object {
                $_.Name -notmatch '^[a-z][a-z0-9-]*\.sh$'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Bad names: $($Violations.Name -join ', ')"
            } else { 'component scripts must be lowercase kebab-case' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'bundles/ — orchestration scripts' {
        BeforeAll {
            $BundleDir = Join-Path $ScriptsRoot 'bundles'
            $BundleScripts = @(Get-ChildItem -Path $BundleDir -Filter '*.sh' -File -ErrorAction SilentlyContinue)
        }

        It 'all bundle scripts are lowercase kebab-case' {
            $Violations = @($BundleScripts | Where-Object {
                $_.Name -notmatch '^[a-z][a-z0-9-]*\.sh$'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Bad names: $($Violations.Name -join ', ')"
            } else { 'bundle scripts must be lowercase kebab-case' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'host/ — subsystem scripts' {
        BeforeAll {
            $HostDir = Join-Path $ScriptsRoot 'host'
            $HostScripts = @(Get-ChildItem -Path $HostDir -Filter '*.sh' -File -ErrorAction SilentlyContinue)
        }

        It 'all host scripts are lowercase single-word or kebab-case' {
            $Violations = @($HostScripts | Where-Object {
                $_.Name -notmatch '^[a-z][a-z0-9-]*\.sh$'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Bad names: $($Violations.Name -join ', ')"
            } else { 'host scripts must be lowercase kebab-case' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'lib/ — shared libraries' {
        BeforeAll {
            $LibDir = Join-Path $ScriptsRoot 'lib'
            $LibScripts = @(Get-ChildItem -Path $LibDir -Filter '*.sh' -File -ErrorAction SilentlyContinue)
        }

        It 'all lib scripts are lowercase kebab-case' {
            $Violations = @($LibScripts | Where-Object {
                $_.Name -notmatch '^[a-z][a-z0-9-]*\.sh$'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Bad names: $($Violations.Name -join ', ')"
            } else { 'lib scripts must be lowercase kebab-case' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'utils/ — operational tools' {
        BeforeAll {
            $UtilsDir = Join-Path $ScriptsRoot 'utils'
            $UtilsShScripts = @(Get-ChildItem -Path $UtilsDir -Filter '*.sh' -File -ErrorAction SilentlyContinue)
        }

        It 'all utils shell scripts are kebab-case' {
            $Violations = @($UtilsShScripts | Where-Object {
                $_.Name -notmatch '^[a-z][a-z0-9-]*\.sh$'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Bad names: $($Violations.Name -join ', ')"
            } else { 'utils scripts must be kebab-case' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'issuefixers/ — temporary patches' {
        BeforeAll {
            $FixerDir = Join-Path $ScriptsRoot 'issuefixers'
            $FixerScripts = @(Get-ChildItem -Path $FixerDir -Filter '*.sh' -File -Force -ErrorAction SilentlyContinue)
        }

        It 'all issuefixer scripts match .issuefixerISSUE-NNN.sh pattern' {
            $Violations = @($FixerScripts | Where-Object {
                $_.Name -notmatch '^\.issuefixerISSUE-\d{3}\.sh$'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Bad names: $($Violations.Name -join ', ')"
            } else { 'issuefixer scripts must match .issuefixerISSUE-NNN.sh' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }
}

Describe 'Script file requirements' {

    Context 'shebang lines' {
        BeforeAll {
            $AllShFiles = @(Get-ChildItem -Path $ScriptsRoot -Filter '*.sh' -Recurse -File -Force)
        }

        It 'all .sh files have #!/usr/bin/env bash shebang' {
            $Violations = [System.Collections.Generic.List[string]]::new()
            foreach ($File in $AllShFiles) {
                $FirstLine = Get-Content $File.FullName -TotalCount 1
                if ($FirstLine -ne '#!/usr/bin/env bash') {
                    $RelPath = $File.FullName.Substring($RepoRoot.Length + 1)
                    $Violations.Add("$RelPath (has: $FirstLine)")
                }
            }
            $Because = if ($Violations.Count -gt 0) {
                "Missing shebang: $($Violations -join '; ')"
            } else { 'all shell scripts need #!/usr/bin/env bash' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'no underscores or camelCase in shell script filenames' {
        BeforeAll {
            $AllShFiles = @(Get-ChildItem -Path $ScriptsRoot -Filter '*.sh' -Recurse -File -Force)
        }

        It 'no shell script filenames contain underscores' {
            $Violations = @($AllShFiles | Where-Object { $_.Name -match '_' })
            $Because = if ($Violations.Count -gt 0) {
                "Underscores found: $($Violations.Name -join ', ')"
            } else { 'shell scripts use kebab-case, not snake_case' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }

        It 'no shell script filenames contain uppercase letters' {
            # Exclude hidden issuefixer files (matched by their own rule)
            $Violations = @($AllShFiles | Where-Object {
                $_.Name -notmatch '^\.issuefixer' -and $_.Name -cmatch '[A-Z]'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Uppercase found: $($Violations.Name -join ', ')"
            } else { 'shell scripts must be lowercase' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'Python script conventions in scripts/' {
        BeforeAll {
            $AllPyFiles = @(Get-ChildItem -Path $ScriptsRoot -Filter '*.py' -Recurse -File)
        }

        It 'all .py files are kebab-case' {
            $Violations = @($AllPyFiles | Where-Object {
                $_.Name -notmatch '^[a-z][a-z0-9-]*\.py$'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Bad names: $($Violations.Name -join ', ')"
            } else { 'Python scripts in scripts/ must be kebab-case' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }

        It 'all .py files have #!/usr/bin/env python3 shebang' {
            $Violations = [System.Collections.Generic.List[string]]::new()
            foreach ($File in $AllPyFiles) {
                $FirstLine = Get-Content $File.FullName -TotalCount 1
                if ($FirstLine -ne '#!/usr/bin/env python3') {
                    $RelPath = $File.FullName.Substring($RepoRoot.Length + 1)
                    $Violations.Add("$RelPath (has: $FirstLine)")
                }
            }
            $Because = if ($Violations.Count -gt 0) {
                "Missing shebang: $($Violations -join '; ')"
            } else { 'Python scripts need #!/usr/bin/env python3' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'Open WebUI functions use snake_case' {
        BeforeAll {
            $FuncDir = Join-Path $RepoRoot 'resources' 'open-webui-functions'
            $FuncFiles = @()
            if (Test-Path $FuncDir) {
                $FuncFiles = @(Get-ChildItem -Path $FuncDir -Filter '*.py' -File)
            }
        }

        It 'all Open WebUI function files are snake_case' {
            $Violations = @($FuncFiles | Where-Object {
                $_.Name -notmatch '^[a-z][a-z0-9_]*\.py$'
            })
            $Because = if ($Violations.Count -gt 0) {
                "Bad names: $($Violations.Name -join ', ')"
            } else { 'Open WebUI functions must be snake_case.py' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }
}
