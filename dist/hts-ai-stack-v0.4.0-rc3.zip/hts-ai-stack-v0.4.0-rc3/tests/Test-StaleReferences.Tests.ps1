BeforeAll {
    $RepoRoot = Split-Path -Parent $PSScriptRoot

    # Collect all CONTEXT.md, REFERENCES.md, and CLAUDE.md files
    $script:FrameworkFiles = @(
        Get-ChildItem -Path $RepoRoot -Filter 'CONTEXT.md' -Recurse -File
        Get-ChildItem -Path $RepoRoot -Filter 'REFERENCES.md' -Recurse -File
        Get-Item -Path (Join-Path $RepoRoot 'CLAUDE.md') -ErrorAction SilentlyContinue
    ) | Where-Object { $_ -ne $null }
}

Describe 'Stale reference checks' {

    Context 'Markdown links point to existing files' {
        BeforeAll {
            $script:BrokenLinks = [System.Collections.Generic.List[string]]::new()

            foreach ($File in $script:FrameworkFiles) {
                $Content = Get-Content $File.FullName -Raw
                $FileDir = $File.DirectoryName

                # Extract markdown links [text](target) — skip URLs, anchors, mailto
                $LinkMatches = [regex]::Matches($Content, '\[([^\]]*)\]\(([^)]+)\)')
                foreach ($Match in $LinkMatches) {
                    $Target = $Match.Groups[2].Value

                    # Skip external URLs and anchor-only links
                    if ($Target -match '^(https?://|mailto:|#)') { continue }

                    # Skip bare placeholder tokens (e.g. [text](url) in templates)
                    if ($Target -match '^[a-z]+$' -and $Target.Length -le 10) { continue }

                    # Strip anchor fragment from path
                    $Target = $Target -replace '#.*$', ''
                    if ([string]::IsNullOrWhiteSpace($Target)) { continue }

                    # Handle absolute-from-root paths (leading /)
                    if ($Target.StartsWith('/')) {
                        $ResolvedPath = Join-Path $RepoRoot $Target.TrimStart('/')
                    }
                    else {
                        $ResolvedPath = Join-Path $FileDir $Target
                    }

                    $ResolvedPath = [System.IO.Path]::GetFullPath($ResolvedPath)

                    if (-not (Test-Path -LiteralPath $ResolvedPath)) {
                        $RelFile = $File.FullName.Substring($RepoRoot.Length + 1)
                        $script:BrokenLinks.Add("$RelFile → $($Match.Groups[2].Value)")
                    }
                }
            }
        }

        It 'all markdown links in framework files resolve to existing paths' {
            $Because = if ($script:BrokenLinks.Count -gt 0) {
                "Broken links:`n$($script:BrokenLinks -join "`n")"
            } else { 'all links should point to existing files or folders' }
            $script:BrokenLinks | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'CLAUDE.md routing table entries resolve' {
        BeforeAll {
            $ClaudeFile = Join-Path $RepoRoot 'CLAUDE.md'
            $script:BrokenRoutes = [System.Collections.Generic.List[string]]::new()

            if (Test-Path $ClaudeFile) {
                $Lines = @(Get-Content $ClaudeFile)
                foreach ($Line in $Lines) {
                    # Match routing table rows: | Task | /folder | filename |
                    if ($Line -match '^\|\s*[^|]+\|\s*`?(/[^|`]*)`?\s*\|\s*`?([^|`]+)`?\s*\|') {
                        $Folder = $matches[1].Trim().TrimStart('/')
                        $ReadFile = $matches[2].Trim()

                        # Skip header/separator rows
                        if ($Folder -match '^-+$' -or $ReadFile -match '^-+$') { continue }
                        if ($Folder -eq 'Go to' -or $ReadFile -eq 'Read') { continue }

                        # Build full path
                        if ([string]::IsNullOrWhiteSpace($Folder) -or $Folder -eq '/') {
                            $FullPath = Join-Path $RepoRoot $ReadFile
                        }
                        else {
                            $FullPath = Join-Path $RepoRoot (Join-Path $Folder $ReadFile)
                        }

                        if (-not (Test-Path -LiteralPath $FullPath)) {
                            $script:BrokenRoutes.Add("$Folder → $ReadFile (expected: $FullPath)")
                        }
                    }
                }
            }
        }

        It 'all routing table entries point to existing files' {
            $Because = if ($script:BrokenRoutes.Count -gt 0) {
                "Broken routes:`n$($script:BrokenRoutes -join "`n")"
            } else { 'routing table should stay in sync with workspace' }
            $script:BrokenRoutes | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context 'Backtick path references resolve (outside code blocks)' {
        BeforeAll {
            $script:BrokenBackticks = [System.Collections.Generic.List[string]]::new()

            # Known planned paths that don't exist yet (allowlist)
            $script:PlannedPaths = @(
                'instances/rtx3060'
                'results/REFERENCES.md'
            )

            foreach ($File in $script:FrameworkFiles) {
                $Lines = @(Get-Content $File.FullName)
                $FileDir = $File.DirectoryName
                $RelFile = $File.FullName.Substring($RepoRoot.Length + 1)
                $InCodeBlock = $false

                # Skip refactor/ — contains aspirational target paths
                if ($RelFile -like 'refactor/*') { continue }

                foreach ($Line in $Lines) {
                    # Track fenced code blocks
                    if ($Line -match '^```') {
                        $InCodeBlock = -not $InCodeBlock
                        continue
                    }
                    if ($InCodeBlock) { continue }

                    # Extract backtick-wrapped strings containing /
                    $BacktickMatches = [regex]::Matches($Line, '`([^`]+/[^`]+)`')
                    foreach ($Match in $BacktickMatches) {
                        $Path = $Match.Groups[1].Value

                        # Skip URLs, API endpoints, globs, regex, commands
                        if ($Path -match '^(https?://|mailto:)') { continue }
                        if ($Path -match '^/api/|^/v[0-9]+/') { continue }
                        if ($Path -match '[\*\?\^]') { continue }
                        if ($Path -match '^\s*(docker|npm|curl|git|sudo|bash|pwsh|python3?|pip)\s') { continue }

                        # Skip shebangs, system paths, template placeholders
                        if ($Path -match '^#!') { continue }
                        if ($Path -match '^/(etc|usr|var|tmp|proc|sys)/') { continue }
                        if ($Path -match '(YYYYMMDD|owner-repo|arXiv-ID)') { continue }

                        # Skip bare placeholder tokens (e.g. [text](url))
                        if ($Path -match '^[a-z]+$' -and $Path.Length -le 10) { continue }

                        # Skip gh CLI examples and documentation-only service paths
                        if ($Path -match '^\s*gh\s') { continue }
                        if ($Path -match '^/services/') { continue }

                        # Skip markdown link syntax inside backticks
                        if ($Path -match '^\[.*\]\(.*\)$') { continue }

                        # Skip container name patterns (no file extension, no /)
                        # Already filtered by requiring / above

                        # Strip trailing description text after spaces
                        $Path = ($Path -split '\s')[0]

                        # Check planned paths allowlist
                        $IsPlanned = $false
                        foreach ($Planned in $script:PlannedPaths) {
                            if ($Path -match [regex]::Escape($Planned)) {
                                $IsPlanned = $true
                                break
                            }
                        }
                        if ($IsPlanned) { continue }

                        # Resolve path — try relative to file dir first, then repo root
                        if ($Path.StartsWith('/')) {
                            $ResolvedPath = Join-Path $RepoRoot $Path.TrimStart('/')
                        }
                        else {
                            $ResolvedPath = Join-Path $FileDir $Path
                        }

                        # Normalize trailing slashes for directory checks
                        $ResolvedPath = $ResolvedPath.TrimEnd('/')
                        $ResolvedPath = [System.IO.Path]::GetFullPath($ResolvedPath)

                        # Fall back to repo root if file-relative resolution fails
                        if (-not (Test-Path -LiteralPath $ResolvedPath)) {
                            $RootPath = Join-Path $RepoRoot $Path
                            $RootPath = $RootPath.TrimEnd('/')
                            $RootPath = [System.IO.Path]::GetFullPath($RootPath)
                            if (Test-Path -LiteralPath $RootPath) {
                                continue
                            }
                        }

                        if (-not (Test-Path -LiteralPath $ResolvedPath)) {
                            $script:BrokenBackticks.Add("$RelFile → $($Match.Groups[1].Value)")
                        }
                    }
                }
            }
        }

        It 'backtick path references outside code blocks resolve to existing paths' {
            $Because = if ($script:BrokenBackticks.Count -gt 0) {
                "Broken backtick refs:`n$($script:BrokenBackticks -join "`n")"
            } else { 'backtick paths should point to existing files or folders' }
            $script:BrokenBackticks | Should -BeNullOrEmpty -Because $Because
        }
    }
}
