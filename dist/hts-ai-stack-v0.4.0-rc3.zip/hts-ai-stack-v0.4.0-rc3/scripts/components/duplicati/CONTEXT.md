# Duplicati Component

Last updated: 2026-04-17

## What happens here

Duplicati provides encrypted, incremental backups of stack data and
configuration to local or cloud storage. Used in the stack for
disaster recovery and data protection.

## Files and structure

| File | Purpose |
|------|---------|
| `duplicati.sh` | Full lifecycle: install, configure, start, stop, health |
| `duplicati.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Authentication

Duplicati is **single-user** — there is no username concept. Login uses
a password only; leave the username field blank (or type anything — it's
ignored).

- **Password source:** `DUPLICATI_WEB_PASSWORD` in `.env` →
  passed to the container as `DUPLICATI__WEBSERVICE_PASSWORD`.
- **Generated on first configure:** if missing from `.env`,
  `duplicati_configure` generates a 24-byte URL-safe random token.
- **Password read on every container start:** Duplicati reads the env var
  on boot and overwrites the stored password hash, so a simple restart
  applies changes from `.env`.

### Reset the password

```bash
./scripts/components/duplicati/duplicati.sh --reset-password
```

This regenerates `DUPLICATI_WEB_PASSWORD` in `.env` and restarts the
container so the new value takes effect. No volume wipe required.

### Encryption key (separate from web password)

`DUPLICATI_ENCRYPTION_KEY` encrypts the Duplicati **settings database**
(backup job configs, schedules, remote credentials). It is **not** the
backup data encryption passphrase — that's set per-backup-job in the UI.

If you lose `DUPLICATI_ENCRYPTION_KEY`, the settings volume becomes
unreadable. Back up `.env` and the `duplicati_config` volume together.
