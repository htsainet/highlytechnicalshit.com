# Nerd Dictation — Desktop Voice-to-Keystrokes

**Priority:** LOW
**Effort:** 1–2 hours
**Risk:** Low-medium — GPL-2.0; host-only install (no Docker); requires display server and audio hardware.
**Target Release:** v0.6.0
**Depends on:** VOSK model on host (not the Docker service in FEATURE-028)
**Blocks:** Nothing

## Problem

Hands-free desktop text input for developer workflows. When working at the machine,
binding voice-to-keystrokes to hotkeys enables dictation into any application (terminal,
editor, browser) without requiring the target app to support voice input natively.

## Current State

Not in the stack. `ideasman42/nerd-dictation` is not tracked in feature-repos.

## Architecture

Host-only install. Nerd Dictation is a single Python script that:

1. Records audio from the microphone via `parec` (PulseAudio) or `pw-cat` (PipeWire)
2. Transcribes with the `vosk` Python library (local model, no network)
3. Outputs as simulated keystrokes via `xdotool` (X11) or `ydotool` (Wayland)

**Deployment constraints:**

- Cannot be containerised — requires direct access to audio hardware, display server, and
  keyboard input injection. No SSH-only use case.
- Requires host Python, PulseAudio/PipeWire, and xdotool/ydotool.
- VOSK model installed on **host** (~50MB). This is separate from the Docker VOSK API
  service in FEATURE-028, which serves the stack's internal transcription needs.

## Implementation Steps

### P0 — Host install script

- [ ] **1. Create `scripts/components/nerd-dictation/nerd-dictation.sh`**
  - `nerd_dictation_install`:
    1. `pip install vosk` on host
    2. Clone `ideasman42/nerd-dictation` to `~/.local/share/nerd-dictation/`
    3. Download VOSK model (e.g., `vosk-model-en-us-0.22-lgraph`) to `~/.config/nerd-dictation/`
    4. Print hotkey setup instructions
  - `nerd_dictation_health`: verify `vosk` importable, model path exists, `nerd-dictation` script present
  - `nerd_dictation_begin` / `nerd_dictation_end`: convenience wrappers for hotkey scripts

- [ ] **2. Print hotkey instructions** in `nerd_dictation_install` output:

  ```text
  Suggested hotkeys:
    Begin: ~/.local/share/nerd-dictation/nerd-dictation begin
    End:   ~/.local/share/nerd-dictation/nerd-dictation end
  Bind these in your desktop environment (GNOME, KDE, i3, etc.)
  ```

### P1 — Audio backend detection

Auto-detect PipeWire vs PulseAudio and set the correct backend:

```bash
if command -v pw-cat &>/dev/null; then
  NERD_DICT_AUDIO="--input pw-cat"
else
  NERD_DICT_AUDIO="--input parec"
fi
```

### P2 — STDOUT mode for scripting

For headless scripting (no keyboard injection needed):

```bash
nerd-dictation begin --output=STDOUT
```

Document this in the component script for pipelines that want transcription
without display server dependency.

## Acceptance Criteria

- `nerd_dictation_install` completes without error on Ubuntu 22.04+
- `nerd_dictation_health` returns success
- `nerd-dictation begin` + `nerd-dictation end` produces text in focused window
- Works on X11 and Wayland (auto-detected)

## Note on Relationship to FEATURE-028

FEATURE-028 (Vosk API) runs the same VOSK engine in Docker as a **gRPC server** for
stack-internal use. Nerd Dictation uses `pip install vosk` **on the host** for
zero-latency local transcription without a network hop. They share the upstream VOSK
library but are completely independent deployments.

## Related

- [FEATURE-028](FEATURE-028.md) — Vosk API Docker service (stack-internal STT)
- [FEATURE-026](FEATURE-026.md) — Faster-Whisper (GPU STT service)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md) — row: `ideasman42/nerd-dictation`
