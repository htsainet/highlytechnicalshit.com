#!/usr/bin/env bash
# scripts/host/nas.sh — NAS/NFS configuration: idmapd, fstab, mount, validate
#
# Standalone usage:
#   ./scripts/host/nas.sh              # configure + mount + validate
#   ./scripts/host/nas.sh --verify     # validate NAS reachability only
#   ./scripts/host/nas.sh --mount      # mount only (assumes fstab is configured)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
NAS_HOST="${NAS_HOST:-}"
NAS_NFS4_DOMAIN="${NAS_NFS4_DOMAIN:-htsai}"
NAS_ENABLED="${NAS_ENABLED:-false}"
HTS_TAG="# hts-ai-stack"

# NFS mount options (NFSv4.1, optimized for Synology)
NFS_OPTS="nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=5,_netdev,x-systemd.automount"

# ── Functions ────────────────────────────────────────────────────────────────

# nas_validate — Check if NAS host is reachable (ping + showmount)
nas_validate() {
  step "NAS — validate"

  if [[ -z "$NAS_HOST" ]]; then
    fail "NAS_HOST not set in .env"
    return 1
  fi

  info "Pinging $NAS_HOST..."
  if ! ping -c 2 -W 3 "$NAS_HOST" >/dev/null 2>&1; then
    fail "Cannot reach $NAS_HOST — check network/tailscale"
    return 1
  fi
  ok "NAS host $NAS_HOST reachable."

  if command -v showmount &>/dev/null; then
    info "NFS exports on $NAS_HOST:"
    showmount -e "$NAS_HOST" 2>/dev/null || warn "showmount failed — NFS may not be enabled"
  else
    info "(showmount not available — install nfs-common to list NFS exports)"
  fi
}

# nas_backup_config — Backup /etc/fstab before modification
nas_backup_config() {
  step "NAS — backup fstab"

  local backup_dir="$REPO_DIR/config/backups"
  local timestamp
  timestamp=$(date +%Y%m%d-%H%M%S)
  local backup_file="$backup_dir/fstab-${timestamp}.bak"

  mkdir -p "$backup_dir"
  if [[ -f /etc/fstab ]]; then
    sudo cp /etc/fstab "$backup_file"
    ok "fstab backed up to $backup_file"
  else
    warn "/etc/fstab does not exist."
  fi
}

# nas_configure_idmap — Write /etc/idmapd.conf with NFSv4 domain
nas_configure_idmap() {
  step "NAS — configure idmapd"

  # Ensure nfs-common is installed (provides idmapd)
  if ! command -v idmapd &>/dev/null && ! dpkg -l nfs-common &>/dev/null 2>&1; then
    info "Installing nfs-common..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq nfs-common
  fi

  local idmapd_conf="/etc/idmapd.conf"
  local domain="$NAS_NFS4_DOMAIN"

  if [[ -f "$idmapd_conf" ]]; then
    if grep -q "^Domain" "$idmapd_conf"; then
      sudo sed -i "s|^Domain.*|Domain = ${domain}|" "$idmapd_conf"
    elif grep -q "^\[General\]" "$idmapd_conf"; then
      sudo sed -i "/^\[General\]/a Domain = ${domain}" "$idmapd_conf"
    else
      printf '\n[General]\nDomain = %s\n' "$domain" | sudo tee -a "$idmapd_conf" >/dev/null
    fi
  else
    printf '[General]\nDomain = %s\n' "$domain" | sudo tee "$idmapd_conf" >/dev/null
  fi
  ok "idmapd.conf → Domain = ${domain}"

  # Restart idmapd so the new domain takes effect
  if systemctl is-active --quiet nfs-idmapd 2>/dev/null; then
    sudo systemctl restart nfs-idmapd && ok "nfs-idmapd restarted"
  fi
}

# nas_configure_fstab — Add NFS mount entries to /etc/fstab (idempotent)
nas_configure_fstab() {
  step "NAS — configure fstab"

  if [[ -z "$NAS_HOST" ]]; then
    fail "NAS_HOST not set in .env"
    return 1
  fi

  # Read mount paths from stack.json via Python
  local config_file="$REPO_DIR/config/stack.json"
  if [[ ! -f "$config_file" ]]; then
    warn "config/stack.json not found — cannot read NAS mount definitions."
    return 1
  fi

  local nas_mounts
  nas_mounts=$(python3 - "$config_file" <<'PYEOF'
import json, sys
with open(sys.argv[1]) as f:
    nas = json.load(f).get("nas", {})
if not nas.get("enabled"):
    sys.exit(0)
host = nas.get("host", "")
uses = nas.get("uses", [])
if "model_cache" in uses and nas.get("model_cache_share") and nas.get("model_cache_mount"):
    print(f"{host}:{nas['model_cache_share']} {nas['model_cache_mount']}")
if "docker_backups" in uses and nas.get("docker_backup_share") and nas.get("docker_backup_mount"):
    print(f"{host}:{nas['docker_backup_share']} {nas['docker_backup_mount']}")
if "timeshift" in uses and nas.get("timeshift_share") and nas.get("timeshift_mount"):
    print(f"{host}:{nas['timeshift_share']} {nas['timeshift_mount']}")
PYEOF
  ) || true

  if [[ -z "$nas_mounts" ]]; then
    info "No NAS mounts defined in stack.json (or NAS disabled)."
    return 0
  fi

  while IFS=' ' read -r share mountpoint; do
    [[ -z "$share" || -z "$mountpoint" ]] && continue

    # Create mount point if missing
    sudo mkdir -p "$mountpoint"

    local fstab_line="${share}  ${mountpoint}  nfs  ${NFS_OPTS}  0  0  ${HTS_TAG}"

    # Idempotent: remove any existing entry for this mountpoint, then append
    if grep -q "[[:space:]]${mountpoint}[[:space:]]" /etc/fstab 2>/dev/null; then
      sudo sed -i "\|[[:space:]]${mountpoint}[[:space:]]|d" /etc/fstab
      info "Replaced existing fstab entry for ${mountpoint}"
    fi

    echo "$fstab_line" | sudo tee -a /etc/fstab >/dev/null
    ok "fstab: ${share} → ${mountpoint}"
  done <<< "$nas_mounts"

  info "Reloading systemd daemon..."
  sudo systemctl daemon-reload
}

# nas_mount — Activate all NFS mounts
nas_mount() {
  step "NAS — mount"
  info "Running mount -a..."
  sudo mount -a || warn "mount -a reported errors — check dmesg"

  # Create model cache subdirectories so Docker doesn't try to chown them
  local model_cache="${MODEL_CACHE_MOUNT:-}"
  if [[ -n "$model_cache" ]] && [[ -d "$model_cache" ]]; then
    sudo mkdir -p "$model_cache"/{ollama,ollama-test,sd-checkpoints}
    sudo chmod 755 "$model_cache"/{ollama,ollama-test,sd-checkpoints}
    ok "Model cache subdirectories created in ${model_cache}."
  fi

  ok "Mounts activated."
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --verify) ACTION="verify"; shift ;;
      --mount)  ACTION="mount"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      if [[ "$NAS_ENABLED" != "true" ]]; then
        info "NAS is not enabled (NAS_ENABLED != true in .env). Nothing to do."
        exit 0
      fi
      nas_validate
      nas_backup_config
      nas_configure_idmap
      nas_configure_fstab
      nas_mount
      ;;
    verify)
      nas_validate
      ;;
    mount)
      nas_mount
      ;;
  esac
fi
