# 06-start-stack.sh — Start Ollama + NemoClaw

Starts Ollama (prod + test) and connects both NemoClaw sandboxes.

```bash
./06-start-stack.sh
```

---

## Modes

| Flag | What starts |
|---|---|
| *(none)* | Ollama (prod + test) + NemoClaw (both sandboxes) |
| `--test` | Ollama only (skips NemoClaw connect) |

---

## Services started

| Service | Port |
|---|---|
| Ollama — Production | 11434 |
| Ollama — Test | 11435 |
| NemoClaw — prod sandbox | 18789 |
| NemoClaw — test sandbox | 18790 |

NemoClaw manages its own OpenClaw gateway instance per sandbox — there is no
standalone OpenClaw container.

---

## Prerequisites

- Steps 00–04 completed (Docker, NVIDIA toolkit, NemoClaw sandboxes onboarded)
- Sandboxes created: `ubuntu-ai-assistant-prod`, `ubuntu-ai-assistant-test`

If sandboxes are not yet created, run:

```bash
./04-setup-nemoclaw.sh
```

---

## Usage

```bash
# Full stack (Ollama + NemoClaw both sandboxes)
./06-start-stack.sh

# Ollama only (skip NemoClaw connect)
./06-start-stack.sh --test
```

---

## Teardown

```bash
# Stop Ollama instances
docker compose -f instances/prod/docker-compose.yml stop ollama-prod
docker compose -f instances/test/docker-compose.yml stop ollama-test

# Stop NemoClaw sandbox
nemoclaw ubuntu-ai-assistant-prod down
nemoclaw ubuntu-ai-assistant-test down
```
