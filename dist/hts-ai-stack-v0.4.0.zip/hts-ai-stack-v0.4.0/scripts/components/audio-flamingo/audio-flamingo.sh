#!/usr/bin/env bash
# scripts/components/audio-flamingo/audio-flamingo.sh — Audio Flamingo: install, configure, start, health
#
# NVIDIA Audio Flamingo 3 — audio understanding LLM (sound, music, speech).
# Runs inference via FastAPI with GPU (CUDA) or CPU-only mode.
#
# Standalone usage:
#   ./scripts/components/audio-flamingo/audio-flamingo.sh              # full: install + configure + start + health
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --install    # install only (build image)
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --configure  # configure only
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --start      # start only
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --stop       # stop
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --restart    # restart (stop + start)
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --health     # health check only
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --status     # show status + port + health
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --destroy    # destroy (remove containers + volumes)
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --cpu        # force CPU-only inference
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --gpu        # force GPU inference
#
# Combine device flag with an action:
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --cpu --start
#   ./scripts/components/audio-flamingo/audio-flamingo.sh --gpu --restart
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"
source "$REPO_DIR/scripts/lib/gpu.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
AUDIO_FLAMINGO_PORT="${AUDIO_FLAMINGO_PORT:-8601}"
AF_DEVICE="${AF_DEVICE:-auto}"

# ── Functions ────────────────────────────────────────────────────────────────

audio_flamingo_install() {
  step "Audio Flamingo — install"
  local dockerfile="$REPO_DIR/docker/audio-flamingo/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    warn "Audio Flamingo Dockerfile not found: $dockerfile"
    info "Create a Dockerfile that clones NVIDIA/audio-flamingo,"
    info "installs dependencies, and downloads the HuggingFace checkpoint."
    return 1
  fi
  compose_build --profile audio-flamingo
  ok "Audio Flamingo image built."
}

audio_flamingo_configure() {
  step "Audio Flamingo — configure"
  info "Port: ${AUDIO_FLAMINGO_PORT}"
  info "Device: ${AF_DEVICE}"
  info "Model: nvidia/audio-flamingo-3-hf (7B, requires ~16GB VRAM at fp16)"
  ok "Audio Flamingo configured."
}

audio_flamingo_start() {
  step "Audio Flamingo — start (device=${AF_DEVICE})"
  # When AF_DEVICE=auto, check free VRAM and fall back to CPU if the GPU
  # is too busy (e.g. Ollama has models loaded). This is a point-in-time
  # snapshot — FEATURE-052 will replace it with a proper VRAM budget system.
  if [[ "$AF_DEVICE" == "auto" ]]; then
    local free_gb
    free_gb=$(get_gpu_free_vram_gb)
    if [[ "$free_gb" -lt 5 ]]; then
      warn "Only ${free_gb}GB free VRAM — not enough for Audio Flamingo GPU mode."
      info "Falling back to CPU inference (slower but functional)."
      info "To force GPU, free up VRAM and run: --gpu --start"
      AF_DEVICE="cpu"
    else
      ok "Free VRAM check: ${free_gb}GB available — using GPU"
    fi
  elif [[ "$AF_DEVICE" == "gpu" ]]; then
    if ! check_free_vram 5 "Audio Flamingo"; then
      warn "Proceeding anyway (--gpu was explicitly requested)."
    fi
  fi
  AF_DEVICE="$AF_DEVICE" compose_up --profile audio-flamingo
  ok "Audio Flamingo started on port ${AUDIO_FLAMINGO_PORT} (device=${AF_DEVICE})."
}

audio_flamingo_stop() {
  step "Audio Flamingo — stop"
  compose_down --profile audio-flamingo
  ok "Audio Flamingo stopped."
}

audio_flamingo_health() {
  local label="Audio Flamingo :${AUDIO_FLAMINGO_PORT}"
  printf "  %-35s" "$label"
  if curl -sf "http://localhost:${AUDIO_FLAMINGO_PORT}/health" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${AUDIO_FLAMINGO_PORT}/health)"
    return 1
  fi
}

audio_flamingo_restart() {
  audio_flamingo_stop
  audio_flamingo_start
}

audio_flamingo_destroy() {
  step "Audio Flamingo — destroy"
  compose_down --profile audio-flamingo -v
  ok "Audio Flamingo destroyed."
}

audio_flamingo_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=audio-flamingo" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Audio Flamingo is running (port ${AUDIO_FLAMINGO_PORT})"
  else
    warn "Audio Flamingo is not running."
  fi
  audio_flamingo_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      --cpu)       AF_DEVICE="cpu";    export AF_DEVICE; shift ;;
      --gpu)       AF_DEVICE="gpu";    export AF_DEVICE; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   audio_flamingo_install   ;;
    configure) audio_flamingo_configure ;;
    start)     audio_flamingo_start     ;;
    stop)      audio_flamingo_stop      ;;
    restart)   audio_flamingo_restart   ;;
    health)    audio_flamingo_health    ;;
    status)    audio_flamingo_status    ;;
    destroy)   audio_flamingo_destroy   ;;
    default)
      audio_flamingo_install
      audio_flamingo_configure
      audio_flamingo_start
      audio_flamingo_health
      ;;
  esac
fi
