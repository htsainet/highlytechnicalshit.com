# 03-setup-models — Model Setup Documentation

Covers model seeding for the **dual-backend** architecture: Ollama on GPU and
BitNet on CPU, both fronted by **llama-swap** as a unified LLM router.

---

## File Structure

```text
03-setup-models.sh           ← master wrapper
scripts/install/models/
  prod.sh                    ← Ollama GPU model pull
  helpers.sh                 ← shared functions (not a run target)
```

---

## Quick Start

Pull all Ollama models:

```bash
./03-setup-models.sh
```

BitNet ships its own model baked into the container image — no pull step needed.
llama-swap routes requests based on model name automatically.

---

## What Each Script Does

The model seeding script follows this pattern:

1. Create host model directories (`~/models/`, `~/sd-models/`, `~/sd-outputs/`)
2. Start the Ollama GPU container
3. Wait for it to be ready
4. Pull each Ollama model (skip if already present)
5. Set the default model
6. Pull/download Stable Diffusion checkpoints (skip if already present)

---

## Architecture

```text
                              ┌──→ hts-ai-ollama-gpu  (port 11434, NVIDIA GPU)
hts-ai-llama-swap:8080 ──────┤
                              └──→ hts-ai-bitnet-cpu  (internal, CPU only)
```

### Ollama GPU (`hts-ai-ollama-gpu`)

GPU-accelerated inference. All consumer services reach it via llama-swap.

| Setting | Value |
|---------|-------|
| Ollama container | `hts-ai-ollama-gpu` |
| Ollama port | `11434` |
| SD container | `stable-diffusion-prod` |
| SD port | `7860` |
| Default model | `gemma4:e4b` |
| After setup | **Container left running** |

**Ollama models:**

- `gemma4:e4b`
- `mistral-nemo:latest`
- `qwen2.5:7b-instruct-q4_K_M`
- `qwen3.5:9b`
- `gurubot/ollamatron:8b-q4_K_M`
- `granite3.1-dense:8b`

**Stable Diffusion:** Factory defaults only — no checkpoints downloaded. The SD WebUI ships with a built-in model that is used as-is.

**To add a model to Ollama:** Add it to `OLLAMA_MODELS_PROD` in `scripts/install/models/prod.sh`
and re-run the script. It will skip models already present and only pull the new one.
Also add the model name to `config/llama-swap.yaml` so llama-swap can route to it.

---

### BitNet CPU (`hts-ai-bitnet-cpu`)

CPU-only 1-bit inference. Ships with its own model baked into the container.
No pull step needed — the model is available as `bitnet` via llama-swap.

| Setting | Value |
|---------|-------|
| Container | `hts-ai-bitnet-cpu` |
| Host port | *(none — internal only)* |
| Model name | `bitnet` |
| CPU limit | 4.0 cores |
| Memory limit | 8 GB |

**To promote a model to prod:** Add it to `OLLAMA_MODELS_PROD` in `scripts/install/models/prod.sh` and re-run that script.

---

## Host Directory Structure

Created automatically by any of the setup scripts:

```text
~/models/
  approved/        ← GGUFs promoted to prod (used via Modelfile)
  testing/         ← GGUFs being evaluated

~/sd-models/
  prod/
    checkpoints/
    loras/
    vae/
    embeddings/
  test/
    checkpoints/
    loras/
    vae/
    embeddings/

~/sd-outputs/
  prod/
  test/
```

---

## Promoting a Model from Test to Prod

```bash
# 1. Copy the GGUF from testing to approved
cp ~/models/testing/mymodel.gguf ~/models/approved/mymodel.gguf

# 2. Add the model to OLLAMA_MODELS_PROD in scripts/install/models/prod.sh

# 3. Re-run prod setup — skips existing models, only pulls new ones
./scripts/install/models/prod.sh
```

---

## Adding a New Model to an Environment

Edit the relevant array in the script and re-run. The skip-if-exists logic means only new models are downloaded:

```bash
# Edit scripts/install/models/test.sh and add your model to OLLAMA_MODELS_TEST
# Then re-run — existing models are skipped automatically
./scripts/install/models/test.sh
```

---

## Shared Helper Functions (`scripts/install/models/helpers.sh`)

| Function | Purpose |
|----------|---------|
| `wait_for_ollama <container> <port>` | Blocks until Ollama API responds, times out after 60s |
| `start_container <service>` | Runs `docker compose up -d <service>` |
| `stop_container <service>` | Runs `docker compose stop <service>` |
| `pull_ollama_if_missing <container> <port> <model>` | Pulls model only if not already present |
| `set_ollama_default <container> <model>` | Creates a `default` alias via Modelfile |
| `find_or_create_sd_volume <grep_term> <service>` | Finds the named volume, starts service to create it if needed |
| `download_sd_if_missing <volume> <filename> <url>` | Downloads a checkpoint via alpine/wget if not present |
| `create_model_dirs` | Creates the full `~/models` and `~/sd-models` directory tree |

---

## Port Reference

| Service | Port |
|---------|------|
| `ollama-prod` | `11434` |
| `ollama-test` | `11435` |
| `stable-diffusion-prod` | `7860` |
| `stable-diffusion-test` | `7861` |

---

## Notes

- **SD checkpoint URLs** — verify each URL at `huggingface.co` before running. Models are occasionally moved or deleted. Failed downloads are cleaned up automatically (partial files are removed).
- **`QUANT_TAG` placeholder** — `nvidia_Nemotron-Cascade-8B-GGUF` uses `Q4_K_M` by default. Change the quant tag in `scripts/install/models/test.sh` if you need a different quantization.
- **Re-running is safe** — all pull and download operations are idempotent. Already-present models are skipped with a `[SKIP]` message.
- **GPU access** — all three Ollama and SD instances request full NVIDIA GPU access via the compose `deploy.resources` block. Only one SD instance should be running at a time to avoid VRAM contention.
