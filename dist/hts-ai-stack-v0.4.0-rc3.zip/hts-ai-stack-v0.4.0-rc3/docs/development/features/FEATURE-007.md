# code-review-graph — Structural Code Knowledge via MCP

**Priority:** MEDIUM
**Target Release:** v0.6.0
**Effort:** ~2 hours (pip package, standard compose pattern)
**Risk:** Low — additive MCP server, no impact on existing services
**Depends on:** Nothing (standalone MCP server)
**Blocks:** Nothing

## Scope

Add [code-review-graph](https://github.com/tirth8205/code-review-graph) as an
optional MCP server that builds a persistent structural map of codebases using
Tree-sitter ASTs stored in SQLite. Exposes 22 MCP tools for blast-radius
analysis, architecture overview, risk-scored reviews, dead code detection, and
execution flow tracing.

### Use Cases

- **Blast-radius analysis** — when a file changes, trace every caller,
  dependent, and test that could be affected. Agent reads only those files
  instead of scanning the whole project
- **Risk-scored code reviews** — map diffs to affected functions, flows, and
  test gaps with severity scoring
- **Architecture overview** — auto-generated architecture map with coupling
  warnings and community detection
- **Refactoring support** — rename preview, dead code detection,
  community-driven suggestions
- **Agent integration** — any MCP-aware agent (OpenSpace, Goose, Open WebUI)
  can call the 22 tools for context-efficient code understanding

### Why Add It

- Reduces token waste: 8.2x average reduction in benchmarks across real repos
- Incremental updates in <2 seconds after initial build (~10s for 500 files)
- 19 languages supported (Python, TypeScript, Go, Rust, Java, C#, etc.)
- Local-only — SQLite in `.code-review-graph/`, no cloud dependency
- Already an MCP server — fits directly into the stack's MCP tool ecosystem

## Implementation Notes

### Docker approach

```yaml
# docker-compose.yml
code-review-graph:
  build: ./docker/code-review-graph
  image: hts-ai-code-review-graph
  container_name: hts-ai-code-review-graph
  profiles: [code-review-graph]
  ports:
    - "5001:5001"            # MCP SSE transport
  volumes:
    - code_review_graph_data:/app/data
    - /path/to/repos:/repos:ro  # read-only mount of repos to index
  environment:
    - CRG_PORT=5001
```

- Single-stage Python image: `pip install code-review-graph`
- MCP SSE server on port **5001** (next to OpenSpace MCP on 5000)
- Read-only volume mount to project repos for indexing
- No GPU needed — pure CPU, Tree-sitter parsing

### Alternative: host-side install

Since code-review-graph indexes local repos, running it host-side may be
simpler and avoids volume mount complexity:

```bash
pip install code-review-graph
code-review-graph install    # auto-detects AI tools, writes MCP config
code-review-graph build      # parse the codebase
```

This registers it as an MCP server in `.mcp.json` directly. Docker is
optional — evaluate during implementation.

### Port allocation

| Host Port | Service | Container | Profile |
|-----------|---------|-----------|---------|
| 5001 | code-review-graph MCP | hts-ai-code-review-graph | code-review-graph |

### MCP tools exposed (22 total)

Key tools include: `get_blast_radius`, `detect_changes`, `get_architecture`,
`find_dead_code`, `get_execution_flows`, `search_code`, `get_community_structure`,
`rename_preview`.

## Acceptance Criteria

- MCP SSE endpoint responds on port 5001
- `get_blast_radius` returns affected files for a known change
- OpenSpace or Open WebUI can discover and call graph tools
- Initial build completes for `hts-ai-stack` repo (< 15 seconds)
- Incremental update after file edit completes in < 2 seconds

## References

- Repo: <https://github.com/tirth8205/code-review-graph>
- Website: <https://code-review-graph.com/>
- MCP: <https://modelcontextprotocol.io/>
- PyPI: <https://pypi.org/project/code-review-graph/>
