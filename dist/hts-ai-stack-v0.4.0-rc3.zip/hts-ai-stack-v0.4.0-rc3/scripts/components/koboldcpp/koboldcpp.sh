#!/usr/bin/env bash
# scripts/components/koboldcpp/koboldcpp.sh — KoboldCpp interactive fiction engine
#
# Docker-based installer for KoboldCpp, a single-binary LLM runner with a
# built-in interactive fiction / text generation web UI. Supports GGUF models
# on CPU and GPU. OpenAI-compatible API at /v1/.
#
# Standalone usage:
#   ./scripts/components/koboldcpp/koboldcpp.sh              # full: install + configure + start + health
#   ./scripts/components/koboldcpp/koboldcpp.sh --install    # install only
#   ./scripts/components/koboldcpp/koboldcpp.sh --configure  # configure only
#   ./scripts/components/koboldcpp/koboldcpp.sh --start      # start only
#   ./scripts/components/koboldcpp/koboldcpp.sh --stop       # stop
#   ./scripts/components/koboldcpp/koboldcpp.sh --restart    # restart (stop + start)
#   ./scripts/components/koboldcpp/koboldcpp.sh --health     # health check only
#   ./scripts/components/koboldcpp/koboldcpp.sh --status     # show status + port + health
#   ./scripts/components/koboldcpp/koboldcpp.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
KOBOLDCPP_CONTAINER="${KOBOLDCPP_CONTAINER:-hts-ai-koboldcpp}"
KOBOLDCPP_PORT="${KOBOLDCPP_PORT:-5001}"

# ── Functions ────────────────────────────────────────────────────────────────

# koboldcpp_install — Build the KoboldCpp container image
koboldcpp_install() {
  step "KoboldCpp — install"
  compose_build --profile koboldcpp
  ok "KoboldCpp image built."
}

# koboldcpp_configure — Ensure .env has KoboldCpp port
koboldcpp_configure() {
  step "KoboldCpp — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^KOBOLDCPP_PORT=" "$env_file" 2>/dev/null; then
    printf 'KOBOLDCPP_PORT=%s\n' "$KOBOLDCPP_PORT" >> "$env_file"
    info "Added KOBOLDCPP_PORT=${KOBOLDCPP_PORT} to .env"
  fi

  info "Place GGUF model files in the koboldcpp_models volume or bind-mount a host directory."
  ok "KoboldCpp configured (port ${KOBOLDCPP_PORT})."
}

# koboldcpp_start — Bring up KoboldCpp via compose
koboldcpp_start() {
  step "KoboldCpp — start"
  compose_up --profile koboldcpp
  ok "KoboldCpp started on port ${KOBOLDCPP_PORT}."
}

# koboldcpp_stop — Bring down KoboldCpp
koboldcpp_stop() {
  step "KoboldCpp — stop"
  compose_down --profile koboldcpp
  ok "KoboldCpp stopped."
}

# koboldcpp_health — Probe the KoboldCpp web UI
koboldcpp_health() {
  health_probe "KoboldCpp :${KOBOLDCPP_PORT}" "http://localhost:${KOBOLDCPP_PORT}/"
}

koboldcpp_restart() {
  koboldcpp_stop
  koboldcpp_start
}

koboldcpp_destroy() {
  step "KoboldCpp — destroy"
  compose_down --profile koboldcpp -v
  ok "KoboldCpp destroyed."
}

koboldcpp_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=koboldcpp" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "KoboldCpp is running (port ${KOBOLDCPP_PORT})"
  else
    warn "KoboldCpp is not running."
  fi
  koboldcpp_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   koboldcpp_install   ;;
    configure) koboldcpp_configure ;;
    start)     koboldcpp_start     ;;
    stop)      koboldcpp_stop      ;;
    restart)   koboldcpp_restart   ;;
    health)    koboldcpp_health    ;;
    status)    koboldcpp_status    ;;
    destroy)   koboldcpp_destroy   ;;
    default)
      koboldcpp_install
      koboldcpp_configure
      koboldcpp_start
      koboldcpp_health
      ;;
  esac
fi
