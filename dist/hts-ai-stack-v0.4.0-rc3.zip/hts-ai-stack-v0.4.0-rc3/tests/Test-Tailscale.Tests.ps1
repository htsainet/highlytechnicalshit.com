$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/tailscale'
    $script:ComponentScript = Join-Path $script:ComponentDir 'tailscale.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'tailscale.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'tailscale file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'tailscale manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is tailscale' {
        $script:Manifest.id | Should -Be 'tailscale'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/tailscale/tailscale.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is tailscale' {
        $script:Manifest.func_prefix | Should -Be 'tailscale'
    }

    It 'category is admin' {
        $script:Manifest.category | Should -Be 'admin'
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'tailscale component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines tailscale_install function' {
        $script:ComponentContent | Should -Match 'tailscale_install\s*\(\)'
    }

    It 'defines tailscale_configure function' {
        $script:ComponentContent | Should -Match 'tailscale_configure\s*\(\)'
    }

    It 'defines tailscale_start function' {
        $script:ComponentContent | Should -Match 'tailscale_start\s*\(\)'
    }

    It 'defines tailscale_stop function' {
        $script:ComponentContent | Should -Match 'tailscale_stop\s*\(\)'
    }

    It 'defines tailscale_health function' {
        $script:ComponentContent | Should -Match 'tailscale_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/tailscale/tailscale\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'tailscale no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/tailscale\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/tailscale/tailscale\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
