# Identity

You are helping Tim build a series of installation and configuration scripts to spin up AI services using locally hosted models.

## Rules

- AI related services should use local LLM
- Services that benefit from GPU should take advantage of nVidia CUDA
- Offload non-GPU tasks to CPU
- Follow best practices for security
- Ask clarifying questions before making assumptions
- When you are unsure, say so

## Context & References Quick-Nav

| Task | Go to | Read |
|------|-------|------|
| Project overview / goals | `/` | `CONTEXT.md` |
| Architecture & references | `/` | `REFERENCES.md` |
| Documentation hub | `/docs` | `CONTEXT.md` |
| Pester tests | `/tests` | `CONTEXT.md` |
| Installation scripts | `/scripts` | `CONTEXT.md` |
| Feature tracking | `/docs/development/features` | `REFERENCES.md` |
| Planning hub | `/docs/planning` | `CONTEXT.md` |
| github repo review | `/docs/planning/repo-review` | `CONTEXT.md` |
| Security architecture review | `/docs/planning/security-review` | `CONTEXT.md` |
| Security repos tracking | `/docs/planning/security-repos` | `CONTEXT.md` |
| Security whitepapers tracking | `/docs/planning/security-whitepapers` | `CONTEXT.md` |
| Feature repos tracking | `/docs/planning/feature-repos` | `CONTEXT.md` |
