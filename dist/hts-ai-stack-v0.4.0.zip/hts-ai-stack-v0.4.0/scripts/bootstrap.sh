#!/usr/bin/env bash
# scripts/bootstrap.sh — Internal thin wrapper: delegates to root bootstrap.sh
#
# The authoritative bootstrap entry point is the root bootstrap.sh.
# This wrapper exists for scripts that source from within the repo tree.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

exec bash "$REPO_DIR/bootstrap.sh" "$@"
