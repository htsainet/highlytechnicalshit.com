# Github Repo Review

Systematic review and evaluation of open-source repositories for integration into the OpenClaw stack.

Last updated: 2026-03-31 19:09:41

## Purpose

This workspace tracks the discovery, triage, and evaluation of ecosystem repositories (security tooling, agents, memory systems, platforms, UIs, personas, skills). Reviews assess self-hosting compatibility, integration feasibility, maintenance risk, and trust before adoption or reference.

## Workflow

**Project:** `/home/tim/github/hts-ai-stack` — self-hosted AI workstation on Ubuntu 24.04.
Stack (all Docker): Ollama (local LLM inference, default: mistral-nemo), Open WebUI, OpenClaw
(AI agent interface), NemoClaw (sandboxed agent runtime), SillyTavern, Whisper STT, XTTS TTS,
Stable Diffusion, Jenkins CI, Gitea. GPU-accelerated, fully self-hosted — no cloud dependencies.

**Task:** Review GitHub repos listed in `REFERENCES.md` and update the table in-place.

**Method:** Use `gh` CLI directly (no subagents — they lack network access):

```bash
gh repo view OWNER/REPO --json name,description,pushedAt,stargazerCount,licenseInfo,isArchived,primaryLanguage,isEmpty
gh api repos/OWNER/REPO/readme --jq '.content' | base64 -d | head -60
```

**Where we left off:** Pass 1 (Haiku) SUBSTANTIVE reviews complete for rows 30–133 (104 repos: 55 previously reviewed + 49 newly reviewed).
Deep reviews (README + metadata): rows 30–109, comprehensive assessments with full context.
Lightweight reviews (metadata-only): rows 110–133, templated assessments with key details.
Trust assessments (rows 30–133): high (15), medium (18), reference (12), not-trusted (4), watch (8), unknown (47).
Remaining rows 134–339 (206 repos): NOT YET reviewed — mostly unclassified/misc categories.
Next: (1) Complete lightweight Pass 1 on rows 134–339 (206 repos), (2) Pass 2 (Sonnet) on high/medium trust repos, (3) Human review coordination.

**Pass 1 Strategy Evolved:**

- **Deep reviews (Haiku):** Rows 30–109 — comprehensive with README analysis (~2-4 API calls per repo)
- **Lightweight reviews (Haiku):** Rows 110–339 — metadata + templated assessment (~1 API call per repo)
- **Rationale:** Security/ecosystem repos (rows 30–109) warrant deep context; remaining repos (110–339) benefit from quick triage

**Table columns:** Repo | Description | Category | Trust | Next Review | Next Actions | Bots Reviewed | Human Reviewed | Details | Engine | Health | Last Update | Last Checked

**Multi-review workflow:**

- **Pass 1 (Haiku):** fast metadata + classification pass
- **Pass 2 (Sonnet):** project-fit pass (self-hosting fit, integration effort, risk, maintenance)
- **Pass 3 (Human):** final accept/reject decision and trust confirmation
- **Escalate to Opus only when needed:** ambiguous fit, conflicting evidence, license uncertainty, or security-sensitive impact
- **State model:** `Engine` is the model family for the most recent pass owner; `Bots Reviewed` is cumulative versioned history

**Update rules:**

- Fill Description with a concise summary including stars, license, and fit verdict
- Set Trust to: `high` · `reference` · `medium` · `unknown` · `not-trusted`
- After Pass 1, set Engine to `haiku` and Bots Reviewed to the exact Haiku version used (for example: `haiku-4-5`)
- After Pass 2, set Engine to `sonnet` and append the exact Sonnet version used to Bots Reviewed (for example: `haiku-4-5,sonnet-4-6`)
- If Opus escalation is used, set Engine to `opus` and append the exact Opus version used to Bots Reviewed
- Set Health to one of: `healthy` · `watch` · `stale`
- Set Last Update from `pushedAt` (YYYY-MM-DD)
- Set Last Checked to today's date (YYYY-MM-DD) when the row is reviewed
- Use Next Actions for concrete follow-ups (for example: `check license`, `run health script`, `pin commit`)
- Set Human Reviewed date only after your final decision
- Leave Details blank unless a per-repo note file exists in `refs/`
- After each batch of 10, update the "Where we left off" line above with the new last-reviewed line number and repo name

## Related Tracking Folders

Repos from the master `REFERENCES.md` are split into purpose-specific sub-trackers:

- **[security-repos/](../security-repos/)** — Security tooling, hardening, threat defense (~45 repos)
- **[security-whitepapers/](../security-whitepapers/)** — arXiv papers and academic security research (12 papers)
- **[feature-repos/](../feature-repos/)** — All non-security repos: agents, memory, platforms, UI, personas, skills, integrations

Per-repo deep-dive artifacts use `owner-reponame.md` naming and live in the corresponding sub-folder.

**Categories:** `nvidia` · `microsoft` · `reference` · `openclaw-ecosystem` · `ring-central` ·
`memory` · `skills` · `agents` · `use-cases` · `alternative-platforms` · `security` ·
`ui-helpers` · `character-cards` · `lorebooks` · `personas` · `mobile` · `sillytavern` ·
`integration` · `misc` · `unclassified` · `not-trusted`

**Trust rubric:**

- `high` — well-known, maintained, directly used or adopted
- `reference` — informational/discovery value, not installed
- `medium` — relevant candidate, needs more evaluation before adoption
- `not-trusted` — irrelevant, cloud-only, unofficial, or low-signal
- `unknown` — not yet reviewed (leave unchanged only if data fetch failed)

**Key judgement criteria for this stack:**

- Self-hostable? (cloud-only = negative signal)
- Ollama/local-model compatible?
- OpenClaw/NemoClaw ecosystem relevance?
- License permissive? (Apache 2.0 / MIT = fine; "other" = flag it)
- Stars + activity as proxy for trust

**Session cadence:** 10 repos per batch, update `docs_references.md` after each batch,
then update the "Where we left off" line in this file. Fresh context window every 5 batches
(50 repos). To find where you left off in a new window:

```bash
grep -n "| haiku |" docs_references.md | tail -1
grep -nE "\|[^|]*haiku[^|]*sonnet[^|]*\|" docs_references.md | tail -1
grep -nE "\|[^|]*haiku[^|]*sonnet[^|]*opus[^|]*\|" docs_references.md | tail -1
```

## Standards and Conventions

- All rows include: trust assessment, category, last update, and health status
- Descriptions are concise (stars, license, and fit verdict in 2-3 sentences)
- Each batch includes 10 repos with multi-pass review (Pass 1: Haiku metadata, Pass 2: Sonnet fit, Pass 3: human decision)
- Engine field tracks which model did the last review; Bots Reviewed tracks cumulative history
- Trust levels are: `high` (adopted), `reference` (informational), `medium` (candidate), `unknown` (not yet assessed), `not-trusted` (rejected)
- Health tracked as: `healthy` (active), `watch` (slowing), `stale` (inactive)

## Tools and skills

- **gh CLI** — GitHub repo metadata, README, star counts, license info
- **Claude Haiku** — Fast metadata pass (stars, description, fit classification)
- **Claude Sonnet** — Project-fit pass (self-hosting, integration effort, risk assessment)
- **Claude Opus** — Escalation for ambiguous, conflicting, or security-sensitive decisions
- **License analysis** — Apache 2.0, MIT, GPL compatibility assessment
- **Docker knowledge** — Container-based self-hosting evaluation
- **git** — Repository history and activity tracking
