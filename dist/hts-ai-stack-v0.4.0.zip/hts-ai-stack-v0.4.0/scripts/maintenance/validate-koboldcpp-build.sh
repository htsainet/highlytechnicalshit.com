#!/usr/bin/env bash
# scripts/maintenance/validate-koboldcpp-build.sh — Validate the koboldcpp
# multi-stage source build (feat/koboldcpp-peer).
#
# Runs all four validation gates in order:
#   1. docker compose build — image builds cleanly from source
#   2. Build label check   — build.commit label matches expected SHA
#   3. CPU-only smoke test — /v1/models returns 200 with GPU layers = 0
#   4. GPU smoke test      — VRAM visible in nvidia-smi, /v1/models 200
#
# Gates 3 and 4 require a running Docker environment. Gate 4 additionally
# requires an NVIDIA GPU and stops the ollama service while it runs.
#
# Usage:
#   ./scripts/maintenance/validate-koboldcpp-build.sh [options]
#
# Flags:
#   --build           Run gate 1 (docker compose build). Skipped by default
#                     because it takes 10-15 min on first run.
#   --gpu             Run gate 4 (GPU smoke test). Requires NVIDIA GPU.
#   --model <file>    GGUF filename inside the koboldcpp_models volume.
#                     Required for gate 4 if KOBOLDCPP_MODEL_FILE is not set.
#   --port <n>        Port koboldcpp listens on (default: 5001).
#   --skip-lint       Skip the markdownlint check at the end.
#   --no-cleanup      Leave the koboldcpp container running after tests.
#   -h, --help        Show this message.
#
# Environment variables:
#   KOBOLDCPP_MODEL_FILE  — GGUF filename for gate 4 (overridden by --model)
#   HF_TOKEN              — Hugging Face token for private/gated models

set -euo pipefail

# ── helpers ──────────────────────────────────────────────────────────────────
PASS="✅"; FAIL="❌"; WARN="⚠️ "; INFO="ℹ️ "
FAILS=0

section() { echo; echo "━━━ $1 ━━━"; }
ok()      { echo "  ${PASS} $1"; }
fail()    { echo "  ${FAIL} $1"; FAILS=$((FAILS+1)); }
warn()    { echo "  ${WARN} $1"; }
info()    { echo "  ${INFO} $1"; }
hint()    { echo "     → $1"; }

die() { echo "${FAIL} $1" >&2; exit 1; }

# ── defaults ─────────────────────────────────────────────────────────────────
DO_BUILD=false
DO_GPU=false
SKIP_LINT=false
NO_CLEANUP=false
PORT="${KOBOLDCPP_PORT:-5001}"
MODEL_FILE="${KOBOLDCPP_MODEL_FILE:-}"
EXPECTED_SHA="b31877e8ec8a1a58e7da88e0b235b9ca0028f504"
WAIT_SECS=30

# ── arg parsing ──────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --build)         DO_BUILD=true;                    shift ;;
    --gpu)           DO_GPU=true;                      shift ;;
    --model)         MODEL_FILE="${2:-}"; shift 2 ;;
    --port)          PORT="${2:-}"; shift 2 ;;
    --skip-lint)     SKIP_LINT=true;                   shift ;;
    --no-cleanup)    NO_CLEANUP=true;                  shift ;;
    -h|--help)
      sed -n '3,31p' "$0" | sed 's/^# \?//'
      exit 0 ;;
    *) die "Unknown argument: $1" ;;
  esac
done

# ── locate repo root ─────────────────────────────────────────────────────────
REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

# ── gate 1: build ─────────────────────────────────────────────────────────────
section "Gate 1: docker compose build"
if [[ "$DO_BUILD" == true ]]; then
  info "Building koboldcpp image (this takes ~10-15 min on first run)..."
  if docker compose --profile koboldcpp build koboldcpp; then
    ok "Image built successfully."
  else
    fail "docker compose build failed."
    hint "Check Dockerfile and network connectivity to GitHub."
  fi
else
  info "Skipped — pass --build to run this gate."
fi

# ── gate 2: build label ────────────────────────────────────────────────────────
section "Gate 2: Build label"
IMAGE_IS_SOURCE_BUILT=false
if docker image inspect hts-ai-koboldcpp &>/dev/null; then
  LABELS_JSON="$(docker image inspect hts-ai-koboldcpp \
    --format '{{json .Config.Labels}}' 2>/dev/null || echo '{}')"
  BUILD_COMMIT="$(echo "$LABELS_JSON" | python3 -c \
    "import sys,json; d=json.load(sys.stdin); print(d.get('build.commit','(missing)'))")"
  BUILD_TAG="$(echo "$LABELS_JSON" | python3 -c \
    "import sys,json; d=json.load(sys.stdin); print(d.get('build.tag','(missing)'))")"
  if [[ "$BUILD_COMMIT" == "$EXPECTED_SHA" ]]; then
    ok "build.commit = ${BUILD_COMMIT}"
    IMAGE_IS_SOURCE_BUILT=true
  elif [[ "$BUILD_COMMIT" == "(missing)" ]]; then
    fail "No build.commit label — this is the old digest-pinned image, not the source build."
    hint "Remove it and rebuild: docker image rm hts-ai-koboldcpp"
    hint "Then re-run with --build to compile from source."
  else
    fail "build.commit mismatch: got '${BUILD_COMMIT}', expected '${EXPECTED_SHA}'"
    hint "Rebuild with --build --no-cache, or check the pinned tag in the Dockerfile."
  fi
  info "build.tag    = ${BUILD_TAG}"
else
  warn "Image hts-ai-koboldcpp not found — run with --build first."
fi

# ── shared: bring up and wait for healthy ─────────────────────────────────────
_wait_for_healthy() {
  local wait="$1"
  local url="http://localhost:${PORT}/v1/models"
  info "Waiting up to ${wait}s for /v1/models to return 200..."
  local i=0
  while (( i < wait )); do
    if curl -sf --max-time 3 "$url" >/dev/null 2>&1; then
      ok "/v1/models returned 200 (after ${i}s)"
      return 0
    fi
    sleep 2; (( i+=2 ))
  done
  fail "/v1/models did not return 200 within ${wait}s"
  hint "docker logs hts-ai-koboldcpp --tail 40"
  return 1
}

_stop_koboldcpp() {
  docker compose --profile koboldcpp stop koboldcpp 2>/dev/null || true
  docker compose --profile koboldcpp rm -f koboldcpp 2>/dev/null || true
}

# ── gate 3: CPU-only smoke test ───────────────────────────────────────────────
section "Gate 3: CPU-only smoke test (KOBOLDCPP_GPU_LAYERS=0)"
if [[ "$IMAGE_IS_SOURCE_BUILT" == false ]]; then
  warn "Skipped — source-built image not present. Run --build after removing the old image."
elif docker image inspect hts-ai-koboldcpp &>/dev/null; then
  _stop_koboldcpp
  KOBOLDCPP_GPU_LAYERS=0 docker compose --profile koboldcpp up koboldcpp -d
  info "Container started. Recent logs:"
  sleep 5 && docker logs hts-ai-koboldcpp --tail 15 2>&1 | sed 's/^/    /'
  _wait_for_healthy "$WAIT_SECS" || true
  if [[ "$NO_CLEANUP" == false ]]; then _stop_koboldcpp; fi
else
  warn "Image not found — skipping CPU smoke test."
fi

# ── gate 4: GPU smoke test ────────────────────────────────────────────────────
section "Gate 4: GPU smoke test (KOBOLDCPP_GPU_LAYERS=99)"
if [[ "$DO_GPU" == true ]]; then
  if ! command -v nvidia-smi &>/dev/null; then
    warn "nvidia-smi not found — GPU gate skipped."
  elif [[ "$IMAGE_IS_SOURCE_BUILT" == false ]]; then
    warn "Skipped — source-built image not present. Run --build after removing the old image."
  elif ! docker image inspect hts-ai-koboldcpp &>/dev/null; then
    warn "Image not found — skipping GPU smoke test."
  else
    if [[ -z "$MODEL_FILE" ]]; then
      warn "No model file specified; GPU gate will start koboldcpp without a model."
      hint "Pass --model your-model.gguf or set KOBOLDCPP_MODEL_FILE."
    fi
    info "Stopping ollama to free VRAM..."
    docker compose stop ollama 2>/dev/null || true
    _stop_koboldcpp

    KOBOLDCPP_GPU_LAYERS=99 \
      ${MODEL_FILE:+KOBOLDCPP_MODEL_FILE="$MODEL_FILE"} \
      docker compose --profile koboldcpp up koboldcpp -d
    info "Container started. Recent logs:"
    sleep 5 && docker logs hts-ai-koboldcpp --tail 15 2>&1 | sed 's/^/    /'

    info "VRAM snapshot (nvidia-smi):"
    nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader 2>/dev/null \
      | sed 's/^/    /' || info "(no compute processes or no GPU)"

    _wait_for_healthy "$WAIT_SECS" || true
    if [[ "$NO_CLEANUP" == false ]]; then _stop_koboldcpp; fi
  fi
else
  info "Skipped — pass --gpu to run this gate."
fi

# ── markdownlint ──────────────────────────────────────────────────────────────
section "Lint check"
if [[ "$SKIP_LINT" == false ]]; then
  if command -v npx &>/dev/null; then
    if npx markdownlint-cli2 \
        DEVIATIONS.md REFERENCES.md docs/planning/ACTIVE.md \
        scripts/components/koboldcpp/koboldcpp_install_plan.md 2>&1 \
        | grep -v '^Finding:\|^Linting:\|^markdownlint' | sed 's/^/    /'; then
      ok "markdownlint passed."
    else
      fail "markdownlint reported errors (see above)."
    fi
  else
    warn "npx not found — skipping lint."
  fi
else
  info "Skipped — --skip-lint passed."
fi

# ── summary ───────────────────────────────────────────────────────────────────
echo
echo "━━━ Summary ━━━"
if (( FAILS == 0 )); then
  ok "All checks passed."
else
  fail "${FAILS} check(s) failed — see output above."
  exit 1
fi
