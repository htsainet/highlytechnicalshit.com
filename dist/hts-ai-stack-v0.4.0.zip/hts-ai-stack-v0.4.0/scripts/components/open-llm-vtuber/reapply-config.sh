#!/usr/bin/env bash
# scripts/components/open-llm-vtuber/reapply-config.sh — stop, regenerate
# conf.yaml + model_dict.json, restart, and run postcheck.
#
# Use this after changing the conf.yaml template in open-llm-vtuber.sh
# (or after editing .env values like VTUBER_DEFAULT_AVATAR). It does NOT
# rebuild the image — that's --install territory.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
COMPONENT="$SCRIPT_DIR/open-llm-vtuber.sh"
CONF_FILE="$REPO_DIR/config/open-llm-vtuber/conf.yaml"

cd "$REPO_DIR"

echo "──[1/5] stop container"
"$COMPONENT" --stop || true

echo "──[2/5] remove stale conf.yaml so it regenerates"
rm -f "$CONF_FILE"

echo "──[3/5] regenerate conf.yaml + model_dict.json"
"$COMPONENT" --configure

echo "──[4/5] start container (force-recreate to pick up new bind mount inodes)"
HTS_FORCE_REBUILD=1 "$COMPONENT" --start

echo "──[5/5] wait 30s for startup, then postcheck"
sleep 30
"$SCRIPT_DIR/postcheck.sh"
