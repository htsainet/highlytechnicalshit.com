# Policies — OpenShell Network and Filesystem Rules

Last updated: 2026-04-11 23:11:00

## What happens here

Version-controlled OpenShell policy YAML files that define what the sandbox can
and cannot reach. Network policies are hot-reloadable (`openshell policy set`
applies instantly). Filesystem policies lock at sandbox creation time.

## Files and structure

| File | Purpose |
|------|---------|
| `openclaw-sandbox.yaml` | Main network policy — allowlisted endpoints, per-binary rules |
| `presets/` | Optional policy fragments (pypi, docker-hub, huggingface, slack, etc.) |

## Policy structure

```yaml
endpoints:
  - name: llama-swap
    host: host.openshell.internal
    port: 8081
    protocol: rest
    enforcement: enforce
    rules:
      - allow: { method: "*", path: "/v1/**" }
    binaries:
      - { path: /usr/local/bin/openclaw }
```

## Key rules

- Policies live in Git — every change is auditable (security review F2)
- Network rules are hot-reloadable: `openshell policy set --policy <file> <sandbox>`
- Filesystem rules are locked at creation — cannot change on running sandbox
- Default deny — only explicitly listed endpoints are reachable
- Per-binary restriction — only the `openclaw` binary can reach llama-swap
- Preset fragments can be combined for specific use cases (pip installs, etc.)

## Process

1. Edit the policy YAML in this folder
2. Apply with `openshell policy set --policy <file> <sandbox>` (network rules hot-reload)
3. For filesystem rules, destroy and recreate the sandbox after changes
4. Commit changes to Git for audit trail

## Tools and dependencies

- **openshell CLI** — Apply and inspect sandbox policies (`openshell policy set`, `openshell term`)
- **git** — Version control for policy audit trail

## What good looks like

- Minimal allowlist — only endpoints the agent actually needs
- Per-binary enforcement — not blanket network access
- Changes go through Git, not ad-hoc `openshell policy set` from the command line
- `openshell term` shows blocked requests for debugging (not silent failures)
