#!/usr/bin/env bash
# scripts/components/bitnet/bitnet.sh — BitNet 1-bit LLM: install, start, health
#
# Standalone usage:
#   ./scripts/components/bitnet/bitnet.sh              # full: install + configure + start + health
#   ./scripts/components/bitnet/bitnet.sh --install    # install only
#   ./scripts/components/bitnet/bitnet.sh --configure  # configure only
#   ./scripts/components/bitnet/bitnet.sh --start      # start only
#   ./scripts/components/bitnet/bitnet.sh --stop       # stop
#   ./scripts/components/bitnet/bitnet.sh --restart    # restart (stop + start)
#   ./scripts/components/bitnet/bitnet.sh --health     # health check only
#   ./scripts/components/bitnet/bitnet.sh --status     # show status + port + health
#   ./scripts/components/bitnet/bitnet.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
BITNET_CONTAINER="${BITNET_CONTAINER:-hts-ai-bitnet-1}"
BITNET_PORT="${BITNET_PORT:-8080}"
BITNET_MODEL="${BITNET_MODEL:-BitNet-b1.58-2B-4T}"
BITNET_HF_REPO="${BITNET_HF_REPO:-microsoft/BitNet-b1.58-2B-4T-gguf}"

# ── Functions ────────────────────────────────────────────────────────────────

# bitnet_install — Build BitNet image from docker/bitnet/Dockerfile
bitnet_install() {
  step "BitNet — install"
  local dockerfile="$REPO_DIR/docker/bitnet/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    fail "BitNet Dockerfile not found: $dockerfile"
    return 1
  fi
  info "Building BitNet from source (clang-18 + CMake) — this may take a few minutes..."
  info "Model weights download separately on first container start."
  compose_build --profile bitnet-cpu
  ok "BitNet image built."
}

# bitnet_configure — Validate BitNet model configuration
bitnet_configure() {
  step "BitNet — configure"
  info "Model: ${BITNET_MODEL}"
  info "HF repo: ${BITNET_HF_REPO}"
  info "API port: ${BITNET_PORT} (OpenAI-compatible)"
  ok "BitNet configured."
}

# bitnet_start — Bring up BitNet via compose (with exclusivity guard)
bitnet_start() {
  step "BitNet — start"
  compose_up --profile bitnet-cpu
  ok "BitNet started on port ${BITNET_PORT}."
}

# bitnet_stop — Bring down BitNet
bitnet_stop() {
  step "BitNet — stop"
  compose_down --profile bitnet-cpu
  ok "BitNet stopped."
}

# bitnet_health — Probe the BitNet OpenAI-compatible API inside the container
# BitNet has no host port binding (llama-swap proxies); use docker exec.
bitnet_health() {
  local label="BitNet :${BITNET_PORT}"
  printf "  %-35s" "$label"
  if docker compose -f "$REPO_DIR/docker-compose.yml" exec -T bitnet curl -sf "http://localhost:${BITNET_PORT}/v1/models" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (docker compose exec bitnet curl http://localhost:${BITNET_PORT}/v1/models)"
    return 1
  fi
}

bitnet_restart() {
  bitnet_stop
  bitnet_start
}

bitnet_destroy() {
  step "BitNet — destroy"
  compose_down --profile bitnet-cpu -v
  ok "BitNet destroyed."
}

bitnet_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=bitnet" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "BitNet is running (port ${BITNET_PORT})"
  else
    warn "BitNet is not running."
  fi
  bitnet_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   bitnet_install   ;;
    configure) bitnet_configure ;;
    start)     bitnet_start     ;;
    stop)      bitnet_stop      ;;
    restart)   bitnet_restart   ;;
    health)    bitnet_health    ;;
    status)    bitnet_status    ;;
    destroy)   bitnet_destroy   ;;
    default)
      bitnet_install
      bitnet_configure
      bitnet_start
      bitnet_health
      ;;
  esac
fi
