# Open-Sora References

Last updated: 2026-04-17

## Upstream

- [GitHub — hpcaitech/Open-Sora](https://github.com/hpcaitech/Open-Sora)
- [Open-Sora Documentation](https://github.com/hpcaitech/Open-Sora/tree/main/docs)

## Models

- Open-Sora v1.3 (1B params) — consumer RTX tier (~24GB VRAM)
- Open-Sora v2.0 (11B params) — datacenter tier (45–60GB VRAM)

## Papers

- [Open-Sora: Democratizing Efficient Video Production for All (arXiv)](https://arxiv.org/abs/2412.00131)

## Related features

- [FEATURE-029](../../docs/development/features/FEATURE-029.md) — original feature spec (disqualified for VRAM)

## API

- Gradio web UI: `http://localhost:7862/`
- Gradio API: `http://localhost:7862/api/`
