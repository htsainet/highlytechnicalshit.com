$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/stable-diffusion'
    $script:ComponentScript = Join-Path $script:ComponentDir 'stable-diffusion.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'stable-diffusion.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'stable-diffusion file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists (TDD — needs creation)' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'stable-diffusion component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines sd_install function' {
        $script:ComponentContent | Should -Match 'sd_install\s*\(\)'
    }

    It 'defines sd_configure function' {
        $script:ComponentContent | Should -Match 'sd_configure\s*\(\)'
    }

    It 'defines sd_start function' {
        $script:ComponentContent | Should -Match 'sd_start\s*\(\)'
    }

    It 'defines sd_stop function' {
        $script:ComponentContent | Should -Match 'sd_stop\s*\(\)'
    }

    It 'defines sd_health function' {
        $script:ComponentContent | Should -Match 'sd_health\s*\(\)'
    }

    It 'defines sd_download_models function' {
        $script:ComponentContent | Should -Match 'sd_download_models\s*\(\)'
    }

    It 'supports --download, --health, and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--download\)'
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/stable-diffusion/stable-diffusion\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'stable-diffusion no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/stable-diffusion\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/stable-diffusion/stable-diffusion\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'stable-diffusion compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'stable-diffusion service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'stable-diffusion:'
    }

    It 'uses sd profile' {
        $script:ComposeContent | Should -Match '\[sd\]'
    }

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/stable-diffusion/Dockerfile' | Should -Exist
    }
}

# ── Attention backend ───────────────────────────────────────────────────────

Describe 'stable-diffusion attention backend' {
    BeforeAll {
        $script:ComposeContent = Get-Content -Path (Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
        $script:Dockerfile = Get-Content -Path (Join-Path $script:RepoRoot 'docker/stable-diffusion/Dockerfile') -Raw
    }

    It 'compose uses --opt-sdp-attention instead of xformers' {
        $script:ComposeContent | Should -Match 'opt-sdp-attention'
    }

    It 'compose uses command: to set launch flags (not just env)' {
        $script:ComposeContent | Should -Match 'command:.*opt-sdp'
    }

    It 'Dockerfile does not install xformers' {
        $script:Dockerfile | Should -Not -Match 'xformers'
    }
}
