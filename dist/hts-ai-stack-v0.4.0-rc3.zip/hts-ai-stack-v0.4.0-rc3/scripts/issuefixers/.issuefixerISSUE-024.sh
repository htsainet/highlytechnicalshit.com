#!/usr/bin/env bash
set -euo pipefail

# Hotfix for ISSUE-024:
# - Ensure `04-setup-nemoclaw.sh` sources the shared logging helpers (ok/fail/etc)
#   immediately after sourcing ui.sh.
#
# Usage:
#   chmod +x .issuefixerISSUE-024.sh
#   ./.issuefixerISSUE-024.sh
#
# Rollback:
#   cp -a 04-setup-nemoclaw.sh.bak.<timestamp> 04-setup-nemoclaw.sh

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="$REPO_ROOT/04-setup-nemoclaw.sh"

if [[ ! -f "$TARGET" ]]; then
  echo "[FAIL] Could not find $TARGET. Run this from the repo root." >&2
  exit 1
fi

# Idempotent: skip if already patched
if grep -q "scripts/install/models/helpers.sh" "$TARGET"; then
  echo "[SKIP] $TARGET already sources helpers.sh — nothing to do." >&2
  exit 0
fi

ts="$(date +%Y%m%d-%H%M%S)"
backup="${TARGET}.bak.${ts}"
cp -a "$TARGET" "$backup"
echo "[INFO] Backup created: $backup" >&2

# Insert the two helper-source lines immediately after the ui.sh source line.
# Uses sed address matching on the exact source line; -i edits in-place.
sed -i \
  '/source "\$SCRIPT_DIR\/setup\/tooling\/ui.sh"/ a\
# shellcheck source=scripts/install/models/helpers.sh\
source "$SCRIPT_DIR/scripts/install/models/helpers.sh"' \
  "$TARGET"

echo "[INFO] Patched: $TARGET" >&2
echo "" >&2
echo "[INFO] Diff (old -> new):" >&2
diff -u "$backup" "$TARGET" || true

echo "" >&2
bash -n "$TARGET" && echo "[OK] Syntax check passed." >&2 || { echo "[FAIL] Syntax error after patch — restoring backup." >&2; cp -a "$backup" "$TARGET"; exit 1; }
echo "[OK] Hotfix applied. Re-run your failing step (e.g., bash install.sh)." >&2
echo "[INFO] To rollback: cp -a \"$backup\" \"$TARGET\"" >&2
