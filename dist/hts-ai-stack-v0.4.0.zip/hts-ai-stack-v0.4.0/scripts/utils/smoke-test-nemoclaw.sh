#!/usr/bin/env bash
# shellcheck disable=SC2259
# scripts/utils/smoke-test-nemoclaw.sh — post-install smoke test for NemoClaw
#
# Verifies the current NemoClaw smoke checks:
#
#   1. downgrade-nemoclaw.sh runs without NVIDIA_API_KEY
#   2. Sandbox reaches Phase: Ready (via nemoclaw status)
#   3. Provider is wired to llama-swap (compatible-endpoint / llama-swap-local)
#   4. Ollama has the expected NemoClaw model available
#   5. In-sandbox completion probe: llama-swap reachable at host.openshell.internal
#
# Usage:
#   ./scripts/utils/smoke-test-nemoclaw.sh            # full run (check 1 re-installs)
#   ./scripts/utils/smoke-test-nemoclaw.sh --skip-reinstall  # skip check 1
#
# Exit codes:
#   0  all checks passed
#   1  one or more checks failed

set -uo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SKIP_REINSTALL=false

for arg in "$@"; do
  case "$arg" in
    --skip-reinstall) SKIP_REINSTALL=true ;;
    -h|--help)
      printf '%s\n' \
        '# scripts/utils/smoke-test-nemoclaw.sh — post-install smoke test for NemoClaw' \
        '#' \
        '# Verifies the current NemoClaw smoke checks:' \
        '#' \
        '#   1. downgrade-nemoclaw.sh runs without NVIDIA_API_KEY' \
        '#   2. Sandbox reaches Phase: Ready (via nemoclaw status)' \
        '#   3. Provider is wired to llama-swap (compatible-endpoint / llama-swap-local)' \
        '#   4. Ollama has the expected NemoClaw model available' \
        '#   5. In-sandbox completion probe: llama-swap reachable at host.openshell.internal' \
        '#' \
        '# Usage:' \
        '#   ./scripts/utils/smoke-test-nemoclaw.sh            # full run (check 1 re-installs)' \
        '#   ./scripts/utils/smoke-test-nemoclaw.sh --skip-reinstall  # skip check 1'
      exit 0
      ;;
    *) printf '[warn] unknown argument: %s\n' "$arg" ;;
  esac
done

GATEWAY="${NEMOCLAW_GATEWAY_NAME:-nemoclaw}"
SANDBOX="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"
SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"
MODEL="${NEMOCLAW_MODEL:-mistral-nemo:latest}"
COMPATIBLE_API_KEY="${COMPATIBLE_API_KEY:-not-needed}"

ok()   { printf '[ OK ] %s\n' "$*"; }
fail() { printf '[FAIL] %s\n' "$*" >&2; FAILED=$((FAILED + 1)); }
info() { printf '[info] %s\n' "$*"; }

FAILED=0

echo "── NemoClaw smoke test ──────────────────────────────────────────────────"
info "gateway:  $GATEWAY"
info "sandbox:  $SANDBOX"
info "swap port: $SWAP_PORT"
info "model:    $MODEL"
echo ""

# ── Check 1: downgrade-nemoclaw.sh runs without NVIDIA_API_KEY ────────────
if [[ "$SKIP_REINSTALL" == "true" ]]; then
  info "Check 1: skipped (--skip-reinstall)"
else
  echo "── Check 1: re-install at pinned tag (no NVIDIA_API_KEY) ──"
  unset NVIDIA_API_KEY NEMOCLAW_PROVIDER_KEY 2>/dev/null || true
  if "$REPO_DIR/scripts/utils/downgrade-nemoclaw.sh"; then
    ok "downgrade-nemoclaw.sh completed without NVIDIA_API_KEY"
  else
    fail "downgrade-nemoclaw.sh exited non-zero — check output above"
  fi
  echo ""
fi

# ── Check 2: sandbox reaches Phase: Ready ─────────────────────────────────
echo "── Check 2: sandbox phase ──"
if ! command -v nemoclaw &>/dev/null; then
  fail "nemoclaw CLI not on PATH — run --install first"
else
  phase=$(nemoclaw "$SANDBOX" status 2>/dev/null \
    | grep -i 'phase\|ready\|status' | head -3 || true)
  if echo "$phase" | grep -qi 'ready'; then
    ok "sandbox '$SANDBOX' phase: Ready"
  else
    fail "sandbox '$SANDBOX' not Ready — nemoclaw status output:"
    while IFS= read -r line; do
      printf '       %s\n' "$line"
    done <<< "$phase"
  fi
fi
echo ""

# ── Check 3: provider wired to llama-swap ─────────────────────────────────
echo "── Check 3: provider endpoint ──"
if ! command -v openshell &>/dev/null; then
  fail "openshell CLI not on PATH"
else
  provider_url=$(openshell provider get compatible-endpoint 2>/dev/null \
    | grep -oE 'http[s]?://[^ ]+' | head -1 || true)
  if [[ -z "$provider_url" ]]; then
    provider_url=$(openshell provider get llama-swap-local 2>/dev/null \
      | grep -oE 'http[s]?://[^ ]+' | head -1 || true)
  fi
  if [[ -z "$provider_url" ]]; then
    # Try alternate subcommand shape
    provider_url=$(nemoclaw "$SANDBOX" status 2>/dev/null \
      | grep -i 'endpoint\|url' | grep -oE 'http[s]?://[^ ]+' | head -1 || true)
  fi
  if echo "$provider_url" | grep -q "host\.openshell\.internal:${SWAP_PORT}/v1"; then
    ok "provider endpoint: $provider_url"
  elif [[ -n "$provider_url" ]]; then
    fail "provider endpoint unexpected: $provider_url (expected host.openshell.internal:${SWAP_PORT}/v1)"
  else
    fail "could not read provider endpoint — run: openshell provider get compatible-endpoint"
  fi
fi
echo ""

# ── Check 4: Ollama has expected model ────────────────────────────────────
echo "── Check 4: host Ollama model availability ──"
if ! command -v docker &>/dev/null; then
  fail "docker not on PATH"
else
  ollama_list=$(docker compose exec -T ollama ollama list 2>/dev/null || true)
  if [[ -z "$ollama_list" ]]; then
    ollama_list=$(docker exec -i hts-ai-ollama ollama list 2>/dev/null || true)
  fi
  if echo "$ollama_list" | python3 - "$MODEL" <<'PYEOF' 2>/dev/null
import sys
model = sys.argv[1]
lines = [line.strip() for line in sys.stdin.read().splitlines() if line.strip()]
raise SystemExit(0 if any(line.split()[0] == model for line in lines[1:]) else 1)
PYEOF
  then
    ok "Ollama has model '$MODEL'"
  elif [[ -n "$ollama_list" ]]; then
    fail "Ollama list did not include '$MODEL'"
  else
    fail "could not read Ollama model list from docker compose exec -T ollama ollama list"
  fi
fi
echo ""

# ── Check 5: in-sandbox completion probe ──────────────────────────────────
echo "── Check 5: in-sandbox llama-swap completion probe ──"
if ! command -v openshell &>/dev/null; then
  fail "openshell CLI not on PATH"
else
  probe=$(openshell sandbox exec -g "$GATEWAY" -n "$SANDBOX" -- \
    sh -lc "curl -fsS --max-time 20 \
      -H 'Authorization: Bearer ${COMPATIBLE_API_KEY}' \
      -H 'Content-Type: application/json' \
      -d '{\"model\":\"${MODEL}\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"max_tokens\":1,\"stream\":false}' \
      http://host.openshell.internal:${SWAP_PORT}/v1/chat/completions" 2>&1 || true)
  if echo "$probe" | grep -q "\"${MODEL}\""; then
    ok "in-sandbox completion probe returned model '${MODEL}'"
  elif [[ -n "$probe" ]]; then
    fail "completion probe returned unexpected response:"
    echo "$probe" | head -5 | while IFS= read -r line; do printf '       %s\n' "$line"; done
  else
    fail "in-sandbox completion probe returned no output — llama-swap may be unreachable from sandbox"
  fi
fi
echo ""

# ── Summary ───────────────────────────────────────────────────────────────
echo "────────────────────────────────────────────────────────────────────────"
if [[ $FAILED -eq 0 ]]; then
  ok "All smoke-test checks passed."
  exit 0
else
  printf '[FAIL] %d check(s) failed — see [FAIL] lines above.\n' "$FAILED" >&2
  exit 1
fi
