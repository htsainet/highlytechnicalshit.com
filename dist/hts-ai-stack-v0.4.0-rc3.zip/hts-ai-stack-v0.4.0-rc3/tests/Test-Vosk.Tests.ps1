$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/vosk'
    $script:ComponentScript = Join-Path $script:ComponentDir 'vosk.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'vosk.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'vosk file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'vosk manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is vosk' {
        $script:Manifest.id | Should -Be 'vosk'
    }

    It 'category is audio' {
        $script:Manifest.category | Should -Be 'audio'
    }

    It 'profile is vosk' {
        $script:Manifest.profile | Should -Be 'vosk'
    }

    It 'dashboard port is 2700' {
        [int]$script:Manifest.dashboard.port | Should -Be 2700
    }

    It 'script path points to component subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/vosk/vosk.sh'
    }

    It 'install_type is compose' {
        $script:Manifest.install_type | Should -Be 'compose'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'vosk port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 2700 is registered in portmap.json' {
        $script:Portmap.ports.'2700' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'2700'.service | Should -Be 'vosk'
    }
}

# ── CLI flags ────────────────────────────────────────────────────────────────

Describe 'vosk CLI flags' {

    BeforeAll {
        $script:ScriptContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'supports --install flag' {
        $script:ScriptContent | Should -Match '--install'
    }

    It 'supports --configure flag' {
        $script:ScriptContent | Should -Match '--configure'
    }

    It 'supports --start flag' {
        $script:ScriptContent | Should -Match '--start'
    }

    It 'supports --stop flag' {
        $script:ScriptContent | Should -Match '--stop'
    }

    It 'supports --restart flag' {
        $script:ScriptContent | Should -Match '--restart'
    }

    It 'supports --health flag' {
        $script:ScriptContent | Should -Match '--health'
    }

    It 'supports --status flag' {
        $script:ScriptContent | Should -Match '--status'
    }

    It 'supports --destroy flag' {
        $script:ScriptContent | Should -Match '--destroy'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'vosk compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'vosk service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'vosk:'
    }

    It 'uses vosk profile' {
        $script:ComposeContent | Should -Match 'vosk'
    }

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/vosk/Dockerfile' | Should -Exist
    }
}

# ── Vosk base image ─────────────────────────────────────────────────────────

Describe 'vosk base image' {
    BeforeAll {
        $script:Dockerfile = Get-Content -Path (Join-Path $script:RepoRoot 'docker/vosk/Dockerfile') -Raw
    }

    It 'uses kaldi-en base image (not kaldi-vosk-server)' {
        $script:Dockerfile | Should -Match 'kaldi-en'
    }

    It 'does not use the model-less kaldi-vosk-server image' {
        $script:Dockerfile | Should -Not -Match 'kaldi-vosk-server'
    }

    It 'base image is from alphacep' {
        $script:Dockerfile | Should -Match 'alphacep/kaldi-en'
    }
}
