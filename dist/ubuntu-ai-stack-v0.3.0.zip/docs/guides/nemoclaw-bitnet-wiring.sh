# NemoClaw + OpenClaw → BitNet wiring guide
# ============================================================
# BitNet's llama-server speaks the same OpenAI-compatible API
# as vLLM. The steps below register it as a custom OpenShell
# provider and point OpenClaw at it — no sandbox restart needed.
# ============================================================

# 1. BUILD AND START BITNET
# ─────────────────────────
# On the host (outside the NemoClaw sandbox):

docker build -t bitnet-llama3-8b .
docker run -d \
  --name bitnet \
  --gpus all \
  -p 8080:8080 \
  -v bitnet-models:/app/models \
  bitnet-llama3-8b

# Wait for the health check to go green before continuing:
docker inspect --format='{{.State.Health.Status}}' bitnet
# Expected: healthy  (may take 2–5 min on first run while model downloads)

# ── UFW: allow OpenShell's bridge subnet to reach BitNet ──
# Only needed if UFW is enabled on your host:
sudo ufw allow proto tcp from 172.18.0.0/16 to any port 8080 comment 'OpenShell → BitNet'
sudo ufw allow proto tcp from 172.17.0.0/16 to any port 8080 comment 'Docker bridge → BitNet'


# 2. REGISTER BITNET AS AN OPENSHELL PROVIDER
# ─────────────────────────────────────────────
# Run these on the HOST (not inside the sandbox).
# host.openshell.internal resolves to the host machine from inside the sandbox.

openshell provider create \
  --name  bitnet-local \
  --type  openai \
  --credential OPENAI_API_KEY=not-needed \
  --config baseUrl=http://host.openshell.internal:8080/v1

# Verify the provider was registered:
openshell provider list


# 3. SWITCH INFERENCE TO BITNET (hot-reload — no restart)
# ────────────────────────────────────────────────────────
openshell inference set \
  --provider bitnet-local \
  --model    bitnet \
  --no-verify

# Confirm:
openclaw nemoclaw status
# Expected output:
#   provider : bitnet-local
#   model    : bitnet
#   endpoint : http://host.openshell.internal:8080/v1


# 4. UPDATE THE NETWORK POLICY
# ─────────────────────────────
# NemoClaw's sandbox denies all unlisted egress by default.
# Add a policy entry to allow BitNet traffic.
# Paste the YAML block below into your openclaw-sandbox.yaml
# (in nemoclaw-blueprint/policies/openclaw-sandbox.yaml),
# then run: openshell policy set --policy openclaw-sandbox.yaml <sandbox-name>
#
# ── YAML to add under the `endpoints:` key ──────────────────
#
#   - name: bitnet
#     host: host.openshell.internal
#     port: 8080
#     protocol: rest
#     enforcement: enforce
#     rules:
#       - allow: { method: "*", path: "/v1/**" }
#     binaries:
#       - { path: /usr/local/bin/openclaw }
#
# ────────────────────────────────────────────────────────────
#
# Or apply it dynamically (session-only, resets on restart):
openshell policy set --policy openclaw-sandbox.yaml <your-sandbox-name> --wait


# 5. CONFIGURE OPENCLAW INSIDE THE SANDBOX
# ──────────────────────────────────────────
# Connect to the sandbox and set the model:
nemoclaw <your-sandbox-name> connect

# Inside the sandbox shell:
openclaw config set models.providers.bitnet-local.apiKey "not-needed"
openclaw config set agents.defaults.model.primary "bitnet-local/bitnet"

# Test it:
openclaw agent --agent main --local \
  -m "Are you running on BitNet?" \
  --session-id test


# 6. SWITCHING BACK TO OLLAMA
# ────────────────────────────
# If you ever want to revert to your previous Ollama provider:
openshell inference set --provider ollama-local --model '<your-ollama-model>'
