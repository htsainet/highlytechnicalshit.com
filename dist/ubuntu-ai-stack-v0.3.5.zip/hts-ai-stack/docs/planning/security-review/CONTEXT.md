# OpenClaw Security Review

Iterative security-focused research and threat modeling for the OpenClaw AI stack.

Last updated: 2026-03-31 19:09:20

## Purpose

This workspace tracks security architecture reviews, threat modeling, curated paper research, and security-focused repo evaluations to harden the local AI agent infrastructure against supply chain, prompt injection, and infrastructure attacks.

## Who I Am

I'm building a local AI agent stack called **OpenClaw** on Ubuntu 24.04 with GPU acceleration. I need iterative security-focused research reviews of curated arXiv papers and GitHub repos, mapped to my architecture.

## My Core Stack

| Component | Role | Status |
|---|---|---|
| **NemoClaw** (NVIDIA) | Security & privacy enforcement via OpenShell — controls agent access to internet, services, filesystem via declarative YAML policies | Running, two sandboxes (prod + test) |
| **OpenClaw** | AI agent runtime (NemoClaw installs its own OpenClaw instance inside the sandbox) | Running inside NemoClaw sandbox |
| **Ollama** | Local LLM inference (Mistral Nemo default) | Running, prod (11434) + test (11435) |

## Peripheral Services (not core, swappable)

| Component | Role | Notes |
|---|---|---|
| Stable Diffusion + ComfyUI | Image/video generation | Nice-to-have |
| XTTS + Whisper | Voice TTS + STT | Nice-to-have |
| SillyTavern | Character card / persona management | Idea for character cards — fun + functional, not a hard requirement |
| Jenkins | CI/CD | Placeholder — may replace with lighter alternative |
| Open WebUI | Chat frontend | Running |
| Dashboard | Nginx service link page | Running on port 80 |

## Threat Model

- Prompt injection → unauthorized access or exfiltration
- Agent persona drift → policy bypass
- Agent-to-agent manipulation via shared context (future)
- Container escape / privilege escalation
- Jenkins pipeline as attack surface
- Reverse proxy misconfiguration
- Sensitive data retention (XTTS audio, Whisper transcripts, SD outputs)
- Audit gaps — unobservable = undetectable compromise
- Skill supply chain contamination (malicious SKILL.md)
- Memory poisoning via HEARTBEAT background execution

## What's Been Completed

### Session 1 — Architecture Review + Paper Triage + Repo Triage + Pester Tests

**Deliverables produced (user has these files):**

1. **session1-report.md** — Full architecture security assessment with gap analysis, risk summary, prioritized next steps
2. `REFERENCES.md` 12 papers prioritized into 4 tiers with review template
3. `./results/REFERENCES.md` **repo-review-triage.md** — ~170 repos triaged into 4 tiers, ~40 worth reviewing, session plan
4. **repo-review-batch1.md** — Deep review of first 2 repos (SlowMist + ClawSec)
5. **tests/Invoke-SecurityChecks.ps1** — Pester test runner for security alignment
6. **tests/Security/Network.Tests.ps1** — Port binding and network exposure tests
7. **tests/Security/Secrets.Tests.ps1** — Credential hygiene and secret scanning tests
8. **tests/Security/Baselines.Tests.ps1** — Config integrity, model approval, container posture

### Key Findings

**Codebase (v0.2.0):**

- All services bind to 0.0.0.0 (CRITICAL — fix by prefixing 127.0.0.1 in compose port mappings)
- Flat Docker network (all services on one bridge — segment into frontend/inference/ops)
- Jenkins has no auth, no TLS, default setup
- No observability stack (OpenTelemetry in TODO but not implemented)
- No data retention policy for audio/image outputs
- .env handling is good (gitignored, chmod 600, crypto-random tokens)
- Prod/test separation is good (isolated Ollama, separate volumes)

### Architecture Decisions Made

- **Repo structure:** Reorganize into `/core`, `/services/audio`, `/services/image`, `/services/ui`, `/ops`, `/setup`
- **Character cards:** Git + signed commits for traceability now. ClawSec drift detection for runtime monitoring. Blockchain (ERC-8004) bookmarked for future multi-tenant/marketplace scenarios.
- **Observability:** Adopt SlowMist nightly audit + ClawSec audit watchdog rather than building from scratch.
- **Pester tests:** Security alignment tests written for network exposure, secrets hygiene, and config baselines. Tests designed to fail on current v0.2.0 and pass after fixes.

## What Comes Next

Depending on what you need, tell me which to do:

1. **Deep-read a paper** — Paste the arXiv URL and say "deep read this using the review template"
2. **Continue repo reviews** — "Review the next batch of repos from the triage"
3. **Write more Pester tests** — "Write the Skills.Tests.ps1 and Policies.Tests.ps1 files"
4. **Build the v0.3.0 release** — "Help me implement the port binding fix and network segmentation"
5. **Review my changes** — Attach updated repo zip for delta review

## Standards and Conventions

- All findings documented with reference to specific threat vectors and mitigations
- Repo reviews include: trust assessment, self-hosting fit, integration cost, maintenance burden
- Papers reviewed using the arXiv template with: problem, relevance to stack, key insight, action
- Session reports capture completed work, key findings, architecture decisions, and next actions
- All Pester test names match approved PowerShell verbs (Test-*, Get-*)

## Tools and skills

- **STRIDE threat modeling** — Structured threat analysis framework
- **OWASP Top 10** — Common vulnerability assessment
- **arXiv papers** — Academic security research
- **GitHub security advisories** — Vulnerability tracking
- **Docker security scanning** — Image vulnerability assessment
- **Pester framework** — Security test implementation
- **NemoClaw/OpenShell** — Policy-based security enforcement
- **Claude Opus** — Threat model synthesis and deep analysis
