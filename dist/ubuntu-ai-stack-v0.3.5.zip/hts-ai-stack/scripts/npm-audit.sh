#!/usr/bin/env bash
# npm-audit.sh — Check npm dependencies for vulnerabilities and updates
#
# Usage:
#   ./scripts/npm-audit.sh              # full audit and update (logs to npm-audit.log)
#   ./scripts/npm-audit.sh --check-only # audit only, no fixes (for pre-commit)
#   ./scripts/npm-audit.sh --log-only   # don't print to stdout, only log to file
#
# Exit codes:
#   0 — all clear
#   1 — vulnerabilities found (but may be auto-fixed)
#   2 — unfixable vulnerabilities or other errors

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
LOG_DIR="${REPO_DIR}/.logs"
LOG_FILE="${LOG_DIR}/npm-audit.log"

# Create log directory
mkdir -p "$LOG_DIR"

# Flags
CHECK_ONLY=false
LOG_ONLY=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --check-only) CHECK_ONLY=true; shift ;;
    --log-only)   LOG_ONLY=true;   shift ;;
    *)            echo "[ERROR] Unknown flag: $1" >&2; exit 2 ;;
  esac
done

# Logging helper
log() {
  local msg="$*"
  local ts=$(date '+%Y-%m-%d %H:%M:%S')
  echo "[${ts}] ${msg}" >> "$LOG_FILE"
  if ! "$LOG_ONLY"; then
    echo "$msg"
  fi
}

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "npm audit run started"

cd "$REPO_DIR"

# Step 1: Run npm audit
if [ ! -f package.json ]; then
  log "⚠ No package.json found — skipping npm audit"
  exit 0
fi

log "Running npm audit..."
AUDIT_EXIT=0
AUDIT_OUTPUT=$(npm audit 2>&1) || AUDIT_EXIT=$?

# Check for vulnerabilities
if echo "$AUDIT_OUTPUT" | grep -qi "found 0 vulnerabilities"; then
  log "✓ No vulnerabilities found"
  VULN_COUNT=0
elif echo "$AUDIT_OUTPUT" | grep -qi "vulnerabilities"; then
  VULN_COUNT=$(echo "$AUDIT_OUTPUT" | grep -oE "[0-9]+ vulnerabilit" | head -1 | grep -oE "[0-9]+")
  log "⚠ Found ${VULN_COUNT} vulnerability/vulnerabilities"
  log "Details:"
  echo "$AUDIT_OUTPUT" | grep -E "severity|found|packages affected" | while IFS= read -r line; do
    log "  ${line}"
  done
else
  log "audit output:"
  echo "$AUDIT_OUTPUT" | while IFS= read -r line; do
    log "  ${line}"
  done
fi

# Step 2: Audit fix (unless --check-only)
if "$CHECK_ONLY"; then
  log "Skipping fixes (--check-only mode)"
  if [ "$AUDIT_EXIT" -ne 0 ]; then
    log "❌ Vulnerabilities detected — run without --check-only to attempt fixes"
    exit 1
  fi
else
  if [ "$AUDIT_EXIT" -ne 0 ]; then
    log "Running npm audit fix..."
    FIX_OUTPUT=$(npm audit fix 2>&1) || true
    log "audit fix output:"
    echo "$FIX_OUTPUT" | while IFS= read -r line; do
      log "  ${line}"
    done
  fi

  # Step 3: Check for updates
  log "Checking for available updates..."
  OUTDATED=$(npm outdated 2>&1 || true)
  if [ -n "$OUTDATED" ]; then
    log "Available updates:"
    echo "$OUTDATED" | while IFS= read -r line; do
      log "  ${line}"
    done
    log "Running npm update..."
    npm update 2>&1 | tail -5 | while IFS= read -r line; do
      log "  ${line}"
    done
  else
    log "✓ All dependencies are up to date"
  fi
fi

log "npm audit run completed (exit: $AUDIT_EXIT)"
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

exit 0
