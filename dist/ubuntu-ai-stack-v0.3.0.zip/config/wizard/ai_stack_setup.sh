#!/usr/bin/env bash
# ai_stack_setup.sh — AI Stack interactive configurator (whiptail)
#
# All UI is provided by whiptail, which is pre-installed on every
# Ubuntu system (no Python deps, no pip, no venv).
# Python3 is used ONLY at the very end to write the JSON — that's
# always available without any extra packages.
#
# Writes: config/stack.json  (committed, no secrets)
#         config/stack.secrets.json  (gitignored, chmod 600)
#         config/backups/YYYYMMDD-HHMMSS/  (timestamped snapshots)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
CONFIG_DIR="$REPO_ROOT/config"
BACKUP_DIR="$CONFIG_DIR/backups"
STACK_JSON="$CONFIG_DIR/stack.json"
SECRETS_JSON="$CONFIG_DIR/stack.secrets.json"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; BOLD='\033[1m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }

TOTAL=13
W=72   # dialog width

# ── whiptail helpers ──────────────────────────────────────────────────────────

# Single-select menu. Exits script cleanly if user presses Escape/Cancel.
# Usage: wt_menu STEP TITLE PROMPT tag1 label1 [tag2 label2 ...]
wt_menu() {
  local step="$1" title="$2" prompt="$3"
  shift 3
  local result
  result=$(whiptail --title "[$step/$TOTAL] $title" \
                    --menu "$prompt" 18 $W 10 "$@" \
                    3>&1 1>&2 2>&3) || { echo -e "\n  Setup cancelled.\n"; exit 0; }
  echo "$result"
}

# Multi-select checklist. Cancel/Escape → empty selection (all optional).
# Usage: wt_check STEP TITLE PROMPT tag1 label1 ON/OFF ...
wt_check() {
  local step="$1" title="$2" prompt="$3"
  shift 3
  local result
  result=$(whiptail --title "[$step/$TOTAL] $title" \
                    --checklist "$prompt\n(Space=toggle, Enter=confirm)" \
                    18 $W 8 "$@" \
                    3>&1 1>&2 2>&3) || true
  # Strip surrounding double-quotes whiptail adds to each selected value
  echo "$result" | tr -d '"'
}

# Text input box.
# Usage: wt_input STEP TITLE PROMPT [default]
wt_input() {
  local step="$1" title="$2" prompt="$3" default="${4:-}"
  whiptail --title "[$step/$TOTAL] $title" \
           --inputbox "$prompt" 10 $W "$default" \
           3>&1 1>&2 2>&3 || { echo -e "\n  Setup cancelled.\n"; exit 0; }
}

# Yes/No question → echoes "true" or "false".
# Usage: wt_yesno STEP TITLE PROMPT [yes|no]
wt_yesno() {
  local step="$1" title="$2" prompt="$3" default="${4:-yes}"
  local extra_flag=""
  [[ "$default" == "no" ]] && extra_flag="--defaultno"
  # shellcheck disable=SC2086
  if whiptail --title "[$step/$TOTAL] $title" \
              --yesno "$prompt" 10 $W $extra_flag \
              3>&1 1>&2 2>&3; then
    echo "true"
  else
    echo "false"
  fi
}

# ── Banner ────────────────────────────────────────────────────────────────────

clear
echo -e "${CYAN}${BOLD}"
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║      AI STACK SETUP CONFIGURATOR                ║"
echo "  ║      Ubuntu AI Environment Builder              ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo -e "${NC}"
echo "  Configures your AI stack and writes config/stack.json."
echo "  Arrow keys to navigate, Space to toggle, Enter to confirm."
echo ""
sleep 1

# ── Step 1: Backend ───────────────────────────────────────────────────────────

BACKEND=$(wt_menu 1 "Backend Engine" "Choose your inference backend:" \
  "ollama"  "Ollama  — Easy setup, broad model support" \
  "bitnet"  "BitNet  — 1-bit quantised, ultra low memory")

# ── Step 2: Model ─────────────────────────────────────────────────────────────

if [[ "$BACKEND" == "ollama" ]]; then
  MODEL=$(wt_menu 2 "Default Model" "Select default model for Ollama:" \
    "llama3.2:3b"                "Llama 3.2 3B      — small, fast" \
    "llama3.1:8b"                "Llama 3.1 8B" \
    "llama3.1:70b"               "Llama 3.1 70B     — large, slow" \
    "mistral:7b"                 "Mistral 7B" \
    "mistral-nemo"               "Mistral Nemo" \
    "phi3:mini"                  "Phi-3 Mini" \
    "phi3:medium"                "Phi-3 Medium" \
    "gemma2:9b"                  "Gemma 2 9B" \
    "gemma2:27b"                 "Gemma 2 27B" \
    "qwen2.5:7b"                 "Qwen 2.5 7B" \
    "deepseek-r1:7b"             "DeepSeek R1 7B" \
    "codellama:13b"              "CodeLlama 13B")
else
  MODEL=$(wt_menu 2 "Default Model" "Select default model for BitNet:" \
    "bitnet-b1.58-2B-4T"         "BitNet B1.58 2B-4T" \
    "bitnet-b1.58-3B"            "BitNet B1.58 3B" \
    "Llama3-8B-1.58-100B-tokens" "Llama3 8B 1.58-bit" \
    "Falcon3-1B-1.58B"           "Falcon3 1B 1.58-bit" \
    "Falcon3-3B-1.58B"           "Falcon3 3B 1.58-bit" \
    "Falcon3-7B-1.58B"           "Falcon3 7B 1.58-bit")
fi

# ── Step 3: Instances ─────────────────────────────────────────────────────────

INSTANCES_MODE=$(wt_menu 3 "Deployment Instances" "Instance topology:" \
  "single"    "Single     — One instance, simple setup" \
  "prod_test" "Prod/Test  — Separate production & test stacks")

INSTANCES_PROD_PORT="11434"
INSTANCES_TEST_PORT="11435"
if [[ "$INSTANCES_MODE" == "prod_test" ]]; then
  INSTANCES_PROD_PORT=$(wt_input 3 "Deployment Instances" "Production API port:" "11434")
  INSTANCES_TEST_PORT=$(wt_input 3 "Deployment Instances" "Test API port:" "11435")
fi

# ── Step 4: Model Cache ───────────────────────────────────────────────────────

CACHE_TYPE=$(wt_menu 4 "Model Cache" "Model cache location:" \
  "none"    "None     — No caching, pull on demand" \
  "local"   "Local    — Cache on this machine's disk" \
  "network" "Network  — Shared NFS / SMB cache")

CACHE_PATH="" CACHE_MOUNT="" CACHE_SHARE_PATH=""
if [[ "$CACHE_TYPE" == "local" ]]; then
  CACHE_PATH=$(wt_input 4 "Model Cache" "Local cache path:" "/opt/ai_models")
fi

# ── Step 5: NAS / Synology ───────────────────────────────────────────────────

NAS_ENABLED="false"
NAS_HOST="" NAS_NFS4_DOMAIN="htsai" NAS_USES=""
NAS_MODEL_CACHE_SHARE="" NAS_MODEL_CACHE_MOUNT="/mnt/ai_models"
NAS_DOCKER_BACKUP_SHARE="" NAS_DOCKER_BACKUP_MOUNT="/mnt/nas-backups"
NAS_TIMESHIFT_SHARE="" NAS_TIMESHIFT_MOUNT="/mnt/nas-timeshift"

# Only ask about Synology discovery when using network cache.
if [[ "$CACHE_TYPE" == "network" ]]; then
  NAS_ENABLED=$(wt_yesno 5 "NAS / Synology" \
    "Use Synology NAS auto-discovery for network model cache setup?" "no")
fi

if [[ "$NAS_ENABLED" == "true" ]]; then

  # ── arp-scan to discover / verify NAS IP ─────────────────────────────────
  _ARP_ITEMS=()
  if command -v arp-scan &>/dev/null; then
    _ARP_RAW=""
    _ARP_SCAN_CMD=()

    # Never block on a hidden sudo password prompt.
    # If sudo credentials are not already cached, skip auto-discovery and
    # continue with manual NAS host entry.
    if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
      _ARP_SCAN_CMD=(arp-scan -l)
    elif command -v sudo &>/dev/null && sudo -n true 2>/dev/null; then
      _ARP_SCAN_CMD=(sudo -n arp-scan -l)
    else
      info "Skipping NAS auto-discovery (sudo auth not cached). Enter NAS host manually."
    fi

    if [[ ${#_ARP_SCAN_CMD[@]} -gt 0 ]]; then
      info "Scanning local network for NAS devices (timeout: 8s)..."
      _ARP_RAW=$(timeout 8s "${_ARP_SCAN_CMD[@]}" 2>/dev/null | grep -E '^[0-9]' | sort -t. -k4 -n) || true
      if [[ -z "$_ARP_RAW" ]]; then
        info "NAS auto-discovery returned no results (or timed out). Continuing with manual host entry."
      fi
    fi

    while IFS=$'\t' read -r ip mac vendor; do
      [[ -z "$ip" ]] && continue
      _ARP_ITEMS+=("$ip" "${vendor:-$mac}")
    done <<< "$_ARP_RAW"
  fi

  if [[ ${#_ARP_ITEMS[@]} -gt 0 ]]; then
    _PICKED=$(whiptail --title "[4/$TOTAL] NAS — Select Device" \
      --menu "Select your NAS from devices found on this network\n(Cancel to enter IP manually):" \
      18 $W 10 "${_ARP_ITEMS[@]}" \
      3>&1 1>&2 2>&3) || _PICKED=""
    NAS_HOST="${_PICKED}"
  fi

  if [[ -z "$NAS_HOST" ]]; then
    NAS_HOST=$(wt_input 4 "NAS / Synology" "NAS hostname or IP address:" "192.168.1.x")
  fi

  NAS_NFS4_DOMAIN=$(wt_input 4 "NAS — NFSv4.1 Domain" \
    "NFSv4.1 domain\n(Synology: Control Panel → File Services → NFS → Advanced Settings\n → NFSv4/4.1 domain):" "htsai")

  # ── Share probe loop ──────────────────────────────────────────────────────
  # Expected shares (installer looks for these exact names on the NAS):
  _S_NAMES=( "htsai-model-backup"         "htsai-docker-volume-backup"   "htsai-timeshift-backup"   )
  _S_TAGS=(  "model_cache"                "docker_backups"                "timeshift"                )
  _S_LABELS=("Model cache (AI models)"    "Docker volume backups"         "Timeshift system backups" )

  _EXPORTS=""  # populated in loop; accessible after break for mount-point collection
  while true; do

    # Probe NFS exports
    _EXPORTS=""
    if command -v showmount &>/dev/null && [[ -n "$NAS_HOST" && "$NAS_HOST" != "192.168.1.x" ]]; then
      _EXPORTS=$(showmount -e "$NAS_HOST" 2>/dev/null | awk '{print $1}') || true
    fi

    # Classify each expected share as found or missing
    _FOUND_IDX=() _MISS_IDX=()
    for i in "${!_S_NAMES[@]}"; do
      if echo "$_EXPORTS" | grep -qE "/${_S_NAMES[$i]}$"; then
        _FOUND_IDX+=("$i")
      else
        _MISS_IDX+=("$i")
      fi
    done

    # Build info about missing shares (shown before the checklist)
    _MISS_MSG=""
    if [[ ${#_MISS_IDX[@]} -gt 0 ]]; then
      _MISS_MSG="Not found on ${NAS_HOST}:\n"
      for i in "${_MISS_IDX[@]}"; do
        _MISS_MSG+="  ✗  /volume1/${_S_NAMES[$i]}\n"
      done
      _MISS_MSG+="\nSee setup/synology-nfs-shares.md for setup instructions."
    fi

    if [[ ${#_FOUND_IDX[@]} -eq 0 ]]; then
      # Nothing found — show info, offer retry or skip only
      whiptail --title "[4/$TOTAL] NAS — No Shares Found" \
        --msgbox "No expected NFS shares were found on ${NAS_HOST}.\n\n${_MISS_MSG}" \
        14 $W || true
      _NAS_ACTION=$(whiptail --title "[4/$TOTAL] NAS — What next?" \
        --menu "Select an option:" 10 $W 2 \
        "r" "Retry — re-scan after creating shares on the NAS" \
        "s" "Skip  — configure NAS manually later" \
        3>&1 1>&2 2>&3) || _NAS_ACTION="s"
    else
      # One or more shares found — show missing info if partial
      if [[ ${#_MISS_IDX[@]} -gt 0 ]]; then
        whiptail --title "[4/$TOTAL] NAS — Some Shares Missing" \
          --msgbox "$_MISS_MSG" 12 $W || true
      fi

      # Build checklist: only found shares, pre-selected ON
      _CHECK_ARGS=()
      for i in "${_FOUND_IDX[@]}"; do
        _CHECK_ARGS+=("${_S_TAGS[$i]}" "${_S_LABELS[$i]}" "ON")
      done

      NAS_USES=$(whiptail --title "[4/$TOTAL] NAS — Enable Shares" \
        --checklist "Shares found on ${NAS_HOST}:\n(Space=toggle, Enter=confirm)" \
        16 $W 5 "${_CHECK_ARGS[@]}" \
        3>&1 1>&2 2>&3 | tr -d '"') || NAS_USES=""

      # c/r/s action menu (r only shown when there are missing shares)
      _MENU_ITEMS=("c" "Continue  — use selected shares")
      [[ ${#_MISS_IDX[@]} -gt 0 ]] && _MENU_ITEMS+=("r" "Retry     — re-scan after fixing missing shares")
      _MENU_ITEMS+=("s" "Skip      — skip NAS configuration")

      _NAS_ACTION=$(whiptail --title "[4/$TOTAL] NAS — Proceed?" \
        --menu "What would you like to do?" \
        12 $W 3 "${_MENU_ITEMS[@]}" \
        3>&1 1>&2 2>&3) || _NAS_ACTION="s"
    fi

    case "$_NAS_ACTION" in
      c) break ;;
      r) continue ;;
      s) NAS_ENABLED="false"; NAS_USES=""; break ;;
    esac
  done

  # ── Collect mount points for selected uses ────────────────────────────────
  if [[ "$NAS_ENABLED" == "true" ]]; then
    if echo "$NAS_USES" | grep -qw "model_cache"; then
      _DET=$(echo "$_EXPORTS" | grep -E "/htsai-model-backup$" | head -1)
      NAS_MODEL_CACHE_SHARE=$(wt_input 4 "NAS — Model Cache" \
        "NFS share path for AI models:" "${_DET:-/volume1/htsai-model-backup}")
      NAS_MODEL_CACHE_MOUNT=$(wt_input 4 "NAS — Model Cache" \
        "Local mount point:" "/mnt/ai_models")
    fi
    if echo "$NAS_USES" | grep -qw "docker_backups"; then
      _DET=$(echo "$_EXPORTS" | grep -E "/htsai-docker-volume-backup$" | head -1)
      NAS_DOCKER_BACKUP_SHARE=$(wt_input 4 "NAS — Docker Backups" \
        "NFS share path for Docker backups:" "${_DET:-/volume1/htsai-docker-volume-backup}")
      NAS_DOCKER_BACKUP_MOUNT=$(wt_input 4 "NAS — Docker Backups" \
        "Local mount point:" "/mnt/nas-backups")
    fi
    if echo "$NAS_USES" | grep -qw "timeshift"; then
      _DET=$(echo "$_EXPORTS" | grep -E "/htsai-timeshift-backup$" | head -1)
      NAS_TIMESHIFT_SHARE=$(wt_input 4 "NAS — Timeshift" \
        "NFS share path for Timeshift snapshots:" "${_DET:-/volume1/htsai-timeshift-backup}")
      NAS_TIMESHIFT_MOUNT=$(wt_input 4 "NAS — Timeshift" \
        "Local mount point:" "/mnt/nas-timeshift")
    fi
  fi
fi

# If network cache is selected but NAS integration is not enabled, ask for
# generic mount/share values directly.
if [[ "$CACHE_TYPE" == "network" ]]; then
  if [[ "$NAS_ENABLED" == "true" ]] && echo "$NAS_USES" | grep -qw "model_cache"; then
    CACHE_MOUNT="$NAS_MODEL_CACHE_MOUNT"
    CACHE_SHARE_PATH="${NAS_HOST}:${NAS_MODEL_CACHE_SHARE}"
  else
    CACHE_MOUNT=$(wt_input 5 "Model Cache" "Network share mount point:" "/mnt/ai_models")
    CACHE_SHARE_PATH=$(wt_input 5 "Model Cache" "Share path (e.g. //nas/ai_models):" "")
  fi
fi

# ── Step 6: Voice ─────────────────────────────────────────────────────────────

VOICE_ENABLED=$(wt_yesno 6 "Voice Support" "Enable voice input / output?" "no")
VOICE_STT="" VOICE_TTS="" VOICE_WAKE_WORD="false"
if [[ "$VOICE_ENABLED" == "true" ]]; then
  VOICE_STT=$(wt_menu 6 "Voice Support" "Speech-to-text engine:" \
    "whisper"        "Whisper (local)    — Private, no cloud" \
    "faster_whisper" "Faster-Whisper     — Optimised local STT" \
    "vosk"           "Vosk (offline)     — Lightweight STT")
  VOICE_TTS=$(wt_menu 6 "Voice Support" "Text-to-speech engine:" \
    "piper"  "Piper   — Fast local neural TTS" \
    "coqui"  "Coqui   — High quality local TTS" \
    "espeak" "espeak  — Lightweight, robotic")
  VOICE_WAKE_WORD=$(wt_yesno 6 "Voice Support" "Enable wake-word detection?" "no")
fi

# ── Step 7: Images ────────────────────────────────────────────────────────────

IMAGES_ENABLED=$(wt_yesno 6 "Image Generation" "Enable image generation?" "no")
IMAGES_ENGINE="" IMAGES_GPU_LAYERS=""
if [[ "$IMAGES_ENABLED" == "true" ]]; then
  IMAGES_ENGINE=$(wt_menu 6 "Image Generation" "Image generation engine:" \
    "stable_diffusion" "Stable Diffusion  — Full control, GPU heavy" \
    "comfyui"          "ComfyUI           — Node-based SD pipeline" \
    "invokeai"         "InvokeAI          — Polished SD UI" \
    "fooocus"          "Fooocus           — Simple SD interface")
  IMAGES_GPU_LAYERS=$(wt_menu 6 "Image Generation" "GPU offload layers:" \
    "0"   "0 — CPU only" \
    "16"  "16 layers" \
    "32"  "32 layers" \
    "48"  "48 layers" \
    "All" "All — max GPU offload")
fi

# ── Step 8: Claw3D ────────────────────────────────────────────────────────────

CLAW3D_ENABLED=$(wt_yesno 8 "Claw3D (3D Visualisation)" "Enable Claw3D visualisation engine?" "no")
CLAW3D_RENDERER="" CLAW3D_RESOLUTION=""
if [[ "$CLAW3D_ENABLED" == "true" ]]; then
  CLAW3D_RENDERER=$(wt_menu 8 "Claw3D" "Rendering backend:" \
    "OpenGL"         "OpenGL" \
    "Vulkan"         "Vulkan" \
    "WebGL_browser"  "WebGL (browser)")
  CLAW3D_RESOLUTION=$(wt_menu 8 "Claw3D" "Default viewport resolution:" \
    "1280x720"  "1280×720" \
    "1920x1080" "1920×1080 (FHD)" \
    "2560x1440" "2560×1440 (QHD)" \
    "4K"        "4K / UHD")
fi

# ── Step 9: Paperclip ─────────────────────────────────────────────────────────

PAPERCLIP_ENABLED=$(wt_yesno 9 "Paperclip (OpenClaw Agent Manager)" "Enable Paperclip agent manager?" "yes")
PAPERCLIP_MAX_AGENTS="4"
PAPERCLIP_AGENT_MEMORY="In-memory (fast)"
PAPERCLIP_AUTO_RESTART="true"
if [[ "$PAPERCLIP_ENABLED" == "true" ]]; then
  PAPERCLIP_MAX_AGENTS=$(wt_menu 9 "Paperclip" "Max concurrent OpenClaw agents:" \
    "2"  "2 agents" \
    "4"  "4 agents" \
    "8"  "8 agents" \
    "16" "16 agents" \
    "32" "32 agents")
  PAPERCLIP_AGENT_MEMORY=$(wt_menu 9 "Paperclip" "Agent memory backend:" \
    "in_memory" "In-memory (fast)" \
    "redis"     "Redis (persistent)" \
    "sqlite"    "SQLite (lightweight)")
  PAPERCLIP_AUTO_RESTART=$(wt_yesno 9 "Paperclip" "Auto-restart failed agents?" "yes")
fi

# ── Step 10: Docker Network ───────────────────────────────────────────────────

NETWORK=$(wt_menu 10 "Docker Network" "Docker network topology:" \
  "Direct bind" "Direct bind  — Host network, fastest" \
  "Single vnet" "Single vnet  — Shared bridge, simple" \
  "Secure vnet" "Secure vnet  — Isolated networks, firewall rules")

# ── Step 11: Comms ────────────────────────────────────────────────────────────

COMMS_PLATFORMS=$(wt_check 11 "Communications (Bot Integrations)" \
  "Select communication platforms:" \
  "telegram" "Telegram  — Bot API, lightweight"               OFF \
  "signal"   "Signal    — Encrypted messaging via signal-cli" OFF \
  "discord"  "Discord   — Bot with slash commands"            OFF)

COMMS_TELEGRAM_TOKEN="" COMMS_SIGNAL_PHONE="" COMMS_DISCORD_TOKEN=""
if echo "$COMMS_PLATFORMS" | grep -qw "telegram"; then
  COMMS_TELEGRAM_TOKEN=$(wt_input 11 "Comms — Telegram" "Telegram bot token (blank to set later):" "")
fi
if echo "$COMMS_PLATFORMS" | grep -qw "signal"; then
  COMMS_SIGNAL_PHONE=$(wt_input 11 "Comms — Signal" "Signal phone number (e.g. +441234567890):" "")
fi
if echo "$COMMS_PLATFORMS" | grep -qw "discord"; then
  COMMS_DISCORD_TOKEN=$(wt_input 11 "Comms — Discord" "Discord bot token (blank to set later):" "")
fi

# ── Step 12: Admin ────────────────────────────────────────────────────────────

ADMIN_TOOLS=$(wt_check 12 "Admin & Remote Access" \
  "Select remote admin tools:" \
  "tailscale"  "Tailscale   — Zero-config VPN mesh"          OFF \
  "xrdp"       "xRDP        — Remote desktop (RDP protocol)" OFF \
  "ssh_server" "SSH Server  — OpenSSH daemon"                ON)

ADMIN_TAILSCALE_KEY="" ADMIN_SSH_PORT="22" ADMIN_SSH_PUBKEY_ONLY="true" ADMIN_XRDP_PORT="3389"
if echo "$ADMIN_TOOLS" | grep -qw "tailscale"; then
  ADMIN_TAILSCALE_KEY=$(wt_input 12 "Admin — Tailscale" "Tailscale auth key (blank to auth interactively):" "")
fi
if echo "$ADMIN_TOOLS" | grep -qw "ssh_server"; then
  ADMIN_SSH_PORT=$(wt_input 12 "Admin — SSH" "SSH port:" "22")
  ADMIN_SSH_PUBKEY_ONLY=$(wt_yesno 12 "Admin — SSH" "Disable password login (pubkey only)?" "yes")
fi
if echo "$ADMIN_TOOLS" | grep -qw "xrdp"; then
  ADMIN_XRDP_PORT=$(wt_input 12 "Admin — xRDP" "RDP port:" "3389")
fi

# ── Step 13: Extras ───────────────────────────────────────────────────────────

EXTRAS=$(wt_check 13 "Extra Components" \
  "Select additional components:" \
  "open_webui"  "Open WebUI    — Browser chat interface" ON  \
  "prometheus"  "Prometheus    — Metrics & monitoring"   OFF \
  "grafana"     "Grafana       — Dashboards"             OFF \
  "nginx"       "Nginx proxy   — Reverse proxy / TLS"    OFF \
  "portainer"   "Portainer     — Docker GUI manager"     OFF)

# ── Summary + confirm ─────────────────────────────────────────────────────────

clear
echo -e "${CYAN}${BOLD}══ Configuration Summary ══${NC}"
echo ""
printf "  %-16s %s\n" "Backend:"     "$BACKEND"
printf "  %-16s %s\n" "Model:"       "$MODEL"
printf "  %-16s %s\n" "Instances:"   "$INSTANCES_MODE"
printf "  %-16s %s\n" "NAS:"         "${NAS_ENABLED} ${NAS_HOST:+(${NAS_HOST})}"
if [[ "$NAS_ENABLED" == "true" ]]; then
printf "  %-16s %s\n" "  NAS uses:"  "${NAS_USES:-none}"
fi
printf "  %-16s %s\n" "Cache:"       "$CACHE_TYPE"
printf "  %-16s %s\n" "Voice:"       "$VOICE_ENABLED"
printf "  %-16s %s\n" "Images:"      "$IMAGES_ENABLED"
printf "  %-16s %s\n" "Claw3D:"      "$CLAW3D_ENABLED"
printf "  %-16s %s (%s agents)\n" "Paperclip:" "$PAPERCLIP_ENABLED" "$PAPERCLIP_MAX_AGENTS"
printf "  %-16s %s\n" "Docker net:"  "$NETWORK"
printf "  %-16s %s\n" "Comms:"       "${COMMS_PLATFORMS:-none}"
printf "  %-16s %s\n" "Admin tools:" "${ADMIN_TOOLS:-none}"
printf "  %-16s %s\n" "Extras:"      "${EXTRAS:-none}"
echo ""

if ! whiptail --title "Save Configuration?" \
              --yesno "Save this configuration to config/stack.json?" \
              10 $W; then
  echo "  Config not saved."
  exit 0
fi

# ── Backup existing config ────────────────────────────────────────────────────

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p "$CONFIG_DIR" "$BACKUP_DIR"

if [[ -f "$STACK_JSON" ]]; then
  mkdir -p "$BACKUP_DIR/$TIMESTAMP"
  cp "$STACK_JSON" "$BACKUP_DIR/$TIMESTAMP/stack.json"
  [[ -f "$REPO_ROOT/.env" ]] && cp "$REPO_ROOT/.env" "$BACKUP_DIR/$TIMESTAMP/.env.bak"
fi

# ── Write JSON ────────────────────────────────────────────────────────────────
# Export all collected values so python3 subprocess can read via os.environ.

export BACKEND MODEL
export INSTANCES_MODE INSTANCES_PROD_PORT INSTANCES_TEST_PORT
export NAS_ENABLED NAS_HOST NAS_NFS4_DOMAIN NAS_USES
export NAS_MODEL_CACHE_SHARE NAS_MODEL_CACHE_MOUNT
export NAS_DOCKER_BACKUP_SHARE NAS_DOCKER_BACKUP_MOUNT
export NAS_TIMESHIFT_SHARE NAS_TIMESHIFT_MOUNT
export CACHE_TYPE CACHE_PATH CACHE_MOUNT CACHE_SHARE_PATH
export VOICE_ENABLED VOICE_STT VOICE_TTS VOICE_WAKE_WORD
export IMAGES_ENABLED IMAGES_ENGINE IMAGES_GPU_LAYERS
export CLAW3D_ENABLED CLAW3D_RENDERER CLAW3D_RESOLUTION
export PAPERCLIP_ENABLED PAPERCLIP_MAX_AGENTS PAPERCLIP_AGENT_MEMORY PAPERCLIP_AUTO_RESTART
export NETWORK
export COMMS_PLATFORMS COMMS_TELEGRAM_TOKEN COMMS_SIGNAL_PHONE COMMS_DISCORD_TOKEN
export ADMIN_TOOLS ADMIN_TAILSCALE_KEY ADMIN_SSH_PORT ADMIN_SSH_PUBKEY_ONLY ADMIN_XRDP_PORT
export EXTRAS
export TIMESTAMP STACK_JSON SECRETS_JSON

python3 - <<'PYEOF'
import json, os, stat

def to_list(s):
    """Convert space-separated string of words to a list, filtering blanks."""
    return [x for x in s.split() if x]

def env(key, default=""):
    return os.environ.get(key, default)

def benv(key):
    return env(key) == "true"

NETWORK_MODES = {
    "Direct bind": ("host",          "Container uses host network directly. Fastest, least isolated."),
    "Single vnet": ("bridge",        "Containers share a single bridge network. Simple and isolated."),
    "Secure vnet": ("custom_bridge", "Separate networks per service with firewall rules. Most secure."),
}

MEMORY_LABELS = {
    "in_memory": "In-memory (fast)",
    "redis":     "Redis (persistent)",
    "sqlite":    "SQLite (lightweight)",
}

network      = env("NETWORK")
net_mode, net_desc = NETWORK_MODES.get(network, ("bridge", ""))
timestamp    = env("TIMESTAMP")
stack_json   = env("STACK_JSON")
secrets_json = env("SECRETS_JSON")

comms_platforms       = to_list(env("COMMS_PLATFORMS"))
comms_telegram_token  = env("COMMS_TELEGRAM_TOKEN")
comms_signal_phone    = env("COMMS_SIGNAL_PHONE")
comms_discord_token   = env("COMMS_DISCORD_TOKEN")

admin_tools        = to_list(env("ADMIN_TOOLS"))
admin_tailscale_key = env("ADMIN_TAILSCALE_KEY")

# ── Build clean config (no secrets) ──────────────────────────────────────────
cfg = {
    "_meta": {
        "format_version": "1",
        "saved_at": timestamp,
        "note": "Secrets/tokens are never stored here — see stack.secrets.json or .env.",
    },
    "backend": env("BACKEND"),
    "model":   env("MODEL"),
    "instances": {
        "mode":      env("INSTANCES_MODE"),
        "prod_port": env("INSTANCES_PROD_PORT"),
        "test_port": env("INSTANCES_TEST_PORT"),
    },
    "model_cache": {"type": env("CACHE_TYPE")},
    "voice": {
        "enabled":   benv("VOICE_ENABLED"),
        "stt":       env("VOICE_STT"),
        "tts":       env("VOICE_TTS"),
        "wake_word": benv("VOICE_WAKE_WORD"),
    },
    "images": {
        "enabled":    benv("IMAGES_ENABLED"),
        "engine":     env("IMAGES_ENGINE"),
        "gpu_layers": env("IMAGES_GPU_LAYERS"),
    },
    "claw3d": {
        "enabled":    benv("CLAW3D_ENABLED"),
        "renderer":   env("CLAW3D_RENDERER"),
        "resolution": env("CLAW3D_RESOLUTION"),
    },
    "paperclip": {
        "enabled":      benv("PAPERCLIP_ENABLED"),
        "max_agents":   env("PAPERCLIP_MAX_AGENTS"),
        "agent_memory": MEMORY_LABELS.get(env("PAPERCLIP_AGENT_MEMORY"), env("PAPERCLIP_AGENT_MEMORY")),
        "auto_restart": benv("PAPERCLIP_AUTO_RESTART"),
    },
    "network": {
        "topology":    network,
        "mode":        net_mode,
        "description": net_desc,
    },
    "comms": {
        "platforms": comms_platforms,
        "tokens":    {},          # secrets stripped
    },
    "admin": {
        "tools":          admin_tools,
        "ssh_port":       env("ADMIN_SSH_PORT"),
        "ssh_pubkey_only": benv("ADMIN_SSH_PUBKEY_ONLY"),
        "xrdp_port":      env("ADMIN_XRDP_PORT"),
    },
    "nas": {
        "enabled":              benv("NAS_ENABLED"),
        "host":                 env("NAS_HOST"),
        "nfs4_domain":          env("NAS_NFS4_DOMAIN", "htsai"),
        "uses":                 to_list(env("NAS_USES")),
        "model_cache_share":    env("NAS_MODEL_CACHE_SHARE"),
        "model_cache_mount":    env("NAS_MODEL_CACHE_MOUNT"),
        "docker_backup_share":  env("NAS_DOCKER_BACKUP_SHARE"),
        "docker_backup_mount":  env("NAS_DOCKER_BACKUP_MOUNT"),
        "timeshift_share":      env("NAS_TIMESHIFT_SHARE"),
        "timeshift_mount":      env("NAS_TIMESHIFT_MOUNT"),
    },
    "extras": {
        "components": to_list(env("EXTRAS")),
    },
}

cache_type = env("CACHE_TYPE")
if cache_type == "local":
    cfg["model_cache"]["path"] = env("CACHE_PATH")
elif cache_type == "network":
    cfg["model_cache"]["mount"]      = env("CACHE_MOUNT")
    cfg["model_cache"]["share_path"] = env("CACHE_SHARE_PATH")

with open(stack_json, "w") as f:
    json.dump(cfg, f, indent=2)
print(f"  ✓  Config saved  → {stack_json}")

# ── Write secrets (gitignored, chmod 600) ─────────────────────────────────────
secrets = {"_meta": {"saved_at": timestamp}}

if "telegram" in comms_platforms and comms_telegram_token:
    secrets.setdefault("comms_tokens", {})["telegram_bot_token"] = comms_telegram_token
if "signal" in comms_platforms and comms_signal_phone:
    secrets.setdefault("comms_tokens", {})["signal_phone_number"] = comms_signal_phone
if "discord" in comms_platforms and comms_discord_token:
    secrets.setdefault("comms_tokens", {})["discord_bot_token"] = comms_discord_token
if "tailscale" in admin_tools and admin_tailscale_key:
    secrets["tailscale_authkey"] = admin_tailscale_key

if len(secrets) > 1:   # more than just _meta
    with open(secrets_json, "w") as f:
        json.dump(secrets, f, indent=2)
    os.chmod(secrets_json, stat.S_IRUSR | stat.S_IWUSR)
    print(f"  ✓  Secrets saved → {secrets_json}  (chmod 600, gitignored)")
PYEOF

echo ""
info "Configuration complete."
echo ""
