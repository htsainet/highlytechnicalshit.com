# Setup Issues & Feature Backlog

---

## FEATURE: Tailscale ACL Policy with Escape Hatch

**Priority:** HIGH (post v0.3.0 port binding fix)
**Effort:** ~20 minutes
**Risk:** None if escape hatch is left enabled — zero behavioral change until intentionally flipped
**Depends on:** Port binding fix (item 1 of v0.3.0 immediate tasks)
**Blocks:** Nothing — additive security layer

### Problem

Once services bind to `127.0.0.1` + `${TAILSCALE_IP}`, they're no longer LAN-exposed. But any device on the tailnet can still reach every service. Right now that's fine (single operator), but adding a second device, sharing tailnet access, or connecting a less-trusted machine means unrestricted access to Jenkins (no auth), Ollama (unauthenticated inference), Open WebUI, etc.

### Solution

Add a Tailscale ACL policy that restricts which tailnet devices can reach which ports on the OpenClaw host. Include a default-allow escape hatch so the policy can be deployed safely and enforced later.

### Implementation Steps

#### 1. Tag the OpenClaw host

```bash
sudo tailscale set --advertise-tags=tag:openclaw-host
```

#### 2. Tag operator devices (laptop, desktop, phone)

For each device you use to access OpenClaw:

```bash
# On each operator device
sudo tailscale set --advertise-tags=tag:operator
```

Or tag them via the Tailscale admin console (login.tailscale.com → Machines → Edit → Tags).

#### 3. Define tag ownership

In the Tailscale admin console (Access Controls tab), add to your policy file:

```jsonc
"tagOwners": {
    "tag:openclaw-host": ["autogroup:admin"],
    "tag:operator":      ["autogroup:admin"]
}
```

#### 4. Add ACL rules with escape hatch

Replace (or add to) the `acls` section of your Tailscale policy:

```jsonc
{
    "acls": [
        // ==========================================================
        // ESCAPE HATCH — DEFAULT ALLOW
        // Uncomment the line below to disable ACL enforcement.
        // This restores "any tailnet device can reach anything"
        // which is the default Tailscale behavior.
        //
        // Leave this UNCOMMENTED when first deploying.
        // Comment it out when ready to enforce granular rules.
        // ==========================================================
        {"action": "accept", "src": ["*"], "dst": ["*:*"]},

        // ==========================================================
        // GRANULAR RULES (active only when escape hatch is commented)
        // ==========================================================

        // --- Core services: operator devices only ---
        //
        // Open WebUI (3000), Dashboard (80), SillyTavern (8000)
        // These are the primary user-facing services.
        {
            "action": "accept",
            "src": ["tag:operator"],
            "dst": ["tag:openclaw-host:80,3000,8000"]
        },

        // --- Inference: operator devices only ---
        //
        // Ollama prod (11434), Ollama test (11435)
        // Unauthenticated inference endpoints — must be restricted.
        {
            "action": "accept",
            "src": ["tag:operator"],
            "dst": ["tag:openclaw-host:11434,11435"]
        },

        // --- Media services: operator devices only ---
        //
        // ComfyUI (8188), XTTS (8020), Whisper (9000)
        // No auth on any of these.
        {
            "action": "accept",
            "src": ["tag:operator"],
            "dst": ["tag:openclaw-host:8188,8020,9000"]
        },

        // --- Ops: operator devices only ---
        //
        // Jenkins (8080) — currently no auth, no TLS.
        // This is the highest-risk service on the tailnet.
        // Consider restricting further to specific devices if needed.
        {
            "action": "accept",
            "src": ["tag:operator"],
            "dst": ["tag:openclaw-host:8080"]
        },

        // --- SSH: operator devices only ---
        {
            "action": "accept",
            "src": ["tag:operator"],
            "dst": ["tag:openclaw-host:22"]
        }

        // --- Everything else is DENIED by default ---
        // Tailscale's implicit deny means any device/port combo
        // not listed above gets blocked silently.
    ],

    "tagOwners": {
        "tag:openclaw-host": ["autogroup:admin"],
        "tag:operator":      ["autogroup:admin"]
    }
}
```

#### 5. Deploy and verify (escape hatch ON)

With the escape hatch line uncommented (default-allow active):

```bash
# From your operator device, verify all services are reachable
tailscale ping openclaw-host
curl http://<TAILSCALE_IP>:3000    # Open WebUI
curl http://<TAILSCALE_IP>:11434   # Ollama
curl http://<TAILSCALE_IP>:8080    # Jenkins
```

Everything should work identically to before. The ACL rules exist but are overridden by the `*:*` allow-all.

#### 6. Enforce (when ready)

Comment out the escape hatch line:

```jsonc
        // {"action": "accept", "src": ["*"], "dst": ["*:*"]},
```

Save the policy. Tailscale enforces immediately (no restart needed).

Then verify:

```bash
# From operator device — should still work
curl http://<TAILSCALE_IP>:3000

# From a non-operator tailnet device — should be refused
# (if you have one to test with)
```

#### 7. Rollback

If anything breaks, uncomment the escape hatch line in the admin console. Takes effect in seconds.

### Validation

After enforcement, run the existing Pester suite:

```powershell
Invoke-Pester ./tests/Security/PortBindings.Tests.ps1 -Output Detailed
```

The Pester tests are unaffected by ACLs because they probe from the host itself (localhost access is independent of Tailscale ACLs). ACL validation is at the tailnet layer, not the host layer.

**Optional future Pester test:** Add a test that hits the Tailscale API or parses `tailscale status --json` to confirm the host is tagged correctly and the policy isn't in escape-hatch mode. Low priority — the admin console is the source of truth for ACLs.

### Future Considerations

- **Per-service tags:** If you add collaborators, split into `tag:ops-admin` (gets Jenkins + SSH) vs `tag:user` (gets Open WebUI + Dashboard only). This is a policy change, no infra work.
- **Tailscale Funnel:** If you ever want to expose a single service publicly (e.g., a demo endpoint), Tailscale Funnel can do this per-service without a reverse proxy. Not recommended for current stack.
- **Headscale migration:** If you want self-hosted control plane, these same ACLs work with Headscale's `policy.json`. The tag and rule syntax is identical.

### Checklist

- [ ] Tag OpenClaw host as `tag:openclaw-host`
- [ ] Tag operator devices as `tag:operator`
- [ ] Add `tagOwners` to Tailscale policy
- [ ] Add ACL rules with escape hatch UNCOMMENTED (default-allow)
- [ ] Verify all services reachable from operator device
- [ ] (When ready) Comment out escape hatch to enforce
- [ ] Verify enforcement from a second device if available
- [ ] Verify rollback works (uncomment escape hatch)
