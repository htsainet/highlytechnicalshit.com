#!/usr/bin/env bash
# scripts/utils/collect-upstream-issues.sh — Generate upstream-issues.json from tracked issue files
#
# Parses docs/upstream/issues/*.md metadata (repo, issue number, state,
# severity, dates) into resources/dashboard/upstream-issues.json.
#
# Usage:
#   ./scripts/utils/collect-upstream-issues.sh            # generate JSON
#   ./scripts/utils/collect-upstream-issues.sh --stdout    # print to stdout instead
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

ISSUES_DIR="$REPO_DIR/docs/upstream/issues"
OUTPUT="$REPO_DIR/resources/dashboard/upstream-issues.json"
TO_STDOUT=false

[[ "${1:-}" == "--stdout" ]] && TO_STDOUT=true

# ── Helpers ───────────────────────────────────────────────────────────────────

# extract_table_field <file> <field_name> — grab value from | **Field** | value | table
extract_table_field() {
  local file="$1" field="$2"
  grep -m1 -iE "^\|\s*\*{2}${field}\*{2}" "$file" 2>/dev/null \
    | sed -E 's/^[^|]*\|[^|]*\|\s*//' \
    | sed -E 's/\s*\|.*//' \
    | sed -E 's/\[([^]]+)\]\([^)]*\)/\1/g' \
    || echo ""
}

# get_title <file> — first H1 line, strip leading "OWNER/REPO#NUM — "
get_title() {
  local raw
  raw=$(grep -m1 '^# ' "$1" 2>/dev/null | sed 's/^# //' || echo "Untitled")
  # Strip "OWNER/REPO#NUM — " prefix if present
  echo "$raw" | sed -E 's/^[^ ]+#[0-9]+ — //'
}

# json_escape <string> — escape for JSON string value
json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g'
}

# ── Live issue data via gh CLI (optional) ─────────────────────────────────────

# Try to fetch live data from GitHub for a repo/number pair.
# Returns JSON with state and updatedAt, or empty string on failure.
fetch_live_data() {
  local repo="$1" number="$2"
  if ! command -v gh &>/dev/null; then
    echo ""
    return
  fi
  gh issue view "$number" --repo "$repo" \
    --json state,updatedAt \
    --jq '{state: .state, updatedAt: .updatedAt}' 2>/dev/null || echo ""
}

# ── Collect entries ───────────────────────────────────────────────────────────

entries=()

for file in "$ISSUES_DIR"/*.md; do
  [[ -f "$file" ]] || continue

  basename="$(basename "$file" .md)"
  title=$(get_title "$file")
  repo=$(extract_table_field "$file" "Repo")
  issue_num=$(extract_table_field "$file" "Issue")
  state=$(extract_table_field "$file" "State")
  severity=$(extract_table_field "$file" "Severity")
  labels=$(extract_table_field "$file" "Labels")
  opened=$(extract_table_field "$file" "Opened")

  # Clean issue number: "#1685" → "1685"
  issue_num=$(echo "$issue_num" | sed -E 's/^#//')

  # Clean repo: "NVIDIA/NemoClaw" (strip any remaining markdown)
  repo=$(echo "$repo" | sed -E 's/\[([^]]+)\].*/\1/')

  # Build issue URL
  issue_url="https://github.com/${repo}/issues/${issue_num}"

  # Try live data from GitHub
  live_state=""
  last_updated=""
  live=$(fetch_live_data "$repo" "$issue_num")
  if [[ -n "$live" ]]; then
    live_state=$(echo "$live" | python3 -c "import json,sys;print(json.load(sys.stdin).get('state',''))" 2>/dev/null || echo "")
    last_updated=$(echo "$live" | python3 -c "import json,sys;print(json.load(sys.stdin).get('updatedAt',''))" 2>/dev/null || echo "")
    # Use live state if available
    [[ -n "$live_state" ]] && state="$live_state"
    # Format date: 2026-04-09T10:04:22Z → 2026-04-09
    last_updated=$(echo "$last_updated" | cut -dT -f1)
  fi

  # Fallback: use opened date if no live data
  [[ -z "$last_updated" ]] && last_updated="$opened"

  entries+=("{\"id\":\"$(json_escape "$basename")\",\"repo\":\"$(json_escape "$repo")\",\"number\":$issue_num,\"title\":\"$(json_escape "$title")\",\"state\":\"$(json_escape "$state")\",\"severity\":\"$(json_escape "$severity")\",\"opened\":\"$(json_escape "$opened")\",\"lastUpdated\":\"$(json_escape "$last_updated")\",\"url\":\"$(json_escape "$issue_url")\",\"labels\":\"$(json_escape "$labels")\"}")
done

# ── Emit JSON ─────────────────────────────────────────────────────────────────

json="{\"generated\":\"$(date -Iseconds)\",\"count\":${#entries[@]},\"items\":["
for i in "${!entries[@]}"; do
  [[ $i -gt 0 ]] && json+=","
  json+="${entries[$i]}"
done
json+="]}"

if $TO_STDOUT; then
  echo "$json"
else
  echo "$json" > "$OUTPUT"
  echo "[INFO] Wrote ${#entries[@]} upstream issues to $OUTPUT"
fi
