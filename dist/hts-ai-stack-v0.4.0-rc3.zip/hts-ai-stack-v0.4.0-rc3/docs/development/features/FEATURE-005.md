# Deferred Services — SCM, Creative, Agent Orchestration

**Priority:** LOW
**Target Release:** v0.6.0
**Effort:** 2-3 days (re-integration + security hardening)
**Risk:** Low — all component installers exist; work is re-enablement
**Depends on:** v0.5.0 stable
**Blocks:** Nothing

> Includes content merged from FEATURE-002 (KoboldCpp + SillyTavern Bundle).
> **KoboldCpp has been elevated to v0.5.0 as a standalone deliverable — see [FEATURE-031](FEATURE-031.md).**
> This file retains SillyTavern and the remaining deferred services.

## Scope

Re-enable services removed from the v0.4.0 build to reduce surface area.
Component installers remain in `scripts/components/`; this feature
re-wires them into the build pipeline with proper security posture.

### SCM & CI/CD

- **Gitea** — `scripts/components/gitea/gitea.sh`, `docker-compose.yml` (profile: gitea)
  - Self-hosted Git, port 3030
  - Docker-compose definition in place; removed from `06-start-stack.sh` and `full-stack.sh`

- **Jenkins** — planned CI/CD server
  - No component installer yet; volumes referenced in `nuke-stack.sh`
  - Security review flags: no reverse proxy, no TLS, default setup (C2)
  - Evaluate lighter alternatives (Gitea Actions, Woodpecker)

### Creative / RP (merged from FEATURE-002)

> **KoboldCpp has been promoted to [FEATURE-031](FEATURE-031.md) (v0.5.0 target).**
> SillyTavern remains here and depends on FEATURE-031 being deployed first.

- ~~**KoboldCpp** — GPU inference backend for creative/RP models~~
  → Elevated to [FEATURE-031](FEATURE-031.md). See that file for full implementation plan.

- **SillyTavern** — `scripts/components/sillytavern/sillytavern.sh`, `instances/prod/docker-compose.yml`
  - Character-based chat frontend, port 8001
  - Init job configures auth (disables whitelist, enables basicAuth)
  - Depends on llama-swap backend

#### Creative Stack Architecture

```text
            llama-swap :8081
           (unified router)
        ┌────────┼────────┐
        ▼                 ▼
     BitNet           KoboldCpp
     (CPU)            (GPU, 12 GB)
        ▲                 ▲
        │                 │
     NemoClaw          SillyTavern
     sandbox             :8001
     (agent tasks)    (creative/RP)
```

#### Creative Port Mapping

| Service | Host Port | Container Port | Notes |
|---------|-----------|----------------|-------|
| `hts-ai-koboldcpp` | *(none)* | `5001` | Internal only — llama-swap routes to it |
| `hts-ai-sillytavern` | `8001` | `8000` | User-facing creative/RP frontend |
| `hts-ai-llama-swap` | `8081` | `8080` | Unified router (existing) |
| `hts-ai-bitnet-cpu` | *(none)* | `8080` | Internal only (existing) |

#### Bundle: `scripts/bundles/creative.sh`

New bundle providing the creative/RP + agent stack without Ollama:

```text
1. HOST SETUP
   ├── scripts/host/nvidia.sh
   ├── scripts/host/docker.sh
   ├── scripts/host/node.sh
   └── scripts/host/tools.sh

2. CORE SERVICES
   ├── scripts/components/koboldcpp/koboldcpp.sh      (NEW — GPU creative inference)
   ├── scripts/components/bitnet/bitnet.sh         (CPU agent inference)
   ├── scripts/components/llama-swap/llama-swap.sh     (unified router)
   ├── scripts/components/sillytavern/sillytavern.sh    (creative frontend)
   └── scripts/components/gitea/gitea.sh          (self-hosted Git)

3. OPTIONAL
   ├── scripts/components/nemoclaw/nemoclaw.sh       (if NEMOCLAW_DEPLOY=true)
   └── scripts/components/dashboard/dashboard.sh      (if DASHBOARD_ENABLED=true)
```

### Agent Orchestration

- **OpenSpace** — `scripts/components/openspace/openspace.sh`, `docker-compose.yml` (profile: openspace)
  - MCP agent runtime, ports 5000 (MCP) + 3001 (dashboard)

- **DeerFlow** — `scripts/components/deerflow/deerflow.sh`, `scripts/bundles/deerflow.sh`
  - Multi-agent orchestration harness
  - Dedicated bundle exists

## Env Flags (legacy — now driven by component manifests via converge.sh)

```bash
GITEA_ENABLED=true
SILLYTAVERN_ENABLED=true
OPENSPACE_ENABLED=true
DEERFLOW_ENABLED=true
```

## Acceptance Criteria

- [ ] Gitea accessible at :3030 with health check passing
- [ ] Jenkins evaluated — decide: keep, replace with Gitea Actions, or drop
- [ ] SillyTavern connects to llama-swap and generates responses
- [ ] OpenSpace MCP endpoint responds on :5000
- [ ] DeerFlow agent harness executes a multi-agent workflow
- [ ] All services pass security review (TLS, auth, reverse proxy)
- [ ] Dashboard updated with all re-enabled services
