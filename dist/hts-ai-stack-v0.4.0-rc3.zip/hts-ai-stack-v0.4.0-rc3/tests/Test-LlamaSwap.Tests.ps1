$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/llama-swap'
    $script:ComponentScript = Join-Path $script:ComponentDir 'llama-swap.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'llama-swap.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'llama-swap file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'llama-swap manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is llama-swap' {
        $script:Manifest.id | Should -Be 'llama-swap'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/llama-swap/llama-swap.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is llamaswap' {
        $script:Manifest.func_prefix | Should -Be 'llamaswap'
    }

    It 'dashboard port is 8081' {
        [int]$script:Manifest.dashboard.port | Should -Be 8081
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'llama-swap component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines llamaswap_install function' {
        $script:ComponentContent | Should -Match 'llamaswap_install\s*\(\)'
    }

    It 'defines llamaswap_configure function' {
        $script:ComponentContent | Should -Match 'llamaswap_configure\s*\(\)'
    }

    It 'defines llamaswap_start function' {
        $script:ComponentContent | Should -Match 'llamaswap_start\s*\(\)'
    }

    It 'defines llamaswap_stop function' {
        $script:ComponentContent | Should -Match 'llamaswap_stop\s*\(\)'
    }

    It 'defines llamaswap_health function' {
        $script:ComponentContent | Should -Match 'llamaswap_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/llama-swap/llama-swap\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'llama-swap port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8081 is registered in portmap.json' {
        $script:Portmap.ports.'8081' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'8081'.service | Should -Be 'llama-swap'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'llama-swap no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/llama-swap\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/llama-swap/llama-swap\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
