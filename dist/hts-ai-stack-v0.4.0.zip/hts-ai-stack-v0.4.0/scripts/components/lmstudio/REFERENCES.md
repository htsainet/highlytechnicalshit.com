# LM Studio References

Last updated: 2026-04-15

## Upstream

- [LM Studio](https://lmstudio.ai/)

## Official documentation

- [LM Studio Docs](https://lmstudio.ai/docs)
- [lms CLI Reference](https://lmstudio.ai/docs/cli)

## Notes

- LM Studio is closed-source; no public GitHub repository.
- Installed via `.deb` package from the official site.
