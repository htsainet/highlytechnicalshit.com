# Installation Scripts

Bootstrap and installation wizards for deploying the AI stack.

Last updated: 2026-03-31 19:08:47

## What happens here

This workspace contains the installation and setup scripts that guide users through deploying the full AI stack on Ubuntu. The process is split into bootstrap (prerequisites + drivers) and install (interactive configuration + service setup).

## Process / Workflow

**Bootstrap phase (curl | bash entry point):**

1. User runs: `curl -sSL https://highlytechnicalshit.com/bootstrap.sh | bash`
2. Script installs system prerequisites (Docker, NVIDIA Container Toolkit, etc.)
3. Script clones repo to local system
4. Script installs NVIDIA drivers (requires reboot)
5. User reboots system

**Install phase (interactive wizard):**

1. User runs `install.sh` from repo root
2. Wizard prompts for configuration choices:
   - Audio support (xtts/whisper)?
   - Image support (stable diffusion/ComfyUI)?
   - Deployment mode (single instance or prod/test)?
   - Storage preferences (Synology NAS caching)?
3. Each step checks if already completed (idempotent)
4. Config snapshot saved to `/config/backups/YYYYMMDD-HHMMSS/`
5. Services started and validated

## Files and structure

| Folder | Purpose |
|--------|---------|
| `install/` | Numbered step scripts (01-autoinstall.sh, 02-setup-docker.sh, etc.) |
| `install/comms/` | Signal, Telegram, communication service setup |
| `install/models/` | Model-specific download and configuration helpers |
| `install/networking/` | Tailscale and network setup |
| `install/system/` | OS-level setup and configuration |
| `install/tooling/` | Developer and ops tooling installation |
| `utils/` | Utility scripts (reset-stack.sh via root launcher, seed-model-cache.sh, teardown.sh, verify.sh) |
| `config/` | Script-managed configuration files and wizard outputs |

## What good looks like

- Scripts are idempotent (safe to run multiple times)
- Each step detects if already completed before proceeding
- Clear, descriptive output messages
- Config backups on every run
- Bootstrap runs unprivileged until driver install (then sudo)
- Install wizard validates choices before proceeding
- Graceful error handling with helpful recovery steps
- All configs stored under /config/backups/ with timestamps

## Tools and skills

- **bash** — Shell scripting (scripts written in bash)
- **Docker** — Container orchestration and service management
- **NVIDIA Container Toolkit** — GPU support in containers
- **Ollama** — Local LLM inference engine
- **Tailscale** — Network connectivity and VPN
- **Claude Code** — Script generation and troubleshooting
