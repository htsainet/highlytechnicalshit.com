# Prometheus Component

Last updated: 2026-04-15

## What happens here

Prometheus collects and stores time-series metrics from all stack services.
Used alongside Grafana for monitoring, alerting, and performance analysis.

## Files and structure

| File | Purpose |
|------|---------|
| `prometheus.sh` | Full lifecycle: install, configure, start, stop, health |
| `prometheus.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

See [usage.md](./usage.md) for command usage.
