#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# helpers.sh — Shared functions for scripts/install/models/*.sh scripts
# Source this file at the top of each sub-script:
#   source "$(dirname "$0")/helpers.sh"
# ─────────────────────────────────────────────────────────────────────────────

# ── Colors & logging ─────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already present" >&2; }
step() { echo -e "\n${CYAN}══ $* ══${NC}" >&2; }
fail() { echo -e "${RED}[FAIL]${NC} $*" >&2; }
ok()   { echo -e "${GREEN}[OK]${NC} $*" >&2; }

# ── Load .env tokens ──────────────────────────────────────────────────────────
# Instance compose files require WEBUI_SECRET_KEY at parse
# time. helpers.sh lives three levels below the repo root
# (repo/scripts/install/models/helpers.sh).
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/../../.. && pwd)"
ENV_FILE="$REPO_ROOT/.env"
if [[ -f "$ENV_FILE" ]]; then
  set -a
  # shellcheck source=/dev/null
  source "$ENV_FILE"
  set +a
else
  echo -e "\033[0;31m[FAIL]\033[0m .env not found at $ENV_FILE — run 01-autoinstall.sh first." >&2
  exit 1
fi

# ── ensure_ai_network ─────────────────────────────────────────────────────────
# The instance compose files declare ai-network as external. It is created by
# the root docker-compose.yml on first `up`. If it doesn't exist yet (e.g. the
# root stack was never started), create it here so model pulls don't abort.
ensure_ai_network() {
  local net="hts-ai-stack_ai-network"
  if ! docker network inspect "$net" >/dev/null 2>&1; then
    info "Network '$net' not found — creating it now..."
    docker network create "$net"
    ok "Network '$net' created."
  fi
}

# ── wait_for_ollama <container> <port> ────────────────────────────────────────
# Blocks until the Ollama API responds on the given port.
wait_for_ollama() {
  local container="$1"
  local port="$2"
  info "Waiting for $container to be ready on port $port..."
  local attempts=0
  until curl -s "http://localhost:${port}/api/tags" > /dev/null 2>&1; do
    sleep 2
    attempts=$((attempts + 1))
    if [ "$attempts" -ge 30 ]; then
      fail "$container did not become ready after 60s — aborting."
      exit 1
    fi
  done
  ok "$container is ready."
}

# ── start_container <service> ─────────────────────────────────────────────────
# Respects COMPOSE_FILE env var if set (e.g. export COMPOSE_FILE=instances/prod/docker-compose.yml)
start_container() {
  local service="$1"
  local compose_args=()
  [[ -n "${COMPOSE_FILE:-}" ]] && compose_args=(-f "$COMPOSE_FILE")
  [[ -n "${ENV_FILE:-}" ]] && compose_args+=(--env-file "$ENV_FILE")
  info "Starting $service..."
  docker compose "${compose_args[@]}" up -d "$service"
}

# ── stop_container <service> ──────────────────────────────────────────────────
stop_container() {
  local service="$1"
  local compose_args=()
  [[ -n "${COMPOSE_FILE:-}" ]] && compose_args=(-f "$COMPOSE_FILE")
  [[ -n "${ENV_FILE:-}" ]] && compose_args+=(--env-file "$ENV_FILE")
  info "Stopping $service..."
  docker compose "${compose_args[@]}" stop "$service"
  ok "$service stopped."
}

# ── pull_ollama_if_missing <container> <port> <model> ────────────────────────
# Pulls a model into the given Ollama container if not already present.
pull_ollama_if_missing() {
  local container="$1"
  local port="$2"
  local model="$3"
  local model_base="${model%%:*}"

  # Check via API whether the model already exists
  if curl -s "http://localhost:${port}/api/tags" | grep -q "\"${model_base}\""; then
    skip "ollama ($container): $model"
  else
    info "Pulling $model into $container..."
    docker exec "$container" ollama pull "$model" \
      && ok "$model pulled." \
      || fail "$model failed to pull — check name/connectivity."
  fi
}

# ── set_ollama_default <container> <model> ────────────────────────────────────
# Tags a model as 'default' inside the container via a Modelfile alias.
set_ollama_default() {
  local container="$1"
  local model="$2"
  info "Setting default model in $container → $model"
  docker exec "$container" sh -c "
    echo 'FROM $model' | ollama create default -f -
  " && ok "Default set to $model." || warn "Could not set default — model may not be loaded yet."
}

# ── find_or_create_sd_volume <volume_grep_term> <compose_service> ─────────────
# Returns the volume name matching the grep term, starting the service if needed.
find_or_create_sd_volume() {
  local grep_term="$1"
  local compose_service="$2"
  local vol

  vol=$(docker volume ls --format '{{.Name}}' | grep "$grep_term" | head -1)
  if [ -z "$vol" ]; then
    warn "Volume matching '$grep_term' not found — starting $compose_service to create it..."
    start_container "$compose_service"
    sleep 5
    vol=$(docker volume ls --format '{{.Name}}' | grep "$grep_term" | head -1)
  fi

  if [ -z "$vol" ]; then
    fail "Could not find or create volume for '$grep_term'. Run ./02-setup-docker.sh first."
    exit 1
  fi

  echo "$vol"
}

# ── download_sd_if_missing <volume> <filename> <url> ─────────────────────────
# Downloads a Stable Diffusion checkpoint into the Docker volume if not already
# present. Resolution order:
#   1. Already in volume        → skip (nothing to do)
#   2. NAS cache available      → copy from NAS (fast, no internet)
#   3. Internet download        → curl on host → copy into volume
#
# NAS cache path is read from NAS_SD_CACHE env var; defaults to
# /mnt/nas/llm-cache/sd-checkpoints if not set.
download_sd_if_missing() {
  local volume="$1"
  local filename="$2"
  local url="$3"
  local nas_cache="${NAS_SD_CACHE:-/mnt/nas/llm-cache/sd-checkpoints}"

  if [ "$url" = "REPLACE_WITH_URL" ]; then
    warn "Skipping $filename — URL not set."
    return
  fi

  # ── 1. Already in the volume? ──────────────────────────────────────────────
  local already_exists
  already_exists=$(docker run --rm \
    -v "${volume}:/models" \
    alpine sh -c "[ -f /models/Stable-diffusion/${filename} ] && echo yes || echo no")

  if [ "$already_exists" = "yes" ]; then
    skip "sd: $filename"
    return
  fi

  # ── 2. Available on NAS? ──────────────────────────────────────────────────
  local nas_file="${nas_cache}/${filename}"
  if [[ -f "$nas_file" ]]; then
    local nas_size
    nas_size=$(stat -c%s "$nas_file" 2>/dev/null || echo 0)
    if [[ "$nas_size" -gt 1000000 ]]; then
      info "sd: $filename — copying from NAS cache..."
      docker run --rm \
        -v "${volume}:/models" \
        -v "${nas_cache}:/nas-cache:ro" \
        alpine sh -c "
          mkdir -p /models/Stable-diffusion
          cp /nas-cache/${filename} /models/Stable-diffusion/${filename}
        " && ok "$filename copied from NAS." \
          || { fail "$filename — NAS copy failed"; return 1; }
      return
    fi
  fi

  # ── 3. Download from internet via host curl ────────────────────────────────
  # Uses host curl (not curlimages/curl) to avoid XetHub CDN redirect issues.
  info "sd: $filename — downloading from internet..."
  local tmp_dir
  tmp_dir=$(mktemp -d)
  local tmp_file="${tmp_dir}/${filename}"

  if curl -fSL --retry 3 --retry-delay 5 --progress-bar \
      -o "$tmp_file" "$url"; then
    info "sd: $filename — copying into volume..."
    docker run --rm \
      -v "${volume}:/models" \
      -v "${tmp_dir}:/tmp-src:ro" \
      alpine sh -c "
        mkdir -p /models/Stable-diffusion
        cp /tmp-src/${filename} /models/Stable-diffusion/${filename}
      " && ok "$filename saved." \
        || { fail "$filename — volume copy failed"; rm -rf "$tmp_dir"; return 1; }
    rm -rf "$tmp_dir"

    # Optionally seed NAS cache for future installs
    if [[ -d "$nas_cache" && -w "$nas_cache" ]] && [[ ! -f "$nas_file" ]]; then
      info "sd: $filename — seeding NAS cache..."
      cp "$tmp_file" "$nas_file" 2>/dev/null && ok "$filename added to NAS cache." || true
    fi
  else
    fail "$filename — download failed. Check URL: $url"
    rm -rf "$tmp_dir"
    return 1
  fi
}

# ── create_model_dirs ─────────────────────────────────────────────────────────
# Creates the ~/models and ~/sd-models directory structure on the host.
create_model_dirs() {
  step "Creating host model directories"
  local dirs=(
    "$HOME/models/approved"
    "$HOME/models/testing"
    "$HOME/sd-models/prod/checkpoints"
    "$HOME/sd-models/prod/loras"
    "$HOME/sd-models/prod/vae"
    "$HOME/sd-models/prod/embeddings"
    "$HOME/sd-models/test/checkpoints"
    "$HOME/sd-models/test/loras"
    "$HOME/sd-models/test/vae"
    "$HOME/sd-models/test/embeddings"
    "$HOME/sd-outputs/prod"
    "$HOME/sd-outputs/test"
  )
  for dir in "${dirs[@]}"; do
    mkdir -p "$dir"
    ok "  $dir"
  done
}
