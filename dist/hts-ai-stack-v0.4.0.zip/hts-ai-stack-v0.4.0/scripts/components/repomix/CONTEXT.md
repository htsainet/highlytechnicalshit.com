# Repomix Component — CONTEXT

## What is Repomix?

Repomix is a CLI tool that packs an entire repository into a single AI‑friendly file (XML, Markdown, JSON, or plain text). It supports local directories, remote Git repositories, and provides token‑count visualisation, compression via Tree‑sitter, and flexible output formats. The output can be fed to local LLMs for code review, documentation generation, test case creation, or any downstream AI workflow.

## How it fits into the HTS AI Stack

- **Host‑installed**: Mirrors other developer‑tool components like Aider and OpenCode; no Docker container needed.
- **CLI‑first**: Users invoke `repomix` (or `npx repomix@latest`) directly from the terminal when they need a packed context file.
- **No GPU requirement**: All heavy work is performed by the LLM; Repomix itself is CPU‑bound.
- **Integration points**: The generated `repomix-output.*` files can be consumed by Claude Code, OpenAI‑compatible back‑ends, or custom scripts that feed context to local LLMs.

## Install method

Installs via **npm** globally (`npm install -g repomix`). If npm is unavailable, the component falls back to using `npx repomix@latest` on demand. This follows upstream instructions and requires no additional system dependencies.

## Files and structure

| File | Purpose |
|------|---------|
| `repomix.sh` | Lifecycle script (install, health, destroy, etc.) |
| `repomix.manifest.json` | Component metadata and config schema |
| `CONTEXT.md` | This file – component context |
| `REFERENCES.md` | Upstream links and documentation |

See [usage.md](./usage.md) for command usage.
