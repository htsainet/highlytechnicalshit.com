# Feature Index

Active feature proposals and development tracking.

| Feature | Priority | Status | File |
|---------|----------|--------|------|
| Tailscale ACL Policy with Escape Hatch | HIGH | Proposed | [FEATURE-000.md](FEATURE-000.md) |
| Docker Isolated Network Mode | LOW | Proposed | [FEATURE-001.md](FEATURE-001.md) |
