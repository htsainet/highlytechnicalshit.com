# Dashboard — Token Extraction and Service Integration

Last updated: 2026-04-11 10:00:00

## What happens here

Extracts OpenClaw auth tokens from the running sandbox and writes them to a JSON
sidecar file for the dashboard. Also patches `controlUi.allowedOrigins` so the
dashboard can embed the OpenClaw UI. Ported from NemoClaw's
`_extract_dashboard_tokens()` and `_fix_sandbox_origins()`.

## Files and structure

| File | Purpose |
|------|---------|
| `tokens.sh` | Extract gateway token, write to `logs/htsclaw-tokens.json` |
| `origins.sh` | Patch `controlUi.allowedOrigins` for dashboard embedding |

## Token sidecar pattern

```json
{
  "sandbox": "hts-ai-openshell-htsclaw-gpu",
  "port": 18792,
  "token": "<extracted-from-sandbox>",
  "updated": "2026-04-11T10:00:00Z"
}
```

Dashboard reads `logs/htsclaw-tokens.json` to authenticate against the
OpenClaw gateway — same pattern as NemoClaw's `nemoclaw-tokens.json`.

## Process

1. Component script calls `tokens.sh` → extracts gateway token from running sandbox
2. `origins.sh` patches CORS origins for dashboard embedding
3. Token sidecar written to `logs/htsclaw-tokens.json`
4. Dashboard reads sidecar on load — no manual token copy needed

## Tools and dependencies

- **jq** — JSON extraction from sandbox API responses
- **curl** — Gateway and sandbox API calls
- Dashboard auto-reads the sidecar file — no additional tools needed

## What good looks like

- Token file created automatically on setup and refresh on upgrade
- Token file has restrictive permissions (600) — not world-readable
- Dashboard card shows htsclaw sandbox at port 18792
- Origins patched so dashboard can iframe the OpenClaw UI without CORS errors
