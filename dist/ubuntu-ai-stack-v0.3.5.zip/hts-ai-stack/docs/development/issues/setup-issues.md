# Setup Issues

Use this file to capture problems that need follow-up while you work through the setup.
This is for actionable defects, missing steps, confusing docs, broken assumptions, and cleanup items.

---

## Issue Template

### ISSUE-000

- Date:
- Area:
- Symptom:
- Reproduction:
- Suspected cause:
- Workaround:
- Fix needed:
- Status: open

---

### ISSUE-024

- Date: 2026-03-30
- Area: 03-setup-models / scripts/install/models/helpers.sh
- Symptom: `03-setup-models.sh` fails immediately with `syntax error near unexpected token ';'` pointing at `scripts/install/models/helpers.sh: line 10`.
- Reproduction:
  1. From repo root, run: `./03-setup-models.sh`
  2. Observe failure: `/scripts/install/models/helpers.sh: line 10: syntax error near unexpected token ';'` and exit code 2.
- Suspected cause: Bash parsing error caused by mismatched quotes in `scripts/install/models/helpers.sh` on the `REPO_ROOT=...` assignment (missing quote after `$(dirname ...)` before appending `/../..`), which can surface as an “unexpected token ';'” parse error.
- Workaround: Manually patch the `REPO_ROOT` line in `scripts/install/models/helpers.sh` to:
  `REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/../.. && pwd)"`
- Fix needed:
  - Correct the quoting in `scripts/install/models/helpers.sh` for the `REPO_ROOT` calculation.
  - Add a CI/pre-commit check to run `bash -n` (or `shellcheck`) on `scripts/install/models/*.sh` and `scripts/install/models/helpers.sh` to prevent future syntax regressions.
- Status: open

### ISSUE-023

- Date: 2026-03-30
- Area: install.sh
- Symptom: Container stable-diffusion-prod Start Failed - Docker volume name includes invalid characters (ANSI color codes)

- Reproduction: run install.sh from v.0.2.0
- Suspected cause: refactoring regression
- Workaround: TBD, possibly related to other suggestions by Claude
- Fix needed: TBD
- Status: open

## Open Issues

### FEATURE-ADD-003

- Date: 2026-03-29
- Area: install
- Symptom:
- Reproduction:
- Suspected cause:
- Workaround:
- Fix needed: add logging
- Status: open

---

### FEATURE-ADD-002

- Date: 2026-03-28
- Area: missing feature
- Symptom: no nim container
- Reproduction: try to run nim
- Suspected cause: not configured
- Workaround: nothing yet
- Fix needed: get nvidia developers key (prompt during setup for nim?)
- Status: open

Steps to Get an NVIDIA API Key

    Visit the NVIDIA API Catalog: Go to build.nvidia.com.
    Select a Model: Choose any AI model you wish to use (e.g., Llama 3, Mixtral).
    Click "Get API Key": Click on the "Get API Key" button in the right-hand pane.
    Sign In/Register: If you don't have an account, you will be prompted to create one, which automatically signs you up for the NVIDIA Developer Program.
    Generate Key: Once signed in, click "Generate API Key".
    Save Key: Copy and securely store your key immediately. It will only be shown once. 

Alternative Method (NGC Registry)
If you need an API key for Docker access or older NVIDIA GPU Cloud (NGC) services:

    Go to ngc.nvidia.com and log in.
    Click on your profile icon in the top right and select Setup.
    Click Generate API Key. 

Important Notes

    Cost: Access to NIM microservices via the NVIDIA API Catalog is free for research, development, and testing.
    Key Security: Do not share your API key, as it provides access to your account's resources. If lost, you must generate a new one, which invalidates the old one.
    Usage: To use the key in your code, set it as an environment variable: export NVIDIA_API_KEY=<your API key>.

### ISSUE-001

- Date: 2026-03-26
- Area: NemoClaw onboarding
- Symptom: Onboard flow appears oriented around local Ollama or hosted NVIDIA API usage, not a custom local NIM endpoint
- Reproduction: Review `04-setup-nemoclaw.sh` prompt guidance and current stack assumptions
- Suspected cause: NemoClaw onboarding likely hardcodes inference backend choices
- Workaround: Use `local-ollama` during onboard and run NIM separately for direct testing
- Fix needed: Verify whether NemoClaw can target a custom OpenAI-compatible local endpoint after onboarding
- Status: partially fixed — NemoClaw supports "Other OpenAI-compatible endpoint" during onboard; docs and script updated to reflect this. Post-onboard inference reconfiguration not supported by CLI.

### ISSUE-018

- Date: 2026-03-30
- Area: docker / GPU
- Symptom: Multiple services compete for RTX 2060 12GB VRAM simultaneously
- Reproduction: Start root compose + prod instance — ollama-prod, stable-diffusion-prod, xtts, and whisper all declare `count: all` GPU reservation; Docker NVIDIA runtime grants access to all without queuing
- Suspected cause: `deploy.resources.reservations.devices.count: all` on every GPU service — correct for single-GPU but no exclusivity enforcement between containers
- Workaround: Profile scripts (mean/lean) stop non-active services before starting others
- Fix needed: Enforce GPU exclusivity in profile startup scripts — ensure only one VRAM-heavy service (Ollama OR Stable Diffusion) is running at a time; add explicit `docker stop` guards before spinning up competing services. Consider `count: 1` + CUDA_VISIBLE_DEVICES where fine-grained control is needed.
- Status: open

---

### ISSUE-019

- Date: 2026-03-30
- Area: docker / GPU
- Symptom: ollama-test holds GPU reservation even when not needed in prod-only mode
- Reproduction: Start prod stack — both ollama-prod and ollama-test declare `count: all`; if ollama-test is left running it competes for VRAM with ollama-prod
- Suspected cause: No CPU-only override for test instance; `06-stop-test-instances.sh` must be run manually
- Workaround: Run `06-stop-test-instances.sh` after stack start in prod mode
- Fix needed: Add a `docker-compose.test-cpu.yml` override that removes GPU reservation for ollama-test, for use when test instance needs to idle without consuming VRAM. Or auto-stop ollama-test at end of `06-start-stack.sh` unless `--test` flag is passed.
- Status: open

---

### ISSUE-020

- Date: 2026-03-30
- Area: docker / stable-diffusion
- Symptom: `--xformers` CLI arg may silently fail if xformers is not present in the SD image
- Reproduction: Start stable-diffusion-prod; check container logs for xformers import errors
- Suspected cause: `siutin/stable-diffusion-webui-docker:cuda-13.2.0-v1.10.1-2026-03-17` uses CUDA 13.2 — xformers wheel availability for this CUDA version is unverified; silent fallback means no error but no speedup
- Workaround: Remove `--xformers` from CLI_ARGS if logs show import errors; `--medvram` alone is sufficient for 12GB
- Fix needed: Verify xformers is present in the image (`docker exec stable-diffusion-prod python -c "import xformers; print(xformers.__version__)"`); remove flag if absent and document finding
- Status: open

---

### ISSUE-021

- Date: 2026-03-30
- Area: docker / VRAM budget
- Symptom: No documented VRAM budget — risk of OOM when loading large models
- Reproduction: Pull mistral-nemo:latest (~7.5GB) while stable-diffusion-prod is running (~4-5GB with --medvram) — total exceeds 12GB
- Suspected cause: No per-service VRAM documentation or runtime guard
- Workaround: Use `qwen2.5:7b-instruct-q4_K_M` (~4.5GB) as prod default when SD is also running; never run mistral-nemo + SD simultaneously
- Fix needed: Document VRAM budget per service in README or 03-setup-models.md; enforce in profile scripts that SD is stopped before loading large Ollama models and vice versa
- Status: open

---

### ISSUE-022

- Date: 2026-03-30
- Area: docker / volumes
- Symptom: Model storage host paths (`~/models/approved`, `~/models/testing`) not explicitly documented as landing on the 990 Pro
- Reproduction: Fresh install — `~` resolves to `/home/<user>` which is under `/` on the 990 Pro with the single-partition layout, so this is fine; but if home were on a separate partition or symlinked it could silently land on the wrong drive
- Suspected cause: Implicit assumption about partition layout
- Workaround: Current single-partition layout on 990 Pro means `~` is correct
- Fix needed: Add a note to `03-setup-models.md` confirming expected model storage path and available space; consider making the base model path a `.env` variable (`MODELS_BASE_DIR`) for portability
- Status: open

---

### FEATURE-ADD-004

- Date: 2026-03-30
- Area: nemoclaw / ollama
- Symptom: `NEMOCLAW_EXPERIMENTAL=1` flag purpose not documented in repo
- Reproduction: See `06-start-stack.sh` — flag is set but its purpose is not explained in comments or docs
- Suspected cause: Missing inline documentation
- Workaround: n/a — flag is working correctly
- Fix needed: Add comment to `06-start-stack.sh` and a note to `04-setup-nemoclaw.md` explaining that `NEMOCLAW_EXPERIMENTAL=1` enables NemoClaw to target a local Ollama instance instead of NVIDIA NIM hosted models. This is the intended production mode for this stack — NIM support tracked separately in FEATURE-ADD-002.
- Status: open

---

## Closed Issues

### ISSUE-003

- Date: 2026-03-26
- Area: Onboarding
- Symptom: Cannot run new shell scripts
- Reproduction:
- Suspected cause: were not marked as executable before git commit
- Workaround:
- Fix needed: chmod +x *.sh
- Status: Fixed - execute permissions added and committed to repo

### ISSUE-004

- Date: 2026-03-26
- Area: QOL
- Symptom: No Remote Desktop Client
- Reproduction:
- Suspected cause: missing package
- Workaround: Install Remmina from App Store
- Fix need-ed: Determine if we can make this part of bootstrap
- Status: Fixed — remmina added to 01-autoinstall.sh step 0

### ISSUE-005

- Date: 2026-03-26
- Area: QOL
- Symptom: No WireGuard Client
- Reproduction:
- Suspected cause: missing package
- Workaround: sudo apt install wireguard
- Fix needed: Determine if we can make this part of bootstrap
- Status: Fixed — wireguard added to 01-autoinstall.sh step 0

### ISSUE-006

- Date: 2026-03-26
- Area: Dashboard
- Symptom: `http://127.0.0.1` returns `403 Forbidden` from nginx
- Reproduction: Start stack and open dashboard on port 80
- Suspected cause: dashboard container had a stale bind mount to an empty host directory (`./dashboard`) instead of `./resources/dashboard`
- Workaround: Recreate the dashboard service
- Fix needed: Ensure dashboard container is recreated when compose bind path changes
- Status: Fixed — recreated `dashboard` with `docker compose up -d --force-recreate dashboard`, mount now points to `resources/dashboard`, and root URL returns 200

### ISSUE-007

- Date: 2026-03-28
- Area: nemoclaw setup
- Symptom: onboarding screen missing a step
- Reproduction: run 04-setup-nemoclaw.sh
- Suspected cause: simple text edit to policy section
- Workaround: ignore the prompts in 04-setup-nemoclaw.sh
- Fix needed: docker,npm,pypi,telegram,huggingface
- Status: fixed manually

### ISSUE-008

- Date: 2026-03-28
- Area: 02-setup-docker
- Symptom: no containers spin up
- Reproduction: docker compose up from root
- Suspected cause: missing variable
- Workaround: manual export WEBUI_SECRET_KEY from .env
- Fix: 06-start-stack.sh now sources .env before docker compose calls; for
  manual runs use: source .env && docker compose … (root) or
  docker compose --env-file ../../.env up (instances/prod)
- Status: fixed 2026-03-29

### ISSUE-009

- Date: 2026-03-28
- Area: prod docker instances
- Symptom: script aborts mid run
- Reproduction: /instances/prod$ docker compose up
- Suspected cause: missing variable
- Workaround: manual export WEBUI_SECRET_KEY from .env
- Fix: 06-start-stack.sh now sources .env before docker compose calls; for
  manual runs use: docker compose --env-file ../../.env up
- Status: fixed 2026-03-29

### ISSUE-016

- Date: 2026-03-28
- Area: ollama test instance
- Symptom: external volume "ollama_test" not found
- Reproduction: model setup script
- Suspected cause: volumes were declared with `external: true` but had never been pre-created
- Workaround: remove external tag from all volumes; /instance/test/docker compose up
- Fix: removed `external: true` from all volume declarations in `instances/test/docker-compose.yml`;
  volumes are now compose-managed and created automatically on first `up`
- Status: fixed 2026-03-29

### ISSUE-002

- Date: 2026-03-26
- Area: Onboarding
- Symptom: Need to manually run 00, 01, 02 several times to finish
- Reproduction:
- Suspected cause: ntp service hangs, nvidia needs reboot, probably more
- Workaround:
- Fix needed: Determine if we can split these scripts into smaller pieces or make them more intelligent
- Status: fixed syntax issues, service name, invoke sudo as needed

### ISSUE-010

- Date: 2026-03-27
- Area: bootstrap
- Symptom: no SSH server
- Reproduction:
- Suspected cause: not installed
- Workaround: sudo apt install openssh-server && sudo systemctl status ssh
- Fix: added `openssh-server` to Step 1 apt install in `00-bootstrap.sh`;
  `systemctl enable --now ssh` runs immediately after install
- Status: fixed 2026-03-29

### ISSUE-015

- Date: 2026-03-28
- Area: bootstrap
- Symptom: curl not found
- Reproduction: try to run 00-bootstrap.sh on bare ubuntu
- Suspected cause: curl not present on minimal Ubuntu install
- Workaround: sudo apt install curl
- Fix: added pre-flight block at top of `00-bootstrap.sh` that installs curl
  via apt if not already present, before any other step runs
- Status: fixed 2026-03-29

### ISSUE-013

- Date: 2026-03-28
- Area: docker prod instances
- Symptom: external volume "sd_outputs_prod" not found
- Reproduction: /instances/prod$ docker compose up
- Suspected cause: volumes declared with `external: true` but never pre-created
- Workaround: skip stable diffusion for now
- Fix: removed `external: true` from all volume declarations in `instances/prod/docker-compose.yml`;
  volumes are now compose-managed and created automatically on first `up`
- Status: fixed 2026-03-29

### ISSUE-014

- Date: 2026-03-28
- Area: bootstrap
- Symptom: browser launches during setup but it doesn't retain token properly
- Reproduction: try to run 00-bootstrap.sh on bare ubuntu
- Suspected cause: logic flow / UX confusion between github.com login and gh CLI OAuth flow
- Workaround: manual auth
- Fix: Step 3 Firefox launch is now gated on `gh auth status`; pre-run checklist
  (ISSUE-017) tells the user upfront that Step 4 requires a browser OAuth sign-in;
  Step 4 `gh auth login --web` skipped if already authenticated
- Status: fixed 2026-03-29

### ISSUE-017

- Date: 2026-03-29
- Area: bootstrap
- Symptom: poor UX on re-runs; no visual branding
- Reproduction: try to run 00-bootstrap.sh
- Suspected cause: missing communication; no idempotency guards
- Workaround:
- Fix: added HTS AI ASCII art banner; pre-run checklist showing [x]/[ ] status
  for each of the 8 steps; Firefox login launch now skipped if GitHub is already
  authenticated (idempotency guard for Step 3)
- Status: fixed 2026-03-29

### ISSUE-012

- Date: 2026-03-28
- Area: 03-setup-models
- Symptom: "network hts-ai-stack_ai-network declared as external, but could not be found"
- Reproduction: run 03-setup-models.sh
- Suspected cause: network created by root compose but instance compose files use
  `external: true` — network absent if root stack never ran
- Workaround: don't pull test models until fixed
- Fix: added `ensure_ai_network` helper in `scripts/install/models/helpers.sh`; called
  at startup of both `prod.sh` and `test.sh` — creates `hts-ai-stack_ai-network`
  if it doesn't exist before any `docker compose up`
- Status: fixed 2026-03-29
