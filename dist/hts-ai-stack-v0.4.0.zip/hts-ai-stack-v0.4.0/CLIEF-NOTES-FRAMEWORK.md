# Clief Notes Framework (Jake Van Clief / Quantum Quill Lyceum)

## Overview

Framework adopted from Jake Van Clief's folder-structure approach, adapted for reproducible AI stack installation with Pester validation workflow.

**Source:** <https://www.skool.com/quantum-quill-lyceum-1116/about>

## Three-Layer Architecture

### Layer 1: The Map (CLAUDE.md)

**Purpose:** Single file at project root providing identity, rules, and routing table

**Must contain:**

- Identity section: who you are, what you're building
- Rules section: technical constraints, must-haves
- Routing table: task type → specific folder and CONTEXT.md file
- Quick nav: what file to read for each type of work

**Constraints:**

- Under 50 lines (forces clarity, prevents bloat)
- No personality instructions ("be creative", "think step", etc.)
- No extensive folder diagrams (< 2 code blocks)
- Visible routing table on one screen

**Structure:**

```markdown
# Identity
[Project identity]

## Rules
- [Constraint 1]
- [Constraint 2]

## Context & References Quick-Nav
| Task | Go to | Read |
|------|-------|------|
| [Task type] | `/folder` | `filename` |
```

### Layer 2: The Rooms (Workspace CONTEXT.md Files)

**Purpose:** Each workspace/folder has its own CONTEXT.md describing what happens there

**Must contain (standard sections):**

1. **# Title** (h1) — clear description of workspace
2. **Last updated:** timestamp (YYYY-MM-DD HH:MM:SS format)
3. **What happens here / Purpose** — what work occurs in this space
4. **Process / Workflow** — how work flows through (discovery → implementation → validation)
5. **Files and structure** — what files live here and how organized
6. **What good looks like** — success criteria, standards, what to avoid
7. **Tools and skills** — external tools, dependencies, extensions needed

**Compliance rules:**

- Exist (all 4 key workspaces minimum: root, /docs, /scripts, /tests)
- Substantive (> 50 chars content, not empty stubs)
- Work-focused (not personality-driven)
- Recent timestamps (within 90 days of current date)
- Use consistent h1 title + h2 section headers
- Have markdown links to existing files only
- Not oversized (< 200 lines typically)

**Example pattern:**

```markdown
# Installation Scripts

Last updated: 2026-03-31 19:08:47

## What happens here
[Clear description]

## Process / Workflow
[Step-by-step workflow]

## Files and structure
[Table or list of files]

## What good looks like
- [Success criteria]
- [Standards]

## Tools and skills
- **Tool Name** — Description
```

### Layer 3: Tools (Tests and Validation)

**Purpose:** Pester tests validate Layer 1 and Layer 2 stay synchronized

**What tests validate:**

- Layer 1 (CLAUDE.md): concise, has routing table, points to real places
- Layer 2 (CONTEXT.md files): consistent structure, current, documented, substantive
- REFERENCES.md: provides architecture/tools, not hardware inventory
- Workspace structure: logical (not flat), key directories exist
- Links: markdown references point to existing files
- Naming: Verb-Noun.Tests.ps1 files follow PowerShell approved verbs
- Routing: all workspaces routed or nested under routed parent
- Timestamps: all last-updated markers recent (< 90 days)

**Test counts:** 38 validations in Test-FrameworkStructure.Tests.ps1

## CONTEXT.md Compliance Checklist

**Required Elements:**

- [ ] File exists in workspace
- [ ] Markdown h1 title (# Title)
- [ ] "Last updated: YYYY-MM-DD HH:MM:SS" marker
- [ ] Purpose/What happens here section
- [ ] Process/Workflow section
- [ ] Files and structure (table or list)
- [ ] What good looks like section (standards/criteria)
- [ ] Tools and skills section (or explicitly state "None")
- [ ] Consistent h2 section headers
- [ ] All links point to existing files

**Content Rules:**

- Work-focused, not personality-driven
- Short and focused (< 200 lines typically)
- Navigable for Claude: clear sections, standard structure
- Links use relative paths or /repo-root paths
- Standards are specific (not vague like "be creative")

## REFERENCES.md Compliance Checklist

**Purpose:** Document architecture, services, external resources — not hardware inventory

**Should contain:**

- External links (services, repos, papers)
- Folder architecture diagrams
- Tool documentation references
- Framework/source attribution

**Should NOT contain:**

- Hardware specifications ("12 GB RTX3060", "32GB RAM")
- Personality instructions
- Redundant workflow (goes in CONTEXT.md)
- Specific implementation details (those go in CONTEXT.md)

**Pattern:** Sits next to CONTEXT.md at same level, provides deeper reference material

## Naming Conventions

**Test files:** `Verb-Noun.Tests.ps1` format with PowerShell-approved verbs

- Examples: `Test-FrameworkStructure.Tests.ps1`, `Test-ModelCache.Tests.ps1`

**Feature tracking:** `FEATURE-###.md` pattern with tracking table in REFERENCES.md

- Example: FEATURE-000.md, FEATURE-001.md

**Security feature tracking:** `SECURITY-###.md` pattern in `docs/security-review/features/`
with tracking table in that folder's REFERENCES.md — same metadata as `FEATURE-###.md` plus
a required **Threat** field mapping to the threat model in `docs/security-review/CONTEXT.md`

**Security repo reviews:** `owner-reponame.md` in results/ folders

**Planning artifacts:** `session*-report.md`, `repo-review-batch*.md`

## Maintenance Workflow

**Create new workspace:**

1. Create folder (e.g., `/docs/guides`)
2. Create `CONTEXT.md` with Purpose, Process, Structure, Standards, Tools
3. Add routing entry to CLAUDE.md
4. Run tests to verify wiring

**Update CONTEXT.md:**

1. Edit content
2. Timestamp auto-updates via `scripts/utils/Update-ContextTimestamps.ps1`
3. Git commit includes updated timestamp

**Update `docs/planning/ACTIVE.md`:**

`ACTIVE.md` is a hand-maintained companion to CLAUDE.md's Quick-Nav. It
signals *what is currently in flight* (branch, active plans, recent
landings) so cold-start AI sessions route to the current gradient rather
than inferring from the steady-state map. Update it at these moments:

1. A plan doc lands under `docs/planning/` → add it to **Active plans**.
2. A plan completes / merges → move it to **Archived** (or delete).
3. A notable commit lands → add a row to **Recent landings**; drop
   entries older than ~7 days to keep the list scannable.
4. Bump the **Last updated** date whenever you edit.

Keep it short — if you're about to paste a commit body, point at the SHA
instead. `git log` is still the source of truth for history; ACTIVE.md
is just the headline.

**Run validation:**

```bash
# Changed files only
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1

# Staged files only
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1 -Staged

# Full repo
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1 -All
```
