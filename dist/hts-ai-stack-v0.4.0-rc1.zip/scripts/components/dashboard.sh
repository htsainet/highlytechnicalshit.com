#!/usr/bin/env bash
# scripts/components/dashboard.sh — Dashboard (nginx): install, configure, start
#
# Standalone usage:
#   ./scripts/components/dashboard.sh            # install + configure + start + health
#   ./scripts/components/dashboard.sh --health   # health check only
#   ./scripts/components/dashboard.sh --stop     # stop dashboard
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
DASHBOARD_PORT="${DASHBOARD_PORT:-80}"
DASHBOARD_CONTAINER="${DASHBOARD_CONTAINER:-hts-ai-dashboard}"

# ── Functions ────────────────────────────────────────────────────────────────

# dashboard_install — Ensure dashboard resources exist
dashboard_install() {
  step "Dashboard — install"
  local html_dir="$REPO_DIR/resources/dashboard"
  local nginx_dir="$REPO_DIR/resources/nginx"

  if [[ ! -f "$html_dir/index.html" ]]; then
    fail "Dashboard index.html not found at $html_dir/index.html"
    return 1
  fi

  info "Dashboard resources verified: index.html"
  [[ -f "$html_dir/nemoclaw-links.json" ]] && info "  nemoclaw-links.json present"
  [[ -f "$nginx_dir/robots.txt" ]]         && info "  robots.txt present"
  [[ -f "$nginx_dir/robots.conf" ]]        && info "  robots.conf present"

  compose_pull --profile dashboard
  ok "Dashboard image pulled."
}

# dashboard_configure — Verify .env keys for dashboard
dashboard_configure() {
  step "Dashboard — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^DASHBOARD_ENABLED=" "$env_file" 2>/dev/null; then
    printf 'DASHBOARD_ENABLED=true\n' >> "$env_file"
    info "Added DASHBOARD_ENABLED=true to .env"
  fi

  ok "Dashboard configured."
}

# dashboard_start — Bring up dashboard via compose
dashboard_start() {
  step "Dashboard — start"
  compose_up --profile dashboard
  ok "Dashboard started on port ${DASHBOARD_PORT}."
}

# dashboard_stop — Bring down dashboard
dashboard_stop() {
  step "Dashboard — stop"
  compose_down --profile dashboard
  ok "Dashboard stopped."
}

# dashboard_health — Probe the dashboard HTTP endpoint
dashboard_health() {
  health_probe "Dashboard :${DASHBOARD_PORT}" "http://localhost:${DASHBOARD_PORT}/"
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      dashboard_install
      dashboard_configure
      dashboard_start
      dashboard_health
      ;;
    health)
      dashboard_health
      ;;
    stop)
      dashboard_stop
      ;;
  esac
fi
