#!/usr/bin/env bash
# peek-nemoclaw-volume-backups.sh — Extract NemoClaw/OpenShell version metadata
# from the openshell-cluster-nemoclaw_*.tar.gz docker-volume backups on the NAS.
#
# Context:
#   survey-nas-backups.sh showed 5 nemoclaw volume tarballs under
#   /mnt/htsai-docker-volume-backup/volumes/, dated 2026-04-17 and 2026-04-19.
#   The volume (openshell-cluster-nemoclaw) holds k3s + sandbox state,
#   including blueprint.yaml and the installed nemoclaw/openshell package.json.
#
# What this script does (read-only, no extraction to disk):
#   For each tarball:
#     1. `tar tzf` to list paths of interest.
#     2. `tar xzOf` to stream those files to stdout and grep version fields.
#
#   Files of interest:
#     • blueprint.yaml          — pins both openshell + nemoclaw versions
#     • package.json            — in any nemoclaw/ or openshell/ path
#     • VERSION / version       — occasional plaintext version files
#     • *.manifest.json         — kubernetes/k3s manifests that may name image tags
#
# Usage:
#   sudo ./scripts/utils/peek-nemoclaw-volume-backups.sh
#
# Output:
#   One section per tarball, oldest first, with the version fields found.

set -euo pipefail

BACKUP_DIR="/mnt/htsai-docker-volume-backup/volumes"

step() { echo; echo "════ $* ════"; }
info() { echo "    $*"; }
warn() { echo "[WARN] $*" >&2; }

[[ $EUID -eq 0 ]] || { echo "Re-run with: sudo $0" >&2; exit 1; }
[[ -d "$BACKUP_DIR" ]] || { echo "Not found: $BACKUP_DIR" >&2; exit 1; }

# Collect tarballs, sorted by filename (timestamp is embedded — sort = chronological)
mapfile -t TARBALLS < <(find "$BACKUP_DIR" -maxdepth 1 -type f \
  -name 'openshell-cluster-nemoclaw_*.tar.gz' 2>/dev/null | sort)

[[ ${#TARBALLS[@]} -gt 0 ]] || { warn "No nemoclaw tarballs found in $BACKUP_DIR"; exit 1; }

info "Found ${#TARBALLS[@]} tarball(s)."

peek_file() {
  # $1 = tarball, $2 = path inside tarball
  # Streams the file and prints version-ish fields.
  local tb="$1" path="$2"
  tar xzOf "$tb" "$path" 2>/dev/null \
    | grep -E '"(name|version|gitHead|_from|_resolved|_integrity)"|^(version|image|tag):|openshell|nemoclaw' \
    | head -20 \
    | sed 's/^/          /'
}

for tb in "${TARBALLS[@]}"; do
  step "$(basename "$tb")"
  info "size: $(du -sh "$tb" | awk '{print $1}')"

  # List interesting entries
  mapfile -t HITS < <(
    tar tzf "$tb" 2>/dev/null \
      | grep -E '(^|/)(blueprint\.yaml|package\.json|VERSION|version)$|/nemoclaw/|/openshell/' \
      | grep -vE '/node_modules/.*/node_modules/' \
      || true
  )

  if [[ ${#HITS[@]} -eq 0 ]]; then
    warn "No candidate files inside tarball."
    continue
  fi

  # Prioritise blueprint.yaml + package.json for nemoclaw/openshell at sensible depths.
  # Print blueprints first, then package.jsons.
  echo
  info "── blueprint.yaml ──"
  for h in "${HITS[@]}"; do
    [[ "$h" == *blueprint.yaml ]] || continue
    echo "      $h"
    peek_file "$tb" "$h"
  done

  echo
  info "── package.json (nemoclaw / openshell) ──"
  for h in "${HITS[@]}"; do
    [[ "$h" == */package.json ]] || continue
    [[ "$h" == */nemoclaw/* || "$h" == */openshell/* ]] || continue
    echo "      $h"
    peek_file "$tb" "$h"
  done

  echo
  info "── other candidate paths (first 15) ──"
  printf '      %s\n' "${HITS[@]}" | head -15
done

echo
echo "Done. Look at the chronology:"
echo "  • 2026-04-17 tarballs = pre-04-19 refactor baseline"
echo "  • 2026-04-19 tarballs = after refactor"
echo
echo "If the 04-17 version installs cleanly and 04-19 doesn't, it's our code."
echo "If both install, upstream drift is the variable."
echo "Pin whichever gitHead/version works in:"
echo "  scripts/components/nemoclaw/nemoclaw.manifest.json  → .upstream.pinned_version"
echo "  scripts/components/nemoclaw/nemoclaw.sh             → NEMOCLAW_INSTALL_TAG"
echo "  (and OPENSHELL_VERSION in nemoclaw.sh if openshell version differs)"
