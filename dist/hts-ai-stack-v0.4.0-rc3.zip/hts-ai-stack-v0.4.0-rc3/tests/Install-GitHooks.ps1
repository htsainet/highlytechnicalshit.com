$ErrorActionPreference = 'Stop'

$repoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
Set-Location $repoRoot

git config core.hooksPath .githooks
Write-Host 'Git hooks configured to use .githooks/'