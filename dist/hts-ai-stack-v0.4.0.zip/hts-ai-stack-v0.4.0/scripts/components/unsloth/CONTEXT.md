# Unsloth Component

Last updated: 2026-04-15

## What happens here

Unsloth provides fast LLM fine-tuning with significantly reduced memory
usage. Used in the stack as a training studio for creating custom model
adapters (LoRA/QLoRA) on local hardware with GPU acceleration.

## Files and structure

| File | Purpose |
|------|---------|
| `unsloth.sh` | Full lifecycle: install, configure, start, stop, health |
| `unsloth.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

See [usage.md](./usage.md) for command usage.
