#!/usr/bin/env bash
# clean-for-commit.sh — remove runtime artifacts, logs, and session data
# so nothing accidental ends up in a commit.
#
# Usage:
#   clean-for-commit.sh             # dry run
#   clean-for-commit.sh --yes       # actually remove
#   clean-for-commit.sh --yes --quiet

set -euo pipefail

repo_root="$(git rev-parse --show-toplevel)"
cd "$repo_root"

YES=0
QUIET=0
for arg in "$@"; do
  case "$arg" in
    --yes|-y)   YES=1 ;;
    --quiet|-q) QUIET=1 ;;
    -h|--help)  sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "unknown arg: $arg" >&2; exit 2 ;;
  esac
done

targets=(
  "data"
  "logs/"*.log
  "scripts/logs/"*.log
  ".logs/"*.log
  "config/backups/"*/
  "resources/dashboard/nemoclaw-tokens.json"
  "resources/dashboard/htsclaw-tokens.json"
  "resources/dashboard/openwebui-token.json"
  "resources/dashboard/install-status.json"
  "resources/dashboard/roadmap.json"
  "resources/dashboard/upstream-issues.json"
  "resources/dashboard/services.json.tmp"
  "instances/prod/docker-compose.yml"
  "instances/prod/models.sh"
  "instances/test/docker-compose.yml"
  "instances/test/models.sh"
  ".last-applied.json"
)

say() { (( QUIET )) || echo "$@"; }

matched=()
for t in "${targets[@]}"; do
  [[ -e "$t" ]] && matched+=("$t")
done

while IFS= read -r d; do matched+=("$d"); done < <(find . -type d -name __pycache__ 2>/dev/null)

if [[ ${#matched[@]} -eq 0 ]]; then
  say "clean-for-commit: nothing to remove"
  exit 0
fi

say "clean-for-commit: ${#matched[@]} target(s):"
for m in "${matched[@]}"; do say "  - $m"; done

if (( ! YES )); then
  say
  say "Dry run — pass --yes to actually remove."
  exit 0
fi

for m in "${matched[@]}"; do
  rm -rf -- "$m"
done
# logs/upstream-watch.log is preserved (glob above only matches *.log, not specific file)
say "clean-for-commit: removed ${#matched[@]} item(s)"
