# Superpowers Component — CONTEXT

## What is Superpowers?

Superpowers is an **agentic skills framework** and **software‑development methodology** that coordinates multiple coding agents, enforces design‑review loops, and drives test‑driven development. It ships as a **host‑installed CLI** (via npm) and provides a set of composable skills that can be invoked from any developer‑tool agent (Aider, OpenCode, Claude Code, etc.).

## How it fits into the HTS AI Stack

- **Host‑installed** – like Aider and OpenCode, no Docker container needed.
- **CLI‑first** – users run `superpowers` or `npx superpowers@latest` to start a workflow. The tool can generate a packed repo context (via Repomix) and then orchestrate sub‑agents for design, planning, implementation, testing, and review.
- **No GPU requirement** – the heavy lifting is done by the LLM backend (llama‑swap / Ollama). Superpowers merely coordinates agents and runs local commands.
- **Integration points** – can be called from other host tools as part of a larger workflow (e.g. `aider` → `superpowers` → `repomix`).

## Install method

Installs via **npm** globally (`npm install -g superpowers`). If npm is unavailable, the component falls back to using `npx superpowers@latest` on demand. This mirrors the upstream instructions and needs no additional system packages.

## Files and structure

| File | Purpose |
|------|---------|
| `superpowers.sh` | Lifecycle script (install, configure, health, destroy) |
| `superpowers.manifest.json` | Component metadata and config schema |
| `CONTEXT.md` | This file – component context |
| `REFERENCES.md` | Upstream links and documentation |

See [usage.md](./usage.md) for command usage.
