# DeerFlow Component

Last updated: 2026-04-15

## What happens here

DeerFlow (Deep Research Flow) is an automated deep-research agent that
performs multi-step web research, synthesis, and report generation.
Used in the stack as an AI-powered research assistant.

## Files and structure

| File | Purpose |
|------|---------|
| `deerflow.sh` | Full lifecycle: install, configure, start, stop, health |
| `deerflow.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
