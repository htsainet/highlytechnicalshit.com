$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/htsclaw'
    $script:ComponentScript = Join-Path $script:ComponentDir 'htsclaw.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'htsclaw.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'htsclaw file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'htsclaw manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is htsclaw' {
        $script:Manifest.id | Should -Be 'htsclaw'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/htsclaw/htsclaw.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is htsclaw' {
        $script:Manifest.func_prefix | Should -Be 'htsclaw'
    }

    It 'dashboard port is 18790' {
        [int]$script:Manifest.dashboard.port | Should -Be 18790
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'htsclaw component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines htsclaw_install function' {
        $script:ComponentContent | Should -Match 'htsclaw_install\s*\(\)'
    }

    It 'defines htsclaw_configure function' {
        $script:ComponentContent | Should -Match 'htsclaw_configure\s*\(\)'
    }

    It 'defines htsclaw_start function' {
        $script:ComponentContent | Should -Match 'htsclaw_start\s*\(\)'
    }

    It 'defines htsclaw_stop function' {
        $script:ComponentContent | Should -Match 'htsclaw_stop\s*\(\)'
    }

    It 'supports --configure, --start, --health, and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--configure\)'
        $script:ComponentContent | Should -Match '--start\)'
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/htsclaw/htsclaw\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'htsclaw port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 18790 is registered in portmap.json' {
        $entries = $script:Portmap.ports.PSObject.Properties |
            Where-Object { $_.Value.service -eq 'htsclaw' }
        $matchedPorts = $entries | ForEach-Object { [int]$_.Name }
        $matchedPorts | Should -Contain 18790
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'htsclaw no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/htsclaw\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/htsclaw/htsclaw\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
