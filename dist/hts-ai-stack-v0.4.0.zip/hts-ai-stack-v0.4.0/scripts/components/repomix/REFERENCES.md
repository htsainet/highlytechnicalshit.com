# Repomix References

- Repository: https://github.com/yamadashy/repomix
- Official website / docs: https://repomix.com
- Installation guide (quick start): https://github.com/yamadashy/repomix#quick-start
