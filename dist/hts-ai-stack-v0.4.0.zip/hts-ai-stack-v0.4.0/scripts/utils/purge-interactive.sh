#!/usr/bin/env bash
# scripts/utils/purge-interactive.sh — Interactive wrapper for purge-chat-logs.sh
# Prompts the user for each purge category and runs the low-level script with the selected flags.

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PURGE_SCRIPT="$SCRIPT_DIR/purge-chat-logs.sh"

prompt() {
  local msg="$1"
  read -r -p "$msg [y/N] " resp
  resp="${resp:-N}"
  [[ "$resp" =~ ^[Yy]$ ]]
}

flags=()

if prompt "Delete Ollama data (models and cache)"; then
  flags+=("--ollama")
fi
if prompt "Delete Stable Diffusion model files"; then
  flags+=("--sd-models")
fi
if prompt "Delete Stable Diffusion generated output images"; then
  flags+=("--sd-outputs")
fi
if prompt "Delete Open-LLM-VTuber persistent data (including chat logs)"; then
  flags+=("--vtuber")
fi
if prompt "Delete ComfyUI bind-mounted data directory"; then
  flags+=("--comfyui")
fi
if prompt "Delete Faster-Whisper cache"; then
  flags+=("--faster-whisper")
fi
if prompt "Delete Coqui-TTS cache"; then
  flags+=("--coqui-tts")
fi
if prompt "Delete Bark TTS cache"; then
  flags+=("--bark")
fi
if prompt "Purge log files in logs/ (excluding upstream-watch.log)"; then
  flags+=("--logs")
fi

if [[ ${#flags[@]} -eq 0 ]]; then
  echo "No components selected – exiting without any purge."
  exit 0
fi

bash "$PURGE_SCRIPT" "${flags[@]}"