# Signal Component

Last updated: 2026-04-15

## What happens here

Signal CLI provides command-line access to the Signal messaging protocol.
Used in the stack as a notification channel — AI agents can send alerts
and summaries via Signal messages.

## Files and structure

| File | Purpose |
|------|---------|
| `signal.sh` | Full lifecycle: install, configure, start, stop, health |
| `signal.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
