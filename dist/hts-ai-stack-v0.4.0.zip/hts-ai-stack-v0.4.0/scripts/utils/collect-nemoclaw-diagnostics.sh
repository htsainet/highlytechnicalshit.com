#!/usr/bin/env bash
# scripts/utils/collect-nemoclaw-diagnostics.sh
# Collects diagnostics for OpenShell / NemoClaw sandbox provisioning failures.
# Usage:
#   sudo ./scripts/utils/collect-nemoclaw-diagnostics.sh        # recommended (captures journalctl, k3s)
#   ./scripts/utils/collect-nemoclaw-diagnostics.sh --outdir /tmp/mine --no-sudo

set -euo pipefail

OUTDIR="/tmp/htsai-diagnostics-$(date +%Y%m%d-%H%M%S)"
CMD_TIMEOUT=${CMD_TIMEOUT:-30}
USE_SUDO=1
ARCHIVE=0
PULL_OLLAMA=0

usage(){
  cat <<EOF
Usage: $0 [options]

Options:
  -o, --outdir DIR     Output directory (default: $OUTDIR)
      --no-sudo        Do not use sudo; run only non-root commands
  -a, --archive        Create a tar.gz of the results at the end
      --pull-ollama    Attempt to run scripts/components/ollama/ollama.sh --pull-models (may require docker)
  -h, --help           Show this help

Example:
  sudo $0 --outdir /tmp/diag --archive --pull-ollama
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -o|--outdir) OUTDIR="$2"; shift 2 ;;
    --no-sudo) USE_SUDO=0; shift ;;
    -a|--archive) ARCHIVE=1; shift ;;
    --pull-ollama) PULL_OLLAMA=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown arg: $1"; usage; exit 1 ;;
  esac
done

mkdir -p "$OUTDIR"
chmod 700 "$OUTDIR"

TIMEFILE="$OUTDIR/collected_at.txt"
date --iso-8601=seconds > "$TIMEFILE" 2>/dev/null || date > "$TIMEFILE"

echo "HTSAI diagnostics collection starting: $(cat "$TIMEFILE")"
echo "Writing files to: $OUTDIR"

# Check for timeout
if command -v timeout >/dev/null 2>&1; then
  TIMEOUT_CMD="timeout ${CMD_TIMEOUT}s"
else
  TIMEOUT_CMD=""
fi

run_cmd(){
  # run_cmd <name> <command-string>
  local name="$1"; shift
  local cmd="$*"
  local outfile="$OUTDIR/${name}.txt"
  printf "### Running: %s\n### Timestamp: %s\n\n" "$cmd" "$(date --iso-8601=seconds 2>/dev/null || date)" > "$outfile"

  if [[ "$USE_SUDO" -eq 1 && "$EUID" -ne 0 ]]; then
    if command -v sudo >/dev/null 2>&1; then
      # Redirect is intentionally outside sudo — $OUTDIR is owned by the
      # invoking user; we only need sudo for the *read* side (root-only paths).
      if [[ -n "$TIMEOUT_CMD" ]]; then
        # shellcheck disable=SC2024
        sudo bash -lc "$TIMEOUT_CMD $cmd" >>"$outfile" 2>&1 || echo "(command exited non-zero)" >>"$outfile"
      else
        # shellcheck disable=SC2024
        sudo bash -lc "$cmd" >>"$outfile" 2>&1 || echo "(command exited non-zero)" >>"$outfile"
      fi
    else
      # no sudo binary available — run as-is
      if [[ -n "$TIMEOUT_CMD" ]]; then
        bash -lc "$TIMEOUT_CMD $cmd" >>"$outfile" 2>&1 || echo "(command exited non-zero)" >>"$outfile"
      else
        bash -lc "$cmd" >>"$outfile" 2>&1 || echo "(command exited non-zero)" >>"$outfile"
      fi
    fi
  else
    # either running as root or not using sudo
    if [[ -n "$TIMEOUT_CMD" ]]; then
      bash -lc "$TIMEOUT_CMD $cmd" >>"$outfile" 2>&1 || echo "(command exited non-zero)" >>"$outfile"
    else
      bash -lc "$cmd" >>"$outfile" 2>&1 || echo "(command exited non-zero)" >>"$outfile"
    fi
  fi
}

# Basic environment
run_cmd "date" "date --iso-8601=seconds || date"
run_cmd "uname" "uname -a"
run_cmd "os_release" "cat /etc/os-release || true"
run_cmd "lsb_release" "lsb_release -a || true"
run_cmd "whoami" "whoami"

# Docker / compose
run_cmd "which_docker" "command -v docker || true"
run_cmd "docker_version" "docker --version || true"
run_cmd "docker_info" "docker info || true"
run_cmd "docker_ps" "docker ps -a --format 'table {{.Names}}\t{{.Status}}\t{{.Image}}' || true"
run_cmd "docker_compose_version" "docker compose version || docker-compose version || true"

# Ollama API
run_cmd "ollama_api_tags" "curl -sS --connect-timeout 5 http://127.0.0.1:11434/api/tags || true"

# Detect k3s / kubectl
run_cmd "which_k3s" "command -v k3s || true"
run_cmd "which_kubectl" "command -v kubectl || true"
run_cmd "which_microk8s" "command -v microk8s.kubectl || true"

# Determine kubectl command to use (no sudo prefix here; run_cmd will add sudo if needed)
KC=""
if command -v k3s >/dev/null 2>&1; then
  KC="k3s kubectl"
elif command -v kubectl >/dev/null 2>&1; then
  KC="kubectl"
elif command -v microk8s.kubectl >/dev/null 2>&1; then
  KC="microk8s.kubectl"
else
  # try via sudo (will prompt if necessary)
  if [[ "$USE_SUDO" -eq 1 ]] && command -v sudo >/dev/null 2>&1; then
    if sudo command -v k3s >/dev/null 2>&1; then KC="k3s kubectl"; fi
    if [[ -z "$KC" ]] && sudo command -v kubectl >/dev/null 2>&1; then KC="kubectl"; fi
    if [[ -z "$KC" ]] && sudo command -v microk8s.kubectl >/dev/null 2>&1; then KC="microk8s.kubectl"; fi
  fi
fi

echo "kubectl_cmd=${KC}" > "$OUTDIR/kubectl_detection.txt"

if [[ -n "$KC" ]]; then
  run_cmd "k8s_nodes" "$KC get nodes -o wide || true"
  run_cmd "k8s_pods_all" "$KC get pods -A -o wide || true"
  run_cmd "k8s_pods_openshell" "$KC get pods -n openshell -o wide || true"
  run_cmd "k8s_describe_openshell" "$KC describe pod openshell-0 -n openshell || true"
  run_cmd "k8s_logs_openshell" "$KC logs -n openshell openshell-0 --all-containers --tail=1000 || true"
  run_cmd "k8s_events_openshell" "$KC get events -n openshell --sort-by=.metadata.creationTimestamp | tail -n 200 || true"
  run_cmd "k8s_pvc_openshell" "$KC get pvc -n openshell -o wide || true"
  run_cmd "k8s_pv" "$KC get pv -o wide || true"
  run_cmd "k8s_nonrunning_pods" "$KC get pods -A --field-selector=status.phase!=Running -o wide || true"
fi

# Inspect common k3s storage paths and kubelet pods
run_cmd "k3s_storage_list" "ls -la /var/lib/rancher/k3s/storage || true"
run_cmd "kubelet_pods_list" "ls -la /var/lib/kubelet/pods || true"

# If we find the PVC path pattern, capture logs inside it (best-effort)
if sudo -n true 2>/dev/null || [[ "$EUID" -eq 0 ]]; then
  for d in /var/lib/rancher/k3s/storage/pvc-* /var/lib/rancher/k3s/storage/pvc-adbf6dbd-*; do
    if [[ -d "$d" ]]; then
      safe_name=$(basename "$d")
      echo "Collecting logs under $d -> $OUTDIR/storage_${safe_name}.txt"
      # shellcheck disable=SC2024
      sudo find "$d" -maxdepth 3 -type f -iname '*.log' -print -exec sudo tail -n 200 {} \; > "$OUTDIR/storage_${safe_name}.txt" 2>&1 || true
    fi
  done
fi

# journalctl checks (k3s, kubelet, containerd/docker)
if [[ "$USE_SUDO" -eq 1 ]]; then
  run_cmd "journal_k3s" "journalctl -u k3s -n 500 --no-pager || true"
  run_cmd "journal_kubelet" "journalctl -u kubelet -n 200 --no-pager || true"
  run_cmd "journal_containerd" "journalctl -u containerd -n 200 --no-pager || journalctl -u docker -n 200 --no-pager || true"
else
  echo "Skipping journalctl entries (run with --no-sudo to change this behavior)" > "$OUTDIR/journal_skipped.txt"
fi

# Grep syslog for provisioning related messages
if [[ -f /var/log/syslog ]]; then
  run_cmd "syslog_openshell_grep" "egrep -i 'openshell|nemoclaw|Start command failed|Provision' /var/log/syslog || true"
else
  echo "/var/log/syslog not present" > "$OUTDIR/syslog_missing.txt"
fi

# Docker-compose / repo compose helper outputs
run_cmd "repo_docker_compose_config_images" "bash -lc 'if [ -f docker-compose.yml ]; then docker compose -f docker-compose.yml config --images 2>/dev/null || true; fi'"
run_cmd "repo_docker_compose_ps" "bash -lc 'if [ -f docker-compose.yml ]; then docker compose -f docker-compose.yml ps || true; fi'"

# Optional: attempt to pull Ollama models using the repo script
if [[ "$PULL_OLLAMA" -eq 1 ]]; then
  echo "Attempting to run scripts/components/ollama/ollama.sh --pull-models (may require docker & jq)" > "$OUTDIR/ollama_attempt.txt"
  if [[ -f scripts/components/ollama/ollama.sh ]]; then
    run_cmd "ollama_pull_attempt" "bash scripts/components/ollama/ollama.sh --pull-models || true"
  else
    echo "ollama script not found in repo" >> "$OUTDIR/ollama_attempt.txt"
  fi
fi

# Summarize key findings into a short file
{
  echo "Summary generated at: $(date --iso-8601=seconds 2>/dev/null || date)"
  echo
  echo "kubectl detection:"
  cat "$OUTDIR/kubectl_detection.txt" 2>/dev/null || true
  echo
  echo "openshell pods (snippet):"
  head -n 200 "$OUTDIR/k8s_pods_openshell.txt" 2>/dev/null || true
  echo
  echo "k8s describe (tail):"
  tail -n 200 "$OUTDIR/k8s_describe_openshell.txt" 2>/dev/null || true
  echo
  echo "Last lines of openshell logs (tail):"
  tail -n 200 "$OUTDIR/k8s_logs_openshell.txt" 2>/dev/null || true
} > "$OUTDIR/summary.txt"

# Create tarball if requested
if [[ "$ARCHIVE" -eq 1 ]]; then
  TARPATH="${OUTDIR}.tar.gz"
  echo "Creating archive: $TARPATH"
  tar -czf "$TARPATH" -C "$(dirname "$OUTDIR")" "$(basename "$OUTDIR")" || echo "(tar failed)"
  echo "Archive written to: $TARPATH"
fi

echo "Diagnostics collection complete. Files written to: $OUTDIR"
if [[ "$ARCHIVE" -eq 1 ]]; then echo "Tarball: $TARPATH"; fi

cat <<EOF
Next steps:
 - Inspect $OUTDIR/summary.txt for a quick view.
 - If you want me to parse the results, paste the summary.txt and any failing logs here.
 - To include more logs, re-run with --pull-ollama or run the script as root.
EOF
