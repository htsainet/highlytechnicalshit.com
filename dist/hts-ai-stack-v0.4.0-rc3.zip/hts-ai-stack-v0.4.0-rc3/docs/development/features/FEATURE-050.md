# FEATURE-050 — Lean-Ctx AI Context Runtime

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | LOW |
| **Effort** | < 15 minutes |
| **Risk** | Low — single binary, no infrastructure changes |
| **Target Release** | v0.5.0 |
| **Depends on** | Nothing |
| **Blocks** | Nothing |

## Problem

AI coding tools (Claude Code, Copilot, Cursor) consume large amounts of tokens by re-reading files, re-running shell commands, and reprocessing context that hasn't changed. This increases cost and latency.

## Solution

Install [lean-ctx](https://github.com/yvgude/lean-ctx) — a context runtime and MCP server that reduces token consumption by up to 99% through file caching, shell output compression, and context deduplication.

### Implementation (complete)

Added install step in `scripts/host/tools.sh` (dev-tools section):

- Tries `cargo install lean-ctx` first (native Rust binary)
- Falls back to `npx lean-ctx-bin` if cargo unavailable
- Idempotent: checks for existing binary before install

### Features

- **42 intelligent tools** via MCP — `ctx_read`, `ctx_write`, `ctx_search`, etc.
- **10 read modes** — full, summary, skeleton, diff, symbols, and more
- **Shell hook** with 90+ patterns for compressed output
- **File caching** — hash-based dedup avoids re-reading unchanged files
- **Zero telemetry** — fully local, MIT licensed, single binary

### Integration points

| Tool | How lean-ctx helps |
|------|-------------------|
| Claude Code | MCP server reduces file read tokens |
| Copilot CLI | Shell hook compresses command output |
| Continue | Works with any MCP-aware editor |
| claude-mem | Complementary — lean-ctx reduces input tokens, claude-mem preserves output context |

## Acceptance criteria

- [x] Install step added to `scripts/host/tools.sh` under dev tools
- [x] Cargo-first install with npx fallback
- [ ] Verified binary runs and MCP server registers

## Upstream

| Resource | Link |
|----------|------|
| GitHub | <https://github.com/yvgude/lean-ctx> |
| Crates.io | <https://crates.io/crates/lean-ctx> |
| npm | <https://www.npmjs.com/package/lean-ctx-bin> |
| Website | <https://leanctx.com> |

## Notes

- Single Rust binary (~5 MB) — very lightweight
- No containers, no ports, no compose services
- Works alongside claude-mem (FEATURE-049) and Continue (FEATURE-047) as the AI dev toolkit trio
