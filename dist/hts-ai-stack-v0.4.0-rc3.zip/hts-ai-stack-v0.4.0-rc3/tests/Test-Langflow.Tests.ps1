$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/langflow'
    $script:ComponentScript = Join-Path $script:ComponentDir 'langflow.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'langflow.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'langflow file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'langflow manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is langflow' {
        $script:Manifest.id | Should -Be 'langflow'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/langflow/langflow.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is langflow' {
        $script:Manifest.func_prefix | Should -Be 'langflow'
    }

    It 'dashboard port is 7870' {
        [int]$script:Manifest.dashboard.port | Should -Be 7870
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'langflow component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines langflow_install function' {
        $script:ComponentContent | Should -Match 'langflow_install\s*\(\)'
    }

    It 'defines langflow_configure function' {
        $script:ComponentContent | Should -Match 'langflow_configure\s*\(\)'
    }

    It 'defines langflow_start function' {
        $script:ComponentContent | Should -Match 'langflow_start\s*\(\)'
    }

    It 'defines langflow_stop function' {
        $script:ComponentContent | Should -Match 'langflow_stop\s*\(\)'
    }

    It 'defines langflow_health function' {
        $script:ComponentContent | Should -Match 'langflow_health\s*\(\)'
    }

    It 'supports --start, --stop, and --health CLI flags' {
        $script:ComponentContent | Should -Match '--start\)'
        $script:ComponentContent | Should -Match '--stop\)'
        $script:ComponentContent | Should -Match '--health\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/langflow/langflow\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'langflow port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 7870 is registered in portmap.json' {
        $script:Portmap.ports.'7870' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'7870'.service | Should -Be 'langflow'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'langflow no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/langflow\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/langflow/langflow\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
