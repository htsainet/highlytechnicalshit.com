#!/usr/bin/env bash
# scripts/components/animatediff/animatediff.sh — AnimateDiff: install, configure, start, health
#
# AnimateDiff — AI-powered animation generation using Stable Diffusion with
# motion modules. Generates short animated sequences from text prompts.
# Runs via Gradio on GPU with CUDA acceleration.
#
# Standalone usage:
#   ./scripts/components/animatediff/animatediff.sh              # full: install + configure + start + health
#   ./scripts/components/animatediff/animatediff.sh --install    # install only (build image)
#   ./scripts/components/animatediff/animatediff.sh --configure  # configure only
#   ./scripts/components/animatediff/animatediff.sh --start      # start only
#   ./scripts/components/animatediff/animatediff.sh --stop       # stop
#   ./scripts/components/animatediff/animatediff.sh --restart    # restart (stop + start)
#   ./scripts/components/animatediff/animatediff.sh --health     # health check only
#   ./scripts/components/animatediff/animatediff.sh --status     # show status + port + health
#   ./scripts/components/animatediff/animatediff.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
ANIMATEDIFF_PORT="${ANIMATEDIFF_PORT:-8603}"

# ── Functions ────────────────────────────────────────────────────────────────

animatediff_install() {
  step "AnimateDiff — install"
  local dockerfile="$REPO_DIR/docker/animatediff/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    warn "AnimateDiff Dockerfile not found: $dockerfile"
    return 1
  fi
  compose_build --profile animatediff
  ok "AnimateDiff image built."
}

animatediff_configure() {
  step "AnimateDiff — configure"
  info "Gradio UI port: ${ANIMATEDIFF_PORT}"
  info "Base model: runwayml/stable-diffusion-v1-5"
  info "Motion module: guoyww/animatediff-motion-adapter-v1-5-3"
  info "Models downloaded from HuggingFace on first start."
  ok "AnimateDiff configured."
}

animatediff_start() {
  step "AnimateDiff — start"
  compose_up --profile animatediff
  ok "AnimateDiff started on port ${ANIMATEDIFF_PORT}."
}

animatediff_stop() {
  step "AnimateDiff — stop"
  compose_down --profile animatediff
  ok "AnimateDiff stopped."
}

animatediff_restart() {
  animatediff_stop
  animatediff_start
}

animatediff_health() {
  step "AnimateDiff — health"
  check_http "AnimateDiff" "http://localhost:${ANIMATEDIFF_PORT}/" 120
}

animatediff_status() {
  step "AnimateDiff — status"
  info "Port: ${ANIMATEDIFF_PORT}"
  animatediff_health
}

animatediff_destroy() {
  step "AnimateDiff — destroy"
  compose_down --profile animatediff -v
  ok "AnimateDiff destroyed (containers + volumes removed)."
}

# ── CLI entry point ──────────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  case "${1:-}" in
    --install)   animatediff_install   ;;
    --configure) animatediff_configure ;;
    --start)     animatediff_start     ;;
    --stop)      animatediff_stop      ;;
    --restart)   animatediff_restart   ;;
    --health)    animatediff_health    ;;
    --status)    animatediff_status    ;;
    --destroy)   animatediff_destroy   ;;
    *)
      animatediff_install
      animatediff_configure
      animatediff_start
      animatediff_health
      ;;
  esac
fi
