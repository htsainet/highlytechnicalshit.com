#!/usr/bin/env bash
# restore-ollama-from-nas.sh — Restore Ollama model cache from NAS backup into
# the local hts-ai-stack_ollama_data docker volume.
#
# Context:
#   Post-nuke, the ollama_data docker volume is empty but
#   /mnt/htsai-model-backup/ollama/ holds the last-good model cache. Pulling
#   every model over the internet again is wasteful when we already have them
#   on the NAS.
#
# What it does:
#   1. Ensures NAS mount and target volume exist.
#   2. Runs a throwaway alpine container with:
#        - /src : NAS ollama dir (read-only bind)
#        - /dst : hts-ai-stack_ollama_data volume
#      and rsyncs /src/ → /dst/ (models + manifests + blobs).
#   3. Reports final volume size + model count.
#
# Usage:
#   sudo ./scripts/utils/restore-ollama-from-nas.sh
#   sudo ./scripts/utils/restore-ollama-from-nas.sh --dry-run
#
# Safe to re-run — rsync is idempotent and won't re-copy unchanged blobs.

set -euo pipefail

NAS_OLLAMA="${NAS_OLLAMA:-/mnt/htsai-model-backup/ollama}"
VOLUME="${VOLUME:-hts-ai-stack_ollama_data}"
DRY_RUN=false

step() { echo; echo "════ $* ════"; }
info() { echo "    $*"; }
warn() { echo "[WARN] $*" >&2; }
fail() { echo "[ERROR] $*" >&2; exit 1; }

for a in "$@"; do
  case "$a" in
    --dry-run) DRY_RUN=true ;;
    --nas) shift; NAS_OLLAMA="$1" ;;
    --volume) shift; VOLUME="$1" ;;
    -h|--help) sed -n '2,25p' "$0"; exit 0 ;;
  esac
done

[[ $EUID -eq 0 ]] || fail "Re-run with sudo (docker socket + NAS perms)."

# ── preflight ─────────────────────────────────────────────────────────────────
step "Preflight"

[[ -d "$NAS_OLLAMA" ]] || fail "NAS ollama dir not found: $NAS_OLLAMA"
info "NAS source:    $NAS_OLLAMA"
info "NAS size:      $(du -sh "$NAS_OLLAMA" | awk '{print $1}')"
info "NAS contents:  $(ls "$NAS_OLLAMA" | tr '\n' ' ')"

# Stop ollama container if running — writes during restore would conflict
if docker ps --format '{{.Names}}' | grep -q '^hts-ai-ollama$'; then
  info "Stopping hts-ai-ollama (will restart after)..."
  $DRY_RUN || docker stop hts-ai-ollama >/dev/null
  RESTART_AFTER=true
else
  RESTART_AFTER=false
fi

# Create the volume if it doesn't exist (compose would create it on next up)
if ! docker volume inspect "$VOLUME" >/dev/null 2>&1; then
  info "Creating docker volume: $VOLUME"
  $DRY_RUN || docker volume create "$VOLUME" >/dev/null
else
  info "Volume exists: $VOLUME"
fi

# ── rsync via throwaway alpine container ──────────────────────────────────────
step "Rsync NAS → volume (throwaway alpine container)"

RSYNC_FLAGS=(-a --info=progress2 --human-readable)
$DRY_RUN && RSYNC_FLAGS+=(--dry-run)

# Note: trailing slashes matter — /src/ copies contents, not the dir itself.
# Ollama expects $VOLUME/models/{blobs,manifests}, which matches the NAS layout
# under /mnt/htsai-model-backup/ollama/models/...
docker run --rm \
  -v "$NAS_OLLAMA":/src:ro \
  -v "$VOLUME":/dst \
  alpine:3.20 sh -c "
    apk add --no-cache rsync >/dev/null
    echo 'Source tree:'
    ls -la /src | head -10
    echo
    echo 'Dest before:'
    ls -la /dst | head -10
    echo
    rsync ${RSYNC_FLAGS[*]} /src/ /dst/
    echo
    echo 'Dest after:'
    ls -la /dst | head -10
  "

# ── post-check ────────────────────────────────────────────────────────────────
step "Post-check"
$DRY_RUN && { info "(dry-run — nothing restored)"; exit 0; }

# Count models via manifests directory
docker run --rm -v "$VOLUME":/d alpine:3.20 sh -c '
  echo "Volume size: $(du -sh /d | awk "{print \$1}")"
  if [ -d /d/models/manifests ]; then
    echo "Manifests:"
    find /d/models/manifests -type f | sed "s|/d/models/manifests/||" | sort
  else
    echo "(no manifests dir — layout may differ; check /d contents)"
    ls -la /d
  fi
'

if $RESTART_AFTER; then
  step "Restarting hts-ai-ollama"
  docker start hts-ai-ollama >/dev/null && info "started."
fi

echo
echo "Done. Sanity check:"
echo "  docker compose up -d ollama   # if not already running"
echo "  docker exec hts-ai-ollama ollama list"
