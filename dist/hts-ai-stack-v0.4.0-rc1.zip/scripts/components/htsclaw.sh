#!/usr/bin/env bash
# scripts/components/htsclaw.sh — htsclaw sandbox: install, configure, start, stop, health
#
# Self-managed OpenClaw sandbox — drives OpenShell directly, no NemoClaw.
# Wraps the subsystem scripts under scripts/htsclaw/ into the component
# contract used by bundles and the setup wizard.
#
# Standalone usage:
#   ./scripts/components/htsclaw.sh              # full setup: install + configure + start + health
#   ./scripts/components/htsclaw.sh --configure   # firewall + provider config only
#   ./scripts/components/htsclaw.sh --start       # create sandbox + forward + personas + tokens
#   ./scripts/components/htsclaw.sh --health      # health check only
#   ./scripts/components/htsclaw.sh --stop        # destroy sandbox
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
HTSCLAW_DIR="$REPO_DIR/scripts/htsclaw"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
HTSCLAW_DEPLOY="${HTSCLAW_DEPLOY:-true}"
HTSCLAW_AGENT_PERSONAS="${HTSCLAW_AGENT_PERSONAS:-true}"

# ── Source subsystem scripts ─────────────────────────────────────────────────
# Each subsystem exports its own public functions. We source them so bundles
# and the standalone CLI dispatch can call them directly.
source "$HTSCLAW_DIR/sandbox/lifecycle.sh"
source "$HTSCLAW_DIR/sandbox/provider.sh"
source "$HTSCLAW_DIR/sandbox/firewall.sh"
source "$HTSCLAW_DIR/health/health.sh"
source "$HTSCLAW_DIR/personas/provision.sh"
source "$HTSCLAW_DIR/dashboard/tokens.sh"
source "$HTSCLAW_DIR/dashboard/origins.sh"

# ── Component contract ───────────────────────────────────────────────────────

# htsclaw_install — Install prerequisites (OpenShell CLI, GitHub CLI).
# Unlike NemoClaw, htsclaw does not need the nemoclaw npm package.
htsclaw_install() {
  _ensure_sudo

  # ── GitHub CLI ──
  step "htsclaw — GitHub CLI"
  if gh --version &>/dev/null; then
    info "GitHub CLI already installed ($(gh --version | head -1))"
  else
    info "Installing GitHub CLI..."
    curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | \
      sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg

    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] \
      https://cli.github.com/packages stable main" | \
      sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null

    sudo apt-get update -qq && sudo apt-get install -y gh
  fi

  if ! gh auth status &>/dev/null; then
    info "Authenticating with GitHub..."
    gh auth login
  else
    info "GitHub CLI already authenticated"
  fi

  # ── OpenShell CLI ──
  step "htsclaw — OpenShell CLI"
  if openshell --version &>/dev/null; then
    info "OpenShell already installed ($(openshell --version))"
  else
    info "Downloading OpenShell binary..."
    local arch tarball
    arch=$(uname -m)
    tarball="openshell-${arch}-unknown-linux-musl.tar.gz"

    gh release download --repo NVIDIA/OpenShell --pattern "$tarball"
    tar xzf "$tarball"
    sudo install -m 755 openshell /usr/local/bin/openshell
    rm -f "$tarball" openshell
    openshell --version
  fi

  ok "htsclaw prerequisites installed."
}

# htsclaw_configure — Firewall rules + inference provider configuration.
htsclaw_configure() {
  htsclaw_firewall
  _ensure_gateway
  htsclaw_provider
  ok "htsclaw configured."
}

# htsclaw_start — Create sandbox, set up forwards, provision personas, extract tokens.
htsclaw_start() {
  if [[ "$HTSCLAW_DEPLOY" != "true" ]]; then
    step "htsclaw — start (SKIPPED)"
    info "Skipping htsclaw deployment — HTSCLAW_DEPLOY is not true"
    return 0
  fi

  step "htsclaw — start"

  # Create sandbox (idempotent — prompts if already exists)
  htsclaw_create

  # Fix controlUi.allowedOrigins so the dashboard can embed the OpenClaw UI
  htsclaw_fix_origins

  # Extract auth tokens for dashboard auto-login
  htsclaw_extract_tokens

  # Provision agent personas (SOUL.md, IDENTITY.md) if enabled
  if [[ "$HTSCLAW_AGENT_PERSONAS" == "true" ]]; then
    htsclaw_provision_personas
  fi

  # Install systemd health timer
  htsclaw_install_health_timer

  ok "htsclaw sandbox started."
}

# htsclaw_stop — Destroy sandbox and clean up.
htsclaw_stop() {
  step "htsclaw — stop"
  htsclaw_destroy
  ok "htsclaw sandbox stopped."
}

# Note: htsclaw_health is already defined by health/health.sh (sourced above).

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start"; shift ;;
      --health)    ACTION="health"; shift ;;
      --stop)      ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      htsclaw_install
      htsclaw_configure
      htsclaw_start
      htsclaw_health
      ;;
    configure)
      htsclaw_configure
      ;;
    start)
      htsclaw_start
      ;;
    health)
      htsclaw_health
      ;;
    stop)
      htsclaw_stop
      ;;
  esac
fi
