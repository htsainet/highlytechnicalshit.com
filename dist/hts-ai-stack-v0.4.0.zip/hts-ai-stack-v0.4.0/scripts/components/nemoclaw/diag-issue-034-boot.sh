#!/usr/bin/env bash
# diag-issue-034-boot.sh — Post-reboot probe for ISSUE-034 (silent dashboard-forward death)
#
# Purpose
#   After the drift-strip redesign (PR #13), the dashboard SSH forward is held
#   by a single systemd oneshot at boot — `hts-nemoclaw-dashboard-forward.service`
#   — with **no retry**, **no watchdog**, and **no listener probe**. If the boot
#   run fails (gateway not yet ready, transient TLS error, version mismatch),
#   the unit goes to `failed` and stays there until the operator runs
#   `--restart-forward` manually. ISSUE-034 is the question of whether that
#   silent-death pattern still bites in the v0.0.29 / openshell 0.0.36 era,
#   or whether the redesign + cross-version fixes have actually solved it.
#
# How to use
#   1. Reboot the host.
#   2. After login, wait ~2 minutes for systemd to settle.
#   3. Run: ./scripts/components/nemoclaw/diag-issue-034-boot.sh
#   4. Read the verdict at the bottom — it tells you exactly what to do next.
#
# Side effects: NONE. Read-only diagnostic.
#
# References
#   - docs/development/issues/ISSUE-034.md
#   - scripts/components/nemoclaw/CONTEXT.md (§ "Boot-time port forward — one
#     documented oneshot, no watchdog")
#   - NVIDIA NemoClaw quickstart §"Restart the Port Forward"

set -euo pipefail

UNIT="hts-nemoclaw-dashboard-forward.service"
PORT=18789

# ── pretty printers ──────────────────────────────────────────────────────────
bold()  { printf '\033[1m%s\033[0m\n' "$*"; }
green() { printf '\033[32m%s\033[0m\n' "$*"; }
yellow(){ printf '\033[33m%s\033[0m\n' "$*"; }
red()   { printf '\033[31m%s\033[0m\n' "$*"; }
hr()    { printf '── %s %s\n' "$*" "$(printf '─%.0s' $(seq 1 $((70 - ${#1} - 4))))"; }

# ── 1. Uptime sanity check ───────────────────────────────────────────────────
hr "Boot context"
uptime_secs=$(awk '{print int($1)}' /proc/uptime)
uptime_mins=$((uptime_secs / 60))
printf '  uptime: %s min  (boot at: %s)\n' \
  "$uptime_mins" "$(uptime -s)"

if (( uptime_mins < 2 )); then
  yellow "  ⚠ uptime is < 2 min — systemd may still be settling. Re-run in 60s for a stable reading."
fi

# ── 2. Systemd unit state ────────────────────────────────────────────────────
hr "Systemd unit"
unit_active=$(systemctl is-active   "$UNIT" 2>/dev/null || true)
unit_failed=$(systemctl is-failed   "$UNIT" 2>/dev/null || true)
unit_enabled=$(systemctl is-enabled "$UNIT" 2>/dev/null || true)

printf '  unit:       %s\n' "$UNIT"
printf '  is-active:  %s\n' "${unit_active:-unknown}"
printf '  is-failed:  %s\n' "${unit_failed:-unknown}"
printf '  is-enabled: %s\n' "${unit_enabled:-unknown}"

# Most recent ExecStart attempt (timestamp + result), so we can tell whether
# the unit ran *this* boot or is still showing pre-reboot history.
last_ts=$(systemctl show "$UNIT" -p ExecMainStartTimestamp --value 2>/dev/null || true)
last_status=$(systemctl show "$UNIT" -p ExecMainStatus --value 2>/dev/null || true)
printf '  last run:   %s  (exit status: %s)\n' \
  "${last_ts:-<never>}" "${last_status:-<n/a>}"

# ── 3. Listener state ────────────────────────────────────────────────────────
hr "Port :$PORT"
listener_line=$(ss -tlnp 2>/dev/null | awk -v p=":$PORT" '$4 ~ p {print; exit}' || true)
if [[ -n "$listener_line" ]]; then
  printf '  %s\n' "$listener_line"
  port_listening=1
else
  printf '  not listening on 127.0.0.1:%s\n' "$PORT"
  port_listening=0
fi

# ── 4. Optional: HTTP probe (does the dashboard actually answer?) ────────────
hr "HTTP probe"
http_ok=0
if (( port_listening == 1 )); then
  http_code=$(curl -sk -o /dev/null -w '%{http_code}' \
    --max-time 5 "http://127.0.0.1:${PORT}/" 2>/dev/null || echo "000")
  printf '  curl http://127.0.0.1:%s/  →  %s\n' "$PORT" "$http_code"
  case "$http_code" in
    200|301|302|401|403) http_ok=1 ;;
  esac
else
  printf '  skipped (port not listening)\n'
fi

# ── 5. Recent journal lines (context for failures) ───────────────────────────
hr "Last 8 journal lines for $UNIT"
journalctl -u "$UNIT" --no-pager -n 8 2>/dev/null \
  | sed 's/^/  /' \
  || printf '  <no journal access — run with sudo for fuller history>\n'

# ── Verdict ──────────────────────────────────────────────────────────────────
echo
hr "Verdict"

if [[ "$unit_active" == "active" || "$unit_active" == "activating" ]] \
   && (( port_listening == 1 )) && (( http_ok == 1 )); then
  green "🟢 BOOT OK — unit active, port listening, dashboard responsive."
  bold  "Action: none. ISSUE-034 is not biting on this boot."
  bold  "If you see 🟢 on a few independent reboots, ISSUE-034 can be closed"
  bold  "as fixed-by-redesign and v0.4.0 gate item ticked off."
  exit 0
fi

if [[ "$unit_failed" == "failed" ]] && (( port_listening == 0 )); then
  red   "🔴 SILENT BOOT DEATH — unit is failed, :$PORT not listening."
  bold  "ISSUE-034 is real on this build. Recovery + fix:"
  echo  "  1. Manual recovery (right now):"
  echo  "       ./scripts/components/nemoclaw/nemoclaw.sh --restart-forward"
  echo  "  2. Land the retry-budget fix in _install_dashboard_forward_boot_unit:"
  echo  "       Restart=on-failure, RestartSec=30s,"
  echo  "       StartLimitIntervalSec=600, StartLimitBurst=5"
  echo  "       (see ACTIVE.md → 'In flight' for the proposed change)"
  exit 1
fi

if [[ "$unit_failed" == "failed" || "$unit_active" != "active" ]] \
   && (( port_listening == 1 )); then
  yellow "🟡 PORT UP, UNIT NOT — :$PORT is held by a non-unit process."
  bold   "Likely cause: an inline 'nemoclaw.sh --start' invocation papered over"
  bold   "the failed boot run. Dashboard works, but the documented recovery path"
  bold   "(boot unit) is broken — that drift will bite a future reboot."
  echo   "Action: land the retry-budget fix per ISSUE-034.md before v0.4.0 ships."
  exit 2
fi

red "❓ INDETERMINATE — unhandled state combination."
echo "  unit_active=$unit_active  unit_failed=$unit_failed  port_listening=$port_listening  http_ok=$http_ok"
echo "Capture this output + 'systemctl status $UNIT --no-pager' for triage."
exit 3
