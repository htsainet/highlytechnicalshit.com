#!/usr/bin/env bash
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already done"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; exit 1; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

ENV_FILE=".env"

# ── Step 1: Install signal-cli ───────────────────────────────────────────────
step "1 — Install signal-cli"

if [[ -d /opt/signal-cli ]] || command -v signal-cli &>/dev/null; then
  skip "signal-cli ($(/opt/signal-cli/bin/signal-cli --version 2>/dev/null | head -1 || signal-cli --version 2>/dev/null | head -1))"
else
  info "Installing signal-cli..."
  SIGNAL_VERSION=$(curl -fsSL https://api.github.com/repos/AsamK/signal-cli/releases/latest \
    | grep '"tag_name"' | cut -d'"' -f4)
  SIGNAL_TARBALL="signal-cli-${SIGNAL_VERSION#v}-Linux-native.tar.gz"
  curl -fsSL \
    "https://github.com/AsamK/signal-cli/releases/download/${SIGNAL_VERSION}/${SIGNAL_TARBALL}" \
    -o /tmp/signal-cli.tar.gz
  sudo mkdir -p /opt/signal-cli
  sudo tar xzf /tmp/signal-cli.tar.gz --strip-components=1 -C /opt/signal-cli
  sudo ln -sf /opt/signal-cli/bin/signal-cli /usr/local/bin/signal-cli
  rm /tmp/signal-cli.tar.gz
  info "signal-cli $(signal-cli --version 2>/dev/null | head -1) installed."
fi

# ── Step 2: Phone number ──────────────────────────────────────────────────────
step "2 — Phone number"

[ -f "$ENV_FILE" ] || fail ".env not found — run ./2-setup-docker.sh first."

SIGNAL_PHONE=$(grep '^SIGNAL_PHONE=' "$ENV_FILE" | cut -d= -f2- | tr -d '[:space:]' || true)

if [ -z "$SIGNAL_PHONE" ]; then
  echo ""
  warn "SIGNAL_PHONE not found in .env."
  echo "  Enter your phone number in E.164 format, e.g. +14155552671"
  read -r -p "  Phone number: " SIGNAL_PHONE
  [ -n "$SIGNAL_PHONE" ] || fail "No phone number provided."
  echo "SIGNAL_PHONE=${SIGNAL_PHONE}" >> "$ENV_FILE"
  info "Phone number saved to .env."
else
  info "SIGNAL_PHONE: ${SIGNAL_PHONE}"
fi

# ── Step 3: Register or link ──────────────────────────────────────────────────
step "3 — Register or link"

# Check if this number is already registered/linked
if signal-cli -u "${SIGNAL_PHONE}" listAccounts &>/dev/null 2>&1; then
  ACCOUNT_INFO=$(signal-cli -u "${SIGNAL_PHONE}" listAccounts 2>/dev/null || true)
  if echo "$ACCOUNT_INFO" | grep -q "${SIGNAL_PHONE}"; then
    skip "Account ${SIGNAL_PHONE} already registered"
    echo ""
    info "Skipping to step 5 (send test message)."
    SKIP_TO_TEST=true
  fi
fi
SKIP_TO_TEST=${SKIP_TO_TEST:-false}

if [ "$SKIP_TO_TEST" = "false" ]; then
  echo ""
  echo "  How do you want to set up this device?"
  echo "  [1] Register new account (sends SMS verification to ${SIGNAL_PHONE})"
  echo "  [2] Link to existing Signal account (scan QR code in Signal app)"
  echo ""
  read -r -p "  Choice [1/2]: " SETUP_MODE

  case "$SETUP_MODE" in
    1)
      # ── Step 3a: Register new ───────────────────────────────────────────
      step "3a — Register new account"
      info "Sending SMS verification to ${SIGNAL_PHONE}..."
      signal-cli -u "${SIGNAL_PHONE}" register

      echo ""
      read -r -p "  Enter the SMS verification code: " VERIFY_CODE
      [ -n "$VERIFY_CODE" ] || fail "No verification code provided."

      info "Verifying..."
      signal-cli -u "${SIGNAL_PHONE}" verify "${VERIFY_CODE}"
      info "Account registered."
      ;;
    2)
      # ── Step 3b: Link existing ──────────────────────────────────────────
      step "3b — Link to existing account"
      warn "A QR code link will be generated. Open Signal on your phone:"
      warn "  Settings → Linked devices → Link new device"
      echo ""
      signal-cli link -n "ubuntu-ai-stack-$(hostname)"
      info "Device linked."
      ;;
    *)
      fail "Invalid choice '${SETUP_MODE}'. Run the script again and choose 1 or 2."
      ;;
  esac
fi

# ── Step 4: Set profile name ──────────────────────────────────────────────────
step "4 — Profile name"

CURRENT_NAME=$(signal-cli -u "${SIGNAL_PHONE}" getUserStatus "${SIGNAL_PHONE}" 2>/dev/null \
  | grep -i name | head -1 || true)

if [ -n "$CURRENT_NAME" ]; then
  info "Current profile: ${CURRENT_NAME}"
  read -r -p "  Update display name? (Enter to skip): " NEW_NAME
else
  read -r -p "  Set a display name for this device (Enter to skip): " NEW_NAME
fi

if [ -n "$NEW_NAME" ]; then
  signal-cli -u "${SIGNAL_PHONE}" updateProfile --name "${NEW_NAME}"
  info "Profile name set to '${NEW_NAME}'."
fi

# ── Step 5: Send test message ─────────────────────────────────────────────────
step "5 — Test send"

echo ""
read -r -p "  Send a test message to yourself? [y/N] " REPLY
if [[ "$REPLY" =~ ^[Yy]$ ]]; then
  signal-cli -u "${SIGNAL_PHONE}" send -m "ubuntu-ai-stack signal-cli test — $(date)" "${SIGNAL_PHONE}"
  info "Test message sent to ${SIGNAL_PHONE}."
fi

echo ""
info "Signal setup complete."
info "Account : ${SIGNAL_PHONE}"
info ""
info "Useful commands:"
echo "  Receive messages  : signal-cli -u ${SIGNAL_PHONE} receive"
echo "  Send a message    : signal-cli -u ${SIGNAL_PHONE} send -m 'hello' +1XXXXXXXXXX"
echo "  List accounts     : signal-cli -u ${SIGNAL_PHONE} listAccounts"
