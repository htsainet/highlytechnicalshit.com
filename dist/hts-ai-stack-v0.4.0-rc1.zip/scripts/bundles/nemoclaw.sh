#!/usr/bin/env bash
# scripts/bundles/nemoclaw.sh — Sandbox agent runtime bundle
#
# Sets up the inference backend, NemoClaw sandbox agent, and dashboard.
#
# Usage:
#   ./scripts/bundles/nemoclaw.sh [--chat mean|claw]
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "NemoClaw Bundle"
load_env

CHAT_MODE="mean"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --chat) CHAT_MODE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-false}"

# ── Services (dual-backend + llama-swap) ──────────────────────────────────────
step "Backend"
bash "$REPO_DIR/scripts/components/ollama.sh" --swap "$CHAT_MODE"
bash "$REPO_DIR/scripts/components/bitnet.sh"
bash "$REPO_DIR/scripts/components/llama-swap.sh"

step "NemoClaw"
bash "$REPO_DIR/scripts/components/nemoclaw.sh"

if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/components/dashboard.sh"
fi

echo ""
ok "NemoClaw bundle ready — dual-backend (GPU+CPU) chat:${CHAT_MODE}"
