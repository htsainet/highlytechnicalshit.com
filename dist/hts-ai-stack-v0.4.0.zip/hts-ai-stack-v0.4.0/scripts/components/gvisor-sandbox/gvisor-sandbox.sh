#!/usr/bin/env bash
# scripts/components/gvisor-sandbox/gvisor-sandbox.sh — gVisor CPU agent sandbox
#
# FEATURE-012: OpenClaw gateway running under gVisor (runsc) for
# VM-level kernel isolation without an actual VM. Talks to llama-swap
# directly on the Docker ai-network, bypassing NemoClaw's gateway.
#
# Standalone usage:
#   ./scripts/components/gvisor-sandbox/gvisor-sandbox.sh              # full: install + start + health
#   ./scripts/components/gvisor-sandbox/gvisor-sandbox.sh --install    # install only
#   ./scripts/components/gvisor-sandbox/gvisor-sandbox.sh --start      # start only
#   ./scripts/components/gvisor-sandbox/gvisor-sandbox.sh --stop       # stop
#   ./scripts/components/gvisor-sandbox/gvisor-sandbox.sh --restart    # restart (stop + start)
#   ./scripts/components/gvisor-sandbox/gvisor-sandbox.sh --health     # health check only
#   ./scripts/components/gvisor-sandbox/gvisor-sandbox.sh --status     # show status + port + health
#   ./scripts/components/gvisor-sandbox/gvisor-sandbox.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env
GVISOR_SANDBOX_PORT="${GVISOR_SANDBOX_PORT:-18791}"
GVISOR_SANDBOX_CONTAINER="${GVISOR_SANDBOX_CONTAINER:-hts-ai-gvisor-sandbox}"

# ── Functions ────────────────────────────────────────────────────────────────

# _gvisor_ensure_runtime — Install runsc and register it as a Docker runtime
_gvisor_ensure_runtime() {
  if command -v runsc &>/dev/null; then
    info "gVisor runtime already installed: $(runsc --version 2>/dev/null | head -1)"
    return 0
  fi

  step "gVisor — installing runsc runtime"

  # GPG key
  if [[ ! -f /usr/share/keyrings/gvisor-archive-keyring.gpg ]]; then
    curl -fsSL https://gvisor.dev/archive.key \
      | sudo gpg --dearmor -o /usr/share/keyrings/gvisor-archive-keyring.gpg
    info "gVisor GPG key installed."
  fi

  # Apt repo
  if [[ ! -f /etc/apt/sources.list.d/gvisor.list ]]; then
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/gvisor-archive-keyring.gpg] https://storage.googleapis.com/gvisor/releases release main" \
      | sudo tee /etc/apt/sources.list.d/gvisor.list > /dev/null
    info "gVisor apt repository added."
  fi

  sudo apt-get update -qq
  sudo apt-get install -y -qq runsc

  if ! command -v runsc &>/dev/null; then
    fail "runsc binary not found after install — check apt output above."
    return 1
  fi
  info "runsc installed: $(runsc --version 2>/dev/null | head -1)"
}

# _gvisor_register_docker_runtime — Register runsc with Docker daemon
_gvisor_register_docker_runtime() {
  if docker info 2>/dev/null | grep -q runsc; then
    info "runsc already registered as Docker runtime."
    return 0
  fi

  step "gVisor — registering Docker runtime"
  sudo runsc install
  sudo systemctl reload docker
  info "Docker runtime 'runsc' registered and daemon reloaded."

  # Sanity check
  if ! docker info 2>/dev/null | grep -q runsc; then
    fail "runsc not visible in 'docker info' after registration."
    return 1
  fi
}

# gvisor_sandbox_install — Ensure gVisor runtime + build container image
gvisor_sandbox_install() {
  step "gVisor Sandbox — install"

  _gvisor_ensure_runtime
  _gvisor_register_docker_runtime

  compose_build --profile gvisor-sandbox
  ok "gVisor sandbox image built."
}

# gvisor_sandbox_start — Bring up gVisor sandbox via compose
gvisor_sandbox_start() {
  step "gVisor Sandbox — start"
  compose_up --profile gvisor-sandbox
  ok "gVisor sandbox started on port ${GVISOR_SANDBOX_PORT}."
}

# gvisor_sandbox_stop — Bring down gVisor sandbox
gvisor_sandbox_stop() {
  step "gVisor Sandbox — stop"
  compose_down --profile gvisor-sandbox
  ok "gVisor sandbox stopped."
}

# gvisor_sandbox_health — Probe the OpenClaw healthz endpoint
gvisor_sandbox_health() {
  health_probe "gVisor Sandbox :${GVISOR_SANDBOX_PORT}" \
    "http://localhost:${GVISOR_SANDBOX_PORT}/healthz"
}

gvisor_sandbox_restart() {
  gvisor_sandbox_stop
  gvisor_sandbox_start
}

gvisor_sandbox_destroy() {
  step "gVisor Sandbox — destroy"
  compose_down --profile gvisor-sandbox -v
  ok "gVisor sandbox destroyed."
}

gvisor_sandbox_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=gvisor-sandbox" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "gVisor Sandbox is running (port ${GVISOR_SANDBOX_PORT})"
  else
    warn "gVisor Sandbox is not running."
  fi
  gvisor_sandbox_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   gvisor_sandbox_install   ;;
    start)     gvisor_sandbox_start     ;;
    stop)      gvisor_sandbox_stop      ;;
    restart)   gvisor_sandbox_restart   ;;
    health)    gvisor_sandbox_health    ;;
    status)    gvisor_sandbox_status    ;;
    destroy)   gvisor_sandbox_destroy   ;;
    default)
      gvisor_sandbox_install
      gvisor_sandbox_start
      gvisor_sandbox_health
      ;;
  esac
fi
