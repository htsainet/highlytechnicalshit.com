# NemoClaw References

Last updated: 2026-04-30

> **Single home for nemoclaw reference material.** The top-level
> `REFERENCES.md` carries only a stub pointing here.
>
> Current pins (manifest is canonical):
> NemoClaw `v0.0.31`, OpenShell `0.0.36`.

## Upstream

- [GitHub — NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw)
- [GitHub — openclaw/openclaw](https://github.com/openclaw/openclaw) — runs inside NemoClaw sandboxes
- [GitHub — NVIDIA/OpenShell](https://github.com/NVIDIA/OpenShell) — container runtime managed by NemoClaw

## Official documentation

- [NemoClaw Latest Docs](https://docs.nvidia.com/nemoclaw/latest/)
- [NemoClaw Quickstart](https://docs.nvidia.com/nemoclaw/latest/get-started/quickstart.html)
- [NemoClaw CLI Commands Reference](https://docs.nvidia.com/nemoclaw/latest/reference/commands.html)

## Official CLI commands (authoritative — do not deviate)

These are the commands documented by NVIDIA. Our scripts MUST use these
commands unless Tim explicitly approves an alternative.

### Lifecycle

| Task | Official command |
|------|-----------------|
| Install + onboard | `curl -fsSL https://www.nvidia.com/nemoclaw.sh \| bash` |
| Recreate gateway/sandbox | `nemoclaw onboard [--recreate-sandbox]` |
| Upgrade sandboxes | `nemoclaw upgrade-sandboxes [--auto] [--check]` |
| Connect to sandbox | `nemoclaw <name> connect` |
| Destroy sandbox | `nemoclaw <name> destroy` |
| Rebuild sandbox | `nemoclaw <name> rebuild` |
| Uninstall | `nemoclaw uninstall [--yes]` |

### Status and diagnostics

| Task | Official command |
|------|-----------------|
| Per-sandbox status | `nemoclaw <name> status` |
| Gateway-wide status | `nemoclaw status` (sandbox list + host auxiliary services) |
| Logs (sandbox) | `nemoclaw <name> logs [--follow]` |
| Debug/diagnostics | `nemoclaw debug [--quick] [--sandbox NAME] [--output PATH]` |
| List sandboxes | `nemoclaw list` |
| Garbage-collect orphan images | `nemoclaw gc` |
| Back up all running sandboxes | `nemoclaw backup-all` |

### Policy and security

| Task | Official command |
|------|-----------------|
| Add network policy | `nemoclaw <name> policy-add <preset>` |
| List policies | `nemoclaw <name> policy-list` |
| Remove policy | `nemoclaw <name> policy-remove <preset>` |

### Auxiliary

| Task | Official command |
|------|-----------------|
| Start host auxiliary services (cloudflared) | `nemoclaw tunnel start` |
| Stop host auxiliary services (cloudflared) | `nemoclaw tunnel stop` |
| Credential management | `nemoclaw credentials list` / `nemoclaw credentials reset <KEY>` |
| Snapshot create | `nemoclaw <name> snapshot create [--name LABEL]` |
| Snapshot list | `nemoclaw <name> snapshot list` |
| Snapshot restore | `nemoclaw <name> snapshot restore [selector] [--to <dst>]` |

> **Note (2026-04-25 docs read):** `nemoclaw start` and `nemoclaw stop`
> are now **deprecated aliases** for `nemoclaw tunnel start` / `nemoclaw
> tunnel stop`. They print a warning and delegate. They control only
> host-side cloudflared, **not** the sandbox or gateway. Sandbox lifecycle
> is `nemoclaw onboard` (create/recreate), `nemoclaw <name> rebuild`
> (preserve workspace), `nemoclaw <name> destroy` (permanent removal).
> Our `nemoclaw_start()` / `nemoclaw_stop()` orchestrate the supported
> primitives; they do not call the deprecated aliases.

### Commands our scripts MUST NOT use

Per NVIDIA's quickstart and onboard docs:

> Avoid `openshell self-update`, `npm update -g openshell`,
> `openshell gateway start --recreate`, or `openshell sandbox create`
> directly unless you intend to manage OpenShell separately and then
> rerun `nemoclaw onboard`.

Additionally:

- **Do not call the deprecated `nemoclaw start` / `nemoclaw stop` aliases.**
  Use `nemoclaw tunnel start` / `nemoclaw tunnel stop` if cloudflared
  control is needed, or the sandbox-lifecycle commands above for sandbox
  control.
- **Do not invent sandbox names that collide with global CLI commands**
  (`status`, `list`, `debug`, etc.) — `nemoclaw onboard` rejects them.

## OpenClaw CLI inside sandboxes

OpenClaw runs inside NemoClaw sandboxes. For commands that operate
on the OpenClaw instance inside a sandbox, see the
[OpenClaw CLI Reference](https://github.com/openclaw/openclaw/tree/main/docs/cli).

## Architecture — host-side CLI, sandbox-hosted agent

The nemoclaw CLI runs on the **host machine**, not inside the OpenShell
sandbox. This matches NVIDIA's documented architecture.

```text
Host
├── openshell CLI  (/usr/local/bin/openshell)        — installed by NVIDIA install-openshell.sh
├── nemoclaw CLI   (~/.npm-global/bin/nemoclaw)      — host-side lifecycle manager
│
└── OpenShell gateway (docker container: openshell-cluster-hts-ai-openshell-nemoclaw)
    └── OpenShell sandbox (hts-ai-openshell-nemoclaw)
        └── OpenClaw agent runtime (inside sandbox)
```

Onboard flow:

1. `nemoclaw_install()` — runs `curl -fsSL https://www.nvidia.com/nemoclaw.sh | bash`
   on host with `NEMOCLAW_SKIP_ONBOARD=1`; refreshes PATH via nvm.sh +
   npm global bin.
2. `nemoclaw_onboard()` → `_do_onboard()` → `_run_onboard_cmd()` — runs
   `env <vars> nemoclaw onboard --non-interactive` on host with
   `NEMOCLAW_POLICY_TIER=balanced`; llama-swap pre-flight check + model
   warm-up before onboard.
3. `_setup_provider()` — switches the runtime
   `compatible-endpoint` provider URL to `host.openshell.internal` for
   in-sandbox access after onboard validates against `localhost:8081`.

## OpenShell — install path

`scripts/lib/common.sh` `install_openshell_nvidia()` installs OpenShell
on the host:

- Tries NVIDIA's `install-openshell.sh` (idempotent, version-ranged) first.
- Re-verifies installed version after the NVIDIA script; falls back to
  direct GitHub release download if it drifts.
- Version change sets `_OPENSHELL_REINSTALLED=true` → gateway recreation
  on the next onboard.

Verification: `./scripts/utils/verify-openshell-pin.sh` confirms the
installed binary, `~/.nemoclaw/blueprint.yaml`, and the manifest agree
on the pinned version.

## Working configuration (verified 2026-04-30 against v0.0.31)

End-to-end MVP chat through llama-swap is working. The gory details live
in [`CONTEXT.md`](CONTEXT.md) §"2026-04-26 — Working configuration"; the
operational TL;DR:

| Knob | Value | Notes |
|------|-------|-------|
| NemoClaw pin | `v0.0.31` | `nemoclaw.manifest.json upstream.pinned_version` |
| OpenShell pin | `0.0.36` | top of NemoClaw v0.0.31 blueprint window `[0.0.32, 0.0.36]` |
| `NEMOCLAW_MODEL` | `mistral-nemo:latest` | NVIDIA/Mistral 12B Q4. Strong tool-caller; `qwen2.5:7b-instruct-q4_K_M` chats fine but spirals on OpenClaw's tool loop. |
| `NEMOCLAW_INFERENCE_TIMEOUT` | `300` | Cold-load of mistral-nemo can take 60–120 s; OpenShell's default 60 s kills the stream. |
| Install-time provider | `NEMOCLAW_PROVIDER=custom` + `NEMOCLAW_EXPERIMENTAL=1` | required to bypass NVIDIA Endpoints API-key check |
| Runtime provider object | `compatible-endpoint` | created by `nemoclaw onboard`. Credential env `COMPATIBLE_API_KEY=not-needed`. |
| Sandbox-side URL | `https://inference.local/v1` | Documented relay; do **not** punch a custom policy hole to `host.openshell.internal:8081` from inside the sandbox. |
| Gateway upstream | `http://host.openshell.internal:8081/v1` | Set via `nemoclaw <name> config provider <name> --base-url`. |
| Tokens sidecar | `resources/dashboard/nemoclaw-tokens.json` | Refreshed every action that touches tokens; banner with full URL prints to stdout. |
| Gateway name (upstream-fixed) | `nemoclaw` | upstream ignores `NEMOCLAW_GATEWAY_NAME`; sandbox is `hts-ai-openshell-nemoclaw` (sandbox naming IS honoured). |

Single source of truth for the model name: `NEMOCLAW_MODEL` is defined
in exactly two places — the `model` prompt in `nemoclaw.manifest.json`
and a lone fallback at `nemoclaw.sh:50`. Every other reference is a
bare `${NEMOCLAW_MODEL}`.

## Smoke-test plan

Execute manually after deployment. All scenarios should pass before
declaring a pin bump healthy.

| # | Scenario | Pass condition |
|---|----------|----------------|
| 1 | Fresh host install (no prior sandbox) | `nemoclaw --version` on host; sandbox reaches `Phase: Ready` |
| 2 | Migration from inverted install (existing sandbox) | `--backup-premigration` runs; re-onboard succeeds; workspace backup files non-empty |
| 3 | Idempotence — run `converge --component nemoclaw` twice | Second run exits 0, no duplicate gateway/sandbox |
| 4 | Non-login shell / systemd invocation | PATH contains nemoclaw after install; `nemoclaw --version` works from systemd unit |
| 5 | `nemoclaw onboard --non-interactive` against `localhost:8081` | Onboard completes without interactive prompt; log shows no auth error |
| 6 | End-to-end prompt through sandbox | Send a chat via OpenClaw dashboard; response returns from llama-swap model |
| 7 | `nemoclaw <name> rebuild --yes` | Rebuild completes; workspace preserved; `openclaw doctor --fix` runs |
| 8 | `nemoclaw upgrade-sandboxes --auto --yes` | Upgrade exits 0; `nemoclaw_restart()` path not triggered |
| 9 | `nemoclaw <name> snapshot create` | Snapshot created; listed in `nemoclaw <name> snapshot list` |
| 10 | Rollback | After rollback procedure, host returns to prior pin without state leakage |

## Rollback procedure

`git revert` alone is insufficient — the NVIDIA installer writes outside
the repo.

1. Run `nemoclaw uninstall --yes`.
2. Remove nvm/npm additions from `~/.bashrc` (look for `# nemoclaw` /
   `# nvm` blocks added by the installer).
3. Back up + remove `~/.nemoclaw`:

   ```bash
   cp -r ~/.nemoclaw ~/nemoclaw-backup-$(date +%Y%m%d)
   rm -rf ~/.nemoclaw
   ```

4. Destroy the current sandbox via `./scripts/components/nemoclaw/nemoclaw.sh --destroy`.
5. Revert the relevant code commit and push.
6. Reinstall the prior version with `./scripts/components/nemoclaw/nemoclaw.sh --install`.

For an in-place pin downgrade (no uninstall), set
`upstream.pinned_version` back in the manifest and run
`nemoclaw_install` with `NEMOCLAW_FORCE_REINSTALL=1`.

## See also

- [`CONTEXT.md`](CONTEXT.md) — operational runbook (boot-time forward,
  inference routing, dashboard auth recovery, working configuration,
  lessons learned).
- [`DEVIATIONS.md`](DEVIATIONS.md) — every deviation from the NVIDIA
  quickstart we currently carry.
- [`DEVIATIONS-history.md`](DEVIATIONS-history.md) — historical
  context for removed scaffolding and the v0.0.21 → v0.0.29 transition.
- `../../../docs/upstream/issues/NVIDIA-NemoClaw-*.md` — upstream issue
  mirrors we are tracking.
