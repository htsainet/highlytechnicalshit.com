# Darktable — References

## Upstream

- **Homepage**: <https://www.darktable.org/>
- **Source**: <https://github.com/darktable-org/darktable>
- **Snap package**: <https://snapcraft.io/darktable>
- **Documentation**: <https://docs.darktable.org/>

## Notes

- GPLv3+ license
- Snap provides latest stable without PPA management
- OpenCL GPU acceleration for image processing
- Command-line interface available via darktable-cli
