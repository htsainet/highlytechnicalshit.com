#!/usr/bin/env bash
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already done"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; exit 1; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

ENV_FILE=".env"

install_tailscale() {
  info "Installing Tailscale for Ubuntu 24.04 (noble)..."

  sudo apt-get update -qq
  sudo apt-get install -y ca-certificates curl

  curl -fsSL https://pkgs.tailscale.com/stable/ubuntu/noble.noarmor.gpg | \
    sudo tee /usr/share/keyrings/tailscale-archive-keyring.gpg >/dev/null
  curl -fsSL https://pkgs.tailscale.com/stable/ubuntu/noble.tailscale-keyring.list | \
    sudo tee /etc/apt/sources.list.d/tailscale.list >/dev/null

  sudo apt-get update -qq
  sudo apt-get install -y tailscale
}

# ── Step 1: Verify or install Tailscale ──────────────────────────────────────
step "1 — Verify or install Tailscale"

if ! tailscale version &>/dev/null; then
  warn "Tailscale not found. Bootstrapping the package repo and installing it now."
  install_tailscale
fi

if ! tailscale version &>/dev/null; then
  fail "Tailscale install failed. Check apt output above and re-run this script."
fi
info "Tailscale $(tailscale version | head -1) present."

# ── Step 2: Auth key ──────────────────────────────────────────────────────────
step "2 — Auth key"

# Check if already connected
TS_STATUS=$(tailscale status 2>&1 || true)
if echo "$TS_STATUS" | grep -qE "^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"; then
  TS_IP=$(tailscale ip -4 2>/dev/null || true)
  skip "Already connected (${TS_IP})"
  echo ""
  info "Tailscale status:"
  tailscale status
  exit 0
fi

# Read auth key from .env if present
TAILSCALE_AUTHKEY=""
if [ -f "$ENV_FILE" ]; then
  TAILSCALE_AUTHKEY=$(grep '^TAILSCALE_AUTHKEY=' "$ENV_FILE" | cut -d= -f2- | tr -d '[:space:]' || true)
fi

if [ -z "$TAILSCALE_AUTHKEY" ]; then
  echo ""
  warn "No TAILSCALE_AUTHKEY found in .env."
  echo "  Option A — Paste a reusable/ephemeral auth key from:"
  echo "             https://login.tailscale.com/admin/settings/keys"
  echo "  Option B — Press Enter to authenticate via browser URL instead."
  echo ""
  read -r -p "  Auth key (or Enter for browser auth): " TAILSCALE_AUTHKEY

  if [ -n "$TAILSCALE_AUTHKEY" ]; then
    echo "TAILSCALE_AUTHKEY=${TAILSCALE_AUTHKEY}" >> "$ENV_FILE"
    info "Auth key saved to .env."
  fi
else
  info "TAILSCALE_AUTHKEY found in .env: ${TAILSCALE_AUTHKEY:0:10}..."
fi

# ── Step 3: Connect ───────────────────────────────────────────────────────────
step "3 — Connect"

sudo systemctl enable --now tailscaled 2>/dev/null || true

if [ -n "$TAILSCALE_AUTHKEY" ]; then
  info "Authenticating with auth key..."
  sudo tailscale up --authkey="${TAILSCALE_AUTHKEY}"
else
  info "Starting browser-based auth..."
  echo ""
  warn "Copy the URL below and open it in a browser to authenticate."
  echo ""
  sudo tailscale up
fi

# ── Step 4: Status ────────────────────────────────────────────────────────────
step "4 — Status"

TS_IP=$(tailscale ip -4 2>/dev/null || echo "unknown")
info "Tailscale connected. IP: ${TS_IP}"
echo ""
tailscale status
echo ""
info "Your AI stack services are now reachable over Tailscale at ${TS_IP}:"
echo "  Open WebUI        : http://${TS_IP}:3000"
echo "  NemoClaw          : http://${TS_IP}:18789"
echo "  Ollama API        : http://${TS_IP}:11434"
echo "  Stable Diffusion  : http://${TS_IP}:7860"
echo ""
info "To disconnect: sudo tailscale down"
info "To re-auth:    sudo tailscale up"
