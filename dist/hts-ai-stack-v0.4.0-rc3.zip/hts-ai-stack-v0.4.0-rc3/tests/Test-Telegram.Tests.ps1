$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/telegram'
    $script:ComponentScript = Join-Path $script:ComponentDir 'telegram.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'telegram.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'telegram file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'telegram manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is telegram' {
        $script:Manifest.id | Should -Be 'telegram'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/telegram/telegram.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is telegram' {
        $script:Manifest.func_prefix | Should -Be 'telegram'
    }

    It 'category is comms' {
        $script:Manifest.category | Should -Be 'comms'
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'telegram component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines telegram_install function' {
        $script:ComponentContent | Should -Match 'telegram_install\s*\(\)'
    }

    It 'defines telegram_configure function' {
        $script:ComponentContent | Should -Match 'telegram_configure\s*\(\)'
    }

    It 'defines telegram_start function' {
        $script:ComponentContent | Should -Match 'telegram_start\s*\(\)'
    }

    It 'defines telegram_stop function' {
        $script:ComponentContent | Should -Match 'telegram_stop\s*\(\)'
    }

    It 'defines telegram_health function' {
        $script:ComponentContent | Should -Match 'telegram_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/telegram/telegram\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'telegram no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/telegram\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/telegram/telegram\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
