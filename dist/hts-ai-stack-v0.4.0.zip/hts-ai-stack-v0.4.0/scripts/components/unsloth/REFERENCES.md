# Unsloth References

Last updated: 2026-04-15

## Upstream

- [GitHub — unslothai/unsloth](https://github.com/unslothai/unsloth)

## Official documentation

- [Unsloth Docs](https://docs.unsloth.ai/)
- [Unsloth Wiki](https://github.com/unslothai/unsloth/wiki)
