#!/usr/bin/env bash
# 00-check-conflicts.sh — Pre-install conflict detection
#
# Detects existing installations of services that conflict with the AI stack
# using three methods: active port listeners, Docker container inspection, and
# filesystem paths / binaries.
#
# Severity:
#   CRITICAL — port actively bound by a non-stack process; stack cannot start
#   WARN     — service installed (binary/path/stopped container) but port free;
#              will not block install but may indicate a co-existing install
#
# Exit codes:
#   0 — clean, or user chose to continue
#   1 — user aborted, or --strict triggered on warnings
#
# Usage:
#   ./00-check-conflicts.sh            # interactive
#   ./00-check-conflicts.sh --force    # skip prompts, always continue
#   ./00-check-conflicts.sh --strict   # treat WARNs as abort conditions
#   ./00-check-conflicts.sh --quiet    # suppress detail, show summary only
#
# Environment:
#   HTSAI_FORCE_INSTALL=true          # equivalent to --force (set by install.sh)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
# shellcheck source=scripts/install/tooling/ui.sh
source "$REPO_DIR/scripts/install/tooling/ui.sh"

CYAN='\033[0;36m'; BOLD='\033[1m'; NC="${NC:-\033[0m}"
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK  ]${NC} $*"; }
crit()  { echo -e "${RED}[CRIT]${NC} $*"; }
skp()   { echo -e "${CYAN}[SKIP]${NC} $*"; }

# ── Flags ─────────────────────────────────────────────────────────────────────
FORCE=false
STRICT=false
QUIET=false
DETECT_ONLY=false

# Detection tracking vars — written to file for wizard pre-population
_D_OLLAMA=false;      _D_OLLAMA_PORT=false
_D_SD=false;          _D_SD_PORT=false
_D_BITNET=false
_D_VOICE=false
_D_NEMOCLAW=false
_D_OPENSHELL=false
_D_LLAMA_SWAP=false

# Accept env var set by install.sh --force-install
[[ "${HTSAI_FORCE_INSTALL:-false}" == "true" ]] && FORCE=true

while [[ $# -gt 0 ]]; do
  case "$1" in
    --force|-f)    FORCE=true;       shift ;;
    --strict)      STRICT=true;      shift ;;
    --quiet|-q)    QUIET=true;       shift ;;
    --detect-only) DETECT_ONLY=true; shift ;;
    *) echo "[FAIL] Unknown argument: $1" >&2; exit 1 ;;
  esac
done

# In detect-only mode: suppress all output (wizard will read the written file)
if "$DETECT_ONLY"; then
  info() { :; }; warn() { :; }; ok() { :; }; crit() { :; }; skp() { :; }
  exec 1>/dev/null
else
  htsai_banner "00 — Conflict Detection"
fi

# ── Findings ──────────────────────────────────────────────────────────────────
CRITS=()   # port actively in use by non-stack process
WARNS=()   # install detected but port not actively conflicting

add_crit() { CRITS+=("$1"); }
add_warn() { WARNS+=("$1"); }

# ── Detection helpers ─────────────────────────────────────────────────────────

# port_active <port> — returns 0 if something is listening on <port>
port_active() {
  local port="$1"
  # ss preferred (no root required); nc as fallback
  if command -v ss &>/dev/null 2>&1; then
    ss -tln 2>/dev/null | awk -v p=":$port" '$4 == p || $4 ~ ":" p "$" {found=1} END{exit !found}' && return 0
  fi
  nc -z -w1 127.0.0.1 "$port" 2>/dev/null && return 0
  return 1
}

# port_owned_by_stack <port> — returns 0 if our stack's Docker containers map this port
port_owned_by_stack() {
  local port="$1"
  command -v docker &>/dev/null 2>&1 || return 1
  docker ps --format '{{.Ports}}' 2>/dev/null | grep -q ":${port}->" && return 0
  return 1
}

# identify_service <port> — probe what's listening; returns a human-readable label
# Strategy:
#   1. Process name via ss --processes (instant, no network, may need same UID)
#   2. HTTP API probes against known service fingerprints (curl, 2s timeout)
#   3. HTTP Server header as fallback
# Returns "unknown service" if nothing matches.
identify_service() {
  local port="$1"
  local label="unknown service"

  # ── 1. Process name via ss ────────────────────────────────────────────────
  if command -v ss &>/dev/null; then
    local _pid _proc
    _pid=$(ss -tlnp "sport = :${port}" 2>/dev/null | grep -oP 'pid=\K[0-9]+' | head -1)
    if [[ -n "${_pid:-}" ]]; then
      if [[ -r "/proc/$_pid/comm" ]]; then
        _proc="$(cat "/proc/$_pid/comm")"
      else
        _proc="$(ps -p "$_pid" -o comm= 2>/dev/null || true)"
      fi
      [[ -n "${_proc:-}" ]] && label="${_proc} (pid ${_pid})"
    fi
  fi

  # ── 2. HTTP API probes ────────────────────────────────────────────────────
  command -v curl &>/dev/null || { echo "$label"; return; }
  local _url="http://127.0.0.1:${port}"
  local _body _health _stats

  _body=$(curl -sf --connect-timeout 2 --max-time 3 "$_url/" 2>/dev/null || true)

  # Ollama — root path returns plain text "Ollama is running"
  if echo "$_body" | grep -q "Ollama is running"; then
    echo "Ollama inference server"; return
  fi

  # BitNet / llama.cpp server — /health returns {"status":"ok"} or "loading model"
  _health=$(curl -sf --connect-timeout 2 --max-time 3 "$_url/health" 2>/dev/null || true)
  if echo "$_health" | grep -qiE '"status"\s*:\s*"(ok|loading.model)"'; then
    local _models
    _models=$(curl -sf --connect-timeout 2 --max-time 3 "$_url/v1/models" 2>/dev/null || true)
    if echo "$_models" | grep -qi "bitnet"; then
      echo "BitNet inference server"; return
    fi
    echo "llama.cpp-compatible inference server"; return
  fi

  # ComfyUI — /system_stats returns JSON with a "system" key
  _stats=$(curl -sf --connect-timeout 2 --max-time 3 "$_url/system_stats" 2>/dev/null || true)
  if echo "$_stats" | grep -qi '"system"'; then
    echo "ComfyUI"; return
  fi

  # Stable Diffusion WebUI (AUTOMATIC1111 / Forge) — Gradio-based
  if echo "$_body" | grep -qiE "stable.diffusion.webui|gradio"; then
    echo "Stable Diffusion WebUI"; return
  fi

  # Open WebUI
  if echo "$_body" | grep -qi "open.webui"; then
    echo "Open WebUI"; return
  fi

  # SillyTavern
  if echo "$_body" | grep -qi "sillytavern"; then
    echo "SillyTavern"; return
  fi

  # Coqui TTS server
  if echo "$_body" | grep -qi "coqui\|tts.server"; then
    echo "Coqui TTS server"; return
  fi

  # NemoClaw API status endpoint
  local _nemo
  _nemo=$(curl -sf --connect-timeout 2 --max-time 3 "$_url/api/status" 2>/dev/null || true)
  if echo "$_nemo" | grep -qi "nemoclaw"; then
    echo "NemoClaw"; return
  fi

  # ── 3. HTTP Server header fallback ────────────────────────────────────────
  local _server_hdr
  _server_hdr=$(curl -sfI --connect-timeout 2 --max-time 3 "$_url/" 2>/dev/null \
    | grep -i "^Server:" | head -1 | sed 's/^[Ss]erver:[[:space:]]*//' | tr -d '\r')
  [[ -n "${_server_hdr:-}" ]] && label="unknown HTTP service (${_server_hdr})"

  echo "$label"
}

# probe_live <port> <path> <grep_pattern>
# Tries GET http://127.0.0.1:<port><path> and checks response against <grep_pattern>.
# Sets _LAST_PROBE_LIVE=true on match. Always returns 0 (safe with set -e).
# Skipped entirely in detect-only mode.
_LAST_PROBE_LIVE=false
probe_live() {
  _LAST_PROBE_LIVE=false
  "$DETECT_ONLY" && return 0
  command -v curl &>/dev/null || return 0
  local port="$1" path="$2" pattern="$3"
  local _resp
  _resp=$(curl -sf --connect-timeout 2 --max-time 3 "http://127.0.0.1:${port}${path}" 2>/dev/null || true)
  echo "$_resp" | grep -qiE "$pattern" && _LAST_PROBE_LIVE=true || true
}

# _note_live <service> <found_var> <live> <port>
# Appends a live/not-serving note to the section output when something was found.
_note_live() {
  local svc="$1" found="$2" live="$3" port="$4"
  "$found" || return 0
  if "$live"; then
    warn "${svc} API confirmed live on :${port}"
  else
    skp "${svc} — installed but not currently serving on :${port}"
  fi
}

# docker_containers_matching <pattern> — prints matching container names (all, incl. stopped)
docker_containers_matching() {
  local pattern="$1"
  command -v docker &>/dev/null 2>&1 || return 0
  docker ps -a --format '{{.Names}}' 2>/dev/null | grep -iE "$pattern" || true
}

# is_stack_container <name> — returns 0 if name matches our known container naming convention
is_stack_container() {
  local name="$1"
  echo "$name" | grep -qE \
    "^hts-ai-(ollama|stable-diffusion|open-webui|dashboard|bitnet|sillytavern|comfyui|openshell|nemoclaw|openspace|gitea|llama-swap)(-gpu|-cpu|-prod|-test|-init)?(-[0-9]+)?$"
}

# check_port <label> <port> <section_found_var>
# Sets _LAST_CHECK_PORT_CONFLICT=true and adds to CRITS if port is actively
# bound by a non-stack process. Always returns 0 (safe with set -e).
check_port() {
  local label="$1"
  local port="$2"
  local -n _found_ref="$3"   # nameref to the section's _found flag variable
  _LAST_CHECK_PORT_CONFLICT=false

  if port_active "$port"; then
    if port_owned_by_stack "$port"; then
      skp "${label} port ${port} — owned by this stack (already running)"
    else
      local _msg="${label}: port ${port} in use"
      if ! "$DETECT_ONLY"; then
        local _id
        _id=$(identify_service "$port")
        _msg="${label}: port ${port} in use by: ${_id}"
      fi
      add_crit "$_msg"
      _found_ref=true
      _LAST_CHECK_PORT_CONFLICT=true
    fi
  fi
}

# ── Section: Ollama ───────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}── Ollama ──────────────────────────────────────────────────${NC}"

_ollama_found=false

check_port "Ollama" 11434 _ollama_found
"$_LAST_CHECK_PORT_CONFLICT" && _D_OLLAMA_PORT=true || true
check_port "Ollama" 11435 _ollama_found

# Bare-metal binary (not in the stack — stack runs Ollama in Docker)
_ollama_bin=""
for _p in /usr/local/bin/ollama /usr/bin/ollama "$HOME/.local/bin/ollama" "$HOME/bin/ollama"; do
  if [[ -x "$_p" ]]; then
    _ollama_bin="$_p"
    break
  fi
done
if [[ -z "$_ollama_bin" ]] && command -v ollama &>/dev/null 2>&1; then
  _ollama_bin="$(command -v ollama)"
fi
if [[ -n "$_ollama_bin" ]]; then
  add_warn "Ollama binary found: $_ollama_bin"
  _ollama_found=true
fi

# Data directory
if [[ -d "$HOME/.ollama" ]]; then
  add_warn "Ollama data directory found: ~/.ollama"
  _ollama_found=true
fi

# systemd service
if systemctl is-active --quiet ollama 2>/dev/null; then
  add_crit "Ollama systemd service is active — will conflict on port 11434"
  _ollama_found=true
elif systemctl is-enabled --quiet ollama 2>/dev/null; then
  add_warn "Ollama systemd service is enabled (not currently running)"
  _ollama_found=true
fi

# External Docker containers
while IFS= read -r cname; do
  [[ -z "$cname" ]] && continue
  is_stack_container "$cname" && continue
  add_warn "External Ollama container found: $cname"
  _ollama_found=true
done < <(docker_containers_matching "ollama")

# HTTP API verification
probe_live 11434 "/" "Ollama is running"
_note_live "Ollama" "$_ollama_found" "$_LAST_PROBE_LIVE" 11434

"$_ollama_found" || ok "Ollama — no conflicts detected"
"$_ollama_found" && _D_OLLAMA=true

# ── Section: Stable Diffusion ────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}── Stable Diffusion ────────────────────────────────────────${NC}"

_sd_found=false

check_port "Stable Diffusion" 7860 _sd_found
"$_LAST_CHECK_PORT_CONFLICT" && _D_SD_PORT=true || true
check_port "Stable Diffusion" 7861 _sd_found
check_port "ComfyUI"          8188 _sd_found

# Common bare-metal install paths
for _sd_path in \
    "$HOME/stable-diffusion-webui" \
    "$HOME/sd-webui-docker" \
    "$HOME/automatic1111" \
    "$HOME/invokeai" \
    "$HOME/ComfyUI" \
    "/opt/stable-diffusion-webui" \
    "/opt/invokeai"; do
  if [[ -d "$_sd_path" ]]; then
    add_warn "Stable Diffusion install found: $_sd_path"
    _sd_found=true
  fi
done

# External Docker containers
while IFS= read -r cname; do
  [[ -z "$cname" ]] && continue
  is_stack_container "$cname" && continue
  add_warn "External SD/image-gen container found: $cname"
  _sd_found=true
done < <(docker_containers_matching "stable.diffusion|automatic1111|invokeai|comfyui")

# HTTP API verification — probe WebUI (:7860) then ComfyUI (:8188)
probe_live 7860 "/" "gradio|stable.diffusion.webui|invokeai|fooocus"
if ! "$_LAST_PROBE_LIVE"; then
  probe_live 8188 "/system_stats" '"system"'
fi
_note_live "Stable Diffusion" "$_sd_found" "$_LAST_PROBE_LIVE" "7860/8188"

"$_sd_found" || ok "Stable Diffusion — no conflicts detected"
"$_sd_found" && _D_SD=true

# ── Section: BitNet ───────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}── BitNet / llama-swap ──────────────────────────────────────${NC}"

_bitnet_found=false

check_port "llama-swap / BitNet" 8080 _bitnet_found

# Bare-metal binary
if command -v bitnet &>/dev/null 2>&1; then
  add_warn "BitNet binary found: $(command -v bitnet)"
  _bitnet_found=true
fi

# Common install directories
for _bt_path in "$HOME/BitNet" "$HOME/bitnet" "/opt/bitnet"; do
  if [[ -d "$_bt_path" ]]; then
    add_warn "BitNet install directory found: $_bt_path"
    _bitnet_found=true
  fi
done

# External Docker containers
while IFS= read -r cname; do
  [[ -z "$cname" ]] && continue
  is_stack_container "$cname" && continue
  add_warn "External BitNet container found: $cname"
  _bitnet_found=true
done < <(docker_containers_matching "bitnet")

# llama-swap Docker containers (external)
while IFS= read -r cname; do
  [[ -z "$cname" ]] && continue
  is_stack_container "$cname" && continue
  add_warn "External llama-swap container found: $cname"
  _bitnet_found=true
  _D_LLAMA_SWAP=true
done < <(docker_containers_matching "llama.swap")

# HTTP API verification — llama.cpp /health endpoint (BitNet uses llama.cpp server)
probe_live 8080 "/health" '"status"'
_note_live "BitNet" "$_bitnet_found" "$_LAST_PROBE_LIVE" 8080

"$_bitnet_found" || ok "BitNet — no conflicts detected"
"$_bitnet_found" && _D_BITNET=true

# ── Section: Voice ────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}── Voice ───────────────────────────────────────────────────${NC}"

_voice_found=false

# Helper: check if a Python package is installed (pip show — faster than import)
_pip_has() { python3 -m pip show "$1" &>/dev/null 2>&1; }

# STT: Whisper
if command -v whisper &>/dev/null 2>&1; then
  add_warn "Whisper binary found: $(command -v whisper)"
  _voice_found=true
elif _pip_has openai-whisper; then
  add_warn "Python package 'openai-whisper' installed"
  _voice_found=true
fi

# STT: Faster-Whisper
if command -v faster-whisper &>/dev/null 2>&1; then
  add_warn "faster-whisper binary found: $(command -v faster-whisper)"
  _voice_found=true
elif _pip_has faster-whisper; then
  add_warn "Python package 'faster-whisper' installed"
  _voice_found=true
fi

# STT: Vosk
if _pip_has vosk; then
  add_warn "Python package 'vosk' installed"
  _voice_found=true
fi

# TTS: Piper — check binary locations (it ships as a pre-built executable)
for _p in /usr/local/bin/piper /usr/bin/piper "$HOME/.local/bin/piper" "$HOME/bin/piper"; do
  if [[ -x "$_p" ]]; then
    add_warn "Piper TTS binary found: $_p"
    _voice_found=true
    break
  fi
done
if ! "$_voice_found" && command -v piper &>/dev/null 2>&1; then
  add_warn "Piper TTS binary found: $(command -v piper)"
  _voice_found=true
fi

# TTS: Coqui
if _pip_has TTS; then
  add_warn "Python package 'TTS' (Coqui) installed"
  _voice_found=true
fi
# Coqui TTS server default port
check_port "Coqui TTS server" 5002 _voice_found

# HTTP API verification — Coqui TTS server (only HTTP-based voice service)
probe_live 5002 "/" "coqui|tts.server|text.to.speech"
_note_live "Coqui TTS" "$_voice_found" "$_LAST_PROBE_LIVE" 5002

"$_voice_found" || ok "Voice tools — none detected"
"$_voice_found" && _D_VOICE=true

# ── Section: NemoClaw ────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}── NemoClaw ────────────────────────────────────────────────${NC}"

_nemoclaw_found=false

check_port "NemoClaw" 18789 _nemoclaw_found
# Port 18790 reserved for future gVisor/Daytona sandbox (FEATURE-012, FEATURE-013)

if command -v nemoclaw &>/dev/null 2>&1; then
  add_warn "NemoClaw binary found: $(command -v nemoclaw)"
  _nemoclaw_found=true
fi

if [[ -d "$HOME/.nemoclaw" ]]; then
  add_warn "NemoClaw data directory found: ~/.nemoclaw"
  _nemoclaw_found=true
fi

# HTTP API verification
probe_live 18789 "/api/status" "nemoclaw"
_note_live "NemoClaw" "$_nemoclaw_found" "$_LAST_PROBE_LIVE" 18789

"$_nemoclaw_found" || ok "NemoClaw — no conflicts detected"
"$_nemoclaw_found" && _D_NEMOCLAW=true

# ── Section: htsclaw ─────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}── htsclaw ────────────────────────────────────────────────${NC}"

_htsclaw_found=false

check_port "htsclaw sandbox" 18792 _htsclaw_found
check_port "htsclaw gateway" 8083  _htsclaw_found

probe_live 18792 "/api/status" "htsclaw"
_note_live "htsclaw" "$_htsclaw_found" "$_LAST_PROBE_LIVE" 18792

"$_htsclaw_found" || ok "htsclaw — no conflicts detected"

# ── Section: OpenShell ───────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}── OpenShell ───────────────────────────────────────────────${NC}"

_openshell_found=false

for _p in /usr/local/bin/openshell /usr/bin/openshell; do
  if [[ -x "$_p" ]]; then
    add_warn "OpenShell binary found: $_p"
    _openshell_found=true
    break
  fi
done

# External Docker containers
while IFS= read -r cname; do
  [[ -z "$cname" ]] && continue
  is_stack_container "$cname" && continue
  add_warn "External OpenShell container found: $cname"
  _openshell_found=true
done < <(docker_containers_matching "openshell")

"$_openshell_found" || ok "OpenShell — no conflicts detected"
"$_openshell_found" && _D_OPENSHELL=true

# ── Write detection file for wizard pre-population ────────────────────────────
_DETECT_FILE="${TMPDIR:-/tmp}/htsai-detected.env"
{
  echo "HTSAI_DETECTED_AT=$(date +%s)"
  echo "HTSAI_DETECTED_OLLAMA=$_D_OLLAMA"
  echo "HTSAI_OLLAMA_PORT_CONFLICT=$_D_OLLAMA_PORT"
  echo "HTSAI_DETECTED_SD=$_D_SD"
  echo "HTSAI_SD_PORT_CONFLICT=$_D_SD_PORT"
  echo "HTSAI_DETECTED_BITNET=$_D_BITNET"
  echo "HTSAI_DETECTED_LLAMA_SWAP=$_D_LLAMA_SWAP"
  echo "HTSAI_DETECTED_VOICE=$_D_VOICE"
  echo "HTSAI_DETECTED_NEMOCLAW=$_D_NEMOCLAW"
  echo "HTSAI_DETECTED_OPENSHELL=$_D_OPENSHELL"
} > "$_DETECT_FILE"

# In detect-only mode, exit here — no summary/prompts needed
if "$DETECT_ONLY"; then exit 0; fi

# ── Section: Other stack ports ───────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}── Other Stack Ports ───────────────────────────────────────${NC}"

_other_found=false

_check_other_port() {
  local label="$1"
  local port="$2"
  if port_active "$port"; then
    if port_owned_by_stack "$port"; then
      skp "${label} port ${port} — owned by this stack"
    else
      local _msg="${label}: port ${port} in use"
      if ! "$DETECT_ONLY"; then
        local _id
        _id=$(identify_service "$port")
        _msg="${label}: port ${port} in use by: ${_id}"
      fi
      add_crit "$_msg"
      _other_found=true
    fi
  fi
}

_check_other_port "Dashboard (nginx)"   80
_check_other_port "Open WebUI"          3000
_check_other_port "OpenSpace agent"     5000
_check_other_port "SillyTavern prod"    6500
_check_other_port "SillyTavern test"    6501

"$_other_found" || ok "Other stack ports — no conflicts detected"

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}── Summary ─────────────────────────────────────────────────${NC}"

if [[ ${#CRITS[@]} -eq 0 && ${#WARNS[@]} -eq 0 ]]; then
  echo ""
  ok "All clear — no conflicts detected."
  echo ""
  exit 0
fi

if ! "$QUIET"; then
  if [[ ${#WARNS[@]} -gt 0 ]]; then
    echo ""
    warn "Existing installs detected (not actively blocking — install can proceed):"
    for w in "${WARNS[@]}"; do
      echo -e "  ${YELLOW}▸${NC} $w"
    done
  fi

  if [[ ${#CRITS[@]} -gt 0 ]]; then
    echo ""
    crit "Active port conflicts (will prevent stack containers from starting):"
    for c in "${CRITS[@]}"; do
      echo -e "  ${RED}▸${NC} $c"
    done
  fi
fi

echo ""

# Critical conflicts
if [[ ${#CRITS[@]} -gt 0 ]]; then
  if "$FORCE"; then
    warn "--force set: continuing despite critical conflicts. Stack start may fail."
  else
    echo -e "${RED}${BOLD}Critical port conflicts must be resolved before the stack can start.${NC}"
    echo ""
    echo "  Suggestions:"
    echo "    • Stop the conflicting service:  sudo systemctl stop ollama"
    echo "    • Or disable it:                 sudo systemctl disable --now ollama"
    echo "    • Then re-run:                   ./install.sh"
    echo ""
    echo "  To continue anyway (stack start may fail):"
    echo "    ./install.sh --force-install"
    echo ""
    read -rp "  Continue anyway? [y/N]: " _choice
    if [[ "${_choice,,}" != "y" && "${_choice,,}" != "yes" ]]; then
      echo "Aborted."
      exit 1
    fi
    warn "Continuing despite critical conflicts — stack start may fail."
  fi
fi

# Warn-only
if [[ ${#CRITS[@]} -eq 0 && ${#WARNS[@]} -gt 0 ]]; then
  if "$STRICT"; then
    echo -e "${RED}${BOLD}--strict: aborting due to warnings.${NC}"
    exit 1
  fi
  info "Warnings noted — continuing install."
fi

echo ""
exit 0
