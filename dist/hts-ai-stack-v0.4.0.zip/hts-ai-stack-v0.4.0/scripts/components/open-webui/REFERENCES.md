# Open WebUI References

Last updated: 2026-04-15

## Upstream

- [GitHub — open-webui/open-webui](https://github.com/open-webui/open-webui)

## Official documentation

- [Open WebUI Docs](https://docs.openwebui.com/)
