# Menus — Python Whiptail CLI

Last updated: 2026-04-11 10:00:00

## What happens here

Interactive TUI menus using Ubuntu's built-in whiptail (no extra dependencies).
Python calls whiptail via subprocess, collects user choices, then calls the
appropriate shell functions from `sandbox/`, `policies/`, and `personas/`.

## Files and structure

| File | Purpose |
|------|---------|
| `htsclaw-menu.py` | Main entry point — top-level menu (Setup / Teardown / Upgrade / Patch / Status) |

## Menu flow

```text
┌─────────────────────────────┐
│  htsclaw — Sandbox Manager  │
├─────────────────────────────┤
│  1. Setup (new sandbox)     │
│  2. Teardown (destroy)      │
│  3. Upgrade OpenClaw        │
│  4. Patch (npm audit fix)   │
│  5. Status / Health         │
│  6. Back                    │
└─────────────────────────────┘
```

### Setup prompts

1. Sandbox name (default: `hts-ai-openshell-htsclaw-gpu`)
2. Model selection (list from llama-swap `/v1/models`)
3. Policy presets — checklist (pypi, docker-hub, huggingface, etc.)
4. Agent personas — yes/no
5. Confirm and create

### Teardown prompts

1. Select sandbox to destroy (list from `openshell sandbox list`)
2. Confirm destruction
3. Optionally destroy gateway (if no sandboxes remain)

### Upgrade prompts

1. Select sandbox to upgrade
2. Show current vs latest OpenClaw version
3. Confirm upgrade (destroy + recreate, preserving config)

## Pattern

Follows existing `scripts/utils/reset-menu.py` — Python subprocess calls to
whiptail with stderr capture. Falls back to plain-text menu if whiptail is
unavailable.

## Tools and dependencies

- **whiptail** — Ubuntu built-in TUI toolkit (no install needed)
- **Python 3** — subprocess calls to whiptail, stdlib only
- **openshell CLI** — sandbox lifecycle (create, destroy, list, upgrade)
- **llama-swap** — model list endpoint (`/v1/models`) for selection menu

## What good looks like

- Zero extra pip dependencies — stdlib only (subprocess, json, os)
- Graceful fallback if whiptail missing
- All destructive actions require explicit confirmation
- Menu integrates into install wizard via `SANDBOX_ENGINE=htsclaw` in stack.json
