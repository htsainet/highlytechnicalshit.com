#!/usr/bin/env bash
# scripts/components/llama-swap.sh — llama-swap LLM router: install, start, health
#
# Standalone usage:
#   ./scripts/components/llama-swap.sh            # install + start + health
#   ./scripts/components/llama-swap.sh --health   # health check only
#   ./scripts/components/llama-swap.sh --stop     # stop llama-swap
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration ────────────────────────────────────────────────────────────
LLAMA_SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"
LLAMA_SWAP_CONFIG="$REPO_DIR/config/llama-swap.yaml"

# ── Functions ────────────────────────────────────────────────────────────────

# llamaswap_install — Pull the llama-swap image via compose
llamaswap_install() {
  step "llama-swap — pull image"
  compose_pull --profile llama-swap
  ok "llama-swap image pulled."
}

# llamaswap_configure — Validate config file exists
llamaswap_configure() {
  step "llama-swap — configure"
  if [[ ! -f "$LLAMA_SWAP_CONFIG" ]]; then
    fail "llama-swap config not found: $LLAMA_SWAP_CONFIG"
    return 1
  fi
  info "Config: $LLAMA_SWAP_CONFIG"
  info "Port: ${LLAMA_SWAP_PORT} (unified LLM endpoint)"
  ok "llama-swap configured."
}

# llamaswap_start — Bring up llama-swap via compose
llamaswap_start() {
  step "llama-swap — start"
  compose_up --profile llama-swap
  ok "llama-swap started on port ${LLAMA_SWAP_PORT}."
}

# llamaswap_stop — Bring down llama-swap
llamaswap_stop() {
  step "llama-swap — stop"
  compose_down --profile llama-swap
  ok "llama-swap stopped."
}

# llamaswap_health — Probe the llama-swap health endpoint
llamaswap_health() {
  health_probe "llama-swap :${LLAMA_SWAP_PORT}" "http://localhost:${LLAMA_SWAP_PORT}/health"
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      llamaswap_install
      llamaswap_configure
      llamaswap_start
      llamaswap_health
      ;;
    health)
      llamaswap_health
      ;;
    stop)
      llamaswap_stop
      ;;
  esac
fi
