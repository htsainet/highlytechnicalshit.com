#!/usr/bin/env bash
# scripts/components/nat-install.sh
# Simple installer for NVIDIA NeMo Agent Toolkit (nvidia-nat) with optional model pulls
# Places a Python venv by default at <repo>/.venv-nat and optionally downloads models.

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
DEFAULT_VENV="$REPO_DIR/.venv-nat"
MODELS_DIR_DEFAULT="$REPO_DIR/models/nat"

usage() {
  cat <<EOF
Usage: $(basename "$0") [options]

Options:
  --venv PATH           Path to python venv to create/use (default: $DEFAULT_VENV)
  --no-venv             Don't create/activate a venv; use current Python environment
  --extras X,Y,Z        Comma-separated extras to install (eval,a2a,config-optimizer)
  --models m1,m2,...    Comma-separated models to pull. Prefix with:
                          ollama:<model>  -> run 'ollama pull <model>' (if ollama in PATH)
                          hf:<repo-id>    -> download via huggingface_hub snapshot_download
  --models-dir PATH     Directory to save HF model snapshots (default: $MODELS_DIR_DEFAULT)
  --llm-endpoint URL    Optional LLM base_url to write into example workflow
  --workflow            Create a small example NAT workflow at scripts/components/nat-example.yml
  --dry-run             Validate args, create venv, and generate workflow — skip pip install and model pulls
  --help                Show this help

Examples:
  # Create venv, install nat + eval plugin
  ./scripts/components/nat-install.sh --extras eval,config-optimizer

  # Install and pull two models via ollama
  ./scripts/components/nat-install.sh --models ollama:gemma4:lite,ollama:gemma4

  # Install and download a HF repo snapshot
  ./scripts/components/nat-install.sh --models hf:mistralai/Mistral-3B-v1 --models-dir /var/tmp/nat-models

EOF
}

warn() { echo "WARNING: $*" >&2; }
info() { echo "INFO: $*" >&2; }
die() { echo "ERROR: $*" >&2; exit 1; }

# Default values
VENV="$DEFAULT_VENV"
USE_VENV=1
EXTRAS=""
MODELS=""
MODELS_DIR="$MODELS_DIR_DEFAULT"
LLM_ENDPOINT=""
CREATE_WORKFLOW=0
DRY_RUN=0

while [[ ${#} -gt 0 ]]; do
  case "$1" in
    --venv) shift; VENV="$1"; shift;;
    --no-venv) USE_VENV=0; shift;;
    --extras) shift; EXTRAS="$1"; shift;;
    --models) shift; MODELS="$1"; shift;;
    --models-dir) shift; MODELS_DIR="$1"; shift;;
    --llm-endpoint) shift; LLM_ENDPOINT="$1"; shift;;
    --workflow) CREATE_WORKFLOW=1; shift;;
    --dry-run) DRY_RUN=1; shift;;
    --help) usage; exit 0;;
    *) echo "Unknown argument: $1"; usage; exit 2;;
  esac
done

check_cmd() { command -v "$1" >/dev/null 2>&1 || return 1; }

# Create venv
create_and_activate_venv() {
  if [[ $USE_VENV -eq 0 ]]; then
    info "Skipping venv creation/activation (--no-venv). Using current environment."
    return 0
  fi

  if [[ -d "$VENV" && -f "$VENV/bin/activate" ]]; then
    info "Using existing venv: $VENV"
  else
    info "Creating venv at: $VENV"
    python3 -m venv "$VENV" || die "Failed to create venv"
  fi

  # shellcheck source=/dev/null
  source "$VENV/bin/activate"
  pip install --upgrade pip setuptools wheel >/dev/null
}

install_nat() {
  local pkg="nvidia-nat"
  if [[ -n "$EXTRAS" ]]; then
    local extras_clean
    extras_clean=$(echo "$EXTRAS" | tr -d ' ')
    pkg="nvidia-nat[${extras_clean}]"
  fi

  if [[ $DRY_RUN -eq 1 ]]; then
    info "[dry-run] Would install: $pkg"
    return 0
  fi

  info "Installing $pkg into environment"
  pip install --upgrade "$pkg" || die "pip install failed for $pkg"

  if check_cmd nat; then
    nat --version || warn "'nat' command exists but --version failed"
  else
    warn "'nat' CLI not found in PATH after install — make sure $VENV/bin is on PATH or use --no-venv"
  fi
}

pull_ollama_model() {
  local model="$1"
  if [[ $DRY_RUN -eq 1 ]]; then
    info "[dry-run] Would pull ollama model: $model"
    return 0
  fi
  if ! check_cmd ollama; then
    warn "ollama not found in PATH; skipping ollama pull for $model"
    return 0
  fi
  info "Pulling ollama model: $model"
  if ollama pull "$model"; then
    info "ollama: pulled $model"
  else
    warn "ollama pull failed for $model"
  fi
}

download_hf_model() {
  local repo="$1"
  local dest="$2"
  if [[ $DRY_RUN -eq 1 ]]; then
    info "[dry-run] Would download HF snapshot: $repo → $dest"
    return 0
  fi
  info "Downloading HF snapshot for $repo into $dest"
  pip install --upgrade huggingface_hub >/dev/null
  python3 - <<PY
from huggingface_hub import snapshot_download
import sys
repo = sys.argv[1]
dest = sys.argv[2]
print('snapshot_download', repo, '->', dest)
snapshot_download(repo, cache_dir=dest, local_files_only=False)
PY
  if [[ $? -ne 0 ]]; then
    warn "hf snapshot_download reported a problem for $repo"
  fi
}

install_models() {
  if [[ -z "$MODELS" ]]; then
    info "No models requested"
    return 0
  fi

  mkdir -p "$MODELS_DIR"
  IFS=',' read -ra MARR <<< "$MODELS"
  for m in "${MARR[@]}"; do
    read -r mtrim <<< "$m"
    case "$mtrim" in
      ollama:*)
        mdl="${mtrim#ollama:}"
        pull_ollama_model "$mdl"
        echo "ollama:$mdl" >> "$MODELS_DIR/models.txt"
        ;;
      hf:*)
        repo="${mtrim#hf:}"
        download_hf_model "$repo" "$MODELS_DIR/$repo"
        echo "hf:$repo" >> "$MODELS_DIR/models.txt"
        ;;
      *)
        warn "Unknown model prefix for '$mtrim' — expected ollama: or hf:. Skipping."
        echo "unknown:$mtrim" >> "$MODELS_DIR/models.txt"
        ;;
    esac
  done
  info "Model manifest written to $MODELS_DIR/models.txt"
}

write_example_workflow() {
  local out="$REPO_DIR/scripts/components/nat-example-workflow.yml"
  info "Writing example workflow to $out"
  cat > "$out" <<YML
# Example NeMo Agent Toolkit workflow (minimal)
functions:
  current_datetime:
    _type: current_datetime

llms:
  nim_llm:
    _type: nim
    model_name: meta/mistral-3b

workflow:
  _type: react_agent
  tool_names: [current_datetime]
  llm_name: nim_llm
  verbose: true
YML

  # If user provided LLM endpoint, add base_url to nim_llm block
  if [[ -n "$LLM_ENDPOINT" ]]; then
    info "Patching example workflow with base_url: $LLM_ENDPOINT"
    python3 - <<PY
from pathlib import Path
p = Path(r"$out")
s = p.read_text()
# Insert base_url under nim_llm block
s = s.replace('model_name: meta/mistral-3b', 'model_name: meta/mistral-3b\n    base_url: "' + r"$LLM_ENDPOINT" + '"')
p.write_text(s)
print('patched')
PY
  fi
  info "Example workflow written — edit as needed"
}

main() {
  if ! check_cmd python3; then
    die "python3 is required"
  fi

  if [[ $DRY_RUN -eq 1 ]]; then
    info "=== DRY RUN MODE ==="
  fi

  create_and_activate_venv
  install_nat
  install_models

  if [[ $CREATE_WORKFLOW -eq 1 ]]; then
    write_example_workflow
  fi

  local mode="Install"
  [[ $DRY_RUN -eq 1 ]] && mode="Dry-run"

  cat <<EOF

${mode} complete.
- venv: $VENV
- nat extras: ${EXTRAS:-none}
- models dir: $MODELS_DIR
- example workflow: $REPO_DIR/scripts/components/nat-example-workflow.yml (if created)

EOF

  if [[ $DRY_RUN -eq 0 ]]; then
    cat <<EOF
Next steps:
- Set NVIDIA_API_KEY if you intend to use NIM remote endpoints: export NVIDIA_API_KEY=...
- Use 'nat --help' to explore nat CLI.
- To run example workflow: nat run --config_file $REPO_DIR/scripts/components/nat-example-workflow.yml --input "Hello"

EOF
  fi
}

main "$@"
