$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/localai'
    $script:ComponentScript = Join-Path $script:ComponentDir 'localai.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'localai.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'localai file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'localai manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is localai' {
        $script:Manifest.id | Should -Be 'localai'
    }

    It 'category is inference' {
        $script:Manifest.category | Should -Be 'inference'
    }

    It 'profile is localai' {
        $script:Manifest.profile | Should -Be 'localai'
    }

    It 'dashboard port is 8080' {
        [int]$script:Manifest.dashboard.port | Should -Be 8080
    }

    It 'health URL targets readyz endpoint' {
        $script:Manifest.health.url | Should -Match 'readyz'
    }

    It 'script path points to component subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/localai/localai.sh'
    }

    It 'install_type is compose' {
        $script:Manifest.install_type | Should -Be 'compose'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'localai port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8080 is registered in portmap.json' {
        $script:Portmap.ports.'8080' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'8080'.service | Should -Be 'localai'
    }
}

# ── CLI flags ────────────────────────────────────────────────────────────────

Describe 'localai CLI flags' {

    BeforeAll {
        $script:ScriptContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'supports --install flag' {
        $script:ScriptContent | Should -Match '--install'
    }

    It 'supports --configure flag' {
        $script:ScriptContent | Should -Match '--configure'
    }

    It 'supports --start flag' {
        $script:ScriptContent | Should -Match '--start'
    }

    It 'supports --stop flag' {
        $script:ScriptContent | Should -Match '--stop'
    }

    It 'supports --restart flag' {
        $script:ScriptContent | Should -Match '--restart'
    }

    It 'supports --health flag' {
        $script:ScriptContent | Should -Match '--health'
    }

    It 'supports --status flag' {
        $script:ScriptContent | Should -Match '--status'
    }

    It 'supports --destroy flag' {
        $script:ScriptContent | Should -Match '--destroy'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'localai compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'localai service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'localai:'
    }

    It 'uses localai profile' {
        $script:ComposeContent | Should -Match 'localai'
    }

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/localai/Dockerfile' | Should -Exist
    }
}
