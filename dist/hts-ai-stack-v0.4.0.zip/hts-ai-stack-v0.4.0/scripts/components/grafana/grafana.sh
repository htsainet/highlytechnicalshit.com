#!/usr/bin/env bash
# scripts/components/grafana/grafana.sh — Grafana: install, configure, start, health
#
# Monitoring dashboards & alerting, backed by Prometheus.
#
# Standalone usage:
#   ./scripts/components/grafana/grafana.sh              # full: install + configure + start + health
#   ./scripts/components/grafana/grafana.sh --install    # install only (build image)
#   ./scripts/components/grafana/grafana.sh --configure  # configure only
#   ./scripts/components/grafana/grafana.sh --start      # start only
#   ./scripts/components/grafana/grafana.sh --stop       # stop
#   ./scripts/components/grafana/grafana.sh --restart    # restart (stop + start)
#   ./scripts/components/grafana/grafana.sh --health     # health check only
#   ./scripts/components/grafana/grafana.sh --status     # show status + port + health
#   ./scripts/components/grafana/grafana.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
GRAFANA_PORT="${GRAFANA_PORT:-3100}"
GRAFANA_USER="${GRAFANA_USER:-admin}"

# ── Functions ────────────────────────────────────────────────────────────────

grafana_install() {
  step "Grafana — install"
  local dockerfile="$REPO_DIR/docker/grafana/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    fail "Grafana Dockerfile not found: $dockerfile"
    return 1
  fi
  compose_build --profile monitoring
  ok "Grafana image built."
}

grafana_configure() {
  step "Grafana — configure"
  info "Admin user: ${GRAFANA_USER}"
  info "HTTP port:  ${GRAFANA_PORT}"

  # Ensure provisioning directories exist
  local prov_dir="$REPO_DIR/config/grafana/provisioning"
  local dash_dir="$REPO_DIR/config/grafana/dashboards"
  mkdir -p "$prov_dir" "$dash_dir"

  ok "Grafana configured."
}

grafana_start() {
  step "Grafana — start"
  compose_up --profile monitoring
  ok "Grafana started on port ${GRAFANA_PORT}."
}

grafana_stop() {
  step "Grafana — stop"
  compose_down --profile monitoring
  ok "Grafana stopped."
}

grafana_health() {
  local label="Grafana :${GRAFANA_PORT}"
  printf "  %-35s" "$label"
  if curl -sf "http://localhost:${GRAFANA_PORT}/api/health" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${GRAFANA_PORT}/api/health)"
    return 1
  fi
}

grafana_restart() {
  grafana_stop
  grafana_start
}

grafana_destroy() {
  step "Grafana — destroy"
  compose_down --profile monitoring -v
  ok "Grafana destroyed."
}

grafana_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=grafana" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Grafana is running (port ${GRAFANA_PORT})"
  else
    warn "Grafana is not running."
  fi
  grafana_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   grafana_install   ;;
    configure) grafana_configure ;;
    start)     grafana_start     ;;
    stop)      grafana_stop      ;;
    restart)   grafana_restart   ;;
    health)    grafana_health    ;;
    status)    grafana_status    ;;
    destroy)   grafana_destroy   ;;
    default)
      grafana_install
      grafana_configure
      grafana_start
      grafana_health
      ;;
  esac
fi
