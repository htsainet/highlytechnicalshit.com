#!/usr/bin/env bash
# scripts/lib/manifest.sh — Host install manifest (what did the stack install?)
# Source this file; do NOT run directly.
#
# Usage:
#   source "$REPO_DIR/scripts/lib/manifest.sh"
#   manifest_add "nvidia-driver" "apt" "560.35.03"
#   manifest_add "docker-ce"     "apt" "27.5.1"
#   manifest_add "nvm"           "curl" "0.39.7"
#
# Writes JSON entries to $REPO_DIR/logs/manifest.json.
# Each entry: { component, method, version, timestamp, script }

# Requires REPO_DIR (set by common.sh or caller)
MANIFEST_FILE="${REPO_DIR}/logs/manifest.json"

manifest_add() {
  local component="${1:?manifest_add: component name required}"
  local method="${2:?manifest_add: install method required (apt|snap|pip|curl|npm|manual)}"
  local version="${3:-unknown}"

  # Ensure logs directory and manifest file exist
  mkdir -p "$(dirname "$MANIFEST_FILE")"
  [[ -f "$MANIFEST_FILE" ]] || echo '[]' > "$MANIFEST_FILE"

  # Build JSON entry (uses jq if available, falls back to printf)
  local timestamp script_name entry
  timestamp="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  script_name="${BASH_SOURCE[1]:-unknown}"
  # Trim to repo-relative path
  script_name="${script_name#"$REPO_DIR/"}"

  if command -v jq &>/dev/null; then
    entry=$(jq -n \
      --arg c "$component" \
      --arg m "$method" \
      --arg v "$version" \
      --arg t "$timestamp" \
      --arg s "$script_name" \
      '{component:$c, method:$m, version:$v, timestamp:$t, script:$s}')

    # Upsert: replace existing entry for same component, or append
    local tmp
    tmp=$(jq --arg c "$component" --argjson e "$entry" \
      'if any(.[]; .component == $c)
       then map(if .component == $c then $e else . end)
       else . + [$e]
       end' "$MANIFEST_FILE")
    printf '%s\n' "$tmp" > "$MANIFEST_FILE"
  else
    # Fallback: append-only (no upsert without jq)
    local json
    json=$(cat "$MANIFEST_FILE")
    # Strip trailing ] and append
    json="${json%]}"
    [[ "$json" == "[" ]] || json="${json},"
    printf '%s{"component":"%s","method":"%s","version":"%s","timestamp":"%s","script":"%s"}]\n' \
      "$json" "$component" "$method" "$version" "$timestamp" "$script_name" > "$MANIFEST_FILE"
  fi
}
