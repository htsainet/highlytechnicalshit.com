#!/usr/bin/env bash
# 02-setup-docker.sh — Pull all stack images to local cache
#
# Run once after cloning, or any time you want to refresh images before
# starting the stack. Does not start any containers.
#
# To start the stack after pulling:
#   ./06-start-stack.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=setup/tooling/ui.sh
source "$SCRIPT_DIR/setup/tooling/ui.sh"

htsai_banner "02 — Docker Setup"

info() { echo -e "${GREEN}[INFO]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already exists"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; exit 1; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

# ── Pre-run checklist ─────────────────────────────────────────────────────────
checklist_start
if [ -f "$SCRIPT_DIR/.env" ]; then checklist_item true "1. .env tokens"; else checklist_item false "1. .env tokens"; fi
checklist_item false "2. Pull container images"
checklist_end

# ── Step 1: Verify .env ───────────────────────────────────────────────────────
step "1 — Check .env"

ENV_FILE="$SCRIPT_DIR/.env"

if [ -f "$ENV_FILE" ]; then
  skip ".env"
else
  fail ".env not found. Run ./01-autoinstall.sh to generate tokens, or create it manually:
  openssl rand -hex 32  # WEBUI_SECRET_KEY
  openssl rand -hex 32  # OPENCLAW_TOKEN"
fi

# Export .env so compose interpolation succeeds for nested compose files.
set -a
# shellcheck source=/dev/null
source "$ENV_FILE"
set +a

# ── Step 2: Pull images ───────────────────────────────────────────────────────
step "2 — Pull images"

info "Pulling root stack images..."

docker compose --env-file "$ENV_FILE" -f "$SCRIPT_DIR/docker-compose.yml" pull

for instance in prod test; do
  info "Pulling $instance instance images..."
  docker compose --env-file "$ENV_FILE" -f "$SCRIPT_DIR/instances/$instance/docker-compose.yml" pull
done

info "All images pulled."
echo ""
info "To start the stack, run:  ./06-start-stack.sh"

