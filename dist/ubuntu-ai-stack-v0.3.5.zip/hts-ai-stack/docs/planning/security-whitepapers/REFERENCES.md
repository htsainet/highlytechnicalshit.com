# Security Whitepapers — Tracking

Papers relevant to the security architecture of this stack.
Sourced from arXiv and cross-referenced against our [threat model](../security-review/CONTEXT.md).

**Status:** `queued` · `reading` · `complete` · `skipped`

| Priority | arXiv | Title | Status | Key Relevance | Details |
|----------|-------|-------|--------|---------------|---------|
| TIER 1 | 2603.26221 | Clawed and Dangerous | queued | 6-dimensional taxonomy, evaluation scorecard, reference doctrine for secure agent platforms | |
| TIER 1 | 2603.23064 | Mind Your HEARTBEAT | queued | OpenClaw background execution enables silent memory pollution | |
| TIER 1 | 2603.10387 | Don't Let the Claw Grip Your Hand | queued | 47 adversarial scenarios, 17% native defense rate | |
| TIER 1 | 2603.11619 | Taming OpenClaw | queued | Five-layer lifecycle security framework | |
| TIER 2 | 2602.11416 | Optimizing Agent Planning for Security and Autonomy | queued | Security-aware planning, autonomy metrics, HITL design | |
| TIER 2 | 2603.16572 | Malicious Or Not | queued | 238K skill ecosystem analysis, supply chain classification | |
| TIER 2 | 2602.06258 | GRP-Obliteration (Russinovich) | queued | Safety alignment removable with single prompt — affects local Ollama models | |
| TIER 2 | 2603.19469 | Framework for Formalizing LLM Agent Security | queued | Four security properties: task alignment, action alignment, source auth, data isolation | |
| TIER 3 | 2603.22868 | Agent-Sentry | queued | Behavioral bounding via execution provenance graphs | |
| TIER 3 | 2310.02238 | Who's Harry Potter? (Russinovich) | queued | LLM unlearning — lower priority | |
| TIER 3 | 2602.20044 | Let There Be Claws | queued | AI agent social network analysis — tangential | |
| TIER 3 | 2404.01833 | Crescendo (Russinovich) | queued | Multi-turn jailbreak attack — recommended addition | |
