# Component Tracker

This file is the single source of truth for the status of all external components used in the stack.

- **Integrated** – component already exists under `scripts/components/` with a manifest and install script.
- **Pending adoption** – component has been vetted and marked *Adopt* but is not yet integrated; a planning summary lives in `docs/planning/feature-repos/adopt-summaries/`.

---

## Integrated

| Component | Repository | Implementation | Notes |
|-----------|------------|----------------|-------|
| NVIDIA NemoClaw | https://github.com/NVIDIA/NemoClaw | [scripts/components/nemoclaw](scripts/components/nemoclaw) | Security sandbox, already wired into the stack |
| Ollama (core) | https://github.com/ollama/ollama | [scripts/components/ollama](scripts/components/ollama) | Local LLM inference engine |
| Open WebUI | https://github.com/open-webui/open-webui | [scripts/components/open-webui](scripts/components/open-webui) | Chat UI (port 3000) |

---

## Pending adoption (wish‑list)

| Component | Repository | Planning doc | Reason for adoption |
|-----------|------------|--------------|---------------------|
| OpenClaw (core) | https://github.com/openclaw/openclaw | [docs/planning/feature-repos/adopt-summaries/OpenClaw_OpenClaw.md](docs/planning/feature-repos/adopt-summaries/OpenClaw_OpenClaw.md) | Primary agent runtime, essential for all agents |
| Ollama Python SDK | https://github.com/ollama/ollama-python | [docs/planning/feature-repos/adopt-summaries/Ollama_OllamaPython.md](docs/planning/feature-repos/adopt-summaries/Ollama_OllamaPython.md) | Python client to talk to Ollama from agents |
| Ollama JS SDK | https://github.com/ollama/ollama-js | [docs/planning/feature-repos/adopt-summaries/Ollama_OllamaJS.md](docs/planning/feature-repos/adopt-summaries/Ollama_OllamaJS.md) | Node/TS client for UI extensions |
| ggml‑org Whisper.cpp | https://github.com/ggml-org/whisper.cpp | [docs/planning/feature-repos/adopt-summaries/ggml_org_WhisperCpp.md](docs/planning/feature-repos/adopt-summaries/ggml_org_WhisperCpp.md) | Offline, CUDA‑accelerated speech‑to‑text |
| ggml‑org Llama VSCode | https://github.com/ggml-org/llama.vscode | [docs/planning/feature-repos/adopt-summaries/ggml_org_LlamaVSCode.md](docs/planning/feature-repos/adopt-summaries/ggml_org_LlamaVSCode.md) | VS Code LLM completion plugin |
| ggml‑org Llama QtCreator | https://github.com/ggml-org/llama.qtcreator | [docs/planning/feature-repos/adopt-summaries/ggml_org_LlamaQtCreator.md](docs/planning/feature-repos/adopt-summaries/ggml_org_LlamaQtCreator.md) | Qt Creator LLM completion plugin |
| ggml‑org Llama Vim | https://github.com/ggml-org/llama.vim | [docs/planning/feature-repos/adopt-summaries/ggml_org_LlamaVim.md](docs/planning/feature-repos/adopt-summaries/ggml_org_LlamaVim.md) | Vim/Neovim LLM completion plugin |
| LeoYeAI OpenClaw Guardian | https://github.com/LeoYeAI/openclaw-guardian | [docs/planning/feature-repos/adopt-summaries/LeoYeAI_OpenClawGuardian.md](docs/planning/feature-repos/adopt-summaries/LeoYeAI_OpenClawGuardian.md) | Ops watchdog with auto‑repair & snapshots |
| NousResearch Hermes‑Agent | https://github.com/NousResearch/hermes-agent | [docs/planning/feature-repos/adopt-summaries/NousResearch_HermesAgent.md](docs/planning/feature-repos/adopt-summaries/NousResearch_HermesAgent.md) | Self‑improving AI agent, complements OpenClaw |
| agentscope‑ai HiClaw | https://github.com/agentscope-ai/HiClaw | [docs/planning/feature-repos/adopt-summaries/agentscope_ai_HiClaw.md](docs/planning/feature-repos/adopt-summaries/agentscope_ai_HiClaw.md) | Matrix‑based coordination layer |
| zeroclaw‑labs Zeroclaw | https://github.com/zeroclaw-labs/zeroclaw | [docs/planning/feature-repos/adopt-summaries/zeroclaw_labs_Zeroclaw.md](docs/planning/feature-repos/adopt-summaries/zeroclaw_labs_Zeroclaw.md) | Extremely lightweight Rust assistant (≤5 MB RAM idle) |
| win4r ClawTeam‑OpenClaw | https://github.com/win4r/ClawTeam-OpenClaw | [docs/planning/feature-repos/adopt-summaries/win4r_ClawTeamOpenClaw.md](docs/planning/feature-repos/adopt-summaries/win4r_ClawTeamOpenClaw.md) | Swarm coordination extension for OpenClaw |
| win4r OpenClaw A2A Gateway | https://github.com/win4r/openclaw-a2a-gateway | [docs/planning/feature-repos/adopt-summaries/win4r_OpenClawA2AGateway.md](docs/planning/feature-repos/adopt-summaries/win4r_OpenClawA2AGateway.md) | Standardized agent‑to‑agent communication gateway |
| MervinPraison PraisonAI | https://github.com/MervinPraison/PraisonAI | [docs/planning/feature-repos/adopt-summaries/MervinPraison_PraisonAI.md](docs/planning/feature-repos/adopt-summaries/MervinPraison_PraisonAI.md) | Docker‑based 24/7 AI employee automation |
| Gen‑Verse OpenClaw‑RL | https://github.com/Gen-Verse/OpenClaw-RL | [docs/planning/feature-repos/adopt-summaries/Gen_Verse_OpenClawRL.md](docs/planning/feature-repos/adopt-summaries/Gen_Verse_OpenClawRL.md) | RL training framework for OpenClaw agents |
| Milla‑Jovovich MemPalace | https://github.com/milla-jovovich/mempalace | [docs/planning/feature-repos/adopt-summaries/milla_jovovich_MemPalace.md](docs/planning/feature-repos/adopt-summaries/milla_jovovich_MemPalace.md) | Local‑first persistent memory layer (ChromaDB) |
| OpenClaw Skills (official) | https://github.com/openclaw/skills | [docs/planning/feature-repos/adopt-summaries/openclaw_Skills.md](docs/planning/feature-repos/adopt-summaries/openclaw_Skills.md) | Core skill pack that drops directly into OpenClaw |
| UnitOneAI SecuritySkills | https://github.com/UnitOneAI/SecuritySkills | [docs/planning/feature-repos/adopt-summaries/UnitOneAI_SecuritySkills.md](docs/planning/feature-repos/adopt-summaries/UnitOneAI_SecuritySkills.md) | Security‑focused skill utilities (port scans, CVE lookups) |
| mksglu Context‑Mode | https://github.com/mksglu/context-mode | [docs/planning/feature-repos/adopt-summaries/mksglu_ContextMode.md](docs/planning/feature-repos/adopt-summaries/mksglu_ContextMode.md) | Conversation truncation/compression for long‑context LLMs |
| Martian‑Engineering Lossless‑Claw | https://github.com/Martian-Engineering/lossless-claw | [docs/planning/feature-repos/adopt-summaries/Martian_Engineering_LosslessClaw.md](docs/planning/feature-repos/adopt-summaries/Martian_Engineering_LosslessClaw.md) | 8× token compression, critical for RTX 3060 VRAM limits |
| LeoYeAI OpenClaw Master Skills | https://github.com/LeoYeAI/openclaw-master-skills | [docs/planning/feature-repos/adopt-summaries/LeoYeAI_OpenClawMasterSkills.md](docs/planning/feature-repos/adopt-summaries/LeoYeAI_OpenClawMasterSkills.md) | Curated collection of useful OpenClaw skills |
| LeoYeAI OpenClaw Ultra Scraping | https://github.com/LeoYeAI/openclaw-ultra-scraping | [docs/planning/feature-repos/adopt-summaries/LeoYeAI_OpenClawUltraScraping.md](docs/planning/feature-repos/adopt-summaries/LeoYeAI_OpenClawUltraScraping.md) | Playwright‑based web‑scraping skill pack |
| nikilster ClawFlows | https://github.com/nikilster/clawflows | [docs/planning/feature-repos/adopt-summaries/nikilster_ClawFlows.md](docs/planning/feature-repos/adopt-summaries/nikilster_ClawFlows.md) | Workflow‑automation library for multi‑step tasks |
| builderz‑labs Mission Control | https://github.com/builderz-labs/mission-control | [docs/planning/feature-repos/adopt-summaries/builderz_labs_MissionControl.md](docs/planning/feature-repos/adopt-summaries/builderz_labs_MissionControl.md) | Visual task board & control panel for OpenClaw |
| TianyiDataScience Control Center | https://github.com/TianyiDataScience/openclaw-control-center | [docs/planning/feature-repos/adopt-summaries/TianyiDataScience_ControlCenter.md](docs/planning/feature-repos/adopt-summaries/TianyiDataScience_ControlCenter.md) | Advanced monitoring dashboard (metrics, logs) |
| grp06 OpenClaw Studio | https://github.com/grp06/openclaw-studio | [docs/planning/feature-repos/adopt-summaries/grp06_OpenClawStudio.md](docs/planning/feature-repos/adopt-summaries/grp06_OpenClawStudio.md) | Drag‑and‑drop IDE for building OpenClaw pipelines |

---

*Keep this file up‑to‑date as components move from Pending adoption to Integrated.*