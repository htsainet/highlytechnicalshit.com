$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/openspace'
    $script:ComponentScript = Join-Path $script:ComponentDir 'openspace.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'openspace.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'openspace file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'openspace manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is openspace' {
        $script:Manifest.id | Should -Be 'openspace'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/openspace/openspace.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is openspace' {
        $script:Manifest.func_prefix | Should -Be 'openspace'
    }

    It 'dashboard port is 3001' {
        [int]$script:Manifest.dashboard.port | Should -Be 3001
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'openspace component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines openspace_install function' {
        $script:ComponentContent | Should -Match 'openspace_install\s*\(\)'
    }

    It 'defines openspace_configure function' {
        $script:ComponentContent | Should -Match 'openspace_configure\s*\(\)'
    }

    It 'defines openspace_start function' {
        $script:ComponentContent | Should -Match 'openspace_start\s*\(\)'
    }

    It 'defines openspace_stop function' {
        $script:ComponentContent | Should -Match 'openspace_stop\s*\(\)'
    }

    It 'defines openspace_health function' {
        $script:ComponentContent | Should -Match 'openspace_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/openspace/openspace\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'openspace port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 3001 is registered in portmap.json' {
        $script:Portmap.ports.'3001' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'3001'.service | Should -Be 'openspace'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'openspace no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/openspace\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/openspace/openspace\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
