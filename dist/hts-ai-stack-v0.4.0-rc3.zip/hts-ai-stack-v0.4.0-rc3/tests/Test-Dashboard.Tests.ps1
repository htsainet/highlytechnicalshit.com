$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/dashboard'
    $script:ComponentScript = Join-Path $script:ComponentDir 'dashboard.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'dashboard.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'dashboard file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'dashboard manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is dashboard' {
        $script:Manifest.id | Should -Be 'dashboard'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/dashboard/dashboard.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is dashboard' {
        $script:Manifest.func_prefix | Should -Be 'dashboard'
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'dashboard component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines dashboard_install function' {
        $script:ComponentContent | Should -Match 'dashboard_install\s*\(\)'
    }

    It 'defines dashboard_configure function' {
        $script:ComponentContent | Should -Match 'dashboard_configure\s*\(\)'
    }

    It 'defines dashboard_start function' {
        $script:ComponentContent | Should -Match 'dashboard_start\s*\(\)'
    }

    It 'defines dashboard_stop function' {
        $script:ComponentContent | Should -Match 'dashboard_stop\s*\(\)'
    }

    It 'defines dashboard_health function' {
        $script:ComponentContent | Should -Match 'dashboard_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/dashboard/dashboard\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'dashboard no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/dashboard\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/dashboard/dashboard\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}

# ── Dashboard nginx proxy ───────────────────────────────────────────────────

Describe 'dashboard nginx proxy' {
    BeforeAll {
        $script:NginxConf = Get-Content -Path (Join-Path $script:RepoRoot 'config/dashboard-nginx.conf') -Raw
        $script:IndexHtml = Get-Content -Path (Join-Path $script:RepoRoot 'resources/dashboard/index.html') -Raw
    }

    It 'nginx config exists' {
        Join-Path $script:RepoRoot 'config/dashboard-nginx.conf' | Should -Exist
    }

    It 'nginx config defines health probe proxy route' {
        $script:NginxConf | Should -Match '/api/probe/'
    }

    It 'nginx config uses Docker DNS resolver' {
        $script:NginxConf | Should -Match '127\.0\.0\.11'
    }

    It 'nginx config defines cookie auth bridge route' {
        $script:NginxConf | Should -Match '/api/auth-bridge'
    }

    It 'dashboard JS defines authUrl helper for cookie auth' {
        $script:IndexHtml | Should -Match 'authUrl'
    }

    It 'dashboard JS loads notifications.json' {
        $script:IndexHtml | Should -Match 'notifications\.json'
    }

    It 'dashboard JS has action container in card template' {
        $script:IndexHtml | Should -Match 'card-action'
    }
}

# ── Dashboard services.json internalPort consistency ─────────────────────────

Describe 'dashboard services.json internalPort consistency' {
    BeforeAll {
        $script:Services = Get-Content -Path (Join-Path $script:RepoRoot 'resources/dashboard/services.json') -Raw | ConvertFrom-Json
    }

    It 'all Docker service entries have internalPort defined' {
        foreach ($section in $script:Services) {
            foreach ($svc in $section.items) {
                if ($svc.service -and -not $svc.placeholder) {
                    $svc.PSObject.Properties.Name | Should -Contain 'internalPort' -Because "$($svc.service) needs internalPort for nginx proxy"
                }
            }
        }
    }
}
