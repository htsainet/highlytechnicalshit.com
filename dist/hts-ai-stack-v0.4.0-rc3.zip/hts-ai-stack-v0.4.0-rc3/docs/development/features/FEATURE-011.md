# Dependency Version Dashboard & Image Pinning

**Priority:** MEDIUM
**Effort:** 6-8 hours
**Risk:** Low — static JSON generation + dashboard JS; no runtime service changes
**Target Release:** v0.5.0
**Depends on:** Nothing
**Blocks:** Nothing

## Scope

Pin all Docker images to specific version tags (replacing `:latest`) and add a
collapsible "Dependency Versions" section to the dashboard showing pinned
versions alongside latest available versions from upstream registries.

### Part 1 — Pin Docker Image Tags

Replace `:latest` tags in `docker-compose.yml` with specific, tested versions:

| Service | Current | Pin to |
|---------|---------|--------|
| gitea/gitea | latest | specific release tag |
| prom/prometheus | latest | specific release tag |
| gcr.io/cadvisor/cadvisor | latest | specific release tag |
| nvidia/dcgm-exporter | latest | specific release tag |
| grafana/grafana-oss | latest | specific release tag |
| portainer/portainer-ce | latest | specific release tag |
| tailscale/tailscale | latest | specific release tag |
| unsloth/unsloth | latest | specific release tag |

Already pinned (no change): `nginx:alpine`,
`siutin/stable-diffusion-webui-docker:cuda-13.2.0-v1.10.1-2026-03-17`.

Locally built images (`hts-ai-ollama-gpu`, `hts-ai-bitnet-cpu`,
`hts-ai-llama-swap`, `hts-ai-open-webui`, `hts-ai-deerflow`,
`openspace:latest`) track upstream via Dockerfile `FROM` — pin those base
image tags in the respective Dockerfiles.

### Part 2 — Version Collector Script

`scripts/utils/collect-versions.sh` generates
`resources/dashboard/versions.json` at install/build time:

```json
{
  "generated_at": "2026-04-08T14:30:00Z",
  "docker": [
    { "name": "grafana/grafana-oss", "pinned": "11.5.2", "registry": "docker.io" },
    { "name": "prom/prometheus", "pinned": "v3.3.0", "registry": "docker.io" }
  ],
  "npm": [
    { "name": "cspell", "pinned": "^10.0.0" },
    { "name": "markdownlint-cli2", "pinned": "^0.18.1" }
  ],
  "local_builds": [
    { "name": "hts-ai-ollama-gpu", "base_image": "ollama/ollama:0.6.2" },
    { "name": "hts-ai-open-webui", "base_image": "ghcr.io/open-webui/open-webui:v0.6.5" }
  ]
}
```

Sources:

- Docker image tags parsed from `docker-compose.yml` and `docker/*/Dockerfile`
- npm versions parsed from `package.json`
- Generated during `install.sh` and `build.sh`, or on-demand

### Part 3 — Dashboard Section

New collapsible section in `resources/dashboard/index.html` (same style as
existing sections) that:

1. Loads `versions.json` on page load
2. Optionally queries upstream registries for latest tags (best-effort, with
   timeout — dashboard still works if queries fail)
3. Renders a table per category:

```text
▼ DEPENDENCY VERSIONS (12)
──────────────────────────────────────────────────────────────

  Docker Images
  ┌─────────────────────────┬──────────┬──────────┬──────────┐
  │ Component               │ Pinned   │ Latest   │ Status   │
  ├─────────────────────────┼──────────┼──────────┼──────────┤
  │ grafana/grafana-oss     │ 11.5.2   │ 11.5.2   │ ✓        │
  │ prom/prometheus         │ v3.3.0   │ v3.4.1   │ ↑ update │
  │ portainer/portainer-ce  │ 2.25.1   │ 2.25.1   │ ✓        │
  └─────────────────────────┴──────────┴──────────┴──────────┘

  npm DevDependencies
  ┌─────────────────────────┬──────────┬──────────┬──────────┐
  │ Package                 │ Pinned   │ Latest   │ Status   │
  ├─────────────────────────┼──────────┼──────────┼──────────┤
  │ cspell                  │ ^10.0.0  │ 10.2.3   │ ✓        │
  │ markdownlint-cli2       │ ^0.18.1  │ 0.22.0   │ ↑ update │
  └─────────────────────────┴──────────┴──────────┴──────────┘
```

### Registry API Calls (Best-Effort)

| Registry | API | Rate limit |
|----------|-----|------------|
| Docker Hub | `GET /v2/{repo}/tags/list` | 100 pulls/6h (anon) |
| GitHub Container Registry | `GET /v2/{repo}/tags/list` | 60 req/h (anon) |
| npm | `GET https://registry.npmjs.org/{pkg}/latest` | Generous |

All lookups are optional — if a registry is unreachable the "Latest" column
shows `—` and the dashboard remains functional. Lookups happen client-side
in the browser with a 4-second timeout per request.

## Acceptance Criteria

- [ ] All Docker images in `docker-compose.yml` pinned to specific tags
- [ ] All Dockerfile `FROM` directives pinned to specific tags
- [ ] `collect-versions.sh` generates valid `versions.json`
- [ ] Dashboard renders version table from `versions.json`
- [ ] Dashboard shows latest available version when registry reachable
- [ ] Dashboard gracefully degrades when registry unreachable
- [ ] `versions.json` regenerated during `install.sh` and `build.sh`
- [ ] `npm install` produces a `package-lock.json` committed to repo
