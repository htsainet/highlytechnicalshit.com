#!/usr/bin/env bash
# scripts/components/crewai/crewai.sh — CrewAI Studio: install, configure, start, health
#
# CrewAI Studio is a Streamlit web UI for building and running CrewAI crews and
# flows.  Runs in Docker (hts-ai-crewai image); LLM calls route through
# llama-swap (OpenAI-compatible API) — no local GPU inference required.
#
# Web UI: http://localhost:8501
# Image:  hts-ai-crewai   (built from docker/crewai/Dockerfile)
# Source: https://github.com/strnad/CrewAI-Studio
#
# Standalone usage:
#   ./scripts/components/crewai/crewai.sh              # full: install + configure + start + health
#   ./scripts/components/crewai/crewai.sh --install    # build/pull image
#   ./scripts/components/crewai/crewai.sh --configure  # validate .env vars
#   ./scripts/components/crewai/crewai.sh --start      # docker compose up --profile crewai
#   ./scripts/components/crewai/crewai.sh --stop       # docker compose down --profile crewai
#   ./scripts/components/crewai/crewai.sh --restart    # stop + start
#   ./scripts/components/crewai/crewai.sh --health     # probe http://localhost:8501/_stcore/health
#   ./scripts/components/crewai/crewai.sh --status     # container status + health
#   ./scripts/components/crewai/crewai.sh --destroy    # remove containers + volumes
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
CREWAI_PORT="${CREWAI_PORT:-8501}"

# ── Functions ────────────────────────────────────────────────────────────────

# crewai_install — Build the hts-ai-crewai image via compose (clones upstream)
crewai_install() {
  step "CrewAI Studio — install"
  info "Building hts-ai-crewai image (clones CrewAI-Studio, installs Python deps)..."
  info "This build downloads Python packages — may take 5–10 min on first run."
  compose_pull --profile crewai
  ok "CrewAI Studio image ready."
}

# crewai_configure — Validate .env has required vars
crewai_configure() {
  step "CrewAI Studio — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^CREWAI_PORT=" "$env_file" 2>/dev/null; then
    printf 'CREWAI_PORT=%s\n' "$CREWAI_PORT" >> "$env_file"
    info "Added CREWAI_PORT=${CREWAI_PORT} to .env"
  fi

  info "Streamlit UI port: ${CREWAI_PORT}"
  info "LLM backend:       llama-swap (http://llama-swap:8080/v1 inside network)"
  info "Persistence:       YAML + run logs in crewai_data volume (/app/data)"
  ok "CrewAI Studio configured."
}

# crewai_start — Bring up the CrewAI Studio container
crewai_start() {
  step "CrewAI Studio — start"
  compose_up --profile crewai
  ok "CrewAI Studio started (UI :${CREWAI_PORT})."
}

# crewai_stop — Bring down the CrewAI Studio container
crewai_stop() {
  step "CrewAI Studio — stop"
  compose_down --profile crewai
  ok "CrewAI Studio stopped."
}

# crewai_health — Probe the Streamlit health endpoint
crewai_health() {
  health_probe "CrewAI Studio :${CREWAI_PORT}" \
    "http://localhost:${CREWAI_PORT}/_stcore/health"
}

crewai_restart() {
  crewai_stop
  crewai_start
}

crewai_destroy() {
  step "CrewAI Studio — destroy"
  compose_down --profile crewai -v
  ok "CrewAI Studio destroyed."
}

crewai_status() {
  local cid
  cid=$(docker ps -qf "name=hts-ai-crewai" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "CrewAI Studio is running (port ${CREWAI_PORT})"
  else
    warn "CrewAI Studio is not running."
  fi
  crewai_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   crewai_install   ;;
    configure) crewai_configure ;;
    start)     crewai_start     ;;
    stop)      crewai_stop      ;;
    restart)   crewai_restart   ;;
    health)    crewai_health    ;;
    status)    crewai_status    ;;
    destroy)   crewai_destroy   ;;
    default)
      crewai_install
      crewai_configure
      crewai_start
      crewai_health
      ;;
  esac
fi
