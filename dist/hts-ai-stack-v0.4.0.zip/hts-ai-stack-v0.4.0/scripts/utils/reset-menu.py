#!/usr/bin/env python3
"""Reset menu — Python + whiptail interactive teardown selector.

Presents a 3-tier destruction menu (each level includes everything above it):
  1. Nuke           Docker-only (containers, volumes, networks, images)
  2. Pave           Nuke + host cleanup → post-bootstrap state
  3. Wipe & Reload  ⚠ FULL TEARDOWN — Pave + reinstall from config

Usage:
  ./scripts/utils/reset-menu.py           # interactive whiptail menu
  ./scripts/utils/reset-menu.py --nuke    # skip menu, run nuke directly
  ./scripts/utils/reset-menu.py --pave    # skip menu, run pave directly
  ./scripts/utils/reset-menu.py --wipe    # skip menu, run wipe directly
"""

import os
import shutil
import subprocess
import sys

REPO_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
NUKE_SCRIPT = os.path.join(REPO_DIR, "nuke-stack.sh")

# ── Colors (for non-whiptail fallback output) ────────────────────────────────
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
CYAN = "\033[0;36m"
BOLD = "\033[1m"
NC = "\033[0m"


def has_whiptail() -> bool:
    return shutil.which("whiptail") is not None


def whiptail_menu() -> str | None:
    """Show a whiptail radiolist and return the selected tier tag, or None."""
    result = subprocess.run(
        [
            "whiptail",
            "--title",
            "AI Stack — Reset Options",
            "--menu",
            (
                "\n"
                "Choose a reset tier (each level includes everything above it):\n"
                "\n"
                "  Nuke           Remove Docker resources only\n"
                "\n"
                "  Pave           Nuke + remove host software → post-bootstrap\n"
                "\n"
                "  Wipe & Reload  ⚠ FULL TEARDOWN — Pave + reinstall from config\n"
            ),
            "22",
            "76",
            "3",
            "nuke",
            "Nuke — Remove Docker containers, volumes, networks, images",
            "pave",
            "Pave — Nuke + uninstall host software (back to bootstrap)",
            "wipe",
            "⚠ Wipe & Reload — FULL TEARDOWN: Pave then reinstall everything",
        ],
        stderr=subprocess.PIPE,
        text=True,
    )
    if result.returncode != 0:
        return None  # user pressed Cancel / Esc
    return result.stderr.strip()


def fallback_menu() -> str | None:
    """Plain-text fallback if whiptail is not available."""
    print(f"\n{CYAN}{BOLD}AI Stack — Reset Options{NC}")
    print(f"  {CYAN}Each level includes everything above it.{NC}\n")
    print(f"  {BOLD}[n]{NC} Nuke          — Remove Docker containers, volumes, networks, images")
    print()
    print(f"  {BOLD}[p]{NC} Pave          — Nuke + uninstall host software (back to bootstrap)")
    print()
    print(f"  {RED}{BOLD}[w]{NC} {RED}Wipe & Reload{NC} — {RED}⚠ FULL TEARDOWN:{NC} Pave then reinstall everything")
    print(f"  {BOLD}[q]{NC} Quit\n")

    while True:
        try:
            choice = input("  Select [n/p/w/q]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return None
        if choice in ("n", "nuke"):
            return "nuke"
        if choice in ("p", "pave"):
            return "pave"
        if choice in ("w", "wipe"):
            return "wipe"
        if choice in ("q", "quit", ""):
            return None
        print(f"  {YELLOW}Invalid choice — enter n, p, w, or q{NC}")


def run_tier(tier: str) -> int:
    """Execute nuke-stack.sh with the selected tier flag."""
    cmd = ["bash", NUKE_SCRIPT, f"--{tier}"]
    result = subprocess.run(cmd)
    return result.returncode


def main() -> int:
    # Allow direct tier selection via CLI flags
    if len(sys.argv) > 1:
        arg = sys.argv[1].lstrip("-")
        if arg in ("nuke", "pave", "wipe"):
            return run_tier(arg)
        if arg in ("h", "help"):
            print(__doc__)
            return 0
        print(f"{RED}Unknown argument: {sys.argv[1]}{NC}", file=sys.stderr)
        return 1

    # Interactive menu
    if has_whiptail():
        tier = whiptail_menu()
    else:
        tier = fallback_menu()

    if tier is None:
        print(f"\n{GREEN}[INFO]{NC} Cancelled — nothing was changed.")
        return 0

    return run_tier(tier)


if __name__ == "__main__":
    sys.exit(main())
