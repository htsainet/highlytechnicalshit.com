# OpenClaw Security Review — Session 1 Report

**Date:** March 30, 2026
**Scope:** arXiv paper review + codebase security assessment (hts-ai-stack v0.2.0)
**Reviewer:** Claude (Opus 4.6) — Security Architecture Review

---

## 1. Paper Inventory & Resolution

Your list of 8 arXiv IDs resolved as follows. Two IDs could not be matched to CS/security papers and may be mistyped:

| # | arXiv ID | Title | Relevance |
|---|----------|-------|-----------|
| 1 | **2602.11416** | *Optimizing Agent Planning for Security and Autonomy* | **HIGH** — Security-aware agent planning with information-flow control; introduces autonomy metrics for HITL decisions |
| 2 | **2603.23064** | *(Could not resolve — non-CS paper or mistyped)* | — |
| 3 | **2603.26221** | *(Could not resolve — non-CS paper or mistyped)* | — |
| 4 | **2603.16572** | *Malicious Or Not: Adding Repository Context to Agent Skill Classification* | **HIGH** — Largest empirical analysis of agent skill supply chain (238K skills); directly relevant to your OpenClaw skill security |
| 5 | **2603.10387** | *Don't Let the Claw Grip Your Hand: Security Analysis and Defense Framework for OpenClaw* | **CRITICAL** — Two-phase security analysis of OpenClaw; 47 adversarial scenarios; only 17% defense rate natively |
| 6 | **2602.20044** | *Let There Be Claws: An Early Social Network Analysis of AI Agents on Moltbook* | **LOW** — Social network analysis of AI agent platforms; tangential to your architecture |
| 7 | **2310.02238** | *Who's Harry Potter? Approximate Unlearning in LLMs* (Russinovich & Eldan) | **LOW** — LLM unlearning technique, not agent security. The Russinovich agent security paper you likely want is **2404.01833** (Crescendo multi-turn jailbreak) |
| 8 | **2602.06258** | *GRP-Obliteration: Unaligning LLMs With a Single Unlabeled Prompt* (Russinovich et al.) | **HIGH** — Shows safety alignment can be removed from LLMs with a single prompt via GRPO; applies to your local Ollama models |

**Bonus papers discovered during search (highly relevant):**

| arXiv ID | Title | Relevance |
|----------|-------|-----------|
| **2603.11619** | *Taming OpenClaw: Security Analysis and Mitigation of Autonomous LLM Agent Threats* | **CRITICAL** — Five-layer lifecycle security framework for OpenClaw specifically |
| **2603.22868** | *Agent-Sentry: Bounding LLM Agents via Execution Provenance* | **HIGH** — Behavioral bounding via functionality graphs; runtime anomaly detection for agents |
| **2603.19469** | *A Framework for Formalizing LLM Agent Security* | **HIGH** — Four security properties: task alignment, action alignment, source authorization, data isolation |

---

## 2. Key Findings from Papers — Mapped to Your Architecture

### 2.1 OpenClaw Has No Built-in Security (2603.10387, 2603.11619)

Both papers independently confirm what you've already intuited: OpenClaw's native architecture relies entirely on the backend LLM's own safety training for defense. Across 47 adversarial scenarios, OpenClaw showed an average defense rate of only 17%. The five-layer lifecycle framework from 2603.11619 identifies threats at each stage:

- **Initialization:** Skill supply chain contamination (malicious SKILL.md files)
- **Input:** Indirect prompt injection via retrieved documents, messages (Telegram, Signal)
- **Inference:** The LLM itself can be coerced — especially relevant since Mistral Nemo is a smaller model with weaker alignment
- **Decision:** Intent drift over long conversations
- **Execution:** Shell command execution with high privileges inside the container

**Your architecture's answer:** NemoClaw/OpenShell provides the missing enforcement layer. This is the right approach — but it must be configured correctly, which it currently isn't fully (see Section 3).

### 2.2 Skill Supply Chain Is a Real Attack Surface (2603.16572)

The skill ecosystem analysis found that automated scanners flag up to 46.8% of marketplace skills as malicious. After adding repository context (code alignment, metadata credibility), the true positive rate drops to 0.52% — but that 0.52% represents real threats across 238K skills. Your stack currently has one custom skill (`.openclaw/skills/stable-diffusion/SKILL.md`) which is benign, but any future skill additions from external sources need vetting.

**Your architecture's implications:**

- SillyTavern character cards function similarly to skills — they define agent behavior and can include system prompts that constitute injection vectors
- Git version control of character cards (your planned approach) is necessary but not sufficient — you also need pre-commit validation of card contents

### 2.3 Safety Alignment of Local Models Is Fragile (2602.06258)

GRP-Obliteration demonstrates that safety alignment can be removed from any open-weight LLM with a single unlabeled prompt and roughly 1 GPU-hour of fine-tuning. This is devastating for your threat model because:

- Mistral Nemo runs locally on Ollama — anyone with access to the machine can fine-tune it
- Even without fine-tuning, the Crescendo attack (Russinovich 2404.01833) shows that multi-turn conversations can gradually bypass alignment
- Your prod/test Ollama instances share GPU resources with no isolation between model loads

**Your architecture's answer:** OpenShell's network policy enforcement is the correct compensating control — even if the LLM is compromised, it cannot reach unauthorized endpoints. But this only works if the policy is comprehensive and correctly maintained.

### 2.4 Security-Aware Agent Planning (2602.11416)

This paper introduces the concept of autonomy metrics — measuring what fraction of consequential actions an agent can execute without human approval while preserving security. The key insight is that system-level defenses (like OpenShell's policy enforcement) actually increase autonomy because they provide deterministic guarantees, reducing the need for HITL approval on every action.

**Your architecture's implications:**

- Your "first agent tasked with keeping operations in line" maps directly to this paper's security-aware agent concept
- The paper's information-flow control defense is essentially what OpenShell implements at the network layer
- You should define a policy for which actions require HITL approval vs. which can be autonomous, calibrated to OpenShell's enforcement

### 2.5 Formalized Security Properties (2603.19469)

This paper proposes four properties that your architecture should verify:

1. **Task alignment** — Is the agent pursuing an authorized objective? → SillyTavern character cards define this
2. **Action alignment** — Does each individual action serve that objective? → OpenShell network policy partially enforces this
3. **Source authorization** — Is the instruction from an authenticated source? → Currently weak in your stack
4. **Data isolation** — Do information flows respect privilege boundaries? → Currently absent between agents

---

## 3. Codebase Security Assessment — hts-ai-stack v0.2.0

### 3.1 What's Working Well

- **.env is .gitignored** and generated with cryptographic randomness (`openssl rand -hex 32`). Tokens are `chmod 600`. Good.
- **Prod/test separation** with isolated Ollama instances, separate volumes, separate SillyTavern configs. Good architectural hygiene.
- **NemoClaw onboard uses `--non-interactive`** with explicit policy presets (`npm,pypi,telegram,huggingface`). This is deny-by-default with explicit allowlists.
- **robots.txt + dashboard-proxy** blocks crawlers from service discovery. The dashboard-proxy returns 403 for everything except `/robots.txt`.
- **Idempotent scripts** with skip-if-done guards throughout. Reduces risk of misconfiguration on re-runs.
- **Pre-commit checks** via PowerShell/Pester with markdown lint, shell syntax, shellcheck, config validation.

### 3.2 Security Gaps (Prioritized)

#### CRITICAL

**C1 — All services bind to 0.0.0.0 with no authentication layer.** Every service in your compose files exposes ports directly to the host network interface. Ollama (11434/11435), Open WebUI (3000/3001), SillyTavern (8001/8002), Stable Diffusion (7860/7861), Jenkins (8081), Whisper (9000), XTTS (8000), and the dashboard (80) are all accessible from any machine on the network. The SillyTavern init script explicitly sets `whitelistMode: false`, which disables IP-based access control.

**Remediation:** Bind all non-essential services to `127.0.0.1` in docker-compose port mappings (e.g., `"127.0.0.1:8001:8000"`). Use Tailscale or a reverse proxy with authentication for remote access. Alternatively, add a firewall rule (`ufw`) to restrict access to known IPs.

**C2 — Jenkins has no reverse proxy, no TLS, and default setup.** Jenkins on port 8081 with the `jenkins/jenkins:lts` image starts with a setup wizard that creates an admin account, but the initial admin password is stored in a Docker volume readable by anyone with Docker access. Jenkins is a high-value target — it can execute arbitrary code on the host.

**Remediation:** Bind Jenkins to `127.0.0.1:8081:8080`. Add a reverse proxy with authentication. Consider whether Jenkins should be in the same Docker network as AI services at all — it should likely be in its own network with explicit bridge rules.

**C3 — Flat Docker network.** All services share a single `ai-network` bridge. This means if any container is compromised, it has direct network access to every other service. A compromised Whisper container can reach Ollama, Jenkins, SillyTavern, and everything else.

**Remediation:** Segment into at least three networks: `frontend` (dashboard, Open WebUI, SillyTavern), `inference` (Ollama, SD, XTTS, Whisper), and `ops` (Jenkins). Only specific services should bridge between networks.

#### HIGH

**H1 — Ollama prod mounts `~/models/approved` as read-only, but the test instance mounts `~/models/testing`.** If the test Ollama instance is compromised, an attacker can read test model files. More importantly, both instances share the same GPU with `count: all`, meaning a malicious model could exhaust GPU memory and DoS the production inference.

**H2 — No observability stack.** Your TODO mentions OpenTelemetry but it's not implemented. Without centralized logging and metrics, you cannot detect prompt injection attempts, anomalous agent behavior, or policy violations. This is an audit gap from your threat model.

**H3 — SD WebUI runs with `--api --listen` and no authentication.** The Stable Diffusion API is unauthenticated and can generate arbitrary images. Combined with C1 (network exposure), anyone on the network can use your GPU for image generation.

**H4 — No data retention policy.** Whisper transcripts persist in `whisper_cache`, XTTS voice models in `xtts_models`, SD outputs in `sd_outputs_prod`. None have rotation, encryption, or access controls. Your threat model calls this out — you need a retention and cleanup policy.

**H5 — SillyTavern character cards are not validated.** Character cards (persona definitions, system prompts) are stored in Docker volumes with no integrity checking. A modified card could inject persistent prompt instructions that survive restarts. Since SillyTavern is your planned source of truth for agent behavior, card integrity is security-critical.

#### MEDIUM

**M1 — NemoClaw sandbox registry patched via Python script.** The `04-setup-nemoclaw.sh` script directly patches `~/.nemoclaw/sandboxes.json` to work around a NemoClaw bug. This bypasses NemoClaw's own state management and could cause drift between what NemoClaw thinks is configured and what's actually running.

**M2 — `COQUI_TOS_AGREED=1` hardcoded.** The XTTS container auto-accepts the Coqui TOS. This is a legal/compliance gap rather than a security gap, but worth noting.

**M3 — Build script uses `git archive` which includes everything at HEAD.** If sensitive test data or configs are accidentally committed, they'll be in the release zip. Consider an explicit inclusion list rather than archive-everything.

---

## 4. Gap Analysis — Your Vision vs. Current State

| Vision | Current State | Gap |
|--------|--------------|-----|
| Security-first architecture | NemoClaw/OpenShell provides policy enforcement, but host services are wide open | Network segmentation, auth, TLS needed |
| Snapshot & rollback for agent behavior | Not implemented | Need Git-based config versioning + automated snapshot comparison |
| Drift detection (prompt + capability) | Not implemented | Need baseline hashing of character cards + periodic comparison |
| Version control for agent configs | SillyTavern configs in Docker volumes, not Git | Need volume export → Git → diff pipeline |
| SillyTavern as source of truth | SillyTavern running but not integrated with version control or validation | Need card export, validation, and integrity checking |
| Audit trail | No centralized logging | Need OpenTelemetry or ELK stack |
| Agent-to-agent security | Not yet applicable (single agent) | Design isolation model before adding agents |

---

## 5. Feature & Functionality Ideas

**F1 — Character Card CI Pipeline.** Jenkins pipeline that: (a) exports SillyTavern character cards to Git, (b) runs a diff against the last known-good version, (c) flags any system prompt changes for human review, (d) computes a hash for integrity verification. This directly addresses drift detection.

**F2 — OpenShell Policy as Code.** Store your `openclaw-sandbox.yaml` policy files in Git. Jenkins pipeline validates policy changes and applies them via `openshell policy set`. This makes policy changes auditable and reversible.

**F3 — Behavioral Baseline Agent.** Your "operations agent" concept from the onboarding prompt. Based on the Agent-Sentry paper (2603.22868), this agent could build functionality graphs from observed behavior and flag deviations. Start simple: log all tool invocations and network requests, establish a baseline, alert on anomalies.

**F4 — Skill Vetting Pipeline.** Based on the skill ecosystem paper (2603.16572), implement a two-stage vetting process for any new OpenClaw skills: (a) static analysis of SKILL.md for suspicious patterns (credential access, network calls to unknown hosts, persistence mechanisms), (b) repository context check (repo age, activity, code alignment).

**F5 — Model Promotion Workflow.** Your prod/test Ollama split is the right foundation. Formalize it: models enter via `~/models/testing` on the test instance, undergo evaluation (including adversarial testing), and are promoted to `~/models/approved` for prod via a Jenkins pipeline with human approval gate.

---

## 6. Prioritized Next Steps

### Immediate (before any live data)

1. **Bind all ports to 127.0.0.1** — This is a 15-minute fix that eliminates the largest attack surface. Anything that needs remote access goes through Tailscale (already in your stack).
2. **Segment Docker networks** — Split `ai-network` into frontend/inference/ops zones.
3. **Enable SillyTavern basicAuth** — The init script sets `basicAuthMode: true` but you need to verify credentials are actually configured and not default.

### Short-term (v0.3.0 release)

1. **Add OpenTelemetry** — Start with log aggregation from all containers. You don't need full tracing yet — just centralized logs you can search.
2. **Git-track character cards and OpenShell policies** — Export from Docker volumes into the repo. Add to pre-commit checks.
3. **Define data retention policy** — Automated cleanup of Whisper transcripts, SD outputs, and XTTS audio after N days.

### Medium-term (v0.4.0+)

1. **Build the skill vetting pipeline** — Static analysis + repo context scoring for any new skills.
2. **Implement behavioral baseline** — Start logging agent actions, build the first functionality graph.
3. **Design multi-agent isolation model** — Before adding a second agent, define how agents communicate, what trust boundaries exist, and how OpenShell policies enforce them.

---

## 7. Recommended Paper Substitutions

For papers 2603.23064 and 2603.26221 (which I couldn't resolve), I recommend substituting:

- **2603.11619** — "Taming OpenClaw" — directly analyzes the platform you're building on
- **2603.22868** — "Agent-Sentry" — execution provenance and behavioral bounding, directly relevant to your drift detection goals
- **2404.01833** — Russinovich's "Crescendo" multi-turn jailbreak attack — the actual Russinovich agent security paper you likely intended

---

*End of Session 1 Report. Ready for repo review session when you provide the repo list.*
