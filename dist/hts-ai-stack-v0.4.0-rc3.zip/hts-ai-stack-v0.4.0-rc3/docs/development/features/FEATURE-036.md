# FEATURE-036 — RisuAI

## Metadata

| Field | Value |
|-------|-------|
| **Feature ID** | FEATURE-036 |
| **Title** | RisuAI — RP Chat with Emotion Sprites, Regex Scripting & Translation |
| **Priority** | LOW |
| **Effort** | 1–2 hours |
| **Risk** | Low (GPL-3.0, Docker available, single-container) |
| **Status** | Proposed |
| **Target** | v0.6.0 |
| **Depends on** | KoboldCpp (FEATURE-031) or llama-swap (FEATURE-003) |
| **Blocks** | nothing |
| **Repo** | [kwaroran/RisuAI](https://github.com/kwaroran/Risuai) |
| **License** | ⚠️ GPL-3.0 |
| **Stars** | 1,404 |
| **Language** | TypeScript (Svelte 5 + Tauri 2.5) |
| **Docker image** | Built from repo via official `docker-compose.yml` |
| **Default port** | 6001 |
| **Stack port** | 6001 |

---

## Problem / Rationale

The stack's RP/creative frontend slot is currently evaluating SillyTavern
(FEATURE-005) and Agnai (FEATURE-032). RisuAI adds a third contender with a
set of capabilities neither of the others provides:

- **Emotion images** — character expression sprites update dynamically based
  on model output sentiment/tags
- **Regex scripting** — post-process model output with regex to build custom
  GUI elements, formatting, or behaviour
- **Powerful translators** — automatic input/output translation so roleplay can
  happen across languages without the model needing to know the user's language
- **HypaMemoryV2/V3 + SupaMemory** — multi-tier long-term memory compression
  to maintain context across very long sessions
- **Plugins** — shareable feature/provider extensions
- **Tauri desktop build** — native cross-platform app (offline, no Docker
  required for desktop use)
- **MCP client** — tool-calling via Model Context Protocol

---

## RP Frontend Comparison

| Capability | SillyTavern | Agnai | RisuAI |
|---|---|---|---|
| **License** | AGPL-3.0 ⚠️ | AGPL-3.0 ⚠️ | GPL-3.0 ⚠️ |
| **Stars** | ~10k | 714 | 1,404 |
| **Docker** | Yes | Yes (GHCR) | Yes (official compose) |
| **KoboldCpp native** | ✅ | ✅ | ✅ (Ooba compat) |
| **Lorebook / world info** | ✅ | ✅ | ✅ |
| **Group chats** | ✅ | ✅ | ✅ |
| **Emotion sprites** | ✅ (Sprite sets) | ✗ | ✅ (Dynamic, expression-linked) |
| **Regex output scripting** | ✅ (STscript) | ✗ | ✅ (Native regex) |
| **Auto-translation** | Via extension | ✗ | ✅ Built-in |
| **Long-term memory compression** | Via extension | Pipeline | ✅ HypaMemory V2/V3 |
| **Plugins** | ✅ Extensions | ✗ | ✅ Shareable plugins |
| **MCP client** | ✗ | ✗ | ✅ |
| **TTS** | Via extension | ✗ | ✅ Built-in |
| **Desktop app (Tauri)** | ✗ | ✗ | ✅ |
| **No MongoDB req.** | ✅ | Guest mode only | ✅ |
| **Multi-user** | ✗ | ✅ (Docker) | ✗ |

**Evaluation note:** All three cover the core RP use case. Only one will be
deployed in the final stack. Evaluate based on UX preference, extension needs,
and community card/character support.

---

## Architecture

```text
Browser → RisuAI web UI (:6001)
                │
                └─ Svelte/Vite frontend (browser-side processing)
                        ├─ KoboldCpp → hts-ai-koboldcpp:5001 (FEATURE-031)
                        ├─ llama-swap → hts-ai-llama-swap:8081/v1
                        └─ OpenRouter / external APIs (optional)
```

RisuAI stores data in browser `localStorage` (web) or local files (Tauri
desktop). No server-side database required in either mode.

---

## Port Assignment

| Port | Purpose |
|------|---------|
| 6001 | RisuAI web UI |

Port 6001 is clear in the Host Port Map (checked 2026-04-12).

---

## Docker Service Sketch

```yaml
hts-ai-risuai:
  image: ghcr.io/kwaroran/risuai:latest
  container_name: hts-ai-risuai
  profiles: [risuai]
  ports:
    - "${RISUAI_PORT:-6001}:6001"
  restart: unless-stopped
```

**Note:** The official `docker-compose.yml` in the repo uses the GHCR image.
Confirm exact image tag before deployment — the repo compose pulls from
`ghcr.io/kwaroran/risuai` but verify the tag (`:latest` vs `:main`).

---

## Implementation Steps

1. Create `docs/development/features/FEATURE-036.md` (this file)
2. Add port 6001 to `REFERENCES.md` Host Port Map
3. Add `FEATURE-036` row to `docs/development/features/REFERENCES.md` v0.6.0 table
4. Add `kwaroran/RisuAI` row to `docs/planning/feature-repos/REFERENCES.md`
5. Write `scripts/components/risuai/risuai.sh` — `risuai_install`, `risuai_configure`,
   `risuai_start`, `risuai_stop`, `risuai_health`
6. Add `docker-compose.yml` service `hts-ai-risuai` under profile `risuai`
7. Add `.env.example` var: `RISUAI_PORT`
8. Validate: `curl http://localhost:6001` returns 200; UI loads in browser
9. Confirm KoboldCpp connection works as a backend provider

---

## Acceptance Criteria

- [ ] RisuAI UI loads on port 6001
- [ ] KoboldCpp or llama-swap connects as a provider
- [ ] Chat with a character card completes a round-trip
- [ ] `docker compose --profile risuai up` / `down` cycle is clean

---

## License Note

⚠️ **GPL-3.0** — copyleft applies on distribution of modified versions only.
Running a modified version as a private self-hosted service does **not** trigger
GPL-3.0 source disclosure (unlike AGPLv3, which covers network use). Private
homelab deployment is fully compliant.

---

## Notes

- **Tauri desktop alternative:** If Docker adds friction for a single-user
  creative workflow, the Tauri desktop build is a clean alternative — no
  container needed, no port conflict, data in local files.
- **Image tag:** Verify GHCR tag before pinning in `docker-compose.yml`.
  The repo's own compose uses the GHCR image; confirm it's current.
- **Single developer:** kwaroran maintains this solo. Active development
  (commits today) but lower bus factor than SillyTavern or Agnai.
- **MCP capability:** RisuAI is currently the only RP frontend in the stack
  evaluation that ships MCP client support natively.
- **Card compatibility:** SillyTavern character cards (PNG spec) are broadly
  compatible across all three RP frontends.
