#!/usr/bin/env bash
# scripts/components/open-sora/open-sora.sh — Open-Sora: install, configure, start, health
#
# HPC-AI Tech Open-Sora — text-to-video generation framework.
# ⚠️ REQUIRES ≥24GB VRAM — the 1B model (v1.3) needs ~24GB minimum.
# Install will check VRAM and block if insufficient.
#
# Standalone usage:
#   ./scripts/components/open-sora/open-sora.sh              # full: install + configure + start + health
#   ./scripts/components/open-sora/open-sora.sh --install    # install only (VRAM check + build image)
#   ./scripts/components/open-sora/open-sora.sh --configure  # configure only
#   ./scripts/components/open-sora/open-sora.sh --start      # start only
#   ./scripts/components/open-sora/open-sora.sh --stop       # stop
#   ./scripts/components/open-sora/open-sora.sh --restart    # restart (stop + start)
#   ./scripts/components/open-sora/open-sora.sh --health     # health check only
#   ./scripts/components/open-sora/open-sora.sh --status     # show status + port + health
#   ./scripts/components/open-sora/open-sora.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"
source "$REPO_DIR/scripts/lib/gpu.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
OPEN_SORA_PORT="${OPEN_SORA_PORT:-7862}"
OPEN_SORA_VRAM_MIN_GB=24

# ── Functions ────────────────────────────────────────────────────────────────

open_sora_install() {
  step "Open-Sora — install"

  if ! check_vram_requirement "$OPEN_SORA_VRAM_MIN_GB"; then
    warn "Skipping Open-Sora build — insufficient VRAM."
    warn "Component is registered in the stack and will activate when VRAM ≥${OPEN_SORA_VRAM_MIN_GB}GB."
    return 0
  fi

  local dockerfile="$REPO_DIR/docker/open-sora/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    warn "Open-Sora Dockerfile not found: $dockerfile"
    return 1
  fi
  compose_build --profile open-sora
  ok "Open-Sora image built."
}

open_sora_configure() {
  step "Open-Sora — configure"
  if ! check_vram_requirement "$OPEN_SORA_VRAM_MIN_GB"; then
    return 0
  fi
  info "Gradio UI port: ${OPEN_SORA_PORT}"
  info "Model: Open-Sora v1.3 (1B params, ~24GB VRAM)"
  ok "Open-Sora configured."
}

open_sora_start() {
  step "Open-Sora — start"
  if ! check_vram_requirement "$OPEN_SORA_VRAM_MIN_GB"; then
    warn "Cannot start Open-Sora — insufficient VRAM."
    return 1
  fi
  compose_up --profile open-sora
  ok "Open-Sora started on port ${OPEN_SORA_PORT}."
}

open_sora_stop() {
  step "Open-Sora — stop"
  compose_down --profile open-sora
  ok "Open-Sora stopped."
}

open_sora_health() {
  local label="Open-Sora :${OPEN_SORA_PORT}"
  printf "  %-35s" "$label"

  local vram_gb
  vram_gb=$(get_gpu_vram_gb)
  if [[ "$vram_gb" -lt "$OPEN_SORA_VRAM_MIN_GB" ]]; then
    echo -e "${YELLOW}SKIP${NC} (requires ≥${OPEN_SORA_VRAM_MIN_GB}GB VRAM, have ${vram_gb}GB)"
    return 0
  fi

  if curl -sf "http://localhost:${OPEN_SORA_PORT}/" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${OPEN_SORA_PORT}/)"
    return 1
  fi
}

open_sora_restart() {
  open_sora_stop
  open_sora_start
}

open_sora_destroy() {
  step "Open-Sora — destroy"
  compose_down --profile open-sora -v
  ok "Open-Sora destroyed."
}

open_sora_status() {
  step "Open-Sora — status"
  local vram_gb
  vram_gb=$(get_gpu_vram_gb)
  info "GPU VRAM: ${vram_gb}GB (minimum: ${OPEN_SORA_VRAM_MIN_GB}GB)"

  if [[ "$vram_gb" -lt "$OPEN_SORA_VRAM_MIN_GB" ]]; then
    warn "Open-Sora is registered but CANNOT RUN on current hardware."
    warn "Upgrade GPU to ≥${OPEN_SORA_VRAM_MIN_GB}GB VRAM to enable."
  else
    local cid
    cid=$(docker ps -qf "label=com.docker.compose.service=open-sora" 2>/dev/null)
    if [[ -n "$cid" ]]; then
      ok "Open-Sora is running (port ${OPEN_SORA_PORT})"
    else
      warn "Open-Sora is not running."
    fi
  fi
  open_sora_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   open_sora_install   ;;
    configure) open_sora_configure ;;
    start)     open_sora_start     ;;
    stop)      open_sora_stop      ;;
    restart)   open_sora_restart   ;;
    health)    open_sora_health    ;;
    status)    open_sora_status    ;;
    destroy)   open_sora_destroy   ;;
    default)
      open_sora_install
      open_sora_configure
      open_sora_start
      open_sora_health
      ;;
  esac
fi
