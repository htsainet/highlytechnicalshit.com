# Repo Review — Batch 1 (Partial)

**Date:** March 30, 2026
**Repos reviewed this batch:** 2 of 6 planned (rate limits)
**Remaining for next session:** adversa-ai/secureclaw, tophant-ai/ClawVault, Atlas-Cowork/openclaw-reference-setup, Tencent/AI-Infra-Guard, gendigitalinc/sage, sinewaveai/agent-security-scanner-mcp, pegasi-ai/clawreins, SeyZ/clawbands, Drakon-Systems-Ltd/ShieldCortex

---

## Repo 1: slowmist/openclaw-security-practice-guide

**Stars:** 185 | **Forks:** 16 | **Trust:** HIGH → upgrade to HIGH-ADOPT
**Also discovered:** slowmist/slowmist-agent-security (companion skill)

### What It Is

A three-layer "Agentic Zero-Trust Architecture" defense guide designed to be injected
directly into OpenClaw's cognition — not a human checklist. SlowMist calls it a
"Mental Seal" (思想钢印) — reshaping the agent's baseline judgment rather than
adding external tools.

### Three-Layer Defense Matrix

1. **Pre-action:** Behavior blacklist (red/yellow lines) + skill installation audit
   - Red lines: exfiltration (curl/wget tokens externally), reverse shells, auth tampering,
     code injection (base64 -d | bash, eval "$(curl)"), blind dependency installation
   - Supply chain defense: full-text scan of skills before installation

2. **In-action:** Permission narrowing + hash baselines + audit logs + pre-flight checks
   - Cross-skill business risk controls before high-risk operations
   - Human confirmation required for irreversible actions

3. **Post-action:** Nightly automated audit (13 core metrics, ALL explicitly reported
   including green lights) + OpenClaw brain Git backup
   - Config baseline hash verification
   - Gateway process environment variable scanning for leaked secrets
   - Regex scanning for private keys and mnemonics in workspace

### Companion Skill: slowmist-agent-security

Installable OpenClaw skill with structured review frameworks for:

- Skill/MCP review (supply chain)
- GitHub repo review
- URL/document review
- On-chain address review
- Product/service review
- Social share review

Includes pattern libraries: 11 red-flag code patterns, 8 social engineering patterns,
7 supply chain attack patterns. Plus report templates for each review type.

### Direct Mapping to Your Stack

| SlowMist Concept | Your Component | Action |
|-----------------|---------------|--------|
| Nightly audit script | Not implemented | Adopt their script as starting point for your observability gap |
| Git brain backup | Not implemented | This IS your version-controlled agent config — adopt immediately |
| Red-line blacklist | OpenShell network policy | Complementary — SlowMist covers behavior, OpenShell covers network |
| Skill installation audit | Not implemented | Adopt their full-text scan approach for any skill additions |
| Hash baseline | Not implemented | Implement for openclaw.json, OpenShell policy YAML, character cards |
| Pre-flight checks | OpenShell HITL approval | Complementary — different enforcement layers |

### Risks / Caveats

- The guide itself acknowledges it can be bypassed via prompt injection of the guide contents
- Relies on "Agent strict compliance" for behavior conventions — not hard enforcement
- Explicitly distinguishes ✅ Hard Controls (OS/kernel enforced) from ⚡ Behavior Conventions (bypassable)
- Does NOT replace NemoClaw/OpenShell — it's a complementary layer

### Verdict

**ADOPT.** Install the slowmist-agent-security skill. Adapt the nightly audit script
for your stack. Implement Git brain backup. This is the most mature, practical
OpenClaw security framework I've seen. It directly addresses 4 of your threat model items:
prompt injection, skill supply chain, audit gaps, and sensitive data retention.

**Update trust level:** HIGH → HIGH-ADOPT. Add to your references list.
**Also add:** slowmist/slowmist-agent-security (not in your current list).

---

## Repo 2: prompt-security/clawsec

**Stars:** 551 | **Forks:** 57 | **Trust:** HIGH → upgrade to HIGH-ADOPT
**Org:** Prompt Security / SentinelOne (major security companies)

### What It Is

A complete security skill suite — "skill of skills" installer that deploys, verifies,
and maintains multiple security skills. Backed by Prompt Security (acquired by
SentinelOne), which gives it serious credibility.

### Skills Included

| Skill | Function |
|-------|----------|
| clawsec-suite | Meta-installer — orchestrates all other skills |
| clawsec-feed | Live NVD CVE advisory feed, auto-polling |
| clawsec-scanner | Vulnerability scanner (deps + SAST + OpenClaw DAST) |
| clawsec-nanoclaw | NanoClaw platform security |
| clawsec-clawhub-checker | ClawHub skill reputation checks |
| clawtributor | Community incident reporting (opt-in, shares anonymized data) |
| openclaw-audit-watchdog | Automated audit |
| prompt-age* | (Name truncated in search results — likely prompt aging/rotation) |

### Key Features for Your Stack

1. **Drift detection for SOUL.md / IDENTITY.md** — This is EXACTLY your persona drift
   detection requirement. ClawSec monitors critical agent identity files and auto-restores
   them if modified. Maps directly to your SillyTavern-as-source-of-truth concept.

2. **SHA256 checksum verification** — Every skill artifact is checksummed. This addresses
   the skill supply chain threat from paper 2603.16572.

3. **NVD CVE feed** — Automated vulnerability advisory polling. Covers your audit gap
   for dependency vulnerabilities.

4. **SBOM manifests** — Every contributed skill requires an SBOM in skill.json. This is
   the kind of supply chain transparency the skill ecosystem paper recommends.

### Direct Mapping to Your Stack

| ClawSec Concept | Your Component | Action |
|----------------|---------------|--------|
| SOUL.md drift detection | SillyTavern character cards | This replaces SillyTavern for drift detection |
| SHA256 skill verification | Not implemented | Adopt — verify any skill before loading |
| NVD CVE feed | Not implemented | Adopt — automated vulnerability awareness |
| Audit watchdog | Not implemented | Evaluate alongside SlowMist's nightly audit |
| ClawHub reputation checks | Not implemented | Use when evaluating skill additions |

### Risks / Caveats

- clawtributor shares anonymized incident data externally — opt-in only, but note the
  data flow for your threat model
- AGPL-3.0 license — if you modify and distribute, you must release source
- Prompt Security was acquired by SentinelOne — corporate backing is good for longevity
  but could mean future licensing changes

### Verdict

**ADOPT.** The drift detection alone is worth it. Install clawsec-suite, skip
clawtributor for now (data sharing concern). Use alongside SlowMist's guide —
they're complementary: SlowMist provides the behavioral framework and nightly audit,
ClawSec provides the skill-level verification and drift detection tooling.

**Update trust level:** HIGH-ADOPT
**Complementary with:** slowmist/openclaw-security-practice-guide (no conflict)

---

## Also Discovered: knownsec/openclaw-security

Already in your list but worth noting — Knownsec is another established Chinese security
firm. Their guide is more traditional (human-facing hardening checklist) compared to
SlowMist's agent-facing approach. Includes a Python audit script. Worth reviewing as
a third perspective alongside SlowMist and ClawSec.

## Also Discovered: hackerbot-claw incident

During the ClawSec search, found a real-world attack case study from StepSecurity:
an autonomous agent called "hackerbot-claw" systematically exploited GitHub Actions
workflows across Microsoft, DataDog, and CNCF repos in Feb-March 2026. Used prompt
injection via poisoned CLAUDE.md files to manipulate AI code reviewers. This is a
live example of the supply chain attack your threat model describes. Worth reading
the full StepSecurity writeup for your paper reviews.

---

## Updated Recommendations

Based on these two repos, my Session 1 recommendations change:

1. **Observability gap** — No longer "implement from scratch." Adopt SlowMist's
   nightly audit script + ClawSec's audit watchdog. Customize for your stack.

2. **Drift detection** — No longer theoretical. ClawSec has working drift detection
   for agent identity files. Deploy it.

3. **Skill vetting pipeline** — No longer "design from scratch." SlowMist's
   agent-security skill has structured review frameworks with templates. Adopt them.

4. **Character card integrity** — ClawSec's SOUL.md monitoring is more practical than
   the SillyTavern Git export pipeline I proposed in Session 1. Use ClawSec for runtime
   monitoring, Git for version history.

5. **New recommendation: Install both.** SlowMist guide + ClawSec suite are
   complementary, not competing. SlowMist = behavioral framework + nightly audit.
   ClawSec = skill verification + drift detection + CVE feed.
