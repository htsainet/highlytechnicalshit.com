# Tailscale ACL Policy — Implementation Guide

## Overview

This guide walks through deploying a Tailscale ACL policy that restricts which
tailnet devices can reach which services on the OpenClaw host. A default-allow
**escape hatch** is included so the policy can be deployed safely and enforced
later with a single-line change.

**Policy file:** `config/tailscale-acl-policy.jsonc`

### Protected services

| Service | Port | Risk if exposed |
|---|---|---|
| SSH | 22 | Shell access |
| Dashboard | 80 | Low — static page |
| Open WebUI | 3000 | Chat history, model access |
| Ollama API | 11434 | Unauthenticated inference |
| NemoClaw prod | 18789 | Agent sandbox |
| NemoClaw test | 18790 | Agent sandbox |

---

## Prerequisites

- Tailscale installed and authenticated on the host (`tailscale status` shows "Online")
- Admin access to the Tailscale admin console (<https://login.tailscale.com>)
- At least one operator device on the same tailnet

---

## Step 1 — Tag the OpenClaw host

On the machine running the stack:

```bash
sudo tailscale set --advertise-tags=tag:openclaw-host
```

Verify:

```bash
tailscale status --self
# Should show "tag:openclaw-host" in the tags column
```

## Step 2 — Tag operator devices

On each device you use to access the stack (laptop, desktop, phone):

```bash
sudo tailscale set --advertise-tags=tag:operator
```

Alternatively, tag devices in the admin console:
**Machines → select device → Edit → Tags → add `tag:operator` → Save**

## Step 3 — Deploy the policy (escape hatch ON)

1. Open the Tailscale ACL editor: <https://login.tailscale.com/admin/acls/file>
2. Replace the contents with the policy from `config/tailscale-acl-policy.jsonc`
3. Click **Save**

The first rule is the escape hatch — a wildcard allow-all:

```jsonc
{"action": "accept", "src": ["*"], "dst": ["*:*"]},
```

While this line is present, **nothing changes**. Every device can still reach
everything, exactly like stock Tailscale behavior.

## Step 4 — Verify (escape hatch still ON)

From an operator device, confirm all services are reachable through the tailnet IP:

```bash
TS_IP=$(tailscale ip -4)   # or use the host's tailnet IP directly

# Dashboard
curl -sf http://$TS_IP:80 > /dev/null && echo "Dashboard: OK"

# Open WebUI
curl -sf http://$TS_IP:3000 > /dev/null && echo "Open WebUI: OK"

# Ollama
curl -sf http://$TS_IP:11434 > /dev/null && echo "Ollama: OK"

# NemoClaw prod
curl -sf http://$TS_IP:18789 > /dev/null && echo "NemoClaw prod: OK"

# SSH
ssh -o ConnectTimeout=3 $TS_IP exit 2>/dev/null && echo "SSH: OK"
```

Everything should work identically to before.

## Step 5 — Enforce (when ready)

In the ACL editor, **comment out** the escape hatch line:

```jsonc
// {"action": "accept", "src": ["*"], "dst": ["*:*"]},
```

Save. Tailscale enforces immediately — no restart needed.

### What changes

| Device | Before | After |
|---|---|---|
| `tag:operator` devices | Full access | Full access (allowed by granular rules) |
| Any other tailnet device | Full access | **Denied** (implicit deny) |

## Step 6 — Validate enforcement

From an operator device — should still work:

```bash
curl -sf http://$TS_IP:3000 > /dev/null && echo "Open WebUI: OK"
```

From a non-operator tailnet device (if available) — should be refused:

```bash
curl --connect-timeout 3 http://$TS_IP:3000
# Expected: connection refused or timeout
```

## Rollback

If anything breaks, **uncomment** the escape hatch line in the admin console and
save. Access is restored within seconds.

```jsonc
{"action": "accept", "src": ["*"], "dst": ["*:*"]},
```

---

## Future extensions

| Scenario | Change |
|---|---|
| Add a collaborator with limited access | Create `tag:user`, add rules for ports 80 and 3000 only |
| Separate ops access | Create `tag:ops-admin`, restrict SSH + NemoClaw to that tag |
| Expose a demo endpoint publicly | Use Tailscale Funnel per-service instead of a reverse proxy |
| Self-hosted control plane | These ACLs work identically with Headscale's `policy.json` |
