# HandBrake Component

Last updated: 2026-04-17

## What happens here

HandBrake is an open-source video transcoder. Converts video between
formats with hardware-accelerated encoding (NVENC, VAAPI) and a library
of presets for common devices and platforms.

## Files and structure

| File | Purpose |
|------|---------|
| `handbrake.sh` | Full lifecycle: install, configure, start, stop, health |
| `handbrake.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- Host-native desktop application — no Docker container or web UI
- Includes both GUI (`ghb`) and CLI (`HandBrakeCLI`)
- NVENC hardware encoding with NVIDIA GPU for fast transcoding
- Supports H.264, H.265, AV1 output codecs

See [usage.md](./usage.md) for command usage.
