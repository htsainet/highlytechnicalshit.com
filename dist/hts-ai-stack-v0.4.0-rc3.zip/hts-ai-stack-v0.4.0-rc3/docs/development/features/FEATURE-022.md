# CrewAI — Multi-Agent Orchestration Framework

**Priority:** MEDIUM
**Effort:** 3–4 hours
**Risk:** Low — pip-installable library, MIT license, no dedicated port.
**Target Release:** v0.6.0
**Depends on:** llama-swap routing (merged), shared agents container (see FEATURE-024)
**Blocks:** Nothing

## Problem

The stack has no role-based multi-agent orchestration. CrewAI enables structured agent
"crews" where each agent has a defined role, set of tools, and assigned tasks.
Use cases: research pipelines, code review crews, content generation chains.

## Current State

Tracked in `docs/planning/feature-repos/REFERENCES.md` as `pending`.
No component script or Docker service exists.

## Architecture

CrewAI is a Python library — it runs inside a shared `hts-ai-agents` container
alongside LangGraph (FEATURE-024). The container exposes no persistent port;
it is a runner for on-demand agent workflow scripts.

```text
  scripts/components/crewai/crewai.sh
        │
        ▼
  docker/agents/Dockerfile
  (hts-ai-agents container)
  ├── crewai
  ├── langgraph        (FEATURE-024)
  └── resources/agents/ (mounted)
        ├── crewai/
        └── langgraph/
```

## Implementation Steps

### P0 — Shared agents container

- [ ] **1. Create `docker/agents/Dockerfile`**

  ```dockerfile
  FROM python:3.11-slim
  WORKDIR /app
  COPY requirements.txt .
  RUN pip install --no-cache-dir -r requirements.txt
  VOLUME ["/app/agents"]
  CMD ["python", "-c", "print('agents container ready')"]
  ```

  `docker/agents/requirements.txt`:

  ```text
  crewai
  langgraph
  openai
  ```

- [ ] **2. Docker compose service**
  Add `agents` service under `profiles: [agents]`. No exposed port — runner only.

  ```yaml
  agents:
    build: ./docker/agents
    image: hts-ai-agents
    container_name: hts-ai-agents
    profiles: [agents]
    restart: "no"
    volumes:
      - ./resources/agents:/app/agents:ro
    environment:
      - OPENAI_API_BASE=http://hts-ai-llama-swap:8081/v1
      - OPENAI_API_KEY=not-needed
    networks:
      - ai-network
  ```

### P1 — Component script

- [ ] **3. Create `scripts/components/crewai/crewai.sh`**
  - `crewai_install` — build agents container image
  - `crewai_run <workflow>` — `docker run --rm hts-ai-agents python /app/agents/crewai/<workflow>.py`
  - `crewai_health` — verify container image exists and Python import succeeds

### P2 — Example workflow

- [ ] **4. Create `resources/agents/crewai/example_crew.py`**
  A minimal 2-agent crew (Researcher + Writer) using llama-swap as the LLM backend.

## Acceptance Criteria

- `docker compose --profile agents build` succeeds
- `crewai_health` confirms `import crewai` succeeds in container
- `crewai_run example_crew` completes without error
- LLM calls route through llama-swap

## Related

- [FEATURE-024](FEATURE-024.md) — LangGraph (shares `hts-ai-agents` container)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md) — row: `crewaiinc/crewai`
