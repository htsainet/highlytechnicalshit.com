# Telegram Component

Last updated: 2026-04-15

## What happens here

Telegram bot integration for the stack — enables AI agents to send and
receive messages via Telegram. Used as a notification and interaction
channel for monitoring alerts and chat-based commands.

## Files and structure

| File | Purpose |
|------|---------|
| `telegram.sh` | Full lifecycle: install, configure, start, stop, health |
| `telegram.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
