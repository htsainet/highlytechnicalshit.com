# Ollama References

Last updated: 2026-04-15

## Upstream

- [GitHub — ollama/ollama](https://github.com/ollama/ollama)

## Official documentation

- [Ollama Docs](https://github.com/ollama/ollama/tree/main/docs)
- [Ollama Model Library](https://ollama.com/library)
- [Ollama API Reference](https://github.com/ollama/ollama/blob/main/docs/api.md)
