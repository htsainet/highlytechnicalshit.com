# Refactor — Pipeline Restructure

Last updated: 2026-04-16 12:00:00

## Purpose

The install pipeline was restructured from a monolithic numbered sequence
(00→07) into a modular architecture: shared libraries, one-script-per-service
components, host-level setup scripts, and high-level bundle orchestrators.

**All 16 tasks were completed.** The refactored structure is in place and
the old numbered scripts still function as thin wrappers during the transition.

## Workflow — what changed

| Before | After |
|--------|-------|
| 8 numbered scripts in `scripts/install/` | `lib/`, `components/`, `host/`, `bundles/` under `scripts/` |
| `01-autoinstall.sh` did 6 unrelated things | Split into `host/nvidia.sh`, `docker.sh`, `node.sh`, `tools.sh` |
| Health checks in 3 places | Unified in `lib/health.sh` |
| Model/compose helpers duplicated | Shared via `lib/compose.sh`, `lib/tokens.sh` |
| `06-start-stack.sh` orchestrated everything | Thin wrapper → delegates to component scripts |
| No way to run one service alone | Every `components/*.sh` is independently runnable |
| `instances/prod` + `instances/test` used only for seeding | Cleaned up (single instance architecture) |
| `OPENCLAW_TOKEN` generated but never used | Removed (dead code) |
| `full-stack.sh` orchestrated all deployments | **Deprecated** → `converge.sh` reads manifests + stack.json directly |
| `.env` booleans drove service enablement | `converge.sh` reads `stack.json` via component manifests |

## File structure

```text
scripts/
├── lib/           # Shared functions (sourced, never run directly)
│   ├── common.sh, health.sh, compose.sh, tokens.sh
│   ├── manifest-loader.sh, state-desired.sh, state-actual.sh
│   └── converge-diff.sh    # Convergence engine libraries
├── components/    # One script per service (independently runnable)
│   ├── ollama/ollama.sh + manifest.json
│   ├── open-webui/open-webui.sh + manifest.json
│   └── ... (33 components total, each with manifest.json)
├── host/          # Host-level setup (not service-specific)
│   ├── nvidia.sh, docker.sh, node.sh, nas.sh, tools.sh
├── bundles/       # Orchestration — mostly deprecated by converge.sh
│   ├── full-stack.sh (DEPRECATED — stub)
│   ├── chat.sh, nemoclaw.sh, voice.sh, deerflow.sh,
│   │   image-gen.sh, openspace.sh (convenience bundles)
├── utils/         # Convergence engine + utilities
│   ├── converge.sh          # PRIMARY orchestrator
│   └── reconfigure.sh       # Day-2 wizard + converge
└── install/       # Old numbered scripts (legacy wrappers only)
```

## Key decisions made

1. **Single instance** — no multi-instance; architecture supports adding later
2. **Single docker-compose.yml + profiles** — bundles pick which profiles to activate
3. **Thin wrappers** for backward compat — old scripts delegate to new structure
4. **Check + fail** for dependencies — scripts error with instructions, never auto-start deps
5. **All 16 services** confirmed as components (including TimeShift + Duplicati)
6. **RTX 3060 config** moved into refactored components (not kept separately)
7. **Both wizards kept** — whiptail primary now, Python wizard is long-term primary
8. **`components/`** naming chosen over `services/` (better fit for mixed concerns)
9. **Backend mutual exclusion** — Ollama and BitNet cannot run simultaneously
10. **NAS as wizard prompt** — user chooses to set up NFS cache, skip, or exit and configure

## Standards (working rules, still in effect)

1. Never break the existing pipeline — old scripts stay as wrappers until validated
2. One service per file — no script touches two services
3. Shared code in `lib/` only — no copy-pasting health checks or compose wrappers
4. Idempotent everything — every script is safe to re-run
5. `set -euo pipefail` on every script
6. Source `.env` explicitly when config values are needed
7. Backend mutual exclusion via `ensure_backend_exclusive` in `lib/compose.sh`

## What good looks like

- Any single service can be installed/tested with `bash scripts/components/X/X.sh`
- Bundles compose services into use cases without duplicating logic
- Adding a new service means creating one file in `components/` and adding it to relevant bundles
- Old numbered scripts still work (thin wrappers) for anyone with existing muscle memory
