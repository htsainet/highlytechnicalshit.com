#!/usr/bin/env bash
# scripts/components/stable-diffusion/diag.sh — Dump diagnostics for the
# Stable Diffusion container so a failure can be investigated from a
# non-docker-capable session (e.g. Copilot CLI inside a snap sandbox).
#
# Usage:
#   ./scripts/components/stable-diffusion/diag.sh              # human-readable to stdout
#   ./scripts/components/stable-diffusion/diag.sh --save       # also tee to logs/sd-diag-<ts>.log
#
# Captures (in order):
#   1. docker version / daemon reachability
#   2. container inspect (status, exit code, OOM, error, restart count)
#   3. last 300 lines of container logs (stdout+stderr)
#   4. compose config for the stable-diffusion service (resolved)
#   5. GPU reservation sanity (nvidia-smi on host + inside container if up)
#   6. Port bind check on $SD_PORT
#
# Safe to run repeatedly. Does not modify any state.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/common.sh" 2>/dev/null || true
[[ -f "$REPO_DIR/.env" ]] && set -a && . "$REPO_DIR/.env" && set +a || true

SD_PORT="${SD_PORT:-7860}"
SD_CONTAINER="${SD_CONTAINER:-hts-ai-stable-diffusion}"
SAVE=false
for arg in "$@"; do
  [[ "$arg" == "--save" ]] && SAVE=true
done

_run() {
  local label="$1"; shift
  printf '\n── %s ──────────────────────────────────────────────────\n' "$label"
  "$@" 2>&1 || printf '[diag] command failed (exit %d): %s\n' "$?" "$*"
}

main() {
  printf '==== Stable Diffusion diagnostics — %s ====\n' "$(date -Iseconds)"
  printf 'container: %s   port: %s   repo: %s\n' "$SD_CONTAINER" "$SD_PORT" "$REPO_DIR"

  _run "docker version" docker version --format 'client={{.Client.Version}} server={{.Server.Version}}'

  _run "container inspect" docker inspect "$SD_CONTAINER" \
    --format 'status={{.State.Status}} running={{.State.Running}} exit={{.State.ExitCode}} oom={{.State.OOMKilled}} restarts={{.RestartCount}} started={{.State.StartedAt}} finished={{.State.FinishedAt}}
error={{.State.Error}}
health={{if .State.Health}}{{.State.Health.Status}} failing={{.State.Health.FailingStreak}}{{else}}<no healthcheck state>{{end}}
image={{.Config.Image}}
cmd={{join .Config.Cmd " "}}'

  _run "last healthcheck log" bash -c \
    'docker inspect '"$SD_CONTAINER"' --format "{{if .State.Health}}{{range .State.Health.Log}}--- exit={{.ExitCode}} @ {{.Start}} ---
{{.Output}}
{{end}}{{end}}" | tail -80'

  _run "container logs (tail 300)" docker logs --tail 300 "$SD_CONTAINER"

  _run "compose config (stable-diffusion)" bash -c \
    "cd '$REPO_DIR' && docker compose --profile sd config stable-diffusion"

  _run "host nvidia-smi" nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used --format=csv

  if docker ps --format '{{.Names}}' | grep -qx "$SD_CONTAINER"; then
    _run "in-container nvidia-smi" docker exec "$SD_CONTAINER" nvidia-smi
    _run "in-container torch.cuda" docker exec "$SD_CONTAINER" python -c \
      'import torch; print("torch",torch.__version__,"cuda",torch.cuda.is_available(),"devices",torch.cuda.device_count())'
  else
    printf '\n[diag] container not running — skipping in-container probes\n'
  fi

  _run "port bind" bash -c "ss -tlnp 2>/dev/null | grep -E ':${SD_PORT}\b' || echo 'no listener on :${SD_PORT}'"

  printf '\n==== end diagnostics ====\n'
}

if [[ "$SAVE" == "true" ]]; then
  mkdir -p "$REPO_DIR/logs"
  out="$REPO_DIR/logs/sd-diag-$(date +%Y%m%d-%H%M%S).log"
  main | tee "$out"
  printf '\n[diag] saved to %s\n' "$out"
else
  main
fi
