#!/usr/bin/env bash
# backups/pre-nuke-checklist.sh — Run all backup layers before a nuke-and-pave
#
# Orchestrates the full backup sequence:
#   1. Verify NAS mounts are live
#   2. Timeshift system snapshot
#   3. Docker volume backups → NAS
#   4. Model weight sync → NAS
#   5. System config backup → NAS
#   6. (Optional) Full disk image via dd → NAS
#   7. Git push verification
#
# Each step is independently skippable. The script prints a final
# readiness checklist so you know exactly what's backed up.
#
# Usage:
#   sudo ./backups/pre-nuke-checklist.sh [options]
#
# Options:
#   --skip-timeshift   Skip Timeshift snapshot
#   --skip-volumes     Skip Docker volume backups
#   --skip-models      Skip model weight sync
#   --skip-configs     Skip system config backup
#   --skip-disk        Skip full disk image (default: skipped unless --disk)
#   --disk             Include full disk image backup
#   --stop-docker      Stop Docker before disk image for consistency
#   --dry-run          Print every action without making changes
#   -h, --help         Show this help

set -euo pipefail

BACKUP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$BACKUP_DIR/.." && pwd)"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
BOLD='\033[1m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
ok()    { echo -e "${GREEN}[ OK ]${NC} $*"; }
skip_msg() { echo -e "${YELLOW}[SKIP]${NC} $*"; }
step()  { echo -e "\n${CYAN}═══════════════════════════════════════════════════${NC}"; echo -e "${CYAN}  $*${NC}"; echo -e "${CYAN}═══════════════════════════════════════════════════${NC}"; }
fail()  { echo -e "${RED}[FAIL]${NC} $*" >&2; }

[[ $EUID -eq 0 ]] || { echo "Must be run as root: sudo $0 $*" >&2; exit 1; }

# ── Defaults ───────────────────────────────────────────────────────────────────
DO_TIMESHIFT=true
DO_VOLUMES=true
DO_MODELS=true
DO_CONFIGS=true
DO_DISK=false
STOP_DOCKER=false
DRY_RUN=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-timeshift) DO_TIMESHIFT=false; shift ;;
    --skip-volumes)   DO_VOLUMES=false;   shift ;;
    --skip-models)    DO_MODELS=false;    shift ;;
    --skip-configs)   DO_CONFIGS=false;   shift ;;
    --skip-disk)      DO_DISK=false;      shift ;;
    --disk)           DO_DISK=true;       shift ;;
    --stop-docker)    STOP_DOCKER=true;   shift ;;
    --dry-run)        DRY_RUN=true;       shift ;;
    -h|--help)        grep '^# ' "$0" | head -30; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

DRY_FLAG=""
"$DRY_RUN" && DRY_FLAG="--dry-run"

DOCKER_FLAG=""
"$STOP_DOCKER" && DOCKER_FLAG="--stop-docker"

# Track results
declare -A RESULTS

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║         Pre-Nuke Backup Checklist                    ║"
echo "║         ─────────────────────────                    ║"
echo "║  Comprehensive backup before system reinstall        ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
"$DRY_RUN" && warn "DRY RUN MODE — no changes will be made"
echo ""

# ── Step 0: Verify NAS mounts ─────────────────────────────────────────────────
step "0 — Verify NAS Mounts"

NAS_MOUNTS=(
  "/mnt/htsai-docker-volume-backup"
  "/mnt/htsai-timeshift-backup"
  "/mnt/htsai-model-backup"
  "/mnt/htsai-disk-image"
)

ALL_MOUNTED=true
for mnt in "${NAS_MOUNTS[@]}"; do
  if mountpoint -q "$mnt" 2>/dev/null; then
    ok "$mnt"
  else
    # Disk image mount is optional unless --disk was specified
    if [[ "$mnt" == "/mnt/htsai-disk-image" ]] && ! "$DO_DISK"; then
      skip_msg "$mnt (not needed — --disk not specified)"
    else
      fail "$mnt NOT MOUNTED"
      ALL_MOUNTED=false
    fi
  fi
done

if ! "$ALL_MOUNTED"; then
  echo ""
  warn "Some NAS mounts are missing. Fix with:"
  warn "  sudo mount -a"
  warn "Or mount manually:"
  warn "  sudo mount -t nfs KEEPITTUNED:/volume1/<share> /mnt/<share>"
  echo ""
  read -rp "Continue anyway? (y/N): " CONTINUE
  [[ "${CONTINUE,,}" == "y" ]] || exit 1
fi

# ── Step 1: Timeshift ─────────────────────────────────────────────────────────
step "1 — Timeshift System Snapshot"

if "$DO_TIMESHIFT"; then
  if ! command -v timeshift &>/dev/null; then
    warn "Timeshift not installed — running setup first..."
    if [[ -x "$BACKUP_DIR/timeshift/setup-timeshift.sh" ]]; then
      bash "$BACKUP_DIR/timeshift/setup-timeshift.sh" --skip-snapshot $DRY_FLAG
    else
      fail "Timeshift setup script not found"
      RESULTS[timeshift]="FAIL"
    fi
  fi

  if command -v timeshift &>/dev/null; then
    info "Creating pre-nuke Timeshift snapshot..."
    if "$DRY_RUN"; then
      echo "  [dry-run] timeshift --create --comments 'Pre-nuke backup' --scripted"
      RESULTS[timeshift]="DRY-RUN"
    else
      if timeshift --create \
        --comments "Pre-nuke backup — $(date '+%Y-%m-%d %H:%M')" \
        --scripted; then
        ok "Timeshift snapshot created"
        RESULTS[timeshift]="OK"
      else
        fail "Timeshift snapshot failed"
        RESULTS[timeshift]="FAIL"
      fi
    fi
  fi
else
  skip_msg "Timeshift (--skip-timeshift)"
  RESULTS[timeshift]="SKIPPED"
fi

# ── Step 2: Docker volumes ────────────────────────────────────────────────────
step "2 — Docker Volume Backups"

if "$DO_VOLUMES"; then
  VOLUME_SCRIPT="$BACKUP_DIR/docker/backup-volumes.sh"
  if [[ -x "$VOLUME_SCRIPT" ]]; then
    info "Running backup-volumes.sh..."
    if bash "$VOLUME_SCRIPT" $DRY_FLAG; then
      ok "Volume backups complete"
      RESULTS[volumes]="OK"
    else
      fail "Volume backup encountered errors"
      RESULTS[volumes]="PARTIAL"
    fi
  else
    fail "backup-volumes.sh not found at $VOLUME_SCRIPT"
    RESULTS[volumes]="FAIL"
  fi
else
  skip_msg "Docker volumes (--skip-volumes)"
  RESULTS[volumes]="SKIPPED"
fi

# ── Step 3: Model weights ────────────────────────────────────────────────────
step "3 — Model Weight Sync"

if "$DO_MODELS"; then
  MODEL_SCRIPT="$REPO_DIR/scripts/host/backup-models.sh"
  if [[ -x "$MODEL_SCRIPT" ]]; then
    if "$DRY_RUN"; then
      echo "  [dry-run] Would run backup-models.sh (rsync model weights to NAS)"
      RESULTS[models]="DRY-RUN"
    else
      info "Running backup-models.sh..."
      if bash "$MODEL_SCRIPT"; then
        ok "Model sync complete"
        RESULTS[models]="OK"
      else
        fail "Model sync encountered errors"
        RESULTS[models]="PARTIAL"
      fi
    fi
  else
    fail "backup-models.sh not found at $MODEL_SCRIPT"
    RESULTS[models]="FAIL"
  fi
else
  skip_msg "Model weights (--skip-models)"
  RESULTS[models]="SKIPPED"
fi

# ── Step 4: System configs ────────────────────────────────────────────────────
step "4 — System Config Backup"

if "$DO_CONFIGS"; then
  CONFIG_DEST="/mnt/htsai-docker-volume-backup/configs/$(date +%Y%m%d-%H%M%S)"

  if "$DRY_RUN"; then
    echo "  [dry-run] Would backup system configs to ${CONFIG_DEST}"
    RESULTS[configs]="DRY-RUN"
  else
    mkdir -p "$CONFIG_DEST"

    # Docker daemon config
    if [[ -f /etc/docker/daemon.json ]]; then
      cp /etc/docker/daemon.json "$CONFIG_DEST/"
      ok "docker/daemon.json"
    fi

    # fstab
    if [[ -f /etc/fstab ]]; then
      cp /etc/fstab "$CONFIG_DEST/"
      ok "fstab"
    fi

    # idmapd.conf (NFS)
    if [[ -f /etc/idmapd.conf ]]; then
      cp /etc/idmapd.conf "$CONFIG_DEST/"
      ok "idmapd.conf"
    fi

    # Timeshift config
    if [[ -f /etc/timeshift/timeshift.json ]]; then
      cp /etc/timeshift/timeshift.json "$CONFIG_DEST/"
      ok "timeshift.json"
    fi

    # Stack .env (sensitive — permissions preserved)
    if [[ -f "$REPO_DIR/.env" ]]; then
      cp --no-preserve=ownership "$REPO_DIR/.env" "$CONFIG_DEST/stack.env"
      chmod 600 "$CONFIG_DEST/stack.env"
      ok ".env → stack.env (mode 600)"
    fi

    # stack.json (wizard answers)
    if [[ -f "$REPO_DIR/config/stack.json" ]]; then
      cp "$REPO_DIR/config/stack.json" "$CONFIG_DEST/"
      ok "stack.json"
    fi

    # NAS env (persists across reinstalls)
    _REAL_HOME="${HOME}"
    if [[ -n "${SUDO_USER:-}" ]]; then
      _REAL_HOME=$(eval echo "~${SUDO_USER}")
    fi
    if [[ -f "${_REAL_HOME}/.config/htsai/nas.env" ]]; then
      cp --no-preserve=ownership "${_REAL_HOME}/.config/htsai/nas.env" "$CONFIG_DEST/"
      ok "nas.env"
    fi

    # NVIDIA driver info (for reinstall)
    if command -v nvidia-smi &>/dev/null; then
      nvidia-smi --query-gpu=driver_version,name --format=csv,noheader \
        > "$CONFIG_DEST/nvidia-gpu-info.txt" 2>/dev/null || true
      ok "nvidia-gpu-info.txt"
    fi

    # Package list (for reference)
    dpkg --get-selections > "$CONFIG_DEST/dpkg-selections.txt" 2>/dev/null || true
    ok "dpkg-selections.txt"

    # Installed snaps
    snap list 2>/dev/null > "$CONFIG_DEST/snap-list.txt" || true
    ok "snap-list.txt"

    ok "System configs backed up to ${CONFIG_DEST}"
    RESULTS[configs]="OK"
  fi
else
  skip_msg "System configs (--skip-configs)"
  RESULTS[configs]="SKIPPED"
fi

# ── Step 5: Full disk image ───────────────────────────────────────────────────
step "5 — Full Disk Image (dd)"

if "$DO_DISK"; then
  DISK_SCRIPT="$BACKUP_DIR/disk-image/backup-disk.sh"
  if [[ -x "$DISK_SCRIPT" ]]; then
    info "Running backup-disk.sh..."
    if bash "$DISK_SCRIPT" $DRY_FLAG $DOCKER_FLAG --verify; then
      ok "Disk image created"
      RESULTS[disk]="OK"
    else
      fail "Disk image creation failed"
      RESULTS[disk]="FAIL"
    fi
  else
    fail "backup-disk.sh not found"
    RESULTS[disk]="FAIL"
  fi
else
  skip_msg "Full disk image (use --disk to enable)"
  RESULTS[disk]="SKIPPED"
fi

# ── Step 6: Git status ────────────────────────────────────────────────────────
step "6 — Git Repository Status"

cd "$REPO_DIR"
UNPUSHED=$(git log --oneline @{u}..HEAD 2>/dev/null | wc -l || echo "?")
UNCOMMITTED=$(git status --porcelain 2>/dev/null | wc -l || echo "?")

if [[ "$UNCOMMITTED" -gt 0 ]]; then
  warn "${UNCOMMITTED} uncommitted changes in working tree"
  git status --short 2>/dev/null | head -10
  RESULTS[git]="DIRTY"
else
  ok "Working tree clean"
  RESULTS[git]="OK"
fi

if [[ "$UNPUSHED" -gt 0 ]]; then
  warn "${UNPUSHED} unpushed commit(s) — remember to push!"
  RESULTS[git]="UNPUSHED"
else
  ok "All commits pushed to remote"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  Pre-Nuke Backup Summary                             ║"
echo "╠══════════════════════════════════════════════════════╣"

READY=true
for key in timeshift volumes models configs disk git; do
  status="${RESULTS[$key]:-N/A}"
  case "$status" in
    OK)      icon="✅" ;;
    DRY-RUN) icon="🔹" ;;
    SKIPPED) icon="⏭️ " ;;
    PARTIAL) icon="⚠️ "; READY=false ;;
    FAIL)    icon="❌"; READY=false ;;
    DIRTY|UNPUSHED) icon="⚠️ "; READY=false ;;
    *)       icon="❓" ;;
  esac
  printf "║  %s  %-12s : %-10s                        ║\n" "$icon" "$key" "$status"
done

echo "╠══════════════════════════════════════════════════════╣"

if "$READY" || "$DRY_RUN"; then
  echo -e "║  ${GREEN}${BOLD}READY TO NUKE AND PAVE${NC}                              ║"
else
  echo -e "║  ${YELLOW}${BOLD}REVIEW WARNINGS BEFORE PROCEEDING${NC}                   ║"
fi

echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "  After reinstall:"
echo "    1. Set DHCP reservation for this MAC address"
echo "    2. Install Ubuntu, same hostname ($(hostname))"
echo "    3. Mount NAS shares (fstab entries saved in config backup)"
echo "    4. Clone repo and run: ./install.sh"
echo "    5. Restore Docker volumes: ./backups/docker/backup-volumes.sh --restore"
echo ""
echo "  Full disaster recovery guide:"
echo "    docs/guides/disaster-recovery.md"
echo ""
