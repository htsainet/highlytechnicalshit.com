#!/usr/bin/env bash
# scripts/utils/purge-chat-logs.sh — Utility to purge chat logs, prompts, caches, and output data across components.
# Allows selective purging via command‑line flags.
# Flags:
#   --ollama            Remove Ollama Docker volume (ollama_data)
#   --sd-models         Remove Stable Diffusion model volume (sd_models)
#   --sd-outputs        Remove Stable Diffusion output volume (sd_outputs)
#   --vtuber            Remove Open‑LLM‑VTuber data volume (open_llm_vtuber_data)
#   --comfyui           Remove ComfyUI bind‑mounted data directory
#   --faster-whisper    Remove Faster‑Whisper cache volume (faster_whisper_cache)
#   --coqui-tts         Remove Coqui‑TTS cache volume (coqui_tts_models)
#   --bark              Remove Bark TTS cache volume (bark_models)
#   --logs              Purge log files in the repository logs/ folder (excludes upstream-watch.log)
#   --all               Purge everything (default when no flags are given)
#
# The script is idempotent and safe to run multiple times.

set -euo pipefail

# Resolve repository root regardless of where the script is invoked from.
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

info() { echo "[INFO] $*"; }
warn() { echo "[WARN] $*"; }

# Helper to remove a Docker volume if it exists.
remove_volume() {
  local vol="$1"
  if docker volume inspect "$vol" >/dev/null 2>&1; then
    info "Removing Docker volume $vol"
    docker volume rm -f "$vol"
  else
    info "Docker volume $vol does not exist – skipping"
  fi
}

purge_ollama() {
  remove_volume ollama_data
}

purge_sd_models() {
  remove_volume sd_models
}

purge_sd_outputs() {
  remove_volume sd_outputs
}

purge_vtuber() {
  remove_volume open_llm_vtuber_data
}

purge_comfyui() {
  local dir="$REPO_DIR/data/comfyui"
  if [[ -d "$dir" ]]; then
    info "Removing ComfyUI data directory $dir"
    rm -rf "$dir"
  else
    info "ComfyUI data directory not found – skipping"
  fi
}

purge_faster_whisper() {
  remove_volume faster_whisper_cache
}

purge_coqui_tts() {
  remove_volume coqui_tts_models
}

purge_bark() {
  remove_volume bark_models
}

purge_logs() {
  if [[ -d "$REPO_DIR/logs" ]]; then
    info "Purging log files in $REPO_DIR/logs (excluding upstream-watch.log)"
    find "$REPO_DIR/logs" -type f -name "*.log" ! -name "upstream-watch.log" -exec rm -f {} +
  else
    info "No logs directory found – nothing to purge"
  fi
}

# -------------------------------------------------------------------
# 1. Stop Docker compose services (if Docker is available).
# -------------------------------------------------------------------
if command -v docker >/dev/null 2>&1 && [[ -f "$REPO_DIR/docker-compose.yml" ]]; then
  info "Stopping Docker compose stack..."
  docker compose -f "$REPO_DIR/docker-compose.yml" down --remove-orphans >/dev/null 2>&1 || true
else
  info "Docker not available or compose file missing – proceeding without stopping services."
fi

# -------------------------------------------------------------------
# 2. Parse arguments – default to --all when none are supplied.
# -------------------------------------------------------------------
if [[ $# -eq 0 ]]; then
  set -- "--all"
fi

for arg in "$@"; do
  case "$arg" in
    --ollama) purge_ollama ;;
    --sd-models) purge_sd_models ;;
    --sd-outputs) purge_sd_outputs ;;
    --vtuber) purge_vtuber ;;
    --comfyui) purge_comfyui ;;
    --faster-whisper) purge_faster_whisper ;;
    --coqui-tts) purge_coqui_tts ;;
    --bark) purge_bark ;;
    --logs) purge_logs ;;
    --all)
      purge_ollama
      purge_sd_models
      purge_sd_outputs
      purge_vtuber
      purge_comfyui
      purge_faster_whisper
      purge_coqui_tts
      purge_bark
      purge_logs
      ;;
    *) warn "Unknown option: $arg" ;;
  esac
done

info "Purge operation completed."
