#!/usr/bin/env bash
# 07-setup-connectivity.sh — Thin wrapper: delegates to component scripts.
#
# Usage:
#   ./07-setup-connectivity.sh [--telegram] [--signal] [--tailscale] [--firefox-home]
#
#   With no flags: runs all four.
#   With flags:    runs only the specified items.
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "07 — Connectivity Setup"

# ── Source component scripts ──────────────────────────────────────────────────
source "$REPO_DIR/scripts/components/tailscale.sh"
source "$REPO_DIR/scripts/components/telegram.sh"
source "$REPO_DIR/scripts/components/signal.sh"

# ── Firefox homepage (stays in wrapper — not a service) ───────────────────────
load_env
FIREFOX_HOMEPAGE_URL="${FIREFOX_HOMEPAGE_URL:-http://127.0.0.1}"

set_firefox_homepage() {
  local profiles_ini profile_dir user_js

  step "Firefox — homepage"

  if ! command -v firefox >/dev/null 2>&1; then
    warn "Firefox is not installed; skipping homepage setup."
    return 0
  fi

  profiles_ini="$HOME/.mozilla/firefox/profiles.ini"
  if [ ! -f "$profiles_ini" ]; then
    warn "Firefox profile not found; open Firefox once, then re-run with --firefox-home."
    return 0
  fi

  profile_dir="$(awk -F= '
    /^\[Profile/ { in_profile=1; path=""; rel=1; def=0; next }
    in_profile && /^Path=/ { path=$2; next }
    in_profile && /^IsRelative=/ { rel=$2; next }
    in_profile && /^Default=/ { def=$2; next }
    /^$/ {
      if (in_profile && def == 1) {
        if (rel == 1) print ENVIRON["HOME"] "/.mozilla/firefox/" path;
        else print path;
        exit
      }
      in_profile=0
    }
    END {
      if (in_profile && def == 1) {
        if (rel == 1) print ENVIRON["HOME"] "/.mozilla/firefox/" path;
        else print path;
      }
    }
  ' "$profiles_ini")"

  if [ -z "$profile_dir" ] || [ ! -d "$profile_dir" ]; then
    warn "Could not locate the default Firefox profile; skipping homepage setup."
    return 0
  fi

  user_js="$profile_dir/user.js"
  touch "$user_js"

  if grep -q '^user_pref("browser.startup.homepage",' "$user_js"; then
    sed -i "s|^user_pref(\"browser.startup.homepage\",.*|user_pref(\"browser.startup.homepage\", \"$FIREFOX_HOMEPAGE_URL\");|" "$user_js"
  else
    printf 'user_pref("browser.startup.homepage", "%s");\n' "$FIREFOX_HOMEPAGE_URL" >> "$user_js"
  fi

  if grep -q '^user_pref("browser.startup.page",' "$user_js"; then
    sed -i 's|^user_pref("browser.startup.page",.*|user_pref("browser.startup.page", 1);|' "$user_js"
  else
    printf 'user_pref("browser.startup.page", 1);\n' >> "$user_js"
  fi

  ok "Firefox homepage set to $FIREFOX_HOMEPAGE_URL"
}

# ── Parse flags ───────────────────────────────────────────────────────────────
RUN_TELEGRAM=false
RUN_SIGNAL=false
RUN_TAILSCALE=false
RUN_FIREFOX_HOME=false

if [ $# -eq 0 ]; then
  RUN_TELEGRAM=true
  RUN_SIGNAL=true
  RUN_TAILSCALE=true
  RUN_FIREFOX_HOME=true
else
  for arg in "$@"; do
    case "$arg" in
      --telegram)     RUN_TELEGRAM=true ;;
      --signal)       RUN_SIGNAL=true ;;
      --tailscale)    RUN_TAILSCALE=true ;;
      --firefox-home) RUN_FIREFOX_HOME=true ;;
      *) echo "Unknown flag: $arg"; echo "Usage: $0 [--telegram] [--signal] [--tailscale] [--firefox-home]"; exit 1 ;;
    esac
  done
fi

# ── Dispatch ──────────────────────────────────────────────────────────────────
if $RUN_TAILSCALE; then
  tailscale_install
  tailscale_configure
  tailscale_start
  tailscale_health
fi

if $RUN_TELEGRAM; then
  telegram_install
  telegram_configure
  telegram_start
  telegram_health
fi

if $RUN_SIGNAL; then
  signal_install
  signal_configure
  signal_start
  signal_health
fi

if $RUN_FIREFOX_HOME; then
  set_firefox_homepage
fi

echo ""
info "07-setup-connectivity.sh complete."
