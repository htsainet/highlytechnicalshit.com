# OpenCode Component — REFERENCES

## Official

- Homepage / docs: <https://opencode.ai/>
- GitHub: <https://github.com/sst/opencode>

## OpenAI-compatible / routing

- llama-swap: <https://github.com/mostlygeek/llama-swap>
- LiteLLM docs: <https://docs.litellm.ai/>

## Related components in this stack

- Aider: <https://aider.chat> — peer tool
- Tabby: <https://tabby.tabbyml.com> — in-editor completions
- Ollama: <https://ollama.com> — model provider

## Related features

- FEATURE-054 — Developer Tools Suite (OpenCode, Aider, Tabby, Gitea Runner)
- FEATURE-067 — Aider Coding-Tier Preset (sibling feature; OpenCode
  can consume the same llama-swap endpoint and coder tags)

## Vendor-instruction deviations

None. Install follows upstream instructions. The host-install-vs-container
decision is a project-policy choice and mirrors Aider's — see
`scripts/components/aider/CONTEXT.md § Why host-installed and not
containerized?`.
