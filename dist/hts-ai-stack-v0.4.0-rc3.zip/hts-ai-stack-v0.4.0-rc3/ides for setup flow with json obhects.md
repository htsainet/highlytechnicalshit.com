examiner.sh - queries tha state of the machine.  njvidia drivers, hardware, installed components, docker containers, etc
---> produces an examination report

interrigator - takes the examination report and asks the user to select components.  some may be "greyed out" if notvalid based on the examination report
---> produces an interrigqation report

validator

orchestrator

enumerator

viewer 

builder

