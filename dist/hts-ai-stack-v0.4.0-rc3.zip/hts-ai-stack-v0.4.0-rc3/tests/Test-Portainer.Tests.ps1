$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/portainer'
    $script:ComponentScript = Join-Path $script:ComponentDir 'portainer.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'portainer.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'portainer file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists (TDD — needs creation)' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'portainer manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is portainer' {
        $script:Manifest.id | Should -Be 'portainer'
    }

    It 'category is admin' {
        $script:Manifest.category | Should -Be 'admin'
    }

    It 'profile is portainer' {
        $script:Manifest.profile | Should -Be 'portainer'
    }

    It 'dashboard port is 9000' {
        [int]$script:Manifest.dashboard.port | Should -Be 9000
    }

    It 'script path should point to component subfolder (TDD)' {
        $script:Manifest.script | Should -Be 'scripts/components/portainer/portainer.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'portainer port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 9000 is registered in portmap.json' {
        $script:Portmap.ports.'9000' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'9000'.service | Should -Be 'portainer'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'portainer compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'portainer service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'portainer'
    }

    It 'uses portainer profile' {
        $script:ComposeContent | Should -Match 'portainer'
    }
}
