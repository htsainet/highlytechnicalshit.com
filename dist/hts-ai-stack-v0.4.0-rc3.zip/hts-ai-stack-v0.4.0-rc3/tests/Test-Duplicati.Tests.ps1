$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/duplicati'
    $script:ComponentScript = Join-Path $script:ComponentDir 'duplicati.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'duplicati.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'duplicati file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'duplicati manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is duplicati' {
        $script:Manifest.id | Should -Be 'duplicati'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/duplicati/duplicati.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is duplicati' {
        $script:Manifest.func_prefix | Should -Be 'duplicati'
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'duplicati component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines duplicati_install function' {
        $script:ComponentContent | Should -Match 'duplicati_install\s*\(\)'
    }

    It 'defines duplicati_configure function' {
        $script:ComponentContent | Should -Match 'duplicati_configure\s*\(\)'
    }

    It 'defines duplicati_start function' {
        $script:ComponentContent | Should -Match 'duplicati_start\s*\(\)'
    }

    It 'defines duplicati_stop function' {
        $script:ComponentContent | Should -Match 'duplicati_stop\s*\(\)'
    }

    It 'defines duplicati_health function' {
        $script:ComponentContent | Should -Match 'duplicati_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/duplicati/duplicati\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'duplicati no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/duplicati\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/duplicati/duplicati\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
