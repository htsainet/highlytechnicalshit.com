$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/open-sora'
    $script:ComponentScript = Join-Path $script:ComponentDir 'open-sora.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'open-sora.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'open-sora file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }

    It 'CONTEXT.md exists' {
        Join-Path $script:ComponentDir 'CONTEXT.md' | Should -Exist
    }

    It 'REFERENCES.md exists' {
        Join-Path $script:ComponentDir 'REFERENCES.md' | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'open-sora manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is open-sora' {
        $script:Manifest.id | Should -Be 'open-sora'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/open-sora/open-sora.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is open_sora_' {
        $script:Manifest.func_prefix | Should -Be 'open_sora_'
    }

    It 'dashboard port is 7862' {
        [int]$script:Manifest.dashboard.port | Should -Be 7862
    }

    It 'vram_min_gb is 24' {
        [int]$script:Manifest.vram_min_gb | Should -Be 24
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'open-sora component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines open_sora_install function' {
        $script:ComponentContent | Should -Match 'open_sora_install\s*\(\)'
    }

    It 'defines open_sora_configure function' {
        $script:ComponentContent | Should -Match 'open_sora_configure\s*\(\)'
    }

    It 'defines open_sora_start function' {
        $script:ComponentContent | Should -Match 'open_sora_start\s*\(\)'
    }

    It 'defines open_sora_stop function' {
        $script:ComponentContent | Should -Match 'open_sora_stop\s*\(\)'
    }

    It 'defines open_sora_health function' {
        $script:ComponentContent | Should -Match 'open_sora_health\s*\(\)'
    }

    It 'defines open_sora_restart function' {
        $script:ComponentContent | Should -Match 'open_sora_restart\s*\(\)'
    }

    It 'defines open_sora_destroy function' {
        $script:ComponentContent | Should -Match 'open_sora_destroy\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/open-sora/open-sora\.sh'
    }
}

# ── VRAM gate ────────────────────────────────────────────────────────────────

Describe 'open-sora VRAM gate' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines get_gpu_vram_gb function' {
        $script:ComponentContent | Should -Match 'get_gpu_vram_gb\s*\(\)'
    }

    It 'defines check_vram_requirement function' {
        $script:ComponentContent | Should -Match 'check_vram_requirement\s*\(\)'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'open-sora port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 7862 is registered in portmap.json' {
        $script:Portmap.ports.'7862' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'7862'.service | Should -Be 'open-sora'
    }
}

# ── Docker file existence ───────────────────────────────────────────────────

Describe 'open-sora Docker artifacts' {

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/open-sora/Dockerfile' | Should -Exist
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'open-sora no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/open-sora\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/open-sora/open-sora\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
