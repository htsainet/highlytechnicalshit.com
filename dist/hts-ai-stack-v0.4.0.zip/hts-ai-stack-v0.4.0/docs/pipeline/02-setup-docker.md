# 02-setup-docker.sh — Pull Docker Images

Pulls all stack images to local cache. Run once after cloning, or any time you
want to refresh to the latest image versions before starting the stack.

```bash
./02-setup-docker.sh
```

> Requires `.env` to exist. Run `./01-autoinstall.sh` first — it generates tokens
> automatically. Or see below for manual token creation.

---

## Step 1 — Check .env

Verifies `.env` exists and exits with instructions if not. Tokens are generated
by `01-autoinstall.sh` and should already be present.

To regenerate tokens manually:

```bash
echo "WEBUI_SECRET_KEY=$(openssl rand -hex 32)" >> .env
echo "OPENCLAW_TOKEN=$(openssl rand -hex 32)" >> .env
chmod 600 .env
```

| Variable | Used by |
|---|---|
| `WEBUI_SECRET_KEY` | Open WebUI session signing |
| `OPENCLAW_TOKEN` | NemoClaw gateway auth token |

---

## Step 2 — Pull images

Pulls the latest version of every image in `docker-compose.yml` and both
instance compose files (prod + test). Does not start any containers.

---

## Next Steps

```bash
converge.sh --yes            # converge all services (Ollama GPU + BitNet CPU + llama-swap + NemoClaw)
./03-setup-models.sh         # pull Ollama models and SD checkpoints
./04-setup-nemoclaw.sh       # optional — NemoClaw sandboxed agent runtime
bash scripts/install/tooling/install-civitai.sh  # optional — CivitAI SD extension
./07-setup-connectivity.sh   # optional — Telegram, Signal, Tailscale
```
