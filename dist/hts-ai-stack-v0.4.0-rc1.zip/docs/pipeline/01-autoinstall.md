# 01-autoinstall.sh — Autoinstall Verify / Host Setup

Installs and verifies all system-level dependencies. Each step checks first and
installs only if missing — safe to re-run at any time.

```bash
./01-autoinstall.sh
```

> Run this after `00-bootstrap.sh` completes and the NVIDIA reboot is done.
> `00-bootstrap.sh` now adds the current user to the `docker` group before the reboot.

---

## Step 0 — Host utilities

Installs host-level tools: `nvtop`, `tmux`, `ffmpeg`, `jq`, `ripgrep`, `btop`,
`bat`, `remmina`, `wireguard`. Skips already-installed packages.

---

## Step 1 — CUDA Toolkit

```bash
sudo apt install -y nvidia-cuda-toolkit nvidia-cuda-toolkit-gcc
nvcc --version
```

> The gcc compat package matters — CUDA's compiler wraps gcc and needs a specific
> version to work correctly.

---

## Step 2 — Docker group

Ensures the `docker` group exists and the current user is in it before Docker is
installed. If the current shell has not picked up the new group yet, the script
uses `sg docker` for Docker commands during the current run.

```bash
sudo groupadd docker            # only if missing
sudo usermod -aG docker $USER
```

---

## Step 3 — Docker Engine

Adds the official Docker apt repo and installs Docker CE, Compose plugin, and
containerd.

```bash
sudo apt install -y ca-certificates curl gnupg
# (see script for full repo setup)
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

Verify:

```bash
docker ps
```

---

## Step 4 — NVIDIA Container Toolkit

Adds the NVIDIA container toolkit repo, installs it, configures the Docker
runtime, and verifies GPU access inside a container.

```bash
# (see script for full repo setup)
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker
```

Verify GPU access inside a container:

```bash
docker run --rm --runtime=nvidia --gpus all nvidia/cuda:12.0.1-base-ubuntu22.04 nvidia-smi
```

---

## Step 5 — Node.js (NVM)

Installs NVM v0.39.7 and Node.js LTS. Required for NemoClaw CLI and the
repo-local markdown lint tooling.

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install --lts
nvm alias default 22
```

Verify:

```bash
node -v
npm -v
```

---

## Step 6 — Visual Studio Code

Adds the Microsoft apt repo and installs VS Code, then installs extensions:
markdownlint, Markdown All in One, cspell, ShellCheck, Remote SSH, Docker,
PowerShell, GitHub Copilot, and Claude Code.

---

## Step 7 — PowerShell 7

Registers the Microsoft package repository, installs PowerShell 7, and ensures
Pester (the test framework used by the repo's pre-commit hooks) is available.

```bash
sudo apt install -y powershell
pwsh -NoLogo -NoProfile -Command "Install-Module -Name Pester ..."
```

---

## Step 8 — Tokens (.env)

Generates `.env` with `WEBUI_SECRET_KEY` and `OPENCLAW_TOKEN` (both random
hex-32). Skips if `.env` already exists. File is `chmod 600` and git-ignored.

---

## Step 9 — Repo tooling

Runs `npm install` for repo-local Node tooling (markdownlint-cli2, cspell) and
installs git hooks via `tests/Install-GitHooks.ps1`.

```bash
npm install
pwsh -NoLogo -NoProfile -File tests/Install-GitHooks.ps1
```

---

## Step 10 — exFAT support

Installs `exfatprogs` for reading/writing exFAT USB drives.

---

## Step 11 — GNOME Remote Desktop (RDP)

GNOME Remote Desktop provides RDP-based remote access to your active desktop
session on port 3389 (primary protocol), with optional VNC on port 5900.
No additional installation needed—configure via:

```bash
./scripts/utils/remote-access.sh
```

Then navigate to: **Quick Setup** → **Both SSH and RDP** (or **RDP only**)

Or use the **Security Profiles** menu to apply hardening (Full Hardening,
LAN-Friendly, or OS Defaults).

> GNOME Remote Desktop is built-in to Ubuntu 24.04 and works with both Xorg
> and Wayland sessions. RDP (port 3389) is the primary protocol for better
> compatibility with Microsoft Remote Desktop clients.

---

## Step 12 — Verify prerequisites

Checks Docker, Docker Compose, NVIDIA CTK, and nvidia-smi are all responding.
Prints versions and GPU name. Warns on any missing component — does not exit.

---

## Next Steps

```bash
./02-setup-docker.sh                        # start the stack
./03-setup-models.sh                        # pull models
./04-setup-nemoclaw.sh                      # optional — NemoClaw agent runtime
bash scripts/install/tooling/install-civitai.sh        # optional — CivitAI SD extension
./06-start-stack.sh                         # start Ollama + OpenClaw
scripts/install/comms/setup-telegram.sh               # optional — Telegram bot
scripts/install/comms/setup-signal.sh                 # optional — Signal integration
scripts/install/networking/setup-tailscale.sh         # optional — secure remote access
```

```bash
sudo systemctl restart docker
```
