$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/ollama'
    $script:ComponentScript = Join-Path $script:ComponentDir 'ollama.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'ollama.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'ollama file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'ollama manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is ollama' {
        $script:Manifest.id | Should -Be 'ollama'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/ollama/ollama.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is ollama' {
        $script:Manifest.func_prefix | Should -Be 'ollama'
    }

    It 'dashboard port is 11434' {
        [int]$script:Manifest.dashboard.port | Should -Be 11434
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'ollama component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines ollama_install function' {
        $script:ComponentContent | Should -Match 'ollama_install\s*\(\)'
    }

    It 'defines ollama_configure function' {
        $script:ComponentContent | Should -Match 'ollama_configure\s*\(\)'
    }

    It 'defines ollama_start function' {
        $script:ComponentContent | Should -Match 'ollama_start\s*\(\)'
    }

    It 'defines ollama_stop function' {
        $script:ComponentContent | Should -Match 'ollama_stop\s*\(\)'
    }

    It 'defines ollama_health function' {
        $script:ComponentContent | Should -Match 'ollama_health\s*\(\)'
    }

    It 'defines ollama_pull_models function' {
        $script:ComponentContent | Should -Match 'ollama_pull_models\s*\(\)'
    }

    It 'defines ollama_swap_model function' {
        $script:ComponentContent | Should -Match 'ollama_swap_model\s*\(\)'
    }

    It 'supports --pull-models, --swap, --health, and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--pull-models\)'
        $script:ComponentContent | Should -Match '--swap\)'
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/ollama/ollama\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'ollama port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 11434 is registered in portmap.json' {
        $script:Portmap.ports.'11434' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'11434'.service | Should -Be 'ollama'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'ollama no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/ollama\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/ollama/ollama\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}

# ── Ollama compose tuning ───────────────────────────────────────────────────

Describe 'ollama compose tuning' {
    BeforeAll {
        $script:ComposeContent = Get-Content -Path (Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'compose sets OLLAMA_KEEP_ALIVE' {
        $script:ComposeContent | Should -Match 'OLLAMA_KEEP_ALIVE'
    }

    It 'compose limits max loaded models to 1' {
        $script:ComposeContent | Should -Match 'OLLAMA_MAX_LOADED_MODELS=1'
    }
}

# ── Ollama model management ─────────────────────────────────────────────────

Describe 'ollama model management' {
    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines ollama_swap_model function' {
        $script:ComponentContent | Should -Match 'ollama_swap_model\s*\(\)'
    }

    It 'defines _ollama_pull_if_missing helper' {
        $script:ComponentContent | Should -Match '_ollama_pull_if_missing\s*\(\)'
    }
}
