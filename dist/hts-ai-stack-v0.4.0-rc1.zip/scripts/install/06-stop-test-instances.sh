#!/usr/bin/env bash
# 06-stop-test-instances.sh — Stop the full stack
#
# Stops all services defined in docker-compose.yml
# (dashboard, ollama, open-webui)
#
# NemoClaw sandboxes are managed separately by the nemoclaw CLI.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
COMPOSE_FILE="$REPO_DIR/docker-compose.yml"

echo ""
echo "══ Stopping stack ══"
docker compose -f "$COMPOSE_FILE" stop
echo "  Stack stopped."

echo ""
echo "══ Current status ══"
docker compose -f "$COMPOSE_FILE" ps --format "table {{.Name}}\t{{.Status}}" 2>/dev/null || true

echo ""
echo "Done."
