# FEATURE-044 — PostHog Product Analytics

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | LOW |
| **Effort** | 4–8 hours |
| **Risk** | Medium — heavy sub-dependency chain (ClickHouse, Kafka, Redis, PostgreSQL) |
| **Target Release** | Unscheduled |
| **Depends on** | Nothing |
| **Blocks** | Nothing |

## Problem

There is no usage analytics for the AI stack. Understanding which models, services, and features are actually being used would help prioritize development and identify underused components. However, the stack currently has a single admin user, making product analytics premature.

## Solution

Self-host [PostHog](https://github.com/posthog/posthog) for product analytics — event tracking, session recording, feature flags, and A/B testing.

### Why deferred

PostHog is a powerful platform, but it carries significant infrastructure overhead:

- **ClickHouse** for event storage (high memory)
- **Kafka** for event ingestion pipeline
- **Redis** for caching and queues
- **PostgreSQL** for metadata
- **Worker processes** (Celery) for async tasks

This adds 4–5 additional containers and ~2–4 GB of RAM just for the analytics subsystem. For a single-user dev stack, Prometheus + Grafana already cover infrastructure monitoring.

### When to revisit

PostHog becomes valuable when:

- The stack serves multiple users (team or family deployment)
- There is a need to understand usage patterns across services
- Feature flag management is needed for gradual rollouts
- Open WebUI usage analytics are desired

### Integration points (future)

- Open WebUI → PostHog JS snippet for session recording
- n8n/DeerFlow → PostHog API events for workflow analytics
- Dashboard → embed PostHog dashboards

## Upstream

| Resource | Link |
|----------|------|
| GitHub | <https://github.com/posthog/posthog> |
| Self-host docs | <https://posthog.com/docs/self-host> |
| Docker compose | <https://posthog.com/docs/self-host/deploy/docker> |

## Notes

- PostHog offers a managed cloud tier with a generous free plan — could be used instead of self-hosting if analytics become needed before this feature ships
- Prometheus + Grafana remain the primary monitoring stack; PostHog would complement, not replace them
