#!/usr/bin/env bash
# scripts/components/localai/localai.sh — LocalAI: unified OpenAI-compatible local API
#
# Standalone usage:
#   ./scripts/components/localai/localai.sh                # full: install + configure + start + health
#   ./scripts/components/localai/localai.sh --install      # install only
#   ./scripts/components/localai/localai.sh --configure    # configure only
#   ./scripts/components/localai/localai.sh --start        # start only
#   ./scripts/components/localai/localai.sh --stop         # stop
#   ./scripts/components/localai/localai.sh --restart      # restart (stop + start)
#   ./scripts/components/localai/localai.sh --health       # health check only
#   ./scripts/components/localai/localai.sh --status       # show status + port + health
#   ./scripts/components/localai/localai.sh --destroy      # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
LOCALAI_PORT="${LOCALAI_PORT:-8080}"
LOCALAI_CONTAINER="${LOCALAI_CONTAINER:-hts-ai-localai}"

# ── Functions ─────────────────────────────────────────────────────────────────

localai_install() {
  step "LocalAI — build image"
  compose_build --profile localai
  ok "LocalAI image built."
}

localai_configure() {
  step "LocalAI — configure"
  info "No additional configuration needed — models downloaded at runtime via API."
  ok "LocalAI configured."
}

localai_start() {
  step "LocalAI — start"
  info "Starting containers..."
  compose_up --profile localai
  ok "LocalAI started on port ${LOCALAI_PORT}."
}

localai_stop() {
  step "LocalAI — stop"
  compose_down --profile localai
  ok "LocalAI stopped."
}

localai_restart() {
  localai_stop
  localai_start
}

localai_health() {
  step "LocalAI — health check"
  check_health "http://localhost:${LOCALAI_PORT}/readyz" 120
}

localai_status() {
  step "LocalAI — status"
  local cid
  cid=$(docker ps -qf "name=${LOCALAI_CONTAINER}" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    info "Container: running ($cid)"
    info "Port:      ${LOCALAI_PORT}"
    localai_health
  else
    warn "Container: not running"
  fi
}

localai_destroy() {
  step "LocalAI — destroy"
  compose_down --profile localai -v
  ok "LocalAI destroyed (containers + volumes removed)."
}

# ── CLI dispatch ──────────────────────────────────────────────────────────────
ACTION=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --install)   ACTION="install";   shift ;;
    --configure) ACTION="configure"; shift ;;
    --start)     ACTION="start";     shift ;;
    --stop)      ACTION="stop";      shift ;;
    --restart)   ACTION="restart";   shift ;;
    --health)    ACTION="health";    shift ;;
    --status)    ACTION="status";    shift ;;
    --destroy)   ACTION="destroy";   shift ;;
    *) shift ;;
  esac
done

case "${ACTION:-default}" in
  install)   localai_install   ;;
  configure) localai_configure ;;
  start)     localai_start     ;;
  stop)      localai_stop      ;;
  restart)   localai_restart   ;;
  health)    localai_health    ;;
  status)    localai_status    ;;
  destroy)   localai_destroy   ;;
  default)   localai_install; localai_configure; localai_start; localai_health ;;
esac
