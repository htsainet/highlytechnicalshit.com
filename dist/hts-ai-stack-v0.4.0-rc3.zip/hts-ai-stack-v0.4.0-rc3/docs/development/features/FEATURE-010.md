# Full Drift Detection — Live State Convergence

**Priority:** MEDIUM
**Effort:** 12-16 hours
**Risk:** Medium — inspecting live container state is fragile across Docker/Compose
version differences; edge cases around manually modified containers
**Target Release:** v0.6.0
**Depends on:** FEATURE-009 (Config-Driven Convergence)
**Blocks:** Nothing

## Scope

Extend FEATURE-009's convergence script to detect **runtime drift** — cases
where the live container state no longer matches `stack.json`, even if
`.last-applied.json` says it was applied. This catches manual changes made
outside the installer (e.g., `docker run` with different ports, env var edits
via `docker exec`, volume mounts changed by hand).

### Drift Sources Detected

| Category | How detected | Example drift |
|----------|-------------|---------------|
| **Container missing** | `docker ps -a --filter name=` | Container deleted manually |
| **Container stopped** | `.State.Status` via `docker inspect` | Container crashed or was stopped |
| **Wrong port** | `.NetworkSettings.Ports` vs `stack.json` | Port changed via `docker run -p` |
| **Wrong env vars** | `.Config.Env` vs expected `.env` values | Env var edited manually |
| **Wrong image** | `.Config.Image` vs compose config | Image tag updated outside compose |
| **Health failing** | `.State.Health.Status` | Container running but unhealthy |
| **Volume mismatch** | `.Mounts` vs compose volumes | Volume path changed manually |
| **NAS mount missing** | `mountpoint -q` / `findmnt` | NFS share unmounted or stale |

### Execution Modes

Same flags as FEATURE-009, plus:

| Mode | Flag | Behaviour |
|------|------|-----------|
| **Audit only** | `--audit` | Report drift without fixing anything |
| **Fix drift** | `--fix-drift` | Detect and repair runtime drift |

### Output Format

```text
$ converge.sh --audit

Drift Report (2026-04-08 14:30:00)
───────────────────────────────────
  ollama        ✓ running, healthy, config matches
  open-webui    ✓ running, healthy, config matches
  bitnet        ⚠ stopped (expected: running)
  llama-swap    ⚠ port mismatch (running: 8082, expected: 8081)
  dashboard     ✗ container missing
  tailscale     ✓ running, healthy, config matches

Actions needed: 3
  → bitnet: start container
  → llama-swap: reconfigure port, restart
  → dashboard: install + start
```

## Implementation Notes

### State Probing Functions

New functions in `lib/health.sh` or a new `lib/state.sh`:

- `container_state <name>` — returns running/stopped/missing
- `container_ports <name>` — returns published port map
- `container_env <name> <key>` — returns env var value from running container
- `container_image <name>` — returns image:tag
- `container_health <name>` — returns healthy/unhealthy/none
- `mount_state <path>` — returns mounted/unmounted/stale

### Diff Engine

Builds a structured diff (bash associative array or temp JSON via `jq`)
comparing desired state (from `stack.json`) against probed live state.
Each entry produces an action: `ok`, `start`, `stop`, `restart`,
`reconfigure`, `install`, or `repair-mount`.

### Integration with FEATURE-009

The FEATURE-009 convergence loop becomes:

1. **Config diff** (FEATURE-009): `stack.json` vs `.last-applied.json`
2. **State diff** (this feature): `stack.json` vs live Docker/mount state
3. **Merge**: union of both diffs → final action plan
4. **Execute**: dispatch to component lifecycle functions

`--fix-drift` enables step 2; without it, only step 1 runs (FEATURE-009
behaviour preserved).

## Acceptance Criteria

- [ ] `converge.sh --audit` reports all drift categories without side effects
- [ ] `converge.sh --fix-drift` repairs stopped containers
- [ ] `converge.sh --fix-drift` detects and fixes port mismatches
- [ ] `converge.sh --fix-drift` detects and reinstalls missing containers
- [ ] `converge.sh --fix-drift` detects stale NFS mounts and remounts
- [ ] Audit output is human-readable with colour-coded status
- [ ] `--audit` returns exit code 0 if no drift, 1 if drift detected
- [ ] Works on both fresh installs and long-running machines
