#!/usr/bin/env bash
# scripts/components/paperclip/paperclip.sh — Paperclip AI agent manager
#
# Standalone usage:
#   ./scripts/components/paperclip/paperclip.sh              # full: install + configure + start + health
#   ./scripts/components/paperclip/paperclip.sh --install    # install only
#   ./scripts/components/paperclip/paperclip.sh --configure  # configure only
#   ./scripts/components/paperclip/paperclip.sh --start      # start only
#   ./scripts/components/paperclip/paperclip.sh --stop       # stop
#   ./scripts/components/paperclip/paperclip.sh --restart    # restart (stop + start)
#   ./scripts/components/paperclip/paperclip.sh --health     # health check only
#   ./scripts/components/paperclip/paperclip.sh --status     # show status + port + health
#   ./scripts/components/paperclip/paperclip.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

load_env
PAPERCLIP_PORT="${PAPERCLIP_PORT:-3101}"
PAPERCLIP_CONTAINER="${PAPERCLIP_CONTAINER:-hts-ai-paperclip-1}"

# ── Lifecycle functions ───────────────────────────────────────────────────────

paperclip_install() {
  step "Paperclip — install"
  compose_build --profile paperclip paperclip
  ok "Paperclip image built."
}

paperclip_configure() {
  step "Paperclip — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^PAPERCLIP_PORT=" "$env_file" 2>/dev/null; then
    printf 'PAPERCLIP_PORT=%s\n' "$PAPERCLIP_PORT" >> "$env_file"
    info "Added PAPERCLIP_PORT=${PAPERCLIP_PORT} to .env"
  fi

  # Generate a strong auth secret if not already set
  if ! grep -q "^PAPERCLIP_AUTH_SECRET=" "$env_file" 2>/dev/null; then
    local secret
    secret=$(openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64)
    printf 'PAPERCLIP_AUTH_SECRET=%s\n' "$secret" >> "$env_file"
    info "Generated PAPERCLIP_AUTH_SECRET in .env"
  fi

  ok "Paperclip configured (port ${PAPERCLIP_PORT})."
}

paperclip_start() {
  step "Paperclip — start"
  compose_up --profile paperclip paperclip

  # Auto-onboard + bootstrap if first run
  _paperclip_auto_onboard

  ok "Paperclip started on port ${PAPERCLIP_PORT}."
}

# _paperclip_auto_onboard — run onboard quickstart + bootstrap-ceo if no config exists
_paperclip_auto_onboard() {
  local container="hts-ai-paperclip"
  local config_check

  # Wait for the server to be responsive
  local attempts=0
  while [[ $attempts -lt 15 ]]; do
    if curl -sf "http://localhost:${PAPERCLIP_PORT}/api/health" >/dev/null 2>&1; then
      break
    fi
    sleep 2
    ((attempts++))
  done

  # Check if already onboarded (config.json exists inside container)
  config_check=$(docker exec "$container" test -f /home/paperclip/.paperclip/instances/default/config.json 2>/dev/null && echo "yes" || echo "no")
  if [[ "$config_check" == "yes" ]]; then
    info "Paperclip already onboarded — skipping"
    return 0
  fi

  info "First run detected — running automated onboard..."

  # Run quickstart onboard non-interactively via env vars
  docker exec "$container" npx tsx /app/cli/src/index.ts onboard --quickstart 2>&1 | tail -5 || {
    warn "Onboard quickstart failed — try manually: docker exec -it $container npx tsx /app/cli/src/index.ts onboard"
    return 0
  }

  # Restart to pick up onboard config
  info "Restarting Paperclip to apply onboard config..."
  docker restart "$container" >/dev/null 2>&1
  sleep 5

  # Generate bootstrap CEO invite
  info "Generating admin invite..."
  local invite_output
  invite_output=$(docker exec "$container" npx tsx /app/cli/src/index.ts auth bootstrap-ceo 2>&1) || {
    warn "Bootstrap-ceo failed — try manually: docker exec -it $container npx tsx /app/cli/src/index.ts auth bootstrap-ceo"
    return 0
  }

  # Extract and display invite URL
  local invite_url
  invite_url=$(echo "$invite_output" | grep -oP 'http://\S+/invite/\S+' | head -1)
  if [[ -n "$invite_url" ]]; then
    # Rewrite localhost to 127.0.0.1 with the correct external port
    invite_url="${invite_url//localhost/127.0.0.1}"
    invite_url=$(echo "$invite_url" | sed "s|:3[0-9]\{3\}/|:${PAPERCLIP_PORT}/|")

    # Write notification to dashboard
    local notif_file="$REPO_DIR/resources/dashboard/notifications.json"
    local expires
    expires=$(date -u -d "+72 hours" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u +%Y-%m-%dT%H:%M:%SZ)
    cat > "$notif_file" <<NOTIF_EOF
[
  {
    "service": "paperclip",
    "label": "ACCEPT INVITE",
    "url": "${invite_url}",
    "expires": "${expires}"
  }
]
NOTIF_EOF
    info "Invite URL posted to dashboard"

    echo ""
    echo -e "${CYAN}${BOLD}┌──────────────────────────────────────────────────┐${NC}"
    echo -e "${CYAN}${BOLD}│  Paperclip Admin Invite URL:                     │${NC}"
    echo -e "${CYAN}${BOLD}│  ${invite_url}${NC}"
    echo -e "${CYAN}${BOLD}│  Expires in 72 hours — open in browser to setup  │${NC}"
    echo -e "${CYAN}${BOLD}└──────────────────────────────────────────────────┘${NC}"
    echo ""
  else
    info "Invite generated — check output above for URL"
  fi
}

paperclip_stop() {
  step "Paperclip — stop"
  compose_down --profile paperclip paperclip
  ok "Paperclip stopped."
}

paperclip_health() {
  health_probe "Paperclip :${PAPERCLIP_PORT}" "http://localhost:${PAPERCLIP_PORT}/api/health"
}

paperclip_restart() {
  paperclip_stop
  paperclip_start
}

paperclip_destroy() {
  step "Paperclip — destroy"
  compose_down --profile paperclip paperclip -v
  ok "Paperclip destroyed."
}

paperclip_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=paperclip" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Paperclip is running (port ${PAPERCLIP_PORT})"
  else
    warn "Paperclip is not running."
  fi
  paperclip_health 2>/dev/null || true
}

# ── Standalone execution ──────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   paperclip_install   ;;
    configure) paperclip_configure ;;
    start)     paperclip_start     ;;
    stop)      paperclip_stop      ;;
    restart)   paperclip_restart   ;;
    health)    paperclip_health    ;;
    status)    paperclip_status    ;;
    destroy)   paperclip_destroy   ;;
    default)
      paperclip_install
      paperclip_configure
      paperclip_start
      paperclip_health
      ;;
  esac
fi
