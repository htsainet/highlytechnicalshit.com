# Gitea References

Last updated: 2026-04-15

## Upstream

- [GitHub — go-gitea/gitea](https://github.com/go-gitea/gitea)
- [Gitea.com](https://about.gitea.com/)

## Official documentation

- [Gitea Docs](https://docs.gitea.com/)
