#!/usr/bin/env bash
# scripts/utils/diagnose-nemoclaw-llamaswap.sh — run focused NemoClaw/llama-swap diagnostics
#
# Usage:
#   ./scripts/utils/diagnose-nemoclaw-llamaswap.sh
#   NEMOCLAW_MODEL=mistral-nemo:latest ./scripts/utils/diagnose-nemoclaw-llamaswap.sh

set -euo pipefail

GATEWAY="${NEMOCLAW_GATEWAY_NAME:-nemoclaw}"
SANDBOX="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"
SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"
MODEL="${NEMOCLAW_MODEL:-mistral-nemo:latest}"
COMPATIBLE_API_KEY="${COMPATIBLE_API_KEY:-not-needed}"
LLAMA_SWAP_CONTAINER="${LLAMA_SWAP_CONTAINER:-hts-ai-llama-swap}"
OLLAMA_CONTAINER="${OLLAMA_CONTAINER:-hts-ai-ollama}"

section() {
  printf '\n── %s ─────────────────────────────────────────────────────────────\n' "$1"
}

show_cmd() {
  printf '[cmd] %s\n' "$1"
}

run_cmd() {
  local label="$1"
  shift
  section "$label"
  show_cmd "$*"
  if "$@"; then
    return 0
  fi
  local rc=$?
  printf '[warn] command exited %d\n' "$rc"
  return 0
}

run_bash_cmd() {
  local label="$1"
  local cmd="$2"
  section "$label"
  show_cmd "$cmd"
  if bash -lc "$cmd"; then
    return 0
  fi
  local rc=$?
  printf '[warn] command exited %d\n' "$rc"
  return 0
}

printf 'NemoClaw / llama-swap diagnostics\n'
printf 'gateway=%s sandbox=%s swap_port=%s model=%s\n' \
  "$GATEWAY" "$SANDBOX" "$SWAP_PORT" "$MODEL"

run_bash_cmd \
  "Host Ollama model list" \
  "docker compose exec -T ollama ollama list || docker exec -i ${OLLAMA_CONTAINER} ollama list"

run_bash_cmd \
  "Host llama-swap completion probe" \
  "curl -fsS -H 'Authorization: Bearer ${COMPATIBLE_API_KEY}' -H 'Content-Type: application/json' -d '{\"model\":\"${MODEL}\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"max_tokens\":1,\"stream\":false}' http://localhost:${SWAP_PORT}/v1/chat/completions"

run_bash_cmd \
  "llama-swap logs (tail 100)" \
  "docker logs --tail 100 ${LLAMA_SWAP_CONTAINER}"

run_cmd "OpenShell provider list" openshell provider list
run_cmd "OpenShell compatible-endpoint provider" openshell provider get compatible-endpoint
run_cmd "OpenShell llama-swap-local provider" openshell provider get llama-swap-local

run_bash_cmd \
  "Sandbox proxy environment" \
  "openshell sandbox exec -g '${GATEWAY}' -n '${SANDBOX}' -- sh -lc 'env | grep -i proxy || true'"

run_bash_cmd \
  "Sandbox llama-swap completion probe" \
  "openshell sandbox exec -g '${GATEWAY}' -n '${SANDBOX}' -- sh -lc \"curl -fsS --max-time 20 -H 'Authorization: Bearer ${COMPATIBLE_API_KEY}' -H 'Content-Type: application/json' -d '{\\\"model\\\":\\\"${MODEL}\\\",\\\"messages\\\":[{\\\"role\\\":\\\"user\\\",\\\"content\\\":\\\"hi\\\"}],\\\"max_tokens\\\":1,\\\"stream\\\":false}' http://host.openshell.internal:${SWAP_PORT}/v1/chat/completions\""

run_bash_cmd \
  "Sandbox llama-swap completion probe (bypass proxies)" \
  "openshell sandbox exec -g '${GATEWAY}' -n '${SANDBOX}' -- sh -lc \"curl --noproxy '*' -fsS --max-time 20 -H 'Authorization: Bearer ${COMPATIBLE_API_KEY}' -H 'Content-Type: application/json' -d '{\\\"model\\\":\\\"${MODEL}\\\",\\\"messages\\\":[{\\\"role\\\":\\\"user\\\",\\\"content\\\":\\\"hi\\\"}],\\\"max_tokens\\\":1,\\\"stream\\\":false}' http://host.openshell.internal:${SWAP_PORT}/v1/chat/completions\""
