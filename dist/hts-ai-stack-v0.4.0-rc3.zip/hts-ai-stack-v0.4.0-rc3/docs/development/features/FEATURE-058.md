# FEATURE-058 — OpenShell Sandbox Tier (Agent / Code-Exec Services)

| Field | Value |
|-------|-------|
| Status | Proposed |
| Category | Security / Runtime Isolation |
| Target Release | v0.6.0+ (after FEATURE-055 + OpenShell reaches beta) |
| Priority | MEDIUM |
| Effort | L |
| Components | Existing `nemoclaw` (reference), new or extended classification for `htsclaw`, `n8n`, `flowise`, `langflow`, any hosted code-exec tool |
| Dependencies | [OpenShell](https://github.com/NVIDIA/OpenShell) (already a stack dep for NemoClaw); FEATURE-055 (for L7 auth on the services themselves) |
| Related | FEATURE-055 (Authelia), FEATURE-056 (microsegmentation), FEATURE-057 (Falco runtime detection), SECURITY-009 (volume/secret isolation) |

## Summary

Classify every stack component by whether it executes **untrusted or
agent-supplied code**, and route that subset through an **OpenShell
sandbox tier** with L7 egress policies.

OpenShell (NVIDIA, Apache 2.0) is a sandbox runtime built agent-first:
each sandbox is a container with policy-enforced egress filtered at
the HTTP method + path level, applied live via declarative YAML.
NemoClaw already integrates with it. This feature extends the pattern
to other stack components whose threat model is "runs code written by
an agent, a user workflow, or an untrusted skill".

## Intent

Establish a clear doctrine:

> **OpenShell sandboxes any component that executes untrusted or
> agent-supplied code. Trusted inference and data services remain on
> standard Docker runtime, protected by the FEATURE-055/056 perimeter
> (Traefik + Authelia + microsegmentation).**

## Tier classification

Add to manifest schema:

```json
"sandbox": {
  "tier": "openshell" | "docker",
  "gateway": "default" | "<custom-gateway-name>",
  "egress_policy": "stack/openshell/policies/<component>.yaml"
}
```

Initial classification guess (refine per service):

| Component | Tier | Rationale |
|---|---|---|
| nemoclaw | openshell | Already integrated (reference impl) |
| htsclaw | openshell (TBD) | Agent sandbox by design |
| n8n | openshell | Runs user-authored JS / shell nodes |
| flowise | openshell | User chains arbitrary code/tool calls |
| langflow | openshell | Same |
| aider (if hosted) | openshell | Runs agent edits against code |
| opencode (if hosted) | openshell | Same |
| ollama, localai, llama-swap | docker | Trusted inference; GPU-bound |
| open-webui | docker | UI in front of Ollama; not code-exec |
| comfyui, animatediff, cogvideox | docker | Trusted image/video gen; GPU-bound |
| gitea, gitea-runner | docker | Runner is arguably code-exec but has its own sandboxing model |
| grafana, prometheus, loki | docker | Pure observability |
| postgres/redis/etc. | docker | Data plane |
| duplicati | docker | Backup tool, not code-exec |

## Phases

### Phase 1 — Manifest schema + audit
- Define `sandbox` block in manifest schema
- Audit every component; set tier based on "does this run agent or
  user-authored code?"
- Commit the classification as a single chore PR

### Phase 2 — OpenShell gateway component
- `scripts/components/openshell/openshell.sh` — gateway lifecycle
  (NemoClaw has this partially; refactor to a proper component)
- `stack/openshell/policies/` — per-component egress policies
- `openshell.manifest.json` with dashboard entry for policy status

### Phase 3 — Policy authoring
For each `sandbox: openshell` service, write an egress policy:
- **n8n** — allow outbound to declared webhook targets + LLM endpoints only
- **flowise / langflow** — similar, plus the stack's Ollama endpoint
- **agent tools (aider/opencode)** — GitHub API + LLM endpoints only, no arbitrary web

### Phase 4 — Generator integration
- Generator reads `sandbox.tier` and emits either standard
  docker-compose stanza (runc) or OpenShell sandbox-create invocation
- For OpenShell services, Traefik sits in front of the sandbox's
  exposed port via the OpenShell gateway's port-forwarding

### Phase 5 — Docs + runbooks
- `docs/security/sandbox-architecture.md` — the tiering doctrine
- `docs/security/openshell-policies.md` — how to author a policy
- Per-component CONTEXT.md updated with sandbox tier rationale

## Open questions

- **OpenShell maturity** — alpha / single-player. Should v1 only target
  `nemoclaw` + `htsclaw` and defer n8n/flowise/langflow to v2 once
  OpenShell hits beta? Likely yes.
- **GPU passthrough** — OpenShell's GPU story isn't clear in current
  docs. For components that need GPU + sandboxing (rare — most GPU
  services are trusted inference), verify before classifying.
- **Ingress path** — does the OpenShell gateway play nicely with
  Traefik forward-auth labels, or do we need a shim?

## Risks & mitigations

| Risk | Mitigation |
|---|---|
| OpenShell alpha breakage | Pin version, track releases, keep NemoClaw as canary |
| GPU + OpenShell incompatibility | Classify as `docker` for anything GPU-dependent |
| Policy drift (policy too permissive over time) | Version policies in git; review in PR |
| Performance overhead | Benchmark per service; revert to `docker` if unacceptable |

## Acceptance criteria

- [ ] Every component has a `sandbox` block in its manifest.
- [ ] NemoClaw's existing OpenShell integration refactored into the
      new component-based pattern without regression.
- [ ] At least one non-NemoClaw service (candidate: n8n) successfully
      runs in OpenShell with an explicit egress policy.
- [ ] Egress policy violations are observable (log + optional Falco alert).
- [ ] Doctrine documented and referenced from CONTEXT.md of every
      sandboxed component.

## Out of scope

- Replacing Docker entirely (not the goal)
- OpenShell for trusted inference (wrong fit)
- Multi-tenant OpenShell (upstream isn't there yet)
