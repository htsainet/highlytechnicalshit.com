# Blender — References

## Upstream

- **Homepage**: <https://www.blender.org/>
- **Source**: <https://projects.blender.org/blender/blender>
- **Snap package**: <https://snapcraft.io/blender>
- **Manual**: <https://docs.blender.org/manual/>
- **CUDA rendering**: <https://docs.blender.org/manual/en/latest/render/cycles/gpu_rendering.html>

## Notes

- Snap provides the latest stable Blender without PPA management
- Cycles GPU rendering requires NVIDIA drivers and CUDA toolkit
- Blender also supports OpenCL and OptiX for rendering
