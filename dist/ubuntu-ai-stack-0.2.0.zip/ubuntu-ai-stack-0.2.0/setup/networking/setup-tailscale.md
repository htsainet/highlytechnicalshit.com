# setup-tailscale.sh — Tailscale VPN

Connects this machine to your Tailscale network so you can reach the AI stack
securely from anywhere without exposing ports to the internet.

```bash
./setup-tailscale.sh
```

> If `tailscale` is not already installed, this script bootstraps the official
> Ubuntu 24.04 Tailscale apt repository and installs it before authentication.

---

## Prerequisites

- A free Tailscale account at [tailscale.com](https://tailscale.com)
- Either:
  - An **auth key** from [tailscale.com/admin/settings/keys](https://login.tailscale.com/admin/settings/keys), or
  - A browser available to complete OAuth

Optionally pre-set the auth key in `.env` to skip the prompt:

```bash
echo "TAILSCALE_AUTHKEY=tskey-auth-xxxx" >> .env
```

---

## What it does

| Step | Action |
|---|---|
| 1 | Verifies `tailscale` is installed; if missing, adds the Tailscale apt repo and installs it |
| 2 | Reads `TAILSCALE_AUTHKEY` from `.env` or prompts (Enter for browser auth) |
| 3 | Enables `tailscaled`, runs `tailscale up` |
| 4 | Prints the assigned Tailscale IP and status |

If you want to install it manually instead, these are the Ubuntu 24.04 commands:

```bash
curl -fsSL https://pkgs.tailscale.com/stable/ubuntu/noble.noarmor.gpg \
  | sudo tee /usr/share/keyrings/tailscale-archive-keyring.gpg >/dev/null
curl -fsSL https://pkgs.tailscale.com/stable/ubuntu/noble.tailscale-keyring.list \
  | sudo tee /etc/apt/sources.list.d/tailscale.list >/dev/null
sudo apt-get update
sudo apt-get install tailscale
```

---

## After setup

Your server gets a stable `100.x.x.x` IP on your tailnet. Use it to reach
services from any device that's also on your tailnet:

| Service | URL via Tailscale |
|---|---|
| Open WebUI | `http://100.x.x.x:3000` |
| OpenClaw | `http://100.x.x.x:18790` |
| Stable Diffusion | `http://100.x.x.x:7860` |
| SSH | `ssh youruser@100.x.x.x` |

```bash
# Check current status
tailscale status

# Get your Tailscale IP
tailscale ip -4
```

---

## Security note

Tailscale uses WireGuard end-to-end encryption. Your traffic never passes
through Tailscale's servers — only the connection negotiation does. For
maximum security, remove or restrict the public `ports:` mappings in
`docker-compose.yaml` and access services via Tailscale IP only.
