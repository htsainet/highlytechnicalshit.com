#!/usr/bin/env bash
# backups/setup-timeshift.sh — Install and configure Timeshift system snapshots
#
# Creates incremental system snapshots using Timeshift (RSYNC or BTRFS mode,
# auto-detected from your root filesystem). Excludes Docker data, model files,
# NAS mounts, and other large disposable directories so snapshots stay lean.
#
# Takes an initial "AI stack baseline" snapshot on first run.
#
# Usage:
#   sudo ./backups/setup-timeshift.sh [options]
#
# Options:
#   --device <path>    Snapshot storage device (e.g. /dev/sdb1)
#                      Defaults to the root partition (prompted if multiple found)
#   --skip-snapshot    Configure only — skip the initial snapshot
#   --dry-run          Print every action without making changes
#   -h, --help         Show this help

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
skip()  { echo -e "${YELLOW}[SKIP]${NC} $* — already done"; }
step()  { echo -e "\n${CYAN}══ $* ══${NC}"; }
fail()  { echo -e "${RED}[FAIL]${NC} $*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || fail "Must be run as root: sudo $0 $*"

# ── Argument parsing ───────────────────────────────────────────────────────────
SNAPSHOT_DEVICE=""
SKIP_SNAPSHOT=false
DRY_RUN=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --device)        SNAPSHOT_DEVICE="$2"; shift 2 ;;
    --skip-snapshot) SKIP_SNAPSHOT=true;   shift ;;
    --dry-run)       DRY_RUN=true;         shift ;;
    -h|--help)       grep '^# ' "$0" | sed 's/^# \?//'; exit 0 ;;
    *) fail "Unknown option: $1" ;;
  esac
done

run() {
  if "$DRY_RUN"; then
    echo "  [dry-run] $*"
  else
    "$@"
  fi
}

echo ""
echo "══ Timeshift Setup ══"
echo ""

# ── Step 1: Install Timeshift ──────────────────────────────────────────────────
step "1 — Install Timeshift"

if command -v timeshift &>/dev/null; then
  skip "Timeshift ($(timeshift --version 2>/dev/null | head -1 || echo 'installed'))"
else
  info "Installing Timeshift..."
  run apt-get update -qq
  run apt-get install -y --no-install-recommends timeshift
  ok "Timeshift installed"
fi

# ── Step 2: Detect snapshot mode ──────────────────────────────────────────────
step "2 — Detect snapshot mode"

FS_TYPE=$(df -T / | tail -1 | awk '{print $2}')
info "Root filesystem type: ${FS_TYPE}"

if [[ "$FS_TYPE" == "btrfs" ]]; then
  BTRFS_MODE="true"
  info "Mode: BTRFS (native snapshots)"
else
  BTRFS_MODE="false"
  info "Mode: RSYNC (incremental with hard links)"
fi

# ── Step 3: Select snapshot device ────────────────────────────────────────────
step "3 — Select snapshot device"

ROOT_DEV=$(df / | tail -1 | awk '{print $1}')
info "Root device: ${ROOT_DEV}"

if [[ -n "$SNAPSHOT_DEVICE" ]]; then
  info "Using specified device: ${SNAPSHOT_DEVICE}"
else
  # Look for non-root block devices that are mounted or available
  CANDIDATES=$(lsblk -rno NAME,TYPE,MOUNTPOINT | \
    awk '$2=="part" && $3!="" && $3!="/" && $3!="[SWAP]" && $3!="/boot" && $3!="/boot/efi" {print "/dev/" $1 " → " $3}' || true)

  if [[ -n "$CANDIDATES" ]]; then
    echo ""
    warn "Multiple storage devices found. Using root partition as fallback."
    warn "For best practice, use a separate partition. Options:"
    echo "$CANDIDATES" | while read -r line; do echo "  $line"; done
    echo ""
    warn "Re-run with --device /dev/sdXN to use a specific partition."
    SNAPSHOT_DEVICE="$ROOT_DEV"
  else
    warn "No separate storage partition detected — using root partition."
    warn "Recommended: add a dedicated partition and re-run with --device /dev/sdXN"
    SNAPSHOT_DEVICE="$ROOT_DEV"
  fi
fi

# Get UUID of snapshot device
SNAPSHOT_UUID=$(blkid -s UUID -o value "$SNAPSHOT_DEVICE" 2>/dev/null || true)
if [[ -z "$SNAPSHOT_UUID" ]]; then
  fail "Could not determine UUID for ${SNAPSHOT_DEVICE}. Check the device path."
fi
info "Snapshot device UUID: ${SNAPSHOT_UUID}"

# ── Step 4: Write Timeshift configuration ─────────────────────────────────────
step "4 — Configure Timeshift"

TIMESHIFT_CONF="/etc/timeshift/timeshift.json"
run mkdir -p /etc/timeshift

# Exclusions tuned for the AI stack:
#   - /var/lib/docker/**  Docker storage (managed separately, huge, volatile)
#   - /home/*/models/**   Local model staging dirs (seeded from NAS)
#   - /mnt/**             NAS mounts (remote, not ours to snapshot)
#   - /media/**           Removable media
#   - **/node_modules/** Node deps (reinstallable)
#   - Standard Timeshift defaults: /home, /root, /tmp, /var/cache, /var/log, /swapfile

if "$DRY_RUN"; then
  echo "  [dry-run] Would write ${TIMESHIFT_CONF}"
else

cat > "$TIMESHIFT_CONF" <<'CONF'
{
  "backup_device_uuid" : "PLACEHOLDER_UUID",
  "parent_device_uuid" : "",
  "do_first_run" : "false",
  "btrfs_mode" : "PLACEHOLDER_BTRFS",
  "include_btrfs_home_for_backup" : "false",
  "include_btrfs_home_for_restore" : "false",
  "stop_cron_emails" : "true",
  "btrfs_use_qgroup" : "true",
  "schedule_monthly" : "true",
  "schedule_weekly" : "true",
  "schedule_daily" : "true",
  "schedule_hourly" : "false",
  "schedule_boot" : "true",
  "count_monthly" : "2",
  "count_weekly" : "3",
  "count_daily" : "5",
  "count_hourly" : "0",
  "count_boot" : "3",
  "date_format" : "%Y-%m-%d %H:%M:%S",
  "exclude" : [
    "+ /root/.**",
    "- /root/**",
    "- /home/**",
    "- /tmp/**",
    "- /var/tmp/**",
    "- /var/cache/**",
    "- /var/log/**",
    "- /swapfile",
    "- /var/lib/docker/**",
    "- /var/lib/containerd/**",
    "- /var/lib/lxc/**",
    "- /var/lib/libvirt/images/**",
    "- /home/*/models/**",
    "- /mnt/**",
    "- /media/**",
    "- **/node_modules/**",
    "- **/.gradle/**",
    "- **/__pycache__/**",
    "- *.iso"
  ],
  "exclude-apps" : []
}
CONF

# Substitute UUIDs and mode
sed -i \
  -e "s/PLACEHOLDER_UUID/${SNAPSHOT_UUID}/" \
  -e "s/PLACEHOLDER_BTRFS/${BTRFS_MODE}/" \
  "$TIMESHIFT_CONF"

fi

ok "Configuration written: ${TIMESHIFT_CONF}"
info "Schedule: daily×5, weekly×3, monthly×2, boot×3"
info "Excluded: Docker data, model dirs, NAS mounts, tmp, caches, logs"

# ── Step 5: Enable Timeshift cron ─────────────────────────────────────────────
step "5 — Enable scheduled snapshots"

# Timeshift installs its own cron on first --check run
run timeshift --check --scripted 2>/dev/null || true

if [[ -f /etc/cron.d/timeshift-hourly ]]; then
  ok "Timeshift cron job active"
else
  warn "Cron job not created yet — will appear after first scheduled run"
fi

# ── Step 6: Initial baseline snapshot ─────────────────────────────────────────
step "6 — Initial snapshot"

if "$SKIP_SNAPSHOT"; then
  info "Skipping initial snapshot (--skip-snapshot)"
elif "$DRY_RUN"; then
  echo "  [dry-run] Would run: timeshift --create --comments 'AI stack baseline' --tags O --scripted"
else
  info "Creating baseline snapshot (this may take a few minutes)..."
  timeshift --create \
    --comments "AI stack baseline — $(date '+%Y-%m-%d')" \
    --tags O \
    --scripted \
    && ok "Baseline snapshot created" \
    || warn "Snapshot creation failed — check: journalctl -xe | grep timeshift"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
ok "Timeshift configured."
echo ""
echo "  Useful commands:"
echo "    sudo timeshift --list                           # list snapshots"
echo "    sudo timeshift --create --comments 'Before X'  # manual snapshot"
echo "    sudo timeshift --restore                        # interactive restore"
echo "    sudo cat ${TIMESHIFT_CONF}               # view config"
echo ""
echo "  Create a snapshot before major changes:"
echo "    sudo timeshift --create --comments 'Before apt upgrade' --tags O --scripted"
echo ""
