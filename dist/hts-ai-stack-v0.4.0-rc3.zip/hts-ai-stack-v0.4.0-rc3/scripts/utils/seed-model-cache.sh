#!/usr/bin/env bash
set -euo pipefail
# ─────────────────────────────────────────────────────────────────────────────
# seed-model-cache.sh — Populate a local or network model cache from the
# central registry (scripts/install/models/registry.json).
#
# Reads all Ollama and SD models from registry.json and downloads them to
# the specified destination. Works with NAS mounts, local SSDs, USB drives,
# or any writable path.
#
# Prerequisites:
#   - jq (JSON parser)
#   - Docker running with NVIDIA GPU access (for Ollama models)
#   - curl (for SD checkpoint downloads)
#   - Internet connectivity
#
# Usage:
#   ./seed-model-cache.sh                              # Interactive destination prompt
#   ./seed-model-cache.sh --dest /mnt/htsai-model-backup    # NAS mount
#   ./seed-model-cache.sh --dest ~/model-cache          # Local path
#   ./seed-model-cache.sh --dest /media/usb/models      # USB drive
#   ./seed-model-cache.sh --ollama                      # Ollama models only
#   ./seed-model-cache.sh --sd                          # SD checkpoints only
#   ./seed-model-cache.sh --env prod                    # Only prod models
#   ./seed-model-cache.sh --env test                    # Only test models
#   ./seed-model-cache.sh --dry-run                     # Preview what would download
#   ./seed-model-cache.sh --list                        # List all registered models
# ─────────────────────────────────────────────────────────────────────────────

# ── Resolve script + repo paths ─────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR" && git rev-parse --show-toplevel 2>/dev/null || echo "$SCRIPT_DIR")"
REGISTRY="${REPO_ROOT}/scripts/install/models/registry.json"

# ── Colors & logging ────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
fail()  { echo -e "${RED}[FAIL]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
step()  { echo -e "\n${CYAN}══ $* ══${NC}"; }
skip()  { echo -e "${YELLOW}[SKIP]${NC} $* — already cached"; }

# ── Parse args ──────────────────────────────────────────────────────────────
DEST=""
DO_OLLAMA=true
DO_SD=true
DRY_RUN=false
LIST_ONLY=false
ENV_FILTER=""  # empty = all environments

for arg in "$@"; do
  case "$arg" in
    --dest)     shift_next=dest ;;
    --env)      shift_next=env ;;
    --ollama)   DO_SD=false ;;
    --sd)       DO_OLLAMA=false ;;
    --dry-run)  DRY_RUN=true ;;
    --list)     LIST_ONLY=true ;;
    -h|--help)
      cat <<EOF
Usage: $(basename "$0") [OPTIONS]

Options:
  --dest PATH     Destination directory for cached models (prompted if omitted)
  --env ENV       Filter by environment: prod, test, or all (default: all)
  --ollama        Seed Ollama models only
  --sd            Seed SD checkpoints only
  --dry-run       Show what would be downloaded without downloading
  --list          List all models in the registry and exit
  -h, --help      Show this help

Examples:
  $(basename "$0") --dest /mnt/htsai-model-backup          # NAS mount
  $(basename "$0") --dest ~/model-cache                # Local SSD
  $(basename "$0") --dest /mnt/htsai-model-backup --env prod --ollama
  $(basename "$0") --list
EOF
      exit 0 ;;
    *)
      if [[ "${shift_next:-}" == "dest" ]]; then
        DEST="$arg"
        shift_next=""
      elif [[ "${shift_next:-}" == "env" ]]; then
        ENV_FILTER="$arg"
        shift_next=""
      else
        warn "Unknown argument: $arg"
      fi ;;
  esac
done

# ── Preflight checks ───────────────────────────────────────────────────────
if ! command -v jq >/dev/null 2>&1; then
  fail "jq is required but not installed. Run: sudo apt-get install -y jq"
  exit 1
fi

if [[ ! -f "$REGISTRY" ]]; then
  fail "Registry not found: $REGISTRY"
  exit 1
fi

# ── Read registry ───────────────────────────────────────────────────────────
# Build filtered model lists from registry.json

build_ollama_list() {
  local filter=".ollama[]"
  if [[ -n "$ENV_FILTER" && "$ENV_FILTER" != "all" ]]; then
    filter=".ollama[] | select(.env[] == \"$ENV_FILTER\")"
  fi
  jq -r "$filter | .model" "$REGISTRY" | sort -u
}

build_sd_list() {
  local filter=".\"sd-checkpoints\"[]"
  if [[ -n "$ENV_FILTER" && "$ENV_FILTER" != "all" ]]; then
    filter=".\"sd-checkpoints\"[] | select(.env[] == \"$ENV_FILTER\")"
  fi
  jq -r "$filter | \"\(.filename)|\(.url)\"" "$REGISTRY" | sort -u
}

# ── List mode ───────────────────────────────────────────────────────────────
if $LIST_ONLY; then
  step "Ollama Models ($(jq '.ollama | length' "$REGISTRY") registered)"
  jq -r '.ollama[] | "  \(.model)\t\(.env | join(","))\t\(.notes // "")"' "$REGISTRY" | column -t -s $'\t'

  step "SD Checkpoints ($(jq '.["sd-checkpoints"] | length' "$REGISTRY") registered)"
  jq -r '.["sd-checkpoints"][] | "  \(.filename)\t\(.env | join(","))\t\(.notes // "")"' "$REGISTRY" | column -t -s $'\t'

  echo ""
  info "Registry: $REGISTRY"
  exit 0
fi

# ── Prompt for destination if not provided ──────────────────────────────────
if [[ -z "$DEST" ]]; then
  step "Select cache destination"
  echo ""
  echo "  Where should models be cached?"
  echo ""
  echo "  Examples:"
  echo "    /mnt/htsai-model-backup    NFS/SMB network share"
  echo "    ~/model-cache               Local SSD"
  echo "    /media/usb/models           USB drive"
  echo ""
  read -r -p "  Path [/mnt/htsai-model-backup]: " DEST
  DEST="${DEST:-/mnt/htsai-model-backup}"
  # Expand ~ to $HOME
  DEST="${DEST/#\~/$HOME}"
fi

# Expand ~ in case it was passed via --dest
DEST="${DEST/#\~/$HOME}"

step "Preflight checks"

# Check destination is writable (create if needed)
if [[ ! -d "$DEST" ]]; then
  info "Creating destination: $DEST"
  mkdir -p "$DEST" 2>/dev/null || {
    fail "Cannot create $DEST — check permissions or mount"
    exit 1
  }
fi

if [[ ! -w "$DEST" ]]; then
  fail "Destination not writable: $DEST"
  exit 1
fi
ok "Destination: $DEST"

# Ensure subdirectories
DEST_OLLAMA="${DEST}/ollama"
DEST_SD="${DEST}/sd-checkpoints"
mkdir -p "$DEST_OLLAMA" "$DEST_SD" 2>/dev/null || {
  fail "Cannot create subdirectories in $DEST"
  exit 1
}

if ! docker info >/dev/null 2>&1; then
  fail "Docker is not running"
  exit 1
fi
ok "Docker is running"

ok "Registry: $REGISTRY (format v$(jq -r '._format_version' "$REGISTRY"))"

# ── Load model lists from registry ──────────────────────────────────────────
mapfile -t OLLAMA_MODELS < <(build_ollama_list)
mapfile -t SD_ENTRIES < <(build_sd_list)

OLLAMA_TOTAL=${#OLLAMA_MODELS[@]}
SD_TOTAL=${#SD_ENTRIES[@]}

env_label="${ENV_FILTER:-all}"
info "Environment filter: $env_label"
info "Ollama models to seed: $OLLAMA_TOTAL"
info "SD checkpoints to seed: $SD_TOTAL"

# ── Counters ────────────────────────────────────────────────────────────────
ollama_pulled=0
ollama_skipped=0
ollama_failed=0
sd_downloaded=0
sd_skipped=0
sd_failed=0

# ─────────────────────────────────────────────────────────────────────────────
# SEED OLLAMA MODELS
# Strategy: Run a temporary Ollama container with the destination as storage.
# Models are pulled directly into the cache. Later, install scripts can copy
# from cache to Docker volumes instead of downloading from the internet.
# ─────────────────────────────────────────────────────────────────────────────
seed_ollama() {
  step "Seeding Ollama models ($OLLAMA_TOTAL models → $DEST_OLLAMA)"

  if [[ "$OLLAMA_TOTAL" -eq 0 ]]; then
    warn "No Ollama models match filter — skipping."
    return
  fi

  if $DRY_RUN; then
    for model in "${OLLAMA_MODELS[@]}"; do
      info "[DRY RUN] Would pull: $model"
    done
    return
  fi

  local container_name="ollama-cache-seeder"
  local seeder_port=11499

  # Clean up any leftover seeder container
  docker rm -f "$container_name" 2>/dev/null || true

  info "Starting temporary Ollama container with cache-backed storage..."
  docker run -d \
    --name "$container_name" \
    --gpus all \
    -v "${DEST_OLLAMA}:/root/.ollama" \
    -p "${seeder_port}:11434" \
    ollama/ollama:latest

  # Wait for Ollama to be ready
  info "Waiting for seeder to start..."
  local attempts=0
  until curl -s "http://localhost:${seeder_port}/api/tags" >/dev/null 2>&1; do
    sleep 2
    attempts=$((attempts + 1))
    if [[ "$attempts" -ge 30 ]]; then
      fail "Ollama seeder did not start after 60s"
      docker rm -f "$container_name" 2>/dev/null || true
      return 1
    fi
  done
  ok "Seeder ready on port $seeder_port"

  # Pull each model
  local i=0
  for model in "${OLLAMA_MODELS[@]}"; do
    i=$((i + 1))
    info "[$i/$OLLAMA_TOTAL] Pulling $model..."

    # Check if already cached (match on model base name)
    if curl -s "http://localhost:${seeder_port}/api/tags" | jq -e ".models[] | select(.name == \"$model\")" >/dev/null 2>&1; then
      skip "$model"
      ollama_skipped=$((ollama_skipped + 1))
      continue
    fi

    if docker exec "$container_name" ollama pull "$model"; then
      ok "$model cached"
      ollama_pulled=$((ollama_pulled + 1))
    else
      fail "$model — pull failed"
      ollama_failed=$((ollama_failed + 1))
    fi
  done

  # Cleanup
  info "Removing seeder container..."
  docker rm -f "$container_name" >/dev/null 2>&1
  ok "Seeder container removed."
}

# ─────────────────────────────────────────────────────────────────────────────
# SEED SD CHECKPOINTS
# Strategy: Download .safetensors files directly via curl.
# ─────────────────────────────────────────────────────────────────────────────
seed_sd() {
  step "Seeding SD checkpoints ($SD_TOTAL models → $DEST_SD)"

  if [[ "$SD_TOTAL" -eq 0 ]]; then
    warn "No SD checkpoints match filter — skipping."
    return
  fi

  local i=0
  for entry in "${SD_ENTRIES[@]}"; do
    i=$((i + 1))
    local filename="${entry%%|*}"
    local url="${entry##*|}"
    local dest_file="${DEST_SD}/${filename}"

    if $DRY_RUN; then
      info "[DRY RUN] Would download: $filename"
      info "          URL: $url"
      continue
    fi

    if [[ -f "$dest_file" ]]; then
      local size
      size=$(stat -c%s "$dest_file" 2>/dev/null || echo 0)
      if [[ "$size" -gt 1000000 ]]; then
        skip "[$i/$SD_TOTAL] $filename ($(numfmt --to=iec "$size"))"
        sd_skipped=$((sd_skipped + 1))
        continue
      else
        warn "$filename exists but is suspiciously small (${size} bytes) — re-downloading"
        rm -f "$dest_file"
      fi
    fi

    info "[$i/$SD_TOTAL] Downloading $filename..."
    if curl -fSL --retry 3 --retry-delay 5 --progress-bar -o "$dest_file" "$url"; then
      local final_size
      final_size=$(stat -c%s "$dest_file" 2>/dev/null || echo 0)
      ok "$filename saved ($(numfmt --to=iec "$final_size"))"
      sd_downloaded=$((sd_downloaded + 1))
    else
      fail "$filename — download failed (check URL)"
      rm -f "$dest_file"
      sd_failed=$((sd_failed + 1))
    fi
  done
}

# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────
SECONDS=0

if $DO_OLLAMA; then
  seed_ollama
fi

if $DO_SD; then
  seed_sd
fi

# ── Summary ─────────────────────────────────────────────────────────────────
duration=$SECONDS
step "Cache Seed Summary"
echo ""
printf "  %-24s %s\n" "Destination:" "$DEST"
printf "  %-24s %s\n" "Registry:" "$REGISTRY"
printf "  %-24s %s\n" "Environment:" "$env_label"
echo ""
if $DO_OLLAMA; then
  printf "  %-24s %s\n" "Ollama pulled:"   "$ollama_pulled"
  printf "  %-24s %s\n" "Ollama skipped:"  "$ollama_skipped (already cached)"
  printf "  %-24s %s\n" "Ollama failed:"   "$ollama_failed"
fi
if $DO_SD; then
  printf "  %-24s %s\n" "SD downloaded:"   "$sd_downloaded"
  printf "  %-24s %s\n" "SD skipped:"      "$sd_skipped (already cached)"
  printf "  %-24s %s\n" "SD failed:"       "$sd_failed"
fi
echo ""
printf "  %-24s %dm %ds\n" "Total time:" $((duration / 60)) $((duration % 60))
echo ""

# Disk usage
if ! $DRY_RUN && ($DO_OLLAMA || $DO_SD); then
  step "Cache Disk Usage"
  du -sh "$DEST_OLLAMA" 2>/dev/null || true
  du -sh "$DEST_SD" 2>/dev/null || true
  echo ""
  du -sh "$DEST" 2>/dev/null || true
fi

total_failed=$((ollama_failed + sd_failed))
if [[ "$total_failed" -gt 0 ]]; then
  warn "$total_failed model(s) failed — review output above."
  exit 1
fi

ok "Cache is fully seeded."
