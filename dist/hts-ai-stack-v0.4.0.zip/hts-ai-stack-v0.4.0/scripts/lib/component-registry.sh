#!/usr/bin/env bash
# scripts/lib/component-registry.sh — Component registry for convergence
# Source this file; do NOT run directly.
#
# Thin shim: delegates to manifest-loader.sh which reads all component
# metadata from scripts/components/*.manifest.json at runtime.
#
# All COMPONENT_* arrays and helper functions are defined by manifest-loader.sh.
# This file exists for backward compatibility — callers that source
# component-registry.sh continue to work unchanged.
#
# Used by: converge.sh (FEATURE-009)
# Requires: common.sh sourced first (for REPO_DIR)

# shellcheck source=scripts/lib/manifest-loader.sh
source "${REPO_DIR}/scripts/lib/manifest-loader.sh"

manifest_load_all
