# Inkscape — Component Context

## Purpose

Inkscape is a free and open-source vector graphics editor using SVG as
its native format. It provides tools for creating and editing scalable
illustrations, diagrams, logos, and complex multi-layer designs.

## Location

`scripts/components/inkscape/` — component directory

## Key Files

| File | Purpose |
|------|---------|
| `inkscape.manifest.json` | Convergence manifest |
| `inkscape.sh` | Install / configure / health script |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and notes |

## Notes

- Installed via **snap** for latest stable version
- Desktop application — no Docker service or web UI
- SVG native format with PDF, EPS, AI import/export
- Command-line batch processing for headless SVG conversion

See [usage.md](./usage.md) for command usage.
