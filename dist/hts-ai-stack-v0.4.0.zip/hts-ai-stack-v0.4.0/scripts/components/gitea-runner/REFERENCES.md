# Gitea Runner Component — REFERENCES

## Official

- Source: <https://gitea.com/gitea/act_runner>
- Gitea Actions docs: <https://docs.gitea.com/usage/actions/overview>
- `act_runner` deployment guide: <https://docs.gitea.com/usage/actions/act-runner>
- Registration flow: <https://docs.gitea.com/usage/actions/act-runner#register-the-runner>
- Config reference: <https://docs.gitea.com/usage/actions/act-runner#configuration>

## Upstream (nektos/act)

`act_runner` builds on `nektos/act` — the same GitHub-Actions-in-Docker
engine that powers local GH Actions testing:

- Source: <https://github.com/nektos/act>

## Related components in this stack

- Gitea server: <https://gitea.com/gitea/gitea>
- Docker CLI (required on host): <https://docs.docker.com/>

## Related features

- FEATURE-054 — Developer Tools Suite (OpenCode, Aider, Tabby, Gitea Runner)

## Vendor-instruction deviations

None. Install follows Gitea's documented `act_runner` deployment via
Docker Compose. No entry in `/DEVIATIONS.md` is required.
