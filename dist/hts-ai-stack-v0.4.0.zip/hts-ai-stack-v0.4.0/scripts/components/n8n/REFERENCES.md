# n8n References

Last updated: 2026-04-15

## Upstream

- [GitHub — n8n-io/n8n](https://github.com/n8n-io/n8n)

## Official documentation

- [n8n Docs](https://docs.n8n.io/)
