# HunyuanVideo — High-Quality Text-to-Video Generation

**Priority:** LOW
**Effort:** 4–6 hours
**Risk:** ~~High~~ → **DISQUALIFIED**
**Target Release:** ~~v0.6.0~~ → Deferred pending hardware upgrade
**Depends on:** CUDA runtime on host
**Blocks:** Nothing

> **⚠️ Hardware Disqualified — RTX 3060 (12GB VRAM)**
>
> The minimum supported path (HunyuanVideoGP community fork) requires **16GB VRAM**.
> The native paths require 45–60GB VRAM.
> The stack's target GPU (NVIDIA RTX 3060, 12GB) does not meet any supported configuration.
> This feature is deferred until the hardware baseline is upgraded to ≥16GB VRAM
> (e.g., RTX 3090 16GB, RTX 4090, or equivalent).
>
> Re-evaluate when hardware changes. See FEATURE-029 for the same constraint.

## Problem

Open-Sora (FEATURE-029) is the accessible text-to-video tier.
HunyuanVideo is the premium quality tier — matching 30B Step-Video and 11B HunyuanVideo
quality scores on VBench benchmarks. It enables higher-fidelity video generation
when hardware permits.

## Current State

Not in the stack. `Tencent-Hunyuan/HunyuanVideo` is not tracked in feature-repos.

## License Note

> **⚠️ Non-Commercial License**
>
> HunyuanVideo is released under the **Tencent Hunyuan Community License**,
> which is **not OSI-approved**. Key restrictions:
>
> - Non-commercial community use is permitted
> - Commercial use requires a separate agreement with Tencent
> - Review the full license before any production or revenue-generating deployment
>
> This service must **not** be used in commercial deployments without a Tencent license agreement.

## Architecture

Gradio web UI on port 7863.

Hardware paths:

| Path | VRAM | Quality |
|------|------|---------|
| Native 720p | 60GB+ (H100/A100) | Full quality |
| Native 544p | 45GB+ | Reduced resolution |
| FP8 + CPU offload | 24GB (RTX 3090/4090) | Reduced quality, slow |
| **HunyuanVideoGP fork** | 16–24GB (consumer RTX) | Community-optimised |

**Recommended consumer RTX path:** [HunyuanVideoGP](https://github.com/deepbeepmeep/HunyuanVideoGP)
by deepbeepmeep — memory-optimised community fork, not affiliated with Tencent.
Component script will detect available VRAM and select the appropriate path.

## Implementation Steps

### P0 — Consumer RTX path (primary)

- [ ] **1. Build Dockerfile (HunyuanVideoGP)**
  Create `docker/hunyuan-video/Dockerfile` targeting the memory-optimised fork:

  ```dockerfile
  FROM nvidia/cuda:12.3.2-cudnn9-devel-ubuntu22.04
  RUN apt-get update && apt-get install -y git python3-pip ffmpeg
  RUN pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
  RUN git clone https://github.com/deepbeepmeep/HunyuanVideoGP /app && \
      cd /app && pip install -e .
  WORKDIR /app
  EXPOSE 7863
  CMD ["python", "gradio_app.py", "--server-port", "7863", "--server-name", "0.0.0.0"]
  ```

- [ ] **2. Docker compose service**
  Add `hunyuan-video` service under `profiles: [hunyuan-video]`.

  ```yaml
  hunyuan-video:
    build:
      context: ./docker/hunyuan-video
    image: hts-ai-hunyuan-video
    container_name: hts-ai-hunyuan-video
    profiles: [hunyuan-video]
    restart: unless-stopped
    ports:
      - "${HUNYUAN_VIDEO_PORT:-7863}:7863"
    volumes:
      - hunyuan-video-models:/app/ckpts
    networks:
      - ai-network
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    healthcheck:
      test: ["CMD", "curl", "-sf", "http://localhost:7863"]
      interval: 60s
      timeout: 30s
      retries: 3
      start_period: 300s
  ```

  > **Note:** Open-Sora (port 7862) and HunyuanVideo (port 7863) should not run simultaneously
  > on consumer GPUs. Only activate one at a time based on VRAM budget.

- [ ] **3. Component script**
  Create `scripts/components/hunyuan-video/hunyuan-video.sh` implementing:
  - `hunyuan_video_install` — VRAM check; build image
  - `hunyuan_video_configure`:
    - `< 16GB` → abort with error; minimum 16GB for HunyuanVideoGP
    - `16–39GB` → use HunyuanVideoGP (community fork)
    - `≥ 40GB` → option to use native 544p path
    - `≥ 60GB` → option to use native 720p path
  - `hunyuan_video_start` — start service + health check (allow 5 min for model load)
  - `hunyuan_video_health` — `curl -sf http://localhost:${HUNYUAN_VIDEO_PORT}`
  - `hunyuan_video_stop` — stop service

- [ ] **4. Env vars**
  Add to `.env.example`:

  ```text
  HUNYUAN_VIDEO_PORT=7863
  ```

### P1 — Registration

- [ ] **5. Port map** — Add port 7863 to `REFERENCES.md` Host Port Map table.
- [ ] **6. Feature index** — Add row to `docs/development/features/REFERENCES.md`.

## Acceptance Criteria

- `docker compose --profile hunyuan-video build` succeeds
- `docker compose --profile hunyuan-video up` starts Gradio UI on port 7863
- `hunyuan_video_health` returns success
- VRAM check documented in component script
- License warning displayed on `hunyuan_video_install`

## Related

- [FEATURE-029](FEATURE-029.md) — Open-Sora (accessible video tier, use instead if VRAM < 24GB)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md) — row: `Tencent-Hunyuan/HunyuanVideo`
