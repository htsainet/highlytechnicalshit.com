# Grafana Component

Last updated: 2026-04-15

## What happens here

Grafana provides monitoring dashboards and alerting backed by Prometheus.
Used in the stack to visualize system metrics, container health, and
GPU utilization.

## Files and structure

| File | Purpose |
|------|---------|
| `grafana.sh` | Full lifecycle: install, configure, start, stop, health |
| `grafana.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

See [usage.md](./usage.md) for command usage.
