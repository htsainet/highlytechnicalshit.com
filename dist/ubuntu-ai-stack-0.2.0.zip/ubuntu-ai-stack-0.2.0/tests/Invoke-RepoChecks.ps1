param(
    [switch]$Staged,
    [switch]$All
)

$ErrorActionPreference = 'Stop'

if (-not (Get-Module -ListAvailable -Name Pester)) {
    throw 'Pester is not installed. Run: pwsh -NoLogo -NoProfile -Command "Install-Module -Name Pester -Scope CurrentUser -Force -SkipPublisherCheck"'
}

Import-Module Pester -ErrorAction Stop

$repoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
Set-Location $repoRoot

if ($All) {
    $files = @(git ls-files)
}
elseif ($Staged) {
    $files = @(git diff --cached --name-only --diff-filter=ACMR)
}
else {
    $files = @(
        @(git diff --name-only --diff-filter=ACMR)
        @(git diff --cached --name-only --diff-filter=ACMR)
    ) | Select-Object -Unique
}

$files = @($files | Where-Object {
    $_ -and (Test-Path -LiteralPath (Join-Path $repoRoot $_))
})

$markdownFiles = @($files | Where-Object { $_ -match '\.md$' })
$shellFiles = @($files | Where-Object { $_ -match '\.sh$' })
$configFiles = @($files | Where-Object { $_ -match '\.(json|jsonc|ya?ml)$' })

if ($markdownFiles.Count -eq 0 -and $shellFiles.Count -eq 0 -and $configFiles.Count -eq 0) {
    Write-Host 'No markdown, shell, or config files selected for checks.'
    exit 0
}

$env:REPO_MARKDOWN_FILES_JSON = ConvertTo-Json $markdownFiles -Compress
$env:REPO_SHELL_FILES_JSON = ConvertTo-Json $shellFiles -Compress
$env:REPO_CONFIG_FILES_JSON = ConvertTo-Json $configFiles -Compress

$configuration = [PesterConfiguration]::Default
$configuration.Run.Path = (Join-Path $PSScriptRoot 'RepoChecks.Tests.ps1')
$configuration.Run.PassThru = $true
$configuration.Output.Verbosity = 'Detailed'

$result = Invoke-Pester -Configuration $configuration

if ($result.FailedCount -gt 0) {
    exit 1
}