# Docker Network Segmentation

**Priority:** MEDIUM
**Effort:** 4-6 hours
**Risk:** Medium — changing network topology can break inter-container service discovery.
Requires careful testing of all inter-service calls (e.g., Open WebUI → Ollama,
llama-swap → Ollama, DeerFlow → llama-swap).
**Target Release:** v0.6.0
**Threat:** Container lateral movement — a compromised container on the flat `ai-network` bridge
can reach every other container directly (Ollama, Portainer socket, Gitea, Grafana, etc.)
with no network controls.
**Depends on:** SECURITY-000 (host-level hardening first)
**Blocks:** Nothing

## Problem

All services share a single Docker bridge network `ai-network`. Any container that is
compromised (via prompt injection, supply chain attack, or RCE) can make direct TCP
connections to every other service — including Portainer (Docker socket access),
Grafana, Gitea, and the LLM inference APIs.

There is no inter-container firewall, no subnet isolation, and no traffic filtering.

## Solution

Split `ai-network` into purpose-scoped networks. Containers only connect to the networks
they need for legitimate communication.

## Proposed Network Layout

| Network | Subnet | Members |
|---------|--------|---------|
| `frontend` | 172.20.0.0/24 | open-webui, dashboard, grafana, sillytavern, comfyui |
| `inference` | 172.20.1.0/24 | ollama, llama-swap, bitnet, unsloth, deerflow-backend |
| `ops` | 172.20.2.0/24 | prometheus, cadvisor, portainer, gitea |
| `agent` | 172.20.3.0/24 | openspace, deerflow-web, nemoclaw sidecar |

Services that span networks (e.g., Open WebUI calls Ollama) connect to both networks:

- `open-webui`: `frontend` + `inference`
- `grafana`: `frontend` + `ops`
- `deerflow-web`: `frontend` + `agent`
- `deerflow-backend`: `inference` + `agent`

Portainer and Prometheus connect only to `ops` — no path to inference or frontend containers.

## Implementation Steps

### 1. Define networks in `docker-compose.yml`

```yaml
networks:
  frontend:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/24
  inference:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.1.0/24
  ops:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.2.0/24
  agent:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.3.0/24
```

### 2. Update each service's `networks:` declaration

Replace `- ai-network` with the appropriate network list per service.

### 3. Validate inter-service connectivity

For each service-to-service call, confirm reachability works across assigned networks:

```bash
docker exec hts-ai-open-webui curl -sf http://hts-ai-ollama-gpu:11434/api/tags
docker exec hts-ai-grafana curl -sf http://hts-ai-prometheus:9090/-/healthy
```

### 4. Verify isolation

Confirm Portainer cannot reach Ollama (different networks, no shared network):

```bash
docker exec hts-ai-portainer curl --max-time 3 http://hts-ai-ollama-gpu:11434/api/tags
# Should timeout or refuse — not return a response
```

## Acceptance Criteria

- All stack services start and function normally
- All known inter-service calls succeed
- Portainer cannot directly reach Ollama or Open WebUI
- Prometheus cannot reach Gitea or open-webui
- `docker network inspect` shows correct membership per network
