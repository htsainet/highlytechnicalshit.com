# FEATURE-060 — YubiKey Integration (Auth + Disk + Signing)

| Field | Value |
|-------|-------|
| Status | Proposed |
| Category | Security / Hardware Authentication |
| Target Release | v0.5.0 (Phase 1–2), v0.6.0+ (Phase 3–5) |
| Priority | HIGH |
| Effort | M (phased; each phase standalone) |
| Components | Docs + host-level helper scripts; no new containers |
| Dependencies | FEATURE-055 (Authelia WebAuthn), FEATURE-059 (Vaultwarden 2FA) |
| Related | SECURITY-009 (secret isolation), Duplicati backup component |

## Summary

Integrate YubiKey hardware tokens across the stack as the universal
second factor for the credential plane, as a FIDO2 key for disk
encryption, and as hardware-held SSH/GPG/signing keys. One piece of
hardware covers the most sensitive operations on the box.

Target hardware: **YubiKey 5 series (NFC + USB-A or USB-C)**. Users
should buy **at least two** (primary + backup in a drawer/safe).

## Why hardware 2FA matters

Software TOTP is good. Hardware FIDO2 is better because:

- **Phishing-resistant.** FIDO2 binds to the origin; a fake auth page
  can't proxy the challenge.
- **Private key never leaves the device.** No secret exists on the host
  or in the cloud that could leak.
- **Touch-to-approve.** Unattended malware can't silently authenticate.
- **Immune to TOTP seed theft.** Authenticator-app backups, if
  compromised, expose every secret. YubiKey has nothing to steal.

The stack already plans 2FA via Authelia TOTP. YubiKey upgrades TOTP to
WebAuthn for the crown-jewel credentials (Authelia master, Vaultwarden
master) while keeping TOTP available for legacy/mobile-only flows.

## Phased rollout

Each phase is independently useful — buy the keys, do Phase 1, stop
any time.

### Phase 1 — Authelia WebAuthn enrollment (v0.5.0)
- Authelia supports WebAuthn natively (built-in)
- Enable `webauthn` auth method in Authelia config
- `authelia.sh --enroll-webauthn <user>` helper script wraps the flow
  (prints enrollment URL, user completes in browser, touches YubiKey)
- `authelia.sh --list-devices <user>` and `--remove-device <id>` for management
- Enrollment of both primary and backup YubiKey required at first setup

### Phase 2 — Vaultwarden 2FA (v0.5.0)
- Vaultwarden supports WebAuthn 2FA out of the box
- Docs for enrolling both YubiKeys via browser
- Note: mobile Bitwarden apps support NFC tap for YubiKey; USB works on desktop
- Covered by FEATURE-059 docs; this feature adds the YubiKey-specific enrollment guide

### Phase 3 — LUKS disk encryption (v0.6.0)
Unlock encrypted data volumes at boot with a YubiKey touch.

- `scripts/host/setup-luks-yubikey.sh` — helper script:
  1. Asks which block device to encrypt (ideally a dedicated data disk, not root)
  2. Creates LUKS2 volume with a recovery passphrase + enrolls YubiKey via
     `systemd-cryptenroll --fido2-device=auto`
  3. Adds entry to `/etc/crypttab` for auto-unlock at boot
  4. Prompts to enroll backup YubiKey
  5. Backs up LUKS header to `/root/luks-header-backup.img` (and reminds user to copy off-box)
- Docs: `docs/security/luks-yubikey.md` — recovery procedures, what to do
  if a YubiKey is lost, how to re-enroll after OS reinstall
- Limitations documented: headless boot requires dropbear-initramfs (out of scope for v1)

### Phase 4 — SSH + Git commit signing (v0.6.0)
- FIDO2 resident SSH keys: `ssh-keygen -t ed25519-sk -O resident`
- Key is bound to YubiKey; `ssh-add -K` retrieves a handle, touch required on every auth
- Helper: `scripts/host/setup-yubikey-ssh.sh` — generates key, installs
  to `~/.ssh/`, configures git signing format
- Git commit signing with SSH keys: `git config gpg.format ssh` + YubiKey-backed key
- Update `bootstrap.sh` optional step: prompt for YubiKey SSH setup
- Docs: `docs/security/yubikey-ssh-and-git.md`

### Phase 5 — Backup encryption with `age` (v0.6.0+)
- `age-plugin-yubikey` lets YubiKey hold an age identity
- Encrypt backup archives / sensitive files to the YubiKey's public key
- Only the YubiKey can decrypt → stronger than passphrase-based
- Complements Duplicati (which uses its own encryption) for one-off
  sensitive archives: LUKS header backup, Authelia secrets export,
  master emergency bundle
- Helper: `scripts/backups/age-yubikey-encrypt.sh`, companion `decrypt.sh`

## Hardware recommendation

| Model | Why |
|---|---|
| **YubiKey 5 NFC (USB-A)** | Desktop + tap-to-auth on Android |
| **YubiKey 5C NFC** | USB-C + NFC (modern laptops + phones) |
| **YubiKey 5Ci** | USB-C + Lightning (iPhone users) |
| **YubiKey 5 Nano** | Leave-in desktop slot, less travel-friendly |

Buy two of whatever fits your ports. Total spend: ~$100.

**DO NOT rely on a single YubiKey.** Enroll the backup into every
system you set up at the same time as the primary. If you lose one,
you pull the backup out of the drawer and re-enroll a new replacement
before losing both.

## What YubiKey does NOT protect

- Running, unlocked system (the other defense layers matter here)
- Attacker with physical access + your touch (threat model: targeted attack by someone near you)
- Compromised firmware on the host itself (TPM + Secure Boot are different layers)
- Backups stored unencrypted off-device (hence Phase 5)

## Risks & mitigations

| Risk | Mitigation |
|---|---|
| Lost both YubiKeys | Recovery passphrase on LUKS, emergency export from Vaultwarden, Authelia reset runbook |
| YubiKey firmware CVE | Yubico publishes advisories; firmware is immutable post-sale — replacement is the remediation |
| Touch-fatigue → reflex-approval phishing | Keep touch required only for high-value ops; avoid "press to unlock every 5 min" |
| Backup YubiKey not kept current | Document quarterly "enrollment sync" check |
| Travel scenario (left YubiKey at home) | Keep a third key at a trusted secondary location, OR accept TOTP-only fallback during travel |

## Acceptance criteria (per phase)

**Phase 1:**
- [ ] User can enroll YubiKey as WebAuthn device in Authelia
- [ ] Login flow prompts for YubiKey touch on subsequent sessions
- [ ] Backup YubiKey also enrolled and tested

**Phase 2:**
- [ ] Vaultwarden 2FA via YubiKey works on desktop + mobile + browser extension

**Phase 3:**
- [ ] LUKS data volume unlocks with YubiKey touch at boot
- [ ] Recovery passphrase tested in a safe scenario
- [ ] LUKS header backup stored off-box

**Phase 4:**
- [ ] SSH into a test server requires YubiKey touch
- [ ] Git commits show "signed" status with YubiKey-backed key

**Phase 5:**
- [ ] `age`-encrypted file decryptable only with YubiKey
- [ ] Documented use in backup workflows

## Out of scope

- Enterprise attestation / OATH-HOTP / smart-card PIV (overkill for homelab)
- Centralized YubiKey provisioning (single-user stack)
- TPM-based unlock (different approach, could be a separate feature)
- Secure Boot chain of trust (platform-level, separate concern)
