# References

Last updated: 2026-04-19 23:05:00

## Core Services

- **OpenClaw**: https://openclaw.ai/
- **NemoClaw**: https://www.nvidia.com/en-us/ai/nemoclaw/
- **OpenShell**: https://docs.nvidia.com/openshell/latest/index.html
- **Ollama**: https://ollama.com/
- **llama-swap**: https://github.com/mostlygeek/llama-swap — Model multiplexer for GPU/CPU split inference
- **Open WebUI**: https://github.com/open-webui/open-webui — Chat frontend

## Folder Architecture

```text
hts-ai-stack/
│
├── bootstrap.sh                 # Entry point — curl | bash target; installs prereqs,
│                                #   clones repo, installs NVIDIA drivers (requires reboot)
├── install.sh                   # Wizard-style installer; runs after reboot from repo root
│                                #   Flow: wizard → apply_config → host prereqs → converge.sh
├── docker-compose.yml           # Convenience root-level compose (delegates to docker/)
├── docker-images.md             # Pinned base image reference (all tags + sha256 digests)
│
├── CLIEF-NOTES-FRAMEWORK.md    # Clief Notes documentation framework spec
├── CLAUDE.md                    # AI assistant identity, rules, and routing
├── CONTEXT.md                   # Project overview and goals
├── REFERENCES.md                # Architecture, services, and key links (this file)
├── README.md                    # Public-facing project documentation
│
├── backups/                     # Backup automation scripts
│   ├── pre-nuke-checklist.sh   #   Orchestrates all backup layers before nuke-and-pave
│   ├── disk-image/             #   Full disk image (dd + gzip → NAS)
│   │   └── backup-disk.sh      #     dd pipe gzip to /mnt/htsai-disk-image/
│   ├── docker/                 #   Docker volume backup scripts
│   │   └── backup-volumes.sh   #     Pause/tar/archive 26 stateful volumes to NAS
│   ├── synology/               #   Synology NAS mount + ActiveProtect agent setup
│   │   └── setup-nas-mount.sh  #     TPM2-encrypted CIFS mount (credentials never on disk)
│   └── timeshift/              #   Timeshift snapshot configuration
│       └── setup-timeshift.sh  #     Install + configure Timeshift with stack exclusions
│
├── config/                      # Runtime and wizard-generated configuration
│   ├── stack.json               #   Primary stack configuration
│   ├── tailscale-acl-policy.jsonc #  Tailscale ACL policy definition
│   ├── backups/                 #   Auto-generated timestamped config snapshots
│   │                            #     (one folder per install.sh run: YYYYMMDD-HHMMSS/)
│   └── wizard/                  #   Interactive wizard scripts for config generation
│
├── docker/                      # Docker build contexts
│   ├── bitnet/                  #   BitNet multi-stage build (Dockerfile + entrypoint)
│   └── openspace/               #   OpenSpace build (Dockerfile + config)
│
├── docs/                        # All documentation
│   ├── CONTEXT.md               #   Documentation hub — routes to sub-folders
│   ├── development/             #   Active development tracking
│   │   ├── testing-log.md       #     Manual test run log
│   │   ├── features/            #     Feature tracker — one FEATURE-###.md per feature
│   │   │   └── CONTEXT.md       #     Feature tracker conventions
│   │   └── issues/              #     In-flight issue notes
│   ├── guides/                  #   How-to guides (Tailscale, Signal, Telegram,
│   │   │                        #     Docker Model Engine, NFS, disaster recovery, etc.)
│   │   ├── disaster-recovery.md #     Nuke-and-pave backup/restore runbook
│   │   └── synology-nfs-shares.md #   Synology DSM NFS share setup (4 shares)
│   ├── pipeline/                #   Step-by-step guides mirroring install script sequence
│   │                            #     (00-bootstrap → 07-setup-connectivity)
│   ├── planning/                #   Strategic planning and research
│   │   ├── CONTEXT.md           #     Planning hub — routes to sub-folders
│   │   ├── TODO.md              #     Backlog and priorities
│   │   ├── agent-skills/        #     Cross-platform skill vetting (OpenClaw, DeerFlow, Claude Code)
│   │   │   ├── CONTEXT.md       #       Scope, rubric, assessment criteria
│   │   │   ├── REFERENCES.md    #       Tracking table (research, writing, prompt-eng, etc.)
│   │   │   └── results/         #       Per-skill review artifacts (owner-skillname.md)
│   │   ├── feature-repos/       #     Non-security repo tracking & review artifacts
│   │   ├── openclaw-skills/     #     OpenClaw skill vetting (sandbox safety, policies, install verdict)
│   │   │   ├── CONTEXT.md       #       Review workflow for feature repos
│   │   │   └── REFERENCES.md    #       Tracking table (agents, memory, platforms, etc.)
│   │   ├── repo-review/         #     Ecosystem repo review session state
│   │   │   ├── CONTEXT.md       #       Session handoff / review workflow
│   │   │   └── REFERENCES.md    #       Master curated repo list (all categories)
│   │   ├── security-repos/      #     Security repo tracking & review artifacts
│   │   │   ├── CONTEXT.md       #       Review workflow for security repos
│   │   │   ├── REFERENCES.md    #       ~45 security repos tracking table
│   │   │   └── results/         #       Per-repo review artifacts (owner-reponame.md)
│   │   └── security-whitepapers/ #    arXiv paper tracking & review artifacts
│   │       ├── CONTEXT.md       #       Paper review workflow
│   │       └── REFERENCES.md    #       12 papers tracking table
│   ├── security-review/         #   Security architecture review session state
│   │   ├── CONTEXT.md           #     Threat model, findings, completed deliverables
│   │   └── REFERENCES.md        #     Complete threat model and findings
│
├── instances/                   # Per-environment runtime configs
│   ├── prod/                    #   Production compose + model list
│   └── test/                    #   Test compose + model list
│
├── logs/                        # Runtime logs (gitignored)
│
├── resources/                   # Static assets served by the stack
│   ├── CONTEXT.md               #   Resource conventions (Open WebUI functions, etc.)
│   ├── dashboard/               #   Nginx dashboard landing page (index.html)
│   │                            #     Also serves token sidecars: nemoclaw-tokens.json,
│   │                            #     openwebui-token.json (gitignored, runtime-generated)
│   ├── nginx/                   #   Nginx configuration (robots.txt, robots.conf)
│   ├── open-webui/              #   Open WebUI container assets
│   │   └── login.html           #     Same-origin login bridge — sets localStorage JWT
│   └── open-webui-functions/    #   Open WebUI Pipe functions (snake_case.py)
│
├── scripts/                     # Installation and utility scripts
│   ├── CONTEXT.md               #   Script goals and conventions
│   ├── bootstrap.sh             #   Repo-local copy of the bootstrap entry point
│   ├── build.sh                 #   Build script
│   ├── install.sh               #   Main installer (wizard-style)
│   ├── bundles/                 #   Feature-specific service groups (chat, voice, etc.)
│   │                            #     full-stack.sh is deprecated — converge.sh is primary
│   ├── components/              #   Per-service lifecycle scripts (install/start/stop/remove)
│   ├── host/                    #   OS-level provisioning (docker, nvidia, tools, node, nas)
│   │   ├── backup-models.sh     #     Rsync Docker model volumes → NAS (safe, no --delete)
│   │   ├── migrate-nas-folders.sh #   One-off: reorganize flat NAS layout into nested structure
│   │   ├── nas.sh               #     NFS plumbing — idmapd, fstab, mount, validate
│   │   ├── nas-setup.sh         #     Interactive NAS config (Docker mirror + NFS shares)
│   │   └── prerequisites.json   #     Stack-wide apt prerequisite tracker
│   ├── install/                 #   Numbered install step scripts (legacy pipeline wrappers)
│   │   ├── 01-autoinstall.sh    #     System auto-install / pre-config
│   │   ├── 02-setup-docker.sh   #     Docker + NVIDIA Container Toolkit setup
│   │   ├── 03-setup-models.sh   #     Ollama model download and configuration
│   │   ├── 04-setup-nemoclaw.sh #     NemoClaw sandbox setup
│   │   ├── 06-stop-test-instances.sh # Stop test instances
│   │   ├── 07-setup-connectivity.sh  # Tailscale / networking finish
│   │   ├── comms/               #     Communication service setup (Signal, Telegram)
│   │   ├── models/              #     Model-specific download/config helpers
│   │   ├── networking/          #     Networking helpers
│   │   ├── system/              #     OS-level setup helpers
│   │   └── tooling/             #     Dev/ops tooling installation
│   ├── issuefixers/             #   One-off scripts to remediate known issues
│   ├── lib/                     #   Shared function libraries (sourced, not executed)
│   │                            #     Includes convergence engine libs: manifest-loader,
│   │                            #     state-desired, state-actual, converge-diff
│   ├── utils/                   #   Operator utilities (converge.sh, reconfigure.sh,
│   │                            #     teardown.sh, verify.sh, audit-models.sh, etc.)
│   └── wizard/                  #   Wizard domain scripts — sourced by ai_stack_setup.sh
│       │                        #     and independently callable for day-2 operations
│       ├── inference-profile.sh #     Inference stack profile selection + LM Studio handling
│       │                        #       Profiles: ollama | dual ★ | dual-lms | localai | custom
│       │                        #       Outputs:  INFERENCE_PROFILE, BACKEND, LMSTUDIO_*
│       │                        #       VRAM gate: localai hidden if GPU_VRAM_TOTAL < 16384 MiB
│       │                        #       STATUS: STUB (inline logic still in ai_stack_setup.sh)
│       └── model-select.sh      #     VRAM-aware model selection + NAS-cached pull
│                                #       Inputs:   BACKEND, GPU_VRAM_TOTAL
│                                #       Outputs:  MODEL, PULL_ALL_MODELS, INFERENCE_BITNET_MODEL
│                                #       Defaults: smollm2:135m (starter); qwen2.5:7b-instruct-q4_K_M via llama-swap
│                                #       STATUS: STUB (inline logic still in ai_stack_setup.sh)
│
├── refactor/                    # Pipeline restructure plan and task tracking
│   ├── CONTEXT.md               #   Refactor scope and decisions
│   └── tasks/                   #   Individual refactor task files
│
└── tests/                       # Pester test suite (PowerShell 7.6 / Pester 5.7.1)
    ├── CONTEXT.md               #   Test conventions and goals
    ├── Install-GitHooks.ps1     #   Git hook installer
    ├── Invoke-RepoChecks.ps1    #   Repo health check runner
    ├── Test-FrameworkStructure.Tests.ps1
    ├── Test-HostPrerequisites.Tests.ps1
    ├── Test-IssueReviewDeadlines.Tests.ps1
    ├── Test-ModelCache.Tests.ps1
    ├── Test-ModelHelpers.Tests.ps1
    ├── Test-NamingConventions.Tests.ps1
    ├── Test-NoEditorSwap.Tests.ps1
    ├── Test-NpmAuditSecurity.Tests.ps1
    ├── Test-RepoChecks.Tests.ps1
    ├── Test-StackValidation.Tests.ps1
    ├── Test-StaleReferences.Tests.ps1
    ├── Test-WizardMenu.Tests.ps1
    ├── Test-WorkspaceValidation.Tests.ps1
    └── validate-config-files.cjs #  Node.js config file validator
```

## Deployment Variants

### Inference Architecture

The inference layer is configured via **inference profiles** selected during install or day-2 reconfiguration. All profiles expose an OpenAI-compatible API via llama-swap (except ollama-only and localai).

```text
Inference profiles (ordered by complexity):

  1. ollama      → Ollama only               — broad model support, GPU
  2. dual ★      → Ollama + BitNet            — GPU + CPU via llama-swap router
  3. dual-lms    → Dual + LM Studio peer      — adds LM Studio as staging sandbox
  4. localai     → LocalAI only               — unified API (requires ≥16GB VRAM)
  5. custom      → user-selected components

★ default. RTX 3060 (12GB) uses dual — BitNet handles CPU 1-bit, Ollama handles GPU.
LocalAI is hidden by the wizard on GPUs with < 16384 MiB total VRAM.
```

**Why not LocalAI on a single 12GB GPU?**
llama-swap's on-demand model swapping is the critical feature for VRAM-constrained systems — it loads one model at a time on request, then unloads it for the next. LocalAI keeps all configured models resident in VRAM simultaneously and has no equivalent capability. On 24GB+ hardware, LocalAI becomes a viable single-service alternative.

**Converge startup order (tier-gated):**

```text
Tier 1 — INFRA     (order 10–19):  dashboard → prometheus → grafana
         ── tier gate: validate infra healthy ──
Tier 2 — INFERENCE (order 20–49):  ollama → bitnet → llama-swap
         ── tier gate: validate inference healthy before UI ──
Tier 3 — CORE UI   (order 50–99):  open-webui → pipelines → audio → sandboxes
Tier 4 — AGENTS+   (order 100+):   portainer → n8n → flowise → agents
```

Tier gates run health checks after each tier. Failures warn but do not abort.

**Key files:**

| File | Purpose |
|---|---|
| `scripts/wizard/inference-profile.sh` | Profile selection + LM Studio handling (STUB) |
| `scripts/wizard/model-select.sh` | VRAM-aware model selection + NAS pull (STUB) |
| `config/wizard/ai_stack_setup.sh` | Main wizard orchestrator (inline logic until stubs are wired) |
| `scripts/components/ollama/ollama.manifest.json` | order: 20 |
| `scripts/components/bitnet/bitnet.manifest.json` | order: 23, always after ollama |
| `scripts/components/llama-swap/llama-swap.manifest.json` | order: 40, router — after all backends |
| `scripts/components/localai/localai.manifest.json` | order: 165, vram_minimum: 16384 |
| `scripts/lib/manifest-loader.sh` | Loads manifests → `COMPONENT_NUMERIC_ORDER`, `COMPONENT_VRAM_MINIMUM` |
| `scripts/utils/converge.sh` | `_execute_tier_gate()` — health-check gate between tiers |

### BitNet — Llama3-8B-1.58 inference backend

**Build context:** `docker/bitnet/` (Dockerfile + entrypoint.sh)

Drop-in Ollama replacement using Microsoft BitNet. Exposes an OpenAI-compatible API on port 8080.

- **Repo:** <https://github.com/microsoft/BitNet>
- **Wiring guide:** `docs/guides/nemoclaw-bitnet-wiring.sh`

## NemoClaw — Option A Architecture

NemoClaw reference material now lives alongside the component:

- [`scripts/components/nemoclaw/REFERENCES.md`](scripts/components/nemoclaw/REFERENCES.md)
  — architecture diagram, OpenShell install path, working configuration
  table, smoke-test plan, rollback procedure, official CLI command tables.
- [`scripts/components/nemoclaw/CONTEXT.md`](scripts/components/nemoclaw/CONTEXT.md)
  — operational runbook (boot-time forward, inference routing, dashboard
  auth recovery, working configuration, lessons learned).
- [`scripts/components/nemoclaw/DEVIATIONS.md`](scripts/components/nemoclaw/DEVIATIONS.md)
  — every deviation from the NVIDIA quickstart we currently carry.

Pins (manifest is canonical): NemoClaw `v0.0.31`, OpenShell `0.0.36`
(`scripts/components/nemoclaw/nemoclaw.manifest.json upstream.pinned_version`
and `upstream.openshell_pinned_version`).

## Music Production

Host-native audio tools and AI-powered music generation.

- **Ubuntu Studio Audio**: <https://ubuntustudio.org/> — JACK2, low-latency kernel, audio plugins
- **KXStudio**: <https://kx.studio/> — Cadence, Catia, Carla plugin host
- **Ardour**: <https://ardour.org/> — Professional DAW
- **AudioCraft / MusicGen**: <https://github.com/facebookresearch/audiocraft> — AI text-to-music (GPU, Gradio UI on port 8602)

## Video Production

Host-native video tools and AI-powered video generation.

- **Kdenlive**: <https://kdenlive.org/> — Non-linear video editor
- **OBS Studio**: <https://obsproject.com/> — Streaming and screen recording
- **HandBrake**: <https://handbrake.fr/> — Video transcoding
- **CogVideoX**: <https://github.com/THUDM/CogVideo> — AI text-to-video, 2B model fits 6GB VRAM (GPU, Gradio UI on port 7865)
- **Open-Sora**: <https://github.com/hpcaitech/Open-Sora> — AI text-to-video, requires ≥24GB VRAM (GPU, Gradio UI on port 7862)

## Animation

Host-native animation tools and AI-powered animation generation.

- **Blender**: <https://www.blender.org/> — 3D modeling, animation & rendering with CUDA GPU support
- **Synfig Studio**: <https://www.synfig.org/> — 2D vector animation with tweening and bones
- **OpenToonz**: <https://opentoonz.github.io/e/> — Professional 2D animation (used by Studio Ghibli)
- **AnimateDiff**: <https://github.com/guoyww/AnimateDiff> — AI text-to-animation via SD1.5 motion modules (GPU, Gradio UI on port 8603)

## Digital Art & Design

Host-native creative applications for illustration, photo editing, and vector graphics.

- **GIMP**: <https://www.gimp.org/> — Photo editing and image compositing
- **Krita**: <https://krita.org/> — Digital painting and illustration with animation support
- **Inkscape**: <https://inkscape.org/> — Professional vector graphics editor (SVG native)
- **Darktable**: <https://www.darktable.org/> — Photography workflow and RAW development

## Creative Writing

AI-assisted and distraction-free writing tools.

- **KoboldCpp**: <https://github.com/LostRuins/koboldcpp> — Interactive fiction & text generation with GGUF models (GPU, web UI on port 5001)
  - Source repo: <https://github.com/LostRuins/koboldcpp>
  - Install docs (Linux make): <https://github.com/LostRuins/koboldcpp#compiling-on-linux-using-make-recommended>
  - Pinned version: `v1.112.2` (commit `b31877e8ec8a1a58e7da88e0b235b9ca0028f504`)
  - Build flags at `v1.112.2`: `LLAMA_CUBLAS=1` (cuBLAS CUDA backend), `LLAMA_PORTABLE=1` (portable arch)
    — note: `LLAMA_CUBLAS` is the correct flag at this tag; the planned `GGML_CUDA` rename had not landed
- **Ghostwriter**: <https://ghostwriter.kde.org/> — Distraction-free Markdown editor (host app, KDE)
- **SillyTavern**: <https://github.com/SillyTavern/SillyTavern> — Character-based AI chat & roleplay (Docker, web UI on port 8001)

### Evaluated & not added

| Tool | Reason |
|------|--------|
| NovelCrafter | Commercial / closed-source — cannot self-host |
| KIT Scenarist | Discontinued → replaced by Story Architect (Starc) |
| Story Architect (Starc) | Desktop app with native Ollama support — candidate for future host-interactive component |
| bibisco | Desktop app, no AI integration |
| Manuskript | Desktop app, no AI integration |

## Voice & Avatar

AI-powered voice interaction and avatar chat.

- **Open-LLM-VTuber**: <https://github.com/t41372/Open-LLM-VTuber> — Live2D avatar chat with local LLM, STT, and TTS (GPU, web UI on port 12393)
- **Coqui TTS**: <https://github.com/coqui-ai/TTS> — Neural text-to-speech (Docker, REST API on port 5002)
- **Bark**: <https://github.com/suno-ai/bark> — Transformer text-to-audio: speech, music, sound effects (MIT, GPU, port 8400)
- **Faster-Whisper**: <https://github.com/SYSTRAN/faster-whisper> — Fast speech-to-text via CTranslate2 (Docker, API on port 8600)

## Developer Tools

AI-powered coding assistants and CI/CD infrastructure.

- **Tabby**: <https://github.com/TabbyML/tabby> — Self-hosted AI code completion, VS Code / JetBrains / vim (GPU, web UI on port 8085)
- **OpenCode**: <https://opencode.ai/> — Terminal AI coding agent with local LLM support (host tool, Ollama-backed)
- **Aider**: <https://aider.chat/> — AI pair programming in your terminal (host tool, Ollama-backed)
- **Gitea Runner**: <https://docs.gitea.com/usage/actions/act-runner> — CI/CD runner for Gitea Actions workflows (Docker, connects to Gitea internally)
- **Gitea**: <https://gitea.com/> — Self-hosted Git service (Docker, web UI on port 3030)

## Host Runtime Install Methods

Decisions about how host-level runtimes (Node, PowerShell, etc.) are
installed by `bootstrap.sh`. These are deliberate — changing any of
them needs an entry in `DEVIATIONS.md`.

### Node.js — NodeSource apt repo (not nvm)

`bootstrap.sh` step 7 installs Node.js 20 LTS from the NodeSource
Debian package repository (`https://deb.nodesource.com/setup_20.x`)
to `/usr/bin/node`. **nvm is deliberately not used.**

Rationale:

- Node is tooling for non-interactive gates: the `pre-commit`
  framework, Pester repo-checks (`markdownlint-cli2`, `cspell`,
  `jsonc-parser`), and CI. None of those source `~/.bashrc`, so
  nvm's shim-based PATH injection silently breaks them.
- One pinned version (Node 20 LTS, required by `markdownlint-cli2`
  0.22.0) — we don't need nvm's multi-version switching.
- System-wide install lets systemd units, root cron jobs, and any
  service account run Node without shell-init gymnastics.
- This is a dedicated AI-stack server, not a multi-project dev
  laptop.

When nvm would be the correct choice (not applicable here):

- Multi-project dev machines juggling Node 14 / 16 / 18 / 20.
- Workflows where the Node version is chosen per-branch or per-repo.

If this decision ever needs to flip (e.g. a dependency requires a
Node version newer than NodeSource ships promptly), log the change
in `DEVIATIONS.md` per the repo rules.

## Docker Image Pinning + NAS Mirroring

All 31 Dockerfiles accept an `ARG MIRROR=` build arg prepended to each `FROM` line. The `MIRROR` variable is passed from `docker-compose.yml` via `build.args` and sourced from `.env` (gitignored).

| State | `.env` setting | Effect |
|---|---|---|
| Default (upstream) | `MIRROR=` | `FROM ollama/ollama:0.20.2` |
| Local NAS mirror | `MIRROR=<nas>:5000/` | `FROM <nas>:5000/ollama/ollama:0.20.2` |

### Setup flow

1. **On NAS:** Run `scripts/release/pull-all-images.sh` via SSH to cache all base images
2. **On NAS:** Start a Docker registry container (`registry:2`) on port 5000
3. **On host:** Run `scripts/release/push-to-nas.sh` to tag + push all 30 images (skopeo fallback for OCI quirks)
4. **On host:** Run `scripts/host/nas-setup.sh` to configure `.env` with mirror + NFS shares
5. **On host:** Add NAS to `/etc/docker/daemon.json` `insecure-registries` if using HTTP

### Pinning tools

- `scripts/release/pin-docker-images.sh` — uses `skopeo` to resolve `latest` → version tag + sha256 digest
- `docker-images.md` — reference table of all 30 base images with pinned tags

### NAS model cache — backup + restore

**The big idea:** Models are large (GB each). The NAS acts as a local cache so you
never re-download from the internet after a nuke-and-pave. Each component script
checks the NAS first: volume → NAS → internet (3-tier fallback).

**Config separation (survives nuke-and-pave):**

- `~/.config/htsai/nas.env` — NAS host, shares, mounts (machine-level, persists)
- `.env` — MIRROR setting (repo-level, disposable)

**Backup (host → NAS):**

```bash
sudo ./scripts/host/backup-models.sh
```

- Auto-detects compose project prefix (`hts-ai-stack_`)
- Rsyncs each Docker volume to its NAS subfolder
- `--no-owner --no-group` for NFS compatibility
- No `--delete` — NAS files are never removed, safe to re-run

**Restore (NAS → host, automatic):**

Component install scripts check NAS before downloading:

1. Model in Docker volume? → skip (already have it)
2. Model on NAS mount? → copy locally (fast LAN transfer)
3. Not on NAS? → download from internet, then seed NAS cache

| Component | Env var | Default NAS path |
|---|---|---|
| Ollama | `NAS_MODEL_CACHE` | `/mnt/htsai-model-backup/ollama/models` |
| Stable Diffusion | `NAS_SD_CACHE` | `/mnt/htsai-model-backup/stable-diffusion/checkpoints` |
| ComfyUI | `NAS_SD_CACHE` | `/mnt/htsai-model-backup/stable-diffusion/checkpoints` |

**NAS folder layout:**

```text
/mnt/htsai-model-backup/
├── ollama/models/             ← blobs + manifests (content-addressed)
├── stable-diffusion/
│   ├── checkpoints/           ← .safetensors files
│   ├── loras/
│   ├── embeddings/
│   └── vae/
├── comfyui/
│   ├── models/
│   ├── custom_nodes/
│   └── output/
├── bitnet/models/
├── localai/models/
├── coqui-tts/models/
└── vosk/models/
```

**Full nuke-and-pave workflow:**

```bash
# 1. Run all backup layers (Timeshift + volumes + models + configs + disk image)
sudo ./backups/pre-nuke-checklist.sh --disk

# 2. Nuke everything
docker compose down -v
docker system prune -a --volumes
rm -rf ~/hts/hts-ai-stack

# 3. Reinstall Ubuntu (same hostname, same user)

# 4. Re-clone and rebuild
git clone https://github.com/htsai-net/hts-ai-stack-release.git ~/hts/hts-ai-stack
cd ~/hts/hts-ai-stack && ./install.sh

# 5. Restore NFS mounts (reads ~/.config/htsai/nas.env, which survived)
sudo ./scripts/host/nas-setup.sh

# 6. Restore Docker volumes from NAS archives
# See: docs/guides/disaster-recovery.md

# 7. Models auto-restore from NAS on first component start — no re-download!
```

**NAS shares (4 total):**

| Share | Mount point | Purpose |
|---|---|---|
| `htsai-model-backup` | `/mnt/htsai-model-backup` | AI model cache (Ollama, SD, ComfyUI, etc.) |
| `htsai-docker-volume-backup` | `/mnt/htsai-docker-volume-backup` | Docker volume backups + system configs |
| `htsai-timeshift-backup` | `/mnt/htsai-timeshift-backup` | Timeshift system snapshots |
| `htsai-disk-image` | `/mnt/htsai-disk-image` | Full disk images for disaster recovery |

**Guides:**

- [Disaster Recovery Runbook](docs/guides/disaster-recovery.md) — step-by-step restore from any backup layer
- [Release Pipeline](docs/guides/release-pipeline.md) — how to cut a public release (source repo → release mirror → website)
- [Synology NFS Share Setup](docs/guides/synology-nfs-shares.md) — DSM configuration for all 4 NAS shares

## Container Naming Conventions

All containers spun up by HTS AI stack MUST be prefixed with `hts-ai-` to avoid conflicts with other services on the host.

### Main Compose Stack (docker-compose.yml)

| Container Name | Service |
|---|---|
| `hts-ai-dashboard` | nginx |
| `hts-ai-gitea` | Self-hosted Git |
| `hts-ai-ollama-1` | LLM inference (GPU) |
| `hts-ai-bitnet-1` | 1-bit LLM (CPU) |
| `hts-ai-open-webui` | Chat frontend |
| `hts-ai-openspace` | Agent skills + dashboard |
| `hts-ai-gvisor-sandbox` | gVisor CPU agent sandbox |
| `hts-ai-koboldcpp` | Interactive fiction (KoboldCpp) |
| `hts-ai-open-llm-vtuber` | Avatar chat (Open-LLM-VTuber) |
| `hts-ai-tabby` | AI code completion (Tabby) |
| `hts-ai-gitea-runner` | CI/CD runner (Gitea Actions) |

### Prod & Test Stacks

Same `hts-ai-*` prefix with environment suffix:

- `hts-ai-ollama-prod-1`, `hts-ai-ollama-test-1`
- `hts-ai-open-webui-prod-1`, `hts-ai-open-webui-test-1`
- `hts-ai-bitnet-prod-1`, `hts-ai-bitnet-test-1`
- `hts-ai-stable-diffusion-prod`, `hts-ai-stable-diffusion-test`
- `hts-ai-sillytavern-prod`, `hts-ai-sillytavern-test`
- `hts-ai-comfyui-test`
- Init containers: `hts-ai-ollama-init`, `hts-ai-stable-diffusion-prod-init`

### External / Third-Party Containers

Not prefixed — managed by third-party tools, not docker-compose:

| Container | Managed By | Notes |
|---|---|---|
| `openshell-cluster-*` | NemoClaw/OpenShell | Managed by `nemoclaw` CLI |
| `hts-ai-assistant-*` | NemoClaw | NemoClaw sandboxes — already prefixed |

### Cleanup

The nuke script (`nuke-stack.sh`) removes stopped containers matching `^hts-ai-*`.

## Dashboard Token Sidecar Pattern

The dashboard uses runtime-generated JSON sidecar files to provide tokenized auto-login URLs for services. These files are gitignored and regenerated on each install/bootstrap.

| Sidecar file | Generated by | Token type | Service |
|---|---|---|---|
| `nemoclaw-tokens.json` | `nemoclaw.sh` (`_extract_dashboard_tokens`) | OpenClaw gateway token | NemoClaw sandboxes (GPU/CPU) |
| `openwebui-token.json` | `open-webui.sh` (`openwebui_generate_dashboard_token`) | JWT (admin sign-in) | Open WebUI |

**Flow:** Component script signs in → writes JSON to `resources/dashboard/` → dashboard JS fetches at load time → rewrites card `href` to tokenized URL → user clicks card → auto-authenticated.

**Open WebUI login bridge:** Because `localStorage` is scoped per origin, the dashboard (`:80`) cannot set tokens for Open WebUI (`:3000`). A tiny bridge page (`resources/open-webui/login.html`) is bind-mounted into the Open WebUI container at `/app/build/static/login.html`. The tokenized URL routes through this page, which sets `localStorage.token` from the same origin and redirects to `/`.

## Host Port Map

> **Rule:** Always review this table before adding or changing a service.
> Duplicate host ports cause silent bind failures at startup.

### Main Compose (`docker-compose.yml`)

| Host Port | Service | Container | Profile | Env Override |
|-----------|---------|-----------|---------|--------------|
| 80 | Dashboard (nginx) | hts-ai-dashboard | dashboard | — |
| 3000 | Open WebUI | hts-ai-open-webui | — | — |
| 3001 | OpenSpace dashboard | hts-ai-openspace | openspace | `OPENSPACE_DASHBOARD_PORT` |
| 3002 | DeerFlow web UI | hts-ai-deerflow | deerflow | `DEERFLOW_PORT` |
| 3005 | Flowise LLM builder | hts-ai-flowise | flowise | `FLOWISE_PORT` |
| 5678 | n8n web UI | hts-ai-n8n | n8n | `N8N_PORT` |
| 7870 | Langflow visual builder | hts-ai-langflow | langflow | `LANGFLOW_PORT` |
| 8001 | SillyTavern web UI | hts-ai-sillytavern | sillytavern | `SILLYTAVERN_PORT` |
| 8200 | Duplicati web UI | hts-ai-duplicati | duplicati | `DUPLICATI_PORT` |
| 8787 | SearXNG meta-search | hts-ai-searxng | searxng | `SEARXNG_PORT` |
| 9099 | Open WebUI Pipelines | hts-ai-pipelines | pipelines | `PIPELINES_PORT` |
| 3030 | Gitea | hts-ai-gitea | gitea | — |
| 3100 | Grafana | hts-ai-grafana | monitoring | — |
| 5000 | OpenSpace MCP | hts-ai-openspace | openspace | — |
| 8003 | DeerFlow backend API | hts-ai-deerflow | deerflow | `DEERFLOW_BACKEND_PORT` |
| 8081 | llama-swap | hts-ai-llama-swap | llama-swap | `LLAMA_SWAP_PORT` |
| 8082 | BitNet API | hts-ai-bitnet-1 | bitnet-cpu | — |
| 8501 | CrewAI Studio (Streamlit) | hts-ai-crewai | crewai | — |
| 8888 | Unsloth Studio UI | hts-ai-unsloth | unsloth | `UNSLOTH_PORT` |
| 8000 | Unsloth API | hts-ai-unsloth | unsloth | `UNSLOTH_API_PORT` |
| 9000 | Portainer HTTP | hts-ai-portainer | portainer | — |
| 9090 | Prometheus | hts-ai-prometheus | monitoring | — |
| 9443 | Portainer HTTPS | hts-ai-portainer | portainer | — |
| 11434 | Ollama API | hts-ai-ollama-1 | ollama-gpu | — |
| 18791 | gVisor sandbox | hts-ai-gvisor-sandbox | gvisor-sandbox | — |
| 18790 | reserved (formerly htsclaw sandbox) | — | — | — |
| 2700 | Vosk gRPC | hts-ai-vosk | vosk | `VOSK_PORT` |
| 5002 | Coqui TTS REST | hts-ai-coqui-tts | coqui-tts | `COQUI_TTS_PORT` |
| 8400 | Bark TTS (text-to-audio) | hts-ai-bark | bark | `BARK_PORT` |
| 5001 | KoboldCpp web UI | hts-ai-koboldcpp | koboldcpp | `KOBOLDCPP_PORT` |
| 8085 | Tabby AI code completion | hts-ai-tabby | tabby | `TABBY_PORT` |
| 12393 | Open-LLM-VTuber avatar chat | hts-ai-open-llm-vtuber | open-llm-vtuber | `OPEN_LLM_VTUBER_PORT` |
| 7862 | Open-Sora Gradio (≥24GB VRAM) | hts-ai-open-sora | open-sora | `OPEN_SORA_PORT` |
| 7865 | CogVideoX Gradio | hts-ai-cogvideox | cogvideox | `COGVIDEOX_PORT` |
| 8600 | Faster-Whisper (speaches) | hts-ai-faster-whisper | faster-whisper | `FASTER_WHISPER_PORT` |
| 8601 | Audio Flamingo (audio LLM) | hts-ai-audio-flamingo | audio-flamingo | `AUDIO_FLAMINGO_PORT` |
| 8602 | AudioCraft / MusicGen Gradio | hts-ai-audiocraft | audiocraft | `AUDIOCRAFT_PORT` |
| 8603 | AnimateDiff Gradio | hts-ai-animatediff | animatediff | `ANIMATEDIFF_PORT` |
| 3006 | Claw3D (3D agent workspace) | hts-ai-claw3d | claw3d | `CLAW3D_PORT` |
| 3101 | Paperclip (AI agent manager) | hts-ai-paperclip | paperclip | `PAPERCLIP_PORT` |
| 8010 | LanguageTool grammar/style API | hts-ai-languagetool | languagetool | `LANGUAGETOOL_PORT` |

### Host-Native Ports (non-Docker)

| Host Port | Service | Notes |
|-----------|---------|-------|
| 1234 | LM Studio | Host tool (not containerized) |
| 8083 | reserved (formerly htsclaw gateway) | — |

### Planned Services (port reserved, not yet in compose)

| Host Port | Service | Notes |
|-----------|---------|-------|
| 3003 | Agnai RP chat | `AGNAI_PORT` |
| 3004 | AnythingLLM web UI | `ANYTHINGLLM_PORT` |
| 3080 | LibreChat web UI | `LIBRECHAT_PORT` |
| 4200 | OpenFang dashboard | `OPENFANG_PORT` |
| 6001 | RisuAI web UI | `RISUAI_PORT` |
| 7863 | HunyuanVideo Gradio | `HUNYUAN_VIDEO_PORT` |
| 7864 | ooba Gradio web UI | `OOBA_UI_PORT` |
| 42617 | ZeroClaw gateway | `ZEROCLAW_PORT` |

### Prod Instance (`instances/prod/docker-compose.yml`)

| Host Port | Service | Notes |
|-----------|---------|-------|
| 3000 | Open WebUI (prod) | Shared with main — only run one |
| 7860 | Stable Diffusion | — |
| 8001 | SillyTavern | — |
| 8080 | llama-swap (prod) | — |
| 11434 | Ollama (prod) | 0.0.0.0 bind |

### Test Instance (`instances/test/docker-compose.yml`)

| Host Port | Service | Notes |
|-----------|---------|-------|
| 3001 | Open WebUI (test) | Conflicts with OpenSpace dashboard if both active |
| 7861 | Stable Diffusion (test) | — |
| 8002 | SillyTavern (test) | — |
| 8081 | llama-swap (test) | Conflicts with main llama-swap if both active |
| 8188 | ComfyUI | — |
| 8189 | ComfyUI (test) | — |
| 11435 | Ollama (test) | — |

### Allocated Range Summary

```text
   80        Dashboard
 2700        Vosk gRPC (STT)
 3000-3005   Web UIs (Open WebUI, OpenSpace dash, DeerFlow, Agnai, AnythingLLM, Flowise)
 3080        LibreChat web UI
 3030        Gitea
 3100        Grafana
 4200        OpenFang dashboard
 5000        OpenSpace MCP
 5001        KoboldCpp (interactive fiction)
 5002        Coqui TTS REST
 8400        Bark TTS (text-to-audio)
 5003        ooba OpenAI-compat API
  5678        n8n workflow automation
  6001        RisuAI web UI
 7860-7861   Stable Diffusion (prod/test)
 7862-7863   Video generation (Open-Sora ≥24GB, HunyuanVideo — disqualified, reserved)
 7865        CogVideoX Gradio (text-to-video)
 7864        ooba Gradio web UI
  7870        Langflow visual AI builder
  8000-8003   Backend APIs (Unsloth API, SillyTavern, DeerFlow)
 8080-8083   LLM routers / gateways (llama-swap, BitNet)
 8085        Tabby AI code completion (GPU)
 8188-8189   ComfyUI (prod/test)
 8200        Duplicati backup UI
 8501        CrewAI Studio (Streamlit)
 8600        Faster-Whisper (speaches STT)
 8602        AudioCraft / MusicGen (Gradio)
 8603        AnimateDiff (Gradio)
  8787        SearXNG meta-search
  8888        Unsloth Studio
 9000-9443   Portainer
  9090        Prometheus
  9099        Open WebUI Pipelines
11434-11435  Ollama (main/test)
12393        Open-LLM-VTuber avatar chat (GPU)
18789-18794  Agent sandboxes (NemoClaw, gVisor, Daytona server/sandbox)
42617        ZeroClaw gateway
```

## Value shapes / gotchas

Per-component catalogue of values written to `.env`, `config/*.{json,yaml}`,
or passed into docker env vars — annotated with the shape gotcha that has
bitten us (or that reviewers should watch for). Grow this table whenever a
new structured value lands in a tracked config or `.env` write path.

| Component | Key | Shape | Gotcha |
|-----------|-----|-------|--------|
| open-webui | `WEBUI_API_KEY` | `sk-<base64>` | base64 padding can end in `=`; any writer that splits on `=` (e.g. `awk -F=`) corrupts it. Use the pure-bash loop in `openwebui_bootstrap_api_key`. |
| open-webui | `WEBUI_SECRET_KEY` | 32-byte urlsafe base64 | same `=` padding risk as above. |
| duplicati | `DUPLICATI_WEB_PASSWORD` | `python -c 'secrets.token_urlsafe(24)'` | contains `-` and `_`; `sed` with `\|` delimiter happened to be safe only because values never contain `\|`. Still migrated to a pure-bash loop to remove the foot-gun. |
| ollama | model tags | `<repo>:<tag>` **or** `hf.co/<org>/<repo>:<quant>` | the `:` in names trips naive parsers that split on `:`; always quote and use `awk -F=` style only for `KEY=VALUE` pairs. |
| llama-swap | bearer token | opaque JWT-shaped | contains `.` and often `=`; preserve verbatim when copying into `.env`. |

Rule of thumb: any value whose source is a randomness primitive
(`secrets.token_urlsafe`, `openssl rand -base64`, `uuidgen`) or an
upstream-defined opaque blob (JWT, signed URL, model tag) MUST be copied
byte-for-byte. Never round-trip through `awk -F=`, `cut -d=`, or `sed`
with a value-derived delimiter.

## Config symmetry invariants

Pairs of files this repo keeps in deliberate lock-step, plus the automated
checker that enforces each invariant. When you add a new pair, register it
here alongside its checker under `scripts/maintenance/` so reviewers (human
or AI) can trace the rule to an enforceable script.

| Pair A | Pair B | Invariant | Checker |
|--------|--------|-----------|---------|
| `scripts/install/models/registry.json` (ollama array) | `config/llama-swap.yaml` (`peers.ollama.models`) | Every routed model is pullable; every prod registry model is routable. | `scripts/maintenance/registry-llama-swap-check.py` |
| `scripts/components/*/*.manifest.json` (`script` field) | `scripts/components/*/*.sh` | Manifest `script` points at an existing, regular, executable shell file. | `scripts/maintenance/manifest-script-check.py` |
| `scripts/components/*/*.manifest.json` (`install_type: compose`) | `docker-compose.yml` (`services`) | Every compose-install manifest has a matching service (by `id` or `compose_service` override). | `scripts/maintenance/stack-compose-check.py` |
| `config/stack.json` (enabled components) | runtime prerequisites | Every stack-enabled component has all deploy prerequisites (compose service, manifest script, registry entry, etc.). | *[planned — see `docs/development/features/FEATURE-068.md`]* |

All checkers follow the same contract: report-only by default (`exit 0`
even with findings), `--strict` for CI / pre-commit gating (`exit 1` on
any finding). Pre-commit wires the strict variants after `scrub-check.sh`
and before the Pester suite so fast failures surface first.

## Component Vendor Docs & Deviation References

Per the **Install per vendor instructions** rule (see `CLAUDE.md` / `AGENTS.md`),
each component lists its authoritative vendor documentation plus any supporting
links (upstream issues, PRs, security advisories, release notes) that justify
deviations recorded in `CONTEXT.md` → *Vendor-Instruction Deviations*.

Entry template — copy this block per component:

```markdown
### <Component Name>

- **Official install docs:** <URL>
- **Release notes / changelog:** <URL>
- **Source repo:** <URL>
- **Deviation refs** (only if `CONTEXT.md` records a deviation):
  - <URL> — <what this link proves / supports>
  - <URL> — <what this link proves / supports>
```

<!-- Add component reference subsections below this line. -->

### NemoClaw

- **Official install docs:** <https://docs.nvidia.com/nemoclaw/latest/get-started/quickstart.html>
- **Release notes / changelog:** <https://docs.nvidia.com/nemoclaw/latest/about/release-notes.html>
- **Source repo:** <https://github.com/NVIDIA/NemoClaw>
- **Version pin source of truth:**
  `scripts/components/nemoclaw/nemoclaw.manifest.json` →
  `upstream.pinned_version` (`"v0.0.31"`). `nemoclaw_install()` and
  `scripts/utils/downgrade-nemoclaw.sh` read this value via `jq` at install
  time; do **not** hard-code the tag anywhere else. Rationale and revisit
  trigger live in `DEVIATIONS.md` → *NemoClaw* (first entry).
  **OpenShell version canonical at
  `nemoclaw.manifest.json upstream.openshell_pinned_version`
  (`"0.0.36"`)** — five previously-hardcoded sites read from the manifest.
- **Deviation refs:**
  - <https://github.com/NVIDIA/NemoClaw/blob/v0.0.31/scripts/install.sh> —
    pinned installer. `--help` at this tag documents
    `NEMOCLAW_PROVIDER build | openai | anthropic | anthropicCompatible |
    gemini | ollama | custom | nim-local | vllm` and
    `NEMOCLAW_EXPERIMENTAL=1 — Show experimental/local options`; we use
    `NEMOCLAW_PROVIDER=custom` (gated by `NEMOCLAW_EXPERIMENTAL=1`) so
    install step `[3/8] Configuring inference` routes to llama-swap instead
    of NVIDIA Endpoints.
  - <https://github.com/NVIDIA/NemoClaw/blob/v0.0.31/nemoclaw-blueprint/blueprint.yaml>
    — declares `min_openshell_version: 0.0.32`, `max_openshell_version:
    0.0.36`; OpenShell pinned at `0.0.36` (top of window). Same window as
    v0.0.29, so the OpenShell pin is unchanged across the v0.0.31 bump.
    `min_openclaw_version` advanced to `2026.4.24` in v0.0.31 (matches the
    GHCR-pinned base image; resolves the v0.0.29 Step 17 Patch 4 mismatch).
  - PR #1824 — `fix(onboard): recover openshell gateway bootstrap startup`:
    <https://github.com/NVIDIA/NemoClaw/pull/1824>
  - PR #466 — `fix(connect): add readiness poll with timeout`:
    <https://github.com/NVIDIA/NemoClaw/pull/466>
  - PR #2472 — `fix(sandbox): fix non-root gateway startup and add crash safety net`:
    <https://github.com/NVIDIA/NemoClaw/pull/2472>
  - <https://docs.k3s.io/installation/requirements#inotify-limits> — upstream k3s
    requirement for `fs.inotify.max_user_instances` / `max_user_watches`; justifies
    the `_fix_inotify_limits` preflight (NVIDIA's OpenShell gateway embeds k3s).
  - <https://github.com/k3s-io/k3s/issues/1969> — canonical report of
    `inotify_init: too many open files` crashing kubelet on default Ubuntu inotify
    limits; matches the symptom we observed in `converge-20260421-120202.log`.
  - <https://docs.docker.com/reference/cli/docker/container/rm/#force> — rationale
    for `docker rm -f` on stale `openshell-cluster-<gateway>` containers that
    `openshell gateway destroy` cannot clear while they are restarting.

### Stable Diffusion

- **Official install docs:** <https://github.com/AUTOMATIC1111/stable-diffusion-webui/wiki/Install-and-Run-on-NVidia-GPUs>
- **Release notes / changelog:** <https://github.com/AUTOMATIC1111/stable-diffusion-webui/releases>
- **Source repo:** <https://github.com/AUTOMATIC1111/stable-diffusion-webui>
- **Deviation refs:**
  - <https://github.com/AUTOMATIC1111/stable-diffusion-webui/blob/master/modules/launch_utils.py> —
    `prepare_environment()` shows the support repos (`stable-diffusion-stability-ai`,
    `generative-models`, `k-diffusion`, `BLIP`) that `launch.py` clones on first
    run; we pre-bake them in the image to stay within the healthcheck budget.
  - <https://github.com/Stability-AI/stablediffusion> — original upstream, deleted
    in late 2025; justifies pointing `stable-diffusion-stability-ai` at the
    community-maintained fork below.
  - <https://github.com/w-e-w/stablediffusion> — maintained fork used as the
    `STABLE_DIFFUSION_REPO` replacement and the pre-baked clone path.
  - <https://docs.docker.com/reference/dockerfile/#healthcheck> — `start_period`,
    `retries`, and `interval` semantics; justifies the extended first-run budget.
  - <https://launchpad.net/~git-core/+archive/ubuntu/ppa> — upstream-maintainer
    PPA providing current git (>=2.44) on Ubuntu 22.04; required because git
    2.34 lacks `--refetch` (added in git 2.38) and `launch.py`'s autofix path
    invokes `git fetch --refetch --no-auto-gc`.
  - <https://github.com/git/git/blob/master/Documentation/RelNotes/2.38.0.txt>
    — git 2.38 release notes introducing `fetch --refetch`.
  - <https://github.com/AUTOMATIC1111/stable-diffusion-webui/blob/master/modules/launch_utils.py>
    — defines `STABLE_DIFFUSION_XL_COMMIT_HASH`
    (`45c443b316737a4ab6e40413d7794a7f5657c19f`) which `git_clone` checks out
    inside `generative-models`; justifies a full clone (no `--depth 1`) for
    that repo so the pinned commit is always reachable.

## Examples of good work

- Component manifests under `scripts/components/*/` — each service has a self-contained `*.manifest.json` with metadata, config mapping, health-check definitions, and deploy order
- Convergence engine (`scripts/utils/converge.sh`) — declarative desired-state reconciliation driven by `stack.json` and manifests
- Docker image pinning workflow (`scripts/release/pin-docker-images.sh`) — every base image locked to version tag + sha256 digest with NAS mirror toggle

## Relevant links

- [OpenClaw](https://openclaw.ai/) — agent framework
- [NemoClaw](https://www.nvidia.com/en-us/ai/nemoclaw/) — NVIDIA agent runtime
- [OpenShell](https://docs.nvidia.com/openshell/latest/index.html) — sandbox isolation
- [Ollama](https://ollama.com/) — local LLM server
- [Open WebUI](https://github.com/open-webui/open-webui) — chat frontend
- [llama-swap](https://github.com/mostlygeek/llama-swap) — model multiplexer for GPU/CPU split inference
- [Clief Notes Framework](CLIEF-NOTES-FRAMEWORK.md) — documentation structure standard

## Notes

- NVIDIA drivers are **only** installed from `bootstrap.sh` and always last (requires reboot)
- OpenClaw runs exclusively inside OpenShell sandboxes — never on bare metal. The `nemoclaw` and `openshell` CLI tools run on the host; OpenClaw runs inside the sandboxes they manage.
- All host port assignments are tracked in `config/portmap.json` (single source of truth) and mirrored in the Host Port Map table above

### ROCm (AMD GPU drivers)

- **Vendor doc followed:** <https://rocmdocs.amd.com/en/latest/Installation_Guide/Installation-Guide.html>
- **Deviation:** Adds ROCm apt repository and installs packages via `scripts/host/amd.sh`.
- **Why:** Automates ROCm installation and integrates with bootstrap flow.
- **Where implemented:** `scripts/host/amd.sh`, invoked from `bootstrap.sh`.
- **Revisit when:** ROCm provides an official installer script or changes repository layout.
- **References:** see `REFERENCES.md` → *ROCm* section.

