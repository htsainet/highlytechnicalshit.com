#!/usr/bin/env python3
"""manifest-script-check.py — verify every component manifest points at a real script.

Invariant:
    For every scripts/components/*/*.manifest.json that declares a `script`
    field, the referenced path MUST exist, be a regular file, and be
    executable. This catches copy/paste mistakes and renames that forgot to
    update the manifest.

Usage:
    scripts/maintenance/manifest-script-check.py            # report only
    scripts/maintenance/manifest-script-check.py --strict   # exit 1 on drift

Exit codes:
    0 = all manifests OK, or findings in report-only mode (default)
    1 = --strict AND one or more findings
    2 = file / parse error
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
COMPONENTS = REPO / "scripts/components"


def main() -> int:
    strict = "--strict" in sys.argv[1:]

    if not COMPONENTS.is_dir():
        sys.stderr.write(f"ERROR: {COMPONENTS} not found\n")
        return 2

    manifests = sorted(COMPONENTS.glob("*/*.manifest.json"))
    findings: list[str] = []
    checked = 0

    for mf in manifests:
        try:
            data = json.loads(mf.read_text())
        except Exception as exc:
            findings.append(f"{mf.relative_to(REPO)}: parse error: {exc}")
            continue

        script = data.get("script")
        if not script:
            continue  # manifests without a script are legal (e.g. pure metadata)
        checked += 1

        target = REPO / script
        rel_mf = mf.relative_to(REPO)

        if not target.exists():
            findings.append(f"{rel_mf}: script path does not exist: {script}")
            continue
        if not target.is_file():
            findings.append(f"{rel_mf}: script path is not a regular file: {script}")
            continue
        if not os.access(target, os.X_OK):
            findings.append(f"{rel_mf}: script is not executable (chmod +x): {script}")

    if not findings:
        print(f"✓ manifest-script-check: {checked}/{len(manifests)} manifest(s) with `script` all point at real executables.")
        return 0

    print(f"✗ manifest-script-check: {len(findings)} finding(s) across {len(manifests)} manifest(s):")
    for f in findings:
        print(f"    - {f}")
    print("  → Fix the manifest's `script` field or restore/chmod +x the target.")

    return 1 if strict else 0


if __name__ == "__main__":
    sys.exit(main())
