# Security Whitepapers

Last updated: 2026-03-31 19:09:58

## What this folder is

Curated arXiv papers and whitepapers relevant to the security architecture of this stack.
Master threat model and architecture decisions live in [`../security-review/CONTEXT.md`](../security-review/CONTEXT.md).

## What good looks like

- Each paper gets a `results/arXiv-ID.md` summary artifact once deep-read (e.g. `results/2603.10387.md`)
- Summaries include: key findings, mapping to our threat model, actionable takeaways
- `REFERENCES.md` is the tracking table — link the Details column to artifacts as they are produced

## Review workflow

1. Papers are triaged into tiers in `REFERENCES.md`
2. Deep-read produces a per-paper artifact in `results/`
3. Update the Details column in `REFERENCES.md` to link to the artifact
4. Cross-reference findings back to `../security-review/CONTEXT.md` threat model

## Tools and skills

- **arXiv.org** — Academic paper discovery and access
- **Claude Opus** — Deep technical paper analysis
- **PDF extraction** — Paper content parsing
- **Threat modeling** — Architecture threat assessment
- **LLM security research** — Foundation model attack/defense knowledge
- **Cryptography** — Cryptographic protocol analysis

## What to avoid

- Don't deep-read Tier 3/4 papers before finishing Tier 1
- Don't duplicate findings — reference them from `../security-review/CONTEXT.md`
