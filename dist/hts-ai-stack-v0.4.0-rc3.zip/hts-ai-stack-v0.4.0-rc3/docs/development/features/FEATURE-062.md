# FEATURE-062 — Repo Hygiene: Pre-Commit Data Scrubber + Secret Scan

| Field | Value |
|-------|-------|
| Status | MVP Landed (Phases 1–3) |
| Category | Developer Experience / Security |
| Target Release | v0.5.0 |
| Priority | HIGH |
| Effort | M (phased; each phase standalone) |
| Components | None (host-side tooling + pre-commit framework) |
| Dependencies | None hard; complements FEATURE-061 (Agent Registry) for agent-scoped cleanup |
| Related | SECURITY-009 (secret isolation), FEATURE-055 (secrets in .env), existing `backups/pre-nuke-checklist.sh` pattern |

## MVP status (landed)

- ✅ **Phase 1** — `.gitignore` hardening (previously landed)
- ✅ **Phase 2** — `scripts/maintenance/clean-for-commit.sh` + `scripts/maintenance/scrub-check.sh`
- ✅ **Phase 3** — `.githooks/pre-commit` wired to call `scrub-check.sh` on staged files; `git config core.hooksPath .githooks` enabled
- ✅ **Release tool** — `scripts/release/build-snapshot.sh` codifies the rc2 snapshot flow (tracked-only + blacklist strip + post-build scrub)
- ✅ **Operator deny-list** — `config/pii-deny.txt.example` shipped; `config/pii-deny.txt` gitignored so each operator can add their names/pets/handles without publishing them
- ⬜ **Phase 4** — CI mirror of the scan (server-side enforcement)
- ⬜ **Phase 5** — optional names corpus (rejected for now: too noisy; deny-list preferred)

## Summary

A layered repo-hygiene system that prevents runtime data, test data,
PII, and secrets from ever landing in the repo.

Four defensive layers:

1. **Passive** — comprehensive `.gitignore` for runtime-writable paths
2. **Active** — `scripts/clean-before-commit.sh` opt-in scrubber
3. **Enforced** — pre-commit hook with secret scanning + path rules
4. **Server-side** — CI mirror of the same checks

User-facing goal: **"I should be able to run one command and know my
working tree has no logs, no test PII, no stray secrets, no runtime DB
dumps — then commit with confidence."**

## Why this feature

The stack generates a lot of runtime data — logs, conversation
histories, SQLite DBs, cached responses, event streams, ephemeral
volumes. Much of it can contain:

- Personal conversations with agents (PII, private thoughts)
- Test data created during manual exploration
- Tokens, session cookies, JWTs captured in logs
- Model responses that echo user input (often sensitive)
- Prompt experiments with real data that shouldn't be shared
- Local file paths, hostnames, internal IPs

Current protection is ad-hoc `.gitignore` entries. A single `git add -A`
in the wrong directory or a misconfigured path could commit months of
conversation history. The goal is defense-in-depth so that the wrong
commit requires defeating multiple layers of guardrails, not one.

## Phases

### Phase 1 — `.gitignore` sweep
- Audit current `.gitignore`
- Add comprehensive patterns for every runtime-writable path across
  the stack (logs, data dirs, per-component caches, SQLite DBs,
  exported conversations, `.env.*`, Docker volume mount points, etc.)
- Allow-list exceptions with explicit `!` rules (e.g., `.env.example`)
- Document policy in `docs/development/gitignore-policy.md`
- Commit as single chore PR

Representative additions:
```gitignore
# Runtime
logs/
**/logs/
data/
**/data/
instances/*/data/
instances/*/logs/
**/*.db
**/*.sqlite
**/*.sqlite3
**/*.wal
**/*.shm

# Secrets
.env
.env.*
!.env.example
!.env.example.*
secrets/
*.key
*.pem
*.p12

# Agent runtime
agents/**/conversations/
agents/**/events/
agents/**/cache/

# Dashboard / UI cache
resources/dashboard/cache/
**/node_modules/
**/__pycache__/

# Backups (keep tooling, not output)
backups/local/
backups/output/
*.tar.gz
*.tar.zst
!release-*.tar.gz

# Volume exports
*.vol.tar
*.volume-backup.*
```

### Phase 2 — `scripts/clean-before-commit.sh`
Opt-in scrubber with safe defaults. Same discipline as
`backups/pre-nuke-checklist.sh` (prompts, dry-run, explicit scopes).

**CLI:**
```bash
clean-before-commit.sh [--dry-run] [--agents-only] [--all]
                       [--preserve=logs,data]
                       [--include-volumes] [--include-backups]
                       [--force]
```

**Default scope** (safe, non-destructive to source):
- Truncate or delete every file under `logs/`, `**/logs/`
- Delete SQLite WAL/SHM files (`*.wal`, `*.shm`)
- Delete `.env.local`, `.env.dev`, `.env.backup*` (but NOT `.env`
  or `.env.example`)
- Clear dashboard/UI caches
- Wipe agent event logs and conversation histories (once FEATURE-061 lands)
- Prune `__pycache__`, `.pytest_cache`, `.mypy_cache`
- Clear Docker stdout capture paths if any
- Truncate Open WebUI conversation exports, SillyTavern chat logs,
  NemoClaw sandbox conversation caches

**Opt-in scope** (destructive, explicit flags):
- `--include-volumes` — `docker volume rm` for ephemeral dev volumes
- `--include-backups` — delete local backup tarballs
- `--all` — everything

**Safeguards:**
- Refuses to run if uncommitted tracked-file changes exist (to avoid
  data loss), unless `--force`
- `--dry-run` prints every action without executing
- Logs every deletion to `backups/clean-before-commit-$(date).log`
- Preserves schemas for SQLite DBs (truncates tables, keeps structure)

### Phase 3 — Pre-commit hook framework
- Adopt the [`pre-commit`](https://pre-commit.com/) framework
- `.pre-commit-config.yaml` at repo root
- Hooks enabled:
  - **`gitleaks`** or **`detect-secrets`** — secret scanning with baseline
  - **`check-added-large-files`** — refuse files > 1 MB without explicit marker
  - **`check-yaml`**, **`check-json`** — syntax validation
  - **`check-merge-conflict`** — catches merge markers
  - **Custom: `no-runtime-paths`** — refuse any tracked file under runtime paths
  - **Custom: `no-data-extensions`** — refuse `.db`, `.sqlite`, `.log`, `.jsonl` without allowlist marker
  - **Custom: `persona-sha-check`** (Phase 4, ties to FEATURE-061) — refuse
    commits that modify tracked persona files without updating manifest SHA
- `bootstrap.sh` installs and activates hooks by default
- Documented bypass: `git commit --no-verify` explicitly requires acknowledging
  why (commit-msg template reminder)

### Phase 4 — Agent-aware scrubbing (ties to FEATURE-061)
Once the agent registry exists:
- `agentctl clean [<agent-id>] [--all]` wipes agent event logs,
  conversation histories, drift baselines
- Called by `clean-before-commit.sh` when the registry DB exists
- Per-agent granularity (e.g., "clean only caco-bot's state")

### Phase 5 — CI / server-side enforcement
- Gitea Actions workflow (and GitHub Actions mirror if pushed there)
  that runs on every PR:
  - `gitleaks detect --no-git` across the diff
  - Large-file check
  - Pattern checks (PII regex: email, phone, SSN, CC, non-RFC1918 IP)
  - Runtime-path regression check
- Blocks merge if violations found
- Allows baseline file for known-accepted matches (e.g., docs examples)

## Risks & mitigations

| Risk | Mitigation |
|---|---|
| False positives in secret scanner block legitimate work | Baseline file + per-repo allowlist |
| Developer bypasses `--no-verify` | CI catches it server-side; commit-msg audit log |
| Scrubber accidentally deletes source files | `--dry-run` default-on in CI; refusal to run with uncommitted changes |
| PII slips through in free-form markdown (docs/plans) | Regex check with allowlist for docs/ examples |
| Historical commits already contain PII | Separate `git filter-repo` runbook documented in `docs/security/historical-scrub.md` |
| Large-file marker abused | CI enforces marker requires code-review approval |

## Out of scope

- Retroactive history rewriting (documented as a separate runbook)
- Enterprise DLP integration
- Encrypted commits / transparent encryption of sensitive files
  (different category — use `git-crypt` or `age` per-file if desired)
- Personal pre-commit preferences (linters, formatters — separate)

## Acceptance criteria

**Phase 1:**
- [ ] `.gitignore` covers every runtime-writable path in the stack
- [ ] Policy doc explains rationale and how to add new entries

**Phase 2:**
- [ ] `clean-before-commit.sh` runs clean on a fresh clone (no-op)
- [ ] Dry-run mode shows expected deletions without executing
- [ ] Scrubbing preserves schema for SQLite DBs
- [ ] Refuses to run with uncommitted source changes unless `--force`

**Phase 3:**
- [ ] `pre-commit install` activates all hooks
- [ ] Secret scanner catches a synthetic `sk-test-fake-...` token
- [ ] Large-file hook blocks a 2MB dummy file without marker
- [ ] Runtime-path hook blocks `git add logs/x.log`

**Phase 5:**
- [ ] CI workflow runs on every PR and blocks on violations
- [ ] Bypassing local hook still gets caught by CI

## Immediate quick-win (ships with Phase 2)

Before the full feature lands, `scripts/clean-before-commit.sh` can be
delivered as a small standalone utility. Low risk, high daily value,
establishes the pattern that Phase 3+ expands on.
