$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..')  )
    Set-Location $script:RepoRoot

    # Load NAS config from ~/.config/htsai/nas.env (survives nuke-and-pave)
    $nasEnvFile = Join-Path $HOME '.config/htsai/nas.env'
    $script:NasVars = @{}
    if (Test-Path $nasEnvFile) {
        Get-Content $nasEnvFile | Where-Object { $_ -match '^\s*([A-Z_]+)=(.*)$' } | ForEach-Object {
            $script:NasVars[$Matches[1]] = $Matches[2]
        }
    }

    # Load MIRROR from repo .env
    $repoEnvFile = Join-Path $script:RepoRoot '.env'
    if (Test-Path $repoEnvFile) {
        Get-Content $repoEnvFile | Where-Object { $_ -match '^\s*MIRROR=(.*)$' } | ForEach-Object {
            $script:NasVars['MIRROR'] = $Matches[1]
        }
    }

    $script:Mirror = $script:NasVars['MIRROR'] ?? ''
    $script:NasHost = $script:NasVars['NAS_HOST'] ?? ''
}

# ── Dockerfile MIRROR wiring ─────────────────────────────────────────────────

Describe 'Dockerfile MIRROR build arg' {
    BeforeDiscovery {
        $script:Dockerfiles = Get-ChildItem -Path (Join-Path $PSScriptRoot '../docker') `
            -Filter 'Dockerfile' -Recurse | ForEach-Object {
            @{
                Name = $_.Directory.Name
                Path = $_.FullName
            }
        }
    }

    It '<Name>/Dockerfile has ARG MIRROR= before every FROM' -TestCases $script:Dockerfiles {
        $lines = Get-Content $Path
        $fromIndices = @()
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -match '^\s*FROM\s') { $fromIndices += $i }
        }
        $fromIndices.Count | Should -BeGreaterThan 0 -Because "$Name should have at least one FROM"

        foreach ($idx in $fromIndices) {
            # Look for ARG MIRROR= in the lines before this FROM
            $found = $false
            for ($j = $idx - 1; $j -ge 0 -and $j -ge ($idx - 3); $j--) {
                if ($lines[$j] -match '^\s*ARG\s+MIRROR=') { $found = $true; break }
            }
            $found | Should -BeTrue -Because "FROM at line $($idx+1) needs ARG MIRROR= before it"
        }
    }

    It '<Name>/Dockerfile FROM lines use ${MIRROR} prefix' -TestCases $script:Dockerfiles {
        $lines = Get-Content $Path | Where-Object { $_ -match '^\s*FROM\s' }
        foreach ($line in $lines) {
            # Allow FROM scratch (no mirror needed) and FROM builder/stage aliases
            if ($line -match 'FROM\s+(scratch|.*\sAS\s)') { continue }
            $line | Should -Match '\$\{MIRROR\}' -Because "FROM should use MIRROR variable"
        }
    }
}

# ── docker-compose.yml MIRROR wiring ─────────────────────────────────────────

Describe 'docker-compose.yml MIRROR args' {
    BeforeAll {
        $script:ComposeFile = Join-Path $script:RepoRoot 'docker-compose.yml'
        $script:ComposeContent = Get-Content $script:ComposeFile -Raw
    }

    It 'Every build: section passes MIRROR arg' {
        # Find all services with build: sections
        $lines = Get-Content $script:ComposeFile
        $inBuild = $false
        $services = @()
        $currentService = ''
        $hasMirror = $false

        foreach ($line in $lines) {
            if ($line -match '^\s{2}(\w[\w-]+):\s*$') {
                if ($inBuild -and $currentService -and -not $hasMirror) {
                    $services += $currentService
                }
                $currentService = $Matches[1]
                $inBuild = $false
                $hasMirror = $false
            }
            if ($line -match '^\s+build:') { $inBuild = $true }
            if ($inBuild -and $line -match 'MIRROR') { $hasMirror = $true }
        }

        $services | Should -BeNullOrEmpty -Because "all build sections should pass MIRROR"
    }
}

# ── NAS Registry connectivity ────────────────────────────────────────────────

Describe 'NAS Registry' -Skip:([string]::IsNullOrWhiteSpace($script:Mirror)) {
    It 'Registry API is reachable' {
        $registryUrl = "http://$($script:Mirror.TrimEnd('/'))v2/"
        $response = Invoke-WebRequest -Uri $registryUrl -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
        $response.StatusCode | Should -Be 200
    }

    It 'Registry has images in catalog' {
        $catalogUrl = "http://$($script:Mirror.TrimEnd('/'))v2/_catalog"
        $response = Invoke-RestMethod -Uri $catalogUrl -TimeoutSec 5
        $response.repositories.Count | Should -BeGreaterThan 0
    }
}

# ── NAS NFS mounts ───────────────────────────────────────────────────────────

Describe 'NAS NFS Shares' -Skip:([string]::IsNullOrWhiteSpace($script:NasHost)) {
    BeforeDiscovery {
        $nasEnvPath = Join-Path $HOME '.config/htsai/nas.env'
        $script:MountCases = @()
        if (Test-Path $nasEnvPath) {
            Get-Content $nasEnvPath | Where-Object { $_ -match '^\s*NAS_(\w+)_MOUNT=(.+)$' } | ForEach-Object {
                $script:MountCases += @{
                    Name  = $Matches[1]
                    Mount = $Matches[2]
                }
            }
        }
    }

    It 'NAS host <NasHost> is reachable' {
        $ping = Test-Connection -ComputerName $script:NasHost -Count 1 -Quiet
        $ping | Should -BeTrue
    }

    It '<Name> mount point exists at <Mount>' -TestCases $script:MountCases {
        Test-Path $Mount | Should -BeTrue -Because "mount point $Mount should exist"
    }

    It '<Name> is mounted at <Mount>' -TestCases $script:MountCases {
        $mounts = & findmnt --noheadings --target $Mount 2>&1
        $mounts | Should -Not -BeNullOrEmpty -Because "$Mount should be an active mount"
    }
}

# ── Scripts exist and are executable ──────────────────────────────────────────

Describe 'NAS scripts' {
    BeforeDiscovery {
        $script:ScriptCases = @(
            @{ Name = 'nas-setup.sh';       Path = 'scripts/host/nas-setup.sh' }
            @{ Name = 'nas.sh';             Path = 'scripts/host/nas.sh' }
            @{ Name = 'push-to-nas.sh';     Path = 'push-to-nas.sh' }
            @{ Name = 'pull-all-images.sh';  Path = 'pull-all-images.sh' }
            @{ Name = 'pin-docker-images.sh'; Path = 'pin-docker-images.sh' }
        )
    }

    It '<Name> exists' -TestCases $script:ScriptCases {
        $fullPath = Join-Path $script:RepoRoot $Path
        Test-Path $fullPath | Should -BeTrue
    }

    It '<Name> is executable' -TestCases $script:ScriptCases {
        $fullPath = Join-Path $script:RepoRoot $Path
        $mode = (Get-Item $fullPath).UnixMode
        $mode | Should -Match 'x' -Because "$Name should be executable"
    }

    It '<Name> has valid bash syntax' -TestCases $script:ScriptCases {
        $fullPath = Join-Path $script:RepoRoot $Path
        $result = & bash -n $fullPath 2>&1
        $LASTEXITCODE | Should -Be 0 -Because "$Name should have valid syntax: $result"
    }
}
