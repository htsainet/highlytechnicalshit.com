#!/usr/bin/env bash
# 01-autoinstall.sh — Thin wrapper (transition period)
#
# Original monolithic autoinstall has been split into focused host scripts:
#   scripts/host/nvidia.sh  — NVIDIA drivers, CUDA, container toolkit
#   scripts/host/docker.sh  — Docker Engine, Compose, group setup
#   scripts/host/node.sh    — Node.js via NVM
#   scripts/host/tools.sh   — VS Code, PowerShell, tokens, repo tooling
#
# This wrapper calls them in the correct order for backwards compatibility.
# See: refactor/tasks/02-split-autoinstall/TASK.md
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner
step "01 — Auto-Install (delegating to host scripts)"

bash "$REPO_DIR/scripts/host/nvidia.sh"
bash "$REPO_DIR/scripts/host/docker.sh"
bash "$REPO_DIR/scripts/host/node.sh"
bash "$REPO_DIR/scripts/host/tools.sh"

info "Host setup complete. install.sh will continue with remaining steps."
