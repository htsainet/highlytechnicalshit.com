# Adding a New Service

This guide explains how to add a new toggleable service to the HTS AI stack. After following these steps the service will appear automatically in the setup wizard, be tracked by the manifest registry, and be converged by the install pipeline.

---

## Prerequisites

- Branch off `feature/009-converge` (or main, after merge)
- Know the service's Docker image name and port(s)
- Know which category the service belongs to (see Step 2 below)

---

## Step 1 — Create the Manifest

Create `scripts/components/<id>.manifest.json`. Use an existing manifest as a template (e.g. `flowise.manifest.json`).

### Required top-level fields

| Field | Type | Notes |
|-------|------|-------|
| `id` | string | Lowercase, hyphen-separated. Must match filename. |
| `display_name` | string | Human-readable label used in wizard and logs. |
| `category` | string | See Step 2 below. |
| `description` | string | One-line description shown in wizard. |
| `install_order` | number | Relative start order within the stack. |
| `script` | string | Relative path to the install/lifecycle script. |
| `func_prefix` | string | Prefix used by lifecycle functions (`start`, `stop`, etc.). |
| `profile` | string | Docker Compose profile name (usually matches `id`). |
| `health.url` | string | HTTP endpoint for health checks (empty if N/A). |
| `health.timeout` | number | Seconds before health check is considered failed. |

### Optional top-level fields

| Field | Type | Default | Notes |
|-------|------|---------|-------|
| `toggleable` | bool | `false` | Set `true` to make this service appear in the wizard checklist. |
| `wizard_default` | bool | `false` | Pre-select ON in a fresh install. Use sparingly. |
| `requires_gpu` | bool | `false` | Adds `[GPU]` label in wizard; shows warning if GPU not detected. |
| `vram_minimum` | int | `0` | Hard floor in MiB — hides service from wizard if GPU VRAM is lower. |
| `vram_estimate_mb` | int | `0` | Typical runtime VRAM in MiB. Used for budget calculation, not gating. |
| `download_size_mb` | int | `0` | Approximate total download size in MiB (Docker image + models + data). |
| `maturity` | string | `"stable"` | See [Maturity Levels](#maturity-levels) below. |
| `install_type` | string | `""` | See [Install Types](#install-types) below. |
| `prompts` | array | `[]` | Follow-up questions after the user enables this service. |

### config block

```jsonc
"config": {
  "toggleable": true,
  "write_rules": [
    {
      "path": ".<id>.enabled",
      "on_enable": true,
      "on_disable": false
    }
  ]
}
```

For services that are array members (e.g. `extras.components`, `admin.tools`):

```jsonc
"config": {
  "toggleable": true,
  "write_rules": [
    {
      "path": ".extras.components",
      "action": "add_remove",
      "value": "<id>"
    }
  ]
}
```

---

## Step 2 — Choose a Category

The category controls which wizard checklist screen the service appears on.

| Category | Screen label | Example services |
|----------|-------------|-----------------|
| `core` | Core Services | dashboard, pipelines |
| `agents` | Agent & Workflow Services | flowise, n8n, deerflow |
| `extras` | Extra Tools & Applications | searxng, sillytavern, duplicati |
| `monitoring` | Monitoring & Management | prometheus |
| `admin` | Admin & Remote Access | portainer, tailscale |
| `training` | Training & Fine-Tuning | unsloth |
| `comms` | Communications | telegram, signal |
| `music` | Music Production | ubuntu-audio, kxstudio, ardour, audiocraft |
| `video` | Video Production | kdenlive, obs-studio, handbrake, cogvideox, open-sora |
| `animation` | Animation | blender, synfig, opentoonz, animatediff |
| `digital-art` | Digital Art & Design | gimp, krita, inkscape, darktable |
| `inference` | _(hardcoded wizard step)_ | ollama, bitnet, lmstudio |
| `sandbox` | _(hardcoded wizard step)_ | nemoclaw |
| `images` | _(hardcoded wizard step)_ | comfyui |

Categories `inference`, `sandbox`, and `images` are excluded from the dynamic checklist — they are controlled by dedicated wizard steps. Do not add new toggleable services to these categories unless you also update the hardcoded wizard steps.

---

## Maturity Levels

The `maturity` field controls how a component appears in the reconfigure checklist.
When omitted, maturity defaults to `"stable"` (no tag shown).

| Value | Checklist tag | Meaning |
|-------|--------------|---------|
| `"stable"` | _(none)_ | Tested and production-ready. This is the default. |
| `"beta"` | `[BETA]` | Functional but may have rough edges. |
| `"untested"` | `[UNTESTED]` | Newly added, not yet validated on real hardware. |

### Promoting a component

To promote a component from untested → stable, either:

1. Change `"maturity": "untested"` to `"maturity": "stable"` in the manifest, or
2. Remove the `"maturity"` field entirely (defaults to stable).

The tag is rendered by `reconfigure.sh` at checklist-build time — no other files
need updating.

---

## Install Types

| `install_type` value | Meaning | Wizard treatment | Converge treatment |
|---------------------|---------|-----------------|-------------------|
| _(absent / empty)_ | Normal Docker Compose service | Toggle in checklist | Full lifecycle (compose up/down/health) |
| `"compose"` | Explicit Docker Compose service | Same as absent | Same as absent |
| `"host"` | Host-native desktop app (apt/snap/PPA) | Toggle in checklist | Runs install script; no compose lifecycle |
| `"host-interactive"` | Host-level install requiring user interaction | Info msgbox only; excluded from checklist | Skipped with guidance message; log path to manual script |
| `"host-automated"` | Host-level install, fully scriptable | Toggle in checklist | Runs install script directly; skips compose |

Services with `install_type: "host-interactive"` (e.g. LM Studio, Signal) require dedicated wizard steps and manual install flows. They are excluded from the dynamic category checklist automatically.

---

## Step 3 — Add prompts[] (optional)

`prompts` is an array of follow-up questions shown after the user enables the service. Leave it empty (`[]`) or omit it if there are no per-service questions.

### Prompt object schema

```jsonc
{
  "key": "basic_auth",          // unique within this manifest
  "type": "input",              // see types below
  "label": "Question text shown in wizard",
  "default": "yes",             // type-appropriate default
  "write_target": "stack.json", // "stack.json" | "env" | "secrets.json"
  "write_path": ".<id>.basic_auth",  // jq-style path (write_target=stack.json)
  "env_var": "MY_VAR",          // env var name (write_target=env)
  "choices": [                  // ONLY for type=menu
    { "tag": "val1", "label": "Option 1" },
    { "tag": "val2", "label": "Option 2" }
  ]
}
```

### Prompt types

| `type` | Whiptail widget | Notes |
|--------|----------------|-------|
| `input` | `--inputbox` | Free-form text |
| `yesno` | `--yesno` | Produces `"true"` / `"false"` |
| `menu` | `--menu` | Single select from `choices[]` |
| `secret` | `--passwordbox` | Written to `secrets.json env_vars` or env; never to `stack.json` |
| `info` | `--msgbox` | Display-only; no value produced |

---

## Step 4 — Add a Docker Compose profile

Add a Compose service block in `docker-compose.yml` (or a `docker-compose.<id>.yml` override file). Use the same profile name as `manifest.profile`.

---

## Step 5 — Add a lifecycle script

Create `scripts/components/<id>.sh`. It must implement the standard lifecycle functions prefixed with `manifest.func_prefix`:

- `<prefix>_start` — pull image and bring up the profile
- `<prefix>_stop` — bring down the profile
- `<prefix>_status` — print running container info
- `<prefix>_logs` — tail container logs

See `scripts/components/flowise/flowise.sh` for a minimal example.

---

## Step 6 — Verify port assignment

Before using any port, check `REFERENCES.md` → Host Port Map for conflicts.

---

## Step 7 — Test

```bash
# 1. Confirm manifest loads cleanly
bash -c "source scripts/lib/manifest-loader.sh; manifest_load_all; echo \${COMPONENT_ORDER[@]}"

# 2. Run the wizard (on a test VM)
bash config/wizard/ai_stack_setup.sh

# 3. Verify the service appears in the correct checklist screen

# 4. Verify stack.json contains the expected key after wizard completes
python3 -c "import json; d=json.load(open('config/stack.json')); print(d.get('<id>'))"

# 5. Run converge
bash scripts/utils/converge.sh
```

---

## Checklist

- [ ] `scripts/components/<id>.manifest.json` created with all required fields
- [ ] `config.toggleable: true` and `write_rules` defined
- [ ] `install_order`, `profile`, `func_prefix` match your Compose/script setup
- [ ] `maturity` set appropriately (`"untested"` for new, omit or `"stable"` for validated)
- [ ] Port(s) registered in `REFERENCES.md` Host Port Map
- [ ] `docker-compose.yml` profile added
- [ ] `scripts/components/<id>.sh` lifecycle script created
- [ ] Wizard tested — service appears, toggles correctly, stack.json is valid
- [ ] `converge.sh` tested — service starts/stops cleanly
