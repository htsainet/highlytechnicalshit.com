$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/flowise'
    $script:ComponentScript = Join-Path $script:ComponentDir 'flowise.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'flowise.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'flowise file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'flowise manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is flowise' {
        $script:Manifest.id | Should -Be 'flowise'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/flowise/flowise.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is flowise' {
        $script:Manifest.func_prefix | Should -Be 'flowise'
    }

    It 'dashboard port is 3005' {
        [int]$script:Manifest.dashboard.port | Should -Be 3005
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'flowise component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines flowise_install function' {
        $script:ComponentContent | Should -Match 'flowise_install\s*\(\)'
    }

    It 'defines flowise_configure function' {
        $script:ComponentContent | Should -Match 'flowise_configure\s*\(\)'
    }

    It 'defines flowise_start function' {
        $script:ComponentContent | Should -Match 'flowise_start\s*\(\)'
    }

    It 'defines flowise_stop function' {
        $script:ComponentContent | Should -Match 'flowise_stop\s*\(\)'
    }

    It 'defines flowise_health function' {
        $script:ComponentContent | Should -Match 'flowise_health\s*\(\)'
    }

    It 'supports --start, --stop, and --health CLI flags' {
        $script:ComponentContent | Should -Match '--start\)'
        $script:ComponentContent | Should -Match '--stop\)'
        $script:ComponentContent | Should -Match '--health\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/flowise/flowise\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'flowise port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 3005 is registered in portmap.json' {
        $script:Portmap.ports.'3005' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'3005'.service | Should -Be 'flowise'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'flowise no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/flowise\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/flowise/flowise\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
