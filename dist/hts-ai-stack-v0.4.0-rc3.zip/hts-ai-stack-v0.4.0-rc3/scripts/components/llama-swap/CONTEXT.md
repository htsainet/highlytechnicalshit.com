# llama-swap Component

Last updated: 2026-04-15

## What happens here

llama-swap is a lightweight model router/proxy that sits in front of
Ollama, enabling automatic model swapping and load balancing across
multiple model backends.

## Files and structure

| File | Purpose |
|------|---------|
| `llama-swap.sh` | Full lifecycle: install, configure, start, stop, health |
| `llama-swap.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
