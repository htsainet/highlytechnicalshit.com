#!/usr/bin/env bash
# scripts/components/ubuntu-audio/ubuntu-audio.sh — Ubuntu Studio Audio: install, configure, health
#
# Host-native installer for the Ubuntu Studio audio stack: JACK2, PulseAudio-JACK
# bridge, low-latency kernel, and curated audio plugins. Configures the realtime
# audio group and PAM limits required for pro-audio work.
#
# Standalone usage:
#   ./scripts/components/ubuntu-audio/ubuntu-audio.sh              # full: install + configure + health
#   ./scripts/components/ubuntu-audio/ubuntu-audio.sh --install    # install only
#   ./scripts/components/ubuntu-audio/ubuntu-audio.sh --configure  # configure only (realtime group)
#   ./scripts/components/ubuntu-audio/ubuntu-audio.sh --start      # no-op (host packages)
#   ./scripts/components/ubuntu-audio/ubuntu-audio.sh --stop       # no-op (host packages)
#   ./scripts/components/ubuntu-audio/ubuntu-audio.sh --restart    # no-op (host packages)
#   ./scripts/components/ubuntu-audio/ubuntu-audio.sh --health     # health check only
#   ./scripts/components/ubuntu-audio/ubuntu-audio.sh --status     # show status + health
#   ./scripts/components/ubuntu-audio/ubuntu-audio.sh --destroy    # uninstall packages
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native system package set, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# Core packages from Ubuntu Studio audio meta-package
UBUNTU_AUDIO_PACKAGES=(
  jackd2
  pulseaudio-module-jack
  qjackctl
  a2jmidid
  linux-lowlatency
  ubuntustudio-audio-plugins
)

# ── Functions ────────────────────────────────────────────────────────────────

ubuntu_audio_install() {
  step "Ubuntu Studio Audio — install"

  local missing=()
  for pkg in "${UBUNTU_AUDIO_PACKAGES[@]}"; do
    if ! dpkg -s "$pkg" &>/dev/null; then
      missing+=("$pkg")
    fi
  done

  if [[ ${#missing[@]} -eq 0 ]]; then
    skip "All Ubuntu Studio audio packages already installed."
  else
    info "Installing: ${missing[*]}"
    sudo apt-get update -qq
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "${missing[@]}"
    ok "Ubuntu Studio audio packages installed."
  fi
}

ubuntu_audio_configure() {
  step "Ubuntu Studio Audio — configure"

  # Add current user to the audio group for realtime scheduling
  if id -nG "$USER" | grep -qw audio; then
    skip "User '$USER' already in audio group."
  else
    info "Adding '$USER' to audio group for realtime scheduling..."
    sudo usermod -aG audio "$USER"
    ok "User added to audio group (re-login required)."
  fi

  # Ensure PAM limits for realtime audio
  local limits_file="/etc/security/limits.d/audio.conf"
  if [[ -f "$limits_file" ]]; then
    skip "Realtime audio PAM limits already configured."
  else
    info "Configuring realtime audio PAM limits..."
    sudo tee "$limits_file" > /dev/null <<'EOF'
@audio   -  rtprio     95
@audio   -  memlock    unlimited
EOF
    ok "PAM limits configured at $limits_file."
  fi

  ok "Ubuntu Studio Audio configured."
}

ubuntu_audio_start() {
  step "Ubuntu Studio Audio — start"
  info "Host packages — no service to start. Use qjackctl to manage JACK."
  ok "Ubuntu Studio Audio start complete."
}

ubuntu_audio_stop() {
  step "Ubuntu Studio Audio — stop"
  info "Host packages — no service to stop."
  ok "Ubuntu Studio Audio stop complete."
}

ubuntu_audio_health() {
  local label="Ubuntu Studio Audio"
  printf "  %-35s" "$label"
  if dpkg -s jackd2 &>/dev/null && dpkg -s qjackctl &>/dev/null; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (jackd2 or qjackctl not installed)"
    return 1
  fi
}

ubuntu_audio_restart() {
  ubuntu_audio_stop
  ubuntu_audio_start
}

ubuntu_audio_destroy() {
  step "Ubuntu Studio Audio — destroy"
  info "Removing Ubuntu Studio audio packages..."
  sudo apt-get remove -y "${UBUNTU_AUDIO_PACKAGES[@]}" 2>/dev/null || true
  sudo apt-get autoremove -y -qq
  ok "Ubuntu Studio Audio packages removed."
}

ubuntu_audio_status() {
  step "Ubuntu Studio Audio — status"
  local installed=0
  for pkg in "${UBUNTU_AUDIO_PACKAGES[@]}"; do
    if dpkg -s "$pkg" &>/dev/null; then
      ok "$pkg installed"
      ((installed++))
    else
      warn "$pkg NOT installed"
    fi
  done
  info "$installed/${#UBUNTU_AUDIO_PACKAGES[@]} packages installed."
  ubuntu_audio_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   ubuntu_audio_install   ;;
    configure) ubuntu_audio_configure ;;
    start)     ubuntu_audio_start     ;;
    stop)      ubuntu_audio_stop      ;;
    restart)   ubuntu_audio_restart   ;;
    health)    ubuntu_audio_health    ;;
    status)    ubuntu_audio_status    ;;
    destroy)   ubuntu_audio_destroy   ;;
    default)
      ubuntu_audio_install
      ubuntu_audio_configure
      ubuntu_audio_health
      ;;
  esac
fi
