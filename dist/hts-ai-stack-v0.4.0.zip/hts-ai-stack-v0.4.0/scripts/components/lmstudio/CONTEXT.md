# LM Studio Component

Last updated: 2026-04-15

## What happens here

LM Studio is a desktop application for running local LLMs with a GUI
and OpenAI-compatible API server. Installed as a host-native `.deb`
package (not Docker). Used in the stack as an alternative inference
engine to Ollama.

## Files and structure

| File | Purpose |
|------|---------|
| `lmstudio.sh` | Full lifecycle: install, configure, start, stop, health |
| `lmstudio.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

See [usage.md](./usage.md) for command usage.
