$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/comfyui'
    $script:ComponentScript = Join-Path $script:ComponentDir 'comfyui.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'comfyui.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'comfyui file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'comfyui manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is comfyui' {
        $script:Manifest.id | Should -Be 'comfyui'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/comfyui/comfyui.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is comfyui' {
        $script:Manifest.func_prefix | Should -Be 'comfyui'
    }

    It 'dashboard port is 8188' {
        [int]$script:Manifest.dashboard.port | Should -Be 8188
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'comfyui component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines comfyui_install function' {
        $script:ComponentContent | Should -Match 'comfyui_install\s*\(\)'
    }

    It 'defines comfyui_configure function' {
        $script:ComponentContent | Should -Match 'comfyui_configure\s*\(\)'
    }

    It 'defines comfyui_start function' {
        $script:ComponentContent | Should -Match 'comfyui_start\s*\(\)'
    }

    It 'defines comfyui_stop function' {
        $script:ComponentContent | Should -Match 'comfyui_stop\s*\(\)'
    }

    It 'defines comfyui_health function' {
        $script:ComponentContent | Should -Match 'comfyui_health\s*\(\)'
    }

    It 'defines comfyui_seed_models function' {
        $script:ComponentContent | Should -Match 'comfyui_seed_models\s*\(\)'
    }

    It 'supports --seed-models, --health, and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--seed-models\)'
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/comfyui/comfyui\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'comfyui port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8188 is registered in portmap.json' {
        $script:Portmap.ports.'8188' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'8188'.service | Should -Be 'comfyui'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'comfyui no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/comfyui\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/comfyui/comfyui\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}

# ── Model download guard ────────────────────────────────────────────────────

Describe 'comfyui model download guard' {
    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'download function checks if file already exists' {
        $script:ComponentContent | Should -Match '-f "\$dest"'
    }

    It 'download function checks file size threshold' {
        $script:ComponentContent | Should -Match '1000000'
    }
}
