# KXStudio Component

Last updated: 2026-04-17

## What happens here

KXStudio provides professional audio tools distributed via a dedicated PPA.
Key tools include Cadence (JACK session management), Catia (JACK patchbay),
and Carla (advanced plugin host supporting LV2, VST2, VST3, LADSPA, DSSI).

## Files and structure

| File | Purpose |
|------|---------|
| `kxstudio.sh` | Full lifecycle: install, configure, start, stop, health |
| `kxstudio.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- Host-native packages — no Docker container or web UI
- Installs the KXStudio PPA for access to the full tool suite
- Cadence replaces QjackCtl with a more integrated JACK management experience
- Carla is a powerful plugin host that can load and chain audio effects
