#!/usr/bin/env bash
# install-comfyui.sh — Pull ComfyUI images for all instance stacks
#
# ComfyUI runs as a Docker service in each instance compose file.
# This script pulls the latest images and prints access URLs.
#
# Ports:
#   prod  → http://<host>:8188
#   test  → http://<host>:8189

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

# ── Step 1: Pull images ───────────────────────────────────────────────────────
step "1 — Pull ComfyUI images"

for instance in prod test; do
  compose_file="$REPO_ROOT/instances/$instance/docker-compose.yml"
  if [ ! -f "$compose_file" ]; then
    warn "Compose file not found: $compose_file — skipping $instance"
    continue
  fi
  info "Pulling comfyui-$instance..."
  docker compose -f "$compose_file" pull "comfyui-$instance"
done

info "All ComfyUI images pulled."

# ── Step 2: Print access info ─────────────────────────────────────────────────
step "2 — Access URLs"

HOST_IP="$(hostname -I | awk '{print $1}')"
echo ""
info "To start ComfyUI, bring up the relevant instance compose:"
echo ""
echo "    cd $REPO_ROOT"
echo "    docker compose -f instances/prod/docker-compose.yml up -d comfyui-prod"
echo "    docker compose -f instances/test/docker-compose.yml up -d comfyui-test"
echo ""
info "Access URLs (once running):"
echo "    prod → http://$HOST_IP:8188"
echo "    test → http://$HOST_IP:8189"
echo ""
info "Volumes (models persist across restarts):"
echo "    comfyui_models_prod / comfyui_models_test"
echo "    Mounted at: /opt/ComfyUI/models"
