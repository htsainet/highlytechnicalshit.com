# Open-Sora Component

Last updated: 2026-04-17

## What happens here

Open-Sora is HPC-AI Tech's open-source text-to-video generation framework.
Produces high-quality video from text prompts using diffusion transformers.
Runs as a Dockerised Gradio web app on port 7862.

## Files and structure

| File | Purpose |
|------|---------|
| `open-sora.sh` | Full lifecycle: install, configure, start, stop, health |
| `open-sora.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- **⚠️ Requires ≥24GB VRAM** — RTX 4090 or better
- Install script includes VRAM gate; gracefully skips on insufficient hardware
- `vram_min_gb: 24` in manifest for future convergence VRAM checker integration
- Currently disqualified on RTX 3060 (12GB) — wired up for future GPU upgrades
- v1.3 (1B params): ~24GB VRAM minimum
- v2.0 (11B params): 45–60GB VRAM (H100/A100 class)
- MIT license

See [usage.md](./usage.md) for command usage.
