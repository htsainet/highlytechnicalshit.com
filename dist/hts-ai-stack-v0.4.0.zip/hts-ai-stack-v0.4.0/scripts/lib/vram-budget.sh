#!/usr/bin/env bash
# scripts/lib/vram-budget.sh — VRAM budget calculator
# Source this file; do NOT run directly.
#
# Functions:
#   vram_budget_check <gpu_mb> <vram1> [vram2 ...]
#     Returns: tier|sum_mb|max_mb|gpu_mb
#     Tiers:
#       concurrent — all selected models fit simultaneously
#       swappable  — each model fits alone, but not all at once
#       too_large  — at least one model exceeds the GPU
#       no_gpu     — no GPU detected (gpu_mb == 0)
#
#   vram_format <mb>
#     Returns human-readable string: "4.0 GB" / "500 MB" / "0 MB"
#
#   download_format <mb>
#     Returns human-readable string: "12.5 GB" / "800 MB" / "0 MB"

# vram_budget_check <gpu_mb> <vram1> [vram2 ...]
vram_budget_check() {
  local gpu_mb=$1; shift
  local sum_mb=0
  local max_mb=0

  for vram in "$@"; do
    (( sum_mb += vram ))
    if (( vram > max_mb )); then
      max_mb=$vram
    fi
  done

  local tier
  if (( gpu_mb == 0 )); then
    tier="no_gpu"
  elif (( max_mb > gpu_mb )); then
    tier="too_large"
  elif (( sum_mb > gpu_mb )); then
    tier="swappable"
  else
    tier="concurrent"
  fi

  echo "${tier}|${sum_mb}|${max_mb}|${gpu_mb}"
}

# vram_format <mb>
# Converts MiB to a human-readable string.
vram_format() {
  local mb=$1
  if (( mb == 0 )); then
    echo "0 MB"
  elif (( mb >= 1024 )); then
    python3 -c "print(f'{$mb / 1024:.1f} GB')"
  else
    echo "${mb} MB"
  fi
}

# download_format <mb>
# Converts MiB to a human-readable download size string.
download_format() {
  local mb=$1
  if (( mb == 0 )); then
    echo "0 MB"
  elif (( mb >= 1024 )); then
    python3 -c "print(f'{$mb / 1024:.1f} GB')"
  else
    echo "${mb} MB"
  fi
}
