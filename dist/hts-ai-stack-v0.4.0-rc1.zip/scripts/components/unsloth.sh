#!/usr/bin/env bash
# scripts/components/unsloth.sh — Unsloth LLM fine-tuning & training studio
#
# Standalone usage:
#   ./scripts/components/unsloth.sh            # install + configure + start + health
#   ./scripts/components/unsloth.sh --health   # health check only
#   ./scripts/components/unsloth.sh --stop     # stop Unsloth
#
# Can also be sourced by bundle scripts for individual function access.
#
# Ref: https://github.com/unslothai/unsloth
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
UNSLOTH_CONTAINER="${UNSLOTH_CONTAINER:-hts-ai-unsloth}"
UNSLOTH_PORT="${UNSLOTH_PORT:-8888}"
UNSLOTH_API_PORT="${UNSLOTH_API_PORT:-8000}"

# ── Functions ────────────────────────────────────────────────────────────────

# unsloth_install — Pull the Unsloth Docker image
unsloth_install() {
  step "Unsloth — install"
  compose_pull --profile unsloth
  ok "Unsloth image pulled."
}

# unsloth_configure — Ensure .env has Unsloth settings
unsloth_configure() {
  step "Unsloth — configure"
  local env_file="$REPO_DIR/.env"

  _ensure() {
    local key="$1" default="$2"
    if ! grep -q "^${key}=" "$env_file" 2>/dev/null; then
      printf '%s=%s\n' "$key" "$default" >> "$env_file"
      info "Added ${key}=${default} to .env"
    fi
  }

  _ensure "UNSLOTH_PORT" "$UNSLOTH_PORT"
  _ensure "UNSLOTH_API_PORT" "$UNSLOTH_API_PORT"
  _ensure "UNSLOTH_PASSWORD" "changeme"

  ok "Unsloth configured (studio :${UNSLOTH_PORT}, api :${UNSLOTH_API_PORT})."
  warn "Change UNSLOTH_PASSWORD in .env before exposing to the network."
}

# unsloth_start — Bring up Unsloth via compose
unsloth_start() {
  step "Unsloth — start"
  compose_up --profile unsloth
  ok "Unsloth started (studio :${UNSLOTH_PORT}, api :${UNSLOTH_API_PORT})."
}

# unsloth_stop — Bring down Unsloth
unsloth_stop() {
  step "Unsloth — stop"
  compose_down --profile unsloth
  ok "Unsloth stopped."
}

# unsloth_health — Probe the Unsloth Studio UI
unsloth_health() {
  health_probe "Unsloth :${UNSLOTH_PORT}" "http://localhost:${UNSLOTH_PORT}/"
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      unsloth_install
      unsloth_configure
      unsloth_start
      unsloth_health
      ;;
    health)
      unsloth_health
      ;;
    stop)
      unsloth_stop
      ;;
  esac
fi
