#!/usr/bin/env bash
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already configured"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; exit 1; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

# ── Step 1: Read / prompt for bot token ───────────────────────────────────────
step "1 — Bot token"

ENV_FILE=".env"
[ -f "$ENV_FILE" ] || fail ".env not found — run ./02-setup-docker.sh first."

TELEGRAM_BOT_TOKEN=$(grep '^TELEGRAM_BOT_TOKEN=' "$ENV_FILE" | cut -d= -f2- | tr -d '[:space:]' || true)

if [ -z "$TELEGRAM_BOT_TOKEN" ]; then
  echo ""
  warn "TELEGRAM_BOT_TOKEN not found in .env."
  echo "  Create a bot via @BotFather on Telegram (/newbot), then paste the token."
  read -r -p "  Bot token: " TELEGRAM_BOT_TOKEN
  [ -n "$TELEGRAM_BOT_TOKEN" ] || fail "No token provided."
  echo "TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}" >> "$ENV_FILE"
  info "Token saved to .env."
else
  info "TELEGRAM_BOT_TOKEN: ${TELEGRAM_BOT_TOKEN:0:10}..."
fi

# ── Step 2: Validate token with Telegram ──────────────────────────────────────
step "2 — Validate token"

BOT_INFO=$(curl -sf "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe" || true)
echo "$BOT_INFO" | grep -q '"ok":true' \
  || fail "Token rejected by Telegram — check TELEGRAM_BOT_TOKEN in .env."

BOT_NAME=$(echo "$BOT_INFO" | grep -o '"username":"[^"]*"' | cut -d'"' -f4)
info "Bot verified: @${BOT_NAME}"

# ── Step 3: Patch openclaw.json via docker exec ───────────────────────────────
step "3 — Configure OpenClaw"

if ! docker ps --format '{{.Names}}' | grep -qw openclaw; then
  fail "OpenClaw is not running — start the stack first: docker compose up -d"
fi

# Use node (already in the container) to patch the JSON in-place
docker exec -e TELEGRAM_BOT_TOKEN="$TELEGRAM_BOT_TOKEN" openclaw \
  node -e "
    const fs = require('fs');
    const path = '/home/node/.openclaw/openclaw.json';
    const cfg = JSON.parse(fs.readFileSync(path, 'utf8'));
    cfg.channels = cfg.channels || {};
    cfg.channels.telegram = Object.assign(cfg.channels.telegram || {}, {
      enabled: true,
      botToken: process.env.TELEGRAM_BOT_TOKEN,
    });
    fs.writeFileSync(path, JSON.stringify(cfg, null, 2));
    console.log('openclaw.json updated.');
  "

# ── Step 4: Restart OpenClaw to pick up new config ───────────────────────────
step "4 — Restart OpenClaw"

info "Restarting openclaw container..."
docker compose restart openclaw

echo ""
info "Done. OpenClaw is now handling Telegram via @${BOT_NAME}."
info "Logs: docker compose logs -f openclaw"
