$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:HelpersPath = Join-Path $script:RepoRoot 'scripts/install/models/helpers.sh'
}

function global:Invoke-ModelHelpersProbe {
    param(
        [Parameter(Mandatory)]
        [bool]$CreateEnvFile
    )

    $runId = [Guid]::NewGuid().ToString('N')
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) "model-helpers-test-$runId"
    $repoRoot = Join-Path $tempRoot 'repo'
    $helpersDir = Join-Path $repoRoot 'scripts/install/models'
    $helpersCopy = Join-Path $helpersDir 'helpers.sh'
    $probeScript = Join-Path $tempRoot 'probe.sh'
    $probeOutput = Join-Path $tempRoot 'probe.log'

    New-Item -ItemType Directory -Path $helpersDir -Force | Out-Null
    Copy-Item -Path $script:HelpersPath -Destination $helpersCopy -Force

    if ($CreateEnvFile) {
        Set-Content -Path (Join-Path $repoRoot '.env') -Value "OPENCLAW_TOKEN=test-token`nWEBUI_SECRET_KEY=test-key`n" -NoNewline
    }

    $probeScriptContent = @'
#!/usr/bin/env bash
set -euo pipefail
source "$1"
echo "REPO_ROOT=$REPO_ROOT"
echo "ENV_FILE=$ENV_FILE"
'@

    Set-Content -Path $probeScript -Value $probeScriptContent -NoNewline
    & bash -c "chmod +x '$probeScript'"

    & bash "$probeScript" "$helpersCopy" *> $probeOutput
    $exitCode = $LASTEXITCODE

    [PSCustomObject]@{
        ExitCode = $exitCode
        Output = if (Test-Path $probeOutput) { Get-Content -Path $probeOutput -Raw } else { '' }
        RepoRoot = $repoRoot
        TempRoot = $tempRoot
    }
}

Describe 'Model helpers path resolution' {
    It 'resolves REPO_ROOT and ENV_FILE to repo root when .env exists' {
        $result = Invoke-ModelHelpersProbe -CreateEnvFile $true
        try {
            $result.ExitCode | Should -Be 0
            $result.Output | Should -Match ([regex]::Escape("REPO_ROOT=$($result.RepoRoot)"))
            $result.Output | Should -Match ([regex]::Escape("ENV_FILE=$($result.RepoRoot)/.env"))
        }
        finally {
            if (Test-Path $result.TempRoot) {
                Remove-Item -Path $result.TempRoot -Recurse -Force
            }
        }
    }

    It 'fails with repo-root .env path when .env is missing' {
        $result = Invoke-ModelHelpersProbe -CreateEnvFile $false
        try {
            $result.ExitCode | Should -Not -Be 0
            $result.Output | Should -Match ([regex]::Escape(".env not found at $($result.RepoRoot)/.env"))
            $result.Output | Should -Not -Match ([regex]::Escape("$($result.RepoRoot)/scripts/.env"))
        }
        finally {
            if (Test-Path $result.TempRoot) {
                Remove-Item -Path $result.TempRoot -Recurse -Force
            }
        }
    }
}