"""AnimateDiff — Gradio web UI for text-to-animation generation."""

import os
import torch
import gradio as gr
import imageio

SD_MODEL = os.environ.get("ANIMATEDIFF_SD_MODEL", "runwayml/stable-diffusion-v1-5")
MOTION_ADAPTER = os.environ.get(
    "ANIMATEDIFF_MOTION_ADAPTER", "guoyww/animatediff-motion-adapter-v1-5-3"
)
PORT = int(os.environ.get("ANIMATEDIFF_PORT", "8603"))

pipe = None


def load_pipeline():
    global pipe
    if pipe is None:
        from diffusers import AnimateDiffPipeline, MotionAdapter, DDIMScheduler

        adapter = MotionAdapter.from_pretrained(
            MOTION_ADAPTER, torch_dtype=torch.float16
        )
        pipe = AnimateDiffPipeline.from_pretrained(
            SD_MODEL, motion_adapter=adapter, torch_dtype=torch.float16
        ).to("cuda")
        pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config)
        pipe.enable_model_cpu_offload()
    return pipe


def generate_animation(
    prompt: str,
    negative_prompt: str = "low quality, blurry",
    num_frames: int = 16,
    guidance_scale: float = 7.5,
    num_inference_steps: int = 25,
):
    """Generate an animation from a text description."""
    p = load_pipeline()

    output = p(
        prompt=prompt,
        negative_prompt=negative_prompt,
        num_frames=min(num_frames, 32),
        guidance_scale=guidance_scale,
        num_inference_steps=num_inference_steps,
    )

    frames = output.frames[0]
    output_path = "/tmp/animatediff_output.gif"
    imageio.mimsave(output_path, frames, duration=100, loop=0)
    return output_path


with gr.Blocks(title="AnimateDiff") as app:
    gr.Markdown("# 🎞️ AnimateDiff")
    gr.Markdown(
        f"Text-to-animation powered by **{SD_MODEL}** + **{MOTION_ADAPTER}**"
    )

    prompt_input = gr.Textbox(
        label="Describe the animation you want",
        placeholder="e.g., A cat walking across a sunlit windowsill, cinematic lighting",
    )
    neg_prompt_input = gr.Textbox(
        label="Negative prompt",
        value="low quality, blurry, distorted",
    )
    with gr.Row():
        frames_input = gr.Slider(
            minimum=8, maximum=32, value=16, step=4, label="Frames"
        )
        guidance_input = gr.Slider(
            minimum=1.0, maximum=20.0, value=7.5, step=0.5, label="Guidance Scale"
        )
        steps_input = gr.Slider(
            minimum=10, maximum=50, value=25, step=5, label="Inference Steps"
        )
    generate_btn = gr.Button("Generate Animation", variant="primary")
    animation_output = gr.Image(label="Generated Animation", type="filepath")
    generate_btn.click(
        generate_animation,
        inputs=[prompt_input, neg_prompt_input, frames_input, guidance_input, steps_input],
        outputs=animation_output,
    )

if __name__ == "__main__":
    app.launch(server_name="0.0.0.0", server_port=PORT)
