#!/usr/bin/env bash
# scripts/utils/audit-models.sh — Audit all pulled Ollama models
#
# Checks:
#   1. HuggingFace security scan status (safe / unsafe / pending / unknown)
#   2. Publisher reputation (downloads, likes, verified org)
#   3. Local ClamAV scan (if clamav is installed)
#
# Usage:
#   ./scripts/utils/audit-models.sh              # audit all models
#   ./scripts/utils/audit-models.sh --json       # JSON output (for Open WebUI)
#   ./scripts/utils/audit-models.sh --no-clam    # skip ClamAV scan
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ── Flags ────────────────────────────────────────────────────────────────────
JSON_OUT=false
SKIP_CLAM=false
OLLAMA_CONTAINER="${OLLAMA_CONTAINER:-hts-ai-ollama}"
OLLAMA_URL="${OLLAMA_URL:-http://localhost:11434}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --json)     JSON_OUT=true;  shift ;;
    --no-clam)  SKIP_CLAM=true; shift ;;
    *) echo "Unknown flag: $1"; exit 1 ;;
  esac
done

HAS_CLAM=false
if [[ "$SKIP_CLAM" == "false" ]] && command -v clamscan &>/dev/null; then
  HAS_CLAM=true
fi

# ── Helpers ──────────────────────────────────────────────────────────────────

# Map Ollama model name → HuggingFace repo ID
# Input:  hf.co/user/repo-name:quant
# Output: user/repo-name
_to_hf_repo() {
  local name="$1"
  # Strip hf.co/ prefix and :tag suffix
  name="${name#hf.co/}"
  name="${name%%:*}"
  echo "$name"
}

# Query HuggingFace API for model security + reputation
_check_hf() {
  local repo="$1"
  local api_url="https://huggingface.co/api/models/${repo}"
  local response
  response=$(curl -sf --max-time 10 "$api_url" 2>/dev/null) || { echo "UNAVAILABLE|||0|0|false"; return; }

  local security siblings downloads likes pipeline_tag author
  # Security scan status from siblings (files)
  security=$(echo "$response" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    # Check for security scan results in safetensors/gguf metadata
    tags = d.get('tags', [])
    # HF marks repos with 'unsafe' or has securityStatus field
    sec = d.get('securityStatus', {})
    status = sec.get('status', 'unknown') if sec else 'unknown'
    # Also check if cardData has any security warnings
    card = d.get('cardData', {}) or {}
    if 'unsafe' in str(tags).lower():
        status = 'unsafe'
    elif status == 'unknown':
        # If no explicit status, check if files passed scan
        siblings = d.get('siblings', [])
        has_files = len(siblings) > 0
        status = 'no-scan-data' if has_files else 'empty-repo'
    print(status)
except Exception:
    print('error')
" 2>/dev/null || echo "error")

  downloads=$(echo "$response" | python3 -c "
import sys, json
try: print(json.load(sys.stdin).get('downloads', 0))
except: print(0)
" 2>/dev/null || echo "0")

  likes=$(echo "$response" | python3 -c "
import sys, json
try: print(json.load(sys.stdin).get('likes', 0))
except: print(0)
" 2>/dev/null || echo "0")

  author=$(echo "$response" | python3 -c "
import sys, json
try: print(json.load(sys.stdin).get('author', 'unknown'))
except: print('unknown')
" 2>/dev/null || echo "unknown")

  echo "${security}|${author}|${downloads}|${likes}"
}

# Find the blob path for a model (Ollama stores in /home/ollama/.ollama/models/)
_find_model_blobs() {
  local model_name="$1"
  # Query ollama show to get the digest, then find the blob
  local manifest_info
  manifest_info=$(curl -sf --max-time 5 "${OLLAMA_URL}/api/show" \
    -d "{\"name\": \"${model_name}\"}" 2>/dev/null) || return
  
  # Extract model layer digests
  echo "$manifest_info" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    for layer in d.get('details', {}).get('families', []):
        pass
    # Get the modelfile to find blob hash
    mf = d.get('modelfile', '')
    print(mf[:200] if mf else '')
except: pass
" 2>/dev/null
}

# ── Main ─────────────────────────────────────────────────────────────────────

# Get model list from Ollama API
models_json=$(curl -sf --max-time 10 "${OLLAMA_URL}/api/tags" 2>/dev/null) || {
  echo "ERROR: Cannot reach Ollama at ${OLLAMA_URL}" >&2
  exit 1
}

model_names=$(echo "$models_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for m in data.get('models', []):
    print(m['name'])
" 2>/dev/null)

if [[ -z "$model_names" ]]; then
  echo "No models found."
  exit 0
fi

model_count=$(echo "$model_names" | wc -l)

# ── JSON output mode ─────────────────────────────────────────────────────────
if [[ "$JSON_OUT" == "true" ]]; then
  echo "["
  first=true
  while IFS= read -r model; do
    [[ -z "$model" ]] && continue
    
    hf_repo=$(_to_hf_repo "$model")
    hf_result=$(_check_hf "$hf_repo")
    IFS='|' read -r security author downloads likes <<< "$hf_result"
    
    clam_status="skipped"
    
    [[ "$first" == "true" ]] && first=false || echo ","
    cat <<ENTRY
  {
    "model": $(python3 -c "import json; print(json.dumps('$model'))"),
    "hf_repo": $(python3 -c "import json; print(json.dumps('$hf_repo'))"),
    "security_scan": $(python3 -c "import json; print(json.dumps('$security'))"),
    "author": $(python3 -c "import json; print(json.dumps('$author'))"),
    "downloads": ${downloads:-0},
    "likes": ${likes:-0},
    "clamav": $(python3 -c "import json; print(json.dumps('$clam_status'))")
  }
ENTRY
  done <<< "$model_names"
  echo ""
  echo "]"
  exit 0
fi

# ── Table output mode ────────────────────────────────────────────────────────
printf "\n  🔍 Auditing %d models...\n\n" "$model_count"
printf "  %-55s %-14s %-12s %-10s %s\n" "MODEL" "SECURITY" "DOWNLOADS" "LIKES" "AUTHOR"
printf "  %-55s %-14s %-12s %-10s %s\n" "-----" "--------" "---------" "-----" "------"

pass=0 warn=0 fail=0

while IFS= read -r model; do
  set +e  # arithmetic (( 0++ )) returns 1, don't die on it
  [[ -z "$model" ]] && continue
  
  # Extract short display name (last 50 chars)
  display="${model}"
  if [[ ${#display} -gt 52 ]]; then
    display="...${display: -49}"
  fi
  
  hf_repo=$(_to_hf_repo "$model")
  hf_result=$(_check_hf "$hf_repo")
  IFS='|' read -r security author downloads likes <<< "$hf_result"
  
  # Color-code security status
  case "$security" in
    safe|no-scan-data)
      icon="✅"; ((pass++)) ;;
    unsafe)
      icon="❌"; ((fail++)) ;;
    UNAVAILABLE|error|empty-repo)
      icon="⚠️ "; ((warn++)) ;;
    *)
      icon="❓"; ((warn++)) ;;
  esac
  
  # Format downloads
  dl_fmt="$downloads"
  if [[ "$downloads" -ge 1000000 ]]; then
    dl_fmt="$(( downloads / 1000000 ))M"
  elif [[ "$downloads" -ge 1000 ]]; then
    dl_fmt="$(( downloads / 1000 ))K"
  fi
  
  printf "  %-55s %s %-12s %-12s %-10s %s\n" "$display" "$icon" "$security" "$dl_fmt" "$likes" "$author"
  set -e
done <<< "$model_names"

printf "\n  ─────────────────────────────────────────────────\n"
printf "  ✅ %d passed   ⚠️  %d warnings   ❌ %d failed\n" "$pass" "$warn" "$fail"

if [[ "$HAS_CLAM" == "true" ]]; then
  printf "\n  🦠 ClamAV: installed (run with host volume access to scan blobs)\n"
else
  printf "\n  🦠 ClamAV: not installed (sudo apt install clamav for local scanning)\n"
fi

printf "\n"
