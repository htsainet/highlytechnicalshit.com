#!/usr/bin/env bash
# Gitea Actions Runner – CI/CD for Gitea (Docker)
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# shellcheck source=scripts/lib/common.sh
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=scripts/lib/health.sh
source "$REPO_DIR/scripts/lib/health.sh"
# shellcheck source=scripts/lib/compose.sh
source "$REPO_DIR/scripts/lib/compose.sh"

GITEA_RUNNER_CONTAINER="${GITEA_RUNNER_CONTAINER:-hts-ai-gitea-runner}"

###############################################################################
# Lifecycle
###############################################################################

gitea_runner_install() {
  log_info "Building Gitea Runner image …"
  compose_build --profile gitea-runner
  log_ok "Gitea Runner image ready"
}

gitea_runner_configure() {
  log_info "Configuring Gitea Actions Runner …"

  local token=""
  if [[ -f "$REPO_DIR/.env" ]]; then
    token="$(grep '^GITEA_RUNNER_TOKEN=' "$REPO_DIR/.env" 2>/dev/null \
             | cut -d= -f2- || true)"
  fi

  if [[ -z "$token" ]]; then
    log_warn "─────────────────────────────────────────────────────────"
    log_warn "Gitea Actions Runner requires a registration token."
    log_warn ""
    log_warn "  1. Open Gitea at http://localhost:3030"
    log_warn "  2. Go to Site Administration → Actions → Runners"
    log_warn "  3. Click 'Create new Runner' and copy the token"
    log_warn "  4. Add to .env:  GITEA_RUNNER_TOKEN=<your-token>"
    log_warn "─────────────────────────────────────────────────────────"
    return 1
  fi

  log_ok "Gitea Runner token found — runner will register on start"
}

gitea_runner_start() {
  log_info "Starting Gitea Actions Runner …"
  compose_up --profile gitea-runner
  log_ok "Gitea Runner started — check Gitea UI for runner status"
}

gitea_runner_stop() {
  log_info "Stopping Gitea Actions Runner …"
  compose_down --profile gitea-runner
  log_ok "Gitea Runner stopped"
}

gitea_runner_restart() {
  gitea_runner_stop
  gitea_runner_start
}

gitea_runner_health() {
  if docker ps --format '{{.Names}}' 2>/dev/null \
       | grep -q "^${GITEA_RUNNER_CONTAINER}$"; then
    log_ok "Gitea Runner container is running"
    return 0
  fi
  log_warn "Gitea Runner container not running"
  return 1
}

gitea_runner_destroy() {
  log_info "Destroying Gitea Runner (removing volumes) …"
  compose_down --profile gitea-runner -v
  log_ok "Gitea Runner destroyed"
}

gitea_runner_status() {
  if docker ps --format '{{.Names}}' 2>/dev/null \
       | grep -q "^${GITEA_RUNNER_CONTAINER}$"; then
    echo "running"
  else
    echo "stopped"
  fi
}
