#!/usr/bin/env bash
# scripts/bundles/openspace.sh — OpenSpace + MCP + Git bundle
#
# Extends the NemoClaw bundle with OpenSpace (MCP dev environment) and Gitea.
#
# Usage:
#   ./scripts/bundles/openspace.sh [--chat mean|claw]
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "OpenSpace Bundle"
load_env

CHAT_MODE="mean"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --chat) CHAT_MODE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-false}"

# ── Backend (dual-backend + llama-swap) ────────────────────────────────────────
step "Backend"
bash "$REPO_DIR/scripts/components/ollama.sh" --swap "$CHAT_MODE"
bash "$REPO_DIR/scripts/components/bitnet.sh"
bash "$REPO_DIR/scripts/components/llama-swap.sh"

step "NemoClaw"
bash "$REPO_DIR/scripts/components/nemoclaw.sh"

# ── OpenSpace + Gitea ─────────────────────────────────────────────────────────
step "OpenSpace + Gitea"
bash "$REPO_DIR/scripts/components/openspace.sh"
bash "$REPO_DIR/scripts/components/gitea.sh"

if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/components/dashboard.sh"
fi

echo ""
ok "OpenSpace bundle ready — dual-backend (GPU+CPU) chat:${CHAT_MODE}"
