#!/usr/bin/env bash
# scripts/lint/check-banned-shell-idioms.sh
#
# Pre-commit / CI lint: blocks newly-added lines that use banned bash idioms.
#
# Banned token this hook enforces:
#   sed  - never use, for anything (regex find-and-replace is guesswork)
#
# NOT enforced by this hook (rule exists in CLAUDE.md / CONTEXT.md, but the
# bite-history in this repo is 100% sed-regex; the others are documented
# discipline + code review):
#   cat > / cat >> file  - prefer edit/create tools, but heredocs are deterministic
#   awk                  - banned only when redirecting to a file
#   tee                  - banned only when writing to real files
#
# Existing legacy uses are GRANDFATHERED: this hook only inspects ADDED lines
# (lines starting with '+' in the unified diff), not entire files. Touching a
# legacy file is safe; introducing a NEW violation in any file is blocked.
#
# Escape hatch (use sparingly, must justify in the comment):
#   some_command  # allow-banned-idiom: <reason>
#
# Modes:
#   * Local pre-commit:   no env vars set -> uses 'git diff --cached'
#   * CI via pre-commit/action: PRE_COMMIT_FROM_REF / PRE_COMMIT_TO_REF set
#   * Manual:             $1 = from-ref, $2 = to-ref

set -euo pipefail

from_ref="${PRE_COMMIT_FROM_REF:-${1:-}}"
to_ref="${PRE_COMMIT_TO_REF:-${2:-}}"

if [[ -n "$from_ref" && -n "$to_ref" ]]; then
    diff_cmd=(git diff --no-color -U0 "$from_ref" "$to_ref" -- '*.sh')
else
    diff_cmd=(git diff --no-color -U0 --cached -- '*.sh')
fi

self_path="scripts/lint/check-banned-shell-idioms.sh"
banned_re='\bsed\b'
allow_re='allow-banned-idiom'

violations=0
current_file=""
line_no=0
first_violation=1

while IFS= read -r line; do
    if [[ "$line" =~ ^\+\+\+\ b/(.*)$ ]]; then
        current_file="${BASH_REMATCH[1]}"
        continue
    fi
    if [[ "$line" =~ ^---\  ]]; then
        continue
    fi
    if [[ "$line" =~ ^@@\ -[0-9,]+\ \+([0-9]+) ]]; then
        line_no="${BASH_REMATCH[1]}"
        continue
    fi
    if [[ "$line" =~ ^\+ ]]; then
        added="${line:1}"
        if [[ "$current_file" != "$self_path" ]] \
           && [[ "$added" =~ $banned_re ]] \
           && [[ ! "$added" =~ $allow_re ]]; then
            if (( first_violation )); then
                printf '\n[banned-shell-idioms] Refusing commit. New violations in added lines:\n\n' >&2
                first_violation=0
            fi
            printf '  %s:%d: %s\n' "$current_file" "$line_no" "$added" >&2
            violations=$((violations + 1))
        fi
        line_no=$((line_no + 1))
    fi
done < <("${diff_cmd[@]}")

if (( violations > 0 )); then
    printf '\n' >&2
    printf '%s\n' \
        "Banned in this repo (per CLAUDE.md / CONTEXT.md):" \
        "  sed  -- never, for anything." \
        "" \
        "Suggested fix:" \
        "  * For replacing text in a file:  use the 'edit' tool (exact literal" \
        "    match, refuses on ambiguity -- no regex guesswork)." \
        "  * For creating a new file:       use the 'create' tool." \
        "  * For output formatting (e.g.  'sed s/^/  /' to indent log lines):" \
        "    use a bash 'while IFS= read -r line; do printf ... \"\$line\"; done' loop." \
        "" \
        "Existing legacy uses are grandfathered; only NEW additions are blocked." \
        "" \
        "Escape hatch (use sparingly, must justify):" \
        "  some_command  # allow-banned-idiom: <reason>" >&2
    exit 1
fi

exit 0
