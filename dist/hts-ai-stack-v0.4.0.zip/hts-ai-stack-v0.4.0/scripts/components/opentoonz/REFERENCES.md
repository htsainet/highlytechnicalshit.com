# OpenToonz — References

## Upstream

- **Homepage**: <https://opentoonz.github.io/e/>
- **Source**: <https://github.com/opentoonz/opentoonz>
- **PPA**: <https://launchpad.net/~morevnaproject/+archive/ubuntu/opentoonz>
- **Wiki**: <https://opentoonz.readthedocs.io/>

## Notes

- PPA maintained by Morevna Project
- Originally proprietary Toonz software, open-sourced by DWANGO in 2016
- BSD 3-Clause license
