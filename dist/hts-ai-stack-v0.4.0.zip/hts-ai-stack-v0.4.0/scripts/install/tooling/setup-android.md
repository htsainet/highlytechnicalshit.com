# setup-android.sh — Android / Samsung Phone Access

Configures Ubuntu to communicate with Android phones over USB via MTP and ADB.

---

## What It Does

1. Installs MTP support (`gvfs-backends`, `libmtp-dev`, `mtp-tools`)
2. Installs `jmtpfs` for command-line MTP mounting
3. Installs ADB (Android Debug Bridge) for developer access
4. Creates a `~/phone` mount point

---

## Usage

```bash
bash setup-android.sh
```

---

## After Running

### File Transfer (MTP)

1. Connect your phone via USB
2. Unlock the phone and pull down the notification shade
3. Tap the USB notification → select **File Transfer (MTP)**

**GUI:** Open the Files app — the phone appears in the sidebar automatically.

**CLI:**

```bash
jmtpfs ~/phone       # mount
ls ~/phone           # browse files
fusermount -u ~/phone  # unmount
```

### ADB (Developer / Debug Access)

1. On the phone: go to **Settings → About → Software** and tap **Build Number** 7 times
2. Go to **Developer Options** → enable **USB Debugging**
3. Confirm the authorization prompt on the phone

```bash
adb devices          # verify connection
adb shell            # open shell on device
adb push file /sdcard/   # copy file to phone
adb pull /sdcard/file .  # copy file from phone
```

---

## Notes

- If the phone is not detected by `jmtpfs`, try toggling USB mode on the phone
  (disconnect and reconnect, re-select File Transfer).
- `gvfs-backends` enables GUI mounting; `jmtpfs` is for headless/CLI use.
- ADB and MTP are mutually exclusive — the phone is in one mode at a time.
