#!/usr/bin/env bash
# scripts/lib/installstatus.sh — Install-progress reporter for the dashboard
# Source this file; do NOT run directly.
#
# Writes resources/dashboard/install-status.json so the dashboard can
# show live build progress (pending → installing → running).
#
# Requires: common.sh sourced first (for REPO_DIR)

INSTALL_STATUS_FILE="${REPO_DIR}/resources/dashboard/install-status.json"

# Track which service is currently being installed so ERR traps can mark it.
_INSTALL_CURRENT_SVC=""

# _install_status_write — Overwrite the status JSON atomically.
# Args: $1 = phase ("installing" | "complete" | "error")
#       stdin or global _INSTALL_SERVICES associative array
_install_status_write() {
  local phase="${1:-installing}"
  local tmp="${INSTALL_STATUS_FILE}.tmp"

  # Build JSON from the associative arrays
  {
    printf '{\n  "phase": "%s",\n  "updated": "%s",\n  "services": {\n' \
      "$phase" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"

    local first=true
    local key
    # Sort keys for stable output
    for key in $(echo "${!_INSTALL_SERVICES[@]}" | tr ' ' '\n' | sort); do
      if [[ "$first" == "true" ]]; then
        first=false
      else
        printf ',\n'
      fi
      printf '    "%s": "%s"' "$key" "${_INSTALL_SERVICES[$key]}"
    done
    printf '\n  },\n  "messages": {\n'

    # Per-service status messages (e.g. "Pulling model gemma4:e4b…")
    first=true
    for key in $(echo "${!_INSTALL_MESSAGES[@]}" | tr ' ' '\n' | sort); do
      [[ -z "${_INSTALL_MESSAGES[$key]}" ]] && continue
      if [[ "$first" == "true" ]]; then
        first=false
      else
        printf ',\n'
      fi
      printf '    "%s": "%s"' "$key" "${_INSTALL_MESSAGES[$key]}"
    done
    printf '\n  }\n}\n'
  } > "$tmp"

  mv -f "$tmp" "$INSTALL_STATUS_FILE"
}

# install_status_init — Initialize status file with selected services.
# Args: service_id ... (e.g. "dashboard" "ollama-gpu" "open-webui")
# All services start as "pending".
install_status_init() {
  declare -gA _INSTALL_SERVICES
  declare -gA _INSTALL_MESSAGES
  for svc in "$@"; do
    _INSTALL_SERVICES["$svc"]="pending"
    _INSTALL_MESSAGES["$svc"]=""
  done
  _install_status_write "installing"
  info "Install status: initialized (${#_INSTALL_SERVICES[@]} services)"
}

# install_status_set — Update a single service's status.
# Args: $1 = service_id, $2 = status ("pending"|"installing"|"running"|"error"|"skipped")
install_status_set() {
  local svc="$1" status="$2"
  _INSTALL_SERVICES["$svc"]="$status"
  # Auto-track the active service for ERR trap handling
  case "$status" in
    installing) _INSTALL_CURRENT_SVC="$svc" ;;
    running|error|skipped) _INSTALL_CURRENT_SVC="" ;;
  esac
  _install_status_write "installing"
}

# install_status_msg — Set a human-readable message for a service.
# Args: $1 = service_id, $2 = message text (or "" to clear)
# Example: install_status_msg "ollama-gpu" "Pulling model gemma4:e4b…"
install_status_msg() {
  local svc="$1" msg="$2"
  _INSTALL_MESSAGES["$svc"]="$msg"
  _install_status_write "installing"
}

# install_status_complete — Mark the install as finished.
install_status_complete() {
  _install_status_write "complete"
  info "Install status: complete"
}

# install_status_error — Mark the install as errored.
# Args: $1 = optional service that failed
install_status_error() {
  if [[ -n "${1:-}" ]]; then
    _INSTALL_SERVICES["$1"]="error"
  fi
  _install_status_write "error"
}

# _install_status_on_error — ERR trap handler.
# Marks the currently-installing service (if any) and the overall phase as error.
# Usage: trap '_install_status_on_error' ERR
_install_status_on_error() {
  if [[ -n "$_INSTALL_CURRENT_SVC" ]]; then
    _INSTALL_SERVICES["$_INSTALL_CURRENT_SVC"]="error"
    _INSTALL_CURRENT_SVC=""
  fi
  _install_status_write "error"
}

# install_status_cleanup — Remove the status file (switch to live probes).
install_status_cleanup() {
  rm -f "$INSTALL_STATUS_FILE" "${INSTALL_STATUS_FILE}.tmp"
}
