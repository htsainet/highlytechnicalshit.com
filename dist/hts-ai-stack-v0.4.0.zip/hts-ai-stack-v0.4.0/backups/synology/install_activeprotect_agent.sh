#!/usr/bin/env bash
#
# install_activeprotect_agent.sh
#
# Scripted / unattended install of the Synology ActiveProtect agent on Linux.
# Based on the APM 1.2 Admin Guide.
#
# Usage:
#   sudo ./install_activeprotect_agent.sh \
#       --installer /path/to/install.run \
#       --server  apm.example.com \
#       --key     apmXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
#
# Optional flags:
#       --port            Custom management server port (default: 443)
#       --prefer-ips      Backup-server network interface and optional port
#       --proxy-addr      Proxy address
#       --proxy-port      Proxy port
#       --proxy-user      Proxy username
#       --proxy-pass      Proxy password
#       --skip-prereqs    Skip prerequisite package installation
#       --dry-run         Show what would be done without executing
#
# Requirements (installed automatically unless --skip-prereqs):
#   make  >= 4.1
#   dkms  >= 2.2.0.3
#   gcc   >= 4.8.2
#   bc    (RPM-based distros only)
#   kernel headers for the running kernel
#
# Supported distros:
#   DEB: Ubuntu 16.04–24.04, Debian 10–13
#   RPM: CentOS 7.x–8.x, RHEL 6.10–9.7, Fedora 38–42
#
# Supported filesystems: ext2, ext3, ext4, XFS
# Supported kernels:     2.6 – 6.14
# Required port:         8443/443 outbound to management server
#
set -euo pipefail

# ──────────────────────────────────────────────
# Defaults
# ──────────────────────────────────────────────
INSTALLER=""
APM_SERVER=""
CONNECT_KEY=""
APM_PORT=""
PREFER_IPS=""
PROXY_ADDR=""
PROXY_PORT=""
PROXY_USER=""
PROXY_PASS=""
SKIP_PREREQS=false
DRY_RUN=false
CONFIG_FILE="/tmp/ActiveProtectAgentInstallConfig"
LOG_FILE="/var/log/activeprotect_agent_install.log"

# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log()   { echo -e "${GREEN}[INFO]${NC}  $*" | tee -a "$LOG_FILE"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*" | tee -a "$LOG_FILE"; }
err()   { echo -e "${RED}[ERROR]${NC} $*" | tee -a "$LOG_FILE" >&2; }
die()   { err "$@"; exit 1; }

usage() {
    sed -n '2,/^$/{ s/^# \?//; p }' "$0"
    exit 0
}

# ──────────────────────────────────────────────
# Parse arguments
# ──────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
    case "$1" in
        --installer)    INSTALLER="$2";    shift 2 ;;
        --server)       APM_SERVER="$2";   shift 2 ;;
        --key)          CONNECT_KEY="$2";  shift 2 ;;
        --port)         APM_PORT="$2";     shift 2 ;;
        --prefer-ips)   PREFER_IPS="$2";   shift 2 ;;
        --proxy-addr)   PROXY_ADDR="$2";   shift 2 ;;
        --proxy-port)   PROXY_PORT="$2";   shift 2 ;;
        --proxy-user)   PROXY_USER="$2";   shift 2 ;;
        --proxy-pass)   PROXY_PASS="$2";   shift 2 ;;
        --skip-prereqs) SKIP_PREREQS=true; shift   ;;
        --dry-run)      DRY_RUN=true;      shift   ;;
        -h|--help)      usage ;;
        *) die "Unknown option: $1" ;;
    esac
done

# ──────────────────────────────────────────────
# Validate required arguments
# ──────────────────────────────────────────────
[[ -z "$INSTALLER" ]]   && die "Missing --installer /path/to/install.run"
[[ -z "$APM_SERVER" ]]  && die "Missing --server <management-server-address>"
[[ -z "$CONNECT_KEY" ]] && die "Missing --key <connect-key>"
[[ -f "$INSTALLER" ]]   || die "Installer not found: $INSTALLER"

# ──────────────────────────────────────────────
# Must run as root
# ──────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    die "This script must be run as root (or with sudo)."
fi

# ──────────────────────────────────────────────
# Detect distro family
# ──────────────────────────────────────────────
detect_pkg_manager() {
    if   command -v apt-get &>/dev/null; then echo "apt"
    elif command -v dnf     &>/dev/null; then echo "dnf"
    elif command -v yum     &>/dev/null; then echo "yum"
    else echo "unknown"
    fi
}

PKG_MGR=$(detect_pkg_manager)
log "Detected package manager: ${PKG_MGR}"
log "Running kernel: $(uname -r)"

# ──────────────────────────────────────────────
# Pre-flight checks
# ──────────────────────────────────────────────
preflight_checks() {
    # Filesystem check — warn on unsupported FS
    local root_fs
    root_fs=$(df --output=fstype / | tail -1)
    case "$root_fs" in
        ext2|ext3|ext4|xfs) log "Root filesystem: ${root_fs} (supported)" ;;
        *)                  warn "Root filesystem '${root_fs}' may not be supported. ActiveProtect supports ext2/3/4 and XFS." ;;
    esac

    # Kernel version range check (2.6 – 6.14)
    local kver
    kver=$(uname -r | grep -oP '^\d+\.\d+')
    log "Kernel version: ${kver}"

    # Check for conflicting kernel modules
    for mod in dattobd veeamsnap elastio; do
        if lsmod | grep -q "^${mod}" 2>/dev/null; then
            warn "Conflicting kernel module '${mod}' is loaded. This may cause installation failure."
        fi
    done
}

preflight_checks

# ──────────────────────────────────────────────
# Install prerequisites
# ──────────────────────────────────────────────
install_prereqs() {
    if $SKIP_PREREQS; then
        log "Skipping prerequisite installation (--skip-prereqs)"
        return
    fi

    log "Installing prerequisites..."
    case "$PKG_MGR" in
        apt)
            apt-get update -qq
            apt-get install -y -qq make dkms gcc linux-headers-"$(uname -r)" 2>&1 | tee -a "$LOG_FILE"
            ;;
        dnf)
            dnf install -y -q make dkms gcc bc kernel-devel-"$(uname -r)" 2>&1 | tee -a "$LOG_FILE"
            ;;
        yum)
            yum install -y -q make dkms gcc bc kernel-devel-"$(uname -r)" 2>&1 | tee -a "$LOG_FILE"
            ;;
        *)
            warn "Unknown package manager. Please install manually: make (>=4.1), dkms (>=2.2.0.3), gcc (>=4.8.2), kernel headers."
            ;;
    esac
}

install_prereqs

# ──────────────────────────────────────────────
# Verify prerequisites are present
# ──────────────────────────────────────────────
verify_prereqs() {
    local missing=()
    command -v make &>/dev/null || missing+=("make")
    command -v dkms &>/dev/null || missing+=("dkms")
    command -v gcc  &>/dev/null || missing+=("gcc")

    if [[ "$PKG_MGR" != "apt" ]]; then
        command -v bc &>/dev/null || missing+=("bc")
    fi

    if [[ ${#missing[@]} -gt 0 ]]; then
        die "Missing required packages: ${missing[*]}"
    fi

    log "All prerequisites verified."
}

verify_prereqs

# ──────────────────────────────────────────────
# Build the config file for unattended connect
# ──────────────────────────────────────────────
build_config() {
    log "Writing config to ${CONFIG_FILE}"

    # Build the server address (with optional port)
    local server_addr="$APM_SERVER"
    if [[ -n "$APM_PORT" ]]; then
        server_addr="${APM_SERVER}:${APM_PORT}"
    fi

    {
        echo "connect_key=${CONNECT_KEY}"
        echo "apm_address=${server_addr}"
        [[ -n "$PREFER_IPS" ]] && echo "prefer_ips=${PREFER_IPS}"
        [[ -n "$PROXY_ADDR" ]] && echo "proxy_addr=${PROXY_ADDR}"
        [[ -n "$PROXY_PORT" ]] && echo "proxy_port=${PROXY_PORT}"
        [[ -n "$PROXY_USER" ]] && echo "proxy_username=${PROXY_USER}"
        [[ -n "$PROXY_PASS" ]] && echo "proxy_password=${PROXY_PASS}"
    } > "$CONFIG_FILE"

    chmod 600 "$CONFIG_FILE"
}

# ──────────────────────────────────────────────
# Clean up config file (contains credentials)
# ──────────────────────────────────────────────
cleanup_config() {
    if [[ -f "$CONFIG_FILE" ]]; then
        rm -f "$CONFIG_FILE"
        log "Removed config file (contains credentials)."
    fi
}
trap cleanup_config EXIT

# ──────────────────────────────────────────────
# Install the agent
# ──────────────────────────────────────────────
run_install() {
    # Make installer executable
    chmod +x "$INSTALLER"

    if $DRY_RUN; then
        log "[DRY RUN] Would write config to ${CONFIG_FILE}:"
        log "  connect_key=${CONNECT_KEY}"
        log "  apm_address=${APM_SERVER}${APM_PORT:+:$APM_PORT}"
        [[ -n "$PREFER_IPS" ]] && log "  prefer_ips=${PREFER_IPS}"
        [[ -n "$PROXY_ADDR" ]] && log "  proxy_addr=${PROXY_ADDR}:${PROXY_PORT}"
        log "[DRY RUN] Would run: ${INSTALLER}"
        return
    fi

    build_config

    log "Running installer: ${INSTALLER}"
    if "$INSTALLER" 2>&1 | tee -a "$LOG_FILE"; then
        log "Agent installation completed successfully."
    else
        die "Agent installation failed. Check ${LOG_FILE} for details."
    fi
}

run_install

# ──────────────────────────────────────────────
# Verify installation
# ──────────────────────────────────────────────
verify_install() {
    if $DRY_RUN; then
        log "[DRY RUN] Would verify agent service status."
        return
    fi

    # Give the service a moment to start
    sleep 3

    if command -v activeprotect-agent-cli &>/dev/null; then
        log "activeprotect-agent-cli is available on PATH."
    else
        warn "activeprotect-agent-cli not found on PATH. The agent may use a different binary name — check /opt/ or /usr/local/."
    fi

    # Check if the agent service is running
    if systemctl is-active --quiet activeprotect-agent 2>/dev/null; then
        log "Agent service is running."
    elif systemctl is-active --quiet synoagentd 2>/dev/null; then
        log "Agent service (synoagentd) is running."
    else
        warn "Could not confirm agent service is running. Check 'systemctl status' for the ActiveProtect service."
    fi
}

verify_install

log "──────────────────────────────────────────────"
log "Installation complete."
log "Log file: ${LOG_FILE}"
log "──────────────────────────────────────────────"
