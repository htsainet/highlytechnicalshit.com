BeforeAll {
    # $PSScriptRoot is /repo/tests, parent is /repo
    $RepoRoot = Split-Path -Parent $PSScriptRoot
}

Describe "Framework Structure Validation" {
    Context "CLAUDE.md routing file" {
        BeforeAll {
            $ClaudeFile = Join-Path $RepoRoot "CLAUDE.md"
            $Content = Get-Content $ClaudeFile -Raw
            $Lines = @(Get-Content $ClaudeFile)
        }

        It "exists at repo root" {
            Test-Path $ClaudeFile | Should -Be $true
        }

        It "is under 50 lines" {
            $Lines.Count | Should -BeLessThan 50
        }

        It "contains routing table with Task and Go columns" {
            $Content | Should -Match "Task"
            $Content | Should -Match "Go to"
            $Content | Should -Match "\|.*\|.*\|"
        }

        It "does not contain extensive folder diagrams" {
            # Count code blocks - should be minimal
            $CodeBlocks = @($Content | Select-String -Pattern '```' -AllMatches)
            $CodeBlocks.Count | Should -BeLessThan 2
        }

        It "defines identity and rules sections" {
            $Content | Should -Match "# Identity"
            $Content | Should -Match "## Rules"
        }

        It "does not contain personality instructions" {
            # Avoid overly prescriptive language
            $Content | Should -Not -Match "be creative"
            $Content | Should -Not -Match "be professional"
            $Content | Should -Not -Match "think step"
        }
    }

    Context "CONTEXT.md files" {
        It "root CONTEXT.md exists" {
            Test-Path (Join-Path $RepoRoot "CONTEXT.md") | Should -Be $true
        }

        It "docs/CONTEXT.md exists" {
            Test-Path (Join-Path $RepoRoot "docs/CONTEXT.md") | Should -Be $true
        }

        It "scripts/CONTEXT.md exists" {
            Test-Path (Join-Path $RepoRoot "scripts/CONTEXT.md") | Should -Be $true
        }

        It "tests/CONTEXT.md exists" {
            Test-Path (Join-Path $RepoRoot "tests/CONTEXT.md") | Should -Be $true
        }

        It "all CONTEXT.md files have content" {
            $AllContexts = @(Get-ChildItem -Path $RepoRoot -Filter "CONTEXT.md" -Recurse)
            $AllContexts | ForEach-Object {
                $Content = Get-Content $_.FullName -Raw
                $Content.Length | Should -BeGreaterThan 50 -Because "CONTEXT.md should not be empty: $($_.FullName)"
            }
        }
    }

    Context "REFERENCES.md file" {
        BeforeAll {
            $RefFile = Join-Path $RepoRoot "REFERENCES.md"
            $Content = Get-Content $RefFile -Raw
        }

        It "exists at repo root" {
            Test-Path $RefFile | Should -Be $true
        }

        It "contains folder architecture diagram" {
            $Content | Should -Match "hts-ai-stack"
        }

        It "references core services" {
            $Content | Should -Match "OpenClaw"
            $Content | Should -Match "NemoClaw"
        }
    }

    Context "Routing table structure" {
        BeforeAll {
            $ClaudeFile = Join-Path $RepoRoot "CLAUDE.md"
            $Lines = @(Get-Content $ClaudeFile)

            # Find routing table rows (pipe-delimited, not headers)
            $RoutingEntries = @($Lines | Where-Object {
                ($_ -match '^\|' -and
                 $_ -notmatch 'Task|---|Go to|Read' -and
                 $_.Trim().Length -gt 3)
            })
        }

        It "has routing table entries" {
            $RoutingEntries.Count | Should -BeGreaterThan 0
        }

        It "has reasonable number of entries (≤ 12)" {
            # Each routing entry should cluster into a few mental modes; allow up to 12
            $RoutingEntries.Count | Should -BeLessOrEqual 12
        }

        It "routing entries reference existing paths" {
            # Verify each entry points to a real location
            foreach ($Entry in $RoutingEntries) {
                if ($Entry -match '\|\s*/([^|]+)\|') {
                    $FolderName = $matches[1].Trim()
                    $FolderPath = Join-Path $RepoRoot $FolderName
                    ((Test-Path $FolderPath) -or ($FolderPath -eq $RepoRoot)) | Should -Be $true
                }
            }
        }
    }

    Context "Workspace structure" {
        It "has key directories (not flat)" {
            @("docs", "scripts", "tests", "docker") | ForEach-Object {
                Test-Path (Join-Path $RepoRoot $_) | Should -Be $true
            }
        }

        It "docs contains subfolders for planning and development" {
            Test-Path (Join-Path $RepoRoot "docs/planning") | Should -Be $true
            Test-Path (Join-Path $RepoRoot "docs/development") | Should -Be $true
        }

        It "scripts/install exists with step files" {
            Test-Path (Join-Path $RepoRoot "scripts/install") | Should -Be $true
            $InstallScripts = @(Get-ChildItem (Join-Path $RepoRoot "scripts/install") -Filter "*.sh")
            $InstallScripts.Count | Should -BeGreaterThan 0
        }

        It "scripts/lib exists with shared libraries" {
            $LibDir = Join-Path $RepoRoot "scripts/lib"
            Test-Path $LibDir | Should -Be $true
            @("common.sh", "health.sh", "compose.sh", "tokens.sh") | ForEach-Object {
                Test-Path (Join-Path $LibDir $_) | Should -Be $true -Because "lib/$_ must exist"
            }
        }

        It "scripts/components exists with service scripts" {
            $CompDir = Join-Path $RepoRoot "scripts/components"
            Test-Path $CompDir | Should -Be $true
            $ComponentScripts = @(Get-ChildItem $CompDir -Filter "*.sh")
            $ComponentScripts.Count | Should -BeGreaterThan 5
        }

        It "scripts/host exists with host dependency scripts" {
            $HostDir = Join-Path $RepoRoot "scripts/host"
            Test-Path $HostDir | Should -Be $true
            @("nvidia.sh", "docker.sh", "node.sh", "tools.sh") | ForEach-Object {
                Test-Path (Join-Path $HostDir $_) | Should -Be $true -Because "host/$_ must exist"
            }
        }

        It "scripts/bundles exists with orchestration scripts" {
            $BundleDir = Join-Path $RepoRoot "scripts/bundles"
            Test-Path $BundleDir | Should -Be $true
            @("full-stack.sh", "chat.sh") | ForEach-Object {
                Test-Path (Join-Path $BundleDir $_) | Should -Be $true -Because "bundles/$_ must exist"
            }
        }
    }

    Context "Pester test naming convention" {
        BeforeAll {
            $PesterTestFiles = @(Get-ChildItem -Path $PSScriptRoot -Filter '*.Tests.ps1' -File)
            $ApprovedVerbs = @((Get-Verb).Verb)
        }

        It "all Pester test files follow Verb-Noun.Tests.ps1 with an approved verb" {
            $Violations = [System.Collections.Generic.List[string]]::new()

            foreach ($TestFile in $PesterTestFiles) {
                if ($TestFile.Name -notmatch '^([A-Za-z][A-Za-z0-9]*)-([A-Za-z][A-Za-z0-9]*)\.Tests\.ps1$') {
                    $Violations.Add("$($TestFile.Name) does not match Verb-Noun.Tests.ps1")
                    continue
                }

                $Verb = $matches[1]
                if ($ApprovedVerbs -notcontains $Verb) {
                    $Violations.Add("$($TestFile.Name) uses unapproved PowerShell verb '$Verb'")
                }
            }

            $Because = if ($Violations.Count -gt 0) { $Violations -join '; ' } else { 'all test filenames should match the documented convention' }
            $Violations | Should -BeNullOrEmpty -Because $Because
        }
    }

    Context "Documentation completeness" {
        It "README.md exists" {
            Test-Path (Join-Path $RepoRoot "README.md") | Should -Be $true
        }

        It "core framework files present (CLAUDE.md, CONTEXT.md, REFERENCES.md)" {
            @("CLAUDE.md", "CONTEXT.md", "REFERENCES.md") | ForEach-Object {
                Test-Path (Join-Path $RepoRoot $_) | Should -Be $true
            }
        }

        It "root CONTEXT.md describes project" {
            $ContextContent = Get-Content (Join-Path $RepoRoot "CONTEXT.md") -Raw
            $ContextContent | Should -Match "building"
            $ContextContent | Should -Match "looks like"
        }
    }

    Context "CONTEXT.md structure consistency" {
        BeforeAll {
            # Define required sections for workspace CONTEXT files
            # (Root CONTEXT.md has different structure, so we exclude it)
            $WorkspaceContexts = @(Get-ChildItem -Path $RepoRoot -Filter "CONTEXT.md" -Recurse |
                Where-Object { $_.FullName -notlike "*$RepoRoot/CONTEXT.md" })

            # Required section headers (at least one of these patterns per file)
            $RequiredPatterns = @(
                "What.*happen",        # "What happens in this workspace" or similar
                "Purpose|Scope",       # Describes what the workspace is for
                "Process|Workflow|Steps", # Describes the workflow
                "File|Structure|Organization", # Describes file organization
                "good.*look|standard|convention" # Describes quality/success criteria
            )
        }

        It "all workspace CONTEXT.md files exist and are substantive" {
            $WorkspaceContexts.Count | Should -BeGreaterThan 0
        }

        It "each workspace CONTEXT.md describes its purpose" {
            $WorkspaceContexts | ForEach-Object {
                $Content = Get-Content $_.FullName -Raw
                # Should describe what the workspace is for (at least 50 chars on purpose)
                $HasPurpose = $Content -match "what.*happen|purpose|scope|folder|track"
                $HasPurpose | Should -Be $true -Because "$($_.FullName) should describe its purpose"
            }
        }

        It "each workspace CONTEXT.md has process/workflow section" {
            $WorkspaceContexts | ForEach-Object {
                $Content = Get-Content $_.FullName -Raw
                # Should describe workflow, process, or how work flows through
                $HasProcess = $Content -match "process|workflow|step|convention|how to|go to"
                $HasProcess | Should -Be $true -Because "$($_.FullName) should describe workflow/process"
            }
        }

        It "each workspace CONTEXT.md describes success criteria or standards" {
            $WorkspaceContexts | ForEach-Object {
                $Content = Get-Content $_.FullName -Raw
                # Should say what good work looks like or standards
                $HasCriteria = $Content -match "good.*look|what to avoid|standard|convention|requirement"
                $HasCriteria | Should -Be $true -Because "$($_.FullName) should describe standards or success"
            }
        }

        It "CONTEXT.md files use consistent header structure (h1 title, h2 sections)" {
            $WorkspaceContexts | ForEach-Object {
                $Content = Get-Content $_.FullName -Raw
                # Should have at least one h1 (# Title) and some h2s (## sections)
                # Note: -match in PS doesn't use multiline mode by default, so we check for presence of pattern
                $HasH1 = $Content -match "# [^\s]"
                $HasH2 = $Content -match "## "

                $HasH1 | Should -Be $true -Because "$($_.FullName) should start with # Title"
                $HasH2 | Should -Be $true -Because "$($_.FullName) should have ## Section headers"
            }
        }
    }

    Context "Living document markers" {
        BeforeAll {
            $AllContexts = @(Get-ChildItem -Path $RepoRoot -Filter "CONTEXT.md" -Recurse)
        }

        It "all CONTEXT.md files have Last updated marker with full timestamp" {
            $AllContexts | ForEach-Object {
                $Content = Get-Content $_.FullName -Raw
                # Format: "Last updated: YYYY-MM-DD HH:MM:SS" (with optional timezone)
                $HasTimestamp = $Content -match "Last updated[:\s]+\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}"
                $HasTimestamp | Should -Be $true -Because "$($_.FullName) should have 'Last updated: YYYY-MM-DD HH:MM:SS' marker"
            }
        }

        It "Last updated timestamps are recent (within 90 days)" {
            $NinetyDaysAgo = (Get-Date).AddDays(-90)
            $AllContexts | ForEach-Object {
                $Content = Get-Content $_.FullName -Raw
                if ($Content -match "Last updated[:\s]+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})") {
                    $DateStr = $matches[1]
                    $Date = [DateTime]::ParseExact($DateStr, 'yyyy-MM-dd HH:mm:ss', $null)
                    $Date | Should -BeGreaterThan $NinetyDaysAgo -Because "$($_.FullName) has stale timestamp: $DateStr"
                }
            }
        }
    }

    Context "Layer 3 skills and tools documentation" {
        BeforeAll {
            $AllContexts = @(Get-ChildItem -Path $RepoRoot -Filter "CONTEXT.md" -Recurse)
        }

        It "all workspace CONTEXT.md files document tools or skills used" {
            $AllContexts | ForEach-Object {
                $Content = Get-Content $_.FullName -Raw
                # Should have a section mentioning tools, skills, dependencies, or explicitly state "None"
                $HasToolsSection = $Content -match "tool|skill|dependency|requirement|extension" -or `
                                   $Content -match "## (Tool|Skill|Dependency|Extension|Requirement)"
                $HasToolsSection | Should -Be $true -Because "$($_.FullName) should document tools/skills or state none are needed"
            }
        }
    }

    Context "Routing table completeness" {
        BeforeAll {
            $ClaudeFile = Join-Path $RepoRoot "CLAUDE.md"
            $RoutingLines = @(Get-Content $ClaudeFile | Where-Object { $_ -match '^\|.*\|' -and $_ -notmatch 'Task|---|Go to' })

            # Extract all paths from routing table (second column, may be backtick-quoted)
            $RoutedPaths = @($RoutingLines | ForEach-Object {
                if ($_ -match '\|\s*`?(/[^`|]+)`?\s*\|') {
                    $matches[1].Trim()
                }
            } | Select-Object -Unique)

            # Find all CONTEXT.md files (except root)
            $AllContexts = @(Get-ChildItem -Path $RepoRoot -Filter "CONTEXT.md*" -Recurse | Where-Object { $_.FullName -ne (Join-Path $RepoRoot "CONTEXT.md") })
        }

        It "all top-level workspace CONTEXT.md files are routed in CLAUDE.md" {
            # Check only top-level or routable workspaces (not sub-sub-workspaces)
            $AllContexts | Where-Object { $_.FullName -notmatch '/(tests|utils)/' } | ForEach-Object {
                $WorkspacePath = "/" + [System.IO.Path]::GetDirectoryName($_.FullName).Replace($RepoRoot, "").TrimStart("/").Replace("\", "/")
                # Allow sub-workspaces under /docs/development, /docs/planning, etc. if parent is routed
                $IsRouted = $RoutedPaths | Where-Object { $_ -eq $WorkspacePath -or $WorkspacePath -match "^$_/" }
                $IsRouted | Should -Not -BeNullOrEmpty -Because "Workspace $WorkspacePath should be routed or under a routed parent"
            }
        }
    }

    Context "CONTEXT.md section consistency" {
        BeforeAll {
            $AllContexts = @(Get-ChildItem -Path $RepoRoot -Filter "CONTEXT.md*" -Recurse)

            # Define expected section headers (at least one per category)
            $ExpectedSections = @{
                "Purpose" = @("purpose", "what.*happen", "what this folder", "describe")
                "Process" = @("process", "workflow", "how to", "go to", "step")
                "Structure" = @("file|structure", "organization", "folder")
                "Standards" = @("good.*look", "standard|convention", "what to avoid|avoid")
                "Tools" = @("tool|skill|dependency", "requirement|extension")
            }
        }

        It "workspace CONTEXT.md files use consistent major sections" {
            $AllContexts | Where-Object { $_.FullName -ne (Join-Path $RepoRoot "CONTEXT.md") } | ForEach-Object {
                $Content = Get-Content $_.FullName -Raw
                $HasSections = $Content -match "##\s+(Purpose|Process|Workflow|File|Structure|Standard|Tool|Skill)"
                $HasSections | Should -Be $true -Because "$($_.FullName) should use standard section headers"
            }
        }
    }

    Context "Link validation" {
        BeforeAll {
            $AllContexts = @(Get-ChildItem -Path $RepoRoot -Filter "CONTEXT.md*" -Recurse)
        }

        It "markdown links in CONTEXT.md files point to existing files" {
            $AllContexts | ForEach-Object {
                $ContextFile = $_
                $Content = Get-Content $ContextFile.FullName -Raw
                $Links = @([regex]::Matches($Content, '\[([^\]]+)\]\(([^)]+)\)') | ForEach-Object { $_.Groups[2].Value })

                $Links | Where-Object { $_ -and $_ -notmatch '^(https?:|mailto:|#)' } | ForEach-Object {
                    $LinkTarget = $_
                    $ContextDir = Split-Path $ContextFile.FullName -Parent

                    # Handle absolute paths (starting with /)
                    if ($LinkTarget -match '^/') {
                        $LinkPath = Join-Path $RepoRoot $LinkTarget.TrimStart("/")
                    }
                    else {
                        # Relative path
                        $LinkPath = Join-Path $ContextDir $LinkTarget
                    }

                    # Normalize path for comparison
                    if (Test-Path $LinkPath) {
                        $LinkPath = (Get-Item $LinkPath).FullName
                    }

                    (Test-Path $LinkPath) | Should -Be $true -Because "Link '$LinkTarget' in $($ContextFile.Name) should exist (resolved to $LinkPath)"
                }
            }
        }
    }

    Context "Anti-patterns check" {
        It "CLAUDE.md is not bloated" {
            $ClaudeLines = @(Get-Content (Join-Path $RepoRoot "CLAUDE.md"))
            $ClaudeLines.Count | Should -BeLessThan 50
        }

        It "REFERENCES.md contains architecture not hardware targets" {
            $RefContent = Get-Content (Join-Path $RepoRoot "REFERENCES.md") -Raw

            # Should have architecture
            $RefContent | Should -Match "hts-ai-stack"

            # Should not have specific hardware specs (like "12 GB RTX3060", "32GB RAM")
            # Filenames like "rtx3060.yml" are OK, just not hardware inventories
            $RefContent | Should -Not -Match "\d+\s*GB\s*RTX"
            $RefContent | Should -Not -Match "\d+GB RAM"
        }

        It "planning folder is organized with subfolders" {
            $PlanningPath = Join-Path $RepoRoot "docs/planning"
            $SubFolders = @(Get-ChildItem $PlanningPath -Directory)

            # Should have multiple organized sub-areas
            $SubFolders.Count | Should -BeGreaterThan 3
        }

        It "no oversized CONTEXT files exist" {
            $AllContexts = @(Get-ChildItem -Path $RepoRoot -Filter "CONTEXT.md" -Recurse)

            $AllContexts | ForEach-Object {
                $Lines = @(Get-Content $_.FullName)
                # CONTEXT.md files should not exceed 100 lines typically
                # But allow larger ones for complex workspaces
                $Lines.Count | Should -BeLessThan 200
            }
        }
    }
}
