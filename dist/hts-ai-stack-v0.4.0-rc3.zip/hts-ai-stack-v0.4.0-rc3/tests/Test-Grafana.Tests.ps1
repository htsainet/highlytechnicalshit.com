$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/grafana'
    $script:ComponentScript = Join-Path $script:ComponentDir 'grafana.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'grafana.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'grafana file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists (TDD — needs creation)' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'grafana manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is grafana' {
        $script:Manifest.id | Should -Be 'grafana'
    }

    It 'category is monitoring' {
        $script:Manifest.category | Should -Be 'monitoring'
    }

    It 'profile is monitoring' {
        $script:Manifest.profile | Should -Be 'monitoring'
    }

    It 'dashboard port is 3100' {
        [int]$script:Manifest.dashboard.port | Should -Be 3100
    }

    It 'health URL targets Grafana API' {
        $script:Manifest.health.url | Should -Match '/api/health'
    }

    It 'script path should point to component subfolder (TDD)' {
        $script:Manifest.script | Should -Be 'scripts/components/grafana/grafana.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'grafana port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 3100 is registered in portmap.json' {
        $script:Portmap.ports.'3100' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'3100'.service | Should -Be 'grafana'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'grafana compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'grafana service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'grafana'
    }

    It 'uses monitoring profile' {
        $script:ComposeContent | Should -Match 'monitoring'
    }
}
