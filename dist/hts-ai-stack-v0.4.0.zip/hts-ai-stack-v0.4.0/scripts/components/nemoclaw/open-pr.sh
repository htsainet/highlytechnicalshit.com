#!/usr/bin/env bash
# Push feat/koboldcpp-peer to origin and open a PR against main.
# One-shot helper — safe to re-run; gh pr create will refuse if a PR
# already exists for the branch.
#
# Requirements: gh CLI authenticated (`gh auth status` should be OK).

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "$REPO_DIR"

BRANCH="feat/koboldcpp-peer"
BASE="main"

current="$(git rev-parse --abbrev-ref HEAD)"
if [[ "$current" != "$BRANCH" ]]; then
  echo "FATAL: expected to be on $BRANCH, currently on $current" >&2
  exit 1
fi

if ! command -v gh >/dev/null 2>&1; then
  echo "FATAL: gh CLI not installed. Install with: sudo apt install gh" >&2
  exit 1
fi

if ! gh auth status >/dev/null 2>&1; then
  echo "FATAL: gh CLI not authenticated. Run: gh auth login" >&2
  exit 1
fi

echo "==> Pushing $BRANCH to origin"
git push origin "$BRANCH"

TITLE="feat(koboldcpp + nemoclaw prompts): peer wiring, source build, upgrade prompts, REPO_DIR fixes"

BODY=$(cat <<'EOF'
Thirteen commits. Highlights:

- KoboldCpp peer wired with Phi-3.5-mini default
- KoboldCpp source-build from LostRuins/koboldcpp v1.112.2 + validate-koboldcpp-build.sh with pre-rewrite image guard
- Reference + adopt entries: LongCat (Video, Flash-Chat, Image, Flash-Omni), magika, elizaOS, AndroClaw, qwen-code, CodeWiki vs Groq analysis
- NemoClaw upgrade prompts (Sonnet Phase 0+1, Opus Phase 2.5 audit, Opus Phase 3 cleanup) — execution deferred to feat/nemoclaw-v0.0.29-upgrade
- fix: REPO_DIR quoting in repomix.sh + superpowers.sh; auth cookie in claw3d health check
EOF
)

echo "==> Opening PR against $BASE"
gh pr create --base "$BASE" --head "$BRANCH" --title "$TITLE" --body "$BODY"

echo
echo "==> Done. Next:"
echo "  1. Review and merge the PR on GitHub."
echo "  2. Tell Copilot 'merged' so it can cut feat/nemoclaw-v0.0.29-upgrade."
