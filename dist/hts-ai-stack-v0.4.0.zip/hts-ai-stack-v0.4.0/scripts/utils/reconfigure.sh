#!/usr/bin/env bash
# Early help – prints the usage header (comment block) and exits before any heavy imports.
if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    _line_no=0
    while IFS= read -r _line; do
        (( _line_no++ ))
        # Skip shebang line and blank line at top
        (( _line_no < 2 )) && continue
        # Stop after the header comment (line ~30)
        (( _line_no > 30 )) && break
        if [[ "$_line" == "# "* ]]; then
            printf '%s\n' "${_line#\# }"
        elif [[ "$_line" == "#"* ]]; then
            printf '%s\n' "${_line#\#}"
        else
            printf '%s\n' "$_line"
        fi
    done < "${BASH_SOURCE[0]}"
    exit 0
fi
# scripts/utils/reconfigure.sh — Interactive component reconfiguration
#
# Presents a whiptail checklist of all toggleable components pre-filled with
# their current enabled state. After selection, pops per-component menus for
# any component that has prompts. Writes changes to config/stack.json and .env,
# then optionally runs converge to apply them.
#
# Usage:
#   ./scripts/utils/reconfigure.sh             # interactive
#   ./scripts/utils/reconfigure.sh --converge  # apply converge after saving
#
# FEATURE-040: Interactive Reconfigure

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/manifest-loader.sh"
source "$REPO_DIR/scripts/lib/menu-handler.sh"

readonly STACK_JSON="$REPO_DIR/config/stack.json"

# ── Read current enabled state for a toggleable component ────────────────────
# Returns "true" or "false" based on config type and current stack.json / .env.
_read_enabled() {
  local id="$1"
  local file; file="$(manifest_file "$id")"
  local cfg_type read_path member_value

  cfg_type=$(jq -r '.config.type'         "$file")
  read_path=$(jq -r '.config.read_path'   "$file")
  member_value=$(jq -r '.config.member_value // ""' "$file")

  case "$cfg_type" in
    boolean)
      jq -r "$read_path // false" "$STACK_JSON"
      ;;
    enum)
      # Enabled if the engine/value field matches any of match_values
      local current match_values
      current=$(jq -r "$read_path // empty" "$STACK_JSON")
      match_values=$(jq -r '.config.match_values[]' "$file")
      if echo "$match_values" | grep -qx "$current"; then
        echo "true"
      else
        echo "false"
      fi
      ;;
    array_member)
      # Enabled if member_value is present in the array at read_path
      jq -r --arg v "$member_value" \
        "if ($read_path // []) | contains([\$v]) then \"true\" else \"false\" end" \
        "$STACK_JSON"
      ;;
    *)
      echo "false"
      ;;
  esac
}

# ── Apply write_rules for enable or disable ───────────────────────────────────
_apply_write_rules() {
  local id="$1"
  local action="$2"  # "enable" or "disable"
  local file; file="$(manifest_file "$id")"

  local rule_count; rule_count=$(jq -r '.config.write_rules | length' "$file")
  local i
  for (( i = 0; i < rule_count; i++ )); do
    local rule; rule=$(jq -c ".config.write_rules[$i]" "$file")
    local path; path=$(jq -r '.path' <<< "$rule")

    local arr_action; arr_action=$(jq -r '.action // ""' <<< "$rule")

    if [[ "$arr_action" == "add_remove" ]]; then
      # Array membership toggle
      local value; value=$(jq -r '.value' <<< "$rule")
      local tmp="${STACK_JSON}.tmp.$$"
      if [[ "$action" == "enable" ]]; then
        jq --arg v "$value" "$path |= (. + [\$v] | unique)" "$STACK_JSON" > "$tmp"
      else
        jq --arg v "$value" "$path |= map(select(. != \$v))" "$STACK_JSON" > "$tmp"
      fi
      mv "$tmp" "$STACK_JSON"
    else
      # Simple set
      local val_key; [[ "$action" == "enable" ]] && val_key="on_enable" || val_key="on_disable"
      local raw_val; raw_val=$(jq -r ".$val_key" <<< "$rule")

      # Determine jq value (bool / number / string)
      local jq_val
      if [[ "$raw_val" == "true" || "$raw_val" == "false" ]]; then
        jq_val="$raw_val"
      elif [[ "$raw_val" =~ ^-?[0-9]+$ ]]; then
        jq_val="$raw_val"
      elif [[ "$raw_val" == "null" || -z "$raw_val" ]]; then
        jq_val='""'
      else
        jq_val=$(jq -n --arg v "$raw_val" '$v')
      fi

      local tmp="${STACK_JSON}.tmp.$$"
      jq --argjson v "$jq_val" "$path = \$v" "$STACK_JSON" > "$tmp" && mv "$tmp" "$STACK_JSON"
    fi
  done
}

# ── Also apply write_rules for group members ──────────────────────────────────
# When prometheus (group=monitoring) is toggled, grafana follows via the same
# read_path; no extra rules needed since both read .monitoring.enabled.
# This function is a no-op placeholder for future multi-rule groups.
_apply_group_rules() { :; }

# ── Update _meta.saved_at timestamp ──────────────────────────────────────────
_update_meta() {
  local ts; ts=$(date '+%Y%m%d-%H%M%S')
  local tmp="${STACK_JSON}.tmp.$$"
  jq --arg ts "$ts" '._meta.saved_at = $ts' "$STACK_JSON" > "$tmp" && mv "$tmp" "$STACK_JSON"
}

# ── Main ──────────────────────────────────────────────────────────────────────
main() {
  local auto_converge=0
  [[ "${1:-}" == "--converge" ]] && auto_converge=1

  if ! command -v jq &>/dev/null; then
    fail "reconfigure.sh requires jq"
  fi
  if ! command -v whiptail &>/dev/null; then
    fail "reconfigure.sh requires whiptail"
  fi

  manifest_load_all

  # ── Step 1: Build top-level checklist ──────────────────────────────────────
  local -a checklist_args=()
  local -a toggleable_ids=()
  mapfile -t toggleable_ids < <(manifest_toggleable_ids)

  local id
  for id in "${toggleable_ids[@]}"; do
    local name; name=$(component_display_name "$id")
    local maturity; maturity=$(manifest_get "$id" '.maturity // "stable"')
    [[ "$maturity" == "untested" ]] && name="$name [UNTESTED]"
    [[ "$maturity" == "beta" ]]     && name="$name [BETA]"
    local state; state=$(_read_enabled "$id")
    local wt_state; [[ "$state" == "true" ]] && wt_state="ON" || wt_state="OFF"
    checklist_args+=("$id" "$name" "$wt_state")
  done

  local selected_raw
  selected_raw=$(whiptail \
    --title "HTS AI Stack — Reconfigure" \
    --checklist "Space to toggle, Enter to confirm\n(checked = enabled)" \
    24 60 "${#toggleable_ids[@]}" \
    "${checklist_args[@]}" \
    3>&1 1>&2 2>&3) || { info "Reconfigure cancelled."; exit 0; }

  # Parse whiptail output into an array of selected IDs
  local -a selected=()
  for tok in $selected_raw; do
    selected+=("${tok//\"/}")
  done

  # ── Step 2: Apply enable/disable write_rules ────────────────────────────────
  for id in "${toggleable_ids[@]}"; do
    local was; was=$(_read_enabled "$id")
    local now="false"
    for s in "${selected[@]}"; do
      [[ "$s" == "$id" ]] && now="true" && break
    done

    if [[ "$was" != "$now" ]]; then
      if [[ "$now" == "true" ]]; then
        info "Enabling $id…"
        _apply_write_rules "$id" "enable"
      else
        info "Disabling $id…"
        _apply_write_rules "$id" "disable"
      fi
    fi
  done

  # ── Step 3: Per-component config menus for enabled components with prompts ──
  for id in "${selected[@]}"; do
    local file; file="$(manifest_file "$id")"
    local prompt_count; prompt_count=$(jq -r '.prompts | length' "$file")
    [[ "$prompt_count" -eq 0 ]] && continue

    step "Configure — $(component_display_name "$id")"
    menu_configure_component "$id" || {
      warn "Configuration for $id cancelled — skipping."
    }
  done

  # ── Step 4: Update timestamp ────────────────────────────────────────────────
  _update_meta
  ok "Configuration saved to config/stack.json"

  # ── Step 5: Offer to converge ───────────────────────────────────────────────
  if [[ "$auto_converge" -eq 1 ]]; then
    step "Converging stack"
    exec "$REPO_DIR/scripts/utils/converge.sh" --yes
  fi

  if whiptail --title "Apply Changes?" \
    --yesno "Run converge to apply changes now?" 10 50 3>&1 1>&2 2>&3; then
    step "Converging stack"
    exec "$REPO_DIR/scripts/utils/converge.sh" --yes
  else
    info "Run './scripts/utils/converge.sh' when ready to apply changes."
  fi
}

main "$@"
