# Deployment Variants — Architecture Overview

This document describes hardware-specific variants of the Ubuntu AI Stack and where their files live.

## Directory Structure

```plaintext
hts-ai-stack/
├── docker-compose.yml              ← Main production stack (all profiles)
├── docker/
│   └── compose/
│       ├── rtx3060.yml             ← RTX 3060 12GB standalone compose
│       ├── modelfiles/
│       │   └── Modelfile           ← Custom Ollama model (16K context pin)
│       ├── deerflow/
│       │   ├── config.yaml         ← DeerFlow model + agent config
│       │   └── .env                ← API keys template (Tavily optional)
│       ├── prod.yml
│       └── test.yml
├── services/
│   └── bitnet/
│       ├── Dockerfile              ← Multi-stage BitNet build (Clang 18, GPU)
│       └── entrypoint.sh           ← Model download + llama-server startup
├── docs/
│   └── guides/
│       └── nemoclaw-bitnet-wiring.sh  ← OpenShell/OpenClaw integration guide
└── setup/
```

## Variants

### RTX 3060 / 12GB — DeerFlow + Ollama + OpenWebUI

**Compose file:** `docker/compose/rtx3060.yml`

Services: Ollama (Qwen3 14B Q4_K_M) + DeerFlow 2.0 + OpenWebUI

| Budget item              | VRAM     |
|--------------------------|----------|
| qwen3:14b-q4_K_M weights | ~8.3 GB  |
| KV cache at 16K tokens   | ~1.5 GB  |
| Runtime overhead         | ~0.5 GB  |
| **Total**                | ~10.3 GB |
| RTX 3060 capacity        | 12.0 GB  |

Context pinned to 16K (not 32K) to stay within VRAM budget during parallel DeerFlow sub-agent tasks.

**Start:**

```bash
docker compose -f docker/compose/rtx3060.yml up -d
```

**Ports:**

| Service    | URL                    |
|------------|------------------------|
| DeerFlow   | http://localhost:3000  |
| OpenWebUI  | http://localhost:8080  |
| Ollama API | http://localhost:11434 |

---

### BitNet — Llama3-8B-1.58 inference backend

**Service files:** `services/bitnet/`

Drop-in Ollama replacement using Microsoft BitNet. Exposes an OpenAI-compatible API on port 8080.

**Build and run:**

```bash
docker build -t bitnet-llama3-8b services/bitnet/
docker run -d --name bitnet --gpus all -p 8080:8080 -v bitnet-models:/app/models bitnet-llama3-8b
```

**NemoClaw/OpenClaw integration:** see `docs/guides/nemoclaw-bitnet-wiring.sh`

---

## Hardware Tiers

| Hardware          | Compose file                    | Status        |
|-------------------|---------------------------------|---------------|
| RTX 4090 / 24GB   | `instances/prod/`               | ✅ Production  |
| RTX 4070 / 12GB   | `instances/test/`               | ✅ Production  |
| RTX 3060 / 12GB   | `docker/compose/rtx3060.yml`    | ✅ Integrated  |
| BitNet backend    | `services/bitnet/`              | ✅ Integrated  |

---

**Last updated:** 2026-03-31
