#!/usr/bin/env bash
# scripts/components/langflow/langflow.sh — Langflow visual AI application builder
#
# Standalone usage:
#   ./scripts/components/langflow/langflow.sh              # full: install + configure + start + health
#   ./scripts/components/langflow/langflow.sh --install    # install only
#   ./scripts/components/langflow/langflow.sh --configure  # configure only
#   ./scripts/components/langflow/langflow.sh --start      # start only
#   ./scripts/components/langflow/langflow.sh --stop       # stop
#   ./scripts/components/langflow/langflow.sh --restart    # restart (stop + start)
#   ./scripts/components/langflow/langflow.sh --health     # health check only
#   ./scripts/components/langflow/langflow.sh --status     # show status + port + health
#   ./scripts/components/langflow/langflow.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

load_env
LANGFLOW_PORT="${LANGFLOW_PORT:-7870}"
LANGFLOW_CONTAINER="${LANGFLOW_CONTAINER:-hts-ai-langflow-1}"

# ── Lifecycle functions ───────────────────────────────────────────────────────

langflow_install() {
  step "Langflow — install"
  compose_build --profile langflow langflow
  ok "Langflow image built."
}

langflow_configure() {
  step "Langflow — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^LANGFLOW_PORT=" "$env_file" 2>/dev/null; then
    printf 'LANGFLOW_PORT=%s\n' "$LANGFLOW_PORT" >> "$env_file"
    info "Added LANGFLOW_PORT=${LANGFLOW_PORT} to .env"
  fi

  ok "Langflow configured (port ${LANGFLOW_PORT})."
}

langflow_start() {
  step "Langflow — start"
  compose_up --profile langflow langflow
  ok "Langflow started on port ${LANGFLOW_PORT}."
}

langflow_stop() {
  step "Langflow — stop"
  compose_down --profile langflow langflow
  ok "Langflow stopped."
}

langflow_health() {
  health_probe "Langflow :${LANGFLOW_PORT}" "http://localhost:${LANGFLOW_PORT}/health"
}

langflow_restart() {
  langflow_stop
  langflow_start
}

langflow_destroy() {
  step "Langflow — destroy"
  compose_down --profile langflow langflow -v
  ok "Langflow destroyed."
}

langflow_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=langflow" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Langflow is running (port ${LANGFLOW_PORT})"
  else
    warn "Langflow is not running."
  fi
  langflow_health 2>/dev/null || true
}

# ── Standalone execution ──────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   langflow_install   ;;
    configure) langflow_configure ;;
    start)     langflow_start     ;;
    stop)      langflow_stop      ;;
    restart)   langflow_restart   ;;
    health)    langflow_health    ;;
    status)    langflow_status    ;;
    destroy)   langflow_destroy   ;;
    default)
      langflow_install
      langflow_configure
      langflow_start
      langflow_health
      ;;
  esac
fi
