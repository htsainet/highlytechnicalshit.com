#!/usr/bin/env bash
# scripts/components/llama-swap/llama-swap.sh — llama-swap LLM router: install, start, health
#
# Standalone usage:
#   ./scripts/components/llama-swap/llama-swap.sh              # full: install + configure + start + health
#   ./scripts/components/llama-swap/llama-swap.sh --install    # install only
#   ./scripts/components/llama-swap/llama-swap.sh --configure  # configure only
#   ./scripts/components/llama-swap/llama-swap.sh --start      # start only
#   ./scripts/components/llama-swap/llama-swap.sh --stop       # stop
#   ./scripts/components/llama-swap/llama-swap.sh --restart    # restart (stop + start)
#   ./scripts/components/llama-swap/llama-swap.sh --health     # health check only
#   ./scripts/components/llama-swap/llama-swap.sh --status     # show status + port + health
#   ./scripts/components/llama-swap/llama-swap.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration ────────────────────────────────────────────────────────────
LLAMA_SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"
LLAMA_SWAP_CONFIG="$REPO_DIR/config/llama-swap.yaml"

# ── Functions ────────────────────────────────────────────────────────────────

# llamaswap_install — Pull the llama-swap image via compose
llamaswap_install() {
  step "llama-swap — pull image"
  compose_pull --profile llama-swap
  ok "llama-swap image pulled."
}

# llamaswap_configure — Validate config file exists
llamaswap_configure() {
  step "llama-swap — configure"
  if [[ ! -f "$LLAMA_SWAP_CONFIG" ]]; then
    fail "llama-swap config not found: $LLAMA_SWAP_CONFIG"
    return 1
  fi
  info "Config: $LLAMA_SWAP_CONFIG"
  info "Port: ${LLAMA_SWAP_PORT} (unified LLM endpoint)"
  ok "llama-swap configured."
}

# llamaswap_start — Bring up llama-swap via compose
llamaswap_start() {
  step "llama-swap — start"
  compose_up --profile llama-swap
  ok "llama-swap started on port ${LLAMA_SWAP_PORT}."
}

# llamaswap_stop — Bring down llama-swap
llamaswap_stop() {
  step "llama-swap — stop"
  compose_down --profile llama-swap
  ok "llama-swap stopped."
}

# llamaswap_health — Probe the llama-swap health endpoint
llamaswap_health() {
  health_probe "llama-swap :${LLAMA_SWAP_PORT}" "http://localhost:${LLAMA_SWAP_PORT}/health"
}

llamaswap_restart() {
  llamaswap_stop
  llamaswap_start
}

llamaswap_destroy() {
  step "llama-swap — destroy"
  compose_down --profile llama-swap -v
  ok "llama-swap destroyed."
}

llamaswap_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=llama-swap" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "llama-swap is running (port ${LLAMA_SWAP_PORT})"
  else
    warn "llama-swap is not running."
  fi
  llamaswap_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   llamaswap_install   ;;
    configure) llamaswap_configure ;;
    start)     llamaswap_start     ;;
    stop)      llamaswap_stop      ;;
    restart)   llamaswap_restart   ;;
    health)    llamaswap_health    ;;
    status)    llamaswap_status    ;;
    destroy)   llamaswap_destroy   ;;
    default)
      llamaswap_install
      llamaswap_configure
      llamaswap_start
      llamaswap_health
      ;;
  esac
fi
