# HTS-AI-Stack — Next Session Plan
# Created: 2026-04-15
# Context: Continuation of NAS mirroring / model cache / wizard work

---

## TASK 1: Fix 23 Stale NAS References

### Background
All NAS paths were standardized in this session:
- Old: `/mnt/nas/llm-cache/*`, `/mnt/ai_models`, `/mnt/nas-backups`, `/mnt/nas-timeshift`
- New: `/mnt/htsai-model-backup`, `/mnt/htsai-docker-volume-backup`, `/mnt/htsai-timeshift-backup`
- NAS config moved from repo `.env` to `~/.config/htsai/nas.env`

But 8 files still have old paths. Fix them all.

### Files to Update

#### 1. `config/profiles/core.json` (lines ~86, 88, 90)
Change these three values in the `"nas"` section:
```
"model_cache_mount": "/mnt/ai_models"         →  "/mnt/htsai-model-backup"
"docker_backup_mount": "/mnt/nas-backups"     →  "/mnt/htsai-docker-volume-backup"
"timeshift_mount": "/mnt/nas-timeshift"       →  "/mnt/htsai-timeshift-backup"
```

#### 2. `config/profiles/full-boat.json` (lines ~90, 92, 94)
Same 3 changes as core.json above.

#### 3. `.last-applied.json` (lines ~86, 88, 90)
Same 3 changes. This is an auto-generated snapshot but should be updated to match.

#### 4. `config/wizard/ai_stack_setup.py` (line ~199)
Change default mount point for network share:
```python
# OLD:
questionary.text("Network share mount point:", default="/mnt/ai_models", style=STYLE).ask()
# NEW:
questionary.text("Network share mount point:", default="/mnt/htsai-model-backup", style=STYLE).ask()
```

#### 5. `config/wizard/ai_stack_setup.sh` (lines ~508-510, 539-541, 700, 707, 714, 726)
Update 7 default path values. These appear in two places (variable init + UI prompts):
```bash
# Variable initialization (appears twice, ~508-510 and ~539-541):
NAS_MODEL_CACHE_MOUNT="/mnt/ai_models"      →  "/mnt/htsai-model-backup"
NAS_DOCKER_BACKUP_MOUNT="/mnt/nas-backups"   →  "/mnt/htsai-docker-volume-backup"
NAS_TIMESHIFT_MOUNT="/mnt/nas-timeshift"     →  "/mnt/htsai-timeshift-backup"

# UI prompt defaults (~700, 707, 714, 726):
"/mnt/ai_models"      →  "/mnt/htsai-model-backup"
"/mnt/nas-backups"     →  "/mnt/htsai-docker-volume-backup"
"/mnt/nas-timeshift"   →  "/mnt/htsai-timeshift-backup"
```
NOTE: First determine if the Bash wizard is still in use. Check what `install.sh`
calls — if it only uses the Python wizard, add a deprecation comment at the top of
the Bash wizard file instead of updating paths.

#### 6. `backups/docker/backup-volumes.sh` (lines ~9, 16, 38, 81)
```bash
# Line 9 (comment):
# OLD: "Requires: NAS mounted at /mnt/nas/llm-cache (setup-nas-mount.sh)"
# NEW: "Requires: NAS mounted at /mnt/htsai-docker-volume-backup (scripts/host/nas-setup.sh)"

# Line 16 (help text):
# OLD: "(default: /mnt/nas/llm-cache/backups/volumes)"
# NEW: "(default: /mnt/htsai-docker-volume-backup/backups/volumes)"

# Line 38 (default destination):
# OLD: DEST="/mnt/nas/llm-cache/backups/volumes"
# NEW: DEST="/mnt/htsai-docker-volume-backup/backups/volumes"

# Line 81 (error message):
# OLD: "Check: systemctl status nas-llm-cache.service"
# NEW: "Check: mountpoint -q /mnt/htsai-docker-volume-backup"
```

#### 7. `backups/synology/setup-nas-mount.sh` — REMOVE ENTIRE FILE
This script creates a deprecated `nas-llm-cache.service` for a single SMB mount.
It is fully replaced by `scripts/host/nas-setup.sh`. Delete the file.

#### 8. `scripts/host/tools.sh` (line ~153)
MCP filesystem config references `/mnt/nas`. Determine if this VS Code MCP
integration is still used. If yes, update to `/mnt/htsai-model-backup`.
If no, remove the MCP block.

### Verification
After all changes:
```bash
# Confirm no old paths remain:
grep -rn '/mnt/nas/' . --include='*.sh' --include='*.py' --include='*.json' --include='*.md' | grep -v node_modules | grep -v .git
grep -rn '/mnt/ai_models' . --include='*.sh' --include='*.py' --include='*.json'
grep -rn '/mnt/nas-backups' . --include='*.sh' --include='*.py' --include='*.json'
grep -rn '/mnt/nas-timeshift' . --include='*.sh' --include='*.py' --include='*.json'
grep -rn 'llm-cache' . --include='*.sh' --include='*.py' --include='*.json'
grep -rn 'nas-llm-cache' . --include='*.sh' --include='*.py' --include='*.json'
```
All should return zero results.

---

## TASK 2: Multi-Select Image Generation Engines

### Background
Currently, both the Python and Bash wizards only allow picking ONE image generation
engine (radio/single-select). The user wants checkbox/multi-select so multiple
engines can run simultaneously for comparison.

### Current Architecture

**Python wizard** (`config/wizard/ai_stack_setup.py`, `choose_images()` ~line 245):
- Uses `questionary.select()` (single choice)
- Returns `config["engine"]` as a single string value
- Options: `stable_diffusion`, `comfyui`, `invokeai`, `fooocus`

**Bash wizard** (`config/wizard/ai_stack_setup.sh`, ~line 759):
- Uses `wt_menu` (single choice via whiptail)
- Same 4 options

**apply_config.sh** (~line 237-245):
- Reads `images.engine` as a single string
- Sets `SD_ENABLED=true` OR `COMFYUI_ENABLED=true` (mutually exclusive)
- InvokeAI and Fooocus have NO corresponding `*_ENABLED` flags yet
- InvokeAI and Fooocus have NO Docker services yet (only conflict detection exists)

### Changes Required

#### Step 1: Python wizard — switch to multi-select
In `config/wizard/ai_stack_setup.py`, function `choose_images()`:
```python
# OLD:
config["engine"] = questionary.select("Image generation engine:", choices=[...]).ask()

# NEW:
config["engines"] = questionary.checkbox(
    "Select image generation engines (space to toggle, enter to confirm):",
    choices=[
        questionary.Choice("Stable Diffusion  — Full control, GPU heavy",  value="stable_diffusion"),
        questionary.Choice("ComfyUI           — Node-based SD pipeline",   value="comfyui"),
        questionary.Choice("InvokeAI          — Polished SD UI",           value="invokeai"),
        questionary.Choice("Fooocus           — Simple SD interface",      value="fooocus"),
    ],
    style=STYLE,
).ask()
```
Note: key changes from `"engine"` (string) to `"engines"` (list).

#### Step 2: Bash wizard — switch to whiptail checklist
In `config/wizard/ai_stack_setup.sh`, replace `wt_menu` with `whiptail --checklist`.
Each option gets an ON/OFF toggle:
```bash
IMAGES_ENGINES=$(whiptail --title "Image Generation" \
  --checklist "Select engines (space to toggle):" 14 $W 4 \
  "stable_diffusion" "Stable Diffusion  — Full control, GPU heavy" OFF \
  "comfyui"          "ComfyUI           — Node-based SD pipeline"  OFF \
  "invokeai"         "InvokeAI          — Polished SD UI"          OFF \
  "fooocus"          "Fooocus           — Simple SD interface"     OFF \
  3>&1 1>&2 2>&3)
```

#### Step 3: apply_config.sh — handle list of engines
```python
# OLD:
engine = images.get("engine", "")
kvs.append(("SD_ENABLED", "true" if engine == "stable_diffusion" else "false"))
kvs.append(("COMFYUI_ENABLED", "true" if engine == "comfyui" else "false"))

# NEW:
engines = images.get("engines", [])
# Backward compat: if old single "engine" key exists, wrap it in a list
if not engines and images.get("engine"):
    engines = [images["engine"]]
kvs.append(("SD_ENABLED", "true" if "stable_diffusion" in engines else "false"))
kvs.append(("COMFYUI_ENABLED", "true" if "comfyui" in engines else "false"))
kvs.append(("INVOKEAI_ENABLED", "true" if "invokeai" in engines else "false"))
kvs.append(("FOOOCUS_ENABLED", "true" if "fooocus" in engines else "false"))
```

#### Step 4: Profile JSON schemas
Update `config/profiles/core.json` and `config/profiles/full-boat.json`:
```json
"images": {
  "enabled": true,
  "engines": ["stable_diffusion"],   // was "engine": "stable_diffusion"
  "gpu_layers": "All"
}
```

#### Step 5: Docker services for InvokeAI and Fooocus
These two engines are listed as wizard options but DON'T have Docker services yet:
- No `docker/invokeai/Dockerfile`
- No `docker/fooocus/Dockerfile`
- No entries in `docker-compose.yml`

**Options:**
- A) Add Dockerfiles + compose entries for both (full implementation)
- B) Mark them as "coming soon" in the wizard with a note
- C) Only enable the checkbox for engines that have Docker services

**Recommendation:** Option C for now — only show `stable_diffusion` and `comfyui`
as selectable, with InvokeAI/Fooocus greyed out or marked "(coming soon)".
Implement the Dockerfiles as a separate task.

#### Step 6: GPU layers question
Currently asked once for the single engine. With multiple engines, either:
- Ask once and apply to all (simpler)
- Ask per-engine (more control but noisy)
**Recommendation:** Ask once, apply to all.

---

## TASK 3: Multi-Select Audio/Voice Engines

### Current Architecture

**Python wizard** (`config/wizard/ai_stack_setup.py`, `choose_voice()` ~line 205):
- STT: single-select between `whisper`, `faster_whisper`, `vosk`
- TTS: single-select between `piper`, `coqui`, `espeak`
- Wake word: yes/no toggle

**apply_config.sh**:
- ⚠️ Voice config is NOT wired in apply_config.sh at all! The wizard collects
  the choices but nothing writes STT/TTS _ENABLED flags to .env.

**Docker services that exist:**
- `docker/faster-whisper/` — Faster Whisper via speaches (STT)
- `docker/vosk/` — Vosk offline STT
- `docker/coqui-tts/` — Coqui TTS
- `docker/audio-flamingo/` — Audio Flamingo (not in wizard yet)
- No `docker/piper/` or `docker/espeak/` directories

### Changes Required

#### Step 1: Python wizard — switch to multi-select for both STT and TTS
```python
# STT — checkbox:
config["stt_engines"] = questionary.checkbox(
    "Select speech-to-text engines:",
    choices=[
        questionary.Choice("Faster-Whisper  — Optimised local STT (GPU)",  value="faster_whisper"),
        questionary.Choice("Vosk            — Lightweight offline STT",    value="vosk"),
        questionary.Choice("Audio Flamingo  — Audio understanding model",  value="audio_flamingo"),
    ],
    style=STYLE,
).ask()

# TTS — checkbox:
config["tts_engines"] = questionary.checkbox(
    "Select text-to-speech engines:",
    choices=[
        questionary.Choice("Coqui TTS  — High quality neural TTS",  value="coqui"),
        questionary.Choice("Piper      — Fast local neural TTS",    value="piper"),
    ],
    style=STYLE,
).ask()
```

#### Step 2: apply_config.sh — add voice engine flags
This is currently MISSING entirely. Add after the images section:
```python
# ── Voice → STT / TTS engine flags ──────────────────────────────────────────
voice = cfg.get("voice", {})
if voice.get("enabled"):
    stt = voice.get("stt_engines", [])
    # Backward compat for old single-select key
    if not stt and voice.get("stt"):
        stt = [voice["stt"]]
    tts = voice.get("tts_engines", [])
    if not tts and voice.get("tts"):
        tts = [voice["tts"]]
    kvs.append(("FASTER_WHISPER_ENABLED", "true" if "faster_whisper" in stt else "false"))
    kvs.append(("VOSK_ENABLED", "true" if "vosk" in stt else "false"))
    kvs.append(("AUDIO_FLAMINGO_ENABLED", "true" if "audio_flamingo" in stt else "false"))
    kvs.append(("COQUI_TTS_ENABLED", "true" if "coqui" in tts else "false"))
    kvs.append(("PIPER_ENABLED", "true" if "piper" in tts else "false"))
else:
    kvs.append(("FASTER_WHISPER_ENABLED", "false"))
    kvs.append(("VOSK_ENABLED", "false"))
    kvs.append(("AUDIO_FLAMINGO_ENABLED", "false"))
    kvs.append(("COQUI_TTS_ENABLED", "false"))
    kvs.append(("PIPER_ENABLED", "false"))
```

#### Step 3: Bash wizard — same checklist treatment
Convert `wt_menu` to `whiptail --checklist` for both STT and TTS.

#### Step 4: Profile JSON schemas
```json
"voice": {
  "enabled": true,
  "stt_engines": ["faster_whisper"],
  "tts_engines": ["coqui"],
  "wake_word": false
}
```

#### Step 5: Missing Docker services
- **Piper TTS** — no `docker/piper/` directory. Either create a Dockerfile or
  mark as "(coming soon)" in the wizard.
- **espeak** — lightweight, usually system-level package, not containerized.
  Consider removing from wizard or noting it's a host-level install.
- **Audio Flamingo** — `docker/audio-flamingo/` EXISTS but is not in the wizard.
  Add it to the STT checkbox list.

---

## TASK 4: Verify + Fix NAS Model Cache Auto-Restore

### Known Issue (observed 2026-04-15)
During install.sh, all models downloaded from internet even though NAS had copies.
Likely causes:
1. NFS mounts not active during install (nas-setup.sh runs separately)
2. `migrate-nas-folders.sh` hasn't run yet — NAS still has old flat layout
3. Ollama's NAS cache check in `ollama.sh` only LOGS that it's checking NAS
   but does NOT actually copy from NAS — it still runs `ollama pull` from internet.
   The NAS cache logic may be incomplete (just a stub/message, no actual rsync/copy).
   **READ THE FULL FUNCTION `_ollama_pull_if_missing` CAREFULLY** to confirm.
4. SD's NAS cache logic in `helpers.sh` looks more complete (has actual `cp` command)
   but the path might not match the new folder layout yet.

### Investigation Steps

1. Ollama checks `/mnt/htsai-model-backup/ollama/models` before downloading
2. SD checks `/mnt/htsai-model-backup/stable-diffusion/checkpoints` before downloading
3. Models that exist on NAS are copied locally without internet

### Test Steps
```bash
# 1. Ensure NFS is mounted
sudo mount -a
sudo ls /mnt/htsai-model-backup/ollama/models/

# 2. Run the migrate script to reorganize NAS folders (one-off)
sudo ./scripts/host/migrate-nas-folders.sh

# 3. Start ollama and pull a model — should detect NAS cache
docker compose up -d ollama
docker compose exec ollama ollama pull dolphin-mistral
# Watch for "[INFO] Pulling dolphin-mistral (checking NAS cache at ...)"

# 4. Verify models restored from NAS, not re-downloaded from internet
```

---

## TASK 5: Commit + Push Everything

### Unpushed Commits (on branch `feature/manifest-wizard`)
- `fed98f3` — Pin all Docker images, add MIRROR build arg, NAS setup wizard
- `929574e` — Strip sha256 digests, add push-to-nas.sh with skopeo fallback, add NAS Pester tests
- `f70ee7a` — Add model backup/migration scripts, NFS fixes
- `9c43047` — Wire NAS model cache to new mount paths, document nuke-and-pave workflow
- Plus whatever new commit(s) come from Tasks 1-3

### Push
```bash
cd ~/hts/hts-ai-stack
git push origin feature/manifest-wizard
```
NOTE: Must use the system git, NOT the snap-packaged git (which is missing git-remote-https).

---

## Priority Order
1. **Task 1** — Fix stale NAS refs (quick, prevents config bugs)
2. **Task 4** — Verify NAS auto-restore works after current install
3. **Task 5** — Push all commits
4. **Task 2** — Multi-select image engines (feature)
5. **Task 3** — Multi-select audio engines (feature)

---

## Key Technical Context

### Config file locations
- `~/.config/htsai/nas.env` — NAS host, shares, mounts (machine-level, persists)
- `.env` — MIRROR setting + all *_ENABLED flags (repo-level, disposable)
- `config/stack.json` — central stack config (NAS section with share/mount mappings)
- `config/profiles/*.json` — wizard profile templates

### Wizard architecture
- **Python wizard**: `config/wizard/ai_stack_setup.py` — uses `questionary` library
- **Bash wizard**: `config/wizard/ai_stack_setup.sh` — uses `whiptail`
- **Config applier**: `config/wizard/apply_config.sh` — reads wizard output JSON,
  writes *_ENABLED flags to `.env`. Contains embedded Python (heredoc).
- Check which wizard `install.sh` actually calls to determine if bash wizard is live.

### Docker compose patterns
- Services use `profiles:` to be conditionally started
- `*_ENABLED=true` in `.env` controls whether compose includes the service
- Each service has a `docker/*/Dockerfile` with `ARG MIRROR=` for NAS registry pull
