# FEATURE-037 — DeerFlow gVisor Agent Sandbox Integration

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | MEDIUM |
| **Effort** | 2–4 hours |
| **Risk** | Low — config change + runtime flag only |
| **Target Release** | v0.6.0 |
| **Depends on** | FEATURE-012 (gVisor runtime installed on host) |
| **Blocks** | Nothing |

## Problem

DeerFlow currently executes LLM-generated code inside the DeerFlow container
itself (`LocalSandboxProvider`, `allow_host_bash: true`). While Docker provides
a basic container boundary, there is no syscall-level isolation — a malicious
or runaway agent payload can make arbitrary kernel calls within that container.

Before hardening this, we need operational experience with DeerFlow as-is to
understand which syscalls and tools agent code actually needs at runtime.

## Solution

Two complementary layers, applied after observing DeerFlow in production:

### Layer 1 — Container Runtime (easy)

Add `runtime: runsc` to the DeerFlow service in `docker-compose.yml`. This
wraps the entire DeerFlow container under gVisor's user-space kernel (Sentry),
intercepting all syscalls from the container — including agent-executed code.

```yaml
# docker-compose.yml — deerflow service
deerflow:
  runtime: runsc   # ← add this line
  ...
```

No code changes required. Requires FEATURE-012 host prerequisite (runsc
installed and registered as a Docker runtime).

### Layer 2 — Remote Sandbox API (optional, future)

If Layer 1 is too restrictive (e.g., syscall compatibility issues), switch
DeerFlow's sandbox provider to POST code to the gVisor sandbox container
(`http://hts-ai-gvisor-sandbox:18791`) for execution. This keeps DeerFlow
itself under a standard runtime while isolating code execution in the gVisor
container.

Requires a custom `deerflow.sandbox.remote:RemoteSandboxProvider` or
equivalent plugin. Deferred until DeerFlow's sandbox API is better understood.

## OpenSpace Assessment

OpenSpace is an MCP server — it delegates tool execution back to the LLM
client (Open WebUI, etc.). It does not execute agent-generated code directly.
No sandbox changes needed unless OpenSpace skills are added that run arbitrary
code.

## Implementation Steps

1. Confirm FEATURE-012 is complete (runsc on host, Docker runtime registered)
2. Review DeerFlow logs for syscall patterns from actual agent runs
3. Test `runtime: runsc` on DeerFlow container in dev:
   `docker run --rm --runtime=runsc hts-ai-deerflow echo ok`
4. If clean, add `runtime: runsc` to `docker-compose.yml` deerflow service
5. Run `scripts/utils/refresh-status.sh` and verify DeerFlow healthcheck passes
6. Observe agent runs for syscall denial errors in DeerFlow logs
7. Document any `seccomp` or `gVisor` profile tuning needed

## Risks

- gVisor supports ~70% of Linux syscalls. DeerFlow's Python dependencies or
  agent tools may hit unsupported syscalls (e.g., `io_uring`, some `ptrace`
  calls). Mitigated by testing before deploying.
- Layer 2 (remote sandbox) requires understanding DeerFlow's sandbox plugin API
  — not yet documented well enough to implement confidently.

## Decision Point

After observing DeerFlow in production, choose:

1. **Layer 1 only** — `runtime: runsc` wraps the whole container (simplest)
2. **Layer 2 only** — remote sandbox API, DeerFlow runs normally
3. **Both** — defense in depth (recommended if syscall compat confirmed)
4. **Neither** — Docker boundary is sufficient given access controls
