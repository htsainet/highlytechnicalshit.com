#!/usr/bin/env bash
# Aider – AI pair programming in your terminal (host tool)
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# shellcheck source=scripts/lib/common.sh
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=scripts/lib/health.sh
source "$REPO_DIR/scripts/lib/health.sh"

###############################################################################
# Lifecycle
###############################################################################

aider_install() {
  log_info "Installing Aider …"
  if command -v aider &>/dev/null; then
    log_ok "Aider is already installed"
    return 0
  fi

  # Prefer pipx for isolated install; fall back to pip
  if command -v pipx &>/dev/null; then
    pipx install aider-chat
  else
    python3 -m pip install --user aider-chat
  fi
  hash -r

  if command -v aider &>/dev/null; then
    log_ok "Aider installed successfully"
  else
    log_warn "Aider binary not found after install — check PATH"
    return 1
  fi
}

aider_configure() {
  log_info "Configuring Aider for local Ollama …"

  local config_file="$HOME/.aider.conf.yml"
  if [[ ! -f "$config_file" ]]; then
    cat > "$config_file" <<'CONF'
# Aider — configured for stack's local Ollama
model: ollama/qwen2.5-coder:7b
auto-commits: false
CONF
    log_ok "Created $config_file → Ollama model ollama/qwen2.5-coder:7b"
  else
    log_ok "Config already exists at $config_file"
  fi
}

aider_start() {
  log_info "Aider is a terminal tool — launch with: aider"
}

aider_stop()    { :; }
aider_restart() { :; }

aider_health() {
  if command -v aider &>/dev/null; then
    log_ok "Aider binary found: $(command -v aider)"
    return 0
  fi
  log_warn "Aider not found in PATH"
  return 1
}

aider_destroy() {
  log_info "Removing Aider …"
  if command -v pipx &>/dev/null; then
    pipx uninstall aider-chat 2>/dev/null || true
  else
    python3 -m pip uninstall -y aider-chat 2>/dev/null || true
  fi
  rm -f "$HOME/.aider.conf.yml"
  log_ok "Aider removed"
}

aider_status() {
  if command -v aider &>/dev/null; then
    echo "installed"
  else
    echo "not_installed"
  fi
}
