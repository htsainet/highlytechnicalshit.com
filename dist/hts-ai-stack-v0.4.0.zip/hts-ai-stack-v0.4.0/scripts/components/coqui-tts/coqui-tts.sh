#!/usr/bin/env bash
# scripts/components/coqui-tts/coqui-tts.sh — Coqui TTS: install, configure, start, health
#
# Coqui TTS with XTTS v2 — high-quality text-to-speech with voice cloning.
# GPU-accelerated with CUDA fallback to CPU.
#
# Standalone usage:
#   ./scripts/components/coqui-tts/coqui-tts.sh              # full: install + configure + start + health
#   ./scripts/components/coqui-tts/coqui-tts.sh --install    # install only (build image)
#   ./scripts/components/coqui-tts/coqui-tts.sh --configure  # configure only
#   ./scripts/components/coqui-tts/coqui-tts.sh --start      # start only
#   ./scripts/components/coqui-tts/coqui-tts.sh --stop       # stop
#   ./scripts/components/coqui-tts/coqui-tts.sh --restart    # restart (stop + start)
#   ./scripts/components/coqui-tts/coqui-tts.sh --health     # health check only
#   ./scripts/components/coqui-tts/coqui-tts.sh --status     # show status + port + health
#   ./scripts/components/coqui-tts/coqui-tts.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
COQUI_TTS_PORT="${COQUI_TTS_PORT:-5002}"

# ── Functions ────────────────────────────────────────────────────────────────

coqui_tts_install() {
  step "Coqui TTS — install"
  local dockerfile="$REPO_DIR/docker/coqui-tts/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    warn "Coqui TTS Dockerfile not found: $dockerfile"
    info "Create a Dockerfile based on idiap/coqui-ai-TTS with XTTS v2 model."
    return 1
  fi
  compose_build --profile coqui-tts
  ok "Coqui TTS image built."
}

coqui_tts_configure() {
  step "Coqui TTS — configure"
  info "REST API port: ${COQUI_TTS_PORT}"
  info "Model: XTTS v2 (multilingual, voice cloning capable)"

  local models_dir="$REPO_DIR/data/coqui-tts/models"
  mkdir -p "$models_dir"

  ok "Coqui TTS configured."
}

coqui_tts_start() {
  step "Coqui TTS — start"
  compose_up --profile coqui-tts
  ok "Coqui TTS started on port ${COQUI_TTS_PORT}."
}

coqui_tts_stop() {
  step "Coqui TTS — stop"
  compose_down --profile coqui-tts
  ok "Coqui TTS stopped."
}

coqui_tts_health() {
  local label="Coqui TTS :${COQUI_TTS_PORT}"
  printf "  %-35s" "$label"
  if curl -sf "http://localhost:${COQUI_TTS_PORT}/api/healthcheck" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${COQUI_TTS_PORT}/api/healthcheck)"
    return 1
  fi
}

coqui_tts_restart() {
  coqui_tts_stop
  coqui_tts_start
}

coqui_tts_destroy() {
  step "Coqui TTS — destroy"
  compose_down --profile coqui-tts -v
  ok "Coqui TTS destroyed."
}

coqui_tts_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=coqui-tts" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Coqui TTS is running (port ${COQUI_TTS_PORT})"
  else
    warn "Coqui TTS is not running."
  fi
  coqui_tts_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   coqui_tts_install   ;;
    configure) coqui_tts_configure ;;
    start)     coqui_tts_start     ;;
    stop)      coqui_tts_stop      ;;
    restart)   coqui_tts_restart   ;;
    health)    coqui_tts_health    ;;
    status)    coqui_tts_status    ;;
    destroy)   coqui_tts_destroy   ;;
    default)
      coqui_tts_install
      coqui_tts_configure
      coqui_tts_start
      coqui_tts_health
      ;;
  esac
fi
