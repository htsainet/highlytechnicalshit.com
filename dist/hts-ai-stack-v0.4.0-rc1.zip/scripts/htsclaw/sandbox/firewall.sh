#!/usr/bin/env bash
# scripts/htsclaw/sandbox/firewall.sh — UFW rules for htsclaw sandbox port
#
# Restricts the sandbox port (default 18792) to Tailscale + localhost only.
# Same pattern as NemoClaw's _setup_ufw but for the htsclaw port.
#
# Can be sourced or run standalone.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
HTSCLAW_PORT="${HTSCLAW_PORT:-18792}"
LLAMA_SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"

# ── Firewall setup ───────────────────────────────────────────────────────────

_ensure_sudo() {
  if sudo -n true 2>/dev/null; then return 0; fi
  info "Administrator privileges required."
  sudo -v || { fail "Sudo authentication failed."; }
}

# htsclaw_firewall — Configure UFW rules for the sandbox port.
# Allows access from Docker subnets (for host.openshell.internal) and
# Tailscale (100.64.0.0/10). Denies everything else.
htsclaw_firewall() {
  step "htsclaw — firewall (UFW)"
  _ensure_sudo

  if ! command -v ufw &>/dev/null; then
    info "Installing UFW..."
    sudo apt-get install -y ufw
  fi

  local docker_subnet="172.16.0.0/12"
  local tailscale_subnet="100.64.0.0/10"

  # ── SSH (don't lock yourself out) ──
  if ! sudo ufw status | grep -q "22/tcp"; then
    sudo ufw allow 22/tcp comment "SSH" >/dev/null
  fi

  # ── llama-swap: Docker/OpenShell sandboxes only ──
  if ! sudo ufw status | grep -q "${LLAMA_SWAP_PORT}/tcp.*ALLOW.*${docker_subnet}"; then
    info "Allowing llama-swap (:${LLAMA_SWAP_PORT}) from Docker subnet..."
    sudo ufw allow from "$docker_subnet" to any port "$LLAMA_SWAP_PORT" proto tcp \
      comment "llama-swap — Docker/OpenShell sandboxes" >/dev/null
  fi

  if ! sudo ufw status | grep -q "${LLAMA_SWAP_PORT}/tcp.*DENY"; then
    sudo ufw deny "$LLAMA_SWAP_PORT"/tcp comment "llama-swap — block LAN/WAN" >/dev/null
  fi

  # ── htsclaw sandbox port: Tailscale + localhost only ──
  if ! sudo ufw status | grep -q "${HTSCLAW_PORT}/tcp.*ALLOW.*${tailscale_subnet}"; then
    info "Allowing htsclaw (:${HTSCLAW_PORT}) from Tailscale subnet..."
    sudo ufw allow from "$tailscale_subnet" to any port "$HTSCLAW_PORT" proto tcp \
      comment "htsclaw — Tailscale access" >/dev/null
  fi

  if ! sudo ufw status | grep -q "${HTSCLAW_PORT}/tcp.*ALLOW.*127.0.0.0"; then
    info "Allowing htsclaw (:${HTSCLAW_PORT}) from localhost..."
    sudo ufw allow from 127.0.0.0/8 to any port "$HTSCLAW_PORT" proto tcp \
      comment "htsclaw — localhost access" >/dev/null
  fi

  if ! sudo ufw status | grep -q "${HTSCLAW_PORT}/tcp.*DENY"; then
    sudo ufw deny "$HTSCLAW_PORT"/tcp comment "htsclaw — block LAN/WAN" >/dev/null
  fi

  # ── Enable UFW if not already active ──
  if ! sudo ufw status | grep -q "Status: active"; then
    info "Enabling UFW..."
    sudo ufw --force enable
  else
    info "UFW already active"
  fi

  ok "Firewall configured — htsclaw (:${HTSCLAW_PORT}) restricted to Tailscale + localhost."
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  htsclaw_firewall
fi
