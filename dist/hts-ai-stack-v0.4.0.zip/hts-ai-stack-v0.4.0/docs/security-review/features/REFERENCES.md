# Security Feature Index

Active security hardening proposals tracked by release target.

## Current Release (v0.4.0 — core infrastructure)

No security features scheduled — v0.4.0 focus is the install pipeline foundation.

## Next Minor Release (v0.5.0)

| Feature | Priority | Status | Threat | File |
|---------|----------|--------|--------|------|
| UFW Default-Deny + Bind to Localhost | HIGH | Proposed | 12 unauthenticated services exposed on LAN | [SECURITY-000.md](SECURITY-000.md) |
| Tailscale ACL Enforcement | HIGH | Proposed | Unrestricted tailnet access to all services | [SECURITY-001.md](SECURITY-001.md) |
| fail2ban — SSH + Service Brute Force | MEDIUM | Proposed | Brute force / credential stuffing on SSH and web UIs | [SECURITY-003.md](SECURITY-003.md) |
| Observability & Audit Trail | HIGH | Proposed | Undetectable compromise without centralized logging | [SECURITY-005.md](SECURITY-005.md) |
| Data Retention & Cleanup Policy | MEDIUM | Proposed | Unbounded sensitive data accumulation in volumes | [SECURITY-006.md](SECURITY-006.md) |

## Future Releases (v0.6.0+)

| Feature | Priority | Status | Threat | File |
|---------|----------|--------|--------|------|
| Docker Network Segmentation | MEDIUM | Proposed | Container lateral movement after compromise | [SECURITY-002.md](SECURITY-002.md) |
| Service Authentication Gaps | HIGH | Proposed | Unauthenticated inference, metrics exposure, data exfil | [SECURITY-004.md](SECURITY-004.md) |
| Agent Persona Integrity & Drift Detection | HIGH | Proposed | Prompt injection persistence via modified persona files | [SECURITY-007.md](SECURITY-007.md) |
| Skill Supply Chain Vetting | MEDIUM | Proposed | Malicious skills execute arbitrary code, exfiltrate data | [SECURITY-008.md](SECURITY-008.md) |

## Threat Model Cross-Reference

Maps `SECURITY-###` features to threat categories in [../CONTEXT.md](../CONTEXT.md).

| Threat | SECURITY-### |
|--------|-------------|
| Prompt injection → unauthorized access or exfiltration | SECURITY-004, SECURITY-007 |
| Container escape / privilege escalation | SECURITY-002 |
| Reverse proxy misconfiguration | SECURITY-000 |
| Sensitive data retention | SECURITY-004, SECURITY-006 |
| Audit gaps — unobservable = undetectable compromise | SECURITY-005 |
| Brute force / credential stuffing | SECURITY-003 |
| Unrestricted network access across tailnet | SECURITY-001 |
| LAN exposure of unauthenticated services | SECURITY-000, SECURITY-004 |
| Agent persona drift / prompt injection persistence | SECURITY-007 |
| Malicious skill supply chain | SECURITY-008 |
| Unbounded data accumulation / no cleanup | SECURITY-006 |
| Cross-service blast radius via shared volumes / pooled secrets | SECURITY-009 |
