# Model Registry Resources

* **model-registry.json** – The master list of models. See the file at the repository root.
* **scripts/lib/model.sh** – Bash library exposing `model_get_url`, `model_get_license`, and a generic download stub.
* **Component manifests** – Updated to use `options_source`/`default_source`. Example: `stable-diffusion.manifest.json`.
* **Component scripts** – Source the library and call `model_download_if_missing`. Example snippet from `stable-diffusion.sh`:
  ```bash
  source "${REPO_DIR}/scripts/lib/model.sh"
  model_download_if_missing "stable_diffusion" "checkpoint" "$SD_CHECKPOINT" "$sd_volume" "$NAS_SD_CACHE"
  ```
* **Wizard integration** – The wizard automatically expands the `options_source` pointers into selectable lists for the user.

When adding a new service:
1. Add its model definitions to `model-registry.json`.
2. Update the component’s manifest with `options_source`/`default_source`.
3. In the component script, call `model_download_if_missing` with the appropriate service/type.

All future model additions follow this same workflow, guaranteeing consistency and compliance.
