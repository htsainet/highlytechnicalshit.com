$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/gitea'
    $script:ComponentScript = Join-Path $script:ComponentDir 'gitea.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'gitea.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'gitea file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists (TDD — needs creation)' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'gitea component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines gitea_install function' {
        $script:ComponentContent | Should -Match 'gitea_install\s*\(\)'
    }

    It 'defines gitea_configure function' {
        $script:ComponentContent | Should -Match 'gitea_configure\s*\(\)'
    }

    It 'defines gitea_start function' {
        $script:ComponentContent | Should -Match 'gitea_start\s*\(\)'
    }

    It 'defines gitea_stop function' {
        $script:ComponentContent | Should -Match 'gitea_stop\s*\(\)'
    }

    It 'defines gitea_health function' {
        $script:ComponentContent | Should -Match 'gitea_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/gitea/gitea\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'gitea no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/gitea\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/gitea/gitea\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
