#!/usr/bin/env bash
# backups/backup-volumes.sh — Back up named Docker volumes to the NAS
#
# Volumes containing irreplaceable state are paused, tarred into a
# datestamped archive on the NAS, then unpaused. Model/cache volumes
# (ollama, bitnet, sd_models) are skipped — they are re-seeded from
# seed-model-cache.sh.
#
# Requires: NAS mounted at /mnt/nas/llm-cache (setup-nas-mount.sh)
#
# Usage:
#   ./backups/backup-volumes.sh [options]
#
# Options:
#   --dest <path>   Backup destination directory
#                   (default: /mnt/nas/llm-cache/backups/volumes)
#   --no-pause      Skip pause/unpause (faster, slight risk of dirty state)
#   --dry-run       Print every action without making changes
#   -h, --help      Show this help

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# shellcheck source=../../scripts/install/tooling/ui.sh
source "$REPO_DIR/scripts/install/tooling/ui.sh"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
skip()  { echo -e "${YELLOW}[SKIP]${NC} $*"; }
step()  { echo -e "\n${CYAN}══ $* ══${NC}"; }
fail()  { echo -e "${RED}[FAIL]${NC} $*" >&2; exit 1; }

# ── Defaults ───────────────────────────────────────────────────────────────────
DEST="/mnt/nas/llm-cache/backups/volumes"
DO_PAUSE=true
DRY_RUN=false
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

# ── Argument parsing ───────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dest)     DEST="$2"; shift 2 ;;
    --no-pause) DO_PAUSE=false; shift ;;
    --dry-run)  DRY_RUN=true;   shift ;;
    -h|--help)  grep '^# ' "$0" | sed 's/^# \?//'; exit 0 ;;
    *) fail "Unknown option: $1" ;;
  esac
done

run() {
  if "$DRY_RUN"; then
    echo "  [dry-run] $*"
  else
    "$@"
  fi
}

htsai_banner "backup-volumes"

# ── Preflight ──────────────────────────────────────────────────────────────────
step "Preflight"

command -v docker &>/dev/null || fail "docker not found"

if ! "$DRY_RUN"; then
  if ! mountpoint -q "$(dirname "$DEST")" && ! mountpoint -q "$DEST"; then
    # Walk up to find the nearest mounted parent
    _check="$DEST"
    _mounted=false
    while [[ "$_check" != "/" ]]; do
      if mountpoint -q "$_check" 2>/dev/null; then
        _mounted=true; break
      fi
      _check="$(dirname "$_check")"
    done
    if ! "$_mounted"; then
      fail "Destination ${DEST} is not under a mounted filesystem.\n  Is the NAS mounted? Check: systemctl status nas-llm-cache.service"
    fi
  fi
fi

run mkdir -p "$DEST"
info "Destination : ${DEST}"
info "Timestamp   : ${TIMESTAMP}"
"$DRY_RUN" && info "Mode        : DRY RUN"

# ── Volume map ─────────────────────────────────────────────────────────────────
# Format: "volume_name:compose_service_to_pause:compose_file"
# compose_service / compose_file may be empty ("") to skip pause/unpause.
#
# Intentionally EXCLUDED (re-seedable from NAS or re-pullable):
#   ollama_data, ollama_prod, ollama_test  — model weights, re-seeded
#   bitnet_models, bitnet_prod, bitnet_test — model weights
#   sd_models_prod, sd_models_test          — checkpoints, re-seeded
#
# Intentionally INCLUDED (irreplaceable user state):
#   open_webui_* — chat history, custom model configs, user accounts
#   sillytavern_* — characters, personas, chat logs
#   comfyui_*     — custom workflows
#   openshell-cluster-nemoclaw — OpenClaw/NemoClaw k3s cluster state (sandboxes, configs)
#   gitea_data    — Gitea repos, config, user accounts

declare -A PAUSE_SERVICE  # volume → service name to pause
declare -A PAUSE_FILE     # volume → compose file for that service

VOLUMES=(
  gitea_data
  open_webui_data
  open_webui_prod
  open_webui_test
  sillytavern_config
  sillytavern_config_test
  comfyui_models_test
  openshell-cluster-nemoclaw
)

# Map each stateful volume to the compose service that owns it
PAUSE_SERVICE[gitea_data]="gitea"
PAUSE_FILE[gitea_data]="$REPO_DIR/docker-compose.yml"

PAUSE_SERVICE[open_webui_data]="open-webui"
PAUSE_FILE[open_webui_data]="$REPO_DIR/docker-compose.yml"

PAUSE_SERVICE[open_webui_prod]="open-webui-prod"
PAUSE_FILE[open_webui_prod]="$REPO_DIR/instances/prod/docker-compose.yml"

PAUSE_SERVICE[open_webui_test]="open-webui-test"
PAUSE_FILE[open_webui_test]="$REPO_DIR/instances/test/docker-compose.yml"

PAUSE_SERVICE[sillytavern_config]="sillytavern-prod"
PAUSE_FILE[sillytavern_config]="$REPO_DIR/instances/prod/docker-compose.yml"

PAUSE_SERVICE[sillytavern_config_test]="sillytavern-test"
PAUSE_FILE[sillytavern_config_test]="$REPO_DIR/instances/test/docker-compose.yml"

PAUSE_SERVICE[comfyui_models_test]="comfyui-test"
PAUSE_FILE[comfyui_models_test]="$REPO_DIR/instances/test/docker-compose.yml"

# openshell-cluster-nemoclaw is managed by NemoClaw directly (not docker-compose).
# Leave PAUSE_SERVICE/PAUSE_FILE unset so the backup runs without pause/unpause.
# The volume captures k3s cluster state: sandbox configs, OpenClaw agent data.

# ── Backup function ────────────────────────────────────────────────────────────
backup_volume() {
  local vol="$1"
  local svc="${PAUSE_SERVICE[$vol]:-}"
  local cfile="${PAUSE_FILE[$vol]:-}"
  local archive="${DEST}/${vol}_${TIMESTAMP}.tar.gz"
  local paused=false

  info "Volume: ${vol}"

  # Verify volume exists
  if ! docker volume inspect "$vol" &>/dev/null; then
    skip "  ${vol} — volume not found (stack may not be running)"
    return
  fi

  # Pause owning service if requested
  if "$DO_PAUSE" && [[ -n "$svc" && -n "$cfile" && -f "$cfile" ]]; then
    if docker compose -f "$cfile" ps --quiet "$svc" 2>/dev/null | grep -q .; then
      info "  Pausing ${svc}..."
      run docker compose -f "$cfile" pause "$svc"
      paused=true
    else
      info "  ${svc} not running — skipping pause"
    fi
  fi

  # Create archive via a throwaway alpine container
  if "$DRY_RUN"; then
    echo "  [dry-run] docker run --rm -v ${vol}:/data -v ${DEST}:/backup alpine tar czf /backup/${vol}_${TIMESTAMP}.tar.gz -C /data ."
  else
    docker run --rm \
      -v "${vol}:/data:ro" \
      -v "${DEST}:/backup" \
      alpine \
      tar czf "/backup/${vol}_${TIMESTAMP}.tar.gz" -C /data . \
      && ok "  → ${archive}" \
      || { warn "  Archive failed for ${vol}"; }
  fi

  # Unpause
  if "$paused"; then
    run docker compose -f "$cfile" unpause "$svc"
    info "  Resumed ${svc}"
  fi
}

# ── Run backups ────────────────────────────────────────────────────────────────
step "Backing up volumes"

ERRORS=0
for vol in "${VOLUMES[@]}"; do
  backup_volume "$vol" || (( ERRORS++ )) || true
  echo ""
done

# ── Prune old backups (keep last 7 per volume) ────────────────────────────────
step "Pruning old archives (keep 7 per volume)"

if "$DRY_RUN"; then
  echo "  [dry-run] Would prune archives older than 7 per volume in ${DEST}"
else
  for vol in "${VOLUMES[@]}"; do
    # List archives for this volume, sorted oldest-first, delete beyond 7
    mapfile -t old < <(ls -1t "${DEST}/${vol}_"*.tar.gz 2>/dev/null | tail -n +8 || true)
    for f in "${old[@]}"; do
      rm -f "$f"
      info "Pruned: $(basename "$f")"
    done
  done
  ok "Pruning complete"
fi

# ── Summary ────────────────────────────────────────────────────────────────────
echo ""
if [[ $ERRORS -eq 0 ]]; then
  ok "All volumes backed up to ${DEST}"
else
  warn "${ERRORS} volume(s) encountered errors — check output above"
fi
echo ""
echo "  Restore a volume:"
echo "    docker run --rm -v <vol>:/data -v ${DEST}:/backup alpine \\"
echo "      tar xzf /backup/<vol>_<timestamp>.tar.gz -C /data"
echo ""
