# Tabby Component — CONTEXT

Last updated: 2026-04-21

## What is Tabby?

Tabby is a self-hosted, GPU-accelerated AI code-completion server. It
provides an OpenAI-compatible completion API that in-editor plugins
(VS Code, JetBrains, Vim/Neovim, etc.) point at for inline "ghost text"
completions, similar to GitHub Copilot but fully local.

- Source: <https://github.com/TabbyML/tabby>
- Docs: <https://tabby.tabbyml.com/>

## How it fits into the HTS AI Stack

A **containerized GPU service**, introduced by FEATURE-054. Runs in the
`hts-ai-tabby` container under Docker Compose (`profile: tabby`), binds
to host port `${TABBY_PORT:-8085}`, and uses CUDA on the same RTX GPU
as Ollama. Its model is distinct from the Ollama tier (default
`TabbyML/StarCoder-1B`) — Tabby runs its own weights optimized for
line-level completion latency rather than full-file editing.

```text
IDE plugin  →  http://<host>:${TABBY_PORT}/v1/completions  →  hts-ai-tabby  →  CUDA
```

Tabby does **not** route through llama-swap. It hosts its own model
loop because its latency budget (sub-100 ms typing cadence) is
incompatible with llama-swap's model-swap eviction.

## Install method

Compose-based — `install_type: compose` in the manifest, image built
from `docker/tabby/` (tag `hts-ai-tabby`). Lifecycle functions
(`tabby_install`, `_start`, `_stop`, `_health`, `_destroy`) all shell
out to `docker compose` helpers from `scripts/lib/compose.sh`.

## Files and structure

| File | Purpose |
|------|---------|
| `tabby.sh` | Lifecycle: install (build image), configure, start, stop, restart, health, destroy, status |
| `tabby.manifest.json` | Component metadata (install_type: compose; GPU reservation) |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and related features |

## Logging conventions

All log calls use the project-wide helpers defined in
`scripts/lib/common.sh`: `info`, `ok`, `warn`, `fail`, `step`. The
previously used `log_info` / `log_ok` / `log_warn` names were never
defined anywhere in `scripts/lib/` and have been renamed stack-wide —
see FEATURE-067 commit for the cleanup.

## VRAM coexistence with Ollama

Tabby holds its model **resident** (unlike llama-swap, which evicts on
tag switch). On the 12 GB RTX 3060 reference target, the StarCoder-1B
default uses ≈ 1.5 GB, leaving ≈ 10 GB for Ollama's active tag. If a
larger Tabby model is selected, cross-check against Ollama's expected
resident set — `config/llama-swap.yaml` single-resident mode assumes
the rest of VRAM is free.

## Related components

- Ollama (`scripts/components/ollama/`) — separate model backend;
  shares the GPU but not the model cache.
- Aider / OpenCode — file-editing agents (different latency profile,
  route through llama-swap).
- Gitea Runner (`scripts/components/gitea-runner/`) — sibling
  FEATURE-054 dev-tool.

See [usage.md](./usage.md) for command usage.
