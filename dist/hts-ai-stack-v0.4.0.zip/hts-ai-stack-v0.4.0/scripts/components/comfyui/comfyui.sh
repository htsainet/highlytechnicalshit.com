#!/usr/bin/env bash
# scripts/components/comfyui/comfyui.sh — ComfyUI workflow-based image generation
#
# Standalone usage:
#   ./scripts/components/comfyui/comfyui.sh                 # full: install + configure + start + seed + health
#   ./scripts/components/comfyui/comfyui.sh --install       # install only
#   ./scripts/components/comfyui/comfyui.sh --configure     # configure only
#   ./scripts/components/comfyui/comfyui.sh --start         # start only
#   ./scripts/components/comfyui/comfyui.sh --stop          # stop
#   ./scripts/components/comfyui/comfyui.sh --restart       # restart (stop + start)
#   ./scripts/components/comfyui/comfyui.sh --health        # health check only
#   ./scripts/components/comfyui/comfyui.sh --status        # show status + port + health
#   ./scripts/components/comfyui/comfyui.sh --destroy       # destroy (remove containers + volumes)
#   ./scripts/components/comfyui/comfyui.sh --seed-models   # download checkpoint models into volume
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
COMFYUI_CONTAINER="${COMFYUI_CONTAINER:-hts-ai-comfyui-1}"
COMFYUI_PORT="${COMFYUI_PORT:-8188}"
COMFYUI_DATA_DIR="${COMFYUI_DATA_DIR:-$REPO_DIR/data/comfyui}"
NAS_SD_CACHE="${NAS_SD_CACHE:-/mnt/htsai-model-backup/stable-diffusion/checkpoints}"

# ── Model registry ───────────────────────────────────────────────────────────
# Format: "filename|url|description|vram_gb"
# SD 1.5 base is always seeded. Others are prompted.
COMFYUI_MODEL_BASE=(
  "v1-5-pruned-emaonly.safetensors|https://huggingface.co/stable-diffusion-v1-5/stable-diffusion-v1-5/resolve/main/v1-5-pruned-emaonly.safetensors|SD 1.5 base (required seed)|2"
)

COMFYUI_MODELS_OPTIONAL=(
  "dreamshaper_v8.safetensors|https://huggingface.co/Lykon/DreamShaper/resolve/main/DreamShaper_8_pruned.safetensors|DreamShaper v8 — versatile, stylized realism (SD1.5 base)|2"
  "majicmixRealistic_v7.safetensors|https://huggingface.co/digiplay/majicMIX_realistic_v7/resolve/main/majicmixRealistic_v7.safetensors|majicMIX Realistic v7 — photorealistic portraits|2"
  "sd_xl_base_1.0.safetensors|https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/sd_xl_base_1.0.safetensors|SDXL 1.0 base — high quality, needs 6-8GB VRAM|8"
)

# ── Functions ────────────────────────────────────────────────────────────────

# comfyui_install — Pull the ComfyUI container image
comfyui_install() {
  step "ComfyUI — install"
  compose_build --profile comfyui
  ok "ComfyUI image built."
}

# comfyui_configure — Ensure .env has ComfyUI settings and data dirs exist
comfyui_configure() {
  step "ComfyUI — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^COMFYUI_PORT=" "$env_file" 2>/dev/null; then
    printf 'COMFYUI_PORT=%s\n' "$COMFYUI_PORT" >> "$env_file"
    info "Added COMFYUI_PORT=${COMFYUI_PORT} to .env"
  fi

  # Create bind-mount directories owned by the current user
  mkdir -p "${COMFYUI_DATA_DIR}/run" "${COMFYUI_DATA_DIR}/basedir"
  info "Data directories: ${COMFYUI_DATA_DIR}"

  ok "ComfyUI configured (port ${COMFYUI_PORT})."
}

# comfyui_start — Bring up ComfyUI via compose
comfyui_start() {
  step "ComfyUI — start"
  compose_up --profile comfyui
  ok "ComfyUI started on port ${COMFYUI_PORT}."
}

# comfyui_stop — Bring down ComfyUI
comfyui_stop() {
  step "ComfyUI — stop"
  compose_down --profile comfyui
  ok "ComfyUI stopped."
}

# comfyui_health — Probe the ComfyUI web UI
comfyui_health() {
  health_probe "ComfyUI :${COMFYUI_PORT}" "http://localhost:${COMFYUI_PORT}/"
}

# _comfyui_model_exists <filename> — returns 0 if checkpoint is already present
_comfyui_model_exists() {
  local filename="$1"
  [[ -f "${COMFYUI_DATA_DIR}/basedir/models/checkpoints/${filename}" ]]
}

# _comfyui_download_model <filename> <url> — downloads checkpoint into the basedir
_comfyui_download_model() {
  local filename="$1"
  local url="$2"
  local checkpoints_dir="${COMFYUI_DATA_DIR}/basedir/models/checkpoints"
  mkdir -p "$checkpoints_dir"

  # 0. Already exists — skip
  local dest="${checkpoints_dir}/${filename}"
  if [[ -f "$dest" ]]; then
    local size
    size=$(stat -c%s "$dest" 2>/dev/null || echo 0)
    if [[ "$size" -gt 1000000 ]]; then
      info "Already present: ${filename} ($(( size / 1048576 )) MB)"
      return 0
    fi
    # File is suspiciously small (partial download?) — re-download
    warn "Incomplete file: ${filename} (${size} bytes) — re-downloading"
    rm -f "$dest"
  fi

  # 1. NAS cache
  local nas_file="${NAS_SD_CACHE}/${filename}"
  if [[ -f "$nas_file" ]]; then
    local nas_size
    nas_size=$(stat -c%s "$nas_file" 2>/dev/null || echo 0)
    if [[ "$nas_size" -gt 1000000 ]]; then
      info "  Copying ${filename} from NAS cache..."
      cp "$nas_file" "${checkpoints_dir}/${filename}" \
        && ok "${filename} copied from NAS." && return 0 \
        || { warn "NAS copy failed — falling back to download."; }
    fi
  fi

  # 2. Internet download
  info "  Downloading ${filename}..."
  curl -fSL --retry 3 --retry-delay 5 --progress-bar \
    -o "${checkpoints_dir}/${filename}" "$url" \
    && ok "${filename} ready." \
    || fail "Download failed for ${filename}."
}

# comfyui_seed_models — Seed checkpoints into the ComfyUI basedir
# Always downloads SD 1.5 base; prompts via whiptail checklist for optional models.
comfyui_seed_models() {
  step "ComfyUI — seed models"

  mkdir -p "${COMFYUI_DATA_DIR}/basedir/models/checkpoints"

  # ── Required: SD 1.5 base ──────────────────────────────────────────────────
  local entry filename url desc
  for entry in "${COMFYUI_MODEL_BASE[@]}"; do
    filename="${entry%%|*}"; rest="${entry#*|}"; url="${rest%%|*}"; rest="${rest#*|}"; desc="${rest%%|*}"
    if _comfyui_model_exists "$filename"; then
      skip "comfyui: ${filename} already present"
    else
      info "Seeding base model: ${desc}"
      _comfyui_download_model "$filename" "$url"
    fi
  done

  # ── Optional models — whiptail checklist ──────────────────────────────────
  local checklist_args=()
  local -A model_map  # filename → "url"

  for entry in "${COMFYUI_MODELS_OPTIONAL[@]}"; do
    filename="${entry%%|*}"; rest="${entry#*|}"; url="${rest%%|*}"; rest="${rest#*|}"; desc="${rest%%|*}"; vram="${rest##*|}"
    if _comfyui_model_exists "$filename"; then
      skip "comfyui: ${filename} already present"
      continue
    fi
    checklist_args+=("$filename" "${desc} (~${vram}GB VRAM)" "OFF")
    model_map["$filename"]="$url"
  done

  if [[ ${#checklist_args[@]} -eq 0 ]]; then
    ok "All optional models already present."
    return
  fi

  local selected
  selected=$(whiptail \
    --title "ComfyUI — Optional Models" \
    --checklist "Space to select, Enter to confirm\n(SD 1.5 base already seeded)" \
    20 78 "${#COMFYUI_MODELS_OPTIONAL[@]}" \
    "${checklist_args[@]}" \
    3>&1 1>&2 2>&3) || { info "No optional models selected."; return; }

  # whiptail returns quoted space-separated filenames — strip quotes
  for filename in $selected; do
    filename="${filename//\"/}"
    url="${model_map[$filename]}"
    _comfyui_download_model "$filename" "$url"
  done

  ok "ComfyUI model seeding complete."
  info "Models at ${COMFYUI_DATA_DIR}/basedir/models/checkpoints/"
}

comfyui_restart() {
  comfyui_stop
  comfyui_start
}

comfyui_destroy() {
  step "ComfyUI — destroy"
  compose_down --profile comfyui -v
  ok "ComfyUI destroyed."
}

comfyui_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=comfyui" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "ComfyUI is running (port ${COMFYUI_PORT})"
  else
    warn "ComfyUI is not running."
  fi
  comfyui_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)     ACTION="install";     shift ;;
      --configure)   ACTION="configure";   shift ;;
      --start)       ACTION="start";       shift ;;
      --stop)        ACTION="stop";        shift ;;
      --restart)     ACTION="restart";     shift ;;
      --health)      ACTION="health";      shift ;;
      --status)      ACTION="status";      shift ;;
      --destroy)     ACTION="destroy";     shift ;;
      --seed-models) ACTION="seed-models"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)     comfyui_install      ;;
    configure)   comfyui_configure    ;;
    start)       comfyui_start        ;;
    stop)        comfyui_stop         ;;
    restart)     comfyui_restart      ;;
    health)      comfyui_health       ;;
    status)      comfyui_status       ;;
    destroy)     comfyui_destroy      ;;
    seed-models) comfyui_seed_models  ;;
    default)
      comfyui_install
      comfyui_configure
      comfyui_start
      comfyui_seed_models
      comfyui_health
      ;;
  esac
fi
