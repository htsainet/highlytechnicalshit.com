# NVIDIA/NemoClaw#1685 — sandbox-base:latest ships stale OpenClaw version

| Field | Value |
|-------|-------|
| **Repo** | [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) |
| **Issue** | [#1685](https://github.com/NVIDIA/NemoClaw/issues/1685) |
| **State** | OPEN |
| **Severity** | high |
| **Labels** | bug, status: triage, NV QA |
| **Opened** | 2026-04-09 |
| **Subscribed** | Yes (GraphQL updateSubscription) |

## Impact on us

Both sandboxes (`hts-ai-openshell-nemoclaw-gpu` on port 18789, `hts-ai-assistant-cpu` on port 18790) run OpenClaw 2026.3.11 despite 2026.4.9 being the advertised current release. The `sandbox-base:latest` Docker image has not been rebuilt to include the newer OpenClaw version.

Affected files:

- `scripts/components/nemoclaw/nemoclaw.sh` — version still bottlenecked by the sandbox base image. (Note: our local `_pre_extract_openclaw()` workaround for GH-503 was removed in commit `5d3451b` on 2026-04-18 when we switched to NVIDIA's official installer; the equivalent `tar` pre-extract workaround is now performed by NVIDIA's installer itself, so GH-503 is upstream's to resolve.)
- `scripts/utils/upgrade-nemoclaw.sh` — upgrade script cannot bump OpenClaw past what the base image ships

## Workaround

None. We cannot override the OpenClaw version embedded in the sandbox base image. Waiting on NVIDIA to rebuild and push a new `sandbox-base:latest`.

## Action when resolved

1. `docker pull` the updated `sandbox-base:latest` image
2. Run `nemoclaw onboard` for both sandboxes to rebuild on the new base
3. Verify OpenClaw version: `curl http://localhost:18789/api/version`
4. Update the dependency inventory in `docs/upstream/REFERENCES.md`

## Status log

- **2026-04-08** — Discovered during GPU sandbox re-onboard. Fresh `nemoclaw onboard` completed (8/8 steps, exit 0) but OpenClaw still 2026.3.11. Force-pulled `sandbox-base:latest` — image dated April 8 still ships 2026.3.11.
- **2026-04-09** — Filed upstream as #1685. Subscribed via GraphQL. Added to `upstream-watch.sh` cron watcher.
- **2026-04-18** — Local `_pre_extract_openclaw()` workaround removed in commit `5d3451b` when nemoclaw.sh switched to NVIDIA's official installer. GH-503's `tar` pre-extract workaround is now handled by the upstream installer.
- **2026-04-30** — Effectively resolved upstream by [PR #2484](https://github.com/NVIDIA/NemoClaw/pull/2484) (NemoClaw v0.0.30/v0.0.31): blueprint now declares `min_openclaw_version: "2026.4.24"` and the GHCR-pinned base image digest contains OpenClaw 2026.4.24. Our manifest pin moved to `v0.0.31` the same day; closure of #1685 awaits upstream confirmation.
