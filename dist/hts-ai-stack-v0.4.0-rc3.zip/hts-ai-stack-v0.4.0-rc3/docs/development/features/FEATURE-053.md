# FEATURE-053 — Avatar Chat (Local AI Character Interaction)

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | MEDIUM |
| **Effort** | 4–6 hours |
| **Risk** | Medium — Open-LLM-VTuber image is large (~13–25 GB), upstream API may change |
| **Target Release** | v0.7.0 |
| **Depends on** | Ollama, Faster-Whisper (optional), Coqui TTS (optional) |
| **Blocks** | Nothing |

## Problem

The stack provides text-based LLM chat (Open WebUI, SillyTavern) and voice
services (Faster-Whisper STT, Coqui TTS) but has no visual avatar for
interactive AI character conversations. Users interested in creative writing,
roleplay, or companion AI want an animated character they can talk to using
voice, with lip-synced responses.

## Solution

Three complementary approaches, from turnkey to fully custom:

### Approach 1 — Open-LLM-VTuber (Docker component) ⭐ Recommended

All-in-one self-hosted avatar chat. Live2D character with lip-sync in the
browser, voice conversation with interruption support. Connects to the stack's
existing Ollama, Faster-Whisper, and Coqui TTS services.

- **Component:** `scripts/components/open-llm-vtuber/`
- **Port:** 12393 (`OPEN_LLM_VTUBER_PORT`)
- **GPU:** Required for real-time performance
- **Upstream:** <https://github.com/Open-LLM-VTuber/Open-LLM-VTuber> (MIT)

Stack integration via `conf.yaml`:

- LLM → `http://ollama:11434` (stack Ollama on ai-network)
- STT → `http://faster-whisper:8600` (stack Faster-Whisper)
- TTS → `http://coqui-tts:5002` (stack Coqui TTS)

### Approach 2 — SillyTavern + Avatar Plugin

Extends the existing SillyTavern service with a visual avatar. No new Docker
service needed — install the plugin from within SillyTavern's extension system.

**Setup steps:**

1. Open SillyTavern at `http://localhost:8001`
2. Go to Extensions → Install Extension
3. Search for **ExpressiveAvatars** or **VTubeStudio Plugin**
4. Install and configure:
   - ExpressiveAvatars: renders in-browser, maps AI emotion tags to
     Live2D expressions
   - VTS Plugin: connects to [VTube Studio](https://denchisoft.github.io/VTubeStudio/)
     running on the desktop for richer avatar control
5. Load a Live2D model (`.model3.json`) — free models available at
   [Booth.pm](https://booth.pm/) or [nizima](https://nizima.com/)

**Pros:** lightweight, reuses existing SillyTavern service.
**Cons:** text-only (no voice unless TTS extension also added), avatar is
secondary to chat UI.

### Approach 3 — DIY Pipeline (Maximum Flexibility)

Wire together existing stack services with a custom frontend for full control
over the avatar pipeline:

```text
Microphone → Faster-Whisper (STT) → Ollama (LLM) → Coqui TTS (voice)
                                                        ↓
                                              SadTalker / Wav2Lip
                                                  (face animation)
                                                        ↓
                                                  Browser / Gradio UI
```

**Components already in stack:** Ollama, Faster-Whisper, Coqui TTS

**Components to add:**

- [SadTalker](https://github.com/Winfredy/SadTalker) — animates a photo with
  audio-driven lip sync (GPU, Python)
- [Wav2Lip](https://github.com/Rudrabha/Wav2Lip) — alternative lip-sync engine
- Custom Gradio / Streamlit frontend to orchestrate the pipeline

**Pros:** full control, reuse all existing services, swap any component.
**Cons:** significant integration work, latency management across services.

## Files

| File | Purpose |
|------|---------|
| `scripts/components/open-llm-vtuber/open-llm-vtuber.manifest.json` | Component manifest |
| `scripts/components/open-llm-vtuber/open-llm-vtuber.sh` | Lifecycle script |
| `docker/open-llm-vtuber/Dockerfile` | Build from upstream source |
| `docker-compose.yml` | Service entry (profile: open-llm-vtuber) |
| `REFERENCES.md` | Port 12393 in host port map |

## Testing

```bash
# Build and start
./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --install
./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --configure
./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --start

# Health check
./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --health

# Open browser
xdg-open http://localhost:12393

# Cleanup
./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --destroy
```
