$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/paperclip'
    $script:ComponentScript = Join-Path $script:ComponentDir 'paperclip.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'paperclip.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'paperclip file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'Dockerfile exists' {
        Join-Path $script:ComponentDir 'Dockerfile' | Should -Exist
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'paperclip compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'paperclip service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'paperclip:'
    }

    It 'uses paperclip profile' {
        $script:ComposeContent | Should -Match '\[paperclip\]'
    }

    It 'compose sets PAPERCLIP_DEPLOYMENT_MODE=authenticated' {
        $script:ComposeContent | Should -Match 'PAPERCLIP_DEPLOYMENT_MODE=authenticated'
    }

    It 'compose sets BETTER_AUTH_SECRET' {
        $script:ComposeContent | Should -Match 'BETTER_AUTH_SECRET'
    }
}

# ── Dockerfile conventions ───────────────────────────────────────────────────

Describe 'paperclip Dockerfile conventions' {

    BeforeAll {
        $script:Dockerfile = Get-Content -Path (Join-Path $script:ComponentDir 'Dockerfile') -Raw
    }

    It 'Dockerfile uses tsx runtime' {
        $script:Dockerfile | Should -Match 'tsx'
    }

    It 'Dockerfile creates non-root user' {
        $script:Dockerfile | Should -Match 'useradd.*paperclip|adduser.*paperclip'
    }
}

# ── Paperclip script functions ───────────────────────────────────────────────

Describe 'paperclip script functions' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'script defines _paperclip_auto_onboard function' {
        $script:ComponentContent | Should -Match '_paperclip_auto_onboard\s*\(\)'
    }

    It 'script writes notifications.json' {
        $script:ComponentContent | Should -Match 'notifications\.json'
    }
}
