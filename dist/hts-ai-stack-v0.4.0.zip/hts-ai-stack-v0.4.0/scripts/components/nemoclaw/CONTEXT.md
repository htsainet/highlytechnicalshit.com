# NemoClaw Component

Last updated: 2026-04-25 12:50:00

## Upstream compliance policy

> **Follow the upstream developer's guidance unless Tim explicitly allows
> an override.**

NemoClaw is developed by **NVIDIA**. OpenClaw (which runs inside NemoClaw
sandboxes) is developed by its own upstream project. Our scripts MUST
follow the official installation, upgrade, health-check, and lifecycle
commands documented by each project:

- **NemoClaw** — use `nemoclaw onboard`, `nemoclaw sandbox`, and the CLI
  commands documented by NVIDIA. Do not invent alternatives or bypass
  NemoClaw's orchestration unless NVIDIA docs say to.
- **OpenClaw** — use `openclaw update`, `openclaw doctor`, `openclaw health`,
  and `openclaw gateway` commands as documented. Restart foreground gateways
  with `SIGUSR1` (official in-process restart). Do not use raw `npm install`
  for upgrades unless Landlock sandbox constraints make `openclaw update`
  impossible (and document the reason).
- **OpenShell** — use `openshell gateway`, `openshell sandbox`, and
  `openshell forward` commands. Do not call `openshell self-update` or
  `npm update -g openshell` in NemoClaw-managed environments.

When upstream guidance conflicts with our implementation:

1. Check the upstream docs and changelog first
2. If a workaround is genuinely required (e.g., Landlock blocks global npm),
   document why and link to the upstream issue
3. **Never silently deviate** — add a comment citing the upstream doc and the
   reason for the workaround
4. If you are unsure whether a deviation is acceptable, **ask Tim**

## What happens here

NemoClaw is the NVIDIA-managed sandbox engine. This folder contains the
component lifecycle script and manifest for installing, configuring, and
onboarding NemoClaw sandboxes on the host.

## OpenShell lifecycle

For NemoClaw-managed environments, use `nemoclaw onboard` when you need
to create or recreate the OpenShell gateway or sandbox. Avoid
`openshell self-update`, `npm update -g openshell`,
`openshell gateway start --recreate`, or `openshell sandbox create`
directly unless you intend to manage OpenShell separately and then rerun
`nemoclaw onboard`.

## Diagnostic flags — what to reach for when the dashboard wedges

For the failure mode "dashboard says still starting" or "Firefox can't
connect to 127.0.0.1:18789", reach for the documented vendor commands
directly. We deliberately do **not** wrap them in HTS-specific flags any
more — every wrapper we tried (`--health`, `--repair-dashboard`,
`--list/--logs/--debug`) drifted from the NVIDIA quickstart and caused
more downtime than it cured. Verified against
[NVIDIA NemoClaw CLI Reference](https://docs.nvidia.com/nemoclaw/latest/reference/commands.html)
on 2026-04-25.

| Situation | Documented command |
|-----------|--------------------|
| Quick "is the sandbox Ready and is the dashboard reachable?" | `./scripts/components/nemoclaw/nemoclaw.sh --status` (rolls up `openshell sandbox get` + `nemoclaw <name> status`) |
| Confirm the sandbox is registered with NemoClaw | `nemoclaw list` |
| Live-tail openclaw inside the sandbox | `nemoclaw <name> logs --follow` |
| Collect a bug-report bundle | `nemoclaw debug --sandbox <name>` |
| Dashboard forward died / tab can't reach `:18789` | `./scripts/components/nemoclaw/nemoclaw.sh --restart-forward` (single documented `openshell forward start --background` per NVIDIA quickstart §"Restart the Port Forward") |
| Re-onboard from scratch | `nemoclaw onboard` |

## Why we do not call `nemoclaw start` / `nemoclaw stop`

Per the NVIDIA CLI reference (verified 2026-04-25), these are
**deprecated aliases** for `nemoclaw tunnel start` / `nemoclaw tunnel
stop`. They control only host-side cloudflared (the optional public-URL
tunnel for the dashboard) — they do **not** start or stop the sandbox.
Our `nemoclaw_start()` already orchestrates the supported primitives
(`nemoclaw onboard`, `_ensure_nemoclaw_gateway`,
`_start_dashboard_forward`, `_extract_dashboard_tokens`); calling the
deprecated alias would emit a deprecation warning and do nothing useful
on this host (no cloudflared installed). See `REFERENCES.md` →
*Auxiliary* for the deprecation note.

## Boot-time port forward — one documented oneshot, no watchdog

NVIDIA's quickstart treats the dashboard SSH forward as a single
user-driven command:

```bash
openshell -g <gateway> forward start --background 18789 <sandbox>
```

Our stack runs that exact command once at boot via a systemd **oneshot**
unit (`hts-nemoclaw-dashboard-forward.service`, installed by
`_install_dashboard_forward_boot_unit()`). It is **not** a watchdog,
retry loop, or escalation path. If the forward later dies, the
documented recovery is a manual single-shot — exposed as
`./scripts/components/nemoclaw/nemoclaw.sh --restart-forward`.

Earlier HTS drift — `hts-nemoclaw-health.timer`,
`_install_health_timer()`, `_ensure_forwards` retry/escalation,
`_forward_listening`/`_wait_forward_listening` listener probes,
sandbox-side TCP relay supervisor, `nemoclaw_health()`,
`nemoclaw.sh --repair-dashboard`, and the `--list`/`--logs`/`--debug`
wrappers — was removed in alignment with the documented design (recorded
in `DEVIATIONS.md`).

## Files and structure

| File | Purpose |
|------|---------|
| `nemoclaw.sh` | Full lifecycle: install, configure, onboard, start, stop, status |
| `nemoclaw.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |

## Key functions

| Function | Purpose |
|----------|---------|
| `nemoclaw_install()` | Version-aware install: clone repo, npm build, npm link, with preflight tool check + EXPERIMENTAL flag drift guard. Idempotent on already-pinned versions; force via `NEMOCLAW_FORCE_REINSTALL=1`. |
| `nemoclaw_configure()` | cgroup fix, registry patch, provider config |
| `nemoclaw_onboard()` | Onboard sandboxes via `nemoclaw onboard` |
| `nemoclaw_start()` | Full lifecycle: install + configure + onboard + dashboard forward |
| `nemoclaw_stop()` | Stop port forwards (sandbox kept running) |
| `nemoclaw_status()` | Sandbox phase + `nemoclaw <name> status` rollup |
| `nemoclaw_cleanup()` | Remove host-side artifacts (systemd unit, sysctl persistence, UFW rules) — preserves sandbox + workspace |
| `_do_onboard()` | Onboard with auto-recovery cascade: stale-session detection → `--fresh` retry; transport-error detection → force-recreate gateway + retry |
| `_force_recreate_gateway()` | Unconditional `docker rm -f` of `openshell-cluster-*` containers — used to cure client/gateway version-mismatch wedges |
| `_cleanup_stale_gateway_containers()` | Conditional cleanup: only removes containers in restarting/exited/dead/created state; running containers are left alone |
| `_preflight_required_tools()` | Verifies `timeout`/`python3`/`curl`/`docker`/`jq` in PATH at install time |
| `_check_experimental_flag_supported()` | Soft warn if a future NemoClaw release no longer recognises `NEMOCLAW_EXPERIMENTAL` |
| `_start_dashboard_forward()` | Vendor-doc oneshot: `openshell forward start --background 18789` |
| `_extract_dashboard_tokens()` | Refresh `resources/dashboard/nemoclaw-tokens.json` from the sandbox |
| `_install_dashboard_forward_boot_unit()` | Install systemd oneshot that runs the documented forward at boot |

Dispatcher actions added since v0.0.29 bump:

- `--onboard-fresh` — force `nemoclaw onboard --fresh` (clears stale session)
- `--recreate-gateway` — force-recreate gateway (cures version-mismatch wedges)
- `--cleanup` — remove host artifacts, preserve sandbox

## Gateway must be recreated after stale container removal

`_do_onboard()` removes the stale `openshell-cluster-*` container when
it finds one holding the gateway port. Without an immediate
`_ensure_nemoclaw_gateway` call after removal, the subsequent
`openshell sandbox exec` (used by `_run_onboard_cmd`) fails instantly
with "transport error → Connection refused" because the gateway it
connects through no longer exists.

**Fix:** after removing the stale container, `_do_onboard` calls
`_ensure_nemoclaw_gateway` with `_OPENSHELL_REINSTALLED=true` to force
recreation before running `nemoclaw onboard`.

## OpenShell version must be pinned to `OPENSHELL_VERSION`

NemoClaw's `blueprint.yaml` specifies an exact version window
(`min_openshell_version == max_openshell_version`). Installing `openshell`
from `releases/latest` can pull a version outside that window and cause
onboard to fail, or to auto-upgrade mid-run and leave the host in a state
that the next converge pass will re-downgrade.

Current pin: **`0.0.36`** (required by NemoClaw v0.0.31 in this repo;
blueprint window is `[0.0.32, 0.0.36]` — unchanged from v0.0.29). See
`scripts/components/nemoclaw/nemoclaw.manifest.json` for the canonical
NemoClaw + OpenShell pins (`upstream.pinned_version` and
`upstream.openshell_pinned_version`) and `DEVIATIONS.md` → *NemoClaw* for
the OpenShell compatibility rationale.

`nemoclaw_install()` compares the installed version against
`OPENSHELL_VERSION` and reinstalls if they differ.
`nemoclaw_start()` runs the same check so a `converge --restart` self-heals
without manual intervention. `_OPENSHELL_REINSTALLED=true` is set after
reinstall to force gateway recreation.

**Ongoing maintenance:** after every NemoClaw update, re-check the blueprint
and update the pin in `scripts/lib/common.sh`, `nemoclaw.sh`, and
`scripts/utils/upgrade-nemoclaw.sh` if it changed:

```bash
grep openshell_version ~/.nemoclaw/blueprint.yaml
```

**Post-converge verification:** one helper lives in `scripts/utils/`:

- `verify-openshell-pin.sh` — confirms the installed openshell binary,
  `~/.nemoclaw/blueprint.yaml`, and all repo defaults agree on the
  pinned version. Safe to run anytime.

## `nemoclaw_start()` self-heals degraded sandboxes

`--start` (called by converge) used to check only whether sandbox metadata
existed — not whether OpenClaw was actually serving. A degraded sandbox
(Phase ≠ Ready) would pass the check, the forward would be set up to
nothing, and `--start` would exit successfully. This is why nemoclaw kept
stopping: converge couldn't revive it.

**Fix:** `nemoclaw_start()` now calls `_check_sandbox_health()` after
confirming the sandbox exists. If the phase is not Ready, it calls
`_do_onboard()` directly (non-interactive, no prompt) to re-onboard
before setting up forwards. On the healthy fast path it still ensures the
required `NEMOCLAW_MODEL`, refreshes provider wiring, and rewrites in-sandbox
agent config if the sandbox was still pinned to an older model. This makes
`--start` fully self-healing.

## Onboard policy presets

`_run_onboard_cmd()` passes
`NEMOCLAW_POLICY_PRESETS="npm,pypi,telegram,huggingface,local-inference"`
to `nemoclaw onboard`. These are deny-by-default allowlists for package
registries and APIs. The `local-inference` preset is NVIDIA's stock allowlist
for OpenShell-hosted inference; on this repo we additionally route sandbox
traffic through `https://inference.local` (see Inference routing below) so
the sandbox never needs a policy hole to `host.openshell.internal:8081`.

Do **not** treat an HTTP `403` from `/v1/models` as proof that policy is
missing; that endpoint can require auth even when routing is healthy.

## Inference routing — NVIDIA-approved path (2026-04-25)

NemoClaw v0.0.21 (`src/lib/onboard.ts:4331-4416`, function `setupInference`)
and OpenShell v0.0.26
(`docs/get-started/tutorials/inference-ollama.mdx`, "Option B: Host-Level
Ollama") define exactly one supported path for routing sandbox inference to
host-side llama-swap:

```text
sandbox / openclaw  ── HTTPS ──▶  https://inference.local/v1
                                          │  (relay terminates inside the
                                          │   gateway pod, not the sandbox)
                                          ▼
                          http://host.openshell.internal:${LLAMA_SWAP_PORT}/v1
                                          │
                                          ▼
                                    llama-swap (host)
```

Wiring requirements:

1. **Provider** — the `compatible-endpoint` provider (created by
   `nemoclaw onboard` Step 4) carries
   `OPENAI_BASE_URL=http://host.openshell.internal:${LLAMA_SWAP_PORT}/v1`.
   This is the *upstream* URL used by the gateway, not by the sandbox.
2. **Inference route** — `openshell inference set --provider compatible-endpoint
   --model <model>` pins the active route. NemoClaw's `setupInference()` does
   this during onboard; `_setup_provider()` re-runs it on every `--start`
   so model/provider drift cannot survive a reconfigure.
3. **Sandbox URL** — `https://inference.local/v1` is baked into the sandbox
   Dockerfile via `ARG NEMOCLAW_INFERENCE_BASE_URL` (`onboard.ts:1225`).
   Openclaw calls only this URL. The gateway resolves it through the bound
   provider+model and makes the upstream call to llama-swap.
4. **No custom network policy is required** for `host.openshell.internal:8081`,
   because the sandbox does not call it. The `_ensure_llamaswap_policy` helper
   was **removed on 2026-04-25** — it solved a problem that does not exist on
   the documented vendor path.

Helper: `_ensure_inference_route_pinned()` mirrors `setupInference()` and is
invoked from `_setup_provider()` after the provider URL update.

Postcondition: `_setup_provider()` probes the sandbox-facing URL only
(`https://inference.local/v1/chat/completions`) — the URL openclaw actually
uses. A green probe means "what openclaw uses works".

## 2026-04-25 troubleshooting summary

Fresh host-side troubleshooting on 2026-04-25 established these current
findings:

1. `nemoclaw_start()` correctly self-heals a missing gateway container when
   gateway metadata still exists. The healthy recovery path is: restart the
   gateway, keep the existing sandbox if it is `Ready`, then recreate the
   port-18789 forward and dashboard token file.
2. A full destroy/recreate no longer reproduced the historical Node
   `v24.15.0` `write EPIPE` / `write EIO` onboard crashes. The fresh recreate
   completed the full 8-step NVIDIA onboard flow and reached sandbox
   `Phase: Ready`.
3. The live recreate-path failure moved to our post-onboard provider check:
   the sandbox-side probe against
   `http://host.openshell.internal:8081/v1/models` returned HTTP `403` after
   provider update.
4. That `403` is a false-negative health signal, not the primary evidence of a
   missing OpenShell policy. This repo already documents the same pattern for
   other OpenAI-style services: `/v1/models` may require auth while the service
   itself is healthy.
5. `_setup_provider()` therefore validates sandbox-side llama-swap routing with
   a minimal `/v1/chat/completions` request instead of `/v1/models`.
6. `smollm2:135m` is too small for the managed OpenClaw agent flow because it
   does not support tools. NemoClaw now uses its own `NEMOCLAW_MODEL` default
   of `qwen2.5:7b-instruct-q4_K_M` (non-thinking, tool-capable, fits 32K
   context comfortably on a 12 GB GPU) instead of inheriting the global
   starter `OLLAMA_MODEL`. The previous default `gemma4:e4b` was a thinking
   model whose `<think>` output is emitted on the non-standard `reasoning`
   field that the OpenClaw chat UI does not render — see DEVIATIONS.md →
   NemoClaw.
7. Direct OpenAI-compatible probes should include
   `Authorization: Bearer not-needed`; omitting that dummy bearer token can
   still return HTTP `403` from llama-swap even when routing is correct.
8. **(Resolved — replaced by Inference routing section above.)** Initial
   investigation focused on a sandbox-side proxy 403 to
   `host.openshell.internal:8081`. The fix was not to punch a custom policy
   hole but to use the documented `https://inference.local` relay; the
   sandbox never needs to reach `host.openshell.internal:8081` directly.
9. **(Historical, no longer relevant.)** `openshell policy get --full` emits
   a multi-document YAML stream with capitalized top-level keys that
   `policy set --policy` rejects. We hit this while implementing the (now
   removed) `_ensure_llamaswap_policy` helper. Documented for posterity in
   case a future feature legitimately needs to patch live OpenShell policy.

## Dashboard portal auth — recovery and gotchas (2026-04-25)

The NemoClaw chat UI ("Portal") served from `http://127.0.0.1:18789` has
several auth/connectivity failure modes that are easy to retrigger and were
hard to diagnose. This section captures the working understanding so we
don't have to rediscover it.

### Failure modes

1. **"Firefox can't connect to 127.0.0.1:18789"** — host listener is up
   (`ss -tln` shows port 18789) but the upstream `openshell forward`
   ssh tunnel has no peer because openclaw inside the sandbox is not
   running. NemoClaw v0.0.21 sandboxes ship with **no openclaw process
   supervisor** — once openclaw exits, it stays exited. Killing it from
   the host (e.g. via `openshell sandbox exec ... kill`) is **not**
   recoverable without `nemoclaw <name> rebuild`.
2. **"unauthorized: gateway token mismatch"** — browser localStorage at
   `http://127.0.0.1:18789` holds a stale token from a prior sandbox
   incarnation. The dashboard URL fragment (`#token=…`) does not always
   overwrite an existing localStorage entry. Fix: incognito window, OR
   DevTools → Application → Local Storage → clear.
3. **"unauthorized: too many failed authentication attempts (retry later)"**
   — the in-memory rate limiter inside openclaw has tripped. The lockout
   counter resets only when the openclaw process itself restarts. Fix:
   `nemoclaw <sandbox> rebuild`.
4. **Stale `running` row, dead listener** — `openshell forward list`
   shows status `running` with a PID, but `ss -tln` shows nothing on
   `127.0.0.1:18789`. The background ssh process exited but its row
   wasn't reaped. Fix: re-run the documented forward command via
   `./scripts/components/nemoclaw/nemoclaw.sh --restart-forward` (which
   wraps `openshell forward stop` + `openshell forward start
   --background`).
5. **Portal link from dashboard goes to wrong host** — earlier the
   dashboard built `http://${window.location.hostname}:18789/...`. If
   the dashboard is opened via Tailscale name or hostname the link
   pointed at a host the forward is not bound to. The forward is
   `127.0.0.1` only and `gateway.controlUi.allowedOrigins` only lists
   `http://127.0.0.1:18789` and `http://localhost:18789`. The dashboard
   now hardcodes `127.0.0.1` in the NemoClaw card link.
6. **`Phase: Ready` but openclaw not serving on `:18789`** (added
   2026-04-25) — sandbox health checks (pod phase, `nemoclaw <name>
   status`) report green because they only probe k8s state and the
   inference provider, **not** the in-sandbox openclaw HTTP listener.
   Symptom: SSH forward is up, `curl 127.0.0.1:18789` returns HTTP 000
   (TCP accept then zero-byte close). `nemoclaw_start` now runs a
   30s host-side curl probe at the end and exits non-zero with a
   clear `[FAIL]` if the dashboard is not responsive — preventing
   misleading `[OK] NemoClaw started.` reports. Recovery is
   `nemoclaw <sandbox> rebuild` (per warn message). Hit twice on
   2026-04-25; root cause inside the openclaw container is upstream
   and out of scope for the strip-drift branch.
7. **Healthy gateway killed every `--start`** (fixed 2026-04-25,
   commit `99aaaca`) — `_cleanup_stale_gateway_containers` was
   `docker rm -f`'ing the gateway container on name match alone,
   ignoring `.State.Status`. Result: every `--start` killed the
   running gateway, then `_ensure_nemoclaw_gateway` rebooted k3s
   (30s–2min). Now state-aware: `running` containers are left alone;
   `restarting/exited/dead/created/paused/unknown` are still
   force-removed (the original bug it was written for).

### Recovery path — vendor-documented, single command

The NVIDIA quickstart §"Restart the Port Forward" prescribes one command
for all the failure modes above:

```bash
openshell -g hts-ai-openshell-nemoclaw-gateway forward start --background 18789 hts-ai-openshell-nemoclaw
```

We expose that exact command, scoped to our gateway/sandbox names, as:

```bash
./scripts/components/nemoclaw/nemoclaw.sh --restart-forward
```

It runs `openshell forward stop` (idempotent) then the documented
`openshell forward start --background`, and refreshes
`resources/dashboard/nemoclaw-tokens.json` so the dashboard tile picks up
the live `gateway.auth.token`. There is intentionally **no** retry loop,
listener probe, or escalation to `nemoclaw <name> rebuild` — those are
operator decisions per NVIDIA's design.

If openclaw inside the sandbox has exited (failure mode #1 or #3 above),
the documented operator action is `nemoclaw <sandbox> rebuild` followed
by `--restart-forward`. (Note: `nemoclaw <name> restart` does **not**
exist — valid actions are `connect, status, logs, policy-add,
policy-remove, policy-list, skill, snapshot, rebuild, shields, config,
destroy`. `rebuild` is the documented in-place recovery; it preserves
the workspace and runs `openclaw doctor --fix` automatically.) Earlier
HTS iterations (`--repair-dashboard`,
`_ensure_forwards` auto-escalation, `hts-nemoclaw-health.timer`) wrapped
those steps into a single self-healing command; that wrapper drifted
from the docs and produced more downtime than it cured, so it was
removed (see `DEVIATIONS.md` and the `nemoclaw_health` removal note).

### Diagnostic-only scripts

- `scripts/utils/diagnose-nemoclaw-dashboard-token.sh` — read-only:
  persisted vs live token comparison, listener probe, HTTP probe of
  root and `/api/auth/whoami`, paired-devices state.
- `scripts/utils/inspect-nemoclaw-tokens.sh` — read-only: dumps every
  token/secret/key/auth/pair field from live `openclaw.json` plus the
  full file. Use this before patching `_extract_dashboard_tokens` if the
  upstream config schema changes.

### Token field

The Control UI authenticates against `gateway.auth.token` in
`/sandbox/.openclaw/openclaw.json` (verified against NemoClaw v0.0.21
`scripts/nemoclaw-start.sh:639-655` `print_dashboard_urls()`). There is
no separate `gateway.controlUi.token`; do not invent one. The URL
fragment format `#token=<64-hex>` is the official format.

### When NOT to "kill openclaw to clear lockout"

We tried this. It looks like it works for ~10 seconds because the host
ssh forward stays bound, but openclaw never comes back without
`nemoclaw <sandbox> rebuild`. Always go through the supported recovery
path.

## Sandbox egress notes (2026-04-25)

These observations were the breadcrumbs that led to the
`inference.local` relay fix in `d4c892b`. The fix is in place, but
record them here so a future session investigating sandbox → host
networking does not have to rediscover them.

- `openshell policy get --full` returns a **multi-document YAML
  stream** (multiple `---`-separated docs). Any policy-merge helper
  MUST use `yaml.safe_load_all(...)` — `yaml.safe_load(...)` will only
  see the first document and silently drop the rest.
- Sandbox egress is **forced through the OpenShell proxy at
  `10.200.0.1:3128`**. There is no direct route from inside the
  sandbox to host services unless the policy explicitly allows it.
- `NO_PROXY` inside the sandbox does **not** include
  `host.openshell.internal`, so even traffic destined for the host
  bridge goes through the proxy by default.
- Diagnostic signal: `curl --noproxy '*'` from inside the sandbox does
  not return `403`; it fails to **connect** at all. That confirms the
  failure mode is "no direct route", not "proxy denies request" — the
  sandbox literally has no other path to the host than the proxy.
- The accepted fix is the `inference.local` relay (allowlisted in the
  OpenShell policy overlay), not poking holes in `NO_PROXY` or trying
  to bypass the proxy.

## 2026-04-26 — Working configuration (chat through llama-swap, MVP green)

End-to-end chat through llama-swap is working again. This section pins the
configuration that works and the load-order / token / model gotchas that took
the longest to find. If chat regresses, start here before re-deriving anything.

### Known-good wiring

- **Model:** `mistral-nemo:latest` (NVIDIA/Mistral 12B Q4, ~7 GB, fits 12 GB
  VRAM with headroom). Strong purpose-built tool-caller — does **not** spiral
  on OpenClaw's agent loop the way `qwen2.5:7b-instruct-q4_K_M` does.
  `qwen2.5` chats fine in plain prompts but produces an infinite
  `tool_call → tool_result → tool_call` loop in OpenClaw (visible as
  "1 tool message" repeating in the UI, and `/v1/chat/completions` hits
  every 3-5 s in `nemoclaw <name> logs`).
- **Single source of truth:** `NEMOCLAW_MODEL` is defined exactly twice:
  1. `nemoclaw.manifest.json` `prompts[].model` → wizard writes `.env`
  2. `nemoclaw.sh:50` lone fallback `NEMOCLAW_MODEL="${NEMOCLAW_MODEL:-mistral-nemo:latest}"`
  Every other reference is a bare `${NEMOCLAW_MODEL}`. **Do not** add inline
  `:-...` fallbacks at use sites — that re-introduces drift the manifest is
  supposed to eliminate. Smoke / diagnose / downgrade utilities all read the
  same env or accept `--model` arg.
- **Provider:** type `compatible-endpoint` (NOT `custom`).
  Credential env: `COMPATIBLE_API_KEY=not-needed`.
- **URLs:**
  - Sandbox-side (used by openclaw runtime): `https://inference.local/v1`
  - Gateway upstream: `http://host.openshell.internal:8081/v1`
  - Direct llama-swap (host): `http://127.0.0.1:8081/v1`
- **Inference route timeout:** `NEMOCLAW_INFERENCE_TIMEOUT=300` (cold-load of
  mistral-nemo can take 60–120 s on first prompt; OpenShell default 60 s
  kills the stream before the first token).
- **Personas:** **Removed (2026-04-28).** Multi-agent persona injection
  (caco-bot, haley) is gone. OpenClaw mkdirs `/sandbox/.openclaw/workspace-<agent>/`
  at session start; that path is root-owned and read-only per sandbox policy,
  so any non-default `agents.list` produces `EACCES: mkdir` on first chat.
  We ran two rounds of agents-dir chown workarounds; both leaked. Per the
  "rewrite over repeat-fix" rule the feature was ripped out: function,
  manifest prompt, env var, profile keys, wizard plumbing. Stock OpenClaw
  uses a single default agent with a writable workspace and works fine.
  `resources/agents/{caco-bot,haley}/` is preserved on disk for any future
  reimplementation but is no longer wired in. See lesson 6 below for the
  failure mode.
- **Pinned versions:** NemoClaw `v0.0.31`, OpenShell `0.0.36` (manifest is
  canonical — `nemoclaw.manifest.json upstream.pinned_version` and
  `upstream.openshell_pinned_version`). See [`DEVIATIONS.md`](DEVIATIONS.md)
  for the rationale, [`DEVIATIONS-history.md`](DEVIATIONS-history.md) for the
  v0.0.21 → v0.0.29 → v0.0.31 transition narrative.

### Lessons that bit us (don't relearn the hard way)

1. **`load_env` clobbers pre-source exports.** The original
   `_ensure_nemoclaw_model_ready` did `export OLLAMA_MODEL="$model"` and
   *then* sourced `scripts/components/ollama/ollama.sh` — which calls
   `load_env`, which re-reads `.env` and overwrites the export with the
   global starter (`smollm2:135m`). Net effect: NemoClaw silently pulled
   the wrong model and llama-swap's `/v1/chat/completions` returned 404
   on `qwen2.5:7b-instruct-q4_K_M` because Ollama never had it.
   **Fix:** assign `OLLAMA_MODEL` *after* sourcing any script that calls
   `load_env`. Pattern is now in `_ensure_nemoclaw_model_ready` (~line 238).
   This trap applies to any script in the repo — anywhere we pre-export then
   source a component script, double-check `load_env` isn't undoing it.
2. **Dashboard token ≠ provider credential.** `nemoclaw <name> config rotate-token`
   rotates the **provider** credential (e.g. `COMPATIBLE_API_KEY`), prompting
   for a new value. It does **not** rotate the dashboard auth token. Those
   are different fields. The dashboard token is `gateway.auth.token` in the
   sandbox-internal `/sandbox/.openclaw/openclaw.json` — root-owned, edited
   via `_sandbox_root_exec` + restart gateway. `nemoclaw.sh --rotate-token`
   does this directly now (see `nemoclaw_rotate_token` ~line 1829).
3. **Tokens-on-disk live in `resources/dashboard/nemoclaw-tokens.json`.**
   Every script path that writes/refreshes that file ends with a printed
   banner — `_print_dashboard_url` (~line 481) — showing
   `http://127.0.0.1:18789/#token=<token>`. No more "go run this Python
   one-liner to assemble the URL".
4. **`/v1/models` lies; chat is the only honest probe.** llama-swap renders
   `/v1/models` from its YAML config, not from what Ollama actually has
   pulled. To verify a model is really available, hit
   `/v1/chat/completions` with a 1-token request. The sandbox-side
   postcondition probe (`_probe_llamaswap_from_sandbox`) does exactly this
   through `https://inference.local`.
5. **Cold-load races the postcondition.** First `--start` after a model
   change can return 502 during the warm-up curl, and the in-sandbox
   postcondition probe a few seconds later can fail simply because the
   model hasn't finished loading into VRAM yet, or because the gateway
   route version we just bumped hasn't propagated. The probe now retries
   internally up to 5× with 10s backoff (each attempt still gets the full
   `NEMOCLAW_INFERENCE_TIMEOUT`), which clears this flake on subsequent
   attempts without needing a second `--start` invocation. If the probe
   still fails after 5 attempts, the model genuinely isn't serving —
   `curl localhost:8081/v1/models` directly to confirm llama-swap is up.
6. **Persona perms (feature removed 2026-04-28).** `/sandbox/.openclaw/` is
   root-owned by image build; `/sandbox/.openclaw-data/` is sandbox-owned.
   Multi-agent persona injection set `agents.list` in `openclaw.json`,
   which makes openclaw try to `mkdir /sandbox/.openclaw/workspace-<agent>/`
   at session start — that path is root-owned and read-only per sandbox
   policy, so first chat hit `EACCES: mkdir`. Workarounds tried:
   pre-create + chown `agents/` to sandbox user (broken — only covers the
   subdir, not `workspace-*` siblings); chown `agents/` after mkdir (broken —
   `workspace-*` still root-owned at runtime); writeback chain from
   `stack.json .sandbox.agent_personas` → env var (broken — never wired).
   Two rounds of fixes both leaked, so per "rewrite over repeat-fix" the
   feature was removed entirely: `_provision_agent_personas`,
   `_sandbox_agent_models_match_expected`, the manifest prompt, the env
   var, profile keys, wizard plumbing. The default single-agent OpenClaw
   config uses a writable workspace and works without any host-side
   patching. If personas are reintroduced, the sandbox image must ship
   `/sandbox/.openclaw/workspace-*` writable by the sandbox user (image
   change, not host-side mkdir/chown), or a different config knob must
   point openclaw at a writable workspace path under `.openclaw-data/`.
7. **`install-status.json` can stick on red after a transient failure.**
   The dashboard's install-mode is gated by `resources/dashboard/install-status.json`
   (written by `scripts/lib/installstatus.sh` during converge). If a
   `--start` ever fails — even a transient cold-load probe flake — the
   converge that called it marks `services.nemoclaw=error`, `phase=error`,
   and the dashboard refuses to run live health probes against
   `127.0.0.1:18789`. NemoClaw shows offline / Failed even when everything
   is actually working. `nemoclaw_start()` now self-heals the file at the
   end of the success path (`_heal_install_status`): clears any
   `nemoclaw=error`, drops the message, and flips `phase` back to
   `complete` if no other service is still red. Atomic write via Python +
   `os.replace`. If you're staring at a red NemoClaw card after a green
   `--start`, that healer didn't run (older script, or `python3` missing
   on PATH) — fix is `phase: complete` + `nemoclaw: running` in the JSON,
   then hard-refresh the dashboard.
8. **`nemoclaw rebuild` refuses on model mismatch.** Rebuild reads
   `~/.nemoclaw/sandboxes/<name>/` resumable state and aborts with
   "Resumable state recorded model X, not Y" when the saved onboard
   model differs from the current `NEMOCLAW_MODEL`. After a default-model
   swap (e.g. qwen2.5 → mistral-nemo), the first `--restart` will burn
   ~30s on a snapshot + backup + delete before the rebuild errors out;
   our script then falls through to a clean recreate via `nemoclaw_start`
   → full onboard. Annoying but not broken. If you want to skip the
   wasted snapshot, run `--stop` then `--start` instead of `--restart`,
   or `rm -rf ~/.nemoclaw/sandboxes/<name>/` before `--restart`.
9. **Dashboard tokens-on-disk were fresh; the browser cached them stale.**
   `resources/dashboard/index.html` `loadTokenOverlays()` does the right
   thing — fetches `nemoclaw-tokens.json`, finds the NemoClaw card by
   port match, rewrites the deep-link href to
   `http://127.0.0.1:18789/#token=<live>`. But the original `fetch()`
   had no cache directive. Browser HTTP cache served the previous
   install's JSON for hours after a `--destroy` + reinstall rotated the
   token. Card looked fresh, link carried a stale token, click →
   "unauthorized: gateway token mismatch" — and the natural debugging
   path (open the dashboard URL printed at the end of install) would
   work, while the dashboard tile would not. Fix (`fef6ad9`,
   2026-04-26): add `cache: 'no-store'` and a `?t=<timestamp>` query
   param to the fetch. **If you see "token mismatch" again,** first
   suspect: a browser tab opened *before* the most recent install — its
   in-memory `index.html` predates the cache-bust and will keep serving
   stale URLs. Hard-refresh (Ctrl+Shift+R) or close the tab. The
   `nemoclaw.sh --tokens` flag re-extracts the JSON from the live
   sandbox without restarting anything; combine it with a hard-refresh
   to recover without a full `--start`.

### One-shot recovery commands

| Symptom | Command |
|---------|---------|
| Don't have the dashboard URL | `./scripts/components/nemoclaw/nemoclaw.sh --tokens` (or any `--start` / `--restart-forward` / `--rotate-token` — they all print the banner) |
| "unauthorized: gateway token mismatch" | `./scripts/components/nemoclaw/nemoclaw.sh --rotate-token` |
| Forward to 18789 dropped | `./scripts/components/nemoclaw/nemoclaw.sh --restart-forward` |
| Chat looping on tool calls | Verify `NEMOCLAW_MODEL=mistral-nemo:latest` in `.env`, then `nemoclaw <sandbox> rebuild --yes` (model is baked into image at Step 21) |
| Postcondition flake on first start | Re-run `--start` once — model is warm by then |

## Tools and skills

- **NemoClaw CLI** — NVIDIA sandbox orchestrator (runs on host, not in Docker)
- **OpenShell CLI** — Container runtime managed by NemoClaw
- **npm** — NemoClaw is installed from source via npm

See [usage.md](./usage.md) for command usage.
