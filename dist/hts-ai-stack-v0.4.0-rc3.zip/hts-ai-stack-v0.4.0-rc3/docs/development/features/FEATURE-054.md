# FEATURE-054 — Developer Tools Suite

| Field | Value |
|-------|-------|
| Status | Draft |
| Category | Developer Experience |
| Components | OpenCode, Aider, Tabby, Gitea Runner |
| Dependencies | Ollama (for OpenCode, Aider), GPU (for Tabby), Gitea (for Runner) |

## Summary

Four developer-focused tools to complement the existing AI stack:

### OpenCode (host tool)

Terminal-first AI coding agent from [opencode.ai](https://opencode.ai/).
Supports 75+ LLM providers including local Ollama. Installed via curl,
configured to use the stack's Ollama at `localhost:11434`.

- **Install**: `curl -fsSL https://opencode.ai/install | bash`
- **Launch**: `opencode` in any project directory
- **Config**: `~/.config/opencode/config.json` → Ollama endpoint

### Aider (host tool)

AI pair programmer for the terminal from [aider.chat](https://aider.chat/).
Makes code edits, creates commits, works with local Ollama models.

- **Install**: `pipx install aider-chat` (or pip)
- **Launch**: `aider` in any git repo
- **Config**: `~/.aider.conf.yml` → `ollama/qwen2.5-coder:7b`

### Tabby (Docker service — GPU)

Self-hosted AI code completion server from [TabbyML](https://tabby.tabbyml.com/).
Provides Copilot-like autocomplete for VS Code, JetBrains, and vim.
Runs its own code models (StarCoder, CodeLlama) on GPU.

- **Port**: 8085 (host) → 8080 (container)
- **Model**: Configurable via `TABBY_MODEL` env var (default: `TabbyML/StarCoder-1B`)
- **GPU**: Required — uses NVIDIA CUDA for model inference
- **IDE setup**: Install Tabby extension → point at `http://<host>:8085`

### Gitea Actions Runner (Docker service)

CI/CD runner for Gitea Actions workflows. Uses Docker-in-Docker to execute
workflow jobs. Requires registration token from Gitea instance.

- **Image**: `gitea/act_runner:latest`
- **No exposed port** — connects outbound to Gitea at `http://gitea:3001`
- **Docker socket**: Mounted for container-based workflow jobs
- **Setup**: Get token from Gitea UI → add `GITEA_RUNNER_TOKEN=<token>` to `.env`

## Architecture

```text
┌─────────────────── Host Tools ───────────────────┐
│  opencode ──→ Ollama (localhost:11434)            │
│  aider    ──→ Ollama (localhost:11434)            │
└──────────────────────────────────────────────────-┘

┌─────────────── Docker Services ──────────────────┐
│  tabby (GPU)     → :8085 → IDE extensions        │
│  gitea-runner    → Gitea (internal :3001)         │
└──────────────────────────────────────────────────-┘
```

## Files Added

- `scripts/components/opencode/` — manifest + lifecycle script
- `scripts/components/aider/` — manifest + lifecycle script
- `scripts/components/tabby/` — manifest + lifecycle script
- `scripts/components/gitea-runner/` — manifest + lifecycle script
- `scripts/components/gitea/gitea.manifest.json` — missing manifest backfill
- `docker/tabby/Dockerfile` — thin wrapper on `tabbyml/tabby:latest`
- `docker/gitea-runner/Dockerfile` — thin wrapper on `gitea/act_runner:latest`
- `docker-compose.yml` — Tabby + Gitea Runner service entries + volumes
- `REFERENCES.md` — port 8085 (Tabby) added to host port map
