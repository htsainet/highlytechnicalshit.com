#!/usr/bin/env bash
# scripts/configure.sh — Day-2 configuration entry point
# Usage:
#   ./scripts/configure.sh --inference    # re-run inference profile selection
#   ./scripts/configure.sh --models       # re-run model selection/pull
#   ./scripts/configure.sh --help

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

source "$REPO_DIR/scripts/lib/common.sh" || true

usage() {
  cat <<EOF
Usage: $(basename "$0") [--inference|--models|--help]

--inference   Re-run inference profile selection (sourcing scripts/wizard/inference-profile.sh)
--models      Re-run model selection and optional pulls (sourcing scripts/wizard/model-select.sh)
--help        Show this help
EOF
}

case "${1:-}" in
  --inference)
    if [[ -f "$REPO_DIR/scripts/wizard/inference-profile.sh" ]]; then
      # shellcheck source=/dev/null
      source "$REPO_DIR/scripts/wizard/inference-profile.sh"
      select_inference_profile || true
    else
      echo "inference-profile.sh missing" >&2
      exit 1
    fi
    ;;
  --models)
    if [[ -f "$REPO_DIR/scripts/wizard/model-select.sh" ]]; then
      # shellcheck source=/dev/null
      source "$REPO_DIR/scripts/wizard/model-select.sh"
      select_model || true
      pull_selected_models || true
    else
      echo "model-select.sh missing" >&2
      exit 1
    fi
    ;;
  --help|-h)
    usage
    ;;
  *)
    usage
    exit 2
    ;;
esac
