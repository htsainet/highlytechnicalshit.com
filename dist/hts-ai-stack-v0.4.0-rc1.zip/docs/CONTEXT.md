# Documentation Hub

Comprehensive documentation for the AI stack: guides, architecture, planning, and operational runbooks.

Last updated: 2026-03-31 19:08:36

## What happens here

This workspace contains all user-facing and internal documentation. Guides help users set up and troubleshoot services. Planning docs track research, design decisions, and security reviews. Development docs track active features and issues.

## Files and structure

| Folder | Purpose |
|--------|---------|
| `development/` | Active development tracking (features, issues, test logs) |
| `guides/` | How-to guides for individual services (Tailscale, Signal, Telegram, Docker, NFS, etc.) |
| `pipeline/` | Step-by-step install pipeline mirroring `scripts/install/` phases |
| `planning/` | Strategic planning, research, repo reviews, security analysis |
| `upstream/` | Upstream dependency inventory and tracked issue files |

## Process / Workflow

1. **Guides** — Updated when services change or new setup steps are documented
2. **Development** — Updated as features are added/tracked and issues are resolved
3. **Planning** — Research artifacts, security reviews, architectural decisions
4. **Pipeline** — Mirrors the numbered install steps; updated when installation changes

## What good looks like

- All guides include: What it's for, Prerequisites, Step-by-step instructions, Troubleshooting
- Feature and issue tracking uses consistent naming (FEATURE-###.md, ISSUE-###.md)
- Planning docs reference external resources with links
- All markdown passes linting (markdownlint-cli2)
- Guides are tested against actual deployments
- Architecture decisions documented with rationale and date

## Tools and skills

- **markdownlint-cli2** — Markdown linting and consistency checking
- **cspell** — Spell checking for documentation
- **Claude Code** — Documentation creation and updates
- **grep/ripgrep** — Search and reference tools
