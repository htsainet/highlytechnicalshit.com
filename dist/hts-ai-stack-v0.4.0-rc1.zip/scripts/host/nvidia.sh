#!/usr/bin/env bash
# scripts/host/nvidia.sh — NVIDIA drivers, CUDA toolkit, and container toolkit
# Independently runnable. Idempotent — skips already-installed components.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/manifest.sh"

banner
step "NVIDIA drivers"

if nvidia-smi &>/dev/null; then
  info "NVIDIA drivers already installed ($(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1))"
else
  info "NVIDIA drivers not found — installing (auto-detect best driver)..."
  sudo apt-get update -qq
  sudo apt-get install -y ubuntu-drivers-common
  sudo ubuntu-drivers install
  echo ""
  warn "══════════════════════════════════════════════════════════════════"
  warn "  NVIDIA drivers installed — REBOOT REQUIRED"
  warn "  After reboot, re-run:  ./install.sh"
  warn "══════════════════════════════════════════════════════════════════"
  exit 0
fi

step "CUDA toolkit"

if nvcc --version &>/dev/null; then
  info "CUDA toolkit already installed ($(nvcc --version | grep release | awk '{print $5}' | tr -d ','))"
else
  info "Installing CUDA toolkit..."
  sudo apt install -y nvidia-cuda-toolkit nvidia-cuda-toolkit-gcc
  nvcc --version
fi

step "NVIDIA Container Toolkit"

if nvidia-ctk --version &>/dev/null; then
  info "NVIDIA Container Toolkit already installed."
else
  info "Installing NVIDIA Container Toolkit..."
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | \
    sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg

  curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

  sudo apt-get update
  sudo apt-get install -y nvidia-container-toolkit

  info "Configuring Docker runtime for NVIDIA..."
  sudo nvidia-ctk runtime configure --runtime=docker
  sudo systemctl restart docker

  info "Verifying GPU access in Docker..."
  docker run --rm --runtime=nvidia --gpus all nvidia/cuda:12.0.1-base-ubuntu22.04 nvidia-smi
fi

step "GPU validation"
if nvidia-smi &>/dev/null; then
  ok "GPU: $(nvidia-smi --query-gpu=name --format=csv,noheader | head -1)"
  manifest_add "nvidia-driver" "apt" "$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1)"
else
  warn "nvidia-smi not responding — check driver installation."
fi

if nvcc --version &>/dev/null; then
  manifest_add "cuda-toolkit" "apt" "$(nvcc --version | grep release | awk '{print $5}' | tr -d ',')"
fi

if nvidia-ctk --version &>/dev/null; then
  ok "NVIDIA CTK: $(nvidia-ctk --version | head -1)"
  manifest_add "nvidia-container-toolkit" "apt" "$(nvidia-ctk --version 2>&1 | awk '{print $NF}' | head -1)"
fi

info "NVIDIA setup complete."
