# FEATURE-061 — Agent Registry & Lifecycle Governance (`agentctl`)

| Field | Value |
|-------|-------|
| Status | Proposed |
| Category | Agent Governance / Security |
| Target Release | v0.6.0 |
| Priority | HIGH |
| Effort | L (new subsystem + CLI + schema) |
| Components | `agent-registry` (new), consumers: `nemoclaw`, `htsclaw`, `n8n`, `flowise`, `langflow`, `open-webui` |
| Dependencies | FEATURE-051 (skills system), SECURITY-007 (persona drift), SECURITY-008 (skill vetting), SECURITY-005 (observability), SECURITY-009 (secret scoping), FEATURE-058 (OpenShell sandbox tier) |
| Related | FEATURE-055 (auth — who invoked the agent), FEATURE-057 (runtime detection) |

## Summary

Right now an "agent" in this stack is an emergent thing: a persona file
somewhere, a skill folder somewhere else, a model pulled by Ollama, and
an orchestration runtime (nemoclaw / n8n / flowise) that glues them
together at call time. There is **no single source of truth** for
"what agents exist, what they're allowed to do, and are they still the
agents we approved?"

This feature introduces an **Agent Registry** — a manifest-driven,
version-controlled, verifiable inventory of every agent in the stack —
and `agentctl`, a CLI for querying and governing them.

Think of it as the agent-layer analogue to the service manifest
system: just as every container declares its ports/volumes/auth in a
manifest, every agent declares its persona/skills/model/capabilities
in an **agent manifest**, and a runtime verifier checks those
declarations match reality before every invocation.

## Goals

1. **Inventory** — a machine-readable list of every agent across every
   orchestrator, queryable with `agentctl list`.
2. **Integrity** — SHA256-pinned persona + skill files; refuse to run
   an agent whose files have changed without an approved version bump.
3. **Authorization** — each agent declares its allowed
   models/skills/tools/egress/runtime; the runtime enforces.
4. **Auditability** — every agent invocation emits a structured event
   (who called it, which version, which skills fired, which model,
   what egress it attempted) into the stack's observability pipeline.
5. **Lifecycle control** — enable/disable/rollback an agent without
   editing orchestrator internals; `agentctl disable` kills all
   registered entry points in one shot.
6. **Drift detection** — consumes SECURITY-007 to alert when a
   deployed persona no longer matches its manifest hash.

## Non-Goals

- Not a prompt-versioning system for ad-hoc chats (those are
  disposable).
- Not a replacement for FEATURE-051 skills — this **consumes** the
  skills registry, doesn't replace it.
- Not an IdP for humans — FEATURE-055 (Authelia) does that.
- No multi-tenant agent marketplace. Single-operator stack.

## Agent Manifest Schema

Each agent lives at `agents/<name>/agent.manifest.yaml`:

```yaml
name: research-assistant
version: 1.4.0
description: Long-form research + citation agent
owner: tim
status: enabled                # enabled | disabled | deprecated

persona:
  path: personas/research.md
  sha256: 9f2a1c...             # verified before every invocation

model:
  primary: ollama/llama3.1:70b-instruct
  fallback: ollama/mistral-small
  temperature_max: 0.7

skills:
  - id: web-search
    version: ">=2.0.0"
    sha256: 7b3e4d...
  - id: citation-formatter
    version: "1.x"

capabilities:
  tools: [http_get, file_read]      # explicit allowlist
  egress:
    - duckduckgo.com
    - arxiv.org
    - "*.wikipedia.org"
  filesystem:
    read: [shared/research-inputs/]
    write: [shared/research-outputs/]
  secrets: []                        # no credential access

runtime:
  orchestrator: nemoclaw             # nemoclaw | n8n | flowise | langflow | direct
  sandbox: openshell                 # openshell | docker | none   (ties to FEATURE-058)
  max_tokens_per_invocation: 32000
  max_invocations_per_hour: 50
  timeout_seconds: 600

governance:
  requires_human_approval: false
  log_level: full                    # full | metadata | minimal
  retention_days: 90
  pii_scrub: true
```

## `agentctl` CLI

```
agentctl list                         # all agents + status + version
agentctl show <name>                  # full resolved manifest
agentctl verify <name>                # rehash persona + skills, compare
agentctl verify --all                 # stack-wide integrity scan
agentctl diff <name> <version>        # manifest diff vs prior
agentctl enable <name>
agentctl disable <name>               # revokes all entry points
agentctl rollback <name> <version>
agentctl audit <name> [--since 24h]   # invocation log
agentctl drift                        # anything failing verify
agentctl export                       # JSON dump for backup
```

## Registry Database

SQLite at `/var/lib/hts-ai/agent-registry.db`:

- `agents` — name, version, manifest SHA, status, enabled_at, owner
- `agent_versions` — full version history (append-only)
- `agent_events` — invocation events (agent, caller, model, skills_used,
  tokens, duration, egress_attempts, outcome)
- `agent_drift` — persona/skill hash mismatches, resolved/unresolved

Written by the runtime wrappers; read by `agentctl`, Grafana, and the
observability pipeline (SECURITY-005).

## Runtime Integration

Each orchestrator gets a thin **agent-registry shim**:

- **nemoclaw / htsclaw** — wrapper around invocation that:
  1. Loads manifest by name.
  2. Verifies SHA256 of persona + every declared skill.
  3. Checks status == enabled and rate limits.
  4. Emits `agent_event` (started).
  5. Calls into OpenShell sandbox if `runtime.sandbox: openshell`.
  6. Captures outcome + egress attempts.
  7. Emits `agent_event` (completed).
- **n8n / flowise / langflow** — custom node / tool that wraps LLM
  calls with the same verification pipeline.
- Failure to verify = hard-fail with structured error, Grafana alert.

## Phases

### Phase 1 — Schema + registry DB + `agentctl list/show/verify`
- Define `agent.manifest.yaml` JSON schema + validator.
- Scaffold `agents/` directory with one reference agent (e.g., the
  nemoclaw default persona migrated in).
- SQLite registry + Python-based `agentctl` CLI.
- Read-only: verify works, but no runtime gating yet.

### Phase 2 — Runtime verification (nemoclaw first)
- Nemoclaw wrapper enforces SHA256 check + status check before
  every invocation. Hard-fail on mismatch.
- Emit `agent_event` rows for every invocation.
- `agentctl audit` surfaces the event stream.

### Phase 3 — Authorization enforcement
- Capability allowlists enforced: model pinning (reject if agent
  calls a model not in manifest), egress (via OpenShell policy
  generation from manifest), tool allowlist (via orchestrator
  config generation).
- `agentctl drift` surfaces any enforcement bypasses.

### Phase 4 — Lifecycle commands
- `agentctl enable/disable/rollback` with cascading effect:
  disable updates registry + regenerates orchestrator configs +
  restarts relevant services.
- Pre-commit hook validates any modified agent manifest.

### Phase 5 — Expand to other orchestrators
- n8n custom node, flowise tool, langflow component, open-webui
  pipeline function. Each enforces the same verification before LLM
  calls.
- Grafana dashboard: agent invocation rate, drift count, top skills,
  egress violations.

## Acceptance Criteria

- [ ] `agents/` directory with at least one committed agent manifest.
- [ ] `agentctl verify --all` passes on a clean install.
- [ ] Modifying a persona file without bumping the manifest hash
      causes the next nemoclaw invocation to hard-fail with a
      structured drift error.
- [ ] Setting `status: disabled` in a manifest blocks all invocation
      paths within 60 seconds of `agentctl disable`.
- [ ] An agent declaring `egress: [arxiv.org]` cannot reach
      `example.com` when running inside its OpenShell sandbox
      (integration with FEATURE-058).
- [ ] Every invocation produces an `agent_event` row retained per the
      manifest's `retention_days`.
- [ ] Grafana dashboard shows per-agent invocation rate + drift.

## Risks

| Risk | Mitigation |
|------|-----------|
| Manifest drift churn (rehash-on-every-save fatigue) | `agentctl bump <name>` command auto-updates hashes + bumps version |
| Orchestrator lock-in (each needs a shim) | Start with nemoclaw; other orchestrators get wrappers only when adopted in earnest |
| Rate-limit enforcement false positives | Per-agent + global toggle; `governance.bypass_rate_limits` escape hatch for admin use |
| Storage growth from full-log retention | `retention_days` + log_level tiers (full/metadata/minimal) |
| Sandbox unavailability (OpenShell alpha) | `runtime.sandbox: none` is a legal value; enforcement degrades but registry still audits |

## Open Questions

- Should `agentctl` be a standalone binary or a component script like
  the rest of the stack? → **Propose**: Python CLI installed into a
  pipx venv, wrapped by `scripts/components/agent-registry/agentctl`
  to match existing component conventions.
- Signing: hashes now, full ed25519 signatures later? → Start with
  SHA256; revisit when multi-operator support is a concern.
- How do we handle persona files that legitimately include dynamic
  data (date, context)? → Personas are **templates**; dynamic data
  injected at call time is not hashed, only the template is.

## References

- FEATURE-051 — skills system (this feature consumes skill hashes)
- FEATURE-058 — OpenShell sandbox tier (runtime enforcement of egress/fs)
- SECURITY-005 — observability (event sink)
- SECURITY-007 — persona drift detection (registry is the source of truth it compares against)
- SECURITY-008 — skill supply chain vetting (skills must be vetted before manifest can pin them)
- SECURITY-009 — secret scoping (agent `capabilities.secrets` is the allowlist)
