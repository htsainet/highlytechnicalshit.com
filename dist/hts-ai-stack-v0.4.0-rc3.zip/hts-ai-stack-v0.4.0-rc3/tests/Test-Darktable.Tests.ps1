$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/darktable'
    $script:ComponentScript = Join-Path $script:ComponentDir 'darktable.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'darktable.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'darktable file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }

    It 'CONTEXT.md exists' {
        Join-Path $script:ComponentDir 'CONTEXT.md' | Should -Exist
    }

    It 'REFERENCES.md exists' {
        Join-Path $script:ComponentDir 'REFERENCES.md' | Should -Exist
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'darktable component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines darktable_install function' {
        $script:ComponentContent | Should -Match 'darktable_install\s*\(\)'
    }

    It 'defines darktable_configure function' {
        $script:ComponentContent | Should -Match 'darktable_configure\s*\(\)'
    }

    It 'defines darktable_start function' {
        $script:ComponentContent | Should -Match 'darktable_start\s*\(\)'
    }

    It 'defines darktable_stop function' {
        $script:ComponentContent | Should -Match 'darktable_stop\s*\(\)'
    }

    It 'defines darktable_health function' {
        $script:ComponentContent | Should -Match 'darktable_health\s*\(\)'
    }

    It 'defines darktable_restart function' {
        $script:ComponentContent | Should -Match 'darktable_restart\s*\(\)'
    }

    It 'defines darktable_destroy function' {
        $script:ComponentContent | Should -Match 'darktable_destroy\s*\(\)'
    }

    It 'defines darktable_status function' {
        $script:ComponentContent | Should -Match 'darktable_status\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/darktable/darktable\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'darktable no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/darktable\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/darktable/darktable\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
