# build-usb.sh — Build an Autoinstall USB Drive

Creates a bootable Ubuntu 24.04 USB drive that installs the AI stack
completely unattended. Boots the installer, runs `autoinstall.yaml`, and
reboots into a ready system with no user interaction required.

---

## What It Does

1. Downloads the Ubuntu 24.04.2 Server ISO (~2.7 GB) and verifies its SHA-256
2. Extracts the ISO contents to a temp working directory
3. Injects `autoinstall.yaml` as `user-data` (plus empty `meta-data` /
   `vendor-data` for cloud-init)
4. Patches GRUB (both BIOS and EFI) to default-boot the autoinstall entry
   with a 5-second timeout
5. Extracts the original ISO's MBR and EFI boot sectors
6. Repackages everything as a new hybrid ISO (`ubuntu-ai-stack.iso`)
7. Writes the ISO to the target USB drive using `dd`

---

## Prerequisites

```bash
sudo apt install -y xorriso wget
```

You must also customize the unattended bootstrap auth in `autoinstall.yaml` before running:

```bash
# Replace any unattended bootstrap auth placeholder with a real secret
nano autoinstall.yaml
```

Browser-based GitHub auth is used by [00-bootstrap.md](00-bootstrap.md), but it
does not work for unattended installs. The autoinstall path still needs a
non-interactive bootstrap credential embedded in `autoinstall.yaml` so the
machine can clone the repo without a browser session.

The script will fail with a clear error if a placeholder such as
`REPLACE_WITH_YOUR_PAT` or `REPLACE_WITH_BOOTSTRAP_AUTH` is still present.

---

## Usage

```bash
# Interactive — prompts to select USB device from lsblk output
./build-usb.sh

# Direct — skip the prompt
./build-usb.sh /dev/sdX
```

> **Warning:** The final `dd` step writes directly to the USB device and is
> **destructive**. Double-check the device path before confirming.

---

## Output

- `ubuntu-ai-stack.iso` — reusable hybrid ISO (can also be written with Balena Etcher)
- USB drive ready to boot into unattended install

---

## Notes

- The ISO download is cached — re-runs skip re-download if the file is present
  and the checksum passes.
- The working directory is `/tmp/ubuntu-ai-stack-usb` and is cleaned up at the
  start of each run.
- GRUB is configured to autoinstall after 5 seconds; the original Ubuntu menu
  entries are preserved below it.
