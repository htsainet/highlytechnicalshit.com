#!/usr/bin/env bash
# scripts/bundles/full-stack.sh — DEPRECATED
#
# This script is no longer used. install.sh now calls host scripts directly
# and delegates all service deployment to converge.sh.
#
# Use instead:
#   ./install.sh                              # full install (wizard + host + converge)
#   ./scripts/utils/converge.sh --yes         # service convergence only
#   ./scripts/utils/reconfigure.sh --converge # toggle services + converge
set -euo pipefail

echo "⚠  full-stack.sh is deprecated. Use install.sh or converge.sh directly."
echo "   → ./install.sh"
echo "   → ./scripts/utils/converge.sh --yes"
exit 1
