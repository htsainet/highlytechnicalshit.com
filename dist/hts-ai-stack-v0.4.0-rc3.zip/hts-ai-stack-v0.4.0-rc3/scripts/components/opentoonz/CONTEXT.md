# OpenToonz — Component Context

## Purpose

OpenToonz is a professional 2D animation application originally developed
by Digital Video S.p.A. and used extensively by Studio Ghibli. It was
open-sourced in 2016 under the BSD license. Features include raster and
vector drawing, scanning, tweening, effects, and a node-based compositor.

## Location

`scripts/components/opentoonz/` — component directory

## Key Files

| File | Purpose |
|------|---------|
| `opentoonz.manifest.json` | Convergence manifest |
| `opentoonz.sh` | Install / configure / health script |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and notes |

## Notes

- Installed via PPA (`ppa:morevnaproject/opentoonz`)
- Desktop application — no Docker service or web UI
- Supports both raster and vector animation workflows
- Used by Studio Ghibli for films like Spirited Away and Ponyo
