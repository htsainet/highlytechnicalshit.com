#!/usr/bin/env bash
# scripts/lib/teardown.sh — Shared teardown functions (nuke / pave tiers)
# Source this file; do NOT run directly.
# Requires: common.sh and compose.sh sourced first.
#
# Tier 1 — NUKE:  Docker-only cleanup (containers, volumes, networks, images)
# Tier 2 — PAVE:  Host-level cleanup (NemoClaw, htsclaw, OpenShell, models, .env, etc.)
#                  Returns to post-bootstrap state. Call teardown_nuke() first.

# ── Tier 1: NUKE ─────────────────────────────────────────────────────────────

teardown_nuke() {
  # ── Graceful stop via component scripts ───────────────────────────────────
  step "Graceful service stop"
  for svc in htsclaw nemoclaw ollama bitnet open-webui openspace dashboard gitea \
             comfyui sillytavern deerflow duplicati stable-diffusion; do
    svc_script="$REPO_DIR/scripts/components/${svc}.sh"
    if [[ -f "$svc_script" ]]; then
      (
        source "$svc_script"
        fn="${svc//-/_}_stop"
        if declare -f "$fn" &>/dev/null; then
          "$fn" 2>/dev/null || true
        fi
      ) || true
    fi
  done

  # ── NemoClaw sandbox containers ───────────────────────────────────────────
  step "NemoClaw sandbox containers"
  if command -v nemoclaw &>/dev/null; then
    for sandbox in hts-ai-openshell-nemoclaw hts-ai-assistant-gpu \
                    hts-ai-assistant-cpu hts-ai-assistant-prod hts-ai-assistant-test; do
      info "Removing sandbox: $sandbox"
      if nemoclaw "$sandbox" destroy --yes 2>/dev/null; then
        ok "$sandbox destroyed"
      else
        info "$sandbox (not found or already removed)"
      fi
    done
    info "Stopping NemoClaw services..."
    nemoclaw stop 2>/dev/null || true
    ok "NemoClaw services stopped"
  else
    info "nemoclaw not in PATH — skipping"
  fi

  # ── htsclaw sandbox containers ───────────────────────────────────────────
  step "htsclaw sandbox containers"
  if command -v openshell &>/dev/null; then
    for sandbox in hts-ai-openshell-htsclaw-gpu; do
      if openshell sandbox get "$sandbox" &>/dev/null 2>&1; then
        info "Stopping htsclaw forward on port ${HTSCLAW_PORT:-18790}..."
        openshell forward stop -g "${HTSCLAW_GATEWAY_NAME:-htsclaw}" \
          "${HTSCLAW_PORT:-18790}" 2>/dev/null || true
        info "Removing htsclaw sandbox: $sandbox"
        openshell sandbox delete -g "${HTSCLAW_GATEWAY_NAME:-htsclaw}" \
          "$sandbox" 2>/dev/null \
          && ok "$sandbox destroyed" \
          || warn "Could not remove $sandbox"
      else
        info "$sandbox (not found or already removed)"
      fi
    done
  else
    info "openshell not in PATH — skipping htsclaw sandbox cleanup"
  fi

  # OpenShell cluster containers and volumes (managed by NemoClaw/htsclaw, not compose)
  for cname in openshell-cluster-nemoclaw openshell-cluster-htsclaw openshell-cluster; do
    if docker inspect "$cname" &>/dev/null 2>&1; then
      info "Removing stray OpenShell container: $cname"
      docker stop "$cname" 2>/dev/null || true
      docker rm   "$cname" 2>/dev/null \
        && ok "Removed container $cname" \
        || warn "Could not remove container $cname"
    fi
    if docker volume inspect "$cname" &>/dev/null 2>&1; then
      info "Removing stray OpenShell volume: $cname"
      docker volume rm "$cname" 2>/dev/null \
        && ok "Removed volume $cname" \
        || warn "Could not remove volume $cname"
    fi
  done

  # ── Docker compose stacks ────────────────────────────────────────────────
  step "Docker stacks"

  _nuke_compose() {
    local label="$1"
    local file="$2"
    if [[ -f "$file" ]]; then
      info "$label..."
      # Profiles are sourced from scripts/components/*.manifest.json at nuke time
      # so newly added services are always included without editing this file.
      local manifest_dir
      manifest_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)/scripts/components"
      local profile_flags=()
      while IFS= read -r p; do
        [[ -n "$p" ]] && profile_flags+=("--profile" "$p")
      done < <(python3 - "$manifest_dir" <<'PYEOF'
import json, glob, sys
seen = set()
# Support both flat and subfolder manifest layouts
for f in sorted(glob.glob(sys.argv[1] + '/*.manifest.json') + glob.glob(sys.argv[1] + '/*/*.manifest.json')):
    try:
        p = json.load(open(f)).get('profile', '').strip()
        if p and p not in seen:
            seen.add(p)
            print(p)
    except Exception:
        pass
PYEOF
)
      # Always include gitea and tailscale — no manifest, but part of the stack
      profile_flags+=("--profile" "gitea" "--profile" "tailscale")

      docker compose -f "$file" \
        "${profile_flags[@]}" \
        down --volumes --remove-orphans --timeout 20 2>/dev/null \
        && ok "$label — removed" \
        || warn "$label — some resources may already be absent"
    else
      warn "$label — compose file not found ($file), skipping"
    fi
  }

  _nuke_compose "Root stack"  "$REPO_DIR/docker-compose.yml"
  _nuke_compose "Prod stack"  "$REPO_DIR/instances/prod/docker-compose.yml"
  _nuke_compose "Test stack"  "$REPO_DIR/instances/test/docker-compose.yml"

  # ── Stray volumes ────────────────────────────────────────────────────────
  step "Stray volumes"
  local stray_volumes=(
    hts-ai_open_webui_data
    hts-ai-stack_jenkins_home
    hts-ai-stack_whisper_cache
    hts-ai-stack_xtts_models
    prod_ollama_prod
    test_ollama_test
  )
  for vol in "${stray_volumes[@]}"; do
    if docker volume inspect "$vol" &>/dev/null 2>&1; then
      docker volume rm "$vol" 2>/dev/null \
        && ok "Removed volume: $vol" \
        || warn "Could not remove volume: $vol"
    fi
  done

  # ── Docker networks ──────────────────────────────────────────────────────
  step "Docker networks"
  for net in hts-ai_ai-network openshell-cluster-nemoclaw openshell-cluster-htsclaw; do
    if docker network inspect "$net" &>/dev/null 2>&1; then
      docker network rm "$net" 2>/dev/null \
        && ok "Removed network: $net" \
        || warn "Could not remove $net (may have active endpoints)"
    fi
  done

  # ── Built images ─────────────────────────────────────────────────────────
  step "Built images"
  local img="bitnet-llama3-8b"
  if docker image inspect "$img" &>/dev/null 2>&1; then
    docker image rm "$img" 2>/dev/null \
      && ok "Removed image: $img" \
      || warn "Could not remove image: $img"
  fi

  # ── Smart Docker cleanup ─────────────────────────────────────────────────
  step "Docker cleanup"
  if command -v docker &>/dev/null; then
    local dangling
    dangling=$(docker image ls -f "dangling=true" -q 2>/dev/null)
    if [[ -n "$dangling" ]]; then
      info "Removing dangling images..."
      # shellcheck disable=SC2086
      docker image rm $dangling 2>/dev/null \
        && ok "Removed $(echo "$dangling" | wc -w) dangling image(s)" \
        || warn "Could not remove some dangling images"
    else
      info "No dangling images"
    fi

    local stopped
    stopped=$(docker ps -a --filter "status=exited" --format "{{.Names}}" 2>/dev/null | grep -E "^hts-ai-" || true)
    if [[ -n "$stopped" ]]; then
      info "Removing stopped HTS stack containers..."
      echo "$stopped" | while read -r cname; do
        docker rm "$cname" 2>/dev/null \
          && ok "Removed container: $cname" \
          || warn "Could not remove: $cname"
      done
    else
      info "No stopped HTS stack containers to clean"
    fi

    info "Pruning build cache..."
    docker builder prune -f 2>/dev/null \
      && ok "Build cache pruned" \
      || warn "Could not prune build cache"

    for net_pattern in "hts-ai_" "openshell-" "nemoclaw-" "htsclaw-"; do
      local unused
      unused=$(docker network ls --filter "type=custom" --format "{{.Name}}" 2>/dev/null | grep "$net_pattern" || true)
      if [[ -n "$unused" ]]; then
        echo "$unused" | while read -r net; do
          if ! docker network inspect "$net" 2>/dev/null | grep -q '"Containers": {'; then
            docker network rm "$net" 2>/dev/null \
              && ok "Removed unused network: $net" \
              || warn "Could not remove network: $net"
          fi
        done
      fi
    done

    # Final sweep — catch any remaining unused resources
    info "Running docker system prune..."
    docker system prune --all --force 2>/dev/null \
      && ok "System prune complete (unused images, networks, build cache removed)" \
      || warn "System prune encountered issues (non-fatal)"

    ok "Docker cleanup complete"
  else
    info "Docker not found; skipping cleanup"
  fi

  ok "Tier 1 (Nuke) complete — Docker resources removed."
}

# ── Tier 2: PAVE ─────────────────────────────────────────────────────────────
# Removes host-level software installed by the stack.
# Returns to post-bootstrap state (Docker, NVIDIA, NVM, dev tools remain).
# MUST call teardown_nuke() first.

teardown_pave() {
  # ── NemoClaw source tree + npm global link ───────────────────────────────
  step "NemoClaw source + npm link"
  if command -v npm &>/dev/null; then
    local npm_prefix
    npm_prefix=$(npm config get prefix 2>/dev/null || true)
    local nemoclaw_src="$HOME/.nemoclaw/source"
    if [[ -d "$nemoclaw_src" ]]; then
      info "Unlinking global nemoclaw binary..."
      (cd "$nemoclaw_src" && npm unlink --global 2>/dev/null) \
        && ok "npm unlink done" \
        || warn "npm unlink failed (may already be removed)"
    fi
    if [[ -n "$npm_prefix" && -L "$npm_prefix/bin/nemoclaw" ]]; then
      rm -f "$npm_prefix/bin/nemoclaw"
      ok "Removed $npm_prefix/bin/nemoclaw symlink"
    fi
    # Remove NVM-installed nemoclaw binary (npm global bin under active node version)
    if [[ -n "$npm_prefix" && -f "$npm_prefix/bin/nemoclaw" ]]; then
      rm -f "$npm_prefix/bin/nemoclaw"
      ok "Removed $npm_prefix/bin/nemoclaw"
    fi
  fi

  # NVIDIA curl installer wrapper script (~/.local/bin/nemoclaw)
  if [[ -f "$HOME/.local/bin/nemoclaw" ]]; then
    rm -f "$HOME/.local/bin/nemoclaw"
    ok "Removed ~/.local/bin/nemoclaw"
  fi

  # NVM-installed nemoclaw (any node version)
  for f in "$HOME"/.nvm/versions/node/*/bin/nemoclaw; do
    [[ -e "$f" ]] && rm -f "$f" && ok "Removed $f"
  done
  for d in "$HOME"/.nvm/versions/node/*/lib/node_modules/nemoclaw; do
    [[ -d "$d" ]] && rm -rf "$d" && ok "Removed $d"
  done

  if [[ -d "$HOME/.nemoclaw" ]]; then
    rm -rf "$HOME/.nemoclaw"
    ok "Removed ~/.nemoclaw/"
  else
    info "$HOME/.nemoclaw not present"
  fi

  # ── OpenShell binary + provider registrations ────────────────────────────
  step "OpenShell binary + providers"
  if command -v openshell &>/dev/null; then
    for provider in bitnet-local ollama-local; do
      if openshell provider list 2>/dev/null | grep -q "$provider"; then
        info "Removing OpenShell provider: $provider"
        openshell provider delete "$provider" 2>/dev/null \
          && ok "Removed provider: $provider" \
          || warn "Could not remove provider: $provider"
      fi
    done
  fi

  if [[ -f /usr/local/bin/openshell ]]; then
    sudo rm -f /usr/local/bin/openshell
    ok "Removed /usr/local/bin/openshell"
  else
    info "openshell not present"
  fi

  # Shadow install from nemoclaw onboard (installed when /usr/local/bin version
  # was a non-semver build like m-dev and the NVIDIA CLI rejected it)
  if [[ -f "$HOME/.local/bin/openshell" ]]; then
    rm -f "$HOME/.local/bin/openshell"
    ok "Removed ~/.local/bin/openshell (shadow install)"
  fi

  # OpenShell config directory (~/.config/openshell)
  if [[ -d "$HOME/.config/openshell" ]]; then
    rm -rf "$HOME/.config/openshell"
    ok "Removed ~/.config/openshell/"
  fi

  # ── htsclaw systemd health timer ─────────────────────────────────────────
  step "htsclaw systemd timer"
  local htsclaw_svc="hts-htsclaw-health"
  if [[ -f "/etc/systemd/system/${htsclaw_svc}.service" ]] \
     || [[ -f "/etc/systemd/system/${htsclaw_svc}.timer" ]]; then
    sudo systemctl disable --now "${htsclaw_svc}.timer"   2>/dev/null || true
    sudo systemctl disable --now "${htsclaw_svc}.service" 2>/dev/null || true
    sudo rm -f "/etc/systemd/system/${htsclaw_svc}.timer" \
               "/etc/systemd/system/${htsclaw_svc}.service"
    sudo systemctl daemon-reload 2>/dev/null || true
    ok "Removed ${htsclaw_svc} systemd timer + service"
  else
    info "htsclaw health timer not installed"
  fi

  # ── nemoclaw systemd health timer ────────────────────────────────────────
  step "nemoclaw systemd timer"
  local nemoclaw_svc="hts-nemoclaw-health"
  if [[ -f "/etc/systemd/system/${nemoclaw_svc}.service" ]] \
     || [[ -f "/etc/systemd/system/${nemoclaw_svc}.timer" ]]; then
    sudo systemctl disable --now "${nemoclaw_svc}.timer"   2>/dev/null || true
    sudo systemctl disable --now "${nemoclaw_svc}.service" 2>/dev/null || true
    sudo rm -f "/etc/systemd/system/${nemoclaw_svc}.timer" \
               "/etc/systemd/system/${nemoclaw_svc}.service"
    sudo systemctl daemon-reload 2>/dev/null || true
    ok "Removed ${nemoclaw_svc} systemd timer + service"
  else
    info "nemoclaw health timer not installed"
  fi

  # ── htsclaw UFW rules ────────────────────────────────────────────────────
  step "htsclaw firewall rules"
  if command -v ufw &>/dev/null; then
    local htsclaw_port="${HTSCLAW_PORT:-18790}"
    if sudo ufw status numbered 2>/dev/null | grep -q "${htsclaw_port}/tcp"; then
      sudo ufw delete allow from 100.64.0.0/10 to any port "$htsclaw_port" proto tcp 2>/dev/null || true
      sudo ufw delete allow from 127.0.0.0/8 to any port "$htsclaw_port" proto tcp 2>/dev/null || true
      sudo ufw delete deny "$htsclaw_port"/tcp 2>/dev/null || true
      ok "Removed UFW rules for htsclaw port $htsclaw_port"
    else
      info "No UFW rules for htsclaw port $htsclaw_port"
    fi
  fi

  # ── signal-cli ───────────────────────────────────────────────────────────
  step "signal-cli"
  if [[ -d /opt/signal-cli ]]; then
    sudo rm -rf /opt/signal-cli
    ok "Removed /opt/signal-cli/"
  fi
  if [[ -L /usr/local/bin/signal-cli ]]; then
    sudo rm -f /usr/local/bin/signal-cli
    ok "Removed /usr/local/bin/signal-cli symlink"
  else
    info "signal-cli not present"
  fi

  # ── GitHub CLI GPG key (installed by nemoclaw.sh) ────────────────────────
  # Leave gh itself (apt package) — just note it's present.

  # ── Model staging directories ────────────────────────────────────────────
  step "Model staging directories"
  for dir in "$HOME/models/approved" "$HOME/models/testing"; do
    if [[ -d "$dir" ]]; then
      rm -rf "$dir" 2>/dev/null || sudo rm -rf "$dir"
      ok "Removed $dir"
    fi
  done
  if [[ -d "$HOME/models" ]] && [[ -z "$(ls -A "$HOME/models" 2>/dev/null)" ]]; then
    rmdir "$HOME/models"
    ok "Removed ~/models (was empty)"
  fi

  # ── .env ─────────────────────────────────────────────────────────────────
  step ".env"
  if [[ -f "$REPO_DIR/.env" ]]; then
    rm -f "$REPO_DIR/.env"
    ok "Removed .env"
  else
    info ".env not present"
  fi

  # ── Repo node_modules ───────────────────────────────────────────────────
  step "Repo node_modules"
  if [[ -d "$REPO_DIR/node_modules" ]]; then
    rm -rf "$REPO_DIR/node_modules"
    ok "Removed node_modules/"
  else
    info "node_modules not present"
  fi

  # ── Git hooks ───────────────────────────────────────────────────────────
  step "Git hooks"
  if [[ -d "$REPO_DIR/.git/hooks" ]]; then
    local removed=0
    for hook in "$REPO_DIR/.git/hooks"/{pre-commit,post-commit,commit-msg}; do
      if [[ -f "$hook" ]]; then
        rm -f "$hook"
        ((removed++))
      fi
    done
    if (( removed > 0 )); then
      ok "Removed $removed git hook(s)"
    else
      info "No custom git hooks to remove"
    fi
  fi

  # ── Install manifest ────────────────────────────────────────────────────
  step "Install manifest"
  if [[ -f "$REPO_DIR/logs/manifest.json" ]]; then
    rm -f "$REPO_DIR/logs/manifest.json"
    ok "Removed logs/manifest.json"
  else
    info "manifest.json not present"
  fi

  ok "Tier 2 (Pave) complete — host returned to post-bootstrap state."
}
