# NVIDIA/NemoClaw#2686 — rebuild fails: Dockerfile Patch 4 literal-string assert breaks against OpenClaw 2026.4.24

| Field | Value |
|-------|-------|
| **Repo** | [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) |
| **Issue** | [#2686](https://github.com/NVIDIA/NemoClaw/issues/2686) |
| **State** | OPEN (likely fixed by [PR #2484](https://github.com/NVIDIA/NemoClaw/pull/2484), shipped in v0.0.30/v0.0.31) |
| **Severity** | high (destroys existing sandbox during failed rebuild) |
| **Labels** | bug, Integration: OpenClaw, Docker |
| **Opened** | 2026-04-29 |
| **Subscribed** | No (duplicate of [#2689](https://github.com/NVIDIA/NemoClaw/issues/2689)'s root cause; track via cron only) |

## Impact on us

Same root cause as [#2689](./NVIDIA-NemoClaw-2689.md): NemoClaw v0.0.29's
Dockerfile Step 17 Patch 4 has a literal-string `assert` against
`replaceConfigFile`'s `await writeConfigFile(params.nextConfig, {...})`
pattern, which no longer exists in OpenClaw 2026.4.24's source.

Distinct from #2689 in that this report focuses on the **rebuild** path:
`nemoclaw <name> rebuild` destroys the running sandbox during the recreate
step, and `nemoclaw onboard --resume` hits the same Patch 4 failure — leaving
the host with no working sandbox and only a tarball backup at
`~/.nemoclaw/rebuild-backups/<name>/<timestamp>/`.

## Workaround

Bumped `nemoclaw.manifest.json upstream.pinned_version` to `v0.0.31`, which
ships PR #2484's fix.

## Action when resolved

1. Confirm the watcher reports CLOSED.
2. Document any rebuild-specific behavior changes in
   `scripts/components/nemoclaw/CONTEXT.md` if the upstream fix changes the
   rebuild backup layout (PR #2227's `.openclaw-data` removal already changed
   it).

## Status log

- **2026-04-29** — Filed upstream as #2686 (same day as #2689; same root cause).
- **2026-04-29** — [PR #2484](https://github.com/NVIDIA/NemoClaw/pull/2484)
  merged.
- **2026-04-30** — Bumped our pin to v0.0.31. Added to `upstream-watch.sh`.
- **2026-04-30** — ✅ Verified: v0.0.31 onboard succeeded on this host
  (rebuild path not re-tested, but the underlying Patch 4 mismatch is
  gone). Tracker stays open until upstream marks it CLOSED.
