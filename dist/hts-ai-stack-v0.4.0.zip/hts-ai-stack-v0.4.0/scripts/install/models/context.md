# Model Registry Documentation

The file `scripts/install/models/registry.json` is the canonical source of truth for all models used by the HTS AI stack. It defines:

- Model identifier (e.g., `ollama` entries)
- Target environment (`test`, `prod`, etc.)
- Installation source scripts (`scripts/install/models/prod.sh`, `scripts/install/models/test.sh`)
- VRAM requirements and optional notes.

### How it works

- During `install.sh` or `converge.sh` the stack reads this JSON to decide which models to pull into Ollama.
- Each entry may have multiple `source` scripts that handle downloading, pulling, or converting the model.
- The `env` array specifies which environments the model should be available in. Typical values: `test` for development, `prod` for production.
- `vram_mb` indicates the minimum GPU memory required; the stack can skip models that exceed available VRAM.

### Adding a new model

1. Add a new object to the appropriate array (e.g., `ollama`).
2. Provide a unique `model` name matching Ollama's naming convention.
3. Add any `env` entries where the model should be installed.
4. Create or update the corresponding install script(s) referenced in `source`.
5. Set `vram_mb` based on the model’s GPU requirements.
6. Optionally add a `notes` field for human context.

### Updating an existing model

- Modify fields as needed (e.g., bump `vram_mb` after testing).
- Ensure any changes are reflected in the `source` scripts.

### Reference

- See `scripts/components/ollama/CONTEXT.md` for details on how Ollama uses the registry.
- The registry is version‑controlled; changes are reviewed via the normal PR process.
