# Ardour References

Last updated: 2026-04-17

## Upstream

- [Ardour](https://ardour.org/)
- [Ardour Manual](https://manual.ardour.org/)
- [GitHub — Ardour/ardour](https://github.com/Ardour/ardour)

## Package

- Ubuntu package: `ardour` (current version in Ubuntu 24.04: Ardour 8.x)
- Upstream builds: [ardour.org/download](https://ardour.org/download.html)

## Documentation

- [Ardour Getting Started Guide](https://manual.ardour.org/toc/)
- [JACK + Ardour Setup](https://manual.ardour.org/setting-up-your-system/)
