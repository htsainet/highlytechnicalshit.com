# install-heidisql.sh — HeidiSQL

Installs [HeidiSQL](https://www.heidisql.com/) on Ubuntu 24.04. Run this on a
**workstation** (not the AI server) to get a GUI database client for connecting
to MariaDB/MySQL/PostgreSQL instances in the stack.

```bash
./install-heidisql.sh
```

---

## Why the extra dependency?

Ubuntu 24.04 does not yet ship `libqt6pas` in the official repos. The script
fetches it from the upstream release before installing HeidiSQL.

| Package | Source |
|---|---|
| `libqt6pas6` | [github.com/davidbannon/libqt6pas](https://github.com/davidbannon/libqt6pas/releases/tag/v6.2.10) |
| `heidisql` | [github.com/HeidiSQL/HeidiSQL](https://github.com/HeidiSQL/HeidiSQL/releases/tag/v12.16) |

---

## What it does

| Step | Action |
|---|---|
| 1 | Checks `dpkg -s libqt6pas6` — installs from GitHub release if missing |
| 2 | Checks `dpkg -s heidisql` — downloads and installs v12.16 if missing |

Both steps are idempotent. Re-running skips already-installed packages.

---

## After install

Launch from the applications menu or:

```bash
heidisql
```

Connect to any database in the stack using its Docker network address or
`localhost` if port-forwarded. For remote connections over Tailscale, use the
server's Tailscale IP.
