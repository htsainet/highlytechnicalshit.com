# Daytona Sandbox — Devcontainer-Based Secure Agent Runtime

**Priority:** LOW (deferred — review in v0.6.0)
**Effort:** 10–14 hours
**Risk:** Medium — Daytona is a separate daemon with its own lifecycle; adds
operational surface area. However, hermes-agent (already tracked) supports
Daytona natively, providing a tested integration path.
**Target Release:** v0.6.0 (deferred from v0.5.0 — htsclaw covers agent
sandboxing; Daytona reserved for future coding-agent use cases)
**Status:** Deferred — removed from dashboard; revisit for coding-specific agents
**Depends on:** Dual-inference plan merged (llama-swap available on
`ai-network`)
**Blocks:** Nothing — comparison data informs FEATURE-012 decision

## Problem

Same as FEATURE-012: NemoClaw's gateway forces a single model for all
sandboxes, blocking true dual-backend routing. We need an alternative sandbox
with real security isolation for the CPU/BitNet workload.

## Solution

Run **Daytona** as a self-hosted workspace manager that creates isolated
devcontainer-based sandboxes with built-in security controls. Daytona provides
OCI-compliant workspaces with network isolation, resource limits, and
credential management — similar to NemoClaw's model but using the
devcontainer spec instead of containerd microVMs.

### Why Daytona

- **hermes-agent** (tracked in `docs/planning/feature-repos/REFERENCES.md`,
  23k★, MIT) lists Daytona as one of its 6 terminal backends alongside
  Docker, SSH, Singularity, and Modal
- hermes-agent supports **OpenClaw migration** — potential path to run the
  same agent framework in both NemoClaw and Daytona sandboxes
- Daytona uses the **devcontainer spec** — standard, portable, well-documented
- Self-hosted — no cloud dependency, runs on the same host
- Built-in workspace isolation with network policies

### Architecture

```text
NemoClaw GPU sandbox (existing)
  └─ containerd microVM → OpenShell gateway → llama-swap → Ollama (gemma4:e4b)

Daytona CPU sandbox (new)
  └─ devcontainer workspace → Docker network → llama-swap → BitNet (bitnet)

hermes-agent (future, optional)
  └─ Daytona terminal backend → same workspace → llama-swap → BitNet (bitnet)
```

### Security Isolation Comparison

| Property | NemoClaw (containerd microVM) | Daytona (devcontainer) |
|----------|------------------------------|------------------------|
| Kernel isolation | Separate kernel in microVM | Shared kernel + namespaces |
| Workspace isolation | k3s pod boundary | Devcontainer per workspace |
| Network egress | Proxy allowlist (10.200.0.1:3128) | Daytona network policies |
| Filesystem | Copy-on-write overlay in VM | Volume-backed workspace |
| Resource limits | k8s resource quotas | Docker cgroups via devcontainer |
| Credential mgmt | OpenShell provider registry | Daytona credential store |
| IDE integration | SSH + port forward | Native VS Code devcontainer |
| Production users | NVIDIA NemoClaw | Daytona Cloud, self-hosted orgs |
| Overhead | ~500MB (k3s cluster) | ~200MB (Daytona server) |

## Implementation Steps

### Phase 1 — Install Daytona Server

Add to `scripts/host/` or `scripts/components/` as a component script.

```bash
# Install Daytona (single binary, self-hosted)
curl -fsSL https://download.daytona.io/daytona/install.sh | \
  DAYTONA_SERVER_PORT=18794 bash

# Start server (systemd-managed)
daytona server start

# Verify
daytona server status
```

### Phase 2 — Configure Provider

Register Docker as the workspace provider (uses local Docker Engine).

```bash
# Set Docker as the default provider
daytona provider install docker-provider

# Configure target (local Docker)
daytona target set local-docker --provider docker-provider
```

### Phase 3 — Create Devcontainer Config

```jsonc
// docker/daytona-sandbox/.devcontainer/devcontainer.json
{
  "name": "hts-ai-cpu-sandbox",
  "image": "node:22-slim",
  "features": {
    "ghcr.io/devcontainers/features/common-utils:2": {}
  },
  "postCreateCommand": "npm install -g openclaw@latest",
  "containerEnv": {
    "OPENCLAW_MODEL": "bitnet",
    "OPENCLAW_INFERENCE_URL": "http://hts-ai-llama-swap:8081/v1",
    "OPENCLAW_API_KEY": "not-needed"
  },
  "forwardPorts": [18793],
  "hostRequirements": {
    "cpus": 4,
    "memory": "4gb"
  },
  "remoteUser": "sandbox"
}
```

### Phase 4 — Create Workspace

```bash
# Create workspace from devcontainer config
daytona create \
  --name hts-ai-cpu-sandbox \
  --target local-docker \
  --devcontainer-path docker/daytona-sandbox/.devcontainer/devcontainer.json

# Start OpenClaw inside the workspace
daytona exec hts-ai-cpu-sandbox -- openclaw start --port 18793
```

### Phase 5 — Network Integration

Connect Daytona workspace to the Docker `ai-network` so it can reach
llama-swap directly.

```bash
# Connect workspace container to ai-network
docker network connect ai-network $(daytona info hts-ai-cpu-sandbox --format '{{.ContainerId}}')
```

Alternatively, configure Daytona's Docker provider to use `ai-network` as the
default network for workspaces.

### Phase 6 — Component Script

New file: `scripts/components/daytona-sandbox/daytona-sandbox.sh`

- Install Daytona server if not present
- Register Docker provider
- Create workspace from devcontainer config
- Connect to ai-network
- Start OpenClaw agent
- Health check: `daytona info hts-ai-cpu-sandbox`

### Phase 7 — hermes-agent Integration (stretch goal)

If hermes-agent evaluation (tracked separately) proceeds:

```bash
# hermes-agent can use Daytona as its terminal backend
hermes config set terminal.backend daytona
hermes config set terminal.daytona.workspace hts-ai-cpu-sandbox
```

This gives a second agent framework running in the same Daytona workspace,
providing a direct comparison of OpenClaw vs hermes-agent.

### Phase 8 — Dashboard Integration

- Add Daytona sandbox card to dashboard (port 18793)
- Add Daytona server status to monitoring panel

## Port Allocation

| Host Port | Service | Notes |
|-----------|---------|-------|
| 18794 | Daytona server API | Management plane |
| 18793 | Daytona sandbox (OpenClaw) | Adjacent to NemoClaw ports (18789–18792) |

## Evaluation Criteria

| Metric | NemoClaw Baseline | Daytona Target |
|--------|-------------------|----------------|
| Workspace start time | ~60s (k3s + microVM) | ~10–15s (devcontainer build) |
| Memory overhead | ~500MB (k3s cluster) | ~200MB (Daytona server) |
| Inference latency | gateway + proxy hop | Direct Docker network |
| Isolation model | containerd microVM | Container namespaces |
| Egress control | Proxy allowlist (fine-grained) | Daytona network policies |
| IDE integration | SSH tunnel | Native devcontainer |
| Agent compatibility | OpenClaw only | OpenClaw + hermes-agent |
| Operational complexity | NemoClaw CLI + openshell | Daytona CLI + devcontainer spec |

## Risks

- Daytona adds a **second management daemon** (alongside the OpenShell
  gateway) — more moving parts to monitor and maintain
- Daytona's Docker provider network integration may require manual
  `docker network connect` to reach `ai-network` services
- devcontainer spec isolation is **weaker than gVisor** — shared kernel,
  standard container namespaces. Acceptable for CPU-only workload but not
  equivalent to NemoClaw's microVM boundary
- Daytona is younger than gVisor — smaller community, less battle-tested for
  security-critical workloads
- hermes-agent integration is a stretch goal that depends on a separate
  evaluation (tracked in feature repos)

## Trade-offs vs FEATURE-012 (gVisor)

| | gVisor (FEATURE-012) | Daytona (FEATURE-013) |
|---|---|---|
| **Isolation strength** | Stronger (user-space kernel) | Standard containers |
| **Operational lift** | Lower (Docker runtime flag) | Higher (separate daemon) |
| **Agent flexibility** | OpenClaw only | OpenClaw + hermes-agent |
| **IDE integration** | None (Docker exec) | Native devcontainer |
| **Ecosystem** | Google (production-proven) | Growing (self-hosted focus) |
| **Future value** | Single-purpose sandbox | Multi-agent platform |

## Decision Point

After evaluating both FEATURE-012 and FEATURE-013:

1. **Keep NemoClaw + gVisor** — strongest isolation, lowest overhead
2. **Keep NemoClaw + Daytona** — if hermes-agent and devcontainer workflow
   add significant value beyond raw isolation
3. **Keep all three** — NemoClaw (GPU), gVisor (secure CPU), Daytona
   (development/agent experimentation)
4. **Consolidate** — if one clearly dominates on isolation + operational cost
