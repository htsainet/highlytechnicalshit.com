# Host Provisioning — References

Last updated: 2026-04-04 22:45:00

## Package Sources

| Source | URL | Used by |
|--------|-----|---------|
| Docker CE apt repo | <https://download.docker.com/linux/ubuntu> | `docker.sh` |
| NVIDIA Container Toolkit | <https://nvidia.github.io/libnvidia-container/stable/> | `nvidia.sh` |
| NodeSource | <https://deb.nodesource.com/setup_lts.x> | `node.sh` |

## Prerequisite Tracker

| Item | Detail |
|------|--------|
| Tracker file | `prerequisites.json` (this folder) |
| Enforcement test | `tests/Test-HostPrerequisites.Tests.ps1` |
| Valid scopes | `core`, `dev`, `admin`, `optional`, `service`, `networking`, `tooling` |
| Coverage | `bootstrap.sh`, `scripts/host/*`, `scripts/install/**/*`, `scripts/components/**/*` |

## Related Documentation

- [NVIDIA Container Toolkit install guide](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html)
- [Docker Engine install on Ubuntu](https://docs.docker.com/engine/install/ubuntu/)
- [NodeSource distributions](https://github.com/nodesource/distributions)
