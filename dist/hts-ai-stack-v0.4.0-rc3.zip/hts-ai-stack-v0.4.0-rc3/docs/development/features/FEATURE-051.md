# FEATURE-051 — Agent Skills for Context Engineering (Reference)

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | LOW |
| **Effort** | < 15 minutes |
| **Risk** | Low — read-only clone into data/references/, no runtime impact |
| **Target Release** | v0.5.0 |
| **Depends on** | Nothing |
| **Blocks** | Nothing |

## Problem

Building effective AI agent pipelines (DeerFlow, OpenSpace, n8n workflows) requires understanding context engineering — how to manage context windows, avoid attention degradation, design multi-agent architectures, and build effective tool interfaces. This knowledge is scattered across blog posts and papers.

## Solution

Clone the [Agent Skills for Context Engineering](https://github.com/muratcankoylan/agent-skills-for-context-engineering) repository into `data/references/` as a local reference. This is a curated collection of 14 skills covering context management for production AI agent systems.

### Implementation (complete)

Added clone step in `scripts/host/tools.sh` alongside the Harvard ML Systems book:

- Shallow-clones into `data/references/agent-skills-context-engineering`
- Idempotent: pulls on re-run, skips on network failure
- `data/` is gitignored

### Skills included

| Category | Skills |
|----------|--------|
| Foundational | context-fundamentals, context-degradation, context-compression |
| Architectural | multi-agent-patterns, memory-systems, tool-design, filesystem-context, hosted-agents |
| Operational | context-optimization, latent-briefing, evaluation, advanced-evaluation |
| Development | project-development |
| Cognitive | bdi-mental-states |

### Relevance to stack components

| Component | Relevant skills |
|-----------|----------------|
| DeerFlow agents | multi-agent-patterns, memory-systems, context-optimization |
| OpenSpace | hosted-agents, tool-design |
| n8n workflows | tool-design, filesystem-context |
| Ollama/llama-swap | context-compression, context-degradation |
| AI dev toolkit | context-fundamentals, project-development |

## Acceptance criteria

- [x] Clone step added to `scripts/host/tools.sh` under reference books
- [x] Idempotent with pull-on-rerun
- [ ] Verified clone completes on target machine

## Upstream

| Resource | Link |
|----------|------|
| GitHub | <https://github.com/muratcankoylan/agent-skills-for-context-engineering> |
| DeepWiki | <https://deepwiki.com/muratcankoylan/Agent-Skills-for-Context-Engineering> |
| Academic citation | [Meta Context Engineering via Agentic Skill Evolution](https://arxiv.org/pdf/2601.21557) (Peking University, 2026) |

## Notes

- Also available as a Claude Code plugin: `/plugin marketplace add muratcankoylan/Agent-Skills-for-Context-Engineering`
- Platform-agnostic — principles apply to any agent framework, not just Claude
- Pairs well with the Harvard ML Systems book (FEATURE-048) as complementary reference material
