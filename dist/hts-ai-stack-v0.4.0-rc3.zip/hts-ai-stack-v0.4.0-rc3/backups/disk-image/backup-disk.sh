#!/usr/bin/env bash
# backups/disk-image/backup-disk.sh — Full disk image via dd + gzip to NAS
#
# Creates a compressed byte-for-byte copy of the system disk. This is
# the nuclear option — if everything else fails, you can restore from
# this image with dd.
#
# The image is piped through gzip in real-time so no local staging space
# is needed. Only used blocks are meaningfully compressed, so the output
# is typically 40-60% of the used disk space.
#
# Requires:
#   - Root privileges (reads raw block device)
#   - NAS mounted at /mnt/htsai-disk-image (or --dest override)
#   - Enough NAS space for the compressed image
#
# Usage:
#   sudo ./backups/disk-image/backup-disk.sh [options]
#
# Options:
#   --device <path>   Source block device          (default: auto-detect root disk)
#   --dest   <path>   NAS destination directory    (default: /mnt/htsai-disk-image)
#   --level  <1-9>    Gzip compression level       (default: 6)
#   --bs     <size>   Block size for dd            (default: 64K)
#   --stop-docker     Stop Docker before imaging, restart after
#   --verify          Verify image header after write
#   --dry-run         Print every action without making changes
#   -h, --help        Show this help

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
step()  { echo -e "\n${CYAN}══ $* ══${NC}"; }
fail()  { echo -e "${RED}[FAIL]${NC} $*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || fail "Must be run as root: sudo $0 $*"

# ── Defaults ───────────────────────────────────────────────────────────────────
DEVICE=""
DEST="/mnt/htsai-disk-image"
GZIP_LEVEL=6
BLOCK_SIZE="64K"
DRY_RUN=false
VERIFY=false
STOP_DOCKER=false

# ── Argument parsing ───────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --device)   DEVICE="$2";     shift 2 ;;
    --dest)     DEST="$2";       shift 2 ;;
    --level)    GZIP_LEVEL="$2"; shift 2 ;;
    --bs)       BLOCK_SIZE="$2"; shift 2 ;;
    --stop-docker) STOP_DOCKER=true; shift ;;
    --verify)   VERIFY=true;     shift ;;
    --dry-run)  DRY_RUN=true;    shift ;;
    -h|--help)  grep '^# ' "$0" | head -30; exit 0 ;;
    *) fail "Unknown option: $1" ;;
  esac
done

run() {
  if "$DRY_RUN"; then
    echo "  [dry-run] $*"
  else
    "$@"
  fi
}

# ── Banner ─────────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║       Full Disk Image Backup (dd + gzip → NAS)      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── Step 1: Auto-detect source device ──────────────────────────────────────────
step "1 — Identify source device"

if [[ -z "$DEVICE" ]]; then
  ROOT_PART=$(df / | tail -1 | awk '{print $1}')
  ROOT_DISK=$(lsblk -ndo PKNAME "$ROOT_PART" 2>/dev/null || true)
  if [[ -n "$ROOT_DISK" ]]; then
    DEVICE="/dev/${ROOT_DISK}"
  else
    DEVICE="$ROOT_PART"
    warn "Could not determine parent disk — using partition ${DEVICE}"
  fi
fi

if [[ ! -b "$DEVICE" ]]; then
  fail "${DEVICE} is not a block device"
fi

DISK_SIZE=$(lsblk -bndo SIZE "$DEVICE" 2>/dev/null || blockdev --getsize64 "$DEVICE")
DISK_SIZE_GB=$(( DISK_SIZE / 1073741824 ))

info "Source device : ${DEVICE}"
info "Disk size     : ${DISK_SIZE_GB} GB (${DISK_SIZE} bytes)"

echo ""
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT "$DEVICE" 2>/dev/null || true
echo ""

# ── Step 2: Validate destination ───────────────────────────────────────────────
step "2 — Validate destination"

if ! mountpoint -q "$DEST" 2>/dev/null; then
  _check="$DEST"
  _mounted=false
  while [[ "$_check" != "/" ]]; do
    if mountpoint -q "$_check" 2>/dev/null; then
      _mounted=true; break
    fi
    _check="$(dirname "$_check")"
  done
  if ! "$_mounted"; then
    fail "${DEST} is not under a mounted filesystem.\n  Mount the NAS share first:\n    sudo mkdir -p ${DEST}\n    sudo mount -t nfs <nas>:/volume1/htsai-disk-image ${DEST}"
  fi
fi

DEST_FREE=$(df --output=avail -B1 "$DEST" | tail -1 | tr -d ' ')
DEST_FREE_GB=$(( DEST_FREE / 1073741824 ))
info "Destination   : ${DEST}"
info "Free space    : ${DEST_FREE_GB} GB"

# Rough estimate: compressed image is about 50% of disk size
ESTIMATED_SIZE=$(( DISK_SIZE / 2 ))
ESTIMATED_GB=$(( ESTIMATED_SIZE / 1073741824 ))

if (( DEST_FREE < ESTIMATED_SIZE )); then
  warn "Destination may not have enough space!"
  warn "Estimated compressed size: ~${ESTIMATED_GB} GB, available: ${DEST_FREE_GB} GB"
  echo ""
  read -rp "Continue anyway? (y/N): " CONTINUE
  [[ "${CONTINUE,,}" == "y" ]] || exit 1
else
  ok "Estimated ~${ESTIMATED_GB} GB compressed, ${DEST_FREE_GB} GB available"
fi

# ── Step 3: Pre-flight safety checks ──────────────────────────────────────────
step "3 — Safety checks"

DOCKER_WAS_RUNNING=false
RUNNING_CONTAINERS=$(docker ps -q 2>/dev/null | wc -l || echo "0")
if [[ "$RUNNING_CONTAINERS" -gt 0 ]]; then
  if "$STOP_DOCKER"; then
    info "Stopping Docker for consistent disk image (--stop-docker)..."
    DOCKER_WAS_RUNNING=true
    run systemctl stop docker
    ok "Docker stopped"
  else
    warn "${RUNNING_CONTAINERS} Docker container(s) currently running"
    warn "For a perfectly consistent image, use --stop-docker or stop manually:"
    warn "  sudo systemctl stop docker"
    echo ""
    read -rp "Continue with Docker running? (y/N): " CONTINUE
    [[ "${CONTINUE,,}" == "y" ]] || exit 1
  fi
else
  ok "No Docker containers running"
fi

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
HOSTNAME=$(hostname)
OUTPUT="${DEST}/${HOSTNAME}-${DEVICE##*/}-${TIMESTAMP}.img.gz"

info "Output file   : ${OUTPUT}"
info "Block size    : ${BLOCK_SIZE}"
info "Compression   : gzip -${GZIP_LEVEL}"
echo ""

if ! "$DRY_RUN"; then
  echo "╔══════════════════════════════════════════════════════╗"
  echo "║  WARNING: This will read the ENTIRE disk.            ║"
  echo "║  The system will be slow during the backup.          ║"
  echo "║  Estimated time: 30-90 minutes over NFS.             ║"
  echo "╚══════════════════════════════════════════════════════╝"
  echo ""
  read -rp "Start disk image backup? (y/N): " CONFIRM
  [[ "${CONFIRM,,}" == "y" ]] || { info "Aborted."; exit 0; }
fi

# ── Step 4: Create the image ──────────────────────────────────────────────────
step "4 — Creating disk image"

START_TIME=$(date +%s)

if "$DRY_RUN"; then
  echo "  [dry-run] dd if=${DEVICE} bs=${BLOCK_SIZE} status=progress | gzip -${GZIP_LEVEL} > ${OUTPUT}"
else
  info "Starting dd → gzip pipeline..."
  info "Monitor progress: watch -n5 ls -lh ${OUTPUT}"
  echo ""

  dd if="$DEVICE" bs="$BLOCK_SIZE" status=progress 2>&1 \
    | gzip -"${GZIP_LEVEL}" \
    > "$OUTPUT"

  sync
fi

END_TIME=$(date +%s)
ELAPSED=$(( END_TIME - START_TIME ))
ELAPSED_MIN=$(( ELAPSED / 60 ))

# ── Step 5: Verify ────────────────────────────────────────────────────────────
step "5 — Verify"

if "$DRY_RUN"; then
  echo "  [dry-run] Would verify image integrity"
else
  IMAGE_SIZE=$(stat -c%s "$OUTPUT" 2>/dev/null || echo 0)
  IMAGE_SIZE_GB=$(echo "scale=2; $IMAGE_SIZE / 1073741824" | bc 2>/dev/null || echo "?")

  ok "Image created: ${OUTPUT}"
  info "Image size    : ${IMAGE_SIZE_GB} GB"
  info "Elapsed time  : ${ELAPSED_MIN} minutes (${ELAPSED}s)"
  info "Compression   : $(echo "scale=1; $IMAGE_SIZE * 100 / $DISK_SIZE" | bc 2>/dev/null || echo "?")% of disk"

  if "$VERIFY"; then
    info "Verifying image header (gzip integrity test)..."
    if gzip -t "$OUTPUT" 2>/dev/null; then
      ok "Image integrity verified ✓"
    else
      warn "Image integrity check FAILED — the file may be corrupt"
    fi
  fi

  # Write metadata sidecar
  METADATA="${OUTPUT%.img.gz}.meta.txt"
  {
    echo "# Disk Image Metadata"
    echo "# Generated by backup-disk.sh"
    echo ""
    echo "hostname=${HOSTNAME}"
    echo "device=${DEVICE}"
    echo "disk_size_bytes=${DISK_SIZE}"
    echo "disk_size_gb=${DISK_SIZE_GB}"
    echo "image_file=$(basename "$OUTPUT")"
    echo "image_size_bytes=${IMAGE_SIZE}"
    echo "timestamp=${TIMESTAMP}"
    echo "date=$(date -Iseconds)"
    echo "gzip_level=${GZIP_LEVEL}"
    echo "block_size=${BLOCK_SIZE}"
    echo "elapsed_seconds=${ELAPSED}"
    echo "kernel=$(uname -r)"
    echo "ubuntu=$(lsb_release -ds 2>/dev/null || echo 'unknown')"
    echo ""
    echo "# Partition layout at time of backup:"
    lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,UUID "$DEVICE" 2>/dev/null || true
    echo ""
    echo "# Restore command:"
    echo "#   gunzip -c ${OUTPUT} | sudo dd of=${DEVICE} bs=${BLOCK_SIZE} status=progress"
  } > "$METADATA"
  ok "Metadata written: ${METADATA}"
fi

# ── Done ──────────────────────────────────────────────────────────────────────

# Restart Docker if we stopped it
if "$DOCKER_WAS_RUNNING" && ! "$DRY_RUN"; then
  info "Restarting Docker (was stopped by --stop-docker)..."
  systemctl start docker
  ok "Docker restarted"
fi

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  Disk image backup complete!                         ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "  Restore (boot from USB, then):"
echo "    sudo mount -t nfs <nas>:/volume1/htsai-disk-image /mnt"
echo "    gunzip -c /mnt/$(basename "$OUTPUT") | sudo dd of=${DEVICE} bs=${BLOCK_SIZE} status=progress"
echo ""
echo "  List images on NAS:"
echo "    ls -lh ${DEST}/"
echo ""
