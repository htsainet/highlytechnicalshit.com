# OBS Studio Component

Last updated: 2026-04-17

## What happens here

OBS Studio is the standard for live streaming and screen recording on
Linux. Supports scene composition, NVENC hardware encoding, and a rich
plugin ecosystem.

## Files and structure

| File | Purpose |
|------|---------|
| `obs-studio.sh` | Full lifecycle: install, configure, start, stop, health |
| `obs-studio.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- Host-native desktop application — no Docker container or web UI
- Installed from the official OBS PPA for latest version
- NVENC hardware encoding available with NVIDIA GPU
- Supports streaming to Twitch, YouTube, and custom RTMP endpoints
