#!/usr/bin/env bash
# scripts/htsclaw/dashboard/tokens.sh — Extract OpenClaw auth tokens
#
# Downloads openclaw.json from the sandbox, extracts the gateway auth token,
# and writes it to a JSON sidecar file for the dashboard to consume.
# Ported from NemoClaw's _extract_dashboard_tokens().
#
# Can be sourced or run standalone.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
HTSCLAW_SANDBOX_NAME="${HTSCLAW_SANDBOX_NAME:-hts-ai-openshell-htsclaw-gpu}"
HTSCLAW_PORT="${HTSCLAW_PORT:-18792}"

# ── Token extraction ─────────────────────────────────────────────────────────

# htsclaw_extract_tokens — Pull auth token from sandbox and write sidecar JSON.
# Token file is restrictive (600) — not world-readable.
htsclaw_extract_tokens() {
  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not found — skipping token extraction."
    return 0
  fi

  step "htsclaw — extract dashboard tokens"

  local sandbox="$HTSCLAW_SANDBOX_NAME"
  local port="$HTSCLAW_PORT"
  local token_file="$REPO_DIR/resources/dashboard/htsclaw-tokens.json"

  # Verify sandbox exists
  if ! openshell sandbox get "$sandbox" &>/dev/null 2>&1; then
    warn "Sandbox '${sandbox}' not found — skipping token extraction."
    return 0
  fi

  local tmpdir
  tmpdir=$(mktemp -d)
  local dl_dir="$tmpdir/$sandbox"
  mkdir -p "$dl_dir"

  # Download openclaw.json from the sandbox
  openshell sandbox download "$sandbox" /sandbox/.openclaw/openclaw.json "$dl_dir/" 2>/dev/null || {
    warn "Failed to download openclaw.json from '${sandbox}'."
    rm -rf "$tmpdir"
    return 1
  }

  # Extract the gateway auth token
  local token
  token=$(python3 -c "
import json, sys
with open('$dl_dir/openclaw.json') as f:
    d = json.load(f)
print(d.get('gateway',{}).get('auth',{}).get('token',''))
" 2>/dev/null)

  rm -rf "$tmpdir"

  if [[ -z "$token" ]]; then
    warn "No auth token found in openclaw.json for '${sandbox}'."
    return 1
  fi

  # Write token sidecar JSON
  mkdir -p "$(dirname "$token_file")"

  local updated
  updated=$(date -Iseconds)

  python3 -c "
import json
data = {
    'sandbox': '$sandbox',
    'port': $port,
    'token': '$token',
    'updated': '$updated'
}
with open('$token_file', 'w') as f:
    json.dump(data, f, indent=2)
    f.write('\n')
" 2>/dev/null || {
    fail "Failed to write token file."
  }

  # Restrictive permissions — token is sensitive
  chmod 600 "$token_file"
  info "Dashboard token written → $token_file"
  ok "Token extracted for '${sandbox}' (:${port})."
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  htsclaw_extract_tokens
fi
