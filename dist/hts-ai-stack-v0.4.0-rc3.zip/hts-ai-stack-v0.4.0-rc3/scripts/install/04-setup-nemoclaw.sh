#!/usr/bin/env bash
# 04-setup-nemoclaw.sh — Sandbox engine dispatcher
#
# Routes to the correct sandbox component based on SANDBOX_ENGINE:
#   htsclaw  → scripts/components/htsclaw/htsclaw.sh  (self-managed)
#   nemoclaw → scripts/components/nemoclaw/nemoclaw.sh (NVIDIA-managed)
#   both     → run htsclaw then nemoclaw side-by-side
#   none     → skip
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

load_env
SANDBOX_ENGINE="${SANDBOX_ENGINE:-nemoclaw}"

banner "04 — Sandbox Setup (${SANDBOX_ENGINE})"

case "$SANDBOX_ENGINE" in
  htsclaw)
    exec bash "$REPO_DIR/scripts/components/htsclaw/htsclaw.sh" "$@"
    ;;
  nemoclaw)
    exec bash "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh" "$@"
    ;;
  both)
    bash "$REPO_DIR/scripts/components/htsclaw/htsclaw.sh" "$@"
    bash "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh" "$@"
    ;;
  none)
    info "Sandbox engine disabled — skipping."
    ;;
  *)
    warn "Unknown SANDBOX_ENGINE='${SANDBOX_ENGINE}' — skipping."
    ;;
esac
