# Tests

Repo checks are PowerShell-first and use Pester as the test runner, while still
calling native Linux tooling for the actual validation work.

## Commands

```bash
# changed markdown, shell, and config files
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1

# staged files only (same mode used by pre-commit)
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1 -Staged

# full repository sweep
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1 -All
```

## What Runs

| Check | Tool | Notes |
| --- | --- | --- |
| Markdown lint | `markdownlint-cli2` | Installed from `package.json` via `npm install` |
| Shell syntax | `bash -n` | Runs on selected `*.sh` files |
| Shell lint | `shellcheck` | Optional; test is skipped if `shellcheck` is not installed |
| Config parse | `node` + `jsonc-parser` + `yaml` | Validates selected `*.json`, `*.jsonc`, `*.yml`, `*.yaml` files |

## Hook Setup

```bash
pwsh -NoLogo -NoProfile -File tests/Install-GitHooks.ps1
```

That sets `core.hooksPath` to `.githooks/`, and `git commit` will then run the
Pester checks against staged markdown and shell files.

## Dependencies

- `pwsh`
- Pester module
- Node.js / NPM
- `markdownlint-cli2` from `npm install`
- `jsonc-parser` and `yaml` from `npm install`
- `bash`
- optional: `shellcheck`

## Notes

- Default mode checks changed files, not the entire repo. That keeps old
  unrelated markdown debt from blocking normal edits.
- Use `-All` when you explicitly want a full cleanup sweep.
