#!/usr/bin/env bash
# scripts/components/timeshift.sh — TimeShift system snapshots: install, configure, health
#
# Standalone usage:
#   ./scripts/components/timeshift.sh            # install + configure + health
#   ./scripts/components/timeshift.sh --health   # health check only
#   ./scripts/components/timeshift.sh --stop     # disable scheduled snapshots
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: TimeShift is a native system package, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
TIMESHIFT_SCHEDULE="${TIMESHIFT_SCHEDULE:-daily}"
TIMESHIFT_SNAPSHOT_COUNT="${TIMESHIFT_SNAPSHOT_COUNT:-5}"

# ── Functions ────────────────────────────────────────────────────────────────

# timeshift_install — Install TimeShift via apt
timeshift_install() {
  step "TimeShift — install"
  if command -v timeshift &>/dev/null; then
    info "TimeShift already installed ($(timeshift --version 2>/dev/null | head -1 || echo 'installed'))"
  else
    info "Installing TimeShift..."
    sudo apt-get update -qq
    sudo apt-get install -y timeshift
  fi
  ok "TimeShift installed."
}

# timeshift_configure — Configure snapshot schedule and excludes
# References existing setup logic in backups/timeshift/setup-timeshift.sh
timeshift_configure() {
  step "TimeShift — configure"
  local setup_script="$REPO_DIR/backups/timeshift/setup-timeshift.sh"

  if [[ -x "$setup_script" ]]; then
    info "Full configuration available via: sudo $setup_script"
    info "Schedule: ${TIMESHIFT_SCHEDULE}, snapshots to keep: ${TIMESHIFT_SNAPSHOT_COUNT}"
  else
    warn "Setup script not found: $setup_script"
    warn "Run 'sudo apt install timeshift' and configure manually"
  fi

  ok "TimeShift configured."
}

# timeshift_start — Enable systemd timer or take a manual snapshot
timeshift_start() {
  step "TimeShift — start"
  if ! command -v timeshift &>/dev/null; then
    warn "TimeShift not installed — run timeshift_install first"
    return 1
  fi

  info "To take a manual snapshot: sudo timeshift --create --comments 'manual'"
  info "To enable scheduled snapshots: configure via 'sudo timeshift-gtk' or setup script"
  ok "TimeShift ready."
}

# timeshift_stop — Disable scheduled snapshots
timeshift_stop() {
  step "TimeShift — stop"
  info "TimeShift snapshots can be managed via: sudo timeshift-gtk"
  info "Or disable the systemd timer: sudo systemctl disable timeshift-autosnap.timer"
  ok "TimeShift stop guidance provided."
}

# timeshift_health — Verify TimeShift is installed and config exists
timeshift_health() {
  step "TimeShift — health"
  if command -v timeshift &>/dev/null; then
    ok "TimeShift is installed."
    local snapshots
    snapshots=$(sudo timeshift --list 2>/dev/null | grep -c ">" || echo "0")
    info "Existing snapshots: ${snapshots}"
  else
    warn "TimeShift is not installed."
  fi
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      timeshift_install
      timeshift_configure
      timeshift_health
      ;;
    health)
      timeshift_health
      ;;
    stop)
      timeshift_stop
      ;;
  esac
fi
