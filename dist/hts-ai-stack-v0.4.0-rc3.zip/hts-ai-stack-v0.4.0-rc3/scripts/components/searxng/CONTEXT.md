# SearXNG Component

Last updated: 2026-04-15

## What happens here

SearXNG is a privacy-respecting metasearch engine. Used in the stack to
provide web search capabilities to AI agents and RAG pipelines without
sending queries to third-party search APIs.

## Files and structure

| File | Purpose |
|------|---------|
| `searxng.sh` | Full lifecycle: install, configure, start, stop, health |
| `searxng.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
