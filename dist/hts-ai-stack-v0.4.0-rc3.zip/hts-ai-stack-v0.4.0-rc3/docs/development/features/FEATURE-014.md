# NemoClaw Built-in OpenClaw Instance — Scope Review

**Priority:** HIGH
**Effort:** 4–6 hours
**Risk:** Low — research and documentation task; no infrastructure changes.
**Target Release:** v0.5.0
**Depends on:** Nothing
**Blocks:** Nothing directly — informs NemoClaw component script scope

## Problem

We discovered that NemoClaw installs its own OpenClaw instance as part of its
standard deployment. The stack currently scripts a standalone OpenClaw Docker
instance separately, duplicating functionality and adding maintenance overhead.

We need to review everything scripted against the standalone Docker instance to
determine:

1. What should be applied to **every NemoClaw instance** (prod, test, future)
2. What is **instance-level customization** (specific to one deployment)
3. What can be **removed entirely** (redundant with NemoClaw's built-in instance)

## Solution

Audit all scripts, configs, and documentation that reference the standalone
OpenClaw Docker instance. Categorize each item and update accordingly.

## Implementation Steps

### Phase 1 — Inventory

Grep for all references to the standalone OpenClaw instance:

- Docker compose services
- Component/install scripts
- Dashboard links
- Documentation references
- Persona/skill/tool configurations

### Phase 2 — Categorize

For each reference, classify as:

| Category | Action |
|----------|--------|
| **Universal** | Move to NemoClaw component script (applied to all instances) |
| **Instance-specific** | Keep as instance-level overlay (prod vs test) |
| **Redundant** | Remove — NemoClaw handles this natively |

### Phase 3 — Update Scripts

- Modify `scripts/components/nemoclaw/nemoclaw.sh` to apply universal configs
- Update instance composes (`instances/prod/`, `instances/test/`)
- Remove redundant standalone OpenClaw service definitions
- Update dashboard to point at NemoClaw's built-in instance

### Phase 4 — Documentation

- Update pipeline docs to reflect NemoClaw-native OpenClaw
- Update architecture diagrams
- Note any NemoClaw version requirements

## Acceptance Criteria

- [ ] Complete inventory of standalone OpenClaw references
- [ ] Each reference categorized (universal / instance / redundant)
- [ ] Scripts updated to target NemoClaw's built-in instance
- [ ] Dashboard links verified working
- [ ] No orphaned standalone OpenClaw Docker service definitions
