#!/usr/bin/env bash
# scripts/components/gitea.sh — Gitea self-hosted git: install, start, health
#
# Standalone usage:
#   ./scripts/components/gitea.sh            # install + configure + start + health
#   ./scripts/components/gitea.sh --health   # health check only
#   ./scripts/components/gitea.sh --stop     # stop gitea
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
GITEA_CONTAINER="${GITEA_CONTAINER:-hts-ai-gitea}"
GITEA_PORT="${GITEA_PORT:-3001}"

# ── Functions ────────────────────────────────────────────────────────────────

# gitea_install — Pull the Gitea Docker image
gitea_install() {
  step "Gitea — install"
  compose_pull gitea
  ok "Gitea image pulled."
}

# gitea_configure — Minimal configuration (env vars are in docker-compose.yml)
gitea_configure() {
  step "Gitea — configure"
  info "Gitea configuration is managed via docker-compose.yml environment block."
  ok "Gitea configured."
}

# gitea_start — Bring up Gitea via compose
gitea_start() {
  step "Gitea — start"
  compose_up gitea
  ok "Gitea started (internal port ${GITEA_PORT})."
}

# gitea_stop — Bring down Gitea
gitea_stop() {
  step "Gitea — stop"
  compose_down gitea
  ok "Gitea stopped."
}

# gitea_health — Probe the Gitea health endpoint
gitea_health() {
  step "Gitea — health"
  wait_for_healthy "$GITEA_CONTAINER" 60
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      gitea_install
      gitea_configure
      gitea_start
      gitea_health
      ;;
    health)
      gitea_health
      ;;
    stop)
      gitea_stop
      ;;
  esac
fi
