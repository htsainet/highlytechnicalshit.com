#!/usr/bin/env bash
# scripts/components/open-llm-vtuber/troubleshoot-chat.sh — diagnose a
# "Connection error" reply from the avatar chat endpoint. Probes the
# LLM path that open-llm-vtuber's agent actually uses (llama-swap by
# default, OpenAI-compatible /v1 API).

set -uo pipefail

VTUBER="${OPEN_LLM_VTUBER_CONTAINER:-hts-ai-open-llm-vtuber}"
SWAP="${LLAMA_SWAP_CONTAINER:-hts-ai-llama-swap}"
SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"

section() { printf '\n── %s ─────────────────────────────────────────────\n' "$1"; }

section "1. base_url / model in container conf.yaml"
docker exec "$VTUBER" sh -c \
  "grep -nE 'base_url|^[[:space:]]+model:|llm_provider' /app/conf.yaml" 2>&1

section "2. llama-swap container status"
docker ps -a --filter "name=$SWAP" --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'

section "3. ai-network membership (both containers must share it)"
for c in "$VTUBER" "$SWAP"; do
  nets=$(docker inspect "$c" --format '{{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}' 2>/dev/null)
  printf '%-30s : %s\n' "$c" "${nets:-MISSING}"
done

section "4. DNS + reachability from inside vtuber container"
docker exec "$VTUBER" sh -c "
  echo '--- getent llama-swap'; getent hosts llama-swap || echo '(name does not resolve)'
  echo '--- curl /v1/models'
  curl -sS --max-time 5 http://llama-swap:${SWAP_PORT}/v1/models -w '\nhttp_code=%{http_code}\n' || echo '(curl failed)'
" 2>&1

section "5. llama-swap models advertised"
docker exec "$SWAP" sh -c "
  curl -sS --max-time 5 http://localhost:${SWAP_PORT}/v1/models 2>/dev/null \
    | python3 -c 'import json,sys; d=json.load(sys.stdin); print(\"\n\".join(m[\"id\"] for m in d.get(\"data\",[])))' 2>/dev/null \
    || echo '(could not parse — raw response above)'
" 2>&1

section "6. open-llm-vtuber log lines about llm/connection"
docker logs --tail 200 "$VTUBER" 2>&1 \
  | grep -iE "openai|connection|connect|llama|ollama|qwen|httpx|httpcore|timeout|refused" \
  | tail -30 \
  || echo "(no matching lines)"

section "7. verdict hints"
echo "If §4 'getent' fails → containers aren't on the same docker network."
echo "If §4 curl returns connection refused → llama-swap isn't listening on :$SWAP_PORT."
echo "If §5 model list does NOT include 'qwen2.5:latest' (or whatever §1 shows as 'model:'),"
echo "    update conf.yaml's model: to a model id that IS listed, then ./reapply-config.sh"
