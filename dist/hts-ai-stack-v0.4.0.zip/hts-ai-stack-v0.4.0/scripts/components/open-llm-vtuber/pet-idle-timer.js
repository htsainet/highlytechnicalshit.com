#!/usr/bin/env node
// pet-idle-timer.js — Idle timer for Open-LLM-VTuber pet mode.
//
// Sends "ai-speak-signal" WebSocket messages at a configurable interval
// so the AI speaks proactively without user input. This is the backend
// companion to the Electron desktop pet — it keeps the pet engaging
// during idle time.
//
// Usage:
//   node pet-idle-timer.js [--interval SECONDS] [--host HOST] [--port PORT]
//
// Environment variables (alternatives to CLI flags):
//   VTUBER_PET_IDLE_INTERVAL  Seconds between proactive speak signals (default 120)
//   OPEN_LLM_VTUBER_PORT      Backend port (default 12393)

const INTERVAL = parseInt(process.env.VTUBER_PET_IDLE_INTERVAL || "120", 10);
const PORT = parseInt(process.env.OPEN_LLM_VTUBER_PORT || "12393", 10);

function parseArgs() {
  const args = process.argv.slice(2);
  const opts = { interval: INTERVAL, host: "127.0.0.1", port: PORT };
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--interval" && args[i + 1]) opts.interval = parseInt(args[++i], 10);
    else if (args[i] === "--host" && args[i + 1]) opts.host = args[++i];
    else if (args[i] === "--port" && args[i + 1]) opts.port = parseInt(args[++i], 10);
  }
  return opts;
}

function connect(opts) {
  const url = `ws://${opts.host}:${opts.port}/client-ws`;
  console.log(`[pet-idle-timer] Connecting to ${url}`);
  console.log(`[pet-idle-timer] Sending ai-speak-signal every ${opts.interval}s (Ctrl+C to stop)`);

  let ws;
  let timer;

  function scheduleNext() {
    timer = setTimeout(() => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: "ai-speak-signal" }));
        console.log("[pet-idle-timer] Sent ai-speak-signal");
      }
      scheduleNext();
    }, opts.interval * 1000);
  }

  function open() {
    ws = new WebSocket(url);

    ws.addEventListener("open", () => {
      console.log("[pet-idle-timer] Connected");
      scheduleNext();
    });

    ws.addEventListener("close", () => {
      console.log("[pet-idle-timer] Disconnected. Reconnecting in 5s...");
      clearTimeout(timer);
      setTimeout(open, 5000);
    });

    ws.addEventListener("error", (err) => {
      console.error("[pet-idle-timer] Connection error. Retrying in 10s...");
      clearTimeout(timer);
      try { ws.close(); } catch {}
      setTimeout(open, 10000);
    });
  }

  open();

  process.on("SIGINT", () => {
    console.log("[pet-idle-timer] Stopped");
    clearTimeout(timer);
    if (ws) ws.close();
    process.exit(0);
  });
  process.on("SIGTERM", () => {
    clearTimeout(timer);
    if (ws) ws.close();
    process.exit(0);
  });
}

connect(parseArgs());
