#!/usr/bin/env bash
# scripts/components/faster-whisper/faster-whisper.sh — Faster-Whisper: install, configure, start, health
#
# Faster-Whisper via speaches — GPU-accelerated speech-to-text with
# OpenAI-compatible /v1/audio/transcriptions API.
#
# Standalone usage:
#   ./scripts/components/faster-whisper/faster-whisper.sh              # full: install + configure + start + health
#   ./scripts/components/faster-whisper/faster-whisper.sh --install    # install only (build image)
#   ./scripts/components/faster-whisper/faster-whisper.sh --configure  # configure only
#   ./scripts/components/faster-whisper/faster-whisper.sh --start      # start only
#   ./scripts/components/faster-whisper/faster-whisper.sh --stop       # stop
#   ./scripts/components/faster-whisper/faster-whisper.sh --restart    # restart (stop + start)
#   ./scripts/components/faster-whisper/faster-whisper.sh --health     # health check only
#   ./scripts/components/faster-whisper/faster-whisper.sh --status     # show status + port + health
#   ./scripts/components/faster-whisper/faster-whisper.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
FASTER_WHISPER_PORT="${FASTER_WHISPER_PORT:-8600}"
WHISPER_MODEL="${WHISPER_MODEL:-large-v3}"

# ── Functions ────────────────────────────────────────────────────────────────

faster_whisper_install() {
  step "Faster-Whisper — install"
  local dockerfile="$REPO_DIR/docker/faster-whisper/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    warn "Faster-Whisper Dockerfile not found: $dockerfile"
    info "Create a Dockerfile based on speaches (OpenAI-compat Whisper wrapper)."
    return 1
  fi
  compose_build --profile faster-whisper
  ok "Faster-Whisper image built."
}

faster_whisper_configure() {
  step "Faster-Whisper — configure"
  info "OpenAI-compat API port: ${FASTER_WHISPER_PORT}"
  info "Whisper model: ${WHISPER_MODEL}"
  info "Endpoint: POST /v1/audio/transcriptions"

  local cache_dir="$REPO_DIR/data/faster-whisper/models"
  mkdir -p "$cache_dir"

  ok "Faster-Whisper configured."
}

faster_whisper_start() {
  step "Faster-Whisper — start"
  compose_up --profile faster-whisper
  ok "Faster-Whisper started on port ${FASTER_WHISPER_PORT}."
}

faster_whisper_stop() {
  step "Faster-Whisper — stop"
  compose_down --profile faster-whisper
  ok "Faster-Whisper stopped."
}

faster_whisper_health() {
  local label="Faster-Whisper :${FASTER_WHISPER_PORT}"
  printf "  %-35s" "$label"
  if curl -sf "http://localhost:${FASTER_WHISPER_PORT}/health" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${FASTER_WHISPER_PORT}/health)"
    return 1
  fi
}

faster_whisper_restart() {
  faster_whisper_stop
  faster_whisper_start
}

faster_whisper_destroy() {
  step "Faster-Whisper — destroy"
  compose_down --profile faster-whisper -v
  ok "Faster-Whisper destroyed."
}

faster_whisper_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=faster-whisper" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Faster-Whisper is running (port ${FASTER_WHISPER_PORT})"
  else
    warn "Faster-Whisper is not running."
  fi
  faster_whisper_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   faster_whisper_install   ;;
    configure) faster_whisper_configure ;;
    start)     faster_whisper_start     ;;
    stop)      faster_whisper_stop      ;;
    restart)   faster_whisper_restart   ;;
    health)    faster_whisper_health    ;;
    status)    faster_whisper_status    ;;
    destroy)   faster_whisper_destroy   ;;
    default)
      faster_whisper_install
      faster_whisper_configure
      faster_whisper_start
      faster_whisper_health
      ;;
  esac
fi
