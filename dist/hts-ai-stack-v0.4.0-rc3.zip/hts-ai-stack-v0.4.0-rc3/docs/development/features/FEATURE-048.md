# FEATURE-048 — ML Systems Reference Book (Harvard CS249r)

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | LOW |
| **Effort** | < 30 minutes |
| **Risk** | Low — read-only clone into data/references/, no runtime impact |
| **Target Release** | v0.5.0 |
| **Depends on** | Nothing |
| **Blocks** | Nothing |

## Problem

Developers working on AI inference, model optimization, quantization, and edge deployment need reference material. The Harvard CS249r "Machine Learning Systems" textbook covers these topics in depth but is only available online at mlsysbook.ai.

## Solution

Clone the [cs249r_book](https://github.com/harvard-edge/cs249r_book) repository into `data/references/cs249r_book` during dev-tools setup. The markdown source is immediately readable and searchable by local AI tools.

### Implementation (complete)

Added a "Reference books" step in `scripts/host/tools.sh` (dev-tools section) that:

1. Creates `data/references/` directory
2. Shallow-clones `harvard-edge/cs249r_book` (depth 1 to save space)
3. On subsequent runs, pulls latest changes
4. Gracefully skips if network is unavailable

The `data/` directory is gitignored, so cloned content never enters the repo.

### What's included in the book

| Volume | Topics |
|--------|--------|
| Fundamentals | ML basics, DL architecttic, training, optimization, hardware |
| Systems | Inference engines, quantization (INT8/INT4), model compression, edge deployment |
| Practice | Benchmarking, profiling, MLOps, responsible AI, real-world case studies |

### Integration points

- **Ollama/llama-swap** — reference chapters on quantization and inference optimization
- **Unsloth** — reference chapters on fine-tuning and training
- **BitNet** — reference chapters on 1-bit models and extreme quantization
- **AI agents** — searchable by Copilot, Continue, or any local coding assistant
- **Future** — could be served as a static site via the dashboard if Quarto is installed

## Acceptance criteria

- [x] Clone step added to `scripts/host/tools.sh` under dev tools
- [x] Idempotent — pulls on re-run, skips on network failure
- [x] `data/references/` gitignored
- [ ] Verified clone completes on target machine

## Upstream

| Resource | Link |
|----------|------|
| GitHub | <https://github.com/harvard-edge/cs249r_book> |
| Rendered site | <https://mlsysbook.ai> |
| MIT Press | Forthcoming Summer 2026 (Vol I + II) |

## Notes

- Shallow clone (~100 MB vs full history) keeps disk usage reasonable
- Book source is Quarto markdown — readable as-is without building
- Additional reference books can be added to the same `data/references/` directory in future
