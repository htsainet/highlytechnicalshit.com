#!/usr/bin/env bash
set -euo pipefail

# Hotfix for ISSUE-023:
# - Prevent find_or_create_sd_volume() from capturing [INFO]/[WARN] output
#   by moving logging functions (info/warn/ok/fail/step/skip) to stderr.
#
# Usage:
#   chmod +x ISSUE-023.sh
#   ./ISSUE-023.sh
#
# Rollback:
#   Restore the backup file it creates next to helpers.sh

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HELPERS="${REPO_ROOT}/scripts/install/models/helpers.sh"

if [[ ! -f "$HELPERS" ]]; then
  echo "[FAIL] Could not find $HELPERS. Run this from the repo root." >&2
  exit 1
fi

ts="$(date +%Y%m%d-%H%M%S)"
backup="${HELPERS}.bak.${ts}"
cp -a "$HELPERS" "$backup"
echo "[INFO] Backup created: $backup" >&2

# We only change the logging helper definitions near the top of the file:
# info() { echo -e "..."; }  -> info() { echo -e "..." >&2; }
# and similarly for warn/skip/step/fail/ok
#
# This is intentionally small and surgical.
tmp="$(mktemp)"

awk '
  BEGIN { changed=0 }

  # Patch each logger function definition to append " >&2" before the closing "; }"
  # We keep the existing content untouched as much as possible.
  /^info\(\)[[:space:]]*\{[[:space:]]*echo -e / {
    if ($0 !~ />&2/) { sub(/;[[:space:]]*\}$/, " >&2; }"); changed=1 }
  }
  /^warn\(\)[[:space:]]*\{[[:space:]]*echo -e / {
    if ($0 !~ />&2/) { sub(/;[[:space:]]*\}$/, " >&2; }"); changed=1 }
  }
  /^skip\(\)[[:space:]]*\{[[:space:]]*echo -e / {
    if ($0 !~ />&2/) { sub(/;[[:space:]]*\}$/, " >&2; }"); changed=1 }
  }
  /^step\(\)[[:space:]]*\{[[:space:]]*echo -e / {
    if ($0 !~ />&2/) { sub(/;[[:space:]]*\}$/, " >&2; }"); changed=1 }
  }
  /^fail\(\)[[:space:]]*\{[[:space:]]*echo -e / {
    if ($0 !~ />&2/) { sub(/;[[:space:]]*\}$/, " >&2; }"); changed=1 }
  }
  /^ok\(\)[[:space:]]*\{[[:space:]]*echo -e / {
    if ($0 !~ />&2/) { sub(/;[[:space:]]*\}$/, " >&2; }"); changed=1 }
  }

  { print }

  END {
    if (changed == 0) {
      # not an error: it may have been patched already or the format differs
      # We still write the file and then diff will show no changes.
      # Exit code 0.
    }
  }
' "$HELPERS" > "$tmp"

# Replace file
chmod --reference="$HELPERS" "$tmp" || true
mv "$tmp" "$HELPERS"

echo "[INFO] Patched: $HELPERS" >&2
echo "" >&2
echo "[INFO] Diff (old -> new):" >&2
# diff may exit 1 when differences exist; that is expected
diff -u "$backup" "$HELPERS" || true

echo "" >&2
echo "[OK] Hotfix applied. Re-run your failing step (e.g., install.sh / 03-setup-models.sh)." >&2
echo "[INFO] If you need to rollback: cp -a \"$backup\" \"$HELPERS\"" >&2