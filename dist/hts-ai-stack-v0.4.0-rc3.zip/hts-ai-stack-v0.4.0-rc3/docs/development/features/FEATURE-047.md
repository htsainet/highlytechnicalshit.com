# FEATURE-047 — Continue AI Coding Assistant Extension

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | LOW |
| **Effort** | < 30 minutes |
| **Risk** | Low — VS Code extension only, no infrastructure changes |
| **Target Release** | v0.5.0 |
| **Depends on** | Nothing |
| **Blocks** | Nothing |

## Problem

The stack runs local LLM inference (Ollama, llama-swap) but there is no local AI coding assistant that uses these models. GitHub Copilot requires cloud connectivity. Developers working offline or preferring local models need an alternative.

## Solution

Install [Continue](https://github.com/continuedev/continue) — an open-source AI coding assistant extension for VS Code and JetBrains that connects to local models.

### Implementation (complete)

Added `continue.continue` to the VS Code extensions list in `scripts/host/tools.sh`. It installs alongside other dev tool extensions when `admin.install_dev_tools` is enabled in `config/stack.json`.

### Configuration

Continue auto-discovers Ollama at `localhost:11434`. For llama-swap, users can configure `~/.continue/config.json`:

```json
{
  "models": [
    {
      "title": "Local (llama-swap)",
      "provider": "openai",
      "model": "autodetect",
      "apiBase": "http://localhost:8081/v1"
    }
  ]
}
```

### Features

- **Tab autocomplete** using local models
- **Chat sidebar** — ask questions about code with full codebase context
- **Inline editing** — select code and ask for modifications
- **Custom slash commands** and context providers
- **Multi-model support** — switch between Ollama models on the fly

## Acceptance criteria

- [x] `continue.continue` added to VS Code extensions in `tools.sh`
- [ ] Extension installs successfully on target machine
- [ ] Connects to local Ollama and produces completions

## Upstream

| Resource | Link |
|----------|------|
| GitHub | <https://github.com/continuedev/continue> |
| VS Code Marketplace | <https://marketplace.visualstudio.com/items?itemName=Continue.continue> |
| Documentation | <https://docs.continue.dev/> |
| Config reference | <https://docs.continue.dev/reference/config> |

## Notes

- Complements GitHub Copilot rather than replacing it — Copilot for cloud models, Continue for local
- No container or service required — purely a VS Code extension
- Works with any OpenAI-compatible endpoint (Ollama, llama-swap, LocalAI)
