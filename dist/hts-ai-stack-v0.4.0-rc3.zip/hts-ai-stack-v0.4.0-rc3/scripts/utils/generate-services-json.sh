#!/usr/bin/env bash
# scripts/utils/generate-services-json.sh — Generate dashboard services registry
#
# Reads all scripts/components/*.manifest.json files, filters those with
# dashboard blocks (show != false), groups by section, sorts by order,
# and writes resources/dashboard/services.json.
#
# Usage:
#   bash scripts/utils/generate-services-json.sh
#
# Output:
#   resources/dashboard/services.json
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
MANIFEST_DIR="$REPO_DIR/scripts/components"
OUTPUT="$REPO_DIR/resources/dashboard/services.json"

if ! command -v jq &>/dev/null; then
  echo "[FAIL] generate-services-json requires jq" >&2
  exit 1
fi

jq -n '
  [inputs | select(.dashboard and (.dashboard.show // true))] |
  group_by(.dashboard.section) |
  sort_by(map(.order) | min) |
  map({
    section: .[0].dashboard.section,
    wrap: (map(select(.dashboard.cluster)) | first | .dashboard.cluster // null),
    items: (sort_by(.order) | map({
      title: (.dashboard.title // .display_name),
      service: .id,
      port: .dashboard.port,
      path: (if (.dashboard.path // "") != "" then .dashboard.path else null end),
      probePath: (if (.dashboard.probePath // "") != "" then .dashboard.probePath else null end),
      uiPath: (if (.dashboard.uiPath // "") != "" then .dashboard.uiPath else null end),
      apiPath: (if (.dashboard.apiPath // "") != "" then .dashboard.apiPath else null end),
      proto: (if (.dashboard.proto // "http") != "http" then .dashboard.proto else null end),
      desc: .dashboard.desc,
      installId: .id,
      gpu: (if (.dashboard.gpu // false) then true else null end)
    } | with_entries(select(.value != null))))
  }) |
  map(if .wrap == null then del(.wrap) else . end)
' "$MANIFEST_DIR"/*/*.manifest.json > "${OUTPUT}.tmp" && mv "${OUTPUT}.tmp" "$OUTPUT"

echo "Generated: $OUTPUT"
jq 'length' "$OUTPUT" | xargs -I{} echo "  {} sections"
