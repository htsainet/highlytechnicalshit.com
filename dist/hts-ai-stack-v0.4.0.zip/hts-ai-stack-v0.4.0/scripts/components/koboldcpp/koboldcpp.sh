#!/usr/bin/env bash
# scripts/components/koboldcpp/koboldcpp.sh — KoboldCpp interactive fiction engine
#
# Source-built container for KoboldCpp (LostRuins/koboldcpp v1.112.2), a
# multi-backend GGUF model runner with a built-in interactive fiction /
# text generation web UI. Supports CPU and CUDA GPU offload. OpenAI-compatible
# API at /v1/. Image built from source in a multi-stage CUDA Docker build;
# entrypoint.sh maps KOBOLDCPP_* env vars to koboldcpp.py CLI args and
# downloads the configured GGUF model on first run.
#
# Standalone usage:
#   ./scripts/components/koboldcpp/koboldcpp.sh              # full: install + configure + start + health
#   ./scripts/components/koboldcpp/koboldcpp.sh --install    # install only
#   ./scripts/components/koboldcpp/koboldcpp.sh --configure  # configure only
#   ./scripts/components/koboldcpp/koboldcpp.sh --start      # start only
#   ./scripts/components/koboldcpp/koboldcpp.sh --stop       # stop
#   ./scripts/components/koboldcpp/koboldcpp.sh --restart    # restart (stop + start)
#   ./scripts/components/koboldcpp/koboldcpp.sh --health     # health check only
#   ./scripts/components/koboldcpp/koboldcpp.sh --status     # show status + port + health
#   ./scripts/components/koboldcpp/koboldcpp.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
KOBOLDCPP_CONTAINER="${KOBOLDCPP_CONTAINER:-hts-ai-koboldcpp}"
KOBOLDCPP_PORT="${KOBOLDCPP_PORT:-5001}"
KOBOLDCPP_MODEL_REPO_DEFAULT="bartowski/Phi-3.5-mini-instruct-GGUF"
KOBOLDCPP_MODEL_FILE_DEFAULT="Phi-3.5-mini-instruct-Q4_K_M.gguf"

# ── Functions ────────────────────────────────────────────────────────────────

# koboldcpp_install — Build the KoboldCpp container image
koboldcpp_install() {
  step "KoboldCpp — install"
  compose_build --profile koboldcpp
  ok "KoboldCpp image built."
}

# koboldcpp_configure — Ensure .env has KoboldCpp port + default model
koboldcpp_configure() {
  step "KoboldCpp — configure"
  local env_file="$REPO_DIR/.env"

  # Seed each key only if absent — never clobber a user override.
  _ensure_env_key() {
    local key="$1" val="$2"
    if ! grep -q "^${key}=" "$env_file" 2>/dev/null; then
      printf '%s=%s\n' "$key" "$val" >> "$env_file"
      info "Added ${key}=${val} to .env"
    fi
  }

  _ensure_env_key KOBOLDCPP_PORT       "$KOBOLDCPP_PORT"
  _ensure_env_key KOBOLDCPP_MODEL_REPO "$KOBOLDCPP_MODEL_REPO_DEFAULT"
  _ensure_env_key KOBOLDCPP_MODEL_FILE "$KOBOLDCPP_MODEL_FILE_DEFAULT"
  _ensure_env_key KOBOLDCPP_CTX_SIZE   "4096"
  _ensure_env_key KOBOLDCPP_GPU_LAYERS "0"
  _ensure_env_key KOBOLDCPP_MULTIUSER  "8"

  info "Default model: ${KOBOLDCPP_MODEL_REPO_DEFAULT} → ${KOBOLDCPP_MODEL_FILE_DEFAULT}"
  info "Mode: CPU-only by default (KOBOLDCPP_GPU_LAYERS=0). Bump to 99 in .env"
  info "      to use GPU — but stop ollama first; both don't fit in 12 GB VRAM."
  ok "KoboldCpp configured (port ${KOBOLDCPP_PORT})."
}

# koboldcpp_start — Bring up KoboldCpp via compose
koboldcpp_start() {
  step "KoboldCpp — start"
  compose_up --profile koboldcpp
  ok "KoboldCpp started on port ${KOBOLDCPP_PORT}."
}

# koboldcpp_stop — Bring down KoboldCpp
koboldcpp_stop() {
  step "KoboldCpp — stop"
  compose_down --profile koboldcpp
  ok "KoboldCpp stopped."
}

# koboldcpp_health — Probe the OpenAI-compatible /v1/models endpoint.
# This proves the model finished loading, not just that the port is open
# (the GUI / launcher answers `/` long before any model is ready).
koboldcpp_health() {
  health_probe "KoboldCpp :${KOBOLDCPP_PORT}" "http://localhost:${KOBOLDCPP_PORT}/v1/models"
}

koboldcpp_restart() {
  koboldcpp_stop
  koboldcpp_start
}

koboldcpp_destroy() {
  step "KoboldCpp — destroy"
  compose_down --profile koboldcpp -v
  ok "KoboldCpp destroyed."
}

koboldcpp_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=koboldcpp" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "KoboldCpp is running (port ${KOBOLDCPP_PORT})"
  else
    warn "KoboldCpp is not running."
  fi
  koboldcpp_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   koboldcpp_install   ;;
    configure) koboldcpp_configure ;;
    start)     koboldcpp_start     ;;
    stop)      koboldcpp_stop      ;;
    restart)   koboldcpp_restart   ;;
    health)    koboldcpp_health    ;;
    status)    koboldcpp_status    ;;
    destroy)   koboldcpp_destroy   ;;
    default)
      koboldcpp_install
      koboldcpp_configure
      koboldcpp_start
      koboldcpp_health
      ;;
  esac
fi
