# FEATURE-052 — GPU VRAM Validator & Model VRAM Display

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | MEDIUM |
| **Effort** | 3–4 hours |
| **Risk** | Low — additive UI enhancement, no breaking changes to existing scripts |
| **Target Release** | v0.6.0 |
| **Depends on** | FEATURE-007 (manifest-driven wizard) |
| **Blocks** | Nothing |

## Problem

Users selecting models in the setup wizard have no visibility into GPU VRAM
requirements. On a 12 GB card (RTX 3060), selecting an SDXL model alongside a
9 GB Ollama model will silently cause OOM failures at runtime. Users only
discover the problem after waiting through long downloads and watching
containers crash-loop.

The wizard already detects whether a GPU exists (`GPU_AVAILABLE`) and warns
when GPU-required services are selected without one. But it has no concept of
**how much** VRAM is available or how much each model needs.

## Solution

Add structured `vram_mb` metadata to every model in the registry, detect the
GPU's total VRAM at wizard startup, display VRAM requirements inline during
model selection, and present a 3-tier validation summary after selection.

### The Three Tiers

| Tier | Icon | Condition | Message |
|------|------|-----------|---------|
| **Concurrent** | ✅ | `sum(all selected vram) ≤ gpu_total` | "All selected models can run simultaneously" |
| **Swappable** | ⚠️ | `max(any single vram) ≤ gpu_total` but sum exceeds | "All models can run, but not at the same time — hot-swap required" |
| **Too Large** | ❌ | `max(any single vram) > gpu_total` | "Some models exceed your GPU — they will fail to load" |

---

## Implementation Plan

### Phase 1: Registry Schema Update

**File:** `scripts/install/models/registry.json`

Add `vram_mb` (integer, VRAM needed at inference time in MiB) and `arch` to
every model entry. Also bump `_format_version` from `1` to `2`.

#### Ollama models — add `vram_mb`

The existing `notes` field already contains VRAM hints (e.g. "~500MB VRAM").
Extract these into a structured field. For models without VRAM notes, estimate
from parameter count using the rule of thumb: `params × quant_bytes ≈ model
size`, plus ~500 MB overhead for KV cache.

```jsonc
// Example: existing entry
{
  "model": "smollm2:135m",
  "vram_mb": 500,       // ← NEW
  "notes": "~500MB VRAM — minimal sidecar, --chat lean"
}
```

Reference VRAM values for Ollama models (inference, Q4_K_M unless noted):

| Model | Params | vram_mb |
|-------|--------|---------|
| smollm2:135m | 135M | 500 |
| gemma4:e4b | ~4B | 3500 |
| mistral-nemo:latest | 12B | 7500 |
| deepseek-r1:14b | 14B | 9000 |
| phi4:14b | 14B | 9000 |
| phi3.5:latest | 3.8B | 3000 |
| qwen3.5:0.8b | 0.8B | 800 |
| qwen3.5:9b | 9B | 6000 |
| qwen2.5:7b-instruct-q4_K_M | 7B | 5000 |
| gurubot/ollamatron:8b-q4_K_M | 8B | 5500 |
| granite3.1-dense:8b | 8B | 5500 |
| dolphin3:latest | 8B | 5500 |
| hf.co/.../MiMo-VL-Miloco-7B:Q4_0 | 7B | 5000 |
| hf.co/.../Nemotron-3-Nano-4B:Q4_K_M | 4B | 3000 |
| hf.co/.../Nemotron-Cascade-8B:Q4_K_M | 8B | 5500 |
| hf.co/.../Qwen3.5-9B-...:Q4_K_M | 9B | 6000 |
| hf.co/.../granite-4.0-1b-base:F16 | 1B | 2500 |

#### SD checkpoints — add `vram_mb` and `arch`

| Filename | arch | vram_mb | Notes |
|----------|------|---------|-------|
| dreamshaper_v8.safetensors | sd15 | 4000 | SD 1.5 inference with xformers |
| majicmixRealistic_v7.safetensors | sd15 | 4000 | |
| realistic_vision_v5.1.safetensors | sd15 | 4000 | |
| anything_v5.safetensors | sd15 | 4000 | |
| juggernautXL_v9.safetensors | sdxl | 8000 | SDXL with xformers |
| realvisxl_v5.safetensors | sdxl | 8000 | |
| dreamshaperXL_v21.safetensors | sdxl | 8000 | |
| sd_xl_base_1.0.safetensors | sdxl | 8000 | |
| flux1-dev.safetensors | flux | 18000 | BF16; FP8 quantized ~12000 |

#### BitNet models — add `vram_mb: 0`

BitNet runs on CPU only. Set `vram_mb: 0` for all entries.

#### Validation

After editing `registry.json`:
```bash
python3 -c "import json; json.load(open('scripts/install/models/registry.json'))"
```
Confirm every entry has a `vram_mb` key (integer, > 0 for GPU models, 0 for
CPU-only).

---

### Phase 2: GPU Detection Utility

**New file:** `scripts/lib/gpu-detect.sh`

A small sourced library that other scripts (wizard, start-stack, dashboard
generator) can use.

```bash
#!/usr/bin/env bash
# gpu-detect.sh — Detect GPU name and total VRAM (MiB)
#
# After sourcing, two variables are set:
#   GPU_NAME     — e.g. "NVIDIA GeForce RTX 3060"  (empty if no GPU)
#   GPU_VRAM_MB  — e.g. "12288"                      (0 if no GPU)

GPU_NAME=""
GPU_VRAM_MB=0

if command -v nvidia-smi &>/dev/null; then
  GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1 || true)
  _raw=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>/dev/null | head -1 || true)
  GPU_VRAM_MB="${_raw:-0}"
fi
```

**Design decisions:**
- Only supports NVIDIA (the only GPU vendor in this stack)
- Multi-GPU: reads first GPU only (multi-GPU support is a future feature)
- Returns 0 if no GPU or nvidia-smi fails — callers check `GPU_VRAM_MB -gt 0`
- No dependencies beyond `nvidia-smi`

---

### Phase 3: VRAM Budget Calculator

**New file:** `scripts/lib/vram-budget.sh`

Sourced library that reads the registry and computes VRAM budgets.

```bash
#!/usr/bin/env bash
# vram-budget.sh — VRAM budget calculator
#
# Functions:
#   vram_for_model <section> <model_id>
#     Returns vram_mb for a model from registry.json
#     section: "ollama" | "sd-checkpoints" | "bitnet"
#     model_id: model name (ollama) or filename (sd-checkpoints)
#
#   vram_budget_check <gpu_vram_mb> <model1_vram> [model2_vram ...]
#     Returns tier: "concurrent" | "swappable" | "too_large"
#
#   vram_format <vram_mb>
#     Returns human-readable string: "4.0 GB" / "500 MB"
```

**Implementation notes:**
- Uses `python3 -c` to query registry.json (jq may not be available)
- `vram_budget_check` iterates the list, computing `sum` and `max`
- The function takes raw vram_mb integers, not model names — the caller
  resolves model→vram before calling
- Returns a structured result: `tier|sum_mb|max_mb|gpu_mb`

Example usage:
```bash
source scripts/lib/gpu-detect.sh
source scripts/lib/vram-budget.sh

result=$(vram_budget_check "$GPU_VRAM_MB" 9000 8000 500)
# result="swappable|17500|9000|12288"
tier="${result%%|*}"
```

---

### Phase 4: Wizard Integration — Inline VRAM Display

**File:** `config/wizard/ai_stack_setup.sh`

#### 4a. Source the new libraries at wizard startup

After the existing `manifest_load_all` call (~line 32):

```bash
source "$REPO_ROOT/scripts/lib/gpu-detect.sh"
source "$REPO_ROOT/scripts/lib/vram-budget.sh"
```

#### 4b. Show VRAM in Ollama model selection (Step 3, ~line 422)

Replace the hardcoded model list with a dynamically-generated one that appends
VRAM info. The whiptail menu items become:

```
gemma4:e4b          "Gemma 4 E4B — recommended (3.5 GB)"
mistral-nemo        "Mistral Nemo (7.5 GB)"
deepseek-r1:14b     "DeepSeek R1 14B (9.0 GB) ⚠️ tight"
```

The "⚠️ tight" annotation appears when `vram_mb > GPU_VRAM_MB * 0.7` (uses
>70% of total VRAM, leaving little room for SD). The "❌ too large" annotation
appears when `vram_mb > GPU_VRAM_MB`.

**Build the menu dynamically** by reading `registry.json` Ollama models that
match the selected env (prod). Use python3 to generate the whiptail args:

```bash
_OLLAMA_MENU_ARGS=$(python3 -c "
import json, sys
gpu = int(sys.argv[1])
with open('$REPO_ROOT/scripts/install/models/registry.json') as f:
    reg = json.load(f)
for m in reg['ollama']:
    if 'prod' not in m.get('env', []): continue
    vram = m.get('vram_mb', 0)
    label = m.get('notes', '').split('—')[-1].strip() if '—' in m.get('notes','') else ''
    vfmt = f'{vram/1024:.1f} GB' if vram >= 1024 else f'{vram} MB'
    tag = ''
    if gpu > 0:
        if vram > gpu: tag = ' ❌'
        elif vram > gpu * 0.7: tag = ' ⚠️'
    print(f'{m[\"model\"]}')
    print(f'{label} ({vfmt}){tag}')
" "$GPU_VRAM_MB")
```

#### 4c. Show VRAM in Image Generation / SD checkpoint selection

The current wizard picks an image engine (SD, ComfyUI, etc.) but does NOT
let users pick which SD checkpoints to download. This is done silently in
`prod.sh`.

**Add a new sub-step** after engine selection (~line 763) that shows a
whiptail checklist of available SD checkpoints with VRAM annotations:

```
[*] dreamshaper_v8        "Fantasy/stylized (4.0 GB) — SD 1.5"
[*] juggernautXL_v9       "Photorealistic (8.0 GB) — SDXL ⚠️"
[ ] flux1-dev              "High-quality (18.0 GB) — Flux ❌"
```

Pre-select checkpoints based on env=prod and GPU fit. Flux would be
unchecked by default on 12 GB cards and annotated with ❌.

Store selections in `SD_CHECKPOINTS` variable (space-separated filenames).
Export to `stack.json` under `images.checkpoints[]`.

#### 4d. Post-selection VRAM Budget Summary

After all model selections are complete (after Step 7, before the
confirmation screen), insert a VRAM budget summary dialog:

```bash
# Determine which models are "active at the same time"
# The active set = default Ollama model + largest selected SD checkpoint
# (SD and Ollama share the GPU; only one SD model loads at a time)
_ollama_vram=$(vram_for_model ollama "$MODEL")
_sd_max_vram=$(python3 -c "
import json
with open('$REPO_ROOT/scripts/install/models/registry.json') as f:
    reg = json.load(f)
selected = '${SD_CHECKPOINTS}'.split()
vrams = [m.get('vram_mb',0) for m in reg['sd-checkpoints'] if m['filename'] in selected]
print(max(vrams) if vrams else 0)
")

_result=$(vram_budget_check "$GPU_VRAM_MB" "$_ollama_vram" "$_sd_max_vram")
_tier="${_result%%|*}"

case "$_tier" in
  concurrent)
    _msg="✅ All selected models can run simultaneously.\n\n"
    _msg+="GPU: ${GPU_NAME} (${GPU_VRAM_MB} MB)\n"
    _msg+="Ollama: $(vram_format $_ollama_vram)\n"
    _msg+="SD peak: $(vram_format $_sd_max_vram)\n"
    _msg+="Total: $(vram_format $((_ollama_vram + _sd_max_vram)))"
    ;;
  swappable)
    _msg="⚠️  Models can run, but not all at the same time.\n\n"
    _msg+="GPU: ${GPU_NAME} (${GPU_VRAM_MB} MB)\n"
    _msg+="Ollama: $(vram_format $_ollama_vram)\n"
    _msg+="SD peak: $(vram_format $_sd_max_vram)\n\n"
    _msg+="llama-swap will unload Ollama models before SD generates.\n"
    _msg+="Use --mode sd or --mode agent to dedicate full GPU."
    ;;
  too_large)
    _msg="❌ Some models exceed your GPU VRAM.\n\n"
    _msg+="GPU: ${GPU_NAME} (${GPU_VRAM_MB} MB)\n"
    _msg+="Ollama: $(vram_format $_ollama_vram)\n"
    _msg+="SD peak: $(vram_format $_sd_max_vram)\n\n"
    _msg+="Models marked ❌ will fail to load. Remove them or upgrade GPU."
    ;;
esac

whiptail --title "GPU VRAM Budget" --msgbox "$_msg" 16 $W || true
```

---

### Phase 5: apply_config.sh Integration

**File:** `config/wizard/apply_config.sh`

Add handling for the new `images.checkpoints[]` array in `stack.json`:

```bash
# Write SD_CHECKPOINTS to .env
sd_checks = cfg.get("images", {}).get("checkpoints", [])
if sd_checks:
    kvs.append(("SD_CHECKPOINTS", " ".join(sd_checks)))
```

Update `prod.sh` to read `SD_CHECKPOINTS` from `.env` instead of its
hardcoded `SD_MODELS_PROD` array:

```bash
if [[ -n "${SD_CHECKPOINTS:-}" ]]; then
  # Read from wizard selection
  for ckpt in $SD_CHECKPOINTS; do
    url=$(python3 -c "
import json
with open('$REGISTRY') as f: reg = json.load(f)
for m in reg['sd-checkpoints']:
    if m['filename'] == '$ckpt':
        print(m['url']); break
")
    SD_MODELS_PROD+=("${ckpt}|${url}")
  done
fi
```

---

### Phase 6: Confirmation Screen Update

**File:** `config/wizard/ai_stack_setup.sh` (confirmation section, ~line 980)

Add GPU info to the confirmation summary:

```bash
if [[ "$GPU_VRAM_MB" -gt 0 ]]; then
  printf "  %-18s %s (%s MB VRAM)\n" "GPU:" "$GPU_NAME" "$GPU_VRAM_MB"
  printf "  %-18s %s\n" "VRAM budget:" "$_tier"
fi
```

---

### Phase 7: Dashboard Integration (Optional Enhancement)

**File:** `resources/dashboard/services.json` or dashboard generator

If time permits, add a GPU VRAM indicator to the dashboard that shows:
- Current GPU utilization (read from `nvidia-smi` in the health check)
- Which models are loaded
- Estimated VRAM per loaded model

This is a nice-to-have and can be a follow-up.

---

## Files Changed

| File | Change |
|------|--------|
| `scripts/install/models/registry.json` | Add `vram_mb` to all models, `arch` to SD 1.5 models, bump format version |
| `scripts/lib/gpu-detect.sh` | **NEW** — GPU name/VRAM detection |
| `scripts/lib/vram-budget.sh` | **NEW** — VRAM budget calculator (tier logic) |
| `config/wizard/ai_stack_setup.sh` | Source libs, dynamic model menus with VRAM labels, checkpoint picker, budget summary |
| `config/wizard/apply_config.sh` | Handle `images.checkpoints[]` → `.env` |
| `scripts/install/models/prod.sh` | Read `SD_CHECKPOINTS` from `.env` instead of hardcoded array |

## Testing

1. **Unit test the budget calculator:**
   ```bash
   source scripts/lib/gpu-detect.sh
   source scripts/lib/vram-budget.sh

   # Simulate 12 GB GPU
   GPU_VRAM_MB=12288

   # Tier 1: concurrent (3500 + 4000 = 7500 < 12288)
   assert "$(vram_budget_check 12288 3500 4000)" == "concurrent|7500|4000|12288"

   # Tier 2: swappable (9000 + 8000 = 17000 > 12288, but max 9000 < 12288)
   assert "$(vram_budget_check 12288 9000 8000)" == "swappable|17000|9000|12288"

   # Tier 3: too_large (18000 > 12288)
   assert "$(vram_budget_check 12288 9000 18000)" == "too_large|27000|18000|12288"
   ```

2. **Registry validation:** Confirm every model entry has `vram_mb` (integer):
   ```bash
   python3 -c "
   import json, sys
   with open('scripts/install/models/registry.json') as f:
       reg = json.load(f)
   ok = True
   for section in ['ollama', 'bitnet', 'sd-checkpoints']:
       for m in reg[section]:
           key = m.get('model', m.get('filename', '?'))
           if 'vram_mb' not in m:
               print(f'MISSING vram_mb: {section}/{key}')
               ok = False
           elif not isinstance(m['vram_mb'], int):
               print(f'NOT INT vram_mb: {section}/{key} = {m[\"vram_mb\"]}')
               ok = False
   sys.exit(0 if ok else 1)
   "
   ```

3. **Wizard smoke test:** Run wizard on machine with GPU, verify:
   - Model labels show "(X.X GB)" suffix
   - Models exceeding GPU show ⚠️ or ❌
   - Budget summary dialog appears with correct tier
   - SD checkpoint picker shows all registry entries

4. **No-GPU fallback:** Run wizard on machine without nvidia-smi:
   - `GPU_VRAM_MB=0` → no VRAM annotations, no budget dialog
   - Wizard functions identically to current behavior

## Edge Cases

- **Multi-GPU:** Currently only reads first GPU. Document as known limitation.
  Future: sum VRAM across GPUs if `CUDA_VISIBLE_DEVICES` is set.
- **Shared VRAM (integrated GPU):** `nvidia-smi` reports total dedicated VRAM,
  which is correct for discrete GPUs. Integrated GPUs are unsupported.
- **Ollama with `--num-gpu 0`:** Some models can be forced to CPU. The
  validator assumes GPU loading (conservative).
- **llama-swap model unloading:** When `--mode agent` is active, SD is not
  loaded. When `--mode sd` is active, only `smollm2:135m` is loaded for Ollama.
  The validator uses the worst case (default model + largest SD checkpoint).
- **VRAM fragmentation:** Real VRAM usage is ~10-15% higher than model size
  due to CUDA contexts, KV caches, and attention buffers. The `vram_mb` values
  should include this overhead.

## Rollback

All changes are additive. If `vram_mb` is missing from a registry entry, the
calculator returns 0 and the wizard falls back to current behavior (no VRAM
display). `gpu-detect.sh` and `vram-budget.sh` are only sourced if present.

## Interim: Per-Component Free VRAM Checks

Before this feature lands, `gpu.sh` provides `get_gpu_free_vram_gb()` and
`check_free_vram()` — point-in-time `nvidia-smi memory.free` snapshots that
individual components can use for start-time guards. Audio Flamingo is the
first adopter: its `auto` device mode checks free VRAM and falls back to CPU
if <5 GB is available.

When FEATURE-052 ships, these spot checks should be **replaced** by the
budget calculator, which tracks all services' `vram_mb` requirements and
produces a tier (concurrent / swappable / too_large) before anything starts.
The per-component fallback logic in `audio-flamingo.sh` should be removed
in favor of converge-level orchestration that decides device placement for
all GPU services at once.
