$ErrorActionPreference = 'Stop'

BeforeDiscovery {
    $repoRoot    = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $manifestDir = Join-Path $repoRoot 'scripts/components'
    $stackPath   = Join-Path $repoRoot 'config/stack.json'

    # Load stack.json to know which services are enabled
    $stack = if (Test-Path $stackPath) {
        Get-Content $stackPath -Raw | ConvertFrom-Json
    } else { $null }

    # Build health test cases for manifests that have a non-empty health.url
    # and whose service appears to be enabled in stack.json.
    # Services with install_type host-interactive are skipped (not Docker-managed).
    $script:HealthCases = Get-ChildItem -Path $manifestDir -Filter '*.manifest.json' -File |
        ForEach-Object {
            $m = Get-Content $_.FullName -Raw | ConvertFrom-Json
            $url = $m.health.url

            if (-not $url) { return }
            if ($m.install_type -eq 'host-interactive') { return }

            @{
                serviceId = $m.id
                url       = $url
                timeout   = [int]$m.health.timeout
            }
        } | Where-Object { $_ -ne $null }
}

# ── Connectivity ──────────────────────────────────────────────────────────────

Describe 'Service health endpoints' {
    It '<serviceId> responds at <url>' -TestCases $script:HealthCases {
        $response = $null
        $err      = $null

        try {
            $response = Invoke-WebRequest -Uri $url -UseBasicParsing `
                -TimeoutSec ([Math]::Min($timeout, 10)) `
                -ErrorAction Stop
        } catch {
            $err = $_.Exception.Message
        }

        # A redirect (3xx) or success (2xx) is healthy.
        # Some endpoints (e.g. Prometheus /-/ready) return 200; others redirect to UI.
        # We accept anything that didn't throw a connection-refused error.
        if ($err -and $err -match 'Unable to connect|Connection refused|No connection') {
            throw "Service '$serviceId' is not reachable at $url — $err"
        }

        # If we got here without a connection error, pass (even 4xx/5xx means the
        # process is up; we're testing liveness, not correctness).
        $true | Should -Be $true
    }
}
