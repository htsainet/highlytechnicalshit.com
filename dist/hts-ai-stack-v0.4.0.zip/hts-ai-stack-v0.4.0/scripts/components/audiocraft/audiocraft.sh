#!/usr/bin/env bash
# scripts/components/audiocraft/audiocraft.sh — AudioCraft / MusicGen: install, configure, start, health
#
# Meta AudioCraft with MusicGen — AI-powered text-to-music generation.
# Runs via Gradio on GPU with CUDA acceleration.
#
# Standalone usage:
#   ./scripts/components/audiocraft/audiocraft.sh              # full: install + configure + start + health
#   ./scripts/components/audiocraft/audiocraft.sh --install    # install only (build image)
#   ./scripts/components/audiocraft/audiocraft.sh --configure  # configure only
#   ./scripts/components/audiocraft/audiocraft.sh --start      # start only
#   ./scripts/components/audiocraft/audiocraft.sh --stop       # stop
#   ./scripts/components/audiocraft/audiocraft.sh --restart    # restart (stop + start)
#   ./scripts/components/audiocraft/audiocraft.sh --health     # health check only
#   ./scripts/components/audiocraft/audiocraft.sh --status     # show status + port + health
#   ./scripts/components/audiocraft/audiocraft.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
AUDIOCRAFT_PORT="${AUDIOCRAFT_PORT:-8602}"

# ── Functions ────────────────────────────────────────────────────────────────

audiocraft_install() {
  step "AudioCraft — install"
  local dockerfile="$REPO_DIR/docker/audiocraft/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    warn "AudioCraft Dockerfile not found: $dockerfile"
    return 1
  fi
  compose_build --profile audiocraft
  ok "AudioCraft image built."
}

audiocraft_configure() {
  step "AudioCraft — configure"
  info "Gradio UI port: ${AUDIOCRAFT_PORT}"
  info "Model: facebook/musicgen-small (300M) — upgradeable to medium/large"
  info "Models downloaded from HuggingFace on first start."
  ok "AudioCraft configured."
}

audiocraft_start() {
  step "AudioCraft — start"
  compose_up --profile audiocraft
  ok "AudioCraft started on port ${AUDIOCRAFT_PORT}."
}

audiocraft_stop() {
  step "AudioCraft — stop"
  compose_down --profile audiocraft
  ok "AudioCraft stopped."
}

audiocraft_health() {
  local label="AudioCraft :${AUDIOCRAFT_PORT}"
  printf "  %-35s" "$label"
  if curl -sf "http://localhost:${AUDIOCRAFT_PORT}/" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${AUDIOCRAFT_PORT}/)"
    return 1
  fi
}

audiocraft_restart() {
  audiocraft_stop
  audiocraft_start
}

audiocraft_destroy() {
  step "AudioCraft — destroy"
  compose_down --profile audiocraft -v
  ok "AudioCraft destroyed."
}

audiocraft_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=audiocraft" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "AudioCraft is running (port ${AUDIOCRAFT_PORT})"
  else
    warn "AudioCraft is not running."
  fi
  audiocraft_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   audiocraft_install   ;;
    configure) audiocraft_configure ;;
    start)     audiocraft_start     ;;
    stop)      audiocraft_stop      ;;
    restart)   audiocraft_restart   ;;
    health)    audiocraft_health    ;;
    status)    audiocraft_status    ;;
    destroy)   audiocraft_destroy   ;;
    default)
      audiocraft_install
      audiocraft_configure
      audiocraft_start
      audiocraft_health
      ;;
  esac
fi
