# Portainer References

Last updated: 2026-04-15

## Upstream

- [GitHub — portainer/portainer](https://github.com/portainer/portainer)

## Official documentation

- [Portainer Docs](https://docs.portainer.io/)
