#!/usr/bin/env bash
# scripts/htsclaw/health/health.sh — Sandbox liveness monitoring
#
# Health check functions and systemd timer installation for htsclaw sandboxes.
# Checks sandbox existence, gateway health, and port forward status.
# Restarts dead forwards automatically.
#
# Simpler than NemoClaw: no TCP relay needed (port 18790 maps directly).
#
# Standalone usage:
#   ./scripts/htsclaw/health/health.sh            # run health check
#   ./scripts/htsclaw/health/health.sh --install   # install systemd timer
#   ./scripts/htsclaw/health/health.sh --status    # show timer status
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
# Source lifecycle so _htsclaw_restart_gateway is available when gateway is down
source "$SCRIPT_DIR/../sandbox/lifecycle.sh" 2>/dev/null || true

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
HTSCLAW_SANDBOX_NAME="${HTSCLAW_SANDBOX_NAME:-hts-ai-openshell-htsclaw-gpu}"
HTSCLAW_PORT="${HTSCLAW_PORT:-18790}"
LLAMA_SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"

# ── Internal helpers ─────────────────────────────────────────────────────────

_ensure_sudo() {
  if sudo -n true 2>/dev/null; then return 0; fi
  info "Administrator privileges required."
  sudo -v || { fail "Sudo authentication failed."; }
}

# ── Health checks ────────────────────────────────────────────────────────────

# _check_sandbox_exists — Verify the sandbox is known to openshell
_check_sandbox_exists() {
  local sandbox="$1"
  openshell sandbox get "$sandbox" &>/dev/null 2>&1
}

# _check_gateway_health — HTTP probe on the forwarded port
_check_gateway_health() {
  local port="$1"
  curl -sf "http://localhost:${port}/healthz" >/dev/null 2>&1
}

# _check_forward_alive — Verify the port forward is in the running state
_check_forward_alive() {
  local port="$1"
  local fwd_status
  fwd_status=$(openshell forward list -g "${HTSCLAW_GATEWAY_NAME:-htsclaw}" 2>/dev/null | grep "$port" || true)
  echo "$fwd_status" | grep -q "running"
}

# _revive_forward — Stop and restart a dead port forward
_revive_forward() {
  local sandbox="$1" port="$2"
  openshell forward stop -g "${HTSCLAW_GATEWAY_NAME:-htsclaw}" "$port" 2>/dev/null || true
  openshell forward start -g "${HTSCLAW_GATEWAY_NAME:-htsclaw}" -d "$port" "$sandbox" 2>/dev/null || {
    warn "Failed to restart forward :${port} → '${sandbox}'."
    return 1
  }
  info "Revived forward :${port} → '${sandbox}'."
}

# htsclaw_health — Run all health checks and revive dead forwards.
htsclaw_health() {
  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not found — cannot run health checks."
    return 1
  fi

  step "htsclaw — health"

  local sandbox="$HTSCLAW_SANDBOX_NAME"
  local port="$HTSCLAW_PORT"
  local healthy=true

  # 1. Check llama-swap (inference backend)
  if curl -sf "http://localhost:${LLAMA_SWAP_PORT}/health" >/dev/null 2>&1; then
    ok "llama-swap (:${LLAMA_SWAP_PORT}) is reachable."
  else
    warn "llama-swap (:${LLAMA_SWAP_PORT}) not reachable."
    healthy=false
  fi

  # 2. Check sandbox exists
  if _check_sandbox_exists "$sandbox"; then
    ok "Sandbox '${sandbox}' exists."
  else
    warn "Sandbox '${sandbox}' not found — create it with htsclaw_create."
    return 1
  fi

  # 3. Check port forward
  if _check_forward_alive "$port"; then
    ok "Forward :${port} → '${sandbox}' is running."
  else
    warn "Forward :${port} → '${sandbox}' is dead — reviving..."
    _revive_forward "$sandbox" "$port"
    healthy=false
  fi

  # 4. Check gateway health (via forwarded port)
  if _check_gateway_health "$port"; then
    ok "OpenClaw gateway (:${port}/healthz) responding."
  else
    warn "OpenClaw gateway (:${port}/healthz) not responding — restarting..."
    if type _htsclaw_restart_gateway &>/dev/null; then
      _htsclaw_restart_gateway "$sandbox" "$port"
      if _check_gateway_health "$port"; then
        ok "OpenClaw gateway revived after restart."
      else
        warn "OpenClaw gateway still not responding after restart."
        healthy=false
      fi
    else
      warn "Gateway restart not available (lifecycle.sh not sourced)."
      healthy=false
    fi
  fi

  if [[ "$healthy" == "true" ]]; then
    ok "All htsclaw health checks passed."
  else
    warn "Some htsclaw health checks failed — review output above."
    return 1
  fi
}

# ── Systemd timer installation ───────────────────────────────────────────────

# htsclaw_install_health_timer — Install a systemd timer for periodic health checks.
htsclaw_install_health_timer() {
  _ensure_sudo

  local service_name="hts-htsclaw-health"
  local service_file="/etc/systemd/system/${service_name}.service"
  local timer_file="/etc/systemd/system/${service_name}.timer"
  local script_path="$REPO_DIR/scripts/htsclaw/health/health.sh"
  local run_user
  run_user=$(whoami)

  # Resolve openshell path so the service can find it
  local extra_path=""
  if command -v openshell &>/dev/null; then
    local os_dir
    os_dir="$(dirname "$(command -v openshell)")"
    extra_path="${os_dir}:"
  fi

  sudo tee "$service_file" > /dev/null <<EOF
[Unit]
Description=HTS AI Stack — htsclaw health check
After=network-online.target docker.service

[Service]
Type=oneshot
ExecStart=${script_path}
WorkingDirectory=${REPO_DIR}
User=${run_user}
Environment=PATH=${extra_path}/usr/local/bin:/usr/bin:/bin
Environment=HOME=$(eval echo ~"$run_user")
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${service_name}
EOF

  sudo tee "$timer_file" > /dev/null <<EOF
[Unit]
Description=HTS AI Stack — htsclaw health timer (every 5 min)

[Timer]
OnBootSec=2min
OnUnitActiveSec=5min
Persistent=true

[Install]
WantedBy=timers.target
EOF

  sudo systemctl daemon-reload
  sudo systemctl enable --now "${service_name}.timer"
  ok "Installed systemd timer: ${service_name}.timer (every 5 min)"
}

# htsclaw_health_timer_status — Show the timer status
htsclaw_health_timer_status() {
  local service_name="hts-htsclaw-health"
  systemctl status "${service_name}.timer" --no-pager 2>/dev/null || \
    warn "Timer '${service_name}.timer' not found — install it with --install."
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="health"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install) ACTION="install"; shift ;;
      --status)  ACTION="status"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    health)  htsclaw_health ;;
    install) htsclaw_install_health_timer ;;
    status)  htsclaw_health_timer_status ;;
  esac
fi
