# Evaluate NeMo NAT Optimizer — Plan

Purpose

- Outline a repeatable evaluation to compare optimization strategies (Optuna / GA) for NAT PoC.

Steps

1. Prepare a small, task-specific eval dataset (scripts/components/nat-eval-sample.jsonl).
2. Define evaluation metric(s) (e.g., BLEU, ROUGE-L, accuracy) depending on task.
3. Run optimizer with conservative trial count (e.g., 20 trials) and capture results.
4. Inspect best parameters and run stability experiments.

Artifacts

- scripts/components/nat-optimizer-config.yml (skeleton)
- scripts/components/nat-eval-sample.jsonl (sample inputs)

Security

- Do not include secrets or private data in evaluation artifacts.

Next steps

- Execute nat eval in an isolated sandbox (openshell or container) and gather results.
