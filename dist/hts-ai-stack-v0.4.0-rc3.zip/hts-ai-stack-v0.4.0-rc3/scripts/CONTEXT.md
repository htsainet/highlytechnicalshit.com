# Installation Scripts

Bootstrap and installation wizards for deploying the AI stack.

Last updated: 2026-04-16 12:00:00

## What happens here

This workspace contains the installation and setup scripts that guide users through deploying the full AI stack on Ubuntu. The process is split into bootstrap (prerequisites + drivers) and install (interactive configuration + convergence).

## Process / Workflow

**Bootstrap phase (curl | bash entry point):**

1. User runs: `curl -sSL https://highlytechnicalshit.com/bootstrap.sh | bash`
2. Script installs system prerequisites (curl, gpg, git, chrony, gh, jq, Docker)
3. Script clones repo to local system
4. Script installs PowerShell + Pester
5. Script installs NVIDIA drivers (always last — requires reboot)
6. User reboots system

**Install phase (interactive wizard + convergence):**

1. User runs `install.sh` from repo root
2. Wizard prompts for configuration choices → saves to `config/stack.json`
3. `apply_config.sh` maps stack.json → `.env`
4. Host prerequisites run (docker, node, tools — idempotent, bootstrap already handled most)
5. `converge.sh --yes` reads stack.json via component manifests and deploys all enabled Docker services
6. Post-converge: chat model loaded via `ollama.sh --swap`
7. Config snapshot saved to `/config/backups/YYYYMMDD-HHMMSS/`

**Day-2 reconfiguration:**

1. User runs `reconfigure.sh` (or `install.sh --reconfigure`)
2. Wizard re-runs → updates stack.json
3. `converge.sh` compares desired vs actual state, starts/stops only what changed

## Files and structure

| Folder | Purpose |
|--------|---------|
| `install/` | Numbered step scripts (01-autoinstall.sh, 02-setup-docker.sh, etc.) |
| `install/comms/` | Signal, Telegram, communication service setup |
| `install/models/` | Model-specific download and configuration helpers |
| `install/networking/` | Tailscale and network setup |
| `install/system/` | OS-level setup and configuration |
| `install/tooling/` | Developer and ops tooling installation |
| `utils/` | Utility scripts (npm-audit.sh, seed-model-cache.sh, teardown.sh, upgrade-nemoclaw.sh, verify.sh, etc.) |
| `config/` | Script-managed configuration files and wizard outputs |
| `*.py` (root) | Python operational scripts (see conventions below) |

## Shell script naming conventions

Each folder enforces a naming pattern. Scripts in the wrong folder or with the wrong naming pattern are considered violations.

| Folder | Pattern | Examples | Notes |
|--------|---------|----------|-------|
| `scripts/` (root) | Entry points only: `install.sh`, `bootstrap.sh`, `build.sh` | `install.sh`, `build.sh` | No operational scripts — those go in subfolders |
| `install/` | `NN-verb-noun.sh` (zero-padded number prefix) | `01-autoinstall.sh`, `06-start-stack.sh` | Numbered pipeline steps, executed in order |
| `install/` (sub-dirs) | `verb-noun.sh` or `noun.sh` | `setup-signal.sh`, `helpers.sh` | Subfolder scripts don't need number prefix |
| `components/` | `{service}.sh` (single lowercase word or hyphenated) | `ollama.sh`, `open-webui.sh` | One file per service with lifecycle functions |
| `bundles/` | `{use-case}.sh` (single word or hyphenated) | `chat.sh`, `voice.sh` | Orchestrated service groups (legacy — converge.sh is now the primary orchestrator) |
| `host/` | `{subsystem}.sh` (single word) | `nvidia.sh`, `docker.sh`, `tools.sh` | OS-level provisioning by subsystem |
| `lib/` | `{domain}.sh` (single word) | `common.sh`, `health.sh`, `compose.sh` | Sourced (not executed); shared library functions |
| `utils/` | `verb-noun.sh` (kebab-case) | `audit-models.sh`, `seed-model-cache.sh` | One-off operational tools |
| `issuefixers/` | `.issuefixer{ISSUE-NNN}.sh` (hidden, prefixed) | `.issuefixerISSUE-023.sh` | Temporary patches, deleted after fix confirmed |

**General rules:**

- All `.sh` files must have `#!/usr/bin/env bash` shebang (first line)
- All `.sh` files must have the executable bit set (`chmod +x`)
- Filenames are always lowercase kebab-case (no underscores, no camelCase)
- No `.sh` files at `scripts/` root except the three entry points

## Python script conventions

Operational Python scripts live alongside bash scripts and follow these rules:

| Convention | Rule |
|------------|------|
| Filename | `kebab-case.py` (matches bash `kebab-case.sh` convention) |
| Shebang | `#!/usr/bin/env python3` (first line) |
| Docstring | Triple-quote block immediately after shebang with description + usage examples |
| Location | Operational/CLI scripts → `scripts/` or `scripts/utils/`. Service resources → `resources/` |
| Dependencies | Prefer standard library. External packages (e.g. `requests`) declared in imports, not requirements.txt |
| Logging | Use `logging` module, write to `logs/` directory |
| CLI args | Use `argparse` with `--dry-run`, `--limit`, `--help` where applicable |

**Not Python scripts** (different convention):

- Open WebUI functions → `resources/open-webui-functions/` (snake_case, Pipe class, no shebang) — see [resources/CONTEXT.md](../resources/CONTEXT.md)
- Wizard config writer → `config/wizard/` (embedded in setup flow)

## What good looks like

- Scripts are idempotent (safe to run multiple times)
- Each step detects if already completed before proceeding
- Clear, descriptive output messages
- Config backups on every run
- Bootstrap runs unprivileged until driver install (then sudo)
- Install wizard validates choices before proceeding
- Graceful error handling with helpful recovery steps
- All configs stored under /config/backups/ with timestamps

## Tools and skills

- **bash** — Shell scripting (scripts written in bash)
- **Python 3** — Operational scripts (review automation, auditing). See Python conventions above
- **Docker** — Container orchestration and service management
- **NVIDIA Container Toolkit** — GPU support in containers
- **Ollama** — Local LLM inference engine
- **Tailscale** — Network connectivity and VPN
- **Claude Code** — Script generation and troubleshooting
