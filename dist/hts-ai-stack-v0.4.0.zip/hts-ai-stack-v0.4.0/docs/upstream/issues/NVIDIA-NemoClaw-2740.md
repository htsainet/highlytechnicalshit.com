# NVIDIA/NemoClaw#2740 — v0.0.30 sandbox image build fails — Dockerfile step 51/57 `ln -sfn .../workspace/media` ENOENT

| Field | Value |
|-------|-------|
| **Repo** | [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) |
| **Issue** | [#2740](https://github.com/NVIDIA/NemoClaw/issues/2740) |
| **State** | OPEN |
| **Severity** | high (blocks fresh sandbox build on v0.0.30/v0.0.31) |
| **Labels** | bug, Platform: Ubuntu, Docker, Sandbox, NV QA, UAT |
| **Opened** | 2026-04-30 |
| **Subscribed** | No (track via cron only) |

## Impact on us

We're bumping to NemoClaw `v0.0.31` to escape [#2689](./NVIDIA-NemoClaw-2689.md)'s
Step 17 Patch 4 failure. v0.0.30 / v0.0.31 introduced a new fresh-onboard
blocker at Dockerfile **Step 51/57**:

```text
ln: failed to create symbolic link '/sandbox/.openclaw-data/workspace/media':
    No such file or directory
```

Root cause (per the upstream report): the conditional
`if [ -e /sandbox/.openclaw-data/workspace/media ]` only checks the symlink
target, not whether the parent directory `/sandbox/.openclaw-data/workspace/`
exists. The unconditional `ln -sfn` then fails on a fresh image build (no
prior workspace state to migrate from). Likely fix is a single
`mkdir -p /sandbox/.openclaw-data/workspace` before the `ln -sfn`, or extending
the conditional to short-circuit when the parent doesn't exist.

This is fallout from [PR #2227](https://github.com/NVIDIA/NemoClaw/pull/2227)
("default to mutable config, make shields opt-in", merged 2026-04-30) which
removed the `.openclaw-data` split layout; the Dockerfile retained references
to the old paths.

Reproduces deterministically on Ubuntu hosts (matches our environment) for
both `nemoclaw onboard --fresh` and `nemoclaw onboard --resume` after a failed
rebuild. Hosts that were *already onboarded* under v0.0.29 and skipped the
fresh build are unaffected.

## Workaround

None on our side. Two paths if v0.0.31 fails on our box:

1. **Wait for v0.0.32+** — likely a small Dockerfile patch. Track via the
   watcher and bump the manifest pin when it lands.
2. **Rollback to v0.0.29** — set `pinned_version` back in the manifest and
   re-run `nemoclaw_install --force`. Existing v0.0.29 sandboxes survive a
   v0.0.31 install attempt; rollback is one line in the manifest.

## Action when resolved

1. Confirm the watcher reports CLOSED.
2. Bump `nemoclaw.manifest.json upstream.pinned_version` to the release that
   contains the fix.
3. Run `./scripts/utils/verify-openshell-pin.sh` after onboard to confirm
   blueprint and binary agree on the OpenShell pin.

## Status log

- **2026-04-30** — Filed upstream as #2740 by NVIDIA QA. Two +1 reactions.
- **2026-04-30** — We bumped our pin from `v0.0.29` to `v0.0.31` to escape
  #2689; this issue is the explicit revisit condition for staying on v0.0.31.
  Added to `upstream-watch.sh`.
- **2026-04-30** — ✅ Did **not** reproduce on this Ubuntu host: fresh
  `nemoclaw onboard` against v0.0.31 completed past Step 51/57 without the
  `workspace/media` ENOENT. Possible reasons: pre-existing
  `~/.nemoclaw/` state from prior v0.0.29 onboards seeded the workspace
  parent, or the `mkdir` race only triggers in a narrower repro window than
  the upstream report suggests. Keep watching — if a future force-rebuild
  hits it, fall back to the rollback path or wait for v0.0.32+.
