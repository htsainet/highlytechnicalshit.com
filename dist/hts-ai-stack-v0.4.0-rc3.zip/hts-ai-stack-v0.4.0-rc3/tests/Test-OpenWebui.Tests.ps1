$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/open-webui'
    $script:ComponentScript = Join-Path $script:ComponentDir 'open-webui.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'open-webui.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'open-webui file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'open-webui manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is open-webui' {
        $script:Manifest.id | Should -Be 'open-webui'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/open-webui/open-webui.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is openwebui' {
        $script:Manifest.func_prefix | Should -Be 'openwebui'
    }

    It 'dashboard port is 3000' {
        [int]$script:Manifest.dashboard.port | Should -Be 3000
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'open-webui component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines openwebui_install function' {
        $script:ComponentContent | Should -Match 'openwebui_install\s*\(\)'
    }

    It 'defines openwebui_configure function' {
        $script:ComponentContent | Should -Match 'openwebui_configure\s*\(\)'
    }

    It 'defines openwebui_start function' {
        $script:ComponentContent | Should -Match 'openwebui_start\s*\(\)'
    }

    It 'defines openwebui_stop function' {
        $script:ComponentContent | Should -Match 'openwebui_stop\s*\(\)'
    }

    It 'defines openwebui_health function' {
        $script:ComponentContent | Should -Match 'openwebui_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/open-webui/open-webui\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'open-webui port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 3000 is registered in portmap.json' {
        $script:Portmap.ports.'3000' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'3000'.service | Should -Be 'open-webui'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'open-webui no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/open-webui\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/open-webui/open-webui\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}

# ── Open WebUI compose security ─────────────────────────────────────────────

Describe 'open-webui compose security' {
    BeforeAll {
        $script:ComposeContent = Get-Content -Path (Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'compose sets WEBUI_SECRET_KEY' {
        $script:ComposeContent | Should -Match 'WEBUI_SECRET_KEY'
    }
}

# ── Open WebUI configure function ────────────────────────────────────────────

Describe 'open-webui configure function' {
    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines openwebui_configure function' {
        $script:ComponentContent | Should -Match 'openwebui_configure\s*\(\)'
    }
}
