# Flowise Component

Last updated: 2026-04-15

## What happens here

Flowise is a drag-and-drop LLM orchestration tool for building chatflows
and agent workflows visually. Used in the stack as a low-code way to
chain LLM calls, tools, and data sources.

## Files and structure

| File | Purpose |
|------|---------|
| `flowise.sh` | Full lifecycle: install, configure, start, stop, health |
| `flowise.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
