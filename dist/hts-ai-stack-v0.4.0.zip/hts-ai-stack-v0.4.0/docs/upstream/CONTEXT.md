# Upstream Dependency Tracking

Last updated: 2026-04-08 20:00:00

## What happens here

This workspace tracks upstream GitHub repositories that hts-ai-stack depends on:
version currency, open issues that affect us, and action plans for when fixes land.

## Process / Workflow

1. **Discovery** — Upstream issue found (via cron watcher, manual browsing, or breakage)
2. **Triage** — Assess severity and impact on our stack
3. **Track** — Create `issues/OWNER-REPO-NUMBER.md` with impact analysis and action plan
4. **Monitor** — Automated cron (`scripts/utils/upstream-watch.sh`) polls issue state daily
5. **Resolve** — When upstream closes the issue, execute the documented action plan
6. **Archive** — Move resolved issue file to `issues/resolved/` and update REFERENCES.md

## Files and structure

- [REFERENCES.md](REFERENCES.md) — Two master tables: dependency inventory + active issues
- `issues/` — One `.md` per tracked upstream issue (naming: `OWNER-REPO-NUMBER.md`)
- `issues/resolved/` — Archived issue files after resolution

## Issue file template

Each `issues/OWNER-REPO-NUMBER.md` must contain:

```markdown
# OWNER/REPO#NUMBER — Title

| Field | Value |
|-------|-------|
| **Repo** | [OWNER/REPO](https://github.com/OWNER/REPO) |
| **Issue** | [#NUMBER](https://github.com/OWNER/REPO/issues/NUMBER) |
| **State** | OPEN / CLOSED |
| **Severity** | critical / high / medium / low |
| **Labels** | upstream labels |
| **Opened** | YYYY-MM-DD |
| **Subscribed** | Yes / No |

## Impact on us

What scripts, services, or configs are affected.

## Workaround

What we're doing in the meantime (or "None — waiting on upstream").

## Action when resolved

Step-by-step what to do when the fix lands.

## Status log

- **YYYY-MM-DD** — Entry describing status change or new information
```

## What good looks like

- Every tracked issue has a corresponding `.md` file with impact analysis
- REFERENCES.md dependency table is updated when versions change
- Resolved issues are archived, not deleted (preserves git history)
- Cron watcher (`scripts/utils/upstream-watch.sh`) covers all tracked issues
- No surprise breakage from upstream — we see it coming

## Tools and skills

- `gh` CLI for issue polling and subscriptions
- `scripts/utils/upstream-watch.sh` for automated daily checks
- `logs/upstream-watch.log` for raw audit trail
