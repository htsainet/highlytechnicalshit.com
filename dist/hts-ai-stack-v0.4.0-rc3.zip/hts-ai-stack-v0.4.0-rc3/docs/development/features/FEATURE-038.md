# FEATURE-038 — reconfigure.sh: Day-2 Stack Reconfiguration Script

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | HIGH |
| **Effort** | 1–2 hours |
| **Risk** | Low — new script, no changes to existing paths |
| **Target Release** | v0.5.0 |
| **Status** | ✅ COMPLETE (April 2026) |
| **Depends on** | FEATURE-009 (converge.sh — complete) |
| **Blocks** | Nothing |

## Problem

The current day-2 reconfiguration path is `./install.sh --reconfigure`, which
used to re-run `full-stack.sh`. This was wrong for post-install changes because
`full-stack.sh` re-executed host bootstrap steps (nvidia drivers, Docker setup,
Node install, system tools) that should only ever run once via `bootstrap.sh`.

## Solution (implemented)

`reconfigure.sh` exists as a lightweight day-2 reconfiguration script.
`install.sh` has been updated to call `converge.sh` directly (no more
`full-stack.sh` in the middle). `full-stack.sh` is now a deprecated stub.

The intended lifecycle is:

```text
bootstrap.sh      — runs ONCE on a fresh host (host-level setup, NVIDIA last → reboot)
install.sh        — initial full install (wizard + host prereqs + converge.sh)
reconfigure.sh    — day-2+ changes (wizard + converge.sh only, no host setup)
```

### Key differences

| Step | `install.sh` | `reconfigure.sh` |
|------|-------------|-----------------|
| Host bootstrap | ✅ (docker + node + tools) | ❌ skipped |
| NVIDIA | ❌ (bootstrap.sh only) | ❌ skipped |
| Setup wizard | ✅ optional | ✅ optional |
| apply_config.sh | ✅ | ✅ (via converge.sh) |
| converge.sh | ✅ | ✅ |
