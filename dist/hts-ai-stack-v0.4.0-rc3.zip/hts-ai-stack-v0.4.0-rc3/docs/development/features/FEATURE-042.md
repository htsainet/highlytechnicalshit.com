# FEATURE-042: Manifest-Driven Dashboard + 4 New Components

## Status

Complete — implemented in `feature/009-converge`.

## Problem

1. Dashboard had a hardcoded `const services` array requiring manual edits for
   each new component.
2. Dashboard had no refresh capability — health probes ran once at page load.
3. Four new components needed: n8n, Open WebUI Pipelines, SearXNG, and Langflow.

## Solution

### Part A: Manifest-Driven Dashboard

Each component manifest gains an optional `dashboard` block describing how its
tile should appear. A generator script reads all manifests and produces
`resources/dashboard/services.json`. The dashboard fetches this file at boot
and on demand via a refresh button.

### Part B: 4 New Components

Added n8n, Open WebUI Pipelines, SearXNG, and Langflow following the exact
Flowise pattern (manifest + lifecycle script + compose service).

## Dashboard Block Schema

```json
"dashboard": {
  "section": "Agent Applications",
  "title": "Flowise",
  "port": 3005,
  "path": "/",
  "probePath": "/api/v1/ping",
  "proto": "http",
  "desc": "Drag-and-drop LLM chain & agent builder",
  "show": true
}
```

## New Files

| File | Purpose |
|------|---------|
| `scripts/components/n8n.manifest.json` | n8n manifest |
| `scripts/components/n8n/n8n.sh` | n8n lifecycle script |
| `scripts/components/pipelines.manifest.json` | Pipelines manifest |
| `scripts/components/pipelines/pipelines.sh` | Pipelines lifecycle script |
| `scripts/components/searxng.manifest.json` | SearXNG manifest |
| `scripts/components/searxng/searxng.sh` | SearXNG lifecycle script |
| `scripts/components/langflow.manifest.json` | Langflow manifest |
| `scripts/components/langflow/langflow.sh` | Langflow lifecycle script |
| `scripts/utils/generate-services-json.sh` | services.json generator |
| `resources/dashboard/services.json` | Generated dashboard registry |

## Modified Files

| File | Changes |
|------|---------|
| `scripts/components/*.manifest.json` (22) | Added `dashboard` blocks |
| `docker-compose.yml` | Added 4 services + 4 volumes |
| `scripts/lib/state-actual.sh` | Added 4 container map entries |
| `REFERENCES.md` | Added 4 port reservations |
| `resources/dashboard/index.html` | Fetch-based services + refresh button |
| `scripts/utils/converge.sh` | Auto-regenerates services.json |

## New Ports

| Port | Service |
|------|---------|
| 5678 | n8n workflow automation |
| 7870 | Langflow visual AI builder |
| 8787 | SearXNG meta-search |
| 9099 | Open WebUI Pipelines |

## Stack JSON Seeds

The following keys default to `false` in `stack.json` (gitignored):

- `.n8n.enabled`
- `.pipelines.enabled`
- `.searxng.enabled`
- `.langflow.enabled`
