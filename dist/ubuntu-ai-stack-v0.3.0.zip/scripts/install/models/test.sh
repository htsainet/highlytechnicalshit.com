#!/usr/bin/env bash
set -euo pipefail
# ─────────────────────────────────────────────────────────────────────────────
# test.sh
# Seeds ollama-test and sd-test with evaluation models.
# STOPS both containers after seeding — start manually when needed:
#   docker compose up -d ollama-test stable-diffusion-test
# ─────────────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(dirname "$0")"
if [[ -f "${SCRIPT_DIR}/helpers.sh" ]]; then
  source "${SCRIPT_DIR}/helpers.sh"
else
  echo "[FAIL] helpers.sh not found in ${SCRIPT_DIR}" >&2
  exit 1
fi
export COMPOSE_FILE="$(cd "${SCRIPT_DIR}/../../.." && pwd)/instances/test/docker-compose.yml"
ensure_ai_network

OLLAMA_CONTAINER="ollama-test"
OLLAMA_PORT="11435"
OLLAMA_DEFAULT="dolphin3:latest"
SD_SERVICE="stable-diffusion-test"

# ─────────────────────────────────────────────────────────────────────────────
# TEST OLLAMA MODELS
# New arrivals and community models being evaluated before promotion to prod.
# Once a model passes testing, add it to scripts/install/models/prod.sh and re-run.
# ─────────────────────────────────────────────────────────────────────────────
OLLAMA_MODELS_TEST=(
  # ── Prod mode models — for baseline comparison against test candidates ──────
  "smollm2:135m"
  "mistral-nemo:latest"
  "deepseek-r1:14b"
  "phi4:14b"

  # ── Graduated from prod — stable but not mapped to a --chat mode ───────────
  "phi3.5:latest"
  "qwen3.5:0.8b"
  "qwen3.5:9b"
  "qwen2.5:7b-instruct-q4_K_M"
  "gurubot/ollamatron:8b-q4_K_M"
  "granite3.1-dense:8b"

  # ── Active evaluation ──────────────────────────────────────────────────────
  # Carried over from prod for baseline comparison
  "dolphin3:latest"

  # HuggingFace models under evaluation
  "hf.co/xiaomi-open-source/Xiaomi-MiMo-VL-Miloco-7B-GGUF:Q4_0"
  "hf.co/nvidia/NVIDIA-Nemotron-3-Nano-4B-GGUF:Q4_K_M"
  "hf.co/bartowski/nvidia_Nemotron-Cascade-8B-GGUF:Q4_K_M"
  "hf.co/Jackrong/Qwen3.5-9B-Claude-4.6-Opus-Reasoning-Distilled-v2-GGUF:Q4_K_M"

  # IBM Granite (evaluation)
  "hf.co/ibm-granite/granite-4.0-1b-base-GGUF:F16"
)

# ─────────────────────────────────────────────────────────────────────────────
# TEST SD MODELS
# SFW checkpoints for prompt and settings evaluation.
# Verify URLs at huggingface.co before running.
# ─────────────────────────────────────────────────────────────────────────────
SD_MODELS_TEST=(
  # Versatile / fantasy characters
  "dreamshaper_v8.safetensors|https://huggingface.co/Lykon/DreamShaper/resolve/main/DreamShaper_8_pruned.safetensors"

  # Photorealistic (SFW)
  "realistic_vision_v5.1.safetensors|https://huggingface.co/SG161222/Realistic_Vision_V5.1_noVAE/resolve/main/Realistic_Vision_V5.1.safetensors"

  # Anime / illustration
  "anything_v5.safetensors|https://huggingface.co/ckpt/anything-v5.0/resolve/main/AnythingV5V3_v5PrtRE.safetensors"
)

# ─────────────────────────────────────────────────────────────────────────────

step "0 — Host directories"
create_model_dirs

# ── Step 1: Ollama test ───────────────────────────────────────────────────────
step "1 — Ollama test models"

start_container "$OLLAMA_CONTAINER"
wait_for_ollama "$OLLAMA_CONTAINER" "$OLLAMA_PORT"

info "Pulling default model first: $OLLAMA_DEFAULT"
pull_ollama_if_missing "$OLLAMA_CONTAINER" "$OLLAMA_PORT" "$OLLAMA_DEFAULT"

info "Pulling remaining test models in background..."
pids=()
for model in "${OLLAMA_MODELS_TEST[@]}"; do
  if [[ "$model" == "$OLLAMA_DEFAULT" ]]; then
    continue
  fi
  (
    pull_ollama_if_missing "$OLLAMA_CONTAINER" "$OLLAMA_PORT" "$model"
  ) &
  pids+=("$!")
done
for pid in "${pids[@]}"; do
  wait "$pid"
done
ok "All test ollama models are ready."

info "Stopping $OLLAMA_CONTAINER — start manually when evaluating models."
stop_container "$OLLAMA_CONTAINER"

# ── Step 2: Stable Diffusion test ────────────────────────────────────────────
step "2 — Stable Diffusion test checkpoints"

SD_VOLUME=$(find_or_create_sd_volume "sd_models_test" "$SD_SERVICE")
info "Using volume: $SD_VOLUME"

for entry in "${SD_MODELS_TEST[@]}"; do
  filename="${entry%%|*}"
  url="${entry##*|}"
  download_sd_if_missing "$SD_VOLUME" "$filename" "$url"
done

info "Stopping $SD_SERVICE — start manually when evaluating."
stop_container "$SD_SERVICE"

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
ok "Test setup complete."
info "  ollama-test  → stopped (port $OLLAMA_PORT when running, default: $OLLAMA_DEFAULT)"
info "  sd-test      → stopped (port 7861 when running)"
info ""
info "To start test environment:"
info "  docker compose up -d ollama-test stable-diffusion-test"
info ""
info "To promote a model to prod, add it to OLLAMA_MODELS_PROD in scripts/install/models/prod.sh"
