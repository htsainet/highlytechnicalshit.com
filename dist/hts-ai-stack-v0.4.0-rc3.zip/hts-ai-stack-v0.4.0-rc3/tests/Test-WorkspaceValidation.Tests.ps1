#Requires -Modules Pester

<#
.SYNOPSIS
    Pester tests to validate a Claude workspace folder follows the
    "Your First Folder" structure (Section 1.2).

.DESCRIPTION
    Validates that:
    - The workspace folder exists
    - CLAUDE.md, CONTEXT.md, and REFERENCES.md are present
    - Each file contains the required section headers
    - Placeholder brackets have been replaced with real content

.PARAMETER WorkspacePath
    Path to the workspace folder to validate. Defaults to the current directory.

.EXAMPLE
    Invoke-Pester -Path ./Test-WorkspaceValidation.Tests.ps1 -Container (
        New-PesterContainer -Path ./Test-WorkspaceValidation.Tests.ps1 -Data @{
            WorkspacePath = "C:\Projects\my-first-workspace"
        }
    )

.EXAMPLE
    # Quick run from inside the workspace folder:
    Invoke-Pester -Path ./Test-WorkspaceValidation.Tests.ps1
#>

param(
    [string]$WorkspacePath = $PWD.Path
)

BeforeDiscovery {
    # Resolve once so every test block sees the same value
    $script:WS = (Resolve-Path -Path $WorkspacePath -ErrorAction SilentlyContinue).Path
}

Describe "Claude Workspace Folder Structure" -Tag "Structure" {

    Context "Workspace root" {

        It "Folder '<WorkspacePath>' should exist" {
            $script:WS | Should -Not -BeNullOrEmpty
            Test-Path -Path $script:WS -PathType Container | Should -BeTrue
        }
    }

    Context "Required files exist" {

        It "CLAUDE.md should exist" {
            Join-Path $script:WS "CLAUDE.md" | Test-Path | Should -BeTrue
        }

        It "CONTEXT.md should exist" {
            Join-Path $script:WS "CONTEXT.md" | Test-Path | Should -BeTrue
        }

        It "REFERENCES.md should exist" {
            Join-Path $script:WS "REFERENCES.md" | Test-Path | Should -BeTrue
        }
    }
}

Describe "CLAUDE.md Content Validation" -Tag "Claude" {

    BeforeAll {
        $script:ClaudePath = Join-Path $script:WS "CLAUDE.md"
        if (Test-Path $script:ClaudePath) {
            $script:ClaudeContent = Get-Content -Path $script:ClaudePath -Raw
        }
    }

    Context "Required sections" {

        It "Should contain an '# Identity' heading" {
            $script:ClaudeContent | Should -Match '(?m)^#\s+Identity'
        }

        It "Should contain a '## Rules' heading" {
            $script:ClaudeContent | Should -Match '(?m)^##\s+Rules'
        }
    }

    Context "Placeholder replacement" {

        It "Should not still contain '[YOUR NAME]'" {
            $script:ClaudeContent | Should -Not -Match '\[YOUR NAME\]'
        }

        It "Should not still contain '[WHAT YOU DO]'" {
            $script:ClaudeContent | Should -Not -Match '\[WHAT YOU DO\]'
        }
    }

    Context "Minimum content" {

        It "Should have at least one rule listed (a line starting with '- ')" {
            $script:ClaudeContent | Should -Match '(?m)^- .+'
        }

        It "Should be longer than 50 characters (not just headers)" {
            $script:ClaudeContent.Length | Should -BeGreaterThan 50
        }
    }
}

Describe "CONTEXT.md Content Validation" -Tag "Context" {

    BeforeAll {
        $script:ContextPath = Join-Path $script:WS "CONTEXT.md"
        if (Test-Path $script:ContextPath) {
            $script:ContextContent = Get-Content -Path $script:ContextPath -Raw
        }
    }

    Context "Required sections" {

        It "Should contain a '# Current Project' heading" {
            $script:ContextContent | Should -Match '(?m)^#\s+Current Project'
        }

        It "Should contain a '## What we are building' heading" {
            $script:ContextContent | Should -Match '(?mi)^##\s+What we are building'
        }

        It "Should contain a '## What good looks like' heading" {
            $script:ContextContent | Should -Match '(?mi)^##\s+What good looks like'
        }

        It "Should contain a '## What to avoid' heading" {
            $script:ContextContent | Should -Match '(?mi)^##\s+What to avoid'
        }
    }

    Context "Placeholder replacement" {

        It "Should not still contain '[Describe your project in 2-3 sentences]'" {
            $script:ContextContent | Should -Not -Match '\[Describe your project'
        }

        It "Should not still contain '[What does a successful output look like?]'" {
            $script:ContextContent | Should -Not -Match '\[What does a successful output'
        }

        It "Should not still contain '[Common mistakes or things you do not want]'" {
            $script:ContextContent | Should -Not -Match '\[Common mistakes'
        }
    }

    Context "Minimum content" {

        It "Should have real content under 'What we are building' (not empty)" {
            # Grab text between this heading and the next heading
            $script:ContextContent | Should -Match '(?msi)##\s+What we are building\s*\r?\n+\S'
        }

        It "Should be longer than 100 characters" {
            $script:ContextContent.Length | Should -BeGreaterThan 100
        }
    }
}

Describe "REFERENCES.md Content Validation" -Tag "References" {

    BeforeAll {
        $script:RefsPath = Join-Path $script:WS "REFERENCES.md"
        if (Test-Path $script:RefsPath) {
            $script:RefsContent = Get-Content -Path $script:RefsPath -Raw
        }
    }

    Context "Required sections" {

        It "Should contain a '# References' heading" {
            $script:RefsContent | Should -Match '(?m)^#\s+References'
        }

        It "Should contain a '## Examples of good work' heading" {
            $script:RefsContent | Should -Match '(?mi)^##\s+Examples of good work'
        }

        It "Should contain a '## Relevant links' heading" {
            $script:RefsContent | Should -Match '(?mi)^##\s+Relevant links'
        }

        It "Should contain a '## Notes' heading" {
            $script:RefsContent | Should -Match '(?mi)^##\s+Notes'
        }
    }

    Context "Placeholder replacement" {

        It "Should not still contain '[Paste an example' placeholder" {
            $script:RefsContent | Should -Not -Match '\[Paste an example'
        }

        It "Should not still contain '[URLs, docs, resources' placeholder" {
            $script:RefsContent | Should -Not -Match '\[URLs, docs, resources'
        }

        It "Should not still contain '[Anything else Claude should know]'" {
            $script:RefsContent | Should -Not -Match '\[Anything else Claude should know\]'
        }
    }

    Context "Minimum content" {

        It "Should be longer than 50 characters" {
            $script:RefsContent.Length | Should -BeGreaterThan 50
        }
    }
}

Describe "Overall Workspace Hygiene" -Tag "Hygiene" {

    Context "No stray placeholder brackets across all files" {

        It "No file should contain generic '[YOUR ...' placeholders" {
            $mdFiles = Get-ChildItem -Path $script:WS -Filter "*.md" -File
            foreach ($file in $mdFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                $content | Should -Not -Match '\[YOUR\s' -Because "$($file.Name) still has unfilled placeholders"
            }
        }
    }

    Context "File encoding" {

        It "All .md files should be valid UTF-8 (readable)" {
            $mdFiles = Get-ChildItem -Path $script:WS -Filter "*.md" -File
            foreach ($file in $mdFiles) {
                { Get-Content -Path $file.FullName -Raw -Encoding UTF8 } |
                    Should -Not -Throw -Because "$($file.Name) should be readable as UTF-8"
            }
        }
    }
}
