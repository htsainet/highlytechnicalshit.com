#!/usr/bin/env bash
# Downgrade NemoClaw CLI to an older tag so its blueprint.yaml accepts
# openshell 0.0.26.
#
# Default target: v0.0.21 (newest tag whose nemoclaw-blueprint/blueprint.yaml
# pins min_openshell_version=0.0.24, max_openshell_version=0.0.26).
#
# Usage:
#   ./scripts/utils/downgrade-nemoclaw.sh                    # v0.0.21 (default)
#   ./scripts/utils/downgrade-nemoclaw.sh v0.0.18            # pick a specific tag
#   NEMOCLAW_TAG=v0.0.17 ./scripts/utils/downgrade-nemoclaw.sh
#
# What it does:
#   1. Snapshots every existing sandbox (official vendor-supported safety net).
#   2. Stops sandboxes + openshell gateway.
#   3. Backs up ~/.nemoclaw (source tree + blueprint) to a timestamped dir.
#   4. Uninstalls the current nemoclaw npm global package under NVM.
#   5. Re-runs the NVIDIA installer pinned to the requested tag.
#   6. Runs `nemoclaw onboard` so it regenerates blueprint.yaml at the new tag.
#   7. Verifies the resulting blueprint allows openshell 0.0.26.
#
# Idempotent: safe to re-run. Requires sudo for host-side cleanup only if
# stale gateway containers need force-removal.

set -euo pipefail

TAG="${1:-${NEMOCLAW_TAG:-v0.0.21}}"
# Hardcoded for emergency rollback target (v0.0.21 / 0.0.26).
# Current canonical pin is in scripts/components/nemoclaw/nemoclaw.manifest.json
# upstream.openshell_pinned_version. Update this only if you intend
# to change the rollback target.
EXPECTED_OPENSHELL="0.0.26"
NEMOCLAW_MODEL="${NEMOCLAW_MODEL:-mistral-nemo:latest}"

say()  { printf '\n\033[1;36m[nemoclaw-downgrade]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[FAIL]\033[0m %s\n' "$*" >&2; exit 1; }

# Make nemoclaw findable even in a non-interactive shell
[[ -f "$HOME/.nvm/nvm.sh" ]] && source "$HOME/.nvm/nvm.sh" >/dev/null 2>&1 || true
NPM_PREFIX=$(npm config get prefix 2>/dev/null || echo "")
export PATH="$HOME/.local/bin:$HOME/.npm-global/bin:${NPM_PREFIX:+${NPM_PREFIX}/bin:}$PATH"

say "Target NemoClaw tag: ${TAG}"

if [[ -f "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/components/ollama/ollama.sh" ]]; then
  (
    export OLLAMA_MODEL="$NEMOCLAW_MODEL"
    # shellcheck source=/dev/null
    source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/components/ollama/ollama.sh"
    ollama_ensure_models
  ) || die "NemoClaw model '${NEMOCLAW_MODEL}' is not ready in Ollama"
fi

# 1. Snapshot every sandbox (vendor-supported rollback safety net)
if command -v nemoclaw >/dev/null 2>&1; then
  say "Taking snapshots of existing sandboxes"
  mapfile -t SANDBOXES < <(nemoclaw list 2>/dev/null | awk 'NR>1 {print $1}' | grep -v '^$' || true)
  for sb in "${SANDBOXES[@]:-}"; do
    [[ -z "$sb" ]] && continue
    echo "  • snapshot ${sb}"
    nemoclaw "$sb" snapshot create "pre-downgrade-$(date +%Y%m%d-%H%M%S)" \
      2>/dev/null || warn "    snapshot failed for ${sb} (continuing)"
  done
else
  warn "nemoclaw CLI not on PATH — skipping snapshot step"
fi

# 2. Stop sandboxes + gateway
say "Stopping sandboxes and OpenShell gateway"
for sb in "${SANDBOXES[@]:-}"; do
  [[ -z "$sb" ]] && continue
  nemoclaw "$sb" stop 2>/dev/null || true
done
openshell gateway stop 2>/dev/null || true

# 3. Backup ~/.nemoclaw (non-destructive — move, don't delete)
if [[ -d "$HOME/.nemoclaw" ]]; then
  BACKUP="$HOME/.nemoclaw.backup-$(date +%Y%m%d-%H%M%S)"
  say "Moving ~/.nemoclaw → ${BACKUP}  (restore with: mv ${BACKUP} ~/.nemoclaw)"
  mv "$HOME/.nemoclaw" "$BACKUP"
fi

# 4. Uninstall current nemoclaw npm global package (ignore if not installed)
if command -v nemoclaw >/dev/null 2>&1; then
  say "Uninstalling current nemoclaw npm global"
  # NVIDIA publishes under a couple of names historically — try both
  npm uninstall -g @nvidia/nemoclaw 2>/dev/null || true
  npm uninstall -g nemoclaw          2>/dev/null || true
fi

if command -v nemoclaw >/dev/null 2>&1; then
  warn "nemoclaw still on PATH at $(command -v nemoclaw) after npm uninstall"
  warn "the installer will overwrite it — continuing"
fi

# 5. Re-run NVIDIA installer pinned to the target tag
say "Running NVIDIA installer at tag ${TAG}"
# Pass provider env so the [3/8] Configuring inference step routes to llama-swap
# instead of NVIDIA Endpoints. See DEVIATIONS.md → NemoClaw.
env NEMOCLAW_NON_INTERACTIVE=1 \
    NEMOCLAW_ACCEPT_THIRD_PARTY_SOFTWARE=1 \
    NEMOCLAW_SKIP_ONBOARD=1 \
    NEMOCLAW_INSTALL_TAG="${TAG}" \
    NEMOCLAW_EXPERIMENTAL=1 \
    NEMOCLAW_PROVIDER=custom \
    NEMOCLAW_ENDPOINT_URL="http://localhost:${LLAMA_SWAP_PORT:-8081}/v1" \
    NEMOCLAW_MODEL="${NEMOCLAW_MODEL}" \
    COMPATIBLE_API_KEY=not-needed \
    NEMOCLAW_POLICY_MODE=suggested \
  bash -c 'curl -fsSL https://www.nvidia.com/nemoclaw.sh | bash' \
  || die "NVIDIA installer failed at tag ${TAG}"

# Refresh PATH after installer (it uses nvm)
[[ -f "$HOME/.nvm/nvm.sh" ]] && source "$HOME/.nvm/nvm.sh" >/dev/null 2>&1 || true
NPM_PREFIX=$(npm config get prefix 2>/dev/null || echo "")
export PATH="$HOME/.local/bin:$HOME/.npm-global/bin:${NPM_PREFIX:+${NPM_PREFIX}/bin:}$PATH"

command -v nemoclaw >/dev/null 2>&1 \
  || die "nemoclaw CLI not found after install — check nvm/npm PATH"
say "Installed: $(nemoclaw --version 2>/dev/null || echo '(version unknown)')"

# 6. Onboard to regenerate blueprint.yaml at the new tag
say "Running 'nemoclaw onboard' to regenerate blueprint"
env NEMOCLAW_NON_INTERACTIVE=1 \
    NEMOCLAW_EXPERIMENTAL=1 \
    NEMOCLAW_PROVIDER=custom \
    NEMOCLAW_ENDPOINT_URL="http://localhost:${LLAMA_SWAP_PORT:-8081}/v1" \
    NEMOCLAW_MODEL="${NEMOCLAW_MODEL}" \
    COMPATIBLE_API_KEY=not-needed \
    NEMOCLAW_POLICY_MODE=suggested \
  nemoclaw onboard --non-interactive \
  || die "'nemoclaw onboard' failed"

# 7. Verify the new blueprint accepts openshell 0.0.26
BP=$(find "$HOME/.nemoclaw" -name 'blueprint.yaml' 2>/dev/null | head -1 || true)
if [[ -z "$BP" ]]; then
  die "blueprint.yaml not found under ~/.nemoclaw after onboard"
fi
MIN=$(grep -E 'min_openshell_version' "$BP" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
MAX=$(grep -E 'max_openshell_version' "$BP" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
say "Blueprint: min=${MIN} max=${MAX}  (file: ${BP})"

# String-sort comparison is fine for 0.0.xx
if [[ -n "$MIN" && -n "$MAX" ]] \
   && [[ "$EXPECTED_OPENSHELL" > "$MIN" || "$EXPECTED_OPENSHELL" == "$MIN" ]] \
   && [[ "$EXPECTED_OPENSHELL" < "$MAX" || "$EXPECTED_OPENSHELL" == "$MAX" ]]; then
  say "SUCCESS: openshell ${EXPECTED_OPENSHELL} is within blueprint range [${MIN}, ${MAX}]"
  say "Next: ./scripts/utils/verify-openshell-pin.sh should now pass cleanly"
else
  die "Blueprint range [${MIN}, ${MAX}] does NOT accept openshell ${EXPECTED_OPENSHELL}"
fi
