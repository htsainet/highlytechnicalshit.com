#!/usr/bin/env bash
# scripts/components/obs-studio/obs-studio.sh — OBS Studio: install, configure, health
#
# Host-native installer for OBS Studio via the official PPA.
# Streaming, screen recording, and scene composition with NVENC GPU encoding.
#
# Standalone usage:
#   ./scripts/components/obs-studio/obs-studio.sh              # full: install + configure + health
#   ./scripts/components/obs-studio/obs-studio.sh --install    # install only
#   ./scripts/components/obs-studio/obs-studio.sh --configure  # configure only
#   ./scripts/components/obs-studio/obs-studio.sh --start      # no-op (desktop app)
#   ./scripts/components/obs-studio/obs-studio.sh --stop       # no-op (desktop app)
#   ./scripts/components/obs-studio/obs-studio.sh --restart    # no-op (desktop app)
#   ./scripts/components/obs-studio/obs-studio.sh --health     # health check only
#   ./scripts/components/obs-studio/obs-studio.sh --status     # show status + health
#   ./scripts/components/obs-studio/obs-studio.sh --destroy    # uninstall OBS Studio
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# ── Functions ────────────────────────────────────────────────────────────────

obs_studio_install() {
  step "OBS Studio — install"
  if command -v obs &>/dev/null; then
    skip "OBS Studio already installed."
  else
    # Add official OBS PPA for latest version
    if ! grep -q "obsproject/obs-studio" /etc/apt/sources.list.d/*.list 2>/dev/null; then
      info "Adding OBS Studio PPA..."
      sudo add-apt-repository -y ppa:obsproject/obs-studio
    fi
    info "Installing OBS Studio..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq obs-studio
    ok "OBS Studio installed."
  fi
}

obs_studio_configure() {
  step "OBS Studio — configure"
  info "Launch OBS Studio from the desktop to complete first-run setup."
  info "NVENC hardware encoding is available with NVIDIA GPU."
  ok "OBS Studio configured."
}

obs_studio_start() {
  step "OBS Studio — start"
  info "Desktop application — launch from your desktop environment."
  ok "OBS Studio start complete."
}

obs_studio_stop() {
  step "OBS Studio — stop"
  info "Desktop application — close from the GUI."
  ok "OBS Studio stop complete."
}

obs_studio_health() {
  local label="OBS Studio"
  printf "  %-35s" "$label"
  if command -v obs &>/dev/null; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (obs not found in PATH)"
    return 1
  fi
}

obs_studio_restart() {
  obs_studio_stop
  obs_studio_start
}

obs_studio_destroy() {
  step "OBS Studio — destroy"
  sudo apt-get remove -y obs-studio 2>/dev/null || true
  sudo apt-get autoremove -y -qq
  ok "OBS Studio removed."
}

obs_studio_status() {
  step "OBS Studio — status"
  if command -v obs &>/dev/null; then
    ok "OBS Studio installed"
  else
    warn "OBS Studio NOT installed"
  fi
  obs_studio_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   obs_studio_install   ;;
    configure) obs_studio_configure ;;
    start)     obs_studio_start     ;;
    stop)      obs_studio_stop      ;;
    restart)   obs_studio_restart   ;;
    health)    obs_studio_health    ;;
    status)    obs_studio_status    ;;
    destroy)   obs_studio_destroy   ;;
    default)
      obs_studio_install
      obs_studio_configure
      obs_studio_health
      ;;
  esac
fi
