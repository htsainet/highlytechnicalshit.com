#!/usr/bin/env bash
# scripts/components/prometheus/prometheus.sh — Prometheus: install, configure, start, health
#
# Metrics collection & time-series database for monitoring the AI stack.
#
# Standalone usage:
#   ./scripts/components/prometheus/prometheus.sh              # full: install + configure + start + health
#   ./scripts/components/prometheus/prometheus.sh --install    # install only (build image)
#   ./scripts/components/prometheus/prometheus.sh --configure  # configure only
#   ./scripts/components/prometheus/prometheus.sh --start      # start only
#   ./scripts/components/prometheus/prometheus.sh --stop       # stop
#   ./scripts/components/prometheus/prometheus.sh --restart    # restart (stop + start)
#   ./scripts/components/prometheus/prometheus.sh --health     # health check only
#   ./scripts/components/prometheus/prometheus.sh --status     # show status + port + health
#   ./scripts/components/prometheus/prometheus.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
PROMETHEUS_PORT="${PROMETHEUS_PORT:-9090}"

# ── Functions ────────────────────────────────────────────────────────────────

prometheus_install() {
  step "Prometheus — install"
  local dockerfile="$REPO_DIR/docker/prometheus/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    fail "Prometheus Dockerfile not found: $dockerfile"
    return 1
  fi
  compose_build --profile monitoring
  ok "Prometheus image built."
}

prometheus_configure() {
  step "Prometheus — configure"
  local config_file="$REPO_DIR/config/prometheus.yml"
  if [[ ! -f "$config_file" ]]; then
    warn "Prometheus config not found: $config_file"
    info "A default config will be needed before starting."
  else
    ok "Prometheus config: $config_file"
  fi
  info "HTTP port: ${PROMETHEUS_PORT}"
  ok "Prometheus configured."
}

prometheus_start() {
  step "Prometheus — start"
  compose_up --profile monitoring
  ok "Prometheus started on port ${PROMETHEUS_PORT}."
}

prometheus_stop() {
  step "Prometheus — stop"
  compose_down --profile monitoring
  ok "Prometheus stopped."
}

prometheus_health() {
  local label="Prometheus :${PROMETHEUS_PORT}"
  printf "  %-35s" "$label"
  if curl -sf "http://localhost:${PROMETHEUS_PORT}/-/ready" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${PROMETHEUS_PORT}/-/ready)"
    return 1
  fi
}

prometheus_restart() {
  prometheus_stop
  prometheus_start
}

prometheus_destroy() {
  step "Prometheus — destroy"
  compose_down --profile monitoring -v
  ok "Prometheus destroyed."
}

prometheus_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=prometheus" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Prometheus is running (port ${PROMETHEUS_PORT})"
  else
    warn "Prometheus is not running."
  fi
  prometheus_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   prometheus_install   ;;
    configure) prometheus_configure ;;
    start)     prometheus_start     ;;
    stop)      prometheus_stop      ;;
    restart)   prometheus_restart   ;;
    health)    prometheus_health    ;;
    status)    prometheus_status    ;;
    destroy)   prometheus_destroy   ;;
    default)
      prometheus_install
      prometheus_configure
      prometheus_start
      prometheus_health
      ;;
  esac
fi
