#!/usr/bin/env bash
# inspect-nemoclaw-tokens.sh
#
# Dumps every token / secret / auth / key / pair field in the live
# /sandbox/.openclaw/openclaw.json so we can identify which one the
# Control UI actually expects. Read-only.

set -euo pipefail

GATEWAY="${NEMOCLAW_GATEWAY_NAME:-nemoclaw}"
SANDBOX="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"

command -v openshell >/dev/null || { echo "openshell not in PATH" >&2; exit 2; }
command -v python3   >/dev/null || { echo "python3 not in PATH"   >&2; exit 2; }

TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT

if ! openshell sandbox download -g "$GATEWAY" "$SANDBOX" \
     /sandbox/.openclaw/openclaw.json "$TMP/" 2>&1; then
  echo "Could not download openclaw.json — is the sandbox running?" >&2
  exit 3
fi

python3 - "$TMP/openclaw.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))

print("=== token / secret / key / auth / pair fields (full path → value preview) ===")
def walk(o, path=''):
    if isinstance(o, dict):
        for k, v in o.items():
            p = f'{path}.{k}' if path else k
            if any(x in k.lower() for x in ('token','secret','key','auth','pair','credential')):
                if isinstance(v, str):
                    preview = v if len(v) <= 24 else v[:16] + '…'
                    print(f'  {p} = {preview!r}  (len={len(v)})')
                elif isinstance(v, dict):
                    print(f'  {p}: <dict, keys={list(v.keys())}>')
                    walk(v, p)
                elif isinstance(v, list):
                    print(f'  {p}: <list, len={len(v)}>')
                    walk(v, p)
                else:
                    print(f'  {p} = {v!r}')
            else:
                walk(v, p)
    elif isinstance(o, list):
        for i, x in enumerate(o):
            walk(x, f'{path}[{i}]')
walk(d)

print()
print("=== top-level structure ===")
print(f"  top-level   : {list(d.keys())}")
gw = d.get('gateway') or {}
print(f"  gateway     : {list(gw.keys())}")
cu = gw.get('controlUi') or {}
print(f"  controlUi   : {list(cu.keys())}")
au = gw.get('auth') or {}
print(f"  auth        : {list(au.keys())}")
de = gw.get('devices') or gw.get('pairing') or {}
print(f"  devices/pair: {list(de.keys()) if isinstance(de, dict) else type(de).__name__}")

print()
print("=== full openclaw.json ===")
print(json.dumps(d, indent=2))
PY
