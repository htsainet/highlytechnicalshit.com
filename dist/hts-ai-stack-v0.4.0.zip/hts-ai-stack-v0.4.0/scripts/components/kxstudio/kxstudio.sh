#!/usr/bin/env bash
# scripts/components/kxstudio/kxstudio.sh — KXStudio: install, configure, health
#
# Host-native installer for KXStudio audio tools via the KXStudio PPA.
# Installs Cadence (JACK management), Catia (JACK patchbay), and
# Carla (advanced plugin host with LV2/VST/LADSPA support).
#
# Standalone usage:
#   ./scripts/components/kxstudio/kxstudio.sh              # full: install + configure + health
#   ./scripts/components/kxstudio/kxstudio.sh --install    # install only (PPA + packages)
#   ./scripts/components/kxstudio/kxstudio.sh --configure  # configure only
#   ./scripts/components/kxstudio/kxstudio.sh --start      # no-op (host packages)
#   ./scripts/components/kxstudio/kxstudio.sh --stop       # no-op (host packages)
#   ./scripts/components/kxstudio/kxstudio.sh --restart    # no-op (host packages)
#   ./scripts/components/kxstudio/kxstudio.sh --health     # health check only
#   ./scripts/components/kxstudio/kxstudio.sh --status     # show status + health
#   ./scripts/components/kxstudio/kxstudio.sh --destroy    # uninstall packages + PPA
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native system package set, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

KXSTUDIO_REPO_DEB_URL="https://launchpad.net/~kxstudio-debian/+archive/ubuntu/kxstudio/+files/kxstudio-repos_11.1.0_all.deb"
KXSTUDIO_REPO_DEB="/tmp/kxstudio-repos.deb"

KXSTUDIO_PACKAGES=(
  cadence
  catia
  carla
)

# ── Functions ────────────────────────────────────────────────────────────────

kxstudio_install() {
  step "KXStudio — install"

  # Add KXStudio PPA if not present
  if dpkg -s kxstudio-repos &>/dev/null; then
    skip "KXStudio repositories already configured."
  else
    info "Adding KXStudio repositories..."
    wget -q --show-progress -O "$KXSTUDIO_REPO_DEB" "$KXSTUDIO_REPO_DEB_URL"
    sudo dpkg -i "$KXSTUDIO_REPO_DEB"
    sudo apt-get update -qq
    rm -f "$KXSTUDIO_REPO_DEB"
    ok "KXStudio repositories added."
  fi

  # Install packages
  local missing=()
  for pkg in "${KXSTUDIO_PACKAGES[@]}"; do
    if ! dpkg -s "$pkg" &>/dev/null; then
      missing+=("$pkg")
    fi
  done

  if [[ ${#missing[@]} -eq 0 ]]; then
    skip "All KXStudio packages already installed."
  else
    info "Installing: ${missing[*]}"
    sudo apt-get install -y -qq "${missing[@]}"
    ok "KXStudio packages installed."
  fi
}

kxstudio_configure() {
  step "KXStudio — configure"
  info "Cadence provides GUI-based JACK configuration."
  info "Launch Cadence from the desktop to configure audio routing."
  ok "KXStudio configured."
}

kxstudio_start() {
  step "KXStudio — start"
  info "Host packages — no service to start. Use Cadence to manage JACK."
  ok "KXStudio start complete."
}

kxstudio_stop() {
  step "KXStudio — stop"
  info "Host packages — no service to stop."
  ok "KXStudio stop complete."
}

kxstudio_health() {
  local label="KXStudio"
  printf "  %-35s" "$label"
  if command -v carla &>/dev/null && command -v cadence &>/dev/null; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (carla or cadence not found)"
    return 1
  fi
}

kxstudio_restart() {
  kxstudio_stop
  kxstudio_start
}

kxstudio_destroy() {
  step "KXStudio — destroy"
  info "Removing KXStudio packages..."
  sudo apt-get remove -y "${KXSTUDIO_PACKAGES[@]}" 2>/dev/null || true
  info "Removing KXStudio repositories..."
  sudo apt-get remove -y kxstudio-repos 2>/dev/null || true
  sudo apt-get autoremove -y -qq
  ok "KXStudio packages and repositories removed."
}

kxstudio_status() {
  step "KXStudio — status"
  for pkg in "${KXSTUDIO_PACKAGES[@]}"; do
    if dpkg -s "$pkg" &>/dev/null; then
      ok "$pkg installed"
    else
      warn "$pkg NOT installed"
    fi
  done
  kxstudio_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   kxstudio_install   ;;
    configure) kxstudio_configure ;;
    start)     kxstudio_start     ;;
    stop)      kxstudio_stop      ;;
    restart)   kxstudio_restart   ;;
    health)    kxstudio_health    ;;
    status)    kxstudio_status    ;;
    destroy)   kxstudio_destroy   ;;
    default)
      kxstudio_install
      kxstudio_configure
      kxstudio_health
      ;;
  esac
fi
