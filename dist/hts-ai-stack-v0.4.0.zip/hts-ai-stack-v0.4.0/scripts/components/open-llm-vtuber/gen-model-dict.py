#!/usr/bin/env python3
"""Generate a complete model_dict.json for Open-LLM-VTuber.

Upstream's model_dict.json registers a single model (mao_pro). Any
live2d_model_name not listed there causes init_live2d to fail and the agent
init path to crash on `NoneType.emo_str`, putting the container in a restart
loop.

This helper scans live2d-models/ on the host, locates each model's
*.model3.json (top-level or under runtime/), and writes a merged
model_dict.json that registers every avatar dir found. Known upstream
entries are preserved verbatim via OVERRIDES; unknown community models
get conservative defaults that satisfy live2d_model.set_model() (i.e., a
non-empty entry with at minimum `name` and `emotionMap`).

Usage:
    gen_model_dict.py <live2d_models_dir> <output_json>

Exit codes:
    0 on success (file written)
    1 if the input directory does not exist or no models were found
"""
from __future__ import annotations

import json
import sys
from pathlib import Path


# Canonical upstream entries — keep these byte-for-byte so the curated
# defaults (kScale, emotionMap, tapMotions) continue to apply.
OVERRIDES: dict[str, dict] = {
    "mao_pro": {
        "name": "mao_pro",
        "description": "",
        "url": "/live2d-models/mao_pro/runtime/mao_pro.model3.json",
        "kScale": 0.5,
        "initialXshift": 0,
        "initialYshift": 0,
        "kXOffset": 1150,
        "idleMotionGroupName": "Idle",
        "emotionMap": {
            "neutral": 0,
            "anger": 2,
            "disgust": 2,
            "fear": 1,
            "joy": 3,
            "smirk": 3,
            "sadness": 1,
            "surprise": 3,
        },
        "tapMotions": {
            "HitAreaHead": {"": 1},
            "HitAreaBody": {"": 1},
        },
    },
}


def find_model3_json(model_dir: Path) -> Path | None:
    """Return the best *.model3.json under model_dir.

    Some community packs ship multiple model3.json files in the same
    directory (e.g. live2d-models/mao_pro/runtime/ contains both
    mao_pro.model3.json and hijiki.model3.json). Prefer one whose stem
    matches the parent directory's name; otherwise fall back to the
    first match alphabetically.
    """
    def _best(matches: list[Path]) -> Path | None:
        if not matches:
            return None
        target = model_dir.name.lower()
        for m in matches:
            # Strip .model3 from the stem (Path.stem only strips .json)
            stem = m.stem
            if stem.endswith(".model3"):
                stem = stem[: -len(".model3")]
            if stem.lower() == target:
                return m
        return sorted(matches)[0]

    top = list(model_dir.glob("*.model3.json"))
    if top:
        return _best(top)
    runtime = model_dir / "runtime"
    if runtime.is_dir():
        return _best(list(runtime.glob("*.model3.json")))
    return None


def default_entry(name: str, model3_rel_url: str) -> dict:
    """Conservative defaults for community models with no curated metadata."""
    return {
        "name": name,
        "description": f"Auto-generated entry for {name}",
        "url": model3_rel_url,
        "kScale": 0.5,
        "initialXshift": 0,
        "initialYshift": 0,
        "idleMotionGroupName": "Idle",
        # Minimum non-empty emotionMap so emo_str is non-empty and the
        # agent's prompt template still renders. Index 0 is the default
        # (no expression change) which is safe for any model.
        "emotionMap": {"neutral": 0},
        "tapMotions": {},
    }


def build_model_dict(models_root: Path) -> list[dict]:
    entries: list[dict] = []
    for child in sorted(models_root.iterdir()):
        if not child.is_dir():
            continue
        name = child.name
        model3 = find_model3_json(child)
        if model3 is None:
            # Skip dirs that aren't actually Live2D models (e.g. images,
            # cache, scratch dirs). Reported on stderr for visibility.
            print(f"[skip] {name}: no *.model3.json found", file=sys.stderr)
            continue
        rel = model3.relative_to(models_root)
        url = f"/live2d-models/{rel.as_posix()}"
        if name in OVERRIDES:
            entry = dict(OVERRIDES[name])
            # Always use the URL we discovered on disk in case the layout
            # differs from upstream's expected path.
            entry["url"] = url
        else:
            entry = default_entry(name, url)
        entries.append(entry)
    return entries


def main() -> int:
    if len(sys.argv) != 3:
        print(f"usage: {sys.argv[0]} <live2d_models_dir> <output_json>", file=sys.stderr)
        return 2
    models_root = Path(sys.argv[1])
    out_path = Path(sys.argv[2])
    if not models_root.is_dir():
        print(f"[error] live2d-models dir not found: {models_root}", file=sys.stderr)
        return 1
    entries = build_model_dict(models_root)
    if not entries:
        print(f"[error] no usable Live2D models found under {models_root}", file=sys.stderr)
        return 1
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(entries, indent=2) + "\n", encoding="utf-8")
    print(
        f"[ok] wrote {out_path} with {len(entries)} entries: "
        + ", ".join(e["name"] for e in entries)
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
