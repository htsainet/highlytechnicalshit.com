$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/animatediff'
    $script:ComponentScript = Join-Path $script:ComponentDir 'animatediff.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'animatediff.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'animatediff file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }

    It 'CONTEXT.md exists' {
        Join-Path $script:ComponentDir 'CONTEXT.md' | Should -Exist
    }

    It 'REFERENCES.md exists' {
        Join-Path $script:ComponentDir 'REFERENCES.md' | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'animatediff manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is animatediff' {
        $script:Manifest.id | Should -Be 'animatediff'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/animatediff/animatediff.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is animatediff' {
        $script:Manifest.func_prefix | Should -Be 'animatediff'
    }

    It 'dashboard port is 8603' {
        [int]$script:Manifest.dashboard.port | Should -Be 8603
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'animatediff component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines animatediff_install function' {
        $script:ComponentContent | Should -Match 'animatediff_install\s*\(\)'
    }

    It 'defines animatediff_configure function' {
        $script:ComponentContent | Should -Match 'animatediff_configure\s*\(\)'
    }

    It 'defines animatediff_start function' {
        $script:ComponentContent | Should -Match 'animatediff_start\s*\(\)'
    }

    It 'defines animatediff_stop function' {
        $script:ComponentContent | Should -Match 'animatediff_stop\s*\(\)'
    }

    It 'defines animatediff_health function' {
        $script:ComponentContent | Should -Match 'animatediff_health\s*\(\)'
    }

    It 'defines animatediff_restart function' {
        $script:ComponentContent | Should -Match 'animatediff_restart\s*\(\)'
    }

    It 'defines animatediff_destroy function' {
        $script:ComponentContent | Should -Match 'animatediff_destroy\s*\(\)'
    }

    It 'defines animatediff_status function' {
        $script:ComponentContent | Should -Match 'animatediff_status\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/animatediff/animatediff\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'animatediff port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8603 is registered in portmap.json' {
        $script:Portmap.ports.'8603' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'8603'.service | Should -Be 'animatediff'
    }
}

# ── Docker file existence ────────────────────────────────────────────────────

Describe 'animatediff Docker artifacts' {

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/animatediff/Dockerfile' | Should -Exist
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'animatediff no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/animatediff\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/animatediff/animatediff\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
