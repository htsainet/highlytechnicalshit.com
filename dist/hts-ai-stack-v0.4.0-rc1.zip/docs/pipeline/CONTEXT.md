# pipeline/

Step-by-step installation pipeline documentation. Each file mirrors a phase in the bootstrap→install sequence.

Last updated: 2026-03-31 19:10:14

## Purpose

This workspace documents each installation phase with detailed instructions, configuration options, and troubleshooting steps. Each guide maps to corresponding scripts in `/scripts/install/` for reference during setup.

## Files

| File | What it covers |
|------|---------------|
| [00-bootstrap.md](00-bootstrap.md) | Entry point: prerequisites, repo clone, driver installation |
| [01-autoinstall.md](01-autoinstall.md) | System auto-install and pre-configuration |
| [02-setup-docker.md](02-setup-docker.md) | Docker + NVIDIA Container Toolkit installation |
| [03-setup-models.md](03-setup-models.md) | Ollama model download and configuration |
| [04-setup-nemoclaw.md](04-setup-nemoclaw.md) | NemoClaw sandbox setup |
| [06-start-stack.md](06-start-stack.md) | Start all services |
| [06-stop-test-instances.md](06-stop-test-instances.md) | Stop test instances |
| [07-setup-connectivity.md](07-setup-connectivity.md) | Tailscale and networking configuration |

## How to use

Read sequentially following the numbers (00, 01, 02, etc.). Each document mirrors the corresponding install step in `/scripts/install/`.

## Standards

- Guides include prerequisites, step-by-step instructions, expected output, and troubleshooting
- Each guide maps clearly to corresponding shell script in `/scripts/install/`
- Numbered sequentially to match install phases
- Include warnings for destructive steps or reboot requirements
- Document expected service ports and health check methods

## Tools and skills

- **Ubuntu 24.04 LTS** — Target operating system
- **Docker** — Container orchestration documentation
- **NVIDIA drivers** — GPU setup instructions
- **NVIDIA Container Toolkit** — GPU container support
- **Ollama** — LLM engine setup
- **Tailscale** — Network connectivity configuration
- **OpenShell/NemoClaw** — Sandbox policy setup
