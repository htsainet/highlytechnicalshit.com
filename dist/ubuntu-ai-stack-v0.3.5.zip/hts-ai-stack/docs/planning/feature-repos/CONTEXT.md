# Feature Repos

Last updated: 2026-03-31 19:10:05

## What this folder is

GitHub repositories for non-security features: agents, memory, alternative platforms, UI, personas, character cards, integrations, skills, and other ecosystem tools.
Master project context lives in [`/CONTEXT.md`](/CONTEXT.md).

## What good looks like

- Each reviewed repo gets an `owner-reponame.md` summary artifact (e.g. `NousResearch-hermes-agent.md`)
- Summaries include: what it does, self-hosting fit, integration effort, verdict, risks
- `REFERENCES.md` is the tracking table — link the Details column to artifacts as they are produced

## Review workflow

1. Repos are listed in `REFERENCES.md` with current review status
2. Use `gh` CLI to fetch metadata: `gh repo view OWNER/REPO --json name,description,pushedAt,stargazerCount,licenseInfo,isArchived,primaryLanguage,isEmpty`
3. Deep review produces a per-repo artifact in this folder
4. Update the Details column in `REFERENCES.md` to link to the artifact

## Tools and skills

- **gh CLI** — GitHub repo metadata, README, stats, language detection
- **Claude Haiku/Sonnet/Opus** — Multi-pass feature repo review
- **Docker knowledge** — Self-hosting and containerization assessment
- **Integration patterns** — API/SDK/skill integration evaluation
- **LLM/AI knowledge** — Model compatibility and capabilities
- **Performance testing** — Benchmarking and resource assessment
- **License analysis** — Open source compatibility

## Naming convention

```text
owner-reponame.md
```

Example: `NousResearch-hermes-agent.md`

## Categories tracked here

`nvidia` · `microsoft` · `reference` · `openclaw-ecosystem` · `ring-central` · `memory` · `skills` · `agents` · `use-cases` · `alternative-platforms` · `ui-helpers` · `character-cards` · `lorebooks` · `personas` · `mobile` · `sillytavern` · `integration` · `misc` · `unclassified`

> Security repos live in [`../security-repos/`](../security-repos/) instead.

## Verdict rubric

- **ADOPT** — install or integrate into our stack
- **REFERENCE** — useful information, not installed
- **WATCH** — promising, needs more evaluation
- **SKIP** — not relevant or not trustworthy

## What to avoid

- Don't adopt cloud-only tools — our stack is self-hosted
- Don't adopt anything with unclear licensing without flagging it
- Don't review misc/unclassified repos before higher-priority categories
