#!/usr/bin/env bash
# scripts/lib/common.sh — Shared colors, logging, and environment helpers
# Source this file; do NOT run directly.

# ── Colors ────────────────────────────────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

# ── Repo root detection ──────────────────────────────────────────────────────
# Callers may override REPO_DIR before sourcing; otherwise auto-detect.
if [[ -z "${REPO_DIR:-}" ]]; then
  REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

# ── Logging ───────────────────────────────────────────────────────────────────
# LOG_FILE can be set by the caller before or after sourcing this file.
_log() {
  local level="$1"; shift
  echo "[$(date '+%F %T')] [$level] $*" >> "${LOG_FILE:-/dev/null}" 2>/dev/null || true
}

info()   { echo -e "${GREEN}[INFO]${NC} $*"; _log INFO "$*"; }
warn()   { echo -e "${YELLOW}[WARN]${NC} $*"; _log WARN "$*"; }
fail()   { echo -e "${RED}[FAIL]${NC} $*"; [[ -n "${LOG_FILE:-}" ]] && echo -e "${RED}[FAIL]${NC} See log: $LOG_FILE"; _log FAIL "$*"; exit 1; }
step()   { echo -e "\n${CYAN}${BOLD}══ $* ══${NC}"; _log STEP "══ $* ══"; }
ok()     { echo -e "${GREEN}[OK]${NC} $*"; _log OK "$*"; }
skip()   { echo -e "${CYAN}[SKIP]${NC} $*"; _log SKIP "$*"; }

banner() {
  echo -e "\n${CYAN}${BOLD}╔══════════════════════════════════════════════════════╗${NC}"
  echo -e "${CYAN}${BOLD}║        AI STACK — INSTALLER                          ║${NC}"
  echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════╝${NC}\n"
  _log INFO "=== AI STACK INSTALLER STARTED ==="
}

# ── Interactive prompt helpers ────────────────────────────────────────────────

# prompt_yesno <title> <message> [--default-yes]
# Shows a whiptail yes/no dialog. Returns 0 (Yes) or 1 (No/Cancel).
prompt_yesno() {
  local title="$1"
  local message="$2"
  local default_yes="${3:-}"
  local extra_args=()
  [[ "$default_yes" == "--default-yes" ]] && extra_args+=("--defaultno" )
  whiptail --title "$title" --yesno "$message" 10 60 "${extra_args[@]}" 3>&1 1>&2 2>&3
}

# prompt_checklist <title> <message> <nameref_in> <nameref_out>
# Shows a whiptail checklist. Items passed as an array of "tag|desc|on|off".
# <nameref_in>  — name of array variable: each element "tag|description|on" or "tag|description|off"
# <nameref_out> — name of array variable to receive selected tags
#
# Example:
#   items=("foo|Do the foo thing|on" "bar|Do the bar thing|off")
#   prompt_checklist "Pick actions" "Space to toggle, Enter to confirm" items selected
#   for tag in "${selected[@]}"; do echo "$tag"; done
prompt_checklist() {
  local title="$1"
  local message="$2"
  local -n _pc_items="$3"
  local -n _pc_out="$4"

  local args=()
  for entry in "${_pc_items[@]}"; do
    local tag="${entry%%|*}"; local rest="${entry#*|}"
    local desc="${rest%%|*}"; local state="${rest##*|}"
    args+=("$tag" "$desc" "$state")
  done

  local raw
  raw=$(whiptail \
    --title "$title" \
    --checklist "$message" \
    20 78 "${#_pc_items[@]}" \
    "${args[@]}" \
    3>&1 1>&2 2>&3) || { _pc_out=(); return 1; }

  # Parse whiptail output: space-separated double-quoted tokens
  _pc_out=()
  for token in $raw; do
    _pc_out+=("${token//\"/}")
  done
}

# ── Environment loader ────────────────────────────────────────────────────────
load_env() {
  local env_file="${1:-$REPO_DIR/.env}"
  if [[ -f "$env_file" ]]; then
    set -a
    # shellcheck source=/dev/null
    source "$env_file"
    set +a
  fi
}
