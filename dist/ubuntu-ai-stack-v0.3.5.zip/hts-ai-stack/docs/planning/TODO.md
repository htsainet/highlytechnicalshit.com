# TODO

## Just added

- [ ] we have discovered that nemoclaw installs its own openclaw instance so we don't need to deploy our own instance.  That said, we should review anything we have scripted to happen to the docker instance we have, so we can determine how much of that should be applied to EVERY nemoclaw instance and how much should be instance level additions

## In Progress

- [x] New tool scripts: install-copilot-cli.sh, install-comfyui.sh, install-lmstudio.sh (rewrite), install-lmlink.sh
- [x] VS Code extensions auto-install in 00-bootstrap.sh (Step 4a)
- [x] ComfyUI added to instance composes (prod:8188 / test:8189) and dashboard
- [x] Script restructure: move 05-setup-civitai.sh → scripts/install/tooling/, simplify 02-setup-docker.sh

## Tooling / Services

- [ ] n8n — workflow automation; Docker service in root compose, port 5678, volume n8n_data

## Observability

- [ ] OpenTelemetry — traces/metrics/logs across services; consider when Jenkins pipelines mature

## Distribution

- [ ] Public mirror repo (hts-ai-stack-public) — GitHub Actions mirrors sanitized milestone releases from private → public
- [ ] Define milestone criteria for public releases

## Website

- [ ] GitHub Pages landing page (free hosting, public repo)
- [ ] Cloudflare CNAME → username.github.io for custom domain
- [ ] Pick domain name

## References / Inspiration

- [ ] goat-agent (https://github.com/CrankingAI/goat-agent) — C# AI agent pattern demo from Boston Code Camp; review for agent design patterns

## Alternate LLM hosting methods

- [ ] vllm
- [ ] llama.cpp
