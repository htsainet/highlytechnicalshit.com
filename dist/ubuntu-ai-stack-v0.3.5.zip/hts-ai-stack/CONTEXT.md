# Current Project

Last updated: 2026-03-31 19:10:46

## What we are building

We are building a reproducible installation procedure for a customizable, Linux AI stack utilizing a locally hosted LLM to act as an AI Agent.  

Org Private Repo : https://github.com/htsainet/hts-ai-stack
Org Public Repo: https://github.com/htsainet/highlytechnicalshit.com

[Core Services]
OpenClaw: https://openclaw.ai/
NemoClaw: https://www.nvidia.com/en-us/ai/nemoclaw/
OpenShell: https://docs.nvidia.com/openshell/latest/index.html
Ollama: https://ollama.com/

## What good looks like

User can securely run and manage a local clawbot instance without having to install everything manually.

## What to avoid

Avoid using cloud based LLMs within the app so spend can be controlled.

## Tools and dependencies

- **Ubuntu 24.04 LTS** — Target Linux distribution
- **Docker** — Container orchestration
- **NVIDIA CUDA** — GPU acceleration
- **Ollama** — Local LLM inference
- **NemoClaw** — Sandbox security enforcement
- **OpenClaw** — AI agent runtime
- **Claude Code** — Documentation and script generation
- **Pester** — Configuration and integration testing
