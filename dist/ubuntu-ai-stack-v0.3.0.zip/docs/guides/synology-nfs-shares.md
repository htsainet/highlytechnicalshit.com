# Synology NFS Shares — Setup Guide

This guide covers the one-time setup you need to do on your Synology NAS
before the AI stack installer can detect and mount its shares.

---

## 1. Required Shared Folders

Create these three shared folders in DSM **before** running the installer:

| Folder name                    | Purpose                          |
|-------------------------------|----------------------------------|
| `htsai-model-backup`          | AI model cache (shared models)   |
| `htsai-docker-volume-backup`  | Docker volume snapshot backups   |
| `htsai-timeshift-backup`      | Timeshift system snapshots       |

**Synology DSM:** File Station → left panel → right-click → Create Shared Folder

---

## 2. Enable NFSv4.1

In DSM: Control Panel → File Services → NFS

- Enable NFS service: ✓
- Maximum NFS protocol: `NFSv4.1`
- Click **Advanced Settings**:
  - NFSv4/4.1 domain: `htsai`
  - Read/Write packet size: `32 KB` (the UI maximum; the Linux client uses 1 MB independently)

---

## 3. Add NFS Permissions to Each Share

For each of the three folders above, go to:
Control Panel → Shared Folders → select folder → Edit → NFS Permissions → Create

| Setting                        | Value                               |
|-------------------------------|-------------------------------------|
| Hostname / IP                  | `<this machine's LAN IP>`           |
| Privilege                      | `Read/Write`                        |
| Squash                         | `No mapping`                        |
| Security                       | `sys`                               |
| Enable asynchronous            | ✓                                   |
| Allow connections from non-privileged ports | ✓                  |

Tip: Find this machine's LAN IP with:

```bash
ip route get 1.1.1.1 | awk '/src/{print $7}'
```

---

## 4. DHCP Reservation (Important)

The Synology NFS allowlist is **IP-specific** — if this machine's IP changes
(e.g. after a nuke-and-pave reinstall), access will be denied.

**Set a DHCP reservation on your router** so this machine always gets the same IP.

- Find the MAC: `ip link show | grep ether`
- Set the reservation to match the IP you used in step 3

---

## 5. Test from This Machine

Once the shares are configured, verify they are visible:

```bash
showmount -e <NAS_IP>
```

Expected output (paths may include `/volume1/` prefix on DSM 7):

```text
/volume1/htsai-timeshift-backup      <this-IP>
/volume1/htsai-docker-volume-backup  <this-IP>
/volume1/htsai-model-backup          <this-IP>
```

If `showmount` hangs or returns nothing:

- Confirm NFS is enabled in DSM
- Confirm the IP in the NFS permission rule matches exactly
- Check Synology firewall rules (Control Panel → Security → Firewall)

---

## 6. Recovery After Reinstall

If you reinstall this machine (same IP via DHCP reservation):

```bash
git clone <repo-url>
cd ubuntu-ai-stack
./install.sh --skip-config   # uses saved config/stack.json, skips the setup menu
```

The NFS mounts will be restored from the saved fstab entries in `apply_config.sh`.
