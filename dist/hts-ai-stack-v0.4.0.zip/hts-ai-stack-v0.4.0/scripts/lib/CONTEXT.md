# Shared Function Libraries

Last updated: 2026-04-16 12:00:00

## What happens here

This workspace contains shared bash function libraries that are **sourced** (not executed) by component and bundle scripts. Every script in the stack that needs logging, compose wrappers, health checks, or token management sources these files.

## Process / Workflow

1. Component or bundle script sources `lib/common.sh` first (always required)
2. Additional libraries sourced as needed (`compose.sh`, `health.sh`, `tokens.sh`)
3. Libraries provide functions — they never run standalone

## Files and structure

| File | Purpose |
|------|---------|
| `common.sh` | Colors, logging (`info`, `ok`, `warn`, `fail`, `step`, `banner`), `REPO_DIR` detection, `load_env`, config helpers |
| `assert-postcondition.sh` | `assert_postcondition <label> <check>` — verifies an invariant actually holds after an external CLI reports success. Exits 2 with captured stderr tail on failure. See [`/CONTEXT.md` § Postcondition verification](../../CONTEXT.md#postcondition-verification). |
| `compose.sh` | Docker Compose wrappers (`compose_up`, `compose_down`, `compose_pull`, `compose_build`) with profile support |
| `health.sh` | Unified health probes (`health_probe <label> <url>`) with retry and timeout |
| `tokens.sh` | Crypto-random token generation (`generate_token`) and `.env` key management (`ensure_env_key`) |
| `manifest-loader.sh` | Loads `*.manifest.json` files into `COMPONENT_*` associative arrays; `_derive_config_key()` converts manifest config blocks into state-desired.sh format |
| `manifest.sh` | Legacy manifest helpers (component metadata lookup) |
| `component-registry.sh` | Component registry — maps component IDs to script paths and config keys |
| `state-desired.sh` | Parses `stack.json` into `DESIRED[]` associative array using manifest config types (`always`, `enum`, `boolean`, `array_member`) |
| `state-actual.sh` | Probes runtime state (Docker containers, host processes) into `ACTUAL[]` associative array |
| `converge-diff.sh` | Compares `DESIRED[]` vs `ACTUAL[]` and produces ordered action plans (start/stop/health-check) |
| `installstatus.sh` | Install progress tracking — writes `install-status.json` for dashboard progress display |
| `menu-handler.sh` | Whiptail/dialog menu helpers for interactive component configuration |
| `teardown.sh` | Stack teardown helpers (stop all containers, remove volumes) |

## What good looks like

- Every file has `# Source this file; do NOT run directly` header comment
- Functions are pure helpers — no side effects on source
- `common.sh` always sourced first (others depend on it)
- No duplicate logic — if two components need the same thing, it belongs here
- All `.sh` files have `#!/usr/bin/env bash` shebang

## Tools and skills

- **Bash** — All libraries are POSIX-compatible bash
- **Docker Compose** — `compose.sh` wraps the `docker compose` CLI
- **OpenSSL** — `tokens.sh` uses `openssl rand` for cryptographic tokens
