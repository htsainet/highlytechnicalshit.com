#!/usr/bin/env bash
# sync-llama-swap-models.sh — make config/llama-swap.yaml reflect the models
# that are actually loaded in the running ollama and bitnet containers.
#
# This is the inverse of pull-llama-swap-models.sh:
#   pull-llama-swap-models.sh:  config → runtime  (pull what config says)
#   sync-llama-swap-models.sh:  runtime → config  (declare what runtime has)
#
# Use this after manually `ollama pull`-ing a model on the host, or after
# bitnet has loaded a different GGUF, when you want llama-swap's routing
# table to match reality without hand-editing YAML.
#
# Usage:
#   ./scripts/utils/sync-llama-swap-models.sh                # sync + restart
#   ./scripts/utils/sync-llama-swap-models.sh --dry-run      # show diff only
#   ./scripts/utils/sync-llama-swap-models.sh --no-restart   # write, skip reload
#   ./scripts/utils/sync-llama-swap-models.sh --peer ollama  # one peer only
#   ./scripts/utils/sync-llama-swap-models.sh --peer bitnet
#   ./scripts/utils/sync-llama-swap-models.sh --peer koboldcpp
#
# Exit codes:
#   0  success (or --dry-run completed; or no changes)
#   1  argument / environment error
#   2  could not reach ollama or bitnet
#   3  failed to write or reload config
#
# Notes:
#   * Inline `#` comments inside the per-peer `models:` list are NOT
#     preserved — the live runtime becomes the source of truth.
#   * Header comments, peer ordering, and the commented-out lmstudio
#     stanza ARE preserved (only the `models:` block is rewritten).
#   * A timestamped backup is written to config/backups/ before any change.

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
CONFIG="${REPO_DIR}/config/llama-swap.yaml"
COMPOSE="${REPO_DIR}/docker-compose.yml"
BACKUP_DIR="${REPO_DIR}/config/backups"

PEER_FILTER=""        # empty = both
DRY_RUN=false
DO_RESTART=true

OLLAMA_PORT="${OLLAMA_PORT:-11434}"
OLLAMA_BASE_URL="${OLLAMA_BASE_URL:-http://localhost:${OLLAMA_PORT}}"
BITNET_PORT="${BITNET_PORT:-8080}"
KOBOLDCPP_PORT="${KOBOLDCPP_PORT:-5001}"

say()  { printf '\n\033[1;36m[sync-models]\033[0m %s\n' "$*"; }
info() { printf '  %s\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n' "$*"; }
fail() { printf '\033[1;31m[FAIL]\033[0m %s\n' "$*" >&2; exit "${2:-1}"; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --peer)       PEER_FILTER="${2:?--peer needs a value}"; shift 2 ;;
    --dry-run)    DRY_RUN=true;     shift ;;
    --no-restart) DO_RESTART=false; shift ;;
    -h|--help)    grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) fail "Unknown argument: $1" ;;
  esac
done

[[ -f "$CONFIG"  ]] || fail "config not found: $CONFIG"
[[ -f "$COMPOSE" ]] || fail "docker-compose.yml not found: $COMPOSE"

case "$PEER_FILTER" in
  ""|ollama|bitnet|koboldcpp) : ;;
  *) fail "--peer must be one of: ollama, bitnet, koboldcpp (got: $PEER_FILTER)" ;;
esac

# ── Discovery ────────────────────────────────────────────────────────────────

# discover_ollama — print one model name per line, sorted, deduped.
# Tries the host port first; falls back to `docker compose exec ollama`.
discover_ollama() {
  local json=""
  if json=$(curl -fsS --max-time 5 "${OLLAMA_BASE_URL}/api/tags" 2>/dev/null); then
    :
  elif json=$(docker compose -f "$COMPOSE" exec -T ollama \
              curl -fsS --max-time 5 "http://localhost:${OLLAMA_PORT}/api/tags" 2>/dev/null); then
    :
  else
    return 1
  fi
  printf '%s' "$json" | python3 -c '
import json, sys
try:
    doc = json.load(sys.stdin)
except Exception:
    sys.exit(1)
names = sorted({m.get("name","").strip() for m in doc.get("models",[]) if m.get("name")})
for n in names:
    if n:
        print(n)
'
}

# discover_bitnet — bitnet has no host port binding; query via exec.
discover_bitnet() {
  local json=""
  if ! json=$(docker compose -f "$COMPOSE" exec -T bitnet \
              curl -fsS --max-time 5 "http://localhost:${BITNET_PORT}/v1/models" 2>/dev/null); then
    return 1
  fi
  printf '%s' "$json" | python3 -c '
import json, sys
try:
    doc = json.load(sys.stdin)
except Exception:
    sys.exit(1)
names = sorted({(m.get("id") or "").strip() for m in doc.get("data",[])})
for n in names:
    if n:
        print(n)
'
}

# discover_koboldcpp — KoboldCpp serves one model per process; its OpenAI
# /v1/models endpoint lists exactly that model. Try host port first (it is
# bound by default), then fall back to docker exec for parity with bitnet.
discover_koboldcpp() {
  local json=""
  if json=$(curl -fsS --max-time 5 "http://localhost:${KOBOLDCPP_PORT}/v1/models" 2>/dev/null); then
    :
  elif json=$(docker compose -f "$COMPOSE" exec -T koboldcpp \
              curl -fsS --max-time 5 "http://localhost:${KOBOLDCPP_PORT}/v1/models" 2>/dev/null); then
    :
  else
    return 1
  fi
  printf '%s' "$json" | python3 -c '
import json, sys
try:
    doc = json.load(sys.stdin)
except Exception:
    sys.exit(1)
names = sorted({(m.get("id") or "").strip() for m in doc.get("data",[])})
for n in names:
    if n:
        print(n)
'
}

# ── Gather model lists ───────────────────────────────────────────────────────

declare -a OLLAMA_MODELS=() BITNET_MODELS=() KOBOLDCPP_MODELS=()

# SYNC_OLLAMA / SYNC_BITNET / SYNC_KOBOLDCPP track whether the rewriter should
# touch each peer. Discovery failures and empty results both leave the peer's
# existing list alone (better to keep a stale entry than to wipe the routing
# table).
SYNC_OLLAMA=false
SYNC_BITNET=false
SYNC_KOBOLDCPP=false

if [[ -z "$PEER_FILTER" || "$PEER_FILTER" == "ollama" ]]; then
  say "Discovering Ollama models"
  if mapfile -t OLLAMA_MODELS < <(discover_ollama) && [[ "${#OLLAMA_MODELS[@]}" -gt 0 ]]; then
    info "Found ${#OLLAMA_MODELS[@]} model(s)"
    for m in "${OLLAMA_MODELS[@]}"; do info "• $m"; done
    SYNC_OLLAMA=true
  else
    warn "Ollama returned no models (or unreachable at ${OLLAMA_BASE_URL}/api/tags) — leaving its peer list unchanged"
    OLLAMA_MODELS=()
    if [[ "$PEER_FILTER" == "ollama" ]]; then
      fail "Ollama discovery failed or empty — refusing to overwrite with []" 2
    fi
  fi
fi

if [[ -z "$PEER_FILTER" || "$PEER_FILTER" == "bitnet" ]]; then
  say "Discovering BitNet models"
  if mapfile -t BITNET_MODELS < <(discover_bitnet) && [[ "${#BITNET_MODELS[@]}" -gt 0 ]]; then
    info "Found ${#BITNET_MODELS[@]} model(s)"
    for m in "${BITNET_MODELS[@]}"; do info "• $m"; done
    SYNC_BITNET=true
  else
    warn "BitNet returned no models (or unreachable) — leaving its peer list unchanged"
    BITNET_MODELS=()
    if [[ "$PEER_FILTER" == "bitnet" ]]; then
      fail "BitNet discovery failed or empty — refusing to overwrite with []" 2
    fi
  fi
fi

if [[ -z "$PEER_FILTER" || "$PEER_FILTER" == "koboldcpp" ]]; then
  say "Discovering KoboldCpp models"
  if mapfile -t KOBOLDCPP_MODELS < <(discover_koboldcpp) && [[ "${#KOBOLDCPP_MODELS[@]}" -gt 0 ]]; then
    info "Found ${#KOBOLDCPP_MODELS[@]} model(s)"
    for m in "${KOBOLDCPP_MODELS[@]}"; do info "• $m"; done
    SYNC_KOBOLDCPP=true
  else
    warn "KoboldCpp returned no models (or unreachable, or profile not enabled) — leaving its peer list unchanged"
    KOBOLDCPP_MODELS=()
    if [[ "$PEER_FILTER" == "koboldcpp" ]]; then
      fail "KoboldCpp discovery failed or empty — is the koboldcpp profile up?" 2
    fi
  fi
fi

if [[ "$SYNC_OLLAMA" != "true" && "$SYNC_BITNET" != "true" && "$SYNC_KOBOLDCPP" != "true" ]]; then
  fail "No peers had usable model lists — nothing to sync." 2
fi

# ── Rewrite YAML (Python; preserves everything except the targeted lists) ───

NEW_CONFIG=$(
  PEER_FILTER="$PEER_FILTER" \
  SYNC_OLLAMA="$SYNC_OLLAMA" \
  SYNC_BITNET="$SYNC_BITNET" \
  SYNC_KOBOLDCPP="$SYNC_KOBOLDCPP" \
  OLLAMA_MODELS_JSON="$(printf '%s\n' "${OLLAMA_MODELS[@]:-}" \
    | python3 -c 'import sys,json; print(json.dumps([l for l in sys.stdin.read().splitlines() if l]))')" \
  BITNET_MODELS_JSON="$(printf '%s\n' "${BITNET_MODELS[@]:-}" \
    | python3 -c 'import sys,json; print(json.dumps([l for l in sys.stdin.read().splitlines() if l]))')" \
  KOBOLDCPP_MODELS_JSON="$(printf '%s\n' "${KOBOLDCPP_MODELS[@]:-}" \
    | python3 -c 'import sys,json; print(json.dumps([l for l in sys.stdin.read().splitlines() if l]))')" \
  python3 - "$CONFIG" <<'PY'
import json, os, re, sys

path = sys.argv[1]
peer_filter = os.environ.get("PEER_FILTER", "")
sync_flags = {
    "ollama":    os.environ.get("SYNC_OLLAMA")    == "true",
    "bitnet":    os.environ.get("SYNC_BITNET")    == "true",
    "koboldcpp": os.environ.get("SYNC_KOBOLDCPP") == "true",
}
new_models = {
    "ollama":    json.loads(os.environ.get("OLLAMA_MODELS_JSON")    or "[]"),
    "bitnet":    json.loads(os.environ.get("BITNET_MODELS_JSON")    or "[]"),
    "koboldcpp": json.loads(os.environ.get("KOBOLDCPP_MODELS_JSON") or "[]"),
}

with open(path) as fh:
    lines = fh.readlines()

# Locate `peers:` block, then iterate peer entries.
out = []
i = 0
n = len(lines)
in_peers = False
peers_indent = None

def peer_header(line):
    # match "  <name>:" at exactly 2-space indent inside peers block
    m = re.match(r"^(  )([A-Za-z0-9_-]+):\s*(#.*)?$", line)
    return m.group(2) if m else None

while i < n:
    line = lines[i]
    if not in_peers:
        out.append(line)
        if re.match(r"^peers:\s*(#.*)?$", line):
            in_peers = True
        i += 1
        continue

    # We are inside the peers: block.
    # End of peers block = a non-blank, non-comment line at column 0.
    if line.strip() and not line.startswith(" ") and not line.lstrip().startswith("#"):
        in_peers = False
        out.append(line)
        i += 1
        continue

    peer = peer_header(line)
    if peer is None:
        out.append(line)
        i += 1
        continue

    # Found a peer header. Walk its body until the next peer header or end of peers.
    out.append(line)
    j = i + 1
    models_start = models_end = None
    while j < n:
        bl = lines[j]
        # next peer header?
        if peer_header(bl) is not None:
            break
        # end of peers block?
        if bl.strip() and not bl.startswith(" ") and not bl.lstrip().startswith("#"):
            break
        # locate `    models:` at 4-space indent
        if models_start is None and re.match(r"^    models:\s*(#.*)?$", bl):
            models_start = j
            k = j + 1
            # consume list items + blank/comment lines that are clearly part of the list
            while k < n:
                kl = lines[k]
                if re.match(r"^      [-#]", kl):    # list item or list-level comment
                    k += 1; continue
                if kl.strip() == "":                # blank line — assume still in list
                    k += 1; continue
                break
            models_end = k
            break
        j += 1

    should_rewrite = (
        peer in new_models
        and sync_flags.get(peer, False)
        and (not peer_filter or peer_filter == peer)
    )

    if models_start is not None and should_rewrite:
        # Emit everything between header and models: as-is
        out.extend(lines[i+1:models_start])
        out.append("    models:\n")
        items = new_models[peer]
        if not items:
            out.append("      []\n")  # explicit empty list keeps YAML valid
        else:
            for m in items:
                out.append(f"      - {m}\n")
        # Skip past the old models block; resume from models_end
        i = models_end
        continue

    # No models: block found, or peer not targeted — leave body untouched.
    i += 1

sys.stdout.write("".join(out))
PY
)

if [[ -z "$NEW_CONFIG" ]]; then
  fail "YAML rewriter produced empty output — refusing to overwrite config" 3
fi

# ── Diff / write ─────────────────────────────────────────────────────────────

TMP_NEW="$(mktemp)"
trap 'rm -f "$TMP_NEW"' EXIT
printf '%s' "$NEW_CONFIG" > "$TMP_NEW"

if diff -q "$CONFIG" "$TMP_NEW" >/dev/null 2>&1; then
  say "Config already matches runtime — nothing to do."
  exit 0
fi

say "Pending changes to $(basename "$CONFIG"):"
diff -u "$CONFIG" "$TMP_NEW" || true

if [[ "$DRY_RUN" == "true" ]]; then
  say "--dry-run set — not writing."
  exit 0
fi

mkdir -p "$BACKUP_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP="${BACKUP_DIR}/llama-swap.yaml.${TS}"
cp -p "$CONFIG" "$BACKUP"
info "Backed up original → $BACKUP"

cp "$TMP_NEW" "$CONFIG" || fail "Failed to write $CONFIG" 3
say "Wrote updated $CONFIG"

# ── Reload llama-swap ────────────────────────────────────────────────────────

if [[ "$DO_RESTART" != "true" ]]; then
  info "--no-restart set — llama-swap will pick up changes on next restart."
  exit 0
fi

if docker compose -f "$COMPOSE" ps --services --status running 2>/dev/null \
   | grep -qx "llama-swap"; then
  say "Restarting llama-swap to apply new config"
  docker compose -f "$COMPOSE" restart llama-swap \
    || fail "docker compose restart llama-swap failed" 3
  info "llama-swap restarted."
else
  warn "llama-swap is not running — skipping restart."
fi

say "Done."
