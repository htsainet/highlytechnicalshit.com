# Refactor — References

## Service script contract

Every `components/*.sh` follows this pattern:

```bash
#!/usr/bin/env bash
# components/servicename.sh — Install and configure ServiceName
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"
source "$SCRIPT_DIR/../lib/health.sh"
source "$SCRIPT_DIR/../lib/compose.sh"

servicename_install()   { ... }
servicename_configure() { ... }
servicename_health()    { ... }
servicename_start()     { ... }
servicename_stop()      { ... }

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  servicename_install
  servicename_configure
  servicename_start
  servicename_health
fi
```

## Bundle definitions

| Bundle | Services | Use Case |
|--------|----------|----------|
| `chat.sh` | Ollama + Open WebUI + Dashboard | Basic chat setup |
| `nemoclaw.sh` | Ollama + NemoClaw + Dashboard | Sandbox agent runtime |
| `openspace.sh` | nemoclaw + OpenSpace + Gitea | MCP agent skills |
| `deerflow.sh` | Chat + Gitea + NemoClaw + DeerFlow + Dashboard | Agent workflows |
| `image-gen.sh` | Stable Diffusion + ComfyUI | Image generation |
| `voice.sh` | chat + Whisper + Xtts | Voice chat (stub — services pending) |
| `full-stack.sh` | **Deprecated** — stub pointing to install.sh / converge.sh | Was: Fresh machine install |

## Shared libraries (`scripts/lib/`)

| File | Purpose |
|------|---------|
| `common.sh` | Colors, logging (`info`, `warn`, `fail`, `step`), `REPO_DIR` |
| `health.sh` | Unified HTTP probe + port check functions |
| `compose.sh` | Docker compose wrapper (profiles, env-file), `ensure_backend_exclusive` |
| `tokens.sh` | Secret generation + `.env` token management |

## Component inventory (`scripts/components/`)

| Component | Notes |
|-----------|-------|
| `ollama.sh` | LLM inference; backend-exclusive with BitNet; NAS cache support |
| `open-webui.sh` | Chat frontend; connects to Ollama or BitNet via `BACKEND_ENGINE` |
| `nemoclaw.sh` | GitHub CLI + OpenShell + sandbox onboarding + registry patching |
| `bitnet.sh` | 1-bit LLM; backend-exclusive with Ollama |
| `openspace.sh` | MCP agent skills server |
| `dashboard.sh` | Nginx link page; ports reflect `.env` |
| `gitea.sh` | Self-hosted git |
| `stable-diffusion.sh` | Image gen; checkpoint download + NAS cache |
| `comfyui.sh` | Workflow image gen; shares model volumes with SD |
| `sillytavern.sh` | Character chat |
| `deerflow.sh` | ByteDance agent workflow; manages main + sandbox containers |
| `timeshift.sh` | Native system snapshots (not a Docker service) |
| `duplicati.sh` | File-level backups |
| `tailscale.sh` | VPN mesh |
| `telegram.sh` | Bot integration |
| `signal.sh` | Signal messaging |
| `unsloth.sh` | Model fine-tuning |

## Host scripts (`scripts/host/`)

| Script | Purpose |
|--------|---------|
| `nvidia.sh` | NVIDIA drivers + CUDA + nvidia-ctk; detects if reboot needed |
| `docker.sh` | Docker engine + compose + user group |
| `node.sh` | NVM + Node.js |
| `nas.sh` | NFS mounts, `/etc/fstab`, `/etc/idmapd.conf`; backs up fstab first |
| `tools.sh` | VS Code, PowerShell, Pester, dev tools |

## Code review standards

When reviewing component scripts, check:

1. **Correctness** — `bash -n` passes, `set -euo pipefail` present, `lib/` functions used, no hardcoded paths
2. **Contract** — correct directory, standard function pattern, `BASH_SOURCE` guard, independently runnable, idempotent
3. **Scope** — one service per file, no unrelated changes, no new dependencies without justification
4. **Quality** — variables quoted, `[[ ]]` conditionals, `$()` substitution, `servicename_action()` naming
5. **Integration** — old wrappers still work, compose profiles match, port numbers match, `hts-ai-` container prefix
6. **Security** — no hardcoded secrets, secrets from `.env` only, no `chmod 777`, `sudo` documented, no unchecked `curl | bash`

## Task completion log

All 16 tasks completed in dependency order:

| # | Task | Status |
|---|------|--------|
| 01 | Create `lib/` (common, health, compose, tokens) | Done |
| 02 | Split `01-autoinstall.sh` → `host/` scripts | Done |
| 03 | Extract Ollama → `components/ollama.sh` | Done |
| 04 | Extract Stable Diffusion → `components/stable-diffusion.sh` | Done |
| 05 | Extract NemoClaw → `components/nemoclaw.sh` | Done |
| 06 | Create `components/dashboard.sh` + `components/gitea.sh` | Done |
| 07 | Create `components/open-webui.sh` | Done |
| 08 | Create `components/openspace.sh` + `components/bitnet.sh` | Done |
| 08b | Create `components/comfyui.sh` + `components/sillytavern.sh` | Done |
| 08c | Create `components/deerflow.sh` | Done |
| 08d | Create `components/timeshift.sh` + `components/duplicati.sh` | Done |
| 09 | Extract connectivity → `components/tailscale.sh`, `telegram.sh`, `signal.sh` | Done |
| 10 | Split `06-start-stack.sh` — delegate to components | Done |
| 11 | Extract NAS → `host/nas.sh` + wizard prompt | Done |
| 12 | Create `bundles/` (7 bundle scripts) | Done |
| 13 | Update `install.sh` entry point | Done |
| 14 | Update `nuke-stack.sh` for new structure | Done |
| 15 | Update Pester tests for new paths | Done |
| 16 | Clean up dead code | Done |
