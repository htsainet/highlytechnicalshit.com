#!/usr/bin/env bash
# install-github-gg.sh — Clone/update and prepare github.gg for local development
#
# What this script does:
# 1) Ensures required tools exist (git, curl)
# 2) Installs Bun if missing
# 3) Clones or updates https://github.com/lantos1618/github.gg
# 4) Installs project dependencies with Bun
# 5) Creates .env.local from .env.example if missing
#
# Optional:
#   --with-db   Run `bun run setup` to start local DB and run migrations
#   --docker    Run github.gg with docker compose instead of local Bun runtime
#
# Examples:
#   ./scripts/install/tooling/install-github-gg.sh
#   ./scripts/install/tooling/install-github-gg.sh --with-db
#   ./scripts/install/tooling/install-github-gg.sh --docker

set -euo pipefail

REPO_URL="https://github.com/lantos1618/github.gg.git"
INSTALL_DIR="${INSTALL_DIR:-$HOME/github/github.gg}"
WITH_DB=0
DOCKER_MODE=0

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
err()  { echo -e "${RED}[ERROR]${NC} $*"; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

usage() {
  cat <<'EOF'
Usage: install-github-gg.sh [--with-db] [--docker] [--help]

Options:
  --with-db   Run `bun run setup` after dependency install
  --docker    Use docker compose to run github.gg in containers
  --help      Show this help

Environment variables:
  INSTALL_DIR  Target path for clone/update (default: $HOME/github/github.gg)
EOF
}

for arg in "$@"; do
  case "$arg" in
    --with-db) WITH_DB=1 ;;
    --docker) DOCKER_MODE=1 ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      err "Unknown argument: $arg"
      usage
      exit 1
      ;;
  esac
done

step "1 — Check prerequisites"
for cmd in git curl; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    err "Required command not found: $cmd"
    exit 1
  fi
done
info "Base prerequisites found."

if [ "$DOCKER_MODE" -eq 1 ] && [ "$WITH_DB" -eq 1 ]; then
  warn "--with-db is ignored when --docker is enabled (containers handle DB/app startup)."
fi

if [ "$DOCKER_MODE" -eq 0 ]; then
  step "2 — Ensure Bun is installed"
  if ! command -v bun >/dev/null 2>&1; then
    info "Installing Bun..."
    curl -fsSL https://bun.sh/install | bash
    export BUN_INSTALL="${BUN_INSTALL:-$HOME/.bun}"
    export PATH="$BUN_INSTALL/bin:$PATH"
  else
    info "Bun already installed: $(bun --version)"
  fi

  if ! command -v bun >/dev/null 2>&1; then
    err "Bun install completed but bun is not in PATH."
    warn "Open a new shell and rerun this script, or run: export PATH=\"$HOME/.bun/bin:$PATH\""
    exit 1
  fi
fi

step "3 — Clone or update github.gg"
mkdir -p "$(dirname "$INSTALL_DIR")"

if [ -d "$INSTALL_DIR/.git" ]; then
  info "Existing repository detected at $INSTALL_DIR"
  git -C "$INSTALL_DIR" fetch --all --prune
  git -C "$INSTALL_DIR" pull --ff-only
else
  if [ -e "$INSTALL_DIR" ]; then
    err "Install path exists but is not a git repo: $INSTALL_DIR"
    warn "Set INSTALL_DIR to a different location and rerun."
    exit 1
  fi
  info "Cloning $REPO_URL -> $INSTALL_DIR"
  git clone "$REPO_URL" "$INSTALL_DIR"
fi

cd "$INSTALL_DIR"

if [ "$DOCKER_MODE" -eq 0 ]; then
  step "4 — Install project dependencies"
  bun install
  info "Dependencies installed."
else
  step "4 — Validate Docker prerequisites"
  if ! command -v docker >/dev/null 2>&1; then
    err "Docker is required for --docker but was not found."
    exit 1
  fi
  if ! docker compose version >/dev/null 2>&1; then
    err "Docker Compose plugin is required for --docker but was not found."
    exit 1
  fi
  info "Docker and docker compose are available."
fi

step "5 — Create local env file (if needed)"
if [ -f .env.local ]; then
  info ".env.local already exists — leaving as-is."
else
  if [ -f .env.example ]; then
    cp .env.example .env.local
    warn "Created .env.local from .env.example."
    warn "Update required values (especially GitHub OAuth credentials) before running the app."
  else
    warn ".env.example not found; skipping env bootstrap."
  fi
fi

if [ "$DOCKER_MODE" -eq 0 ] && [ "$WITH_DB" -eq 1 ]; then
  step "6 — Run project setup (DB + migrations)"
  if ! command -v docker >/dev/null 2>&1; then
    err "Docker is required for --with-db but was not found."
    exit 1
  fi
  bun run setup
  info "Setup completed."
fi

if [ "$DOCKER_MODE" -eq 1 ]; then
  step "6 — Build and start with docker compose"
  docker compose up -d --build
  info "Containers are running."
fi

step "Done"
info "github.gg is prepared at: $INSTALL_DIR"
echo
info "Next steps:"
echo "  1) cd $INSTALL_DIR"
echo "  2) Edit .env.local with your GitHub OAuth credentials"
if [ "$DOCKER_MODE" -eq 1 ]; then
  echo "  3) docker compose ps"
  echo "  4) docker compose logs -f"
  echo "  5) open http://localhost:3000"
elif [ "$WITH_DB" -eq 0 ]; then
  echo "  3) (optional) bun run setup"
  echo "  4) bun dev"
else
  echo "  3) bun dev"
fi
echo
