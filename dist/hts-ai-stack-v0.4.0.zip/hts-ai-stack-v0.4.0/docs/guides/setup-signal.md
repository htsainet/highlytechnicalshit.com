# setup-signal.sh — Signal Integration

Registers or links a Signal account using `signal-cli`, then configures it as
an OpenClaw messaging channel. Lets you chat with the AI via Signal.

```bash
./setup-signal.sh
```

> `signal-cli` is installed by `./01-autoinstall.sh`. Run that first.

---

## Prerequisites

- A phone number that can receive SMS (for new registration), **or** an existing
  Signal account on your phone (for linking)
- `signal-cli` installed (handled by `01-autoinstall.sh`)

Optionally pre-set your phone number in `.env` to skip the prompt:

```bash
echo "SIGNAL_PHONE=+14155552671" >> .env   # E.164 format
```

---

## What it does

| Step | Action |
|---|---|
| 1 | Verifies `signal-cli` is installed |
| 2 | Reads `SIGNAL_PHONE` from `.env` or prompts for it |
| 3a | **Register new** — sends SMS code, prompts for verification |
| 3b | **Link existing** — generates QR/link to scan in Signal app (Settings → Linked devices) |
| 4 | Optionally sets a display name for this device |
| 5 | Sends a test message to yourself to confirm setup |

---

## Registration vs Linking

| Mode | Use when |
|---|---|
| **Register new** | You have a spare phone number (SIM or VoIP) dedicated to the bot |
| **Link existing** | You want to re-use your personal Signal account (messages go to all linked devices) |

Linking to your personal account means the AI will see and respond to all your
Signal conversations — only do this if that's intentional.

---

## After setup

```bash
# Receive incoming messages manually
signal-cli -u +14155552671 receive

# Send a message
signal-cli -u +14155552671 send -m "hello" +1XXXXXXXXXX

# List registered accounts
signal-cli -u +14155552671 listAccounts
```

For persistent background receiving, configure `signal-cli` as a daemon or
integrate with OpenClaw's Signal channel in `openclaw.json`.
