#!/usr/bin/env bash
# scripts/utils/generate-services-json.sh — Generate dashboard services registry
#
# Reads all scripts/components/*.manifest.json files, filters those with
# dashboard blocks (show != false), groups by section, sorts by order,
# and writes resources/dashboard/services.json.
#
# Usage:
#   bash scripts/utils/generate-services-json.sh
#
# Output:
#   resources/dashboard/services.json
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
MANIFEST_DIR="$REPO_DIR/scripts/components"
OUTPUT="$REPO_DIR/resources/dashboard/services.json"

python3 - "$MANIFEST_DIR" "$OUTPUT" <<'PYEOF'
import json, sys, glob, os
from collections import defaultdict

manifest_dir, output = sys.argv[1], sys.argv[2]
manifests = glob.glob(os.path.join(manifest_dir, '*', '*.manifest.json'))

items = []
for path in manifests:
    try:
        d = json.load(open(path))
    except Exception:
        continue
    db = d.get('dashboard')
    if not db:
        continue
    if db.get('show') is False:
        continue
    items.append(d)

groups = defaultdict(list)
for d in items:
    section = d.get('dashboard', {}).get('section')
    groups[section].append(d)

def min_order(group):
    return min(d.get('order', 999) for d in group)

sections = sorted(groups.items(), key=lambda kv: min_order(kv[1]))

result = []
for section, group in sections:
    group_sorted = sorted(group, key=lambda d: d.get('order', 999))
    cluster = next((d['dashboard']['cluster'] for d in group_sorted
                    if d.get('dashboard', {}).get('cluster')), None)
    sec_items = []
    for d in group_sorted:
        db = d.get('dashboard', {})
        item = {'title': db.get('title') or d.get('display_name'),
                'service': d['id'], 'installId': d['id']}
        for key in ('port', 'desc'):
            if db.get(key) is not None:
                item[key] = db[key]
        for key in ('path', 'probePath', 'uiPath', 'apiPath'):
            if db.get(key):
                item[key] = db[key]
        if db.get('proto') and db['proto'] != 'http':
            item['proto'] = db['proto']
        if db.get('gpu'):
            item['gpu'] = True
        sec_items.append(item)
    entry = {'section': section, 'items': sec_items}
    if cluster:
        entry['wrap'] = cluster
    result.append(entry)

tmp = output + '.tmp'
with open(tmp, 'w') as f:
    json.dump(result, f, indent=2)
os.replace(tmp, output)
print(f"Generated: {output}")
print(f"  {len(result)} sections")
PYEOF
