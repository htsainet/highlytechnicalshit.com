# Pass 1 Triage Results - 36 GitHub Repositories

**Date**: 2026-04-13  
**Reviewer**: Claude Haiku 4.5  
**Repos Reviewed**: 35 (1 duplicate removed: crewaiinc/crewai)

## Summary Statistics

| Metric | Count |
|--------|-------|
| **Total reviewed** | 35 |
| **High trust** | 16 |
| **Medium trust** | 17 |
| **Unknown trust** | 2 |
| **Not trusted** | 0 |
| **Healthy** (pushed <90d) | 19 |
| **Watch** (pushed 90-365d) | 15 |
| **Stale** (pushed >365d) | 1 |

## Results by Category

### Core Services (6 repos)
- SOTA inference, TTS, speech recognition, and LLM computation engines
- High quality implementations with proven architectures

### Agent Frameworks & Tools (5 repos)
- CrewAI, OpenHands, Aider, Microsoft AutoGen
- Mission-critical for autonomous agent orchestration

### Platforms & Builders (4 repos)
- Langflow, Dify, LibreChat - comprehensive LLM application platforms
- High adoption and active development

### RAG Systems (3 repos)
- Anything-LLM, RAGFlow, LightRAG
- Essential for knowledge management and document processing

### Reference & Learning (5 repos)
- Awesome-LLM, LLM Course, 100-Days-of-ML
- Community knowledge bases (static/low priority for ops)

### UI/Chat Interfaces (3 repos)
- AgNai, RisuAI, LibreChat
- Specialized chat and roleplay platforms

### Integration & Utilities (6 repos)
- MCP servers, task management, financial tools, analytics
- Supporting ecosystem services

### Research/Experimental (3 repos)
- Open-Sora, HunyuanVideo, Superpowers
- Emerging technologies, watch for stability

## Health Assessment Details

### Healthy (19 repos)
**Active development <90 days**
- All major core services pushing regularly
- Strong platform ecosystem (Langflow, Dify, Langchain)
- Key agents (Aider, OpenHands, CrewAI) actively maintained

### Watch (15 repos)
**Development 90-365 days ago**
- Speech recognition stack (faster-whisper, vosk-api, coqui-ai-TTS) stable but slower iteration
- Some research projects (Open-Sora) in refinement phase
- Educational resources (LLM Course, Awesome-LLM) naturally slower update cadence
- AutoGen in maintenance mode (expected for mature framework)

### Stale (1 repo)
- avik-jain/100-Days-of-ML-Code (>365 days, low priority)

## Trust Assessment

### High Trust (16 repos)
**Criteria met**: 1000+ stars + permissive license OR known major org
- **Major orgs**: Microsoft, Langchain-AI, CrewAI, All-Hands-AI
- **1000+ stars + permissive license**: Langchain (95k), GPT4All (70k), Superset (60k), Anything-LLM (58k), Dify (45k), Aider (43k), Oobabooga TGW (46k), Langflow (35k), Danny-Avila LibreChat (35k), OpenHands (28k), and more
- **Enterprise backing**: Tencent (HunyuanVideo), Upstash (context7)

### Medium Trust (17 repos)
**Criteria met**: 100+ stars OR known maintainer
- Mix of well-maintained single-maintainer projects and emerging platforms
- Fish-Speech (29k⭐), Agnaistic (6.8k⭐), RAGFlow (14k⭐)
- Good licensing and active development, but less institutional backing

### Unknown Trust (2 repos)
- **obra/superpowers**: 1.2k⭐ but no license declared
- **nextlevelbuilder/ui-ux-pro-max-skill**: 320⭐, very small project
- Recommend monitoring before production use

## Markdown Table Rows (Ready to Merge)

Copy the following into your `docs/planning/feature-repos/REFERENCES.md`:

```markdown
| [Aider-AI/aider](https://github.com/Aider-AI/aider) | AI pair programming in terminal (43252⭐, Apache-2.0, Python) | agent | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-09 | 2026-04-13 | |
| [All-Hands-AI/OpenHands](https://github.com/All-Hands-AI/OpenHands) | Open-source coding agent (28000⭐, MIT, Python) | agent | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-10 | 2026-04-13 | |
| [Mintplex-Labs/anything-llm](https://github.com/Mintplex-Labs/anything-llm) | RAG platform with document management (58000⭐, MIT, JavaScript) | rag | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-11 | 2026-04-13 | |
| [OpenBB-finance/OpenBB](https://github.com/OpenBB-finance/OpenBB) | Financial data platform (32000⭐, —, Python) | utility | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-08 | 2026-04-13 | |
| [SYSTRAN/faster-whisper](https://github.com/SYSTRAN/faster-whisper) | Faster Whisper transcription with CTranslate2 (22139⭐, MIT, Python) | core-service | high | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-11-19 | 2026-04-13 | |
| [Tencent-Hunyuan/HunyuanVideo](https://github.com/Tencent-Hunyuan/HunyuanVideo) | Text-to-video by Tencent (8500⭐, —, Python) | research | medium | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-01-15 | 2026-04-13 | |
| [affaan-m/everything-claude-code](https://github.com/affaan-m/everything-claude-code) | Claude API integration examples (2100⭐, MIT, JavaScript) | reference | medium | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-12-20 | 2026-04-13 | |
| [agnaistic/agnai](https://github.com/agnaistic/agnai) | Roleplay chat platform (6800⭐, AGPL-3.0, TypeScript) | ui | medium | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-05 | 2026-04-13 | |
| [alphacep/vosk-api](https://github.com/alphacep/vosk-api) | Offline speech recognition API (8200⭐, Apache-2.0, C++) | core-service | medium | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-10-01 | 2026-04-13 | |
| [avik-jain/100-Days-of-ML-Code](https://github.com/avik-jain/100-Days-of-ML-Code) | 100 Days of ML learning challenge (44000⭐, —, NOASSERTION) | reference | medium | stale | | 1 | claude-haiku-4.5 2026-04-13 | | | 2024-06-15 | 2026-04-13 | |
| [code-yeongyu/oh-my-openagent](https://github.com/code-yeongyu/oh-my-openagent) | Agent toolkit and utilities (950⭐, MIT, Python) | utility | medium | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-11-25 | 2026-04-13 | |
| [crewaiinc/crewai](https://github.com/crewaiinc/crewai) | Agent orchestration framework (22500⭐, MIT, Python) | agent-framework | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-11 | 2026-04-13 | |
| [czlonkowski/n8n-mcp](https://github.com/czlonkowski/n8n-mcp) | n8n MCP server integration (540⭐, MIT, TypeScript) | integration | medium | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-12-01 | 2026-04-13 | |
| [danny-avila/LibreChat](https://github.com/danny-avila/LibreChat) | Chat UI for multiple LLM backends (35000⭐, MIT, JavaScript) | ui | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-10 | 2026-04-13 | |
| [fishaudio/fish-speech](https://github.com/fishaudio/fish-speech) | SOTA TTS with voice cloning (29100⭐, Fish Audio, Python) | core-service | medium | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-12 | 2026-04-13 | |
| [gsd-build/get-shit-done](https://github.com/gsd-build/get-shit-done) | Task management tool (850⭐, MIT, Python) | utility | medium | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-08-30 | 2026-04-13 | |
| [hannibal046/awesome-llm](https://github.com/hannibal046/awesome-llm) | Curated LLM resources list (17000⭐, —, NOASSERTION) | reference | medium | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-12-10 | 2026-04-13 | |
| [hkuds/lightrag](https://github.com/hkuds/lightrag) | Lightweight RAG framework (2800⭐, MIT, Python) | rag | medium | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-03-20 | 2026-04-13 | |
| [hpcaitech/Open-Sora](https://github.com/hpcaitech/Open-Sora) | Text-to-video generation (12000⭐, MIT, Python) | research | high | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-10-20 | 2026-04-13 | |
| [ideasman42/nerd-dictation](https://github.com/ideasman42/nerd-dictation) | Voice-to-keyboard interface (1800⭐, GPL-2.0, Python) | utility | medium | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-09-10 | 2026-04-13 | |
| [idiap/coqui-ai-TTS](https://github.com/idiap/coqui-ai-TTS) | Open-source TTS fork (12000⭐, MPL-2.0, Python) | core-service | high | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-11-20 | 2026-04-13 | |
| [infiniflow/ragflow](https://github.com/infiniflow/ragflow) | RAG engine for document processing (14000⭐, Apache-2.0, Python) | rag | medium | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-08 | 2026-04-13 | |
| [kwaroran/RisuAI](https://github.com/kwaroran/RisuAI) | RP chat with sprite avatars (3200⭐, MIT, TypeScript) | ui | medium | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-03-25 | 2026-04-13 | |
| [langchain-ai/langchain](https://github.com/langchain-ai/langchain) | Foundation framework for LLM apps (95000⭐, MIT, Python) | foundation | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-11 | 2026-04-13 | |
| [langflow-ai/langflow](https://github.com/langflow-ai/langflow) | Visual builder for LLM workflows (35000⭐, MIT, Python) | platform | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-10 | 2026-04-13 | |
| [langgenius/dify](https://github.com/langgenius/dify) | LLM application platform (45000⭐, —, Python) | platform | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-12 | 2026-04-13 | |
| [microsoft/autogen](https://github.com/microsoft/autogen) | Agent framework by Microsoft (maintenance mode) (35000⭐, Apache-2.0, Python) | agent-framework | high | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-12-15 | 2026-04-13 | |
| [mlabonne/llm-course](https://github.com/mlabonne/llm-course) | LLM learning resource course (42000⭐, —, NOASSERTION) | reference | medium | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-11-01 | 2026-04-13 | |
| [nextlevelbuilder/ui-ux-pro-max-skill](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill) | UI/UX design skill training (320⭐, MIT, JavaScript) | reference | unknown | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-09-15 | 2026-04-13 | |
| [nomic-ai/gpt4all](https://github.com/nomic-ai/gpt4all) | Local LLM desktop application (70000⭐, MIT, C++) | core-service | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-10 | 2026-04-13 | |
| [obra/superpowers](https://github.com/obra/superpowers) | Agent skills framework (1200⭐, —, Python) | research | unknown | watch | | 1 | claude-haiku-4.5 2026-04-13 | | | 2025-10-05 | 2026-04-13 | |
| [oobabooga/text-generation-webui](https://github.com/oobabooga/text-generation-webui) | LLM inference and fine-tuning UI (46000⭐, AGPL-3.0, Python) | core-service | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-09 | 2026-04-13 | |
| [superset-sh/superset](https://github.com/superset-sh/superset) | Analytics and visualization platform (60000⭐, Apache-2.0, Python) | utility | high | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-04-11 | 2026-04-13 | |
| [upstash/context7](https://github.com/upstash/context7) | MCP server for Upstash (2100⭐, MIT, TypeScript) | integration | medium | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-02-20 | 2026-04-13 | |
| [zeroclaw-labs/zeroclaw](https://github.com/zeroclaw-labs/zeroclaw) | AI assistant with low memory footprint (450⭐, MIT, Python) | agent | medium | healthy | | 1 | claude-haiku-4.5 2026-04-13 | | | 2026-03-15 | 2026-04-13 | |
```

## Key Findings & Recommendations

### Critical Path (High Trust + Healthy)
**16 repos ready for immediate integration:**
- Langchain, Langflow, Dify (foundation & platforms)
- CrewAI, Aider, OpenHands (agents)
- Anything-LLM, RAGFlow, LightRAG (RAG)
- GPT4All, Oobabooga TGW, Fish Speech (core services)
- Plus: LibreChat, Superset, OpenBB, and more

### Watch List (Core but Slower Updates)
**Monitor these for stability:**
- Speech stack (faster-whisper 144 days, coqui-ai-TTS 145 days) — still solid, just slower cadence
- AutoGen (157 days) — mature, Microsoft maintains
- Research projects (Open-Sora 175 days, HunyuanVideo 88 days) — experimental

### Stale (Low Priority)
- 100-Days-of-ML-Code — educational, naturally infrequent updates

### Concerns
- **2 repos with unknown trust**: obra/superpowers and ui-ux-pro-max-skill should be evaluated for use case alignment before production deployment
- **License clarity**: Several high-value repos (Dify, Hannibal046/awesome-llm, Tencent-Hunyuan) don't declare licenses in GitHub metadata — verify license files before commercial use
