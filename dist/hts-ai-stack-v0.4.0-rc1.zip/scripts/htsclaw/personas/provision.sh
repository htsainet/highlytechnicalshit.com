#!/usr/bin/env bash
# scripts/htsclaw/personas/provision.sh — Agent identity provisioning
#
# Uploads SOUL.md and IDENTITY.md files into sandbox workspaces so each
# OpenClaw agent has a distinct personality, system prompt, and behavioral
# constraints. Configures multi-agent routing in openclaw.json.
#
# Ported from NemoClaw's _provision_agent_personas() but uses openshell
# sandbox exec/upload directly instead of containerd exec.
#
# Can be sourced or run standalone.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/htsclaw/sandbox/lifecycle.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
HTSCLAW_SANDBOX_NAME="${HTSCLAW_SANDBOX_NAME:-hts-ai-openshell-htsclaw-gpu}"
HTSCLAW_AGENT_PERSONAS="${HTSCLAW_AGENT_PERSONAS:-true}"
HTSCLAW_GATEWAY_NAME="htsclaw"
HTSCLAW_CLUSTER_CONTAINER="openshell-cluster-${HTSCLAW_GATEWAY_NAME}"
OLLAMA_MODEL="${OLLAMA_MODEL:-gemma4:e4b}"

# ── Internal helpers ─────────────────────────────────────────────────────────

# Root exec — openclaw.json is root-owned inside the sandbox
_htsclaw_root_exec() {
  local sandbox="$1" exec_prefix="$2"; shift 2

  if ! docker inspect "$HTSCLAW_CLUSTER_CONTAINER" &>/dev/null; then
    warn "Cluster container '${HTSCLAW_CLUSTER_CONTAINER}' not found."
    return 1
  fi

  local ctr_id
  ctr_id=$(docker exec "$HTSCLAW_CLUSTER_CONTAINER" \
    /bin/sh -c "ctr -n k8s.io tasks list 2>/dev/null | awk '{print \$1}'" \
    | while read -r id; do
        local hn
        hn=$(docker exec "$HTSCLAW_CLUSTER_CONTAINER" \
          ctr -n k8s.io tasks exec --exec-id "hn-${id:0:8}" --user 0 "$id" \
          hostname 2>/dev/null) || continue
        if [[ "$hn" == "$sandbox" ]]; then echo "$id"; break; fi
      done)

  if [[ -z "${ctr_id:-}" ]]; then
    warn "Could not find containerd task for '${sandbox}'."
    return 1
  fi

  docker exec "$HTSCLAW_CLUSTER_CONTAINER" \
    ctr -n k8s.io tasks exec \
      --exec-id "${exec_prefix}-${sandbox:0:8}" --user 0 "$ctr_id" \
      "$@"
}

# _htsclaw_restart_gateway is provided by lifecycle.sh (kill + start + healthcheck)

# ── Persona provisioning ────────────────────────────────────────────────────

# htsclaw_provision_personas — Upload agent persona files into sandbox workspaces
# and configure multi-agent routing in openclaw.json.
htsclaw_provision_personas() {
  if [[ "$HTSCLAW_AGENT_PERSONAS" != "true" ]]; then
    info "Agent persona injection disabled (HTSCLAW_AGENT_PERSONAS=false) — skipping."
    return 0
  fi

  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not found — skipping persona provisioning."
    return 0
  fi

  step "htsclaw — provision agent personas"

  local agents_dir="$REPO_DIR/resources/agents"
  if [[ ! -d "$agents_dir" ]]; then
    warn "No agents directory found at ${agents_dir} — skipping personas."
    return 0
  fi

  local sandbox="$HTSCLAW_SANDBOX_NAME"

  # Verify sandbox exists
  if ! openshell sandbox get "$sandbox" &>/dev/null 2>&1; then
    warn "Sandbox '${sandbox}' not found — create it first."
    return 1
  fi

  # Discover agents — each subdirectory of resources/agents/ with a SOUL.md
  local agents_provisioned=()

  for agent_dir in "$agents_dir"/*/; do
    [[ -d "$agent_dir" ]] || continue
    local agent
    agent=$(basename "$agent_dir")

    # Must have at least a SOUL.md or IDENTITY.md
    if [[ ! -f "$agent_dir/SOUL.md" && ! -f "$agent_dir/IDENTITY.md" ]]; then
      continue
    fi

    # Create workspace directory inside sandbox
    local ws_dir="/sandbox/.openclaw-data/workspace-${agent}"
    openshell sandbox exec -n "$sandbox" -- mkdir -p "$ws_dir" 2>/dev/null || {
      warn "Failed to create workspace dir for '${agent}' in '${sandbox}'."
      continue
    }

    # Upload persona files
    for file in SOUL.md IDENTITY.md; do
      [[ -f "$agent_dir/$file" ]] || continue
      openshell sandbox upload "$sandbox" "$agent_dir/$file" "${ws_dir}/" 2>/dev/null \
        && info "Provisioned ${agent}/${file} → ${sandbox}:${ws_dir}/" \
        || warn "Failed to provision ${agent}/${file} → ${sandbox}"
    done

    # Upload shared AGENTS.md if the agent doesn't have its own
    local shared_agents_md="$agents_dir/AGENTS.md"
    if [[ ! -f "$agent_dir/AGENTS.md" && -f "$shared_agents_md" ]]; then
      openshell sandbox upload "$sandbox" "$shared_agents_md" "${ws_dir}/" 2>/dev/null \
        && info "Provisioned shared AGENTS.md → ${sandbox}:${ws_dir}/" \
        || warn "Failed to provision shared AGENTS.md → ${sandbox}"
    fi

    agents_provisioned+=("$agent")
  done

  if [[ ${#agents_provisioned[@]} -eq 0 ]]; then
    info "No agent personas found in ${agents_dir} — nothing to provision."
    return 0
  fi

  # Patch openclaw.json for multi-agent routing
  _patch_multi_agent_config "$sandbox" "${agents_provisioned[@]}"

  ok "Provisioned ${#agents_provisioned[@]} agent persona(s): ${agents_provisioned[*]}"
}

# _patch_multi_agent_config — Update openclaw.json with agent list + per-agent dirs
_patch_multi_agent_config() {
  local sandbox="$1"; shift
  local agents=("$@")
  local agents_csv="${agents[*]}"
  local agents_dir="$REPO_DIR/resources/agents"
  local default_model="inference/${OLLAMA_MODEL}"

  # Build agents.list JSON on the host from IDENTITY.md metadata
  local agents_json
  agents_json=$(python3 - "$agents_csv" "$agents_dir" "$default_model" <<'PYEOF'
import json, re, sys, pathlib
agents = sys.argv[1].split()
agents_dir = pathlib.Path(sys.argv[2])
default_model = sys.argv[3]
result = []
first = True
for agent in sorted(agents):
    id_file = agents_dir / agent / "IDENTITY.md"
    name, emoji, model = agent, "", default_model
    if id_file.exists():
        text = id_file.read_text()
        m = re.search(r"\*\*Name:\*\*\s*(.+)", text)
        if m: name = m.group(1).strip()
        m = re.search(r"\*\*Emoji:\*\*\s*(.+)", text)
        if m: emoji = m.group(1).strip()
        m = re.search(r"\*\*Model:\*\*\s*(.+)", text)
        if m: model = m.group(1).strip()
    entry = {"id": agent, "name": name,
             "model": model,
             "workspace": "/sandbox/.openclaw-data/workspace-" + agent,
             "identity": {"name": name}}
    if emoji: entry["identity"]["emoji"] = emoji
    if first: entry["default"] = True; first = False
    result.append(entry)
print(json.dumps(result))
PYEOF
  ) || { warn "Failed to build agents list JSON."; return 1; }

  # Escape for embedding in a Python one-liner
  local escaped_json
  escaped_json=$(printf '%s' "$agents_json" | python3 -c "import sys; print(repr(sys.stdin.read()))")

  local patch_script="import json,pathlib;p=pathlib.Path('/sandbox/.openclaw/openclaw.json');d=json.loads(p.read_text());d['agents']={'list':json.loads(${escaped_json})};p.write_text(json.dumps(d,indent=2));print('OK')"

  local result
  result=$(_htsclaw_root_exec "$sandbox" "agents" python3 -c "$patch_script" 2>&1) || {
    warn "Failed to patch multi-agent config in '${sandbox}': ${result}"
    return 1
  }

  # Create per-agent directories under ~/.openclaw/agents/<id>/agent/ with models.json
  local agentdir_script
  agentdir_script="
import json, pathlib, os, pwd
cfg = json.loads(pathlib.Path('/sandbox/.openclaw/openclaw.json').read_text())
providers = cfg.get('models', {}).get('providers', {})
models_json = json.dumps({'providers': providers}, indent=2)
sb = pwd.getpwnam('sandbox')
for agent in cfg.get('agents', {}).get('list', []):
    agent_dir = pathlib.Path('/sandbox/.openclaw/agents') / agent['id'] / 'agent'
    agent_dir.mkdir(parents=True, exist_ok=True)
    # chown the whole agent tree so the sandbox user can write sessions
    top = pathlib.Path('/sandbox/.openclaw/agents') / agent['id']
    for d in [top, agent_dir]:
        os.chown(d, sb.pw_uid, sb.pw_gid)
    mf = agent_dir / 'models.json'
    if not mf.exists():
        mf.write_text(models_json)
        os.chown(mf, sb.pw_uid, sb.pw_gid)
        print(f'Created {mf}')
    else:
        print(f'Exists  {mf}')
print('OK')
"
  result=$(_htsclaw_root_exec "$sandbox" "adir" python3 -c "$agentdir_script" 2>&1) || {
    warn "Failed to create agent dirs in '${sandbox}': ${result}"
  }

  _htsclaw_restart_gateway "$sandbox"
  info "Multi-agent config patched in '${sandbox}' (${agents[*]})."
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  htsclaw_provision_personas
fi
