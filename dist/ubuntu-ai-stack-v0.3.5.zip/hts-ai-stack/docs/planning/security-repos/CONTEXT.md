# Security Repos

Last updated: 2026-03-31 19:09:51

## What this folder is

GitHub repositories focused on security tooling, hardening, auditing, and threat defense for AI agent stacks.
Master threat model and architecture decisions live in [`../security-review/CONTEXT.md`](../security-review/CONTEXT.md).

## What good looks like

- Each reviewed repo gets a `results/owner-reponame.md` summary artifact (e.g. `results/slowmist-openclaw-security-practice-guide.md`)
- Summaries include: what it does, mapping to our stack, verdict (ADOPT / REFERENCE / SKIP), risks
- `REFERENCES.md` is the tracking table — link the Details column to artifacts as they are produced

## Review workflow

1. Repos are listed in `REFERENCES.md` with current review status
2. Use `gh` CLI to fetch metadata: `gh repo view OWNER/REPO --json name,description,pushedAt,stargazerCount,licenseInfo,isArchived,primaryLanguage,isEmpty`
3. Deep review produces a per-repo artifact in `results/`
4. Update the Details column in `REFERENCES.md` to link to the artifact
5. Cross-reference findings back to `../security-review/CONTEXT.md` threat model

## Tools and skills

- **gh CLI** — GitHub repo metadata and README fetching
- **Claude Haiku/Sonnet/Opus** — Multi-pass security repo review
- **STRIDE threat modeling** — Threat assessment mapping
- **Docker security** — Container hardening knowledge
- **License analysis** — Open source compliance
- **CVE databases** — Vulnerability tracking and assessment

## Naming convention

```text
results/owner-reponame.md
```

Example: `results/slowmist-openclaw-security-practice-guide.md`

## Verdict rubric

- **ADOPT** — install or integrate into our stack
- **REFERENCE** — useful information, not installed
- **WATCH** — promising, needs more evaluation
- **SKIP** — not relevant or not trustworthy

## What to avoid

- Don't review repos with no README and no stars before finishing Tier 1/2 repos
- Don't adopt anything with unclear licensing without flagging it
