#!/usr/bin/env bash
# nuke-stack.sh (legacy) — Destroy all AI stack services, containers, volumes, and config
#
# Canonical entrypoint is ./reset-stack.sh at repo root.
# This internal script is kept for backward compatibility.
#
# Removes:
#   • All containers from root, prod, and test compose stacks
#   • All named Docker volumes (Ollama models, BitNet models, Open WebUI data,
#     Stable Diffusion, SillyTavern, ComfyUI)
#   • NemoClaw sandboxes (hts-ai-assistant-prod, hts-ai-assistant-test)
#   • OpenShell cluster container (openshell-cluster-nemoclaw)
#   • NemoClaw source tree (~/.nemoclaw/) and npm global link
#   • OpenShell binary (/usr/local/bin/openshell)
#   • OpenShell provider registration (bitnet-local)
#   • AI stack Docker networks
#   • Local built Docker image (bitnet-llama3-8b)
#   • Model staging directories (~/models/approved, ~/models/testing)
#   • .env file
#
# Leaves installed: Docker, CUDA, Tailscale, nvm, Ollama binary, packages.
#
# Usage (preferred):
#   ./reset-stack.sh         # prompts for confirmation
#   ./reset-stack.sh --yes   # skip confirmation
#
# Legacy usage still works:
#   ./scripts/utils/nuke-stack.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
# shellcheck source=scripts/install/tooling/ui.sh
source "$REPO_DIR/scripts/install/tooling/ui.sh"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
step()  { echo -e "\n${CYAN}══ $* ══${NC}"; }
fail()  { echo -e "${RED}[FAIL]${NC} $*" >&2; exit 1; }

AUTO_YES=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --yes|-y) AUTO_YES=true; shift ;;
    *) fail "Unknown argument: $1" ;;
  esac
done

htsai_banner "nuke-stack"

echo -e "${RED}This will destroy:${NC}"
echo "  • All AI stack containers (root, prod, test)"
echo "  • All associated Docker volumes"
echo "    (Ollama models, BitNet models, Open WebUI, SD, SillyTavern, ComfyUI)"
echo "  • NemoClaw sandboxes + source tree (~/.nemoclaw/) + npm link"
echo "  • OpenShell binary (/usr/local/bin/openshell) + provider registrations"
echo "  • AI stack Docker containers, volumes, networks"
echo "  • Built Docker image: bitnet-llama3-8b"
echo "  • Model staging directories (~/models/approved, ~/models/testing)"
echo "  • .env"
echo ""
echo -e "${GREEN}Left intact:${NC} Docker, CUDA, Tailscale, nvm, Ollama binary, all packages"
echo ""

if [[ "$AUTO_YES" == false ]]; then
  read -r -p "  Proceed? [y/N]: " confirm
  [[ "${confirm,,}" == "y" || "${confirm,,}" == "yes" ]] || { info "Aborted."; exit 0; }
fi

# ── Step 1: NemoClaw sandboxes ────────────────────────────────────────────────
step "NemoClaw sandboxes"
if command -v nemoclaw &>/dev/null; then
  for sandbox in hts-ai-assistant-prod hts-ai-assistant-test; do
    status_out=$(nemoclaw "$sandbox" status 2>&1) || true
    if echo "$status_out" | grep -qi "unknown command\|no sandboxes\|not found\|not registered"; then
      info "$sandbox — not registered, skipping"
    else
      info "Destroying $sandbox..."
      nemoclaw "$sandbox" destroy --yes 2>/dev/null \
        && ok "$sandbox destroyed" \
        || warn "$sandbox destroy failed (may already be removed)"
    fi
  done
  info "Stopping NemoClaw services..."
  nemoclaw stop 2>/dev/null || true
  ok "NemoClaw services stopped"
else
  info "nemoclaw not in PATH — skipping"
fi

# OpenShell cluster container is managed by NemoClaw directly (not compose).
# Force-remove it if nemoclaw stop left it behind.
for cname in openshell-cluster-nemoclaw openshell-cluster; do
  if docker inspect "$cname" &>/dev/null 2>&1; then
    info "Removing stray OpenShell container: $cname"
    docker stop "$cname" 2>/dev/null || true
    docker rm   "$cname" 2>/dev/null \
      && ok "Removed $cname" \
      || warn "Could not remove $cname"
  fi
done

# ── Step 2: Docker compose stacks ─────────────────────────────────────────────
step "Docker stacks"

compose_down() {
  local label="$1"
  local file="$2"
  if [[ -f "$file" ]]; then
    info "$label..."
    docker compose -f "$file" \
      --profile ollama --profile bitnet \
      down --volumes --remove-orphans --timeout 20 2>/dev/null \
      && ok "$label — removed" \
      || warn "$label — some resources may already be absent"
  else
    warn "$label — compose file not found ($file), skipping"
  fi
}

compose_down "Root stack"  "$REPO_DIR/docker-compose.yml"
compose_down "Prod stack"  "$REPO_DIR/instances/prod/docker-compose.yml"
compose_down "Test stack"  "$REPO_DIR/instances/test/docker-compose.yml"

# ── Step 3: Stray volumes not owned by any compose file ───────────────────────
step "Stray volumes"
STRAY_VOLUMES=(
  hts-ai-stack_jenkins_home
  hts-ai-stack_open-webui
  hts-ai-stack_whisper_cache
  hts-ai-stack_xtts_models
  prod_ollama_prod
  test_ollama_test
)
for vol in "${STRAY_VOLUMES[@]}"; do
  if docker volume inspect "$vol" &>/dev/null 2>&1; then
    docker volume rm "$vol" 2>/dev/null \
      && ok "Removed volume: $vol" \
      || warn "Could not remove volume: $vol"
  fi
done

# ── Step 4: AI-stack Docker networks ──────────────────────────────────────────
step "Docker networks"
for net in hts-ai-stack_ai-network openshell-cluster-nemoclaw; do
  if docker network inspect "$net" &>/dev/null 2>&1; then
    docker network rm "$net" 2>/dev/null \
      && ok "Removed network: $net" \
      || warn "Could not remove $net (may have active endpoints)"
  fi
done

# ── Step 5: Locally built images ──────────────────────────────────────────────
step "Built images"
img="bitnet-llama3-8b"
if docker image inspect "$img" &>/dev/null 2>&1; then
  docker image rm "$img" 2>/dev/null \
    && ok "Removed image: $img" \
    || warn "Could not remove image: $img (may be referenced by another container)"
fi

# ── Step 6: NemoClaw source tree and npm global link ─────────────────────────
step "NemoClaw source + npm link"

# Unlink the global nemoclaw binary installed via `npm link`
if command -v npm &>/dev/null; then
  NPM_PREFIX=$(npm config get prefix 2>/dev/null || true)
  NEMOCLAW_SRC="$HOME/.nemoclaw/source"
  if [[ -d "$NEMOCLAW_SRC" ]]; then
    info "Unlinking global nemoclaw binary..."
    (cd "$NEMOCLAW_SRC" && npm unlink --global 2>/dev/null) \
      && ok "npm unlink done" \
      || warn "npm unlink failed (may already be removed)"
  fi
  # Also remove the bin symlink directly in case npm unlink misses it
  if [[ -n "$NPM_PREFIX" && -L "$NPM_PREFIX/bin/nemoclaw" ]]; then
    rm -f "$NPM_PREFIX/bin/nemoclaw"
    ok "Removed $NPM_PREFIX/bin/nemoclaw symlink"
  fi
fi

if [[ -d "$HOME/.nemoclaw" ]]; then
  rm -rf "$HOME/.nemoclaw"
  ok "Removed ~/.nemoclaw/"
else
  info "$HOME/.nemoclaw not present"
fi

# ── Step 7: OpenShell binary and provider registrations ───────────────────────
step "OpenShell binary + providers"

# Remove registered providers before removing the binary
if command -v openshell &>/dev/null; then
  for provider in bitnet-local ollama-local; do
    if openshell provider list 2>/dev/null | grep -q "$provider"; then
      info "Removing OpenShell provider: $provider"
      openshell provider delete "$provider" 2>/dev/null \
        && ok "Removed provider: $provider" \
        || warn "Could not remove provider: $provider"
    fi
  done
fi

if [[ -f /usr/local/bin/openshell ]]; then
  sudo rm -f /usr/local/bin/openshell
  ok "Removed /usr/local/bin/openshell"
else
  info "openshell not present"
fi

# ── Step 8: Model staging directories ─────────────────────────────────────────
step "Model staging directories"
for dir in "$HOME/models/approved" "$HOME/models/testing"; do
  if [[ -d "$dir" ]]; then
    rm -rf "$dir"
    ok "Removed $dir"
  fi
done
# Remove ~/models itself only if now empty
if [[ -d "$HOME/models" ]] && [[ -z "$(ls -A "$HOME/models" 2>/dev/null)" ]]; then
  rmdir "$HOME/models"
  ok "Removed ~/models (was empty)"
fi

# ── Step 9: .env ──────────────────────────────────────────────────────────────
step ".env"
if [[ -f "$REPO_DIR/.env" ]]; then
  rm -f "$REPO_DIR/.env"
  ok "Removed .env"
else
  info ".env not present"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
ok "Stack nuked."
echo ""
echo "  To rebuild:  ./01-autoinstall.sh → ./06-start-stack.sh"
echo ""
