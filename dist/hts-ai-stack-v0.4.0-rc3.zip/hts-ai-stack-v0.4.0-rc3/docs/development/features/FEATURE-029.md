# Open-Sora — Text-to-Video Generation Service

**Priority:** LOW
**Effort:** 4–8 hours (build time heavy — Flash Attention compile)
**Risk:** ~~Medium~~ → **DISQUALIFIED**
**Target Release:** ~~v0.6.0~~ → Deferred pending hardware upgrade
**Depends on:** CUDA runtime on host
**Blocks:** Nothing

> **⚠️ Hardware Disqualified — RTX 3060 (12GB VRAM)**
>
> Open-Sora v1.3 (1B, the minimum consumer tier) requires **~24GB VRAM**.
> The stack's target GPU (NVIDIA RTX 3060, 12GB) does not meet this requirement.
> This feature is deferred until the hardware baseline is upgraded to ≥24GB VRAM
> (e.g., RTX 3090, RTX 4090, or equivalent).
>
> Re-evaluate when hardware changes. See FEATURE-030 for the same constraint.

## Problem

The stack has no text-to-video generation capability. Open-Sora is the accessible
open-source entry point: the 1B-param v1.3 model runs on consumer RTX 24GB cards,
while the 11B v2.0 model targets high-end hardware. Both support text-to-video (T2V)
and image-to-video (I2V) generation with a Gradio web UI.

## Current State

Not in the stack. `hpcaitech/Open-Sora` is not tracked in feature-repos.
No public Docker image exists — must build from source.

## Architecture

Gradio web UI on port 7862.
Component script auto-selects v1.3 vs v2.0 based on detected VRAM.

```text
  VRAM < 40GB → Open-Sora v1.3 (1B params, consumer RTX)
  VRAM ≥ 40GB → Open-Sora v2.0 (11B params, H100/A100)
```

## Implementation Steps

### P0 — Service

- [ ] **1. Build Dockerfile**
  Create `docker/open-sora/Dockerfile` from source:

  ```dockerfile
  FROM nvidia/cuda:12.3.2-cudnn9-devel-ubuntu22.04
  RUN apt-get update && apt-get install -y git python3-pip ffmpeg
  RUN pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
  RUN pip install flash-attn --no-build-isolation
  RUN git clone https://github.com/hpcaitech/Open-Sora /app && \
      cd /app && pip install -e .
  WORKDIR /app
  EXPOSE 7862
  CMD ["python", "gradio_app.py", "--server-port", "7862", "--server-name", "0.0.0.0"]
  ```

  > **Note:** Flash Attention compilation takes ~20–45 minutes on first build. Cache the
  > built image layer in CI to avoid rebuilding on every deploy.

- [ ] **2. Docker compose service**
  Add `open-sora` service under `profiles: [open-sora]`.

  ```yaml
  open-sora:
    build:
      context: ./docker/open-sora
    image: hts-ai-open-sora
    container_name: hts-ai-open-sora
    profiles: [open-sora]
    restart: unless-stopped
    ports:
      - "${OPEN_SORA_PORT:-7862}:7862"
    environment:
      - OPEN_SORA_VERSION=${OPEN_SORA_VERSION:-v1.3}
    volumes:
      - open-sora-models:/app/pretrained_models
    networks:
      - ai-network
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    healthcheck:
      test: ["CMD", "curl", "-sf", "http://localhost:7862"]
      interval: 60s
      timeout: 30s
      retries: 3
      start_period: 180s
  ```

- [ ] **3. Component script**
  Create `scripts/components/open-sora/open-sora.sh` implementing:
  - `open_sora_install` — build Docker image (with VRAM check)
  - `open_sora_configure` — VRAM check → set `OPEN_SORA_VERSION` in `.env`
    - `<40GB` VRAM → warn; auto-set `OPEN_SORA_VERSION=v1.3`
    - `≥40GB` VRAM → allow v2.0
  - `open_sora_start` — start service + wait for Gradio
  - `open_sora_health` — `curl -sf http://localhost:${OPEN_SORA_PORT}`
  - `open_sora_stop` — stop service

- [ ] **4. Env vars**
  Add to `.env.example`:

  ```text
  OPEN_SORA_PORT=7862
  OPEN_SORA_VERSION=v1.3
  ```

### P1 — Registration

- [ ] **5. Port map** — Add port 7862 to `REFERENCES.md` Host Port Map table.
- [ ] **6. Feature index** — Add row to `docs/development/features/REFERENCES.md`.

## Acceptance Criteria

- `docker compose --profile open-sora build` succeeds (allow 45 min for Flash Attention)
- `docker compose --profile open-sora up` starts the Gradio UI on port 7862
- `open_sora_health` returns success
- T2V generation completes for a short prompt on v1.3 with consumer GPU
- VRAM auto-selection documented in component script

## Related

- [FEATURE-030](FEATURE-030.md) — HunyuanVideo (premium quality video tier)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md) — row: `hpcaitech/Open-Sora`
