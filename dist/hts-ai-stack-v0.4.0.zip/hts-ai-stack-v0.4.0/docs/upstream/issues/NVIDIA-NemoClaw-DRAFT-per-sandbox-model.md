# NVIDIA/NemoClaw — Feature Request: Per-sandbox model override

| Field | Value |
|-------|-------|
| **Repo** | [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) |
| **Issue** | DRAFT — not yet submitted |
| **State** | DRAFT |
| **Severity** | high |
| **Labels** | enhancement |
| **Opened** | — |
| **Subscribed** | — |

## Summary

`openshell inference set --model` applies the model globally to the entire
gateway. All sandboxes under that gateway are forced to use the same model.
There is no mechanism to assign different models to different sandboxes within
the same gateway.

This prevents a common multi-sandbox pattern: running one sandbox on a GPU
model (e.g. `gemma4:e4b` via Ollama) and another on a CPU model (e.g.
`bitnet` via BitNet) through a shared llama-swap router.

## Observed behavior

```bash
# Set model for "GPU sandbox" — applies to ALL sandboxes on the gateway
openshell inference set --model gemma4:e4b -g nemoclaw

# Both sandboxes now use gemma4:e4b — no way to set bitnet for the CPU sandbox
```

The gateway-level model is set in `gateway-state.js` and pushed to every
sandbox uniformly. NemoClaw also hardcodes the gateway name to `"nemoclaw"`
in `gateway-state.js:20` and `onboard.js:103`, preventing a workaround via
multiple gateways.

## Expected behavior

Either:

1. **Per-sandbox model override:** Allow `openshell inference set --model <model> --sandbox <name>` to set a model for a specific sandbox, overriding the gateway default.
2. **Multi-gateway support in NemoClaw:** Allow NemoClaw to manage multiple named gateways so different sandbox groups can have different model configurations.

Option 1 is preferred — it keeps the single-gateway simplicity while enabling
heterogeneous sandbox deployments.

## Impact on us

We removed the CPU NemoClaw sandbox (`hts-ai-assistant-cpu`) from our
installer because the single-model-per-gateway limitation made it
non-functional with a different model than the GPU sandbox.

Our dual-backend infrastructure (Ollama GPU + BitNet CPU fronted by
llama-swap) remains operational — but only the GPU sandbox can use it
through NemoClaw. CPU agent sandbox capabilities are being evaluated
through alternative technologies (gVisor, Daytona).

## Workaround

Currently none within NemoClaw. We are evaluating:

- **gVisor** (FEATURE-012): Docker runtime `runsc` with syscall-level isolation
- **Daytona** (FEATURE-013): Devcontainer-based workspaces with hermes-agent

Both bypass the NemoClaw/OpenShell gateway entirely for the CPU sandbox.

## Environment

- NemoClaw CLI: v0.0.10
- OpenClaw: 2026.3.11
- OpenShell gateway: containerd microVMs in k3s
- Host: Ubuntu 24.04, Docker with NVIDIA Container Toolkit
- GPU: RTX 3060 12GB

## GitHub issue draft

```markdown
### Feature Request: Per-sandbox model override

**Is your feature request related to a problem?**

`openshell inference set --model` applies globally to the entire gateway.
All sandboxes under that gateway use the same model. There is no way to
assign different models to different sandboxes.

This blocks a common pattern: running heterogeneous sandboxes with
different inference backends (e.g. one GPU sandbox using `gemma4:e4b`
via Ollama, one CPU sandbox using `bitnet` via BitNet) through a shared
llama-swap router.

**Describe the solution you'd like**

A per-sandbox model override, e.g.:

```bash
openshell inference set --model gemma4:e4b --sandbox hts-ai-openshell-nemoclaw-gpu -g nemoclaw
openshell inference set --model bitnet --sandbox hts-ai-assistant-cpu -g nemoclaw
```

This would override the gateway-level default for that specific sandbox
while keeping the current behavior as the fallback.

### Alternatives considered

- **Multiple gateways:** OpenShell supports multiple gateways, but
  NemoClaw hardcodes the gateway name to `"nemoclaw"` in
  `gateway-state.js` and `onboard.js`, making this impractical.
- **External sandbox technologies:** We are evaluating gVisor and
  Daytona as alternatives that bypass NemoClaw entirely for CPU
  sandboxes, but this loses NemoClaw's policy enforcement.

### Environment

- NemoClaw CLI v0.0.10
- OpenClaw 2026.3.11
- Ubuntu 24.04, Docker + NVIDIA Container Toolkit

```text
# NemoClaw + OpenClaw runtime
```

## Status log

- **2026-04-09** — Draft created after discovering the limitation during dual-sandbox implementation.
