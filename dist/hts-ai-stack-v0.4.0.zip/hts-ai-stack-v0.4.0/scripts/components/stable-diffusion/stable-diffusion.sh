#!/usr/bin/env bash
# scripts/components/stable-diffusion/stable-diffusion.sh — Stable Diffusion: image gen setup, checkpoints, NAS cache
#
# Standalone usage:
#   ./scripts/components/stable-diffusion/stable-diffusion.sh                # full: install + configure + start + health
#   ./scripts/components/stable-diffusion/stable-diffusion.sh --install      # install only
#   ./scripts/components/stable-diffusion/stable-diffusion.sh --configure    # configure only
#   ./scripts/components/stable-diffusion/stable-diffusion.sh --start        # start only
#   ./scripts/components/stable-diffusion/stable-diffusion.sh --stop         # stop
#   ./scripts/components/stable-diffusion/stable-diffusion.sh --restart      # restart (stop + start)
#   ./scripts/components/stable-diffusion/stable-diffusion.sh --health       # health check only
#   ./scripts/components/stable-diffusion/stable-diffusion.sh --status       # show status + port + health
#   ./scripts/components/stable-diffusion/stable-diffusion.sh --destroy      # destroy (remove containers + volumes)
#   ./scripts/components/stable-diffusion/stable-diffusion.sh --download     # download checkpoints only
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"
source "$REPO_DIR/scripts/lib/model.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
SD_PORT="${SD_PORT:-7860}"
SD_CONTAINER="${SD_CONTAINER:-hts-ai-stable-diffusion}"
SD_USE_EXTERNAL="${SD_USE_EXTERNAL:-false}"
NAS_SD_CACHE="${NAS_SD_CACHE:-/mnt/htsai-model-backup/stable-diffusion/checkpoints}"
SD_CHECKPOINT="${SD_CHECKPOINT:-dreamshaper_v8.safetensors}"
SD_VAE="${SD_VAE:-}"
IMAGES_ENABLED="${IMAGES_ENABLED:-false}"

# ── Functions ─────────────────────────────────────────────────────────────────

# sd_install — Pull the SD Docker image via compose
sd_install() {
  step "Stable Diffusion — build image"
  compose_build --profile sd
  ok "Stable Diffusion image built."
}

# sd_configure — Ensure .env has SD-related vars
sd_configure() {
  step "Stable Diffusion — configure"
  local env_file="$REPO_DIR/.env"

  _ensure_key() {
    local key="$1" default="$2"
    if ! grep -q "^${key}=" "$env_file" 2>/dev/null; then
      printf '%s=%s\n' "$key" "$default" >> "$env_file"
      info "Added ${key}=${default} to .env"
    fi
  }

  _ensure_key "SD_PORT" "$SD_PORT"
  _ensure_key "IMAGES_ENABLED" "$IMAGES_ENABLED"
  _ensure_key "SD_CHECKPOINT" "$SD_CHECKPOINT"
  _ensure_key "SD_VAE" "$SD_VAE"
  ok "Stable Diffusion .env keys verified."
}

# sd_start — Bring up SD via compose
sd_start() {
  step "Stable Diffusion — start"
  if [[ "$SD_USE_EXTERNAL" == "true" ]]; then
    info "Using external Stable Diffusion — skipping local start."
    return 0
  fi
  compose_up --profile sd
  ok "Stable Diffusion container started."
}

# sd_stop — Bring down SD
sd_stop() {
  step "Stable Diffusion — stop"
  compose_down --profile sd
  ok "Stable Diffusion stopped."
}

# sd_health — Probe the SD web UI.
# First-start bootstrap (pip resolution, optional checkpoint download) can
# take many minutes even with repos prebaked in the image, so we extend the
# probe well past the default 60 s → 15 min (180 attempts × 5 s).
sd_health() {
  health_probe "Stable Diffusion :${SD_PORT}" "http://localhost:${SD_PORT}" 180 5
}

# sd_download_models — Download checkpoints from registry or NAS cache
sd_download_models() {
  step "Stable Diffusion — download models"

  if [[ "$IMAGES_ENABLED" != "true" ]]; then
    info "Image generation disabled (IMAGES_ENABLED!=true) — skipping model download."
    return 0
  fi

  # Find (or create) the SD volume
  local sd_volume
  sd_volume=$(docker volume ls --format '{{.Name}}' | grep "sd_models" | head -1 || true)
  if [[ -z "$sd_volume" ]]; then
    info "SD volume not found — starting SD container briefly to create it..."
    compose_up --profile sd
    sleep 5
    sd_volume=$(docker volume ls --format '{{.Name}}' | grep "sd_models" | head -1 || true)
    if [[ -z "$sd_volume" ]]; then
      warn "Could not find or create SD volume. Run docker compose up first."
      return 1
    fi
  fi

  info "Using volume: $sd_volume"

  # Download required checkpoint
  model_download_if_missing "stable_diffusion" "checkpoint" "$SD_CHECKPOINT" "$sd_volume" "$NAS_SD_CACHE"

  # Download optional VAE if set
  if [[ -n "$SD_VAE" ]]; then
    model_download_if_missing "stable_diffusion" "vae" "$SD_VAE" "$sd_volume" "$NAS_SD_CACHE"
  fi

  ok "Model download complete."
}

# ── Internal helpers ──────────────────────────────────────────────────────────



sd_restart() {
  sd_stop
  sd_start
}

sd_destroy() {
  step "Stable Diffusion — destroy"
  compose_down --profile sd -v
  ok "Stable Diffusion destroyed."
}

sd_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=stable-diffusion" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Stable Diffusion is running (port ${SD_PORT})"
  else
    warn "Stable Diffusion is not running."
  fi
  sd_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      --download)  ACTION="download";  shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   sd_install        ;;
    configure) sd_configure      ;;
    start)     sd_start          ;;
    stop)      sd_stop           ;;
    restart)   sd_restart        ;;
    health)    sd_health         ;;
    status)    sd_status         ;;
    destroy)   sd_destroy        ;;
    download)  sd_download_models ;;
    default)
      sd_install
      sd_configure
      sd_start
      sd_health
      ;;
  esac
fi
