$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:IssuesDir = Join-Path $script:RepoRoot 'docs/development/issues'
}

Describe 'Issue hygiene' {

    BeforeAll {
        # Collect shipped git tags
        $script:ShippedTags = @()
        try {
            $script:ShippedTags = git -C $script:RepoRoot tag --list 'v*' |
                ForEach-Object { $_.Trim() } |
                Where-Object { $_ -match '^v\d+\.\d+\.\d+$' }
        } catch { }

        # Parse issue blocks from individual ISSUE-###.md files
        $script:Issues = [System.Collections.Generic.List[hashtable]]::new()

        $issueFiles = Get-ChildItem -Path $script:IssuesDir -Filter 'ISSUE-*.md' -ErrorAction SilentlyContinue
        foreach ($file in $issueFiles) {
            $id = $file.BaseName
            $lines = Get-Content $file.FullName
            $current = @{
                Id            = $id
                Date          = ''
                Area          = ''
                Status        = ''
                ReviewBy      = ''
                TargetRelease = ''
                Raw           = [System.Collections.Generic.List[string]]::new()
            }
            foreach ($line in $lines) {
                $current.Raw.Add($line)
                if ($line -match '^\*\*Date:\*\*\s*(.+)') { $current.Date = $Matches[1].Trim() }
                if ($line -match '^\*\*Area:\*\*\s*(.+)') { $current.Area = $Matches[1].Trim() }
                if ($line -match '^\*\*Status:\*\*\s*(.+)') { $current.Status = $Matches[1].Trim() }
                if ($line -match '^\*\*Review by:\*\*\s*(.+)') { $current.ReviewBy = $Matches[1].Trim() }
                if ($line -match '^\*\*Target Release:\*\*\s*(.+)') { $current.TargetRelease = $Matches[1].Trim() }
                # Also support legacy dash-prefixed format
                if ($line -match '^\s*-\s*Date:\s*(.+)') { if (-not $current.Date) { $current.Date = $Matches[1].Trim() } }
                if ($line -match '^\s*-\s*Area:\s*(.+)') { if (-not $current.Area) { $current.Area = $Matches[1].Trim() } }
                if ($line -match '^\s*-\s*Status:\s*(.+)') { if (-not $current.Status) { $current.Status = $Matches[1].Trim() } }
                if ($line -match '^\s*-\s*Review by:\s*(.+)') { if (-not $current.ReviewBy) { $current.ReviewBy = $Matches[1].Trim() } }
                if ($line -match '^\s*-\s*Target Release:\s*(.+)') { if (-not $current.TargetRelease) { $current.TargetRelease = $Matches[1].Trim() } }
            }
            $script:Issues.Add($current)
        }

        # Classify issues by status
        $script:OpenIssues = $script:Issues | Where-Object {
            $_.Status -match 'open' -and $_.Status -notmatch 'fixed|closed|upstream'
        }
        $script:PendingReview = $script:Issues | Where-Object {
            $_.Status -match 'fixed-pending-review'
        }

        # ---- Check: required metadata ----
        $script:MissingMetadata = [System.Collections.Generic.List[string]]::new()
        foreach ($issue in $script:Issues) {
            $missing = @()
            if (-not $issue.Date)   { $missing += 'Date' }
            if (-not $issue.Area)   { $missing += 'Area' }
            if (-not $issue.Status) { $missing += 'Status' }
            if ($missing.Count -gt 0) {
                $script:MissingMetadata.Add("$($issue.Id) missing: $($missing -join ', ')")
            }
        }

        # ---- Check: fixed-pending-review needs Review by ----
        $script:MissingReviewBy = [System.Collections.Generic.List[string]]::new()
        foreach ($issue in $script:PendingReview) {
            if (-not $issue.ReviewBy) {
                $script:MissingReviewBy.Add("$($issue.Id) is fixed-pending-review but has no Review by date")
            }
        }

        # ---- Check: open issues need a Target Release ----
        $script:MissingTargetRelease = [System.Collections.Generic.List[string]]::new()
        foreach ($issue in $script:OpenIssues) {
            if (-not $issue.TargetRelease) {
                $script:MissingTargetRelease.Add($issue.Id)
            }
        }

        # ---- Check: no open issue targets a shipped tag ----
        $script:ShippedTargets = [System.Collections.Generic.List[string]]::new()
        foreach ($issue in $script:OpenIssues) {
            if ($issue.TargetRelease -match '(v\d+\.\d+\.\d+)') {
                $ver = $Matches[1]
                if ($script:ShippedTags -contains $ver) {
                    $script:ShippedTargets.Add("$($issue.Id) targets $ver which is already shipped")
                }
            }
        }
    }

    It 'issue files exist' {
        $script:Issues.Count | Should -BeGreaterThan 0 -Because 'at least one ISSUE-###.md file should exist in docs/development/issues/'
    }

    It 'all issues have required metadata (Date, Area, Status)' {
        if ($script:MissingMetadata.Count -gt 0) {
            $detail = $script:MissingMetadata -join "`n  "
            "Incomplete issues:`n  $detail" | Should -Be '' -Because 'every issue must have Date, Area, and Status fields filled in'
        }
    }

    It 'fixed-pending-review issues have a Review by date' {
        if ($script:MissingReviewBy.Count -gt 0) {
            $detail = $script:MissingReviewBy -join "`n  "
            "Missing Review by:`n  $detail" | Should -Be '' -Because 'fixed-pending-review issues must include a Review by date for accountability'
        }
    }

    It 'open issues have a Target Release version' {
        if ($script:MissingTargetRelease.Count -gt 0) {
            $detail = $script:MissingTargetRelease -join "`n  "
            "Untagged open issues:`n  $detail" | Should -Be '' -Because 'open issues must declare a Target Release (e.g. v0.5.0 or Unscheduled) — close or archive issues that no longer apply'
        }
    }

    It 'no open issue targets an already-shipped git tag' {
        if ($script:ShippedTargets.Count -gt 0) {
            $detail = $script:ShippedTargets -join "`n  "
            "Stale issues:`n  $detail" | Should -Be '' -Because 'open issues must not target a release that has already shipped — update Target Release or close the issue'
        }
    }
}
