# Aider Component — CONTEXT

## What is Aider?

Aider is an open-source AI pair-programming tool that runs in the terminal
and edits files directly in a local git repository. It generates diffs,
applies them to the working tree, optionally runs tests, and can
auto-commit changes. It talks to any OpenAI-compatible endpoint, which is
how it integrates with local inference.

- Source: <https://github.com/Aider-AI/aider>
- Docs: <https://aider.chat>
- Install docs: <https://aider.chat/docs/install.html>

## How it fits into the HTS AI Stack

A host-installed CLI (not a containerized service). Developers invoke
`aider` inside any git-tracked project directory to edit code with
LLM assistance. Model calls route through the local inference stack
(intended target: llama-swap's OpenAI-compatible endpoint).

```text
Developer terminal  →  aider (host CLI)  →  llama-swap :<port>/v1  →  ollama/bitnet
```

No GPU is required by Aider itself — all inference is external.

## Install method

Host install via **pipx** (vendor-recommended). See
<https://aider.chat/docs/install.html>.

- Primary path: `pipx install aider-chat`
- Fallback: `python3 -m pip install --user aider-chat`

This follows Aider's official instructions; it is **not** a vendor
deviation. See `DEVIATIONS.md` — there is nothing to record there for
Aider install.

### Why host-installed and not containerized?

Aider is a long-lived interactive terminal UX that watches local files,
edits them in place, and runs tests inside the user's git working tree.
The upstream project ships and supports it as a host CLI (same category
as `git`, `gh`, or `claude` CLI). Containerizing would require
bind-mounting the active project tree and the user's shell, with
non-trivial UX and permission cost, for no security gain on a
single-user developer workstation.

This is a considered exception to the stack's general
"containerize-if-possible" preference, not a vendor-instruction
deviation. If/when upstream ships an officially supported container
image, revisit.

## Tier placement

Order 181 — `extras` / Developer Tools section. Grouped with the other
developer-CLI tools (OpenCode, etc.). Listed in `docker-compose.yml`
only as a metadata no-op; the component script is driven directly by
`converge.sh`.

## LLM routing — important

Aider uses LiteLLM under the hood, so the same model-name-prefix
conventions as other LiteLLM-based components in this stack apply. The
current `aider_configure` writes a minimal single-model config pointing
at Ollama directly; FEATURE-067 upgrades this to a two-tier
architect+editor config routed through llama-swap (OpenAI-compatible),
for consistency with CrewAI and Open WebUI.

Summary of the intended config shape (see `FEATURE-067.md` for detail):

```yaml
openai-api-base: http://localhost:${LLAMA_SWAP_PORT}/v1
openai-api-key: dummy
model: openai/qwen2.5-coder:7b
architect-model: openai/deepseek-r1:14b
architect: true
auto-commits: false
```

Model names must carry the `openai/` prefix or LiteLLM will try to call
openai.com and fail with an auth error. The portion after the prefix is
the exact Ollama tag (colon and all) and must match an entry under
`peers.ollama.models` in `config/llama-swap.yaml`.

`LLAMA_SWAP_PORT` defaults to `8081` on the host (see `.env`).

## Persistence

Aider stores its config and history on the host under the invoking
user's home directory — nothing lives in Docker volumes for this
component:

```text
~/.aider.conf.yml       — global config (written by aider_configure)
~/.aider.chat.history.md — chat history (per-repo, created by aider)
~/.aider.input.history   — prompt history
```

Per-repo state (e.g. `.aider.tags.cache.v3/`) is written inside each
project the user runs `aider` in.

## Related components

- `llama-swap` (40) — preferred local inference backend for Aider
- `ollama` (10) — model provider behind llama-swap
- `opencode` — alternative terminal coding agent
- `crewai` (122) — multi-agent orchestration (different use case: prose/research crews)

See [usage.md](./usage.md) for command usage.
