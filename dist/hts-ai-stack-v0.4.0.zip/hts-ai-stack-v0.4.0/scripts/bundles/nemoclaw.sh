#!/usr/bin/env bash
# scripts/bundles/nemoclaw.sh — Sandbox agent runtime bundle
#
# Sets up the inference backend, NemoClaw sandbox agent, and dashboard.
#
# Usage:
#   ./scripts/bundles/nemoclaw.sh
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "NemoClaw Bundle"
load_env

DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-true}"

# ── Services (dual-backend + llama-swap) ──────────────────────────────────────
step "Backend"
bash "$REPO_DIR/scripts/components/ollama/ollama.sh"
bash "$REPO_DIR/scripts/components/bitnet/bitnet.sh"
bash "$REPO_DIR/scripts/components/llama-swap/llama-swap.sh"

step "NemoClaw"
bash "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh"

if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/components/dashboard/dashboard.sh"
fi

echo ""
ok "NemoClaw bundle ready — dual-backend (GPU+CPU)"
