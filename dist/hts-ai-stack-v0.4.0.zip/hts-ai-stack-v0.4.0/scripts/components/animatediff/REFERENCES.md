# AnimateDiff — References

## Upstream

- **Paper**: <https://arxiv.org/abs/2307.04725>
- **Source**: <https://github.com/guoyww/AnimateDiff>
- **HuggingFace**: <https://huggingface.co/guoyww/animatediff-motion-adapter-v1-5-3>
- **Diffusers integration**: <https://huggingface.co/docs/diffusers/api/pipelines/animatediff>

## Notes

- Apache-2.0 license
- Works with existing SD1.5 LoRAs and textual inversions
- Motion modules are lightweight adapters (~1.8GB)
- Can also run inside ComfyUI via AnimateDiff-Evolved nodes
