# Blender — Component Context

## Purpose

Blender is a free and open-source 3D creation suite. It supports the full
3D pipeline: modeling, rigging, animation, simulation, rendering,
compositing, motion tracking, and video editing. Cycles renderer supports
CUDA GPU acceleration for fast rendering on NVIDIA hardware.

## Location

`scripts/components/blender/` — component directory

## Key Files

| File | Purpose |
|------|---------|
| `blender.manifest.json` | Convergence manifest |
| `blender.sh` | Install / configure / health script |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and notes |

## Notes

- Installed via **snap** (official Blender distribution channel)
- Desktop application — no Docker service or web UI
- Cycles render engine supports CUDA for GPU-accelerated rendering
- NVIDIA drivers must be installed (handled by bootstrap.sh)
