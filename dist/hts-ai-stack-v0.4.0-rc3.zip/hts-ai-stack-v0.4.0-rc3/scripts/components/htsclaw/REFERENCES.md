# htsclaw References

Last updated: 2026-04-15

## Upstream

- No upstream repository — htsclaw is an internal component built as
  part of the hts-ai-stack project.

## Related

- [NemoClaw](../nemoclaw/REFERENCES.md) — the NVIDIA-managed sandbox
  that htsclaw was designed to complement or replace.
