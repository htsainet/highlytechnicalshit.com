# llama-swap References

Last updated: 2026-04-15

## Upstream

- [GitHub — mostlygeek/llama-swap](https://github.com/mostlygeek/llama-swap)

## Official documentation

- [llama-swap README](https://github.com/mostlygeek/llama-swap#readme)
