$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/htsclaw'
    $script:ComponentScript = Join-Path $script:ComponentDir 'htsclaw.sh'
    $script:HtsclawDir = Join-Path $script:RepoRoot 'scripts/htsclaw'
    $script:BundleScript = Join-Path $script:RepoRoot 'scripts/bundles/htsclaw.sh'
    $script:HealthScript = Join-Path $script:RepoRoot 'scripts/htsclaw/health/health.sh'
    $script:DispatchScript = Join-Path $script:RepoRoot 'scripts/install/04-setup-nemoclaw.sh'
    $script:ApplyConfig = Join-Path $script:RepoRoot 'config/wizard/apply_config.sh'
    $script:WizardScript = Join-Path $script:RepoRoot 'config/wizard/ai_stack_setup.sh'
    $script:StackJsonExample = Join-Path $script:RepoRoot 'config/stack.json.example'
}

# ── Subsystem scripts ───────────────────────────────────────────────────────

Describe 'htsclaw subsystem scripts' {

    It '<_> exists' -ForEach @(
        'sandbox/lifecycle.sh',
        'sandbox/provider.sh',
        'sandbox/firewall.sh',
        'health/health.sh',
        'personas/provision.sh',
        'menus/htsclaw-menu.py',
        'dashboard/tokens.sh'
    ) {
        Join-Path $script:HtsclawDir $_ | Should -Exist
    }
}

# ── Component sources subsystems ─────────────────────────────────────────────

Describe 'htsclaw subsystem sourcing' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'sources sandbox/lifecycle.sh' {
        $script:ComponentContent | Should -Match 'source.*sandbox/lifecycle\.sh'
    }

    It 'sources sandbox/provider.sh' {
        $script:ComponentContent | Should -Match 'source.*sandbox/provider\.sh'
    }

    It 'sources sandbox/firewall.sh' {
        $script:ComponentContent | Should -Match 'source.*sandbox/firewall\.sh'
    }

    It 'sources health/health.sh' {
        $script:ComponentContent | Should -Match 'source.*health/health\.sh'
    }

    It 'sources personas/provision.sh' {
        $script:ComponentContent | Should -Match 'source.*personas/provision\.sh'
    }

    It 'sources dashboard/tokens.sh' {
        $script:ComponentContent | Should -Match 'source.*dashboard/tokens\.sh'
    }

    It 'sources dashboard/origins.sh' {
        $script:ComponentContent | Should -Match 'source.*dashboard/origins\.sh'
    }

    It 'respects HTSCLAW_DEPLOY flag in htsclaw_start' {
        $script:ComponentContent | Should -Match 'HTSCLAW_DEPLOY.*!=.*true'
    }
}

# ── Bundle script ────────────────────────────────────────────────────────────

Describe 'htsclaw bundle orchestration' {

    BeforeAll {
        $script:BundleContent = Get-Content -Path $script:BundleScript -Raw
    }

    It 'bundle script exists' {
        $script:BundleScript | Should -Exist
    }

    It 'invokes ollama, bitnet, and llama-swap before htsclaw component' {
        $ollamaPos = $script:BundleContent.IndexOf('components/ollama.sh')
        $bitnetPos = $script:BundleContent.IndexOf('components/bitnet.sh')
        $llamaSwapPos = $script:BundleContent.IndexOf('components/llama-swap.sh')
        $htsclawPos = $script:BundleContent.IndexOf('components/htsclaw.sh')

        $ollamaPos | Should -BeGreaterThan -1 -Because 'bundle should invoke ollama'
        $bitnetPos | Should -BeGreaterThan -1 -Because 'bundle should invoke bitnet'
        $llamaSwapPos | Should -BeGreaterThan -1 -Because 'bundle should invoke llama-swap'
        $htsclawPos | Should -BeGreaterThan -1 -Because 'bundle should invoke htsclaw'

        $ollamaPos | Should -BeLessThan $htsclawPos -Because 'ollama must precede htsclaw'
        $bitnetPos | Should -BeLessThan $htsclawPos -Because 'bitnet must precede htsclaw'
        $llamaSwapPos | Should -BeLessThan $htsclawPos -Because 'llama-swap must precede htsclaw'
    }

    It 'conditionally invokes dashboard' {
        $script:BundleContent | Should -Match 'DASHBOARD_ENABLED.*==.*true'
        $script:BundleContent | Should -Match 'dashboard\.sh'
    }
}

# ── Health script ────────────────────────────────────────────────────────────

Describe 'htsclaw health script' {

    BeforeAll {
        $script:HealthContent = Get-Content -Path $script:HealthScript -Raw
    }

    It 'defines htsclaw_health function' {
        $script:HealthContent | Should -Match 'htsclaw_health\s*\(\)'
    }

    It 'defines htsclaw_install_health_timer function' {
        $script:HealthContent | Should -Match 'htsclaw_install_health_timer\s*\(\)'
    }

    It 'defines htsclaw_health_timer_status function' {
        $script:HealthContent | Should -Match 'htsclaw_health_timer_status\s*\(\)'
    }

    It 'returns non-zero when health checks fail' {
        $script:HealthContent | Should -Match 'Some htsclaw health checks failed[\s\S]*?return 1'
    }

    It 'uses the correct systemd service name' {
        $script:HealthContent | Should -Match 'hts-htsclaw-health'
    }

    It 'configures a 5-minute timer interval' {
        $script:HealthContent | Should -Match 'OnUnitActiveSec=5min'
    }

    It 'uses default port 18790' {
        $script:HealthContent | Should -Match 'HTSCLAW_PORT.*18790'
    }
}

# ── Install pipeline dispatcher ──────────────────────────────────────────────

Describe 'sandbox engine dispatcher (04-setup-nemoclaw.sh)' {

    BeforeAll {
        $script:DispatchContent = Get-Content -Path $script:DispatchScript -Raw
    }

    It 'reads SANDBOX_ENGINE variable' {
        $script:DispatchContent | Should -Match 'SANDBOX_ENGINE'
    }

    It 'routes htsclaw to components/htsclaw.sh' {
        $script:DispatchContent | Should -Match 'htsclaw\)[\s\S]*?components/htsclaw\.sh'
    }

    It 'routes nemoclaw to components/nemoclaw.sh' {
        $script:DispatchContent | Should -Match 'nemoclaw\)[\s\S]*?components/nemoclaw\.sh'
    }

    It 'handles "none" by skipping' {
        $script:DispatchContent | Should -Match 'none\)'
        $script:DispatchContent | Should -Match 'skipping'
    }

    It 'routes "both" to htsclaw then nemoclaw' {
        $script:DispatchContent | Should -Match 'both\)[\s\S]*?htsclaw\.sh[\s\S]*?nemoclaw\.sh'
    }

    It 'handles unknown engines gracefully' {
        $script:DispatchContent | Should -Match '\*\)'
    }

    It 'defaults to nemoclaw for backward compatibility' {
        $script:DispatchContent | Should -Match 'SANDBOX_ENGINE="\$\{SANDBOX_ENGINE:-nemoclaw\}'
    }
}

# ── Config integration ───────────────────────────────────────────────────────

Describe 'sandbox config integration' {

    Context 'stack.json.example' {
        BeforeAll {
            $script:ExampleJson = Get-Content -Path $script:StackJsonExample -Raw |
                ConvertFrom-Json
        }

        It 'has a sandbox.engine key' {
            $script:ExampleJson.sandbox.engine | Should -Not -BeNullOrEmpty
        }

        It 'defaults sandbox.engine to htsclaw' {
            $script:ExampleJson.sandbox.engine | Should -Be 'htsclaw'
        }

        It 'has a sandbox.agent_personas key' {
            $script:ExampleJson.sandbox.agent_personas | Should -Not -BeNullOrEmpty
        }
    }

    Context 'wizard defaults' {
        BeforeAll {
            $script:WizardContent = Get-Content -Path $script:WizardScript -Raw
        }

        It 'declares SANDBOX_ENGINE default' {
            $script:WizardContent | Should -Match 'SANDBOX_ENGINE="htsclaw"'
        }

        It 'declares SANDBOX_AGENT_PERSONAS default' {
            $script:WizardContent | Should -Match 'SANDBOX_AGENT_PERSONAS="true"'
        }

        It 'exports SANDBOX_ENGINE' {
            $script:WizardContent | Should -Match 'export SANDBOX_ENGINE'
        }

        It 'exports SANDBOX_AGENT_PERSONAS' {
            $script:WizardContent | Should -Match 'export SANDBOX_AGENT_PERSONAS'
        }

        It 'presents a menu with htsclaw, nemoclaw, both, and none choices' {
            $script:WizardContent | Should -Match '"htsclaw"'
            $script:WizardContent | Should -Match '"nemoclaw"'
            $script:WizardContent | Should -Match '"both"'
            $script:WizardContent | Should -Match '"none"'
        }

        It 'writes sandbox.engine to JSON output' {
            $script:WizardContent | Should -Match '"engine".*SANDBOX_ENGINE'
        }
    }

    Context 'apply_config reads sandbox config' {
        BeforeAll {
            $script:ApplyContent = Get-Content -Path $script:ApplyConfig -Raw
        }

        It 'reads sandbox_engine from config' {
            $script:ApplyContent | Should -Match 'sandbox.*engine'
        }

        It 'sets SANDBOX_ENGINE env var' {
            $script:ApplyContent | Should -Match '"SANDBOX_ENGINE"'
        }

        It 'sets HTSCLAW_DEPLOY env var' {
            $script:ApplyContent | Should -Match '"HTSCLAW_DEPLOY"'
        }

        It 'sets HTSCLAW_AGENT_PERSONAS env var' {
            $script:ApplyContent | Should -Match '"HTSCLAW_AGENT_PERSONAS"'
        }

        It 'sets HTSCLAW_DEPLOY for both htsclaw and both engines' {
            $script:ApplyContent | Should -Match 'htsclaw.*both'
        }

        It 'sets NEMOCLAW_DEPLOY for both nemoclaw and both engines' {
            $script:ApplyContent | Should -Match 'nemoclaw.*both'
        }

        It 'migrates legacy nemoclaw-only config' {
            $script:ApplyContent | Should -Match 'nemoclaw.*if.*nemoclaw_deploy'
        }
    }
}

# ── Extended port allocation ─────────────────────────────────────────────────

Describe 'htsclaw extended port allocation' {

    BeforeAll {
        $script:ReferencesContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'REFERENCES.md') -Raw
        $script:ConflictsContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'scripts/install/00-check-conflicts.sh') -Raw
    }

    It 'port 18790 is registered in REFERENCES.md port map' {
        $script:ReferencesContent | Should -Match '18790.*htsclaw'
    }

    It 'port 8083 is registered in REFERENCES.md port map' {
        $script:ReferencesContent | Should -Match '8083.*htsclaw'
    }

    It 'port 18790 does not collide with Daytona' {
        $script:ReferencesContent | Should -Not -Match '18790.*[Dd]aytona'
    }

    It '00-check-conflicts.sh checks port 18790' {
        $script:ConflictsContent | Should -Match '18790'
    }

    It '00-check-conflicts.sh checks port 8083' {
        $script:ConflictsContent | Should -Match '8083'
    }
}
