#!/usr/bin/env bash
# scripts/components/handbrake/handbrake.sh — HandBrake: install, configure, health
#
# Host-native installer for HandBrake video transcoder.
# Supports NVENC/VAAPI hardware encoding for fast GPU-accelerated transcoding.
#
# Standalone usage:
#   ./scripts/components/handbrake/handbrake.sh              # full: install + configure + health
#   ./scripts/components/handbrake/handbrake.sh --install    # install only
#   ./scripts/components/handbrake/handbrake.sh --configure  # configure only
#   ./scripts/components/handbrake/handbrake.sh --start      # no-op (desktop app)
#   ./scripts/components/handbrake/handbrake.sh --stop       # no-op (desktop app)
#   ./scripts/components/handbrake/handbrake.sh --restart    # no-op (desktop app)
#   ./scripts/components/handbrake/handbrake.sh --health     # health check only
#   ./scripts/components/handbrake/handbrake.sh --status     # show status + health
#   ./scripts/components/handbrake/handbrake.sh --destroy    # uninstall HandBrake
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# ── Functions ────────────────────────────────────────────────────────────────

handbrake_install() {
  step "HandBrake — install"
  if command -v ghb &>/dev/null || command -v HandBrakeCLI &>/dev/null; then
    skip "HandBrake already installed."
  else
    info "Installing HandBrake..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq handbrake handbrake-cli
    ok "HandBrake installed."
  fi
}

handbrake_configure() {
  step "HandBrake — configure"
  info "Launch HandBrake from the desktop to configure encoding presets."
  info "NVENC hardware encoding available with NVIDIA GPU."
  ok "HandBrake configured."
}

handbrake_start() {
  step "HandBrake — start"
  info "Desktop application — launch from your desktop environment."
  ok "HandBrake start complete."
}

handbrake_stop() {
  step "HandBrake — stop"
  info "Desktop application — close from the GUI."
  ok "HandBrake stop complete."
}

handbrake_health() {
  local label="HandBrake"
  printf "  %-35s" "$label"
  if command -v ghb &>/dev/null || command -v HandBrakeCLI &>/dev/null; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (handbrake not found in PATH)"
    return 1
  fi
}

handbrake_restart() {
  handbrake_stop
  handbrake_start
}

handbrake_destroy() {
  step "HandBrake — destroy"
  sudo apt-get remove -y handbrake handbrake-cli 2>/dev/null || true
  sudo apt-get autoremove -y -qq
  ok "HandBrake removed."
}

handbrake_status() {
  step "HandBrake — status"
  if command -v ghb &>/dev/null; then
    ok "HandBrake GUI installed"
  else
    warn "HandBrake GUI NOT installed"
  fi
  if command -v HandBrakeCLI &>/dev/null; then
    ok "HandBrakeCLI installed"
  else
    warn "HandBrakeCLI NOT installed"
  fi
  handbrake_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   handbrake_install   ;;
    configure) handbrake_configure ;;
    start)     handbrake_start     ;;
    stop)      handbrake_stop      ;;
    restart)   handbrake_restart   ;;
    health)    handbrake_health    ;;
    status)    handbrake_status    ;;
    destroy)   handbrake_destroy   ;;
    default)
      handbrake_install
      handbrake_configure
      handbrake_health
      ;;
  esac
fi
