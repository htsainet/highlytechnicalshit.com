$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/pipelines'
    $script:ComponentScript = Join-Path $script:ComponentDir 'pipelines.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'pipelines.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'pipelines file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'pipelines manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is pipelines' {
        $script:Manifest.id | Should -Be 'pipelines'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/pipelines/pipelines.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is pipelines' {
        $script:Manifest.func_prefix | Should -Be 'pipelines'
    }

    It 'dashboard port is 9099' {
        [int]$script:Manifest.dashboard.port | Should -Be 9099
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'pipelines component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines pipelines_install function' {
        $script:ComponentContent | Should -Match 'pipelines_install\s*\(\)'
    }

    It 'defines pipelines_configure function' {
        $script:ComponentContent | Should -Match 'pipelines_configure\s*\(\)'
    }

    It 'defines pipelines_start function' {
        $script:ComponentContent | Should -Match 'pipelines_start\s*\(\)'
    }

    It 'defines pipelines_stop function' {
        $script:ComponentContent | Should -Match 'pipelines_stop\s*\(\)'
    }

    It 'defines pipelines_health function' {
        $script:ComponentContent | Should -Match 'pipelines_health\s*\(\)'
    }

    It 'supports --start, --stop, and --health CLI flags' {
        $script:ComponentContent | Should -Match '--start\)'
        $script:ComponentContent | Should -Match '--stop\)'
        $script:ComponentContent | Should -Match '--health\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/pipelines/pipelines\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'pipelines port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 9099 is registered in portmap.json' {
        $script:Portmap.ports.'9099' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'9099'.service | Should -Be 'pipelines'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'pipelines no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/pipelines\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/pipelines/pipelines\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}

# ── Pipelines health endpoint ────────────────────────────────────────────────

Describe 'pipelines health endpoint' {
    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw | ConvertFrom-Json
    }

    It 'health URL uses /v1 endpoint' {
        $script:Manifest.health.url | Should -Match '/v1$'
    }

    It 'dashboard probePath matches health URL path' {
        $script:Manifest.dashboard.probePath | Should -Be '/v1'
    }

    It 'dashboard apiPath is /v1' {
        $script:Manifest.dashboard.apiPath | Should -Be '/v1'
    }
}
