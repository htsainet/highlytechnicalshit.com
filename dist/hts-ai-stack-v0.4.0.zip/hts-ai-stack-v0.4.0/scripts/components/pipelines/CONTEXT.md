# Pipelines Component

Last updated: 2026-04-17

## What happens here

Pipelines is the Open WebUI plugin system — a middleware layer that
intercepts and transforms LLM requests/responses. Used in the stack
to add filters, function calling, and custom processing to chat flows.

## Files and structure

| File | Purpose |
|------|---------|
| `pipelines.sh` | Full lifecycle: install, configure, start, stop, health |
| `pipelines.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Health check

The health probe URL is `/v1` (not `/v1/models`). The `/v1/models`
endpoint returns 403 without an API key, which causes the dashboard
to report the service as down even when it's running fine.

See [usage.md](./usage.md) for command usage.
