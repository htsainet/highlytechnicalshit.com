$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/searxng'
    $script:ComponentScript = Join-Path $script:ComponentDir 'searxng.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'searxng.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'searxng file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'searxng manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is searxng' {
        $script:Manifest.id | Should -Be 'searxng'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/searxng/searxng.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is searxng' {
        $script:Manifest.func_prefix | Should -Be 'searxng'
    }

    It 'dashboard port is 8787' {
        [int]$script:Manifest.dashboard.port | Should -Be 8787
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'searxng component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines searxng_install function' {
        $script:ComponentContent | Should -Match 'searxng_install\s*\(\)'
    }

    It 'defines searxng_configure function' {
        $script:ComponentContent | Should -Match 'searxng_configure\s*\(\)'
    }

    It 'defines searxng_start function' {
        $script:ComponentContent | Should -Match 'searxng_start\s*\(\)'
    }

    It 'defines searxng_stop function' {
        $script:ComponentContent | Should -Match 'searxng_stop\s*\(\)'
    }

    It 'defines searxng_health function' {
        $script:ComponentContent | Should -Match 'searxng_health\s*\(\)'
    }

    It 'supports --start, --stop, and --health CLI flags' {
        $script:ComponentContent | Should -Match '--start\)'
        $script:ComponentContent | Should -Match '--stop\)'
        $script:ComponentContent | Should -Match '--health\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/searxng/searxng\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'searxng port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8787 is registered in portmap.json' {
        $script:Portmap.ports.'8787' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'8787'.service | Should -Be 'searxng'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'searxng no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/searxng\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/searxng/searxng\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
