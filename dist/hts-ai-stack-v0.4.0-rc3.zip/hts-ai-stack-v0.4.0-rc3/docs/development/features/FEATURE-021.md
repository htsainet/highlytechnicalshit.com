# ZeroClaw — Personal AI Assistant Service

**Priority:** HIGH
**Effort:** 2–3 hours
**Risk:** Low — public GHCR image, stable v0.6.9, MIT/Apache-2.0 dual license.
**Target Release:** v0.6.0
**Depends on:** llama-swap routing (merged)
**Blocks:** Nothing

## Problem

The stack has no always-on personal assistant with native multi-channel inbox support.
ZeroClaw fills this with a <5MB RAM idle Rust binary, 22+ messaging channels
(WhatsApp, Telegram, Signal, Discord, iMessage, Matrix, IRC, Email, Bluesky, and more),
a web dashboard, and an OpenClaw workspace migration utility.

## Current State

Not tracked in `docs/development/features/`. ZeroClaw was not in the original stack design.
Public GHCR image available: `ghcr.io/zeroclaw-labs/zeroclaw:latest`.

## Implementation Steps

### P0 — Service

- [ ] **1. Docker compose service**
  Add `zeroclaw` service to `docker-compose.yml` under `profiles: [zeroclaw]`.

  ```yaml
  zeroclaw:
    image: ghcr.io/zeroclaw-labs/zeroclaw:latest
    container_name: hts-ai-zeroclaw
    profiles: [zeroclaw]
    restart: unless-stopped
    ports:
      - "${ZEROCLAW_PORT:-42617}:42617"
    environment:
      - ZEROCLAW_ALLOW_PUBLIC_BIND=true
      - ZEROCLAW_GATEWAY_PORT=42617
      - PROVIDER=openai
      - API_KEY=not-needed
      - ZEROCLAW_MODEL=${ZEROCLAW_MODEL:-}
    volumes:
      - zeroclaw-data:/zeroclaw-data
    networks:
      - ai-network
    healthcheck:
      test: ["CMD", "zeroclaw", "status", "--format=exit-code"]
      interval: 60s
      timeout: 10s
      retries: 3
      start_period: 10s
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 32M
  ```

  > **Note:** Verify `PROVIDER=openai` supports a `ZEROCLAW_API_BASE` override to point at
  > llama-swap. If the provider driver hard-codes `api.openai.com`, open an upstream issue
  > and fall back to `PROVIDER=openrouter` with a local-compatible key until resolved.

- [ ] **2. Component script**
  Create `scripts/components/zeroclaw/zeroclaw.sh` implementing:
  - `zeroclaw_install` — pull image
  - `zeroclaw_configure` — validate env vars; emit workspace config
  - `zeroclaw_start` — start service + health check
  - `zeroclaw_health` — `docker exec zeroclaw status --format=exit-code`
  - `zeroclaw_stop` — stop service

- [ ] **3. Env vars**
  Add to `.env.example`:

  ```text
  ZEROCLAW_PORT=42617
  ZEROCLAW_MODEL=
  ```

### P1 — Registration

- [ ] **4. Port map** — Add port 42617 to `REFERENCES.md` Host Port Map table.
- [ ] **5. Feature index** — Add row to `docs/development/features/REFERENCES.md`.

### P2 — Local LLM wiring

ZeroClaw connects to llama-swap as the OpenAI-compatible provider:

```toml
# ~/.zeroclaw/config.toml (injected via volume or env)
[provider]
name = "openai"
base_url = "http://hts-ai-llama-swap:8081/v1"
api_key = "not-needed"
```

### P3 — OpenClaw migration (optional)

For users running htsclaw, document the migration path:

```bash
# Preview migration (safe, read-only)
docker exec hts-ai-zeroclaw zeroclaw migrate openclaw --dry-run

# Run migration (copies memory, workspace, config from ~/.openclaw/)
docker exec hts-ai-zeroclaw zeroclaw migrate openclaw
```

## Acceptance Criteria

- `docker compose --profile zeroclaw up` starts the service
- Gateway accessible at `http://localhost:42617`
- `zeroclaw_health` returns success
- LLM calls route to llama-swap (verifiable in llama-swap logs)
- Port 42617 conflict-free per `REFERENCES.md` map

## Related

- [FEATURE-019](FEATURE-019.md) — htsclaw (OpenClaw sandbox — migration source)
- [FEATURE-020](FEATURE-020.md) — OpenFang (agent OS, different use case)
- [docs/planning/feature-repos/REFERENCES.md](../../planning/feature-repos/REFERENCES.md)
