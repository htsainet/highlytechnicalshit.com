#!/usr/bin/env bash
# scripts/lib/converge-diff.sh — Compare desired vs actual state
# Source this file; do NOT run directly.
#
# Compares DESIRED and ACTUAL arrays to produce an ordered action plan.
# Each action specifies: component, action type, reason.
#
# Used by: converge.sh (FEATURE-009)
# Requires: common.sh, component-registry.sh, state-desired.sh, state-actual.sh

# ── Action plan arrays ────────────────────────────────────────────────────────
# Populated by converge_plan()
# Parallel arrays: same index = same action
declare -ga PLAN_COMPONENT=()
declare -ga PLAN_ACTION=()
declare -ga PLAN_REASON=()

# Action types:
#   "start"     — component should be running but is stopped/missing
#   "stop"      — component should be disabled but is running
#   "restart"   — component is degraded, needs restart
#   "install"   — component is missing, needs install + start
#   "no-op"     — component is in desired state
#   "health"    — component is running, just verify health

# ── Plan generator ────────────────────────────────────────────────────────────

# converge_plan
# Compares DESIRED vs ACTUAL and populates the PLAN arrays.
# Must be called after desired_state_load() and actual_state_load().
converge_plan() {
  # Clear any previous plan
  PLAN_COMPONENT=()
  PLAN_ACTION=()
  PLAN_REASON=()

  local component desired actual action reason
  
  for component in "${COMPONENT_ORDER[@]}"; do
    desired="${DESIRED[$component]:-disabled}"
    actual="${ACTUAL[$component]:-missing}"
    
    # Determine action based on state matrix
    case "${desired}:${actual}" in
      enabled:running)
        action="health"
        reason="verify health"
        ;;
      enabled:degraded)
        action="restart"
        reason="degraded, needs restart"
        ;;
      enabled:stopped)
        action="start"
        reason="stopped but should be running"
        ;;
      enabled:missing)
        action="install"
        reason="missing, needs install"
        ;;
      disabled:running)
        action="stop"
        reason="running but should be disabled"
        ;;
      disabled:degraded)
        action="stop"
        reason="degraded and should be disabled"
        ;;
      disabled:stopped|disabled:missing)
        action="no-op"
        reason="already disabled"
        ;;
      *)
        action="no-op"
        reason="unknown state: ${desired}:${actual}"
        ;;
    esac
    
    PLAN_COMPONENT+=("$component")
    PLAN_ACTION+=("$action")
    PLAN_REASON+=("$reason")
  done
}

# ── Plan accessors ────────────────────────────────────────────────────────────

# plan_length
# Returns the number of actions in the plan.
plan_length() {
  echo "${#PLAN_COMPONENT[@]}"
}

# plan_get <index>
# Prints the action at the given index as "component:action:reason".
plan_get() {
  local idx="$1"
  echo "${PLAN_COMPONENT[$idx]}:${PLAN_ACTION[$idx]}:${PLAN_REASON[$idx]}"
}

# plan_has_changes
# Returns 0 if the plan has any non-no-op actions, 1 otherwise.
plan_has_changes() {
  local i
  for i in "${!PLAN_ACTION[@]}"; do
    if [[ "${PLAN_ACTION[$i]}" != "no-op" && "${PLAN_ACTION[$i]}" != "health" ]]; then
      return 0
    fi
  done
  return 1
}

# plan_action_count <action_type>
# Returns the count of actions of the given type.
plan_action_count() {
  local action_type="$1"
  local count=0 i
  for i in "${!PLAN_ACTION[@]}"; do
    if [[ "${PLAN_ACTION[$i]}" == "$action_type" ]]; then
      ((count++))
    fi
  done
  echo "$count"
}

# ── Plan output ───────────────────────────────────────────────────────────────

# plan_dump
# Prints the full plan for debugging.
plan_dump() {
  local i component action reason
  echo "Convergence plan (${#PLAN_COMPONENT[@]} components):"
  for i in "${!PLAN_COMPONENT[@]}"; do
    component="${PLAN_COMPONENT[$i]}"
    action="${PLAN_ACTION[$i]}"
    reason="${PLAN_REASON[$i]}"
    printf "  %-20s %-10s %s\n" "$component" "$action" "$reason"
  done
}

# plan_summary
# Prints a summary of planned actions.
plan_summary() {
  local install_count start_count stop_count restart_count health_count noop_count
  install_count=$(plan_action_count "install")
  start_count=$(plan_action_count "start")
  stop_count=$(plan_action_count "stop")
  restart_count=$(plan_action_count "restart")
  health_count=$(plan_action_count "health")
  noop_count=$(plan_action_count "no-op")
  
  echo "Plan summary:"
  [[ $install_count -gt 0 ]] && echo "  Install: $install_count"
  [[ $start_count -gt 0 ]]   && echo "  Start:   $start_count"
  [[ $stop_count -gt 0 ]]    && echo "  Stop:    $stop_count"
  [[ $restart_count -gt 0 ]] && echo "  Restart: $restart_count"
  [[ $health_count -gt 0 ]]  && echo "  Health:  $health_count"
  [[ $noop_count -gt 0 ]]    && echo "  No-op:   $noop_count"
}

# plan_print_table
# Prints a formatted table of planned changes (excludes no-op).
plan_print_table() {
  local has_changes=false
  local i component action reason display_name
  
  # Check if there are any changes
  for i in "${!PLAN_ACTION[@]}"; do
    if [[ "${PLAN_ACTION[$i]}" != "no-op" ]]; then
      has_changes=true
      break
    fi
  done
  
  if [[ "$has_changes" != "true" ]]; then
    echo "No changes needed — all components in desired state."
    return
  fi
  
  # Print header
  printf "%-20s %-12s %-12s %s\n" "Component" "Current" "Action" "Reason"
  printf "%-20s %-12s %-12s %s\n" "─────────────────" "──────────" "──────────" "────────────────────────"
  
  for i in "${!PLAN_COMPONENT[@]}"; do
    action="${PLAN_ACTION[$i]}"
    [[ "$action" == "no-op" ]] && continue
    
    component="${PLAN_COMPONENT[$i]}"
    reason="${PLAN_REASON[$i]}"
    display_name=$(component_display_name "$component")
    local current="${ACTUAL[$component]:-unknown}"
    
    # Color-code actions
    local action_color
    case "$action" in
      install|start) action_color="${GREEN}${action}${NC}" ;;
      stop)          action_color="${YELLOW}${action}${NC}" ;;
      restart)       action_color="${CYAN}${action}${NC}" ;;
      health)        action_color="${GREEN}${action}${NC}" ;;
      *)             action_color="$action" ;;
    esac
    
    printf "%-20s %-12s %-12b %s\n" "$display_name" "$current" "$action_color" "$reason"
  done
}

# ── Filtered plan accessors ───────────────────────────────────────────────────

# plan_components_to_start
# Prints component IDs that need start or install.
plan_components_to_start() {
  local i
  for i in "${!PLAN_COMPONENT[@]}"; do
    local action="${PLAN_ACTION[$i]}"
    if [[ "$action" == "start" || "$action" == "install" ]]; then
      echo "${PLAN_COMPONENT[$i]}"
    fi
  done
}

# plan_components_to_stop
# Prints component IDs that need stop.
plan_components_to_stop() {
  local i
  for i in "${!PLAN_COMPONENT[@]}"; do
    if [[ "${PLAN_ACTION[$i]}" == "stop" ]]; then
      echo "${PLAN_COMPONENT[$i]}"
    fi
  done
}

# plan_components_to_restart
# Prints component IDs that need restart.
plan_components_to_restart() {
  local i
  for i in "${!PLAN_COMPONENT[@]}"; do
    if [[ "${PLAN_ACTION[$i]}" == "restart" ]]; then
      echo "${PLAN_COMPONENT[$i]}"
    fi
  done
}

# plan_components_to_health_check
# Prints component IDs that just need health verification.
plan_components_to_health_check() {
  local i
  for i in "${!PLAN_COMPONENT[@]}"; do
    if [[ "${PLAN_ACTION[$i]}" == "health" ]]; then
      echo "${PLAN_COMPONENT[$i]}"
    fi
  done
}
