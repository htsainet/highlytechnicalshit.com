# 0 — Bootstrap

Run on a fresh Ubuntu 24.04 install before anything else. Automates all manual
steps needed to get from a bare machine to a cloned, token-ready repo.

```bash
curl -fsSL https://raw.githubusercontent.com/htsainet/highlytechnicalshit.com/refs/heads/main/install.sh | bash
```

---

## What it does

| Step | Action |
| --- | --- |
| 1 | apt update + install `curl`, `gpg`, `chrony`, `gh`; configure NTP, set timezone, and add the current user to the `docker` group before reboot |
| 2 | Install latest Git from `ppa:git-core/ppa` |
| 3 | Install Firefox and launch GitHub login |
| 4 | Authenticate GitHub CLI using browser/device flow (`gh auth login --web`) |
| 5 | Configure git identity (auto-detected from GitHub CLI session) |
| 6 | Verify GitHub access |
| 7 | Clone repo to `~/github/ubuntu-ai-stack` using GitHub CLI |
| 8 | Install NVIDIA drivers + reboot prompt (always last) |

Each step is idempotent — re-running skips already-completed steps.

Remaining host setup (VS Code, PowerShell, Node.js, Docker, CUDA, .env tokens,
repo tooling, exFAT, xRDP) is handled by `01-autoinstall.sh` after reboot.

---

## GitHub Authentication

Bootstrap now uses GitHub CLI's browser login flow instead of a personal access
token. Before auth, bootstrap installs Firefox and the latest Git. In the normal
desktop flow, Firefox opens GitHub's login page before the CLI auth step runs.

When the script reaches the auth step, it runs:

```bash
gh auth login --hostname github.com --git-protocol https --web
```

If a browser session is available, GitHub opens automatically. If not, GitHub
CLI falls back to a device-code flow you can complete from another browser.

Timezone defaults to `America/New_York`, but you can override it when invoking
bootstrap:

```bash
BOOTSTRAP_TIMEZONE=America/Chicago bash <(curl -fsSL https://raw.githubusercontent.com/htsainet/ubuntu-ai-stack/refs/heads/main/00-bootstrap.sh)
```

---

## After bootstrap

After bootstrap completes, run `01-autoinstall.sh`. If the NVIDIA driver step
ends with a reboot, run it after rebooting:

```bash
cd ~/github/ubuntu-ai-stack
./01-autoinstall.sh
```

Then continue with the numbered scripts:

```bash
./02-setup-docker.sh        # Docker stack
./03-setup-models.sh        # pull Ollama models
./04-setup-nemoclaw.sh      # optional — NemoClaw agent runtime
bash setup/tooling/install-civitai.sh  # optional — CivitAI Stable Diffusion extension
./06-start-stack.sh         # start Ollama + OpenClaw
```

Optional setup scripts are under `setup/`:

```bash
setup/comms/setup-telegram.sh       # Telegram bot
setup/comms/setup-signal.sh         # Signal integration
setup/networking/setup-tailscale.sh # secure remote access
```

---

## Manual fallback

If you prefer not to use the script, the steps it performs are:

```bash
sudo apt update && sudo apt install -y curl gpg ca-certificates apt-transport-https software-properties-common openssh-client chrony gh firefox
sudo add-apt-repository -y ppa:git-core/ppa
sudo apt update && sudo apt install -y git
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git
git config --global user.name "$(gh api user -q .login)"
git config --global user.email "$(gh api user -q .login)@users.noreply.github.com"
mkdir -p ~/github && gh repo clone htsainet/ubuntu-ai-stack ~/github/ubuntu-ai-stack
# Install NVIDIA drivers, reboot, then run ./01-autoinstall.sh
```
