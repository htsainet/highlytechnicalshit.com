# References

## Examples of good work

- The three-layer workspace pattern documented in `Test-FrameworkStructure.md`
- `Verb-Noun.Tests.ps1` naming enforced by `Test-FrameworkStructure.Tests.ps1`
- Folder-level `CONTEXT.md` files that document purpose, workflow, structure, and tools

## Relevant links

- Jake Van Clief, Quantum Quill Lyceum overview: https://www.skool.com/quantum-quill-lyceum-1116/about

## Notes

- The framework used in this repository was adopted from Jake Van Clief's folder-structure approach and then adapted for this repo's installation, documentation, and Pester validation workflow.
- This file exists to keep source attribution and external references out of `CONTEXT.md`, which stays focused on local workflow and standards.
