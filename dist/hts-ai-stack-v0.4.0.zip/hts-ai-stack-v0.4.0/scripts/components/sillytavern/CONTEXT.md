# SillyTavern Component

Last updated: 2026-04-17

## What happens here

SillyTavern is a character-based AI chat interface with persona management,
world-building, and roleplay features. Used in the stack as an alternative
chat frontend that connects to Ollama.

## Files and structure

| File | Purpose |
|------|---------|
| `sillytavern.sh` | Full lifecycle: install, configure, start, stop, health |
| `sillytavern.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Docker networking fix

SillyTavern's default config blocks connections from Docker bridge IPs.
The configure step injects two settings into `config.yaml` via a busybox
sidecar init container:

- `enableUserAccounts: true` — enables the built-in user account system
- `securityOverride: true` — disables the IP whitelist check

Without `securityOverride`, the health check and browser access fail
because Docker maps traffic through the bridge network (172.x.x.x),
which SillyTavern's allowlist rejects.
See [usage.md](./usage.md) for command usage.
