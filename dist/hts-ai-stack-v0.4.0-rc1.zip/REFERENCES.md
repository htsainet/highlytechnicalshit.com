# References

Last updated: 2026-04-05 20:30:00

## Core Services

- **OpenClaw**: https://openclaw.ai/
- **NemoClaw**: https://www.nvidia.com/en-us/ai/nemoclaw/
- **OpenShell**: https://docs.nvidia.com/openshell/latest/index.html
- **Ollama**: https://ollama.com/
- **llama-swap**: https://github.com/mostlygeek/llama-swap — Model multiplexer for GPU/CPU split inference
- **Open WebUI**: https://github.com/open-webui/open-webui — Chat frontend

## Folder Architecture

```text
hts-ai-stack/
│
├── bootstrap.sh                 # Entry point — curl | bash target; installs prereqs,
│                                #   clones repo, installs NVIDIA drivers (requires reboot)
├── install.sh                   # Wizard-style installer; runs after reboot from repo root
├── setup.sh                     # Supporting setup steps
├── docker-compose.yml           # Convenience root-level compose (delegates to docker/)
│
├── CLIEF-NOTES-FRAMEWORK.md    # Clief Notes documentation framework spec
├── CLAUDE.md                    # AI assistant identity, rules, and routing
├── CONTEXT.md                   # Project overview and goals
├── REFERENCES.md                # Architecture, services, and key links (this file)
├── README.md                    # Public-facing project documentation
│
├── backups/                     # Backup automation scripts
│   ├── docker/                  #   Docker volume backup scripts
│   ├── synology/                #   Synology NAS mount + ActiveProtect agent setup
│   └── timeshift/               #   Timeshift snapshot configuration
│
├── config/                      # Runtime and wizard-generated configuration
│   ├── stack.json               #   Primary stack configuration
│   ├── tailscale-acl-policy.jsonc #  Tailscale ACL policy definition
│   ├── backups/                 #   Auto-generated timestamped config snapshots
│   │                            #     (one folder per install.sh run: YYYYMMDD-HHMMSS/)
│   └── wizard/                  #   Interactive wizard scripts for config generation
│
├── docker/                      # Docker build contexts
│   ├── bitnet/                  #   BitNet multi-stage build (Dockerfile + entrypoint)
│   └── openspace/               #   OpenSpace build (Dockerfile + config)
│
├── docs/                        # All documentation
│   ├── CONTEXT.md               #   Documentation hub — routes to sub-folders
│   ├── development/             #   Active development tracking
│   │   ├── testing-log.md       #     Manual test run log
│   │   ├── features/            #     Feature tracker — one FEATURE-###.md per feature
│   │   │   └── CONTEXT.md       #     Feature tracker conventions
│   │   └── issues/              #     In-flight issue notes
│   ├── guides/                  #   How-to guides (Tailscale, Signal, Telegram,
│   │                            #     Docker Model Engine, NFS, etc.)
│   ├── pipeline/                #   Step-by-step guides mirroring install script sequence
│   │                            #     (00-bootstrap → 07-setup-connectivity)
│   ├── planning/                #   Strategic planning and research
│   │   ├── CONTEXT.md           #     Planning hub — routes to sub-folders
│   │   ├── TODO.md              #     Backlog and priorities
│   │   ├── feature-repos/       #     Non-security repo tracking & review artifacts
│   │   ├── openclaw-skills/     #     OpenClaw skill vetting (sandbox safety, policies, install verdict)
│   │   │   ├── CONTEXT.md       #       Review workflow for feature repos
│   │   │   └── REFERENCES.md    #       Tracking table (agents, memory, platforms, etc.)
│   │   ├── repo-review/         #     Ecosystem repo review session state
│   │   │   ├── CONTEXT.md       #       Session handoff / review workflow
│   │   │   └── REFERENCES.md    #       Master curated repo list (all categories)
│   │   ├── security-repos/      #     Security repo tracking & review artifacts
│   │   │   ├── CONTEXT.md       #       Review workflow for security repos
│   │   │   ├── REFERENCES.md    #       ~45 security repos tracking table
│   │   │   └── results/         #       Per-repo review artifacts (owner-reponame.md)
│   │   └── security-whitepapers/ #    arXiv paper tracking & review artifacts
│   │       ├── CONTEXT.md       #       Paper review workflow
│   │       └── REFERENCES.md    #       12 papers tracking table
│   ├── security-review/         #   Security architecture review session state
│   │   ├── CONTEXT.md           #     Threat model, findings, completed deliverables
│   │   └── REFERENCES.md        #     Complete threat model and findings
│
├── instances/                   # Per-environment runtime configs
│   ├── prod/                    #   Production compose + model list
│   └── test/                    #   Test compose + model list
│
├── logs/                        # Runtime logs (gitignored)
│
├── resources/                   # Static assets served by the stack
│   ├── CONTEXT.md               #   Resource conventions (Open WebUI functions, etc.)
│   ├── dashboard/               #   Nginx dashboard landing page (index.html)
│   │                            #     Also serves token sidecars: nemoclaw-tokens.json,
│   │                            #     openwebui-token.json (gitignored, runtime-generated)
│   ├── nginx/                   #   Nginx configuration (robots.txt, robots.conf)
│   ├── open-webui/              #   Open WebUI container assets
│   │   └── login.html           #     Same-origin login bridge — sets localStorage JWT
│   └── open-webui-functions/    #   Open WebUI Pipe functions (snake_case.py)
│
├── scripts/                     # Installation and utility scripts
│   ├── CONTEXT.md               #   Script goals and conventions
│   ├── bootstrap.sh             #   Repo-local copy of the bootstrap entry point
│   ├── build.sh                 #   Build script
│   ├── install.sh               #   Main installer (wizard-style)
│   ├── bundles/                 #   Orchestrated service groups (chat, full-stack, etc.)
│   ├── components/              #   Per-service lifecycle scripts (install/start/stop/remove)
│   ├── host/                    #   OS-level provisioning (docker, nvidia, tools, node, nas)
│   │   └── prerequisites.json   #     Stack-wide apt prerequisite tracker
│   ├── install/                 #   Numbered install step scripts (legacy pipeline wrappers)
│   │   ├── 01-autoinstall.sh    #     System auto-install / pre-config
│   │   ├── 02-setup-docker.sh   #     Docker + NVIDIA Container Toolkit setup
│   │   ├── 03-setup-models.sh   #     Ollama model download and configuration
│   │   ├── 04-setup-nemoclaw.sh #     NemoClaw sandbox setup
│   │   ├── 06-start-stack.sh    #     Start all services
│   │   ├── 06-stop-test-instances.sh # Stop test instances
│   │   ├── 07-setup-connectivity.sh  # Tailscale / networking finish
│   │   ├── comms/               #     Communication service setup (Signal, Telegram)
│   │   ├── models/              #     Model-specific download/config helpers
│   │   ├── networking/          #     Networking helpers
│   │   ├── system/              #     OS-level setup helpers
│   │   └── tooling/             #     Dev/ops tooling installation
│   ├── issuefixers/             #   One-off scripts to remediate known issues
│   ├── lib/                     #   Shared function libraries (sourced, not executed)
│   └── utils/                   #   Operator utilities (npm-audit.sh, audit-models.sh,
│                                #     seed-model-cache.sh, teardown.sh, verify.sh)
│
├── refactor/                    # Pipeline restructure plan and task tracking
│   ├── CONTEXT.md               #   Refactor scope and decisions
│   └── tasks/                   #   Individual refactor task files
│
└── tests/                       # Pester test suite (PowerShell 7.6 / Pester 5.7.1)
    ├── CONTEXT.md               #   Test conventions and goals
    ├── Install-GitHooks.ps1     #   Git hook installer
    ├── Invoke-RepoChecks.ps1    #   Repo health check runner
    ├── Test-FrameworkStructure.Tests.ps1
    ├── Test-HostPrerequisites.Tests.ps1
    ├── Test-IssueReviewDeadlines.Tests.ps1
    ├── Test-ModelCache.Tests.ps1
    ├── Test-ModelHelpers.Tests.ps1
    ├── Test-NamingConventions.Tests.ps1
    ├── Test-NoEditorSwap.Tests.ps1
    ├── Test-NpmAuditSecurity.Tests.ps1
    ├── Test-RepoChecks.Tests.ps1
    ├── Test-StackValidation.Tests.ps1
    ├── Test-StaleReferences.Tests.ps1
    ├── Test-WizardMenu.Tests.ps1
    ├── Test-WorkspaceValidation.Tests.ps1
    └── validate-config-files.cjs #  Node.js config file validator
```

## Deployment Variants

### BitNet — Llama3-8B-1.58 inference backend

**Build context:** `docker/bitnet/` (Dockerfile + entrypoint.sh)

Drop-in Ollama replacement using Microsoft BitNet. Exposes an OpenAI-compatible API on port 8080.

- **Repo:** <https://github.com/microsoft/BitNet>
- **Wiring guide:** `docs/guides/nemoclaw-bitnet-wiring.sh`

## Container Naming Conventions

All containers spun up by HTS AI stack MUST be prefixed with `hts-ai-` to avoid conflicts with other services on the host.

### Main Compose Stack (docker-compose.yml)

| Container Name | Service |
|---|---|
| `hts-ai-dashboard` | nginx |
| `hts-ai-gitea` | Self-hosted Git |
| `hts-ai-ollama-gpu` | LLM inference (GPU) |
| `hts-ai-bitnet-cpu` | 1-bit LLM (CPU) |
| `hts-ai-open-webui` | Chat frontend |
| `hts-ai-openspace` | Agent skills + dashboard |
| `hts-ai-gvisor-sandbox` | gVisor CPU agent sandbox |

### Prod & Test Stacks

Same `hts-ai-*` prefix with environment suffix:

- `hts-ai-ollama-gpu-prod`, `hts-ai-ollama-gpu-test`
- `hts-ai-open-webui-prod`, `hts-ai-open-webui-test`
- `hts-ai-bitnet-cpu-prod`, `hts-ai-bitnet-cpu-test`
- `hts-ai-stable-diffusion-prod`, `hts-ai-stable-diffusion-test`
- `hts-ai-sillytavern-prod`, `hts-ai-sillytavern-test`
- `hts-ai-comfyui-test`
- Init containers: `hts-ai-ollama-init`, `hts-ai-stable-diffusion-prod-init`

### External / Third-Party Containers

Not prefixed — managed by third-party tools, not docker-compose:

| Container | Managed By | Notes |
|---|---|---|
| `openshell-cluster-*` | NemoClaw/OpenShell | Managed by `nemoclaw` CLI |
| `hts-ai-assistant-*` | NemoClaw | NemoClaw sandboxes — already prefixed |

### Cleanup

The nuke script (`nuke-stack.sh`) removes stopped containers matching `^hts-ai-*`.

## Dashboard Token Sidecar Pattern

The dashboard uses runtime-generated JSON sidecar files to provide tokenized auto-login URLs for services. These files are gitignored and regenerated on each install/bootstrap.

| Sidecar file | Generated by | Token type | Service |
|---|---|---|---|
| `nemoclaw-tokens.json` | `nemoclaw.sh` (`_extract_dashboard_tokens`) | OpenClaw gateway token | NemoClaw sandboxes (GPU/CPU) |
| `openwebui-token.json` | `open-webui.sh` (`openwebui_generate_dashboard_token`) | JWT (admin sign-in) | Open WebUI |

**Flow:** Component script signs in → writes JSON to `resources/dashboard/` → dashboard JS fetches at load time → rewrites card `href` to tokenized URL → user clicks card → auto-authenticated.

**Open WebUI login bridge:** Because `localStorage` is scoped per origin, the dashboard (`:80`) cannot set tokens for Open WebUI (`:3000`). A tiny bridge page (`resources/open-webui/login.html`) is bind-mounted into the Open WebUI container at `/app/build/static/login.html`. The tokenized URL routes through this page, which sets `localStorage.token` from the same origin and redirects to `/`.

## Host Port Map

> **Rule:** Always review this table before adding or changing a service.
> Duplicate host ports cause silent bind failures at startup.

### Main Compose (`docker-compose.yml`)

| Host Port | Service | Container | Profile | Env Override |
|-----------|---------|-----------|---------|--------------|
| 80 | Dashboard (nginx) | hts-ai-dashboard | dashboard | — |
| 3000 | Open WebUI | hts-ai-open-webui | — | — |
| 3001 | OpenSpace dashboard | hts-ai-openspace | openspace | `OPENSPACE_DASHBOARD_PORT` |
| 3002 | DeerFlow web UI | hts-ai-deerflow | deerflow | `DEERFLOW_PORT` |
| 3030 | Gitea | hts-ai-gitea | gitea | — |
| 3100 | Grafana | hts-ai-grafana | monitoring | — |
| 5000 | OpenSpace MCP | hts-ai-openspace | openspace | — |
| 8003 | DeerFlow backend API | hts-ai-deerflow | deerflow | `DEERFLOW_BACKEND_PORT` |
| 8081 | llama-swap | hts-ai-llama-swap | llama-swap | `LLAMA_SWAP_PORT` |
| 8082 | BitNet API | hts-ai-bitnet-cpu | bitnet-cpu | — |
| 8888 | Unsloth Studio UI | hts-ai-unsloth | unsloth | `UNSLOTH_PORT` |
| 8000 | Unsloth API | hts-ai-unsloth | unsloth | `UNSLOTH_API_PORT` |
| 9000 | Portainer HTTP | hts-ai-portainer | portainer | — |
| 9090 | Prometheus | hts-ai-prometheus | monitoring | — |
| 9443 | Portainer HTTPS | hts-ai-portainer | portainer | — |
| 11434 | Ollama API | hts-ai-ollama-gpu | ollama-gpu | — |
| 18791 | gVisor sandbox | hts-ai-gvisor-sandbox | gvisor-sandbox | — |
| 18792 | htsclaw sandbox | hts-ai-assistant | htsclaw | `HTSCLAW_PORT` |

### Host-Native Ports (non-Docker)

| Host Port | Service | Notes |
|-----------|---------|-------|
| 8083 | htsclaw gateway | OpenShell port-forward; `HTSCLAW_GATEWAY_PORT` |

### Prod Instance (`instances/prod/docker-compose.yml`)

| Host Port | Service | Notes |
|-----------|---------|-------|
| 3000 | Open WebUI (prod) | Shared with main — only run one |
| 7860 | Stable Diffusion | — |
| 8001 | SillyTavern | — |
| 8080 | llama-swap (prod) | — |
| 11434 | Ollama (prod) | 0.0.0.0 bind |

### Test Instance (`instances/test/docker-compose.yml`)

| Host Port | Service | Notes |
|-----------|---------|-------|
| 3001 | Open WebUI (test) | Conflicts with OpenSpace dashboard if both active |
| 7861 | Stable Diffusion (test) | — |
| 8002 | SillyTavern (test) | — |
| 8081 | llama-swap (test) | Conflicts with main llama-swap if both active |
| 8189 | ComfyUI (test) | — |
| 11435 | Ollama (test) | — |

### Allocated Range Summary

```text
   80        Dashboard
 3000-3002   Web UIs (Open WebUI, OpenSpace dash, DeerFlow)
 3030        Gitea
 3100        Grafana
 5000        OpenSpace MCP
 7860-7861   Stable Diffusion (prod/test)
 8000-8003   Backend APIs (Unsloth, SillyTavern, DeerFlow)
 8080-8083   LLM routers / gateways (llama-swap, BitNet, htsclaw gw)
 8189        ComfyUI (test)
 8888        Unsloth Studio
 9000-9443   Portainer
 9090        Prometheus
11434-11435  Ollama (main/test)
18789-18794  Agent sandboxes (NemoClaw GPU, gVisor, htsclaw, Daytona server/sandbox)
```
