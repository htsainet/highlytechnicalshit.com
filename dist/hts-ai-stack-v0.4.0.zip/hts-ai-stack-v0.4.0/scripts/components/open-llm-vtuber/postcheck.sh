#!/usr/bin/env bash
# scripts/components/open-llm-vtuber/postcheck.sh — quick verdict after a
# rebuild/restart of Open-LLM-VTuber. Surfaces just enough to know whether
# init_live2d succeeded and the agent loaded.
#
# Usage:
#   ./scripts/components/open-llm-vtuber/postcheck.sh

set -uo pipefail

CONTAINER="${OPEN_LLM_VTUBER_CONTAINER:-hts-ai-open-llm-vtuber}"
PORT="${OPEN_LLM_VTUBER_PORT:-12393}"

section() { printf '\n── %s ─────────────────────────────────────────────\n' "$1"; }

section "1. container status"
docker ps -a --filter "name=$CONTAINER" \
  --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'

section "2. state / restart count / last exit"
docker inspect "$CONTAINER" --format '
status        : {{.State.Status}}
running       : {{.State.Running}}
restartcount  : {{.RestartCount}}
last exitcode : {{.State.ExitCode}}
health        : {{if .State.Health}}{{.State.Health.Status}} (failingstreak={{.State.Health.FailingStreak}}){{else}}<no healthcheck>{{end}}
' 2>&1

section "3. model_dict.json inside container"
docker exec "$CONTAINER" python3 -c \
  "import json; d=json.load(open('/app/model_dict.json')); print(len(d),'entries:'); [print(' -',e['name']) for e in d]" 2>&1

section "4. live2d / agent init lines from logs"
docker logs --tail 200 "$CONTAINER" 2>&1 \
  | grep -E "Live2D|model_dict|emo_str|Uvicorn|Application startup|ERROR|CRITICAL|Failed to initialize" \
  || echo "(no matching lines — that's good)"

section "5. http probe :$PORT"
curl -sS -o /dev/null -w 'http_code=%{http_code}  time=%{time_total}s\n' \
  --max-time 5 "http://localhost:$PORT/" || true

section "6. verdict"
status=$(docker inspect "$CONTAINER" --format '{{.State.Status}}' 2>/dev/null)
rc=$(docker inspect "$CONTAINER" --format '{{.RestartCount}}' 2>/dev/null)
health=$(docker inspect "$CONTAINER" --format '{{if .State.Health}}{{.State.Health.Status}}{{end}}' 2>/dev/null)

if [[ "$status" == "running" && "$rc" -lt 2 ]]; then
  if [[ "$health" == "healthy" || -z "$health" ]]; then
    echo "[ ok ] container is up and stable. Try http://localhost:$PORT/ in Firefox."
  else
    echo "[wait] container is up but healthcheck status is '$health'. Re-run this script in 30–60s; healthcheck has start_period=120s."
  fi
elif [[ "$status" == "restarting" ]]; then
  echo "[fail] still crash-looping (restartcount=$rc). Inspect section 4 for the new error."
else
  echo "[fail] container status='$status' restartcount=$rc — see sections 2 and 4."
fi
