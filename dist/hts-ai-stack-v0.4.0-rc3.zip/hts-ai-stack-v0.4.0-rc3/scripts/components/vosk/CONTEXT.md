# Vosk Component

Last updated: 2026-04-15

## What happens here

Vosk provides offline, CPU-only speech-to-text via gRPC. Designed for
low-latency, low-resource environments where GPU is unavailable or
reserved for other workloads. Supports 20+ languages with small models.

## Files and structure

| File | Purpose |
|------|---------|
| `vosk.sh` | Full lifecycle: install, configure, start, stop, health |
| `vosk.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Base image

Uses `alphacep/kaldi-en:latest` which bundles the English model.
The original `alphacep/kaldi-vosk-server` image ships with NO model,
requiring a volume mount — which caused startup failures.

## Notes

- CPU-only — offloads STT from GPU, keeping it free for LLM inference
- gRPC + WebSocket API on port 2700
- English model bundled in base image (~50MB)
- Can run alongside Faster-Whisper (GPU STT) for redundancy
