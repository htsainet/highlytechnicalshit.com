# planning/

Strategic planning, research, and repo/paper review tracking. Each sub-folder has its own `CONTEXT.md` with workflow instructions and a `REFERENCES.md` tracking table.

Last updated: 2026-03-31 19:09:10

## Sub-folders

| Folder | What's tracked | Artifacts |
|--------|---------------|-----------|
| [feature-repos/](feature-repos/) | Non-security repos: agents, memory, platforms, UI, personas, skills, integrations | `results/owner-reponame.md` |
| [repo-review/](repo-review/) | Master repo review session state — all categories, review workflow, batch progress | `results/repo-review-batch*.md` |
| [security-repos/](security-repos/) | ~45 security-focused repos: tooling, hardening, threat defense | `results/owner-reponame.md` |
| [security-review/](security-review/) | Security architecture — threat model, findings, architecture decisions | `results/session*-report.md` |
| [security-whitepapers/](security-whitepapers/) | 12 arXiv papers on agent security | `results/arXiv-ID.md` |

## How to navigate

1. **Know the category?** Go directly to the matching sub-folder and read its `CONTEXT.md`
2. **Looking for a specific repo?** Check `repo-review/REFERENCES.md` (master list) or the category-specific REFERENCES.md
3. **Security question?** Start with `security-review/CONTEXT.md` for the threat model, then `security-repos/` for tooling
4. **Need the backlog?** See [TODO.md](TODO.md)

## Conventions

- Every sub-folder has `CONTEXT.md` (workflow) + `REFERENCES.md` (tracking table)
- Review artifacts go in `results/` within each sub-folder
- Naming: `owner-reponame.md` for repos, `arXiv-ID.md` for papers, `session*-report.md` or `repo-review-batch*.md` for session outputs

## Tools and skills

- **gh CLI** — GitHub repo metadata and README fetching
- **Claude Haiku/Sonnet/Opus** — Multi-pass repo review and analysis
- **arXiv** — Paper discovery and access
- **grep/ripgrep** — Cross-reference and audit trail search
- **git** — Version control and audit history
- **Claude Code** — Planning document generation and updates
