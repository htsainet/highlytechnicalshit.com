# Brainstorming — Stack Direction

> **Date:** 2026-04-06
> **Participants:** Tim + Claude Sonnet (Phase 2 review session)
> **Status:** Active — revisit after testing DeerFlow + OpenSpace

---

## Context

After completing Phase 2 security repo reviews, we stepped back to assess whether
the review pipeline (45+ security repos, 60+ feature repos, multi-pass review)
was serving the actual goal: **a secure local AI workstation for personal use**.

---

## What Actually Works Today

- Open WebUI + Ollama (GPU) + llama-swap + BitNet (CPU) = dual-inference chat
- Dashboard (Nginx) showing service status
- Tailscale for remote access
- NemoClaw OpenShell sandbox container running (but agent instances not deployed)

Everything else is scripted/stubbed but not in daily use.

---

## Key Realizations

1. **The building process was the thinking process.** The repo research and
   infrastructure work served as structured thinking — but the actual product
   (the workstation) hasn't been used yet beyond basic chat.

2. **Multiple agent platforms is viable.** Agents are CPU-constrained, not
   VRAM-constrained. Can run DeerFlow + OpenSpace + NemoClaw simultaneously
   for different purposes. Don't need to pick one.

3. **Security repos are premature.** All 3 top security tools (SlowMist, ClawSec,
   ClawVault) are OpenClaw-specific. Evaluating 45 security repos before
   committing to an agent platform is wasted effort.

4. **The repo IS the product.** Tim's friend and nephew will clone it and choose
   what to adopt. The bundles system already supports "pick your adventure"
   install paths.

5. **"Structured thinking through ideas" is the real use case.** Not primarily
   a coding assistant or research agent — a thinking partner with persistence.

---

## Architecture Understanding

### NemoClaw / OpenSpace / OpenClaw relationship

```text
NemoClaw = the locked room (security sandbox, cgroups, NVIDIA isolation)
  └── OpenClaw = the agent inside the room (LLM-powered assistant)
       └── OpenSpace = the tools on the workbench (MCP skills, file access)

DeerFlow = separate agent entirely (multi-step research: search → analyze → report)
```

- OpenSpace runs INSIDE NemoClaw, not in front of it
- DeerFlow is independent — good for automated research tasks
- All are CPU-bound, can coexist on same hardware

### Dashboard NemoClaw offline issue

The dashboard defines two NemoClaw cards:

- **NemoClaw GPU** → port 18789 (not running — no container deployed)
- **NemoClaw GPU** → port 18789 (agent sandbox via OpenShell gateway)

Only `openshell-cluster-nemoclaw` is running (port 8080→30051). The NemoClaw
agent instances haven't been started yet — the sandbox infrastructure is there
but the agents inside it aren't deployed.

---

## Recommended Next Steps (in order)

### Phase 1 — Use what you have (now)

- [ ] Use Open WebUI + Ollama daily for ADHD thought structuring
- [ ] Create a "thinking partner" system prompt / conversation style
- [ ] Don't add anything — just use it

### Phase 2 — Try one agent platform (next session)

- [ ] Get DeerFlow running (script is BUILT — test it)
  - Use it for repo research if you want to continue evaluations
  - Multi-step web search → synthesize → report
- [ ] Get OpenSpace running (script is BUILT — test it)
  - MCP skills, file management, code execution
- [ ] Try NemoClaw agent deployment (script is BUILT, heavier setup)
  - Requires deploying actual agent instances inside the sandbox

### Phase 3 — After daily workflow established

- [ ] Evaluate security tools — only for the platform(s) you chose
- [ ] Consider Obsidian for linking conversations/notes/repo tracking
- [ ] Revisit parked security repos only if needed
- [ ] Clean up dashboard to reflect actual running services

---

## Security Repo Review Status (as of 2026-04-06)

### Completed (Pass 2 — Sonnet verified)

| Repo | Verdict | Key finding |
|------|---------|-------------|
| slowmist/openclaw-security-practice-guide | ADOPT | Haiku swapped stars/forks — corrected. Strongest behavioral framework. |
| tophant-ai/ClawVault | ADOPT | Proxy SPoF risk. MIT. Highest value for exfil prevention. |
| gendigitalinc/sage | ADOPT ⚠️ | **DRL 1.1 dual-license on threat rules** — Haiku missed this entirely. |
| prompt-security/clawsec | ADOPT | AGPL-3.0 compliance unresolved. 881★ (up 60% in 4 days). |
| Tencent/AI-Infra-Guard | REFERENCE | Scanning/audit tool only. No auth on port 8088 — internal only. |
| adversa-ai/secureclaw | REFERENCE | Haiku verdict mismatch fixed. No LICENSE file — legally blocked. |
| Atlas-Cowork/openclaw-reference-setup | REFERENCE | MIT from badge only — gh API null. Has SECURITY.md (Haiku missed). |

### Parked

~37 pending security repos — revisit after agent platform selection.

---

## Obsidian Future

If/when we move to Obsidian:

- Point vault at `docs/planning/`
- Add YAML frontmatter to result docs (verdict, stars, license, pass, trust)
- Dataview queries replace massive markdown tables
- Graph view shows repo relationships automatically
- Canvas for architecture diagrams
- Daily notes for ADHD management

This is a separate workstream — don't start until Phase 1 daily use is established.

---

## Open Questions

- [ ] Is DeerFlow a better repo researcher than a human + Claude conversation?
- [ ] Does NemoClaw agent deployment require OpenClaw, or can it sandbox other agents?
- [ ] Would Obsidian + local model plugin replace the need for a separate PKM agent?
- [ ] Should the dashboard only show running services (hide undeployed ones)?
