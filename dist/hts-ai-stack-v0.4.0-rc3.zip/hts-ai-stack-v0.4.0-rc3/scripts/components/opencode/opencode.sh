#!/usr/bin/env bash
# OpenCode – terminal AI coding agent (host tool)
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# shellcheck source=scripts/lib/common.sh
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=scripts/lib/health.sh
source "$REPO_DIR/scripts/lib/health.sh"

###############################################################################
# Lifecycle
###############################################################################

opencode_install() {
  log_info "Installing OpenCode …"
  if command -v opencode &>/dev/null; then
    log_ok "OpenCode is already installed"
    return 0
  fi

  curl -fsSL https://opencode.ai/install | bash
  hash -r

  if command -v opencode &>/dev/null; then
    log_ok "OpenCode installed successfully"
  else
    log_warn "OpenCode binary not found after install — check PATH"
    return 1
  fi
}

opencode_configure() {
  log_info "Configuring OpenCode for local Ollama …"

  # Create a global config pointing at the stack's Ollama
  local config_dir="${XDG_CONFIG_HOME:-$HOME/.config}/opencode"
  mkdir -p "$config_dir"

  local config_file="$config_dir/config.json"
  if [[ ! -f "$config_file" ]]; then
    cat > "$config_file" <<'CONF'
{
  "provider": {
    "id": "ollama",
    "type": "openai",
    "api_url": "http://localhost:11434/v1",
    "model": "qwen2.5-coder:7b"
  }
}
CONF
    log_ok "Created $config_file → Ollama at localhost:11434"
  else
    log_ok "Config already exists at $config_file"
  fi
}

opencode_start() {
  log_info "OpenCode is a terminal tool — launch with: opencode"
}

opencode_stop()    { :; }
opencode_restart() { :; }

opencode_health() {
  if command -v opencode &>/dev/null; then
    log_ok "OpenCode binary found: $(command -v opencode)"
    return 0
  fi
  log_warn "OpenCode not found in PATH"
  return 1
}

opencode_destroy() {
  log_info "Removing OpenCode …"
  local bin
  bin="$(command -v opencode 2>/dev/null || true)"
  if [[ -n "$bin" ]]; then
    sudo rm -f "$bin"
    log_ok "Removed $bin"
  fi
  rm -rf "${XDG_CONFIG_HOME:-$HOME/.config}/opencode"
  log_ok "OpenCode removed"
}

opencode_status() {
  if command -v opencode &>/dev/null; then
    echo "installed"
  else
    echo "not_installed"
  fi
}
