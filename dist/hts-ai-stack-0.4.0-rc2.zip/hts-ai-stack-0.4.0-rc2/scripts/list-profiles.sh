#!/usr/bin/env bash
# scripts/list-profiles.sh — List saved stack profiles
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"

PROFILES_DIR="$REPO_DIR/config/profiles"

if [[ ! -d "$PROFILES_DIR" ]] || ! compgen -G "$PROFILES_DIR/*.json" > /dev/null; then
  info "No saved profiles yet. Use save-profile.sh to create one."
  exit 0
fi

# Resolve active profile
ACTIVE=""
if [[ -L "$PROFILES_DIR/active" ]]; then
  ACTIVE="$(readlink "$PROFILES_DIR/active")"
  ACTIVE="${ACTIVE%.json}"
fi

step "Saved Profiles"
for f in "$PROFILES_DIR"/*.json; do
  name="$(basename "$f" .json)"
  created="$(stat -c '%y' "$f" 2>/dev/null | cut -d' ' -f1)"
  size="$(stat -c '%s' "$f" 2>/dev/null)"

  if [[ "$name" == "$ACTIVE" ]]; then
    echo -e "  ${GREEN}▸ ${BOLD}${name}${NC}  ${CYAN}(active)${NC}  saved: $created  ${size}B"
  else
    echo -e "    ${name}  saved: $created  ${size}B"
  fi
done
