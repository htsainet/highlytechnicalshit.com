# SearXNG Component

Last updated: 2026-04-21 (rev 2)

## What happens here

SearXNG is a privacy-respecting metasearch engine. Used in the stack to
provide web search capabilities to AI agents and RAG pipelines without
sending queries to third-party search APIs.

## Files and structure

| File | Purpose |
|------|---------|
| `searxng.sh` | Full lifecycle: install, configure, start, stop, health |
| `searxng.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Volume layout (two mounts required)

The container entrypoint checks for **both** of these directories and exits
immediately with code 127 if either is missing:

| Mount | Named volume | Purpose |
|-------|-------------|---------|
| `/etc/searxng` | `searxng_data` | Config — `settings.yml` lives here |
| `/var/cache/searxng` | `searxng_cache` | Runtime cache — favicon DB, etc. |

Missing the cache volume was the original startup failure.

## Secret key

`SEARXNG_SECRET_KEY` is **not** read by the image. The entrypoint
auto-generates a random secret and injects it directly into `settings.yml`
on first start (via `sed` on `ultrasecretkey` in the bundled template).
Do not pass a secret via environment variable — the image silently ignores it.

## Permissions

The entrypoint runs as root and sets `FORCE_OWNERSHIP=true` by default,
which means it `chown -R searxng:searxng` the mounted volumes automatically.
No manual `chmod` workaround is needed.

## Granian / IPv6 crash (known issue)

The image (`2026.4.13+`) uses **Granian** as its WSGI server instead of the
older `uwsgi`. Granian defaults to `GRANIAN_HOST="::"` (IPv6 all interfaces).
On a host with IPv6 disabled this produces an immediate crash with exit code 1
and kernel error 97 (`EAFNOSUPPORT` — unsupported address family). The
container exits before the Docker healthcheck `start_period` can run, causing
`docker compose up --wait` to return failure within 1 second.

**Fix**: `GRANIAN_HOST=0.0.0.0` is now set in `docker-compose.yml` (added
2026-04-21, commit `42f3661`) to force IPv4 binding.

Upstream reference: <https://github.com/searxng/searxng/issues/5059>

## Healthcheck

The correct endpoint is `GET /healthz` — returns plain text `OK`.

See [usage.md](./usage.md) for command usage.
