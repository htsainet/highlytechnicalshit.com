# 03-setup-models — Model Setup Documentation

Covers the model seeding scripts for both environments: **prod** and **test**.
Each environment has its own Ollama instance and Stable Diffusion instance,
isolated from one another.

---

## File Structure

```text
03-setup-models.sh           ← master wrapper (runs both)
setup/models/
  prod.sh                    ← prod environment only
  test.sh                    ← test environment only
  helpers.sh                 ← shared functions (not a run target)
```

---

## Quick Start

Run both environments in sequence:

```bash
./03-setup-models.sh
```

Or run a specific environment only:

```bash
./03-setup-models.sh --prod-only
./03-setup-models.sh --test-only
```

Or run each script independently:

```bash
./setup/models/prod.sh
./setup/models/test.sh
```

---

## What Each Script Does

Both scripts follow the same pattern:

1. Create host model directories (`~/models/`, `~/sd-models/`, `~/sd-outputs/`)
2. Start the target Ollama container
3. Wait for it to be ready
4. Pull each Ollama model (skip if already present)
5. Set the default model
6. Pull/download Stable Diffusion checkpoints (skip if already present)
7. Stop the container (except prod, which stays running)

---

## Environments

### Prod (`setup/models/prod.sh`)

Vetted, stable models only. The environment NemoClaw talks to.

| Setting | Value |
|---------|-------|
| Ollama container | `ollama-prod` |
| Ollama port | `11434` |
| SD container | `stable-diffusion-prod` |
| SD port | `7860` |
| Default model | `mistral-nemo:latest` |
| After setup | **Both containers left running** |

**Ollama models:**

- `mistral-nemo:latest`
- `qwen2.5:7b-instruct-q4_K_M`
- `qwen3.5:9b`
- `gurubot/ollamatron:8b-q4_K_M`
- `granite3.1-dense:8b`

**Stable Diffusion:** Factory defaults only — no checkpoints downloaded. The SD WebUI ships with a built-in model that is used as-is.

**To add a model to prod:** Test it in `ollama-test` first, then add it to `OLLAMA_MODELS_PROD` in `setup/models/prod.sh` and re-run the script. It will skip models already present and only pull the new one.

---

### Test (`setup/models/test.sh`)

New arrivals and community models under evaluation. Stopped after seeding — start manually when needed.

| Setting | Value |
|---------|-------|
| Ollama container | `ollama-test` |
| Ollama port | `11435` |
| SD container | `stable-diffusion-test` |
| SD port | `7861` |
| Default model | `qwen3.5:9b` |
| After setup | **Both containers stopped** |

**Ollama models:**

Prod baseline (for comparison):

- `mistral-nemo:latest`
- `qwen3.5:9b`
- `dolphin3:latest`

HuggingFace models under evaluation:

- `hf.co/nvidia/NVIDIA-Nemotron-3-Nano-4B-GGUF:Q4_K_M`
- `hf.co/bartowski/nvidia_Nemotron-Cascade-8B-GGUF:Q4_K_M`
- `hf.co/Jackrong/Qwen3.5-9B-Claude-4.6-Opus-Reasoning-Distilled-v2-GGUF:Q4_K_M`
- `hf.co/ibm-granite/granite-4.0-1b-base-GGUF:F16`

**Stable Diffusion checkpoints:**

- `dreamshaper_v8.safetensors` — versatile / fantasy characters
- `realistic_vision_v5.1.safetensors` — photorealistic (SFW)
- `anything_v5.safetensors` — anime / illustration

**To start the test environment:**

```bash
docker compose up -d ollama-test stable-diffusion-test
```

**To promote a model to prod:** Add it to `OLLAMA_MODELS_PROD` in `setup/models/prod.sh` and re-run that script.

---

## Host Directory Structure

Created automatically by any of the setup scripts:

```text
~/models/
  approved/        ← GGUFs promoted to prod (used via Modelfile)
  testing/         ← GGUFs being evaluated

~/sd-models/
  prod/
    checkpoints/
    loras/
    vae/
    embeddings/
  test/
    checkpoints/
    loras/
    vae/
    embeddings/

~/sd-outputs/
  prod/
  test/
```

---

## Promoting a Model from Test to Prod

```bash
# 1. Copy the GGUF from testing to approved
cp ~/models/testing/mymodel.gguf ~/models/approved/mymodel.gguf

# 2. Add the model to OLLAMA_MODELS_PROD in setup/models/prod.sh

# 3. Re-run prod setup — skips existing models, only pulls new ones
./setup/models/prod.sh
```

---

## Adding a New Model to an Environment

Edit the relevant array in the script and re-run. The skip-if-exists logic means only new models are downloaded:

```bash
# Edit setup/models/test.sh and add your model to OLLAMA_MODELS_TEST
# Then re-run — existing models are skipped automatically
./setup/models/test.sh
```

---

## Shared Helper Functions (`setup/models/helpers.sh`)

| Function | Purpose |
|----------|---------|
| `wait_for_ollama <container> <port>` | Blocks until Ollama API responds, times out after 60s |
| `start_container <service>` | Runs `docker compose up -d <service>` |
| `stop_container <service>` | Runs `docker compose stop <service>` |
| `pull_ollama_if_missing <container> <port> <model>` | Pulls model only if not already present |
| `set_ollama_default <container> <model>` | Creates a `default` alias via Modelfile |
| `find_or_create_sd_volume <grep_term> <service>` | Finds the named volume, starts service to create it if needed |
| `download_sd_if_missing <volume> <filename> <url>` | Downloads a checkpoint via alpine/wget if not present |
| `create_model_dirs` | Creates the full `~/models` and `~/sd-models` directory tree |

---

## Port Reference

| Service | Port |
|---------|------|
| `ollama-prod` | `11434` |
| `ollama-test` | `11435` |
| `stable-diffusion-prod` | `7860` |
| `stable-diffusion-test` | `7861` |

---

## Notes

- **SD checkpoint URLs** — verify each URL at `huggingface.co` before running. Models are occasionally moved or deleted. Failed downloads are cleaned up automatically (partial files are removed).
- **`QUANT_TAG` placeholder** — `nvidia_Nemotron-Cascade-8B-GGUF` uses `Q4_K_M` by default. Change the quant tag in `setup/models/test.sh` if you need a different quantization.
- **Re-running is safe** — all pull and download operations are idempotent. Already-present models are skipped with a `[SKIP]` message.
- **GPU access** — all three Ollama and SD instances request full NVIDIA GPU access via the compose `deploy.resources` block. Only one SD instance should be running at a time to avoid VRAM contention.
