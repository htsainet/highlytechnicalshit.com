# FEATURE-043 — Ollama Model Review & Registry Audit

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | MEDIUM |
| **Effort** | 2–4 hours |
| **Risk** | Low — registry and doc changes; no script logic changes |
| **Target Release** | v0.5.0 |
| **Depends on** | Nothing |
| **Blocks** | Nothing |

## Problem

The current Ollama model registry (`scripts/install/models/registry.json`) has
not been systematically reviewed against the target hardware (RTX 3060 12GB VRAM,
32 GB system RAM).

Known issues identified during hardware review (2026-04-14):

1. **Wrong VRAM annotation** — `gemma4:e4b` is noted as `~7-8GB VRAM` but actual
   usage is ~3–4 GB. The annotation is misleading for capacity planning.
2. **Underutilized VRAM for default chat model** — `gemma4:e4b` (4B, ~3–4 GB VRAM)
   leaves 8–9 GB idle on a 12GB card. Larger models (8B–12B range) ran with
   stability issues during initial setup and were not retested after stack
   stabilization.
3. **No formal test process** — Models in the `test` env have no documented
   validation criteria or promotion checklist.
4. **Legacy models accumulating** — `mistral-nemo:latest` is kept for compatibility
   but has no documented owner or removal criteria.

## Solution

### 1. Fix the known annotation error

Update `gemma4:e4b` VRAM note in `registry.json` from `~7-8GB VRAM` to `~3-4GB VRAM`.

### 2. Audit all prod model VRAM annotations

Verify every prod model note against actual Ollama pull size and measured
VRAM usage on the RTX 3060 12GB. Correct any inaccuracies.

### 3. Retest candidate upgrade models

The primary gap is the default chat model. Candidates to test against
`gemma4:e4b` on the production hardware:

| Candidate | Params | Est. VRAM | Reason to test |
|-----------|--------|-----------|----------------|
| `llama3.1:8b-instruct-q4_K_M` | 8B | ~5.3 GB | Best-supported generalist |
| `qwen2.5:14b-instruct-q4_K_M` | 14B | ~9 GB | Top coding + reasoning |
| `gemma3:12b-instruct-q4_K_M` | 12B | ~7.9 GB | Quality-first chat |

For each candidate:

- Pull via Ollama on prod hardware
- Run a standard prompt battery (5 reasoning, 5 coding, 5 general chat prompts)
- Record tokens/second and VRAM high-water mark
- Compare output quality against current `gemma4:e4b` baseline

### 4. Define model promotion criteria

Document in `registry.json` `_comment` or a companion `REGISTRY-NOTES.md`:

- What "prod-ready" means (VRAM headroom, t/s floor, quality bar)
- How models move from `test` to `prod`
- When legacy models are removed

### 5. Establish a model review cadence

Add a quarterly model review task to `docs/upstream/REFERENCES.md` or
`docs/planning/TODO.md` so the registry doesn't drift against hardware and
model ecosystem advances.

## Acceptance criteria

- [ ] `gemma4:e4b` VRAM annotation corrected in `registry.json`
- [ ] All prod model VRAM annotations verified and corrected as needed
- [ ] At least two candidate models tested and results documented
- [ ] Default chat model decision documented (keep `gemma4:e4b` or promote replacement)
- [ ] Model promotion criteria written and committed

## Notes

- The `deepseek-r1:14b` and `phi4:14b` reasoning models are well-matched to
  the hardware (9 GB VRAM, ~3 GB headroom) and do not need to change.
- `smollm2:135m` sidecar role is correct and should stay.
- Previous difficulty running larger models may be resolved now that the stack
  is stable — worth retesting before assuming the 4B ceiling holds.
- See also `docs/upstream/issues/microsoft-BitNet-WATCH-larger-model.md` for
  the parallel BitNet model watch item.
