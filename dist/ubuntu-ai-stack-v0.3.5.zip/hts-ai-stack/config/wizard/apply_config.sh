#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════╗
# ║       AI STACK — APPLY CONFIG                    ║
# ║       Maps setup menu JSON → .env variables      ║
# ╚══════════════════════════════════════════════════╝
#
# Usage:
#   ./apply_config.sh                          # auto-detect latest ai_stack_config_*.json
#   ./apply_config.sh ai_stack_config_XXX.json # specify a config file
#   ./apply_config.sh --env-file /path/to/.env # specify .env location
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

ok()   { echo -e "${GREEN}  ✓${RESET}  $*"; }
info() { echo -e "${CYAN}  ▸${RESET}  $*"; }
warn() { echo -e "${YELLOW}  ⚠${RESET}  $*"; }
fail() { echo -e "${RED}  ✗${RESET}  $*"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
ENV_FILE="${REPO_ROOT}/.env"
CONFIG_FILE=""

# ── Parse args ────────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --env-file) ENV_FILE="$2"; shift 2 ;;
    *)          CONFIG_FILE="$1"; shift ;;
  esac
done

# ── Find config if not specified ──────────────────────────────────────────────
if [[ -z "$CONFIG_FILE" ]]; then
  # Prefer canonical config/stack.json (written by ai_stack_setup.py)
  if [[ -f "${REPO_ROOT}/config/stack.json" ]]; then
    CONFIG_FILE="${REPO_ROOT}/config/stack.json"
  else
    # Legacy fallback: find latest ai_stack_config_*.json
    CONFIG_FILE=$(find "$SCRIPT_DIR" "$REPO_ROOT" -maxdepth 1 -name 'ai_stack_config_*.json' -printf '%T@\t%p\n' 2>/dev/null | sort -rn | head -1 | cut -f2)
    if [[ -z "$CONFIG_FILE" ]]; then
      fail "No config found. Run ./install.sh or ai_stack_setup.py first."
    fi
  fi
fi

[[ -f "$CONFIG_FILE" ]] || fail "Config file not found: ${CONFIG_FILE}"
info "Config : ${CONFIG_FILE}"
info "Env    : ${ENV_FILE}"
echo ""

# ── Read config and map to .env ───────────────────────────────────────────────
# Uses python3 to parse JSON and emit KEY=VALUE pairs.
ENV_UPDATES=$(python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys

with open(sys.argv[1]) as f:
    cfg = json.load(f)

kvs = []

# Backend engine
backend = cfg.get("backend", "ollama")
kvs.append(("BACKEND_ENGINE", backend))

# Model
model = cfg.get("model", "")
if backend == "ollama" and model:
    kvs.append(("OLLAMA_MODEL", model))
elif backend == "bitnet" and model:
    kvs.append(("BITNET_MODEL", model))

# Model library size
pull_all = cfg.get("pull_all_models", True)
kvs.append(("PULL_ALL_MODELS", "true" if pull_all else "false"))

# Dashboard
dashboard = cfg.get("dashboard", {})
kvs.append(("DASHBOARD_ENABLED", "true" if dashboard.get("enabled") else "false"))

# Instances
instances = cfg.get("instances", {})
mode = instances.get("mode", "single")
kvs.append(("INSTANCE_MODE", mode))
if mode == "prod_test":
    if instances.get("prod_port"):
        kvs.append(("OLLAMA_PROD_PORT", instances["prod_port"]))
    if instances.get("test_port"):
        kvs.append(("OLLAMA_TEST_PORT", instances["test_port"]))

# Model cache
cache = cfg.get("model_cache", {})
if cache.get("type") == "local" and cache.get("path"):
    kvs.append(("MODEL_CACHE_PATH", cache["path"]))
elif cache.get("type") == "network":
    if cache.get("mount"):
        kvs.append(("MODEL_CACHE_MOUNT", cache["mount"]))
        kvs.append(("NAS_SD_CACHE", f"{cache['mount']}/sd-checkpoints"))
        kvs.append(("OLLAMA_DATA_DIR", f"{cache['mount']}/ollama"))
        kvs.append(("OLLAMA_TEST_DATA_DIR", f"{cache['mount']}/ollama-test"))
    if cache.get("share_path"):
        kvs.append(("MODEL_CACHE_SHARE", cache["share_path"]))

# Docker network
network = cfg.get("network", {})
if network.get("mode"):
    kvs.append(("DOCKER_NETWORK_MODE", network["mode"]))

# Comms tokens
comms = cfg.get("comms", {})
tokens = comms.get("tokens", {})
for key, val in tokens.items():
    if val:
        env_key = key.upper()
        kvs.append((env_key, val))

# Admin: Tailscale
admin = cfg.get("admin", {})
if admin.get("tailscale_authkey"):
    kvs.append(("TAILSCALE_AUTHKEY", admin["tailscale_authkey"]))
if admin.get("ssh_port"):
    kvs.append(("SSH_PORT", admin["ssh_port"]))

# Open WebUI URL based on backend
if backend == "bitnet":
    kvs.append(("OLLAMA_BASE_URL", ""))
    kvs.append(("OPENAI_API_BASE_URL", "http://bitnet:8080/v1"))
    kvs.append(("OPENAI_API_KEY", "not-needed"))
else:
    kvs.append(("OLLAMA_BASE_URL", "http://ollama:11434"))
    kvs.append(("OPENAI_API_BASE_URL", ""))

for k, v in kvs:
    print(f"{k}={v}")
PYEOF
)

# ── Upsert each key into .env ────────────────────────────────────────────────
[[ -f "$ENV_FILE" ]] || touch "$ENV_FILE"

while IFS='=' read -r key value; do
  [[ -z "$key" ]] && continue
  if grep -q "^${key}=" "$ENV_FILE"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$ENV_FILE"
    ok "${key}=${value}  (updated)"
  else
    printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
    ok "${key}=${value}  (added)"
  fi
done <<< "$ENV_UPDATES"

echo ""
ok "Config applied to ${ENV_FILE}"

# ── NAS / NFSv4 system config ─────────────────────────────────────────────────
# If NAS is enabled, configure /etc/idmapd.conf so NFSv4 user mapping matches
# the domain set on the Synology (Control Panel → File Services → NFS → Advanced
# Settings → NFSv4/4.1 domain).  Mismatched domains cause files to appear as
# nobody:nogroup on the mounted share.
NAS_CFG=$(python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys
with open(sys.argv[1]) as f:
    nas = json.load(f).get("nas", {})
if nas.get("enabled"):
    print(nas.get("nfs4_domain", "htsai"))
PYEOF
)

if [[ -n "$NAS_CFG" ]]; then
  NFS4_DOMAIN="$NAS_CFG"
  info "NAS enabled — configuring NFSv4 idmapd domain: ${NFS4_DOMAIN}"

  # Ensure nfs-common is installed (provides idmapd)
  if ! command -v idmapd &>/dev/null && ! dpkg -l nfs-common &>/dev/null 2>&1; then
    info "Installing nfs-common ..."
    sudo apt-get install -y nfs-common
  fi

  IDMAPD_CONF="/etc/idmapd.conf"
  if [[ -f "$IDMAPD_CONF" ]]; then
    if grep -q "^Domain" "$IDMAPD_CONF"; then
      sudo sed -i "s|^Domain.*|Domain = ${NFS4_DOMAIN}|" "$IDMAPD_CONF"
    else
      # Insert under [General] section if it exists, else append
      if grep -q "^\[General\]" "$IDMAPD_CONF"; then
        sudo sed -i "/^\[General\]/a Domain = ${NFS4_DOMAIN}" "$IDMAPD_CONF"
      else
        printf '\n[General]\nDomain = %s\n' "$NFS4_DOMAIN" | sudo tee -a "$IDMAPD_CONF" >/dev/null
      fi
    fi
  else
    printf '[General]\nDomain = %s\n' "$NFS4_DOMAIN" | sudo tee "$IDMAPD_CONF" >/dev/null
  fi
  ok "idmapd.conf  Domain = ${NFS4_DOMAIN}"

  # Restart idmapd so the new domain takes effect
  if systemctl is-active --quiet nfs-idmapd 2>/dev/null; then
    sudo systemctl restart nfs-idmapd && ok "nfs-idmapd restarted"
  fi

  # ── /etc/fstab NFS mount entries ────────────────────────────────────────────
  # rsize/wsize 1M: Linux client negotiates the largest block it can use,
  # independent of Synology's UI cap (which only sets the server-side default).
  # nfsvers=4.1: match the Maximum NFS protocol set on the Synology.
  # _netdev: defer mount until network is up; x-systemd.automount: lazy mount.
  NFS_OPTS="nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=5,_netdev,x-systemd.automount"

  NAS_MOUNTS=$(python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys
with open(sys.argv[1]) as f:
    nas = json.load(f).get("nas", {})
if not nas.get("enabled"):
    sys.exit(0)
host = nas.get("host", "")
uses = nas.get("uses", [])
if "model_cache" in uses and nas.get("model_cache_share") and nas.get("model_cache_mount"):
    print(f"{host}:{nas['model_cache_share']} {nas['model_cache_mount']}")
if "docker_backups" in uses and nas.get("docker_backup_share") and nas.get("docker_backup_mount"):
    print(f"{host}:{nas['docker_backup_share']} {nas['docker_backup_mount']}")
if "timeshift" in uses and nas.get("timeshift_share") and nas.get("timeshift_mount"):
    print(f"{host}:{nas['timeshift_share']} {nas['timeshift_mount']}")
PYEOF
  )

  if [[ -n "$NAS_MOUNTS" ]]; then
    info "Configuring NFS mounts in /etc/fstab ..."
    while IFS=' ' read -r share mountpoint; do
      [[ -z "$share" || -z "$mountpoint" ]] && continue
      # Create mount point if missing
      sudo mkdir -p "$mountpoint"
      FSTAB_LINE="${share}  ${mountpoint}  nfs  ${NFS_OPTS}  0  0"
      # Remove any existing entry for this mountpoint then append fresh
      sudo sed -i "\|[[:space:]]${mountpoint}[[:space:]]|d" /etc/fstab
      echo "$FSTAB_LINE" | sudo tee -a /etc/fstab >/dev/null
      ok "fstab: ${share}  →  ${mountpoint}"
    done <<< "$NAS_MOUNTS"
    info "Reloading systemd daemon to recognize new mounts..."
    sudo systemctl daemon-reload
    info "Run 'sudo mount -a' to mount now, or reboot to mount automatically."
  fi
fi

# After NFS mount is active, create subdirectories so Docker doesn't try to chown them
info "Creating model cache subdirectories (will be created after 'sudo mount -a')..."
MODEL_CACHE_MOUNT=$(grep "^MODEL_CACHE_MOUNT=" "$ENV_FILE" | cut -d= -f2)
if [[ -n "$MODEL_CACHE_MOUNT" && -d "$MODEL_CACHE_MOUNT" ]]; then
  sudo mkdir -p "$MODEL_CACHE_MOUNT"/{ollama,ollama-test,sd-checkpoints}
  sudo chmod 755 "$MODEL_CACHE_MOUNT"/{ollama,ollama-test,sd-checkpoints}
  ok "Model cache subdirectories created"
fi

info "Start the stack: cd ${REPO_ROOT} && ./06-start-stack.sh"
