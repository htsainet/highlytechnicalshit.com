#!/usr/bin/env bash
# push-to-nas.sh — Tag and push all cached Docker images to a local NAS registry
#
# Usage:  ./push-to-nas.sh [registry]
#         ./push-to-nas.sh <nas>:5000
#
# Requires: Docker daemon running, images already pulled (via pull-all-images.sh),
#           and the NAS registry accessible over HTTP.
#
# NOTE: If the registry uses HTTP (not HTTPS), add it to Docker's insecure registries:
#   /etc/docker/daemon.json → {"insecure-registries": ["<nas>:5000"]}
#   Then: sudo systemctl restart docker

set -uo pipefail

REGISTRY="${1:-<nas>:5000}"

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Each entry: "source_ref|tag_as"
# source_ref is what docker knows it as (pulled with digest → use digest ref)
# tag_as is the clean name to push under (preserving original path)
IMAGES=(
  "alphacep/kaldi-vosk-server@sha256:381024347b954835c9c20adea2041377e7b55f50d4c5887eb42101bbf6e750a1|alphacep/kaldi-vosk-server:latest"
  "erikvl87/languagetool@sha256:e1ea6a97538848ba824076ee197eccdc81e5faeeac497512c74b2f556a1b5759|erikvl87/languagetool:6.7-dockerupdate-3"
  "flowiseai/flowise@sha256:c99242725f0663dbff1c4375500a5c0094ff7635a83510650d53e0573a7be1f6|flowiseai/flowise:latest"
  "gitea/gitea:1.25.5|gitea/gitea:1.25.5"
  "grafana/grafana-oss:12.4.2|grafana/grafana-oss:12.4.2"
  "langflowai/langflow@sha256:01b48149017d0a211cb4dd0b7454bd4ff68870937b9037c0c2c0928d24868ce1|langflowai/langflow:1.9.0"
  "mmartial/comfyui-nvidia-docker@sha256:20fea207e2552c3d72811aef4319bb5bc1064651ed8c8d40b8627210171f23e7|mmartial/comfyui-nvidia-docker:ubuntu24_cuda12.6.3-latest"
  "nginx:1.29-alpine|nginx:1.29-alpine"
  "node:20-slim|node:20-slim"
  "nvidia/dcgm-exporter:4.5.2-4.8.1-distroless|nvidia/dcgm-exporter:4.5.2-4.8.1-distroless"
  "ollama/ollama@sha256:0455f166da85b1d07f694c33ba09278ca649603c0611ba8e46272b16eed7fccd|ollama/ollama:0.20.2"
  "portainer/portainer-ce:2.40.0|portainer/portainer-ce:2.40.0"
  "prom/prometheus:v3.11.0|prom/prometheus:v3.11.0"
  "python@sha256:3d5ed973e45820f5ba5e46bd065bd88b3a504ff0724d85980dcd05eab361fcf4|python:3.12-slim"
  "pytorch/pytorch:2.6.0-cuda12.6-cudnn9-runtime|pytorch/pytorch:2.6.0-cuda12.6-cudnn9-runtime"
  "searxng/searxng@sha256:4c6b4f3e1fc10a907a40b7eaaf5b92d50f5b4097d6fb5b02041c0f9926233b36|searxng/searxng:2026.4.13-ee66b070a"
  "tailscale/tailscale:v1.96.5|tailscale/tailscale:v1.96.5"
  "ubuntu@sha256:186072bba1b2f436cbb91ef2567abca677337cfc786c86e107d25b7072feef0c|ubuntu:24.04"
  "unsloth/unsloth:2026.4.4-pt2.9.0-vllm-0.16.0-cu12.8-studio-release-v0.1.35-beta|unsloth/unsloth:2026.4.4-pt2.9.0-vllm-0.16.0-cu12.8-studio-release-v0.1.35-beta"
  "ghcr.io/coqui-ai/tts@sha256:bdbe05ed859448c620b698e18b8c8aced8fa82329e9ef22de60430d44963df19|ghcr.io/coqui-ai/tts:v0.22.0"
  "ghcr.io/google/cadvisor:0.56.2|ghcr.io/google/cadvisor:0.56.2"
  "ghcr.io/mostlygeek/llama-swap@sha256:f6355e100aa9af3daedb61f1967704220a578d71957d4e964dcc4cd201158b04|ghcr.io/mostlygeek/llama-swap:cpu"
  "ghcr.io/open-webui/open-webui@sha256:b8095f79a6a8ffad8f830bdacc9b5b0aef805689b31bca0b065cc2424d3cfaeb|ghcr.io/open-webui/open-webui:main"
  "ghcr.io/open-webui/pipelines@sha256:b48e9bc338ce2be0acfbeff01810db72408a12f07739f9e3879c1f2b00952d6e|ghcr.io/open-webui/pipelines:main"
  "ghcr.io/openclaw/openclaw@sha256:7ea070b04d1e70811fe8ba15feaad5890b1646021b24e00f4795bd4587a594ed|ghcr.io/openclaw/openclaw:2026.4.14"
  "ghcr.io/sillytavern/sillytavern@sha256:5520831198cdb30ede4ae6c481a5a36257d4e9e3177512d6e28d0c7bb1c9e76f|ghcr.io/sillytavern/sillytavern:latest"
  "ghcr.io/speaches-ai/speaches@sha256:6ec12ebf890a17e0d4b242a8ba9e0eb1fb836e60e8a3c857aea9838d541579ac|ghcr.io/speaches-ai/speaches:0.8.1-cuda"
  "docker.n8n.io/n8nio/n8n@sha256:ad20607cdd24bac004ec44804b6b8ded9a2fbf92ed46c4496bf007762c883af2|docker.n8n.io/n8nio/n8n:2.16.1"
  "lscr.io/linuxserver/duplicati@sha256:1e4f61e7c4ac5bb79196d2a56c416cc8b9371ff6f7ac89971701e3bfd9a658ae|lscr.io/linuxserver/duplicati:v2.3.0.0_stable_2026-04-14-ls288"
  "quay.io/go-skynet/local-ai@sha256:8b9688beeaeac2f12a4dcc632e7094adb58f86cf2dbc88570b29a879e135ea10|quay.io/go-skynet/local-ai:v4.1.3-gpu-nvidia-cuda-12"
)

TOTAL=${#IMAGES[@]}
PUSHED=0
FAILED=0
FAILED_LIST=()

# Verify registry is reachable
echo -e "${YELLOW}Testing registry at ${REGISTRY}...${NC}"
if ! curl -sf "http://${REGISTRY}/v2/" > /dev/null 2>&1; then
  echo -e "${RED}ERROR: Cannot reach http://${REGISTRY}/v2/${NC}"
  echo "Make sure the registry container is running on the NAS."
  echo "If using HTTP, add to /etc/docker/daemon.json:"
  echo "  {\"insecure-registries\": [\"${REGISTRY}\"]}"
  exit 1
fi
echo -e "${GREEN}Registry OK${NC}"
echo ""

echo -e "${YELLOW}Tagging and pushing ${TOTAL} images to ${REGISTRY}...${NC}"
echo ""

for entry in "${IMAGES[@]}"; do
  SRC="${entry%%|*}"
  TAG_AS="${entry##*|}"
  REMOTE="${REGISTRY}/${TAG_AS}"

  echo -n "  [$((PUSHED + FAILED + 1))/${TOTAL}] ${TAG_AS} ... "

  # Tag the local image for the NAS registry
  if ! docker tag "${SRC}" "${REMOTE}" 2>/dev/null; then
    echo -e "${RED}TAG FAILED${NC}"
    FAILED_LIST+=("${TAG_AS}")
    ((FAILED++)) || true
    continue
  fi

  # Push to NAS registry (fall back to skopeo if docker push fails)
  if docker push "${REMOTE}" --quiet > /dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
    ((PUSHED++)) || true
  elif command -v skopeo &>/dev/null; then
    echo -n "docker push failed, trying skopeo ... "
    if skopeo copy --dest-tls-verify=false \
        "docker://${TAG_AS}" \
        "docker://${REMOTE}" > /dev/null 2>&1; then
      echo -e "${GREEN}OK (skopeo)${NC}"
      ((PUSHED++)) || true
    else
      echo -e "${RED}FAILED${NC}"
      FAILED_LIST+=("${TAG_AS}")
      ((FAILED++)) || true
    fi
  else
    echo -e "${RED}PUSH FAILED${NC}"
    FAILED_LIST+=("${TAG_AS}")
    ((FAILED++)) || true
  fi

  # Clean up the local tag (keeps original image)
  docker rmi "${REMOTE}" > /dev/null 2>&1 || true
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "  ${GREEN}Pushed: ${PUSHED}${NC}  ${RED}Failed: ${FAILED}${NC}  Total: ${TOTAL}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [[ ${#FAILED_LIST[@]} -gt 0 ]]; then
  echo ""
  echo -e "${RED}Failed images:${NC}"
  for f in "${FAILED_LIST[@]}"; do
    echo "  - $f"
  done
fi

echo ""
echo "Verify with: curl http://${REGISTRY}/v2/_catalog"
