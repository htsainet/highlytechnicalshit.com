#!/usr/bin/env bash
# scripts/components/sillytavern.sh — SillyTavern character chat frontend
#
# Standalone usage:
#   ./scripts/components/sillytavern.sh            # install + configure + start + health
#   ./scripts/components/sillytavern.sh --health   # health check only
#   ./scripts/components/sillytavern.sh --stop     # stop SillyTavern
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
SILLYTAVERN_CONTAINER="${SILLYTAVERN_CONTAINER:-hts-ai-sillytavern}"
SILLYTAVERN_PORT="${SILLYTAVERN_PORT:-8000}"

# ── Functions ────────────────────────────────────────────────────────────────

# sillytavern_install — Pull the SillyTavern container image
sillytavern_install() {
  step "SillyTavern — install"
  compose_pull --profile sillytavern
  ok "SillyTavern image pulled."
}

# sillytavern_configure — Ensure .env has SillyTavern port
sillytavern_configure() {
  step "SillyTavern — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^SILLYTAVERN_PORT=" "$env_file" 2>/dev/null; then
    printf 'SILLYTAVERN_PORT=%s\n' "$SILLYTAVERN_PORT" >> "$env_file"
    info "Added SILLYTAVERN_PORT=${SILLYTAVERN_PORT} to .env"
  fi

  ok "SillyTavern configured (port ${SILLYTAVERN_PORT})."
}

# sillytavern_start — Bring up SillyTavern via compose
sillytavern_start() {
  step "SillyTavern — start"
  compose_up --profile sillytavern
  ok "SillyTavern started on port ${SILLYTAVERN_PORT}."
}

# sillytavern_stop — Bring down SillyTavern
sillytavern_stop() {
  step "SillyTavern — stop"
  compose_down --profile sillytavern
  ok "SillyTavern stopped."
}

# sillytavern_health — Probe the SillyTavern web UI
sillytavern_health() {
  health_probe "SillyTavern :${SILLYTAVERN_PORT}" "http://localhost:${SILLYTAVERN_PORT}/"
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      sillytavern_install
      sillytavern_configure
      sillytavern_start
      sillytavern_health
      ;;
    health)
      sillytavern_health
      ;;
    stop)
      sillytavern_stop
      ;;
  esac
fi
