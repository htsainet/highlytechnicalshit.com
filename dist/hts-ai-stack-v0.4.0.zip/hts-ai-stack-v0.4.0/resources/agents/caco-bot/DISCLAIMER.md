# Content Disclaimer

The caco-bot persona is a **fictional character** designed as a retro-gaming
enthusiast with a deliberately provocative personality. It contains:

- Strong language and profanity (in-character)
- Opinionated hot-takes on gaming topics
- Deliberately confrontational conversational style

This persona is provided as an **example of character-driven agent design**.
It includes a PRIME DIRECTIVE that prohibits instructions related to real
violence, self-harm, illegal activity, or genuine harassment.

**This content does not reflect the views of the project maintainers.**
