$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))

    # Detect backend engine from .env
    $envFile = Join-Path $script:RepoRoot '.env'
    $script:BackendEngine = 'ollama'
    if (Test-Path $envFile) {
        $match = Select-String -Path $envFile -Pattern '^BACKEND_ENGINE=(.+)$' -ErrorAction SilentlyContinue
        if ($match) { $script:BackendEngine = $match.Matches[0].Groups[1].Value.Trim() }
    }
}

Describe 'Docker compose validation' {
    It 'docker-compose.yml is valid YAML' {
        $composeFile = Join-Path $script:RepoRoot 'docker-compose.yml'
        $composeFile | Should -Exist
        { docker compose -f $composeFile config --quiet 2>&1 } | Should -Not -Throw
    }

    It 'defines the expected core services' {
        $composeFile = Join-Path $script:RepoRoot 'docker-compose.yml'
        $services = docker compose -f $composeFile config --services 2>&1 | Sort-Object
        $services | Should -Contain 'dashboard'
        $services | Should -Contain 'open-webui'
        $services | Should -Contain 'ollama-gpu'
        $services | Should -Contain 'bitnet-cpu'
    }

    It 'all service images follow hts-ai-* naming convention' {
        $composeFile = Join-Path $script:RepoRoot 'docker-compose.yml'
        $Content = Get-Content $composeFile -Raw
        $ImageLines = @([regex]::Matches($Content, '^\s+image:\s*(.+)$', 'Multiline') | ForEach-Object {
            $_.Groups[1].Value.Trim()
        })
        $ImageLines.Count | Should -BeGreaterThan 0 -Because "docker-compose.yml should define images"
        $ImageLines | ForEach-Object {
            $_ | Should -Match '^hts-ai-' -Because "image '$_' should follow the hts-ai-* naming convention"
        }
    }

    It 'all services have required com.htsai labels' {
        $composeFile = Join-Path $script:RepoRoot 'docker-compose.yml'
        $AllProfiles = @('dashboard','gitea','ollama-gpu','bitnet-cpu','llama-swap','openspace','deerflow','unsloth','tailscale')
        $profileArgs = ($AllProfiles | ForEach-Object { "--profile $_" }) -join ' '
        $json = Invoke-Expression "docker compose -f $composeFile $profileArgs config --format json 2>&1" | ConvertFrom-Json
        $json.services.PSObject.Properties | ForEach-Object {
            $svc = $_.Name
            $labels = $_.Value.labels
            $labels.'com.htsai.stack'      | Should -Be 'hts-ai-stack' -Because "service '$svc' needs com.htsai.stack label"
            $labels.'com.htsai.managed-by'  | Should -Be 'docker-compose' -Because "service '$svc' needs com.htsai.managed-by label"
            $labels.'com.htsai.role'        | Should -Not -BeNullOrEmpty -Because "service '$svc' needs com.htsai.role label"
        }
    }

    It 'defines the ai-network bridge network' {
        $composeFile = Join-Path $script:RepoRoot 'docker-compose.yml'
        $networks = docker compose -f $composeFile config --format json 2>&1 | ConvertFrom-Json
        $networks.networks.PSObject.Properties.Name | Should -Contain 'ai-network'
    }
}

Describe 'Docker network' {
    It 'ai-network exists' {
        $network = docker network ls --filter name=hts-ai-stack_ai-network --format '{{.Name}}' 2>&1
        $network | Should -Not -BeNullOrEmpty
    }

    It 'ai-network uses bridge driver' {
        $driver = docker network inspect hts-ai-stack_ai-network --format '{{.Driver}}' 2>&1
        $driver | Should -Be 'bridge'
    }
}

Describe 'Container health — Ollama backend' -Skip:($script:BackendEngine -ne 'ollama') {
    It 'dashboard is running' {
        $status = docker inspect --format '{{.State.Status}}' hts-ai-dashboard 2>&1
        $status | Should -Be 'running'
    }

    It 'ollama is running and healthy' {
        $status = docker inspect --format '{{.State.Status}}' hts-ai-ollama-gpu 2>&1
        $status | Should -Be 'running'
        $health = docker inspect --format '{{.State.Health.Status}}' hts-ai-ollama-gpu 2>&1
        $health | Should -Be 'healthy'
    }

    It 'open-webui is running' {
        $status = docker inspect --format '{{.State.Status}}' hts-ai-open-webui 2>&1
        $status | Should -Be 'running'
    }
}

Describe 'Container health — BitNet backend' -Skip:($script:BackendEngine -ne 'bitnet') {
    It 'dashboard is running' {
        $status = docker inspect --format '{{.State.Status}}' hts-ai-dashboard 2>&1
        $status | Should -Be 'running'
    }

    It 'bitnet is running and healthy' {
        $status = docker inspect --format '{{.State.Status}}' hts-ai-bitnet-cpu 2>&1
        $status | Should -Be 'running'
        $health = docker inspect --format '{{.State.Health.Status}}' hts-ai-bitnet-cpu 2>&1
        $health | Should -Be 'healthy'
    }

    It 'open-webui is running' {
        $status = docker inspect --format '{{.State.Status}}' hts-ai-open-webui 2>&1
        $status | Should -Be 'running'
    }
}

Describe 'Endpoint health — Ollama backend' -Skip:($script:BackendEngine -ne 'ollama') {
    It 'dashboard responds on :80' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:80 2>&1
        $response | Should -Be '200'
    }

    It 'ollama API responds on :11434' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:11434/api/tags 2>&1
        $response | Should -Be '200'
    }

    It 'open-webui responds on :3000' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:3000 2>&1
        $response | Should -Be '200'
    }
}

Describe 'Endpoint health — BitNet backend' -Skip:($script:BackendEngine -ne 'bitnet') {
    It 'dashboard responds on :80' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:80 2>&1
        $response | Should -Be '200'
    }

    It 'bitnet API responds on :8080' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:8080/v1/models 2>&1
        $response | Should -Be '200'
    }

    It 'open-webui responds on :3000' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:3000 2>&1
        $response | Should -Be '200'
    }
}

Describe 'Script inventory' {
    It 'has the expected entry-point scripts' {
        foreach ($script in @('bootstrap.sh', 'install.sh', 'setup.sh', 'nuke-stack.sh')) {
            $path = Join-Path $script:RepoRoot $script
            $path | Should -Exist -Because "$script must exist"
            $mode = (Get-Item -LiteralPath $path -Force).UnixFileMode
            ($mode -band [System.IO.UnixFileMode]::UserExecute) | Should -Not -Be 0 -Because "$script must be executable"
        }
    }

    It 'entry-point scripts pass bash -n syntax check' {
        foreach ($script in @('bootstrap.sh', 'install.sh', 'setup.sh', 'nuke-stack.sh')) {
            $path = Join-Path $script:RepoRoot $script
            & bash -n $path
            $LASTEXITCODE | Should -Be 0 -Because "$script must parse cleanly"
        }
    }
}

Describe 'Host install manifest' {
    BeforeAll {
        $script:ManifestPath = Join-Path $script:RepoRoot 'logs/manifest.json'
    }

    It 'manifest.json exists and is valid JSON' -Skip:(-not (Test-Path (Join-Path ([System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))) 'logs/manifest.json'))) {
        $raw = Get-Content $script:ManifestPath -Raw
        { $raw | ConvertFrom-Json } | Should -Not -Throw
    }

    It 'every manifest entry has the required fields' -Skip:(-not (Test-Path (Join-Path ([System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))) 'logs/manifest.json'))) {
        $entries = Get-Content $script:ManifestPath -Raw | ConvertFrom-Json
        $entries.Count | Should -BeGreaterThan 0 -Because 'manifest should have at least one entry'
        $entries | ForEach-Object {
            $_.component  | Should -Not -BeNullOrEmpty -Because "entry needs a component name"
            $_.method     | Should -Not -BeNullOrEmpty -Because "component '$($_.component)' needs an install method"
            $_.timestamp  | Should -Match '^\d{4}-\d{2}-\d{2}T' -Because "component '$($_.component)' needs an ISO timestamp"
            $_.script     | Should -Not -BeNullOrEmpty -Because "component '$($_.component)' needs a source script"
        }
    }

    It 'manifest.sh passes bash syntax check' {
        $path = Join-Path $script:RepoRoot 'scripts/lib/manifest.sh'
        $path | Should -Exist
        & bash -n $path
        $LASTEXITCODE | Should -Be 0
    }
}

Describe 'Host alignment check' {
    It 'check-host-alignment.sh passes bash syntax check' {
        $path = Join-Path $script:RepoRoot 'scripts/utils/check-host-alignment.sh'
        $path | Should -Exist
        & bash -n $path
        $LASTEXITCODE | Should -Be 0
    }

    It 'check-host-alignment.sh --json produces valid structured output' {
        $path = Join-Path $script:RepoRoot 'scripts/utils/check-host-alignment.sh'
        $raw = & bash $path --json 2>$null
        $json = $raw | ConvertFrom-Json
        $json.aligned    | Should -Not -BeNullOrEmpty -Because 'report needs an aligned flag'
        $json.timestamp.ToString() | Should -Match '\d{4}' -Because 'report needs a timestamp'
        $json.summary.total     | Should -BeGreaterThan 0 -Because 'report needs a package count'
        $json.summary.installed | Should -BeGreaterOrEqual 0
        $json.summary.missing   | Should -BeGreaterOrEqual 0
        $json.packages   | Should -Not -BeNullOrEmpty -Because 'report needs a packages array'
    }
}

Describe 'Nuke and Pave' {
    It 'install.sh recognises --nuke-and-pave flag' {
        $path = Join-Path $script:RepoRoot 'install.sh'
        $content = Get-Content $path -Raw
        $content | Should -Match '--nuke-and-pave' -Because 'install.sh must accept the flag'
        $content | Should -Match 'NUKE_AND_PAVE=true' -Because 'flag must set the variable'
    }

    It 'install.sh offers [p] Nuke & Pave in menu' {
        $path = Join-Path $script:RepoRoot 'install.sh'
        $content = Get-Content $path -Raw
        $content | Should -Match '\[p\] Nuke & Pave' -Because 'interactive menu must offer pave option'
    }

    It 'nuke-and-pave clears the install manifest' {
        $path = Join-Path $script:RepoRoot 'install.sh'
        $content = Get-Content $path -Raw
        $content | Should -Match 'rm -f.*manifest\.json' -Because 'pave must clear stale manifest'
    }
}
