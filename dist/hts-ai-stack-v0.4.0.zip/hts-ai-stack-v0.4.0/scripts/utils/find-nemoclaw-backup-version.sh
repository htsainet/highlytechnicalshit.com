#!/usr/bin/env bash
# find-nemoclaw-backup-version.sh — Identify the NemoClaw / OpenShell versions
# that were installed in previous (pre-nuke) snapshots on the NAS.
#
# Purpose:
#   Upstream NVIDIA/NemoClaw has no tags/releases and ships "alpha" software
#   that changes on every commit to main. When current installs fail, we want
#   to pin NEMOCLAW_INSTALL_TAG / OPENSHELL_VERSION to the last known-good
#   build. This script scrapes version metadata out of the Synology backups.
#
# What it searches:
#   /mnt/htsai-timeshift-backup  — system-level timeshift snapshots (most
#                                  likely to contain $HOME/.nvm/...)
#   /mnt/htsai-disk-image        — full-disk images (raw/qcow2 — not walked)
#   /mnt/htsai-docker-volume-backup — docker volumes (may contain sandbox
#                                     state, blueprint.yaml)
#
# For each mount it looks for:
#   • npm global install: .../node_modules/{nemoclaw,openshell}/package.json
#     → reports "version", "gitHead", "_from", "_resolved"
#   • blueprint.yaml (pins both nemoclaw + openshell versions together)
#   • any .nemoclaw/ config dirs
#
# Usage:
#   sudo ./scripts/utils/find-nemoclaw-backup-version.sh
#     sudo is required — NFS backup mounts are typically root-readable only.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source common helpers if available; fall back to minimal inline helpers so
# the script is runnable standalone (e.g. if repo checkout is partial).
if [[ -f "$REPO_DIR/scripts/lib/common.sh" ]]; then
  # shellcheck disable=SC1091
  source "$REPO_DIR/scripts/lib/common.sh"
else
  step() { echo; echo "==> $*"; }
  info() { echo "    $*"; }
  ok()   { echo "[OK] $*"; }
  warn() { echo "[WARN] $*" >&2; }
  fail() { echo "[ERROR] $*" >&2; exit 1; }
fi

MOUNTS=(
  /mnt/htsai-timeshift-backup
  /mnt/htsai-docker-volume-backup
  /mnt/htsai-disk-image
  /mnt/htsai-model-backup
)

# ── preflight ─────────────────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
  warn "Not running as root — NFS backup mounts may be unreadable."
  warn "Re-run with: sudo $0"
fi

any_mounted=false
for m in "${MOUNTS[@]}"; do
  if [[ -d "$m" ]] && mountpoint -q "$m" 2>/dev/null; then
    any_mounted=true
  fi
done
$any_mounted || fail "No NAS mounts found under /mnt/htsai-*. Run ./scripts/host/nas-setup.sh first."

# ── 1. package.json scan (npm global installs) ────────────────────────────────
step "Scanning backups for nemoclaw/openshell package.json"

# -L follows symlinks (timeshift snapshots are link-heavy).
# -path filter keeps us out of huge model/data trees.
found_pkg=false
while IFS= read -r pkg; do
  found_pkg=true
  name=$(grep -oE '"name"[[:space:]]*:[[:space:]]*"[^"]+"' "$pkg" | head -1 | sed -E 's/.*"([^"]+)"$/\1/')
  [[ "$name" =~ ^(nemoclaw|openshell)$ ]] || continue
  echo
  info "── $pkg"
  grep -E '"(name|version|gitHead|_from|_resolved|_integrity)"' "$pkg" 2>/dev/null \
    | sed 's/^[[:space:]]*/      /' \
    || info "(could not read version fields)"
done < <(find -L "${MOUNTS[@]}" \
            \( -path '*/node_modules/nemoclaw/package.json' \
            -o -path '*/node_modules/openshell/package.json' \) \
            2>/dev/null)

$found_pkg || warn "No nemoclaw/openshell package.json files found in backups."

# ── 2. blueprint.yaml scan ────────────────────────────────────────────────────
step "Scanning backups for NemoClaw blueprint.yaml (pins openshell + nemoclaw together)"

found_bp=false
while IFS= read -r bp; do
  found_bp=true
  echo
  info "── $bp"
  grep -E 'openshell|nemoclaw|version|image|tag' "$bp" 2>/dev/null \
    | head -40 \
    | sed 's/^/      /'
done < <(find -L "${MOUNTS[@]}" -name 'blueprint.yaml' 2>/dev/null)

$found_bp || warn "No blueprint.yaml files found in backups."

# ── 3. ~/.nemoclaw state dirs ─────────────────────────────────────────────────
step "Scanning backups for .nemoclaw state directories"

found_state=false
while IFS= read -r d; do
  found_state=true
  echo
  info "── $d"
  ls -la "$d" 2>/dev/null | head -20 | sed 's/^/      /'
  for f in "$d"/config.json "$d"/state.json "$d"/version; do
    if [[ -f "$f" ]]; then
      echo "      --- $(basename "$f") ---"
      head -30 "$f" 2>/dev/null | sed 's/^/        /'
    fi
  done
done < <(find -L "${MOUNTS[@]}" -type d -name '.nemoclaw' 2>/dev/null)

$found_state || info "No .nemoclaw state dirs found (expected — they live in $HOME on host)."

# ── 4. openshell binary metadata in backups ───────────────────────────────────
step "Scanning backups for openshell CLI binary (cli/dist/index.js banner)"

while IFS= read -r f; do
  if grep -l 'openshell' "$f" >/dev/null 2>&1; then
    ver=$(grep -oE '"version"[[:space:]]*:[[:space:]]*"[0-9]+\.[0-9]+\.[0-9]+"' "$f" | head -1 || true)
    [[ -n "$ver" ]] && { echo; info "── $f"; info "      $ver"; }
  fi
done < <(find -L "${MOUNTS[@]}" -path '*/openshell/cli/package.json' 2>/dev/null)

echo
ok "Scan complete."
echo
echo "Next step: take the highest 'gitHead' from a known-good snapshot and pin it in:"
echo "  scripts/components/nemoclaw/nemoclaw.manifest.json  → .upstream.pinned_version"
echo "  scripts/components/nemoclaw/nemoclaw.sh             → NEMOCLAW_INSTALL_TAG=<sha>"
