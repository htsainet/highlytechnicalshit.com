$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:WizardScript = Join-Path $script:RepoRoot 'config/wizard/ai_stack_setup.sh'
}

function global:Invoke-WizardMenuMockRun {
    param(
        [string]$ExternalOllama = 'no',
        [string]$ExternalWebUI = 'no'
    )

    $runId = [Guid]::NewGuid().ToString('N')
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) "wizard-menu-test-$runId"
    $repoRoot = Join-Path $tempRoot 'repo'
    $wizardDir = Join-Path $repoRoot 'config/wizard'
    $mockBin = Join-Path $tempRoot 'mockbin'
    $mockLog = Join-Path $tempRoot 'whiptail.log'
    $runLog = Join-Path $tempRoot 'wizard.log'

    New-Item -ItemType Directory -Path $wizardDir -Force | Out-Null
    New-Item -ItemType Directory -Path $mockBin -Force | Out-Null

    $wizardCopy = Join-Path $wizardDir 'ai_stack_setup.sh'
    Copy-Item -Path $script:WizardScript -Destination $wizardCopy -Force

    $mockWhiptail = @'
#!/usr/bin/env bash
set -euo pipefail

args="$*"
echo "$args" >> "${MOCK_LOG:?MOCK_LOG not set}"

if [[ "$args" == *"--menu"* ]]; then
  case "$args" in
    *"[1/6] Backend Engine"*) echo "ollama" >&2 ;;
    *"[2/6] Default Model"*) echo "llama3.2:3b" >&2 ;;
    *"[3/6] Deployment Instances"*) echo "single" >&2 ;;
    *) echo "single" >&2 ;;
  esac
  exit 0
fi

if [[ "$args" == *"--checklist"* ]]; then
  case "$args" in
    *"[5/6] Extra Components"*) echo "open_webui nginx" >&2 ;;
    *) echo "" >&2 ;;
  esac
  exit 0
fi

if [[ "$args" == *"--inputbox"* ]]; then
  if [[ "$#" -gt 0 ]]; then
    printf '%s\n' "${@: -1}" >&2
  else
    printf '\n' >&2
  fi
  exit 0
fi

if [[ "$args" == *"--yesno"* ]]; then
  # Save confirmation: Yes
  if [[ "$args" == *"Save Configuration?"* ]]; then
    exit 0
  fi

  # External Ollama: No (install ours) unless env override
  if [[ "$args" == *"Existing Ollama"* ]]; then
    [[ "${WIZARD_EXTERNAL_OLLAMA:-no}" == "yes" ]] && exit 0
    exit 1
  fi

  # External Open WebUI: No (install ours) unless env override
  if [[ "$args" == *"Existing Open WebUI"* ]]; then
    [[ "${WIZARD_EXTERNAL_WEBUI:-no}" == "yes" ]] && exit 0
    exit 1
  fi

  # All optional feature prompts default to No.
  exit 1
fi

if [[ "$args" == *"--msgbox"* ]]; then
  exit 0
fi

exit 0
'@

    $mockWhiptailPath = Join-Path $mockBin 'whiptail'
    Set-Content -Path $mockWhiptailPath -Value $mockWhiptail -NoNewline
    & bash -c "chmod +x '$mockWhiptailPath'"

    $pathWithMock = "${mockBin}:$([Environment]::GetEnvironmentVariable('PATH'))"

    & bash -c "cd '$repoRoot' && PATH='$pathWithMock' MOCK_LOG='$mockLog' WIZARD_EXTERNAL_OLLAMA='$ExternalOllama' WIZARD_EXTERNAL_WEBUI='$ExternalWebUI' bash '$wizardCopy'" *> $runLog
    $exitCode = $LASTEXITCODE

    $stackJsonPath = Join-Path $repoRoot 'config/stack.json'
    $stackJson = $null
    if (Test-Path $stackJsonPath) {
        $stackJson = Get-Content -Path $stackJsonPath -Raw | ConvertFrom-Json
    }

    [PSCustomObject]@{
        ExitCode = $exitCode
        StackJsonPath = $stackJsonPath
        StackJson = $stackJson
        MockLogPath = $mockLog
        MockLog = if (Test-Path $mockLog) { Get-Content -Path $mockLog -Raw } else { '' }
        RunLogPath = $runLog
        TempRoot = $tempRoot
    }
}

Describe 'Wizard menu flow validation' {
    It 'completes MVP run with managed Ollama and Open WebUI' {
        $result = Invoke-WizardMenuMockRun
        try {
            $result.ExitCode | Should -Be 0
            (Test-Path $result.StackJsonPath) | Should -BeTrue
            $result.StackJson.backend | Should -Be 'ollama'
            $result.StackJson.services.ollama.use_external | Should -BeFalse
            $result.StackJson.services.open_webui.use_external | Should -BeFalse
            $result.StackJson.services.nemoclaw.deploy | Should -BeTrue
        }
        finally {
            if (Test-Path $result.TempRoot) {
                Remove-Item -Path $result.TempRoot -Recurse -Force
            }
        }
    }

    It 'writes MVP defaults for disabled features' {
        $result = Invoke-WizardMenuMockRun
        try {
            $result.ExitCode | Should -Be 0
            $result.StackJson.model_cache.type | Should -Be 'none'
            $result.StackJson.nas.enabled | Should -BeFalse
            $result.StackJson.voice.enabled | Should -BeFalse
            $result.StackJson.images.enabled | Should -BeFalse
            $result.StackJson.claw3d.enabled | Should -BeFalse
            $result.StackJson.paperclip.enabled | Should -BeFalse
            $result.StackJson.openspace.enabled | Should -BeFalse
            $result.StackJson.deerflow.enabled | Should -BeFalse
        }
        finally {
            if (Test-Path $result.TempRoot) {
                Remove-Item -Path $result.TempRoot -Recurse -Force
            }
        }
    }

    It 'visits all MVP screens in order' {
        $result = Invoke-WizardMenuMockRun
        try {
            $result.ExitCode | Should -Be 0
            $result.MockLog | Should -Match '(?s)\[1/6\] Backend Engine.*\[1/6\] Existing Ollama.*\[1/6\] Existing Open WebUI.*\[2/6\] Default Model.*\[3/6\] Deployment Instances.*\[4/6\] Quick Dashboard.*\[5/6\] Extra Components.*Save Configuration\?'
        }
        finally {
            if (Test-Path $result.TempRoot) {
                Remove-Item -Path $result.TempRoot -Recurse -Force
            }
        }
    }

    It 'records external Ollama URL in config when user opts in' {
        $result = Invoke-WizardMenuMockRun -ExternalOllama 'yes'
        try {
            $result.ExitCode | Should -Be 0
            $result.StackJson.services.ollama.use_external | Should -BeTrue
            $result.StackJson.services.ollama.external_url | Should -Not -BeNullOrEmpty
        }
        finally {
            if (Test-Path $result.TempRoot) {
                Remove-Item -Path $result.TempRoot -Recurse -Force
            }
        }
    }

    It 'records external Open WebUI URL in config when user opts in' {
        $result = Invoke-WizardMenuMockRun -ExternalWebUI 'yes'
        try {
            $result.ExitCode | Should -Be 0
            $result.StackJson.services.open_webui.use_external | Should -BeTrue
            $result.StackJson.services.open_webui.external_url | Should -Not -BeNullOrEmpty
        }
        finally {
            if (Test-Path $result.TempRoot) {
                Remove-Item -Path $result.TempRoot -Recurse -Force
            }
        }
    }
}
