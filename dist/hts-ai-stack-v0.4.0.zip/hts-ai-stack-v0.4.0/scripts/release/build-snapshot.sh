#!/usr/bin/env bash
# build-snapshot.sh — assemble a public release snapshot of the repo.
#
# Only tracked files (.gitignore honored) + workspace blacklist strip +
# post-build PII/secret sweep via scrub-check.sh.
#
# Usage:
#   build-snapshot.sh                     # builds to ./build/release-snapshot
#   build-snapshot.sh --out /tmp/rel      # custom output dir (must be empty/new)
#   build-snapshot.sh --tarball out.tgz   # also emit tarball

set -euo pipefail

repo_root="$(git rev-parse --show-toplevel)"
cd "$repo_root"

OUT="build/release-snapshot"
TARBALL=

while [[ $# -gt 0 ]]; do
  case "$1" in
    --out)     OUT="$2"; shift 2 ;;
    --tarball) TARBALL="$2"; shift 2 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

BLACKLIST=(
  BATCH_2_MERGE_READY.txt
  batch_2_results.md
  brainstorming.md
  cspell.json
  docker-images.md
  .claude
)

if [[ -e "$OUT" ]]; then
  if [[ -n "$(ls -A "$OUT" 2>/dev/null)" ]]; then
    echo "build-snapshot: $OUT exists and is not empty — refusing to overwrite." >&2
    exit 2
  fi
fi
mkdir -p "$OUT"

echo "==> exporting tracked files to $OUT"
git ls-files | tar -cf - --files-from=- | tar -xf - -C "$OUT"

echo "==> stripping workspace blacklist"
for item in "${BLACKLIST[@]}"; do
  if [[ -e "$OUT/$item" ]]; then
    rm -rf "${OUT:?}/$item"
    echo "   - removed $item"
  fi
done

echo "==> running post-build scrub-check"
if ! "$repo_root/scripts/maintenance/scrub-check.sh" --path "$OUT"; then
  echo
  echo "build-snapshot: scrub-check FAILED on $OUT"
  echo "  Redact flagged content and rerun."
  exit 1
fi

if [[ -n "$TARBALL" ]]; then
  echo "==> writing tarball $TARBALL"
  tar -czf "$TARBALL" -C "$OUT" .
fi

files=$(find "$OUT" -type f | wc -l)
size=$(du -sh "$OUT" | awk '{print $1}')
echo
echo "build-snapshot: OK ($files files, $size)"
echo "  Output: $OUT"
[[ -n "$TARBALL" ]] && echo "  Tarball: $TARBALL"
