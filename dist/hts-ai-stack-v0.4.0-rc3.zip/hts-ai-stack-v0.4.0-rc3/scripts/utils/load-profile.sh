#!/usr/bin/env bash
# scripts/utils/load-profile.sh — Load a saved profile and converge the stack
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"

PROFILES_DIR="$REPO_DIR/config/profiles"
STACK_JSON="$REPO_DIR/config/stack.json"

usage() {
  echo "Usage: $(basename "$0") <profile-name>"
  echo ""
  echo "  Loads a saved profile into stack.json and restarts the stack."
  echo "  Use list-profiles.sh to see available profiles."
  exit 1
}

NAME="${1:-}"
[[ -z "$NAME" || "$NAME" == "-h" || "$NAME" == "--help" ]] && usage

PROFILE_FILE="$PROFILES_DIR/${NAME}.json"

[[ -f "$PROFILE_FILE" ]] || fail "Profile '$NAME' not found. Run list-profiles.sh to see available profiles."

# ── Check if already active ───────────────────────────────────────────────────
ACTIVE=""
if [[ -L "$PROFILES_DIR/active" ]]; then
  ACTIVE="$(readlink "$PROFILES_DIR/active")"
  ACTIVE="${ACTIVE%.json}"
fi

if [[ "$ACTIVE" == "$NAME" ]]; then
  # Compare to catch manual edits
  if diff -q "$PROFILE_FILE" "$STACK_JSON" > /dev/null 2>&1; then
    info "Profile '$NAME' is already active and stack.json matches. Nothing to do."
    exit 0
  fi
  warn "Profile '$NAME' is active but stack.json has drifted. Re-converging."
fi

# ── Load ──────────────────────────────────────────────────────────────────────
step "Loading profile: $NAME"

cp "$PROFILE_FILE" "$STACK_JSON"
chmod 644 "$STACK_JSON"

# Update active symlink
ln -sf "${NAME}.json" "$PROFILES_DIR/active"

ok "stack.json updated from profile: $NAME"

# ── Converge ──────────────────────────────────────────────────────────────────
step "Converging stack to profile: $NAME"

if [[ -x "$SCRIPT_DIR/utils/converge.sh" ]]; then
  info "Running converge to apply profile…"
  bash "$SCRIPT_DIR/utils/converge.sh" --yes
elif [[ -x "$SCRIPT_DIR/install/06-start-stack.sh" ]]; then
  warn "Falling back to legacy start-stack…"
  bash "$SCRIPT_DIR/install/06-start-stack.sh"
else
  warn "No converge script found — manually restart the stack to apply changes."
fi

ok "Stack converged to profile: $NAME"
