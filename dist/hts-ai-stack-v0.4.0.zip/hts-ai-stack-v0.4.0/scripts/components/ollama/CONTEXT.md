# Ollama Component

Last updated: 2026-04-21 09:33:00

## What happens here

Ollama is the primary local LLM runtime for the stack. It downloads, manages,
and serves large language models with GPU acceleration via CUDA. All chat and
inference traffic routes through Ollama.

This folder also owns the **chat template auto-fix system**: HuggingFace GGUF
models pulled via `hf.co/...` sometimes ship without a valid
`tokenizer.chat_template` in their metadata. Ollama falls back to raw
completion mode — no prompt wrapping, no stop tokens — causing raw `[INST]`,
`<|im_start|>`, or similar tokens to bleed into model responses. The fix
detects the prompt family from the GGUF architecture field and patches the
model manifest in-place (weights reused, only template metadata changes).

> **Note on local aliases:** `ollama create` does not accept `hf.co/` as an
> output namespace (reserved for remote pulls). Fixed models are registered
> under a sanitized local name derived from the HF path, preserving the
> quantization tag so different quants of the same model stay distinct, e.g.
> `hf.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF:Q4_K_M` → `mistral-7b-instruct-v0.2-q4_k_m`.
> Models without a `:tag` drop the suffix, e.g. `hf.co/x/Model-7B-GGUF` → `model-7b`.
> The org is omitted from the alias; same-tag cross-org collisions are caught
> by a collision guard that refuses to overwrite an alias pointing at a
> different FROM blob. (Note: OpenHermes-2.5 / Nous-Hermes-2 / dolphin-2.x
> fine-tunes of Mistral use ChatML, not Mistral v1, and are routed to
> `chatml.Modelfile` even though their GGUF architecture field reads `mistral`.)

## Process / Workflow

### Normal model pull

1. Registry entry in `scripts/install/models/registry.json`
2. `_ollama_pull_if_missing` pulls via Docker Compose exec
3. For `hf.co/*` models: `_ollama_fix_template_for` runs automatically
4. If architecture is recognised → template + stop tokens patched in-place
5. If unrecognised → warn and skip (model still usable, may have bleeding)

### Manual / ad-hoc GGUF pull

1. User runs `docker exec -it hts-ai-ollama ollama pull hf.co/...`
2. Run `./scripts/components/ollama/ollama.sh --fix-templates` to batch-fix
3. Or manually: `docker cp <Modelfile> hts-ai-ollama:/tmp/ && docker exec hts-ai-ollama ollama create <local-name> -f /tmp/<Modelfile>`

### Template family detection order

1. `ollama show <model>` → reads `architecture` field from GGUF metadata
2. Maps GGUF `architecture` field: `mistral`/`mixtral` → Mistral v1 for base Instruct variants, ChatML for known ChatML fine-tunes (OpenHermes-2, Nous-Hermes-2, dolphin-2, neural-hermes, OpenOrca/SlimOrca); `llama` + name → llama2/llama3/alpaca/deepseek-v1; `gemma*` → Gemma; `cohere*`/`command*` → Command-R; `falcon*` → Falcon; `phi2*` → Phi-2; `qwen*`/`phi3*`/`phi4*`/`nemotron*` → ChatML
3. Falls back to model name regex when the architecture field is absent
4. Skips: `base`, `embed`, `vision`, `vl`, `multimodal` — these are not chat models

## Files and structure

| File | Purpose |
|------|---------|
| `ollama.sh` | Full lifecycle: install, configure, start, stop, health, pull-models, swap, fix-templates |
| `ollama.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and documentation |

Modelfile templates (in `scripts/install/models/modelfiles/`):

| File | Prompt family | Use for |
|------|--------------|---------|
| `mistral-v1.Modelfile` | Mistral v1 | Mistral / Mixtral base Instruct variants (ChatML fine-tunes — OpenHermes-2, Nous-Hermes-2, dolphin-2, OpenOrca — route to `chatml.Modelfile` instead) |
| `llama2.Modelfile` | Llama 2 Chat | llama-2-7b/13b/70b-chat and Llama 2 fine-tunes |
| `llama3.Modelfile` | Llama 3 | meta-llama-3, llama3.x fine-tunes |
| `gemma.Modelfile` | Gemma / Gemma 2 | gemma-2b-it, gemma-7b-it, gemma-2-9b/27b-it |
| `command-r.Modelfile` | Command-R | command-r, command-r-plus, c4ai-command-r |
| `alpaca.Modelfile` | Alpaca | alpaca, vicuna, WizardLM, Beluga, older fine-tunes |
| `deepseek-v1.Modelfile` | DeepSeek v1 | deepseek-llm-chat, deepseek-coder-instruct (v1 only) |
| `falcon.Modelfile` | Falcon | falcon-7b/40b/180b-instruct (TII v1; Falcon 2 → ChatML) |
| `phi2.Modelfile` | Phi-2 | phi-1_5, phi-2 fine-tunes (Phi-3/4 → ChatML) |
| `chatml.Modelfile` | ChatML | qwen2/3, phi-3/4, nemotron, deepseek-v2+ |

Each Modelfile has a `FROM REPLACE_ORG/REPLACE_MODEL:REPLACE_TAG` placeholder — swap in
the target model and run `ollama create <local-name> -f <file>`. See file headers for
the exact one-liner.

Key functions in `ollama.sh`:

| Function | Purpose |
|----------|---------|
| `_ollama_pull_if_missing` | Pull with exact-name dedup + auto template fix for hf.co/* |
| `_ollama_detect_prompt_family` | Arch field → mistral / llama3 / llama2 / gemma / command-r / alpaca / deepseek-v1 / falcon / phi2 / chatml / skip / unknown |
| `_ollama_needs_template_fix` | True if `ollama show --modelfile` has no TEMPLATE line |
| `_ollama_fix_template_for` | Injects template + stop tokens, creates sanitized local alias |
| `ollama_fix_templates` | Batch scan + fix all (or hf.co-only) models |

CLI flags:

| Flag | Effect |
|------|--------|
| `--fix-templates` | Fix missing templates on all `hf.co/*` models |
| `--fix-templates --all` | Fix missing templates on every model in Ollama |

## What good looks like

- Model responds with natural text only — no raw `[INST]`, `<|im_start|>`, `</s>`, or similar tokens in output
- `ollama show --modelfile <model>` contains a `TEMPLATE` block and at least one `PARAMETER stop`
- `hf.co/*` models always have a local alias registered after pull
- Base, embedding, vision, and VL models are never given a chat template

## Tools and skills

- **Docker** — all `ollama` commands run inside `hts-ai-ollama` container via `docker exec`
- **jq** — parses `/api/tags` response to enumerate models
- **curl** — health-checks the Ollama API at `:11434`
- **Ollama Modelfile** — declarative format for `FROM`, `TEMPLATE`, `PARAMETER stop`; see `REFERENCES.md`

See [usage.md](./usage.md) for command usage.
