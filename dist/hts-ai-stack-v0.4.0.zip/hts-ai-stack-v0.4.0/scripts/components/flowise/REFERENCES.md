# Flowise References

Last updated: 2026-04-15

## Upstream

- [GitHub — FlowiseAI/Flowise](https://github.com/FlowiseAI/Flowise)

## Official documentation

- [Flowise Docs](https://docs.flowiseai.com/)
