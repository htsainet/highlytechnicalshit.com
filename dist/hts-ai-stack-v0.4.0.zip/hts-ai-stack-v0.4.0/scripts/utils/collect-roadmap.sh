#!/usr/bin/env bash
# scripts/utils/collect-roadmap.sh — Generate roadmap.json from feature & security files
#
# Parses FEATURE-*.md and SECURITY-*.md metadata (title, priority, status,
# target release, creation date) into resources/dashboard/roadmap.json.
#
# Usage:
#   ./scripts/utils/collect-roadmap.sh            # generate roadmap.json
#   ./scripts/utils/collect-roadmap.sh --stdout    # print to stdout instead
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

FEATURE_DIR="$REPO_DIR/docs/development/features"
SECURITY_DIR="$REPO_DIR/docs/security-review/features"
FEATURE_REF="$FEATURE_DIR/REFERENCES.md"
SECURITY_REF="$SECURITY_DIR/REFERENCES.md"
OUTPUT="$REPO_DIR/resources/dashboard/roadmap.json"
TO_STDOUT=false

[[ "${1:-}" == "--stdout" ]] && TO_STDOUT=true

# ── Helpers ───────────────────────────────────────────────────────────────────

# extract_field <file> <field_name> — grab value from **Field:** line
extract_field() {
  local file="$1" field="$2"
  # Match both **Field:** value and **Field:** value formats
  grep -m1 -iE "^\*{0,2}${field}:?\*{0,2}\s" "$file" 2>/dev/null \
    | sed -E 's/^\*{0,2}[^:]+:\*{0,2}\s*//' \
    | sed 's/\s*$//' \
    || echo ""
}

# get_title <file> — first H1 line
get_title() {
  grep -m1 '^# ' "$1" 2>/dev/null | sed 's/^# //' || echo "Untitled"
}

# get_status <references_file> <filename> — look up status from REFERENCES.md table
get_status() {
  local ref_file="$1" basename="$2"
  grep -F "$basename" "$ref_file" 2>/dev/null \
    | grep -oE '\b(Proposed|In Progress|Testing|Complete|Deferred|Won'\''t Do|Superseded)\b' \
    | head -1 \
    || echo "Proposed"
}

# get_created_date <file> — git creation date, fallback to file mtime
get_created_date() {
  local file="$1"
  local git_date
  git_date=$(git -C "$REPO_DIR" log --diff-filter=A --format='%as' -- "$file" 2>/dev/null | tail -1)
  if [[ -n "$git_date" ]]; then
    echo "$git_date"
  else
    # Fallback: file modification time
    date -r "$file" '+%Y-%m-%d' 2>/dev/null || date '+%Y-%m-%d'
  fi
}

# get_last_updated_date <file> — git last-modified date, fallback to created date
get_last_updated_date() {
  local file="$1"
  local git_date
  git_date=$(git -C "$REPO_DIR" log -1 --format='%as' -- "$file" 2>/dev/null)
  if [[ -n "$git_date" ]]; then
    echo "$git_date"
  else
    get_created_date "$file"
  fi
}

# json_escape <string> — escape for JSON string value
json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g'
}

# ── Collect entries ───────────────────────────────────────────────────────────

entries=()

# Process FEATURE-*.md files
for file in "$FEATURE_DIR"/FEATURE-*.md; do
  [[ -f "$file" ]] || continue
  basename="$(basename "$file")"
  id="${basename%.md}"

  title=$(get_title "$file")
  # Skip superseded features
  if grep -qi 'superseded' "$file" 2>/dev/null; then
    continue
  fi

  priority=$(extract_field "$file" "Priority")
  target=$(extract_field "$file" "Target Release")
  status=$(get_status "$FEATURE_REF" "$basename")
  created=$(get_created_date "$file")
  updated=$(get_last_updated_date "$file")

  # Normalize target release
  target=$(echo "$target" | sed -E 's/^Next Minor \(([^)]+)\)/\1/; s/\+$//')

  entries+=("{\"id\":\"$id\",\"type\":\"feature\",\"title\":\"$(json_escape "$title")\",\"priority\":\"$(json_escape "$priority")\",\"status\":\"$(json_escape "$status")\",\"target\":\"$(json_escape "$target")\",\"created\":\"$created\",\"lastUpdated\":\"$updated\"}")
done

# Process SECURITY-*.md files
for file in "$SECURITY_DIR"/SECURITY-*.md; do
  [[ -f "$file" ]] || continue
  basename="$(basename "$file")"
  id="${basename%.md}"

  title=$(get_title "$file")
  priority=$(extract_field "$file" "Priority")
  target=$(extract_field "$file" "Target Release")
  status=$(get_status "$SECURITY_REF" "$basename")
  created=$(get_created_date "$file")
  updated=$(get_last_updated_date "$file")

  entries+=("{\"id\":\"$id\",\"type\":\"security\",\"title\":\"$(json_escape "$title")\",\"priority\":\"$(json_escape "$priority")\",\"status\":\"$(json_escape "$status")\",\"target\":\"$(json_escape "$target")\",\"created\":\"$created\",\"lastUpdated\":\"$updated\"}")
done

# ── Build JSON ────────────────────────────────────────────────────────────────

json="{\"generated_at\":\"$(date -u '+%Y-%m-%dT%H:%M:%SZ')\",\"items\":["
first=true
for entry in "${entries[@]}"; do
  $first || json+=","
  json+="$entry"
  first=false
done
json+="]}"

if $TO_STDOUT; then
  echo "$json"
else
  mkdir -p "$(dirname "$OUTPUT")"
  echo "$json" > "$OUTPUT"
  echo "[OK] Wrote $(echo "$json" | grep -o '"id"' | wc -l) items to $OUTPUT"
fi
