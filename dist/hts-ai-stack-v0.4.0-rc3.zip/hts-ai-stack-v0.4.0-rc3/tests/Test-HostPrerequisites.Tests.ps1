$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:PrereqFile = Join-Path $script:RepoRoot 'scripts/host/prerequisites.json'
}

Describe 'Host prerequisite tracker' {

    BeforeAll {
        $script:Prereqs = $null
        if (Test-Path $script:PrereqFile) {
            $script:Prereqs = Get-Content $script:PrereqFile -Raw | ConvertFrom-Json
        }
    }

    It 'prerequisites.json exists' {
        $script:PrereqFile | Should -Exist
    }

    It 'prerequisites.json is valid JSON with a prerequisites array' {
        $script:Prereqs | Should -Not -BeNullOrEmpty
        $script:Prereqs.prerequisites | Should -Not -BeNullOrEmpty
        $script:Prereqs.prerequisites.Count | Should -BeGreaterThan 0
    }

    Context 'every entry has required fields' {
        BeforeAll {
            $script:InvalidEntries = [System.Collections.Generic.List[string]]::new()
            $requiredFields = @('package', 'installer', 'reason', 'added', 'scope')
            $validScopes = @('core', 'dev', 'admin', 'optional', 'service', 'networking', 'tooling')

            foreach ($entry in $script:Prereqs.prerequisites) {
                foreach ($field in $requiredFields) {
                    if ([string]::IsNullOrWhiteSpace($entry.$field)) {
                        $script:InvalidEntries.Add("$($entry.package): missing '$field'")
                    }
                }
                if ($entry.scope -and $entry.scope -notin $validScopes) {
                    $script:InvalidEntries.Add("$($entry.package): invalid scope '$($entry.scope)' (expected: $($validScopes -join ', '))")
                }
            }
        }

        It 'all entries have package, installer, reason, added, and a valid scope' {
            if ($script:InvalidEntries.Count -gt 0) {
                $detail = $script:InvalidEntries -join "`n  "
                "Invalid entries:`n  $detail" | Should -Be '' -Because 'every prerequisite must be fully documented'
            }
        }
    }

    Context 'apt-get installs are documented' {
        BeforeAll {
            $script:Undocumented = [System.Collections.Generic.List[string]]::new()
            $trackedPackages = $script:Prereqs.prerequisites | ForEach-Object { $_.package }

            # Scan all shell scripts that install packages
            $scriptDirs = @(
                (Join-Path $script:RepoRoot 'scripts/host')
                (Join-Path $script:RepoRoot 'scripts/install')
                (Join-Path $script:RepoRoot 'scripts/components')
            )
            $allScripts = [System.Collections.Generic.List[System.IO.FileInfo]]::new()
            foreach ($dir in $scriptDirs) {
                if (Test-Path $dir) {
                    Get-ChildItem -Path $dir -Filter '*.sh' -Recurse -File | ForEach-Object { $allScripts.Add($_) }
                }
            }
            $bootstrap = Get-Item -Path (Join-Path $script:RepoRoot 'bootstrap.sh') -ErrorAction SilentlyContinue
            $scriptsBootstrap = Get-Item -Path (Join-Path $script:RepoRoot 'scripts/bootstrap.sh') -ErrorAction SilentlyContinue
            if ($bootstrap) { $allScripts.Add($bootstrap) }
            if ($scriptsBootstrap) { $allScripts.Add($scriptsBootstrap) }

            foreach ($scriptFile in $allScripts) {
                $lines = Get-Content $scriptFile.FullName
                foreach ($line in $lines) {
                    # Match actual install commands (not comments, echo, printf, fail messages)
                    if ($line -match '^\s*#') { continue }
                    if ($line -match '(echo|printf|info|warn|fail|log)\s') { continue }
                    if ($line -notmatch '(?:sudo\s+)?apt(?:-get)?\s+install\s+') { continue }

                    # Strip the command prefix and flags, extract package names
                    $pkgPart = $line -replace '.*install\s+', ''
                    $pkgPart = $pkgPart -replace '-[yqf]+\s*', ''
                    $pkgPart = $pkgPart -replace '--\S+\s*', ''

                    # Strip shell redirections, pipes, trailing commands, and inline comments
                    $pkgPart = $pkgPart -replace '\s*2>[&/].*', ''
                    $pkgPart = $pkgPart -replace '\s*\|.*', ''
                    $pkgPart = $pkgPart -replace '\s*>.*', ''
                    $pkgPart = $pkgPart -replace '\s*;.*', ''
                    $pkgPart = $pkgPart -replace '\s*&&.*', ''
                    $pkgPart = $pkgPart -replace '\s*\|\|.*', ''
                    $pkgPart = $pkgPart -replace '\s*#.*', ''
                    $pkgPart = $pkgPart.Trim()

                    # Skip lines that only reference bash arrays or variables
                    if ($pkgPart -match '^\$\{' -or $pkgPart -match '^\"\$\{' -or $pkgPart -match '^\"\$[A-Z]') { continue }

                    # Skip empty remainder (e.g. apt-get install -f with no packages)
                    if ([string]::IsNullOrWhiteSpace($pkgPart)) { continue }

                    # Split remaining into individual package names
                    $packages = $pkgPart -split '\s+' | Where-Object {
                        $_ -and
                        $_ -notmatch '^\$' -and
                        $_ -notmatch '^\"\$' -and
                        $_ -notmatch '^-' -and
                        $_ -notmatch 'linux-headers-'
                    }

                    foreach ($pkg in $packages) {
                        if ($pkg -notin $trackedPackages) {
                            $relPath = $scriptFile.FullName.Substring($script:RepoRoot.Length + 1)
                            $script:Undocumented.Add("$pkg (in $relPath)")
                        }
                    }
                }
            }
        }

        It 'all apt-installed packages have a prerequisites.json entry' {
            if ($script:Undocumented.Count -gt 0) {
                $detail = $script:Undocumented -join "`n  "
                "Undocumented packages:`n  $detail" | Should -Be '' -Because 'every host package must be tracked in scripts/host/prerequisites.json'
            }
        }
    }
}
