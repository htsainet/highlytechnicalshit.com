# ONNX Runtime — Lightweight CPU Inference & Model Export

**Priority:** LOW
**Target Release:** v0.6.0+
**Effort:** 1-2 days (container + llama-swap integration)
**Risk:** Low — additive service, no impact on existing stack
**Depends on:** Unsloth fine-tuning pipeline (FEATURE-004) or non-LLM workloads
**Blocks:** Nothing

## Scope

Add [ONNX Runtime](https://github.com/onnx/onnx) as an optional CPU
inference backend for serving quantized or exported models that don't fit
the Ollama/BitNet workflow.

### Use Cases

- **Fine-tuned model export** — serve Unsloth-exported ONNX models in a
  lightweight CPU runtime without pulling them into Ollama
- **Non-LLM AI workloads** — embedding generation, classification,
  speech-to-text, vision models where ONNX is the standard distribution
  format
- **Edge deployment testing** — validate ONNX-quantized models before
  shipping to resource-constrained environments

### Why Not Now

- Ollama (GPU) + BitNet (CPU) already cover LLM inference
- Models in use (gemma4, bitnet) are served natively by their backends
- ONNX Runtime would add another inference path to maintain without
  solving a current gap

### When to Revisit

- Unsloth produces ONNX-exported fine-tunes that need serving
- Computer vision, speech, or embedding workloads are added to the stack
- A model is available in ONNX format but not in GGUF/Ollama format

## Implementation Notes

- Docker container with `onnxruntime` (CPU) or `onnxruntime-gpu` (CUDA)
- Expose OpenAI-compatible API (via a thin wrapper) so llama-swap can
  route to it like any other backend
- Profile-gated: `docker compose --profile onnx up onnx-runtime`
- GPU variant shares CUDA with Ollama — needs scheduling consideration

## References

- ONNX spec: <https://github.com/onnx/onnx>
- ONNX Runtime: <https://onnxruntime.ai/>
- ONNX Runtime server: <https://github.com/microsoft/onnxruntime/tree/main/onnxruntime/python/tools/transformers>
