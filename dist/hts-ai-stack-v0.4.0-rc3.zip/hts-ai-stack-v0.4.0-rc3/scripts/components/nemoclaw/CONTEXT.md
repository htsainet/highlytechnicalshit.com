# NemoClaw Component

Last updated: 2026-04-15

## What happens here

NemoClaw is the NVIDIA-managed sandbox engine. This folder contains the
component lifecycle script and manifest for installing, configuring, and
onboarding NemoClaw sandboxes on the host.

## OpenShell lifecycle

For NemoClaw-managed environments, use `nemoclaw onboard` when you need
to create or recreate the OpenShell gateway or sandbox. Avoid
`openshell self-update`, `npm update -g openshell`,
`openshell gateway start --recreate`, or `openshell sandbox create`
directly unless you intend to manage OpenShell separately and then rerun
`nemoclaw onboard`.

## Files and structure

| File | Purpose |
|------|---------|
| `nemoclaw.sh` | Full lifecycle: install, configure, onboard, health, start, stop |
| `nemoclaw.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |

## Key functions

| Function | Purpose |
|----------|---------|
| `nemoclaw_install()` | Clone repo, npm build, npm link |
| `nemoclaw_configure()` | cgroup fix, registry patch, provider config |
| `nemoclaw_onboard()` | Onboard sandbox(es) via `nemoclaw onboard` |
| `nemoclaw_start()` | Full lifecycle: install + configure + onboard |
| `nemoclaw_stop()` | Destroy all sandboxes |
| `nemoclaw_health()` | Health check via dashboard port probe |

## Port relay fix

The `_ensure_forwards()` function sets up TCP port relays for sandbox
access. A bug caused it to create a self-loop relay when the listen
port equaled the target port (e.g., 18789→18789), consuming CPU and
preventing connections. Fixed to skip relay setup when listen==target.

## Tools and skills

- **NemoClaw CLI** — NVIDIA sandbox orchestrator (runs on host, not in Docker)
- **OpenShell CLI** — Container runtime managed by NemoClaw
- **npm** — NemoClaw is installed from source via npm
