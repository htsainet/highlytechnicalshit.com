#!/usr/bin/env bash
# scripts/host/migrate-nas-folders.sh — One-off: reorganize NAS model backup layout
#
# Moves existing flat folders into the new service/models/ structure.
# Safe to re-run — skips moves that are already done.
#
# Usage:  sudo ./scripts/host/migrate-nas-folders.sh

set -euo pipefail

NAS="/mnt/htsai-model-backup"

if [[ $EUID -ne 0 ]]; then
  echo "[ERROR] Run with sudo: sudo $0"
  exit 1
fi

if ! mountpoint -q "$NAS" 2>/dev/null; then
  echo "[ERROR] $NAS is not mounted. Run: sudo mount -a"
  exit 1
fi

move_into() {
  local src="$1" dest="$2"
  if [[ -d "$src" && ! -d "$dest" ]]; then
    mkdir -p "$(dirname "$dest")"
    echo "[MOVE] $src → $dest"
    mv "$src" "$dest"
  elif [[ -d "$dest" ]]; then
    echo "[SKIP] $dest already exists"
  else
    echo "[SKIP] $src not found"
  fi
}

echo "═══════════════════════════════════════════"
echo "  Migrate NAS model backup folder layout"
echo "═══════════════════════════════════════════"
echo ""

# ollama/ → ollama/models/
# Special: ollama already exists, need to move contents into subfolder
if [[ -d "$NAS/ollama" && ! -d "$NAS/ollama/models" ]]; then
  echo "[MOVE] ollama/ contents → ollama/models/"
  mkdir -p "$NAS/ollama-tmp"
  mv "$NAS/ollama"/* "$NAS/ollama-tmp/" 2>/dev/null || true
  mkdir -p "$NAS/ollama/models"
  mv "$NAS/ollama-tmp"/* "$NAS/ollama/models/" 2>/dev/null || true
  rmdir "$NAS/ollama-tmp" 2>/dev/null || true
  echo "[OK] ollama restructured"
elif [[ -d "$NAS/ollama/models" ]]; then
  echo "[SKIP] ollama/models/ already exists"
fi

# ollama-test → ollama-test/models  (if you want to keep it)
if [[ -d "$NAS/ollama-test" && ! -d "$NAS/ollama-test/models" ]]; then
  echo "[MOVE] ollama-test/ contents → ollama-test/models/"
  mkdir -p "$NAS/ollama-test-tmp"
  mv "$NAS/ollama-test"/* "$NAS/ollama-test-tmp/" 2>/dev/null || true
  mkdir -p "$NAS/ollama-test/models"
  mv "$NAS/ollama-test-tmp"/* "$NAS/ollama-test/models/" 2>/dev/null || true
  rmdir "$NAS/ollama-test-tmp" 2>/dev/null || true
  echo "[OK] ollama-test restructured"
elif [[ -d "$NAS/ollama-test/models" ]]; then
  echo "[SKIP] ollama-test/models/ already exists"
fi

# sd-* → stable-diffusion/*
move_into "$NAS/sd-checkpoints" "$NAS/stable-diffusion/checkpoints"
move_into "$NAS/sd-loras"       "$NAS/stable-diffusion/loras"
move_into "$NAS/sd-embeddings"  "$NAS/stable-diffusion/embeddings"
move_into "$NAS/sd-vae"         "$NAS/stable-diffusion/vae"

echo ""
echo "[OK] Migration complete. New layout:"
ls -1d "$NAS"/*/ 2>/dev/null | sed "s|$NAS/|  |"
