#!/usr/bin/env bash
# scripts/components/duplicati.sh — Duplicati file-level backups
#
# Standalone usage:
#   ./scripts/components/duplicati.sh            # install + configure + start + health
#   ./scripts/components/duplicati.sh --health   # health check only
#   ./scripts/components/duplicati.sh --stop     # stop Duplicati
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
DUPLICATI_CONTAINER="${DUPLICATI_CONTAINER:-hts-ai-duplicati}"
DUPLICATI_PORT="${DUPLICATI_PORT:-8200}"

# ── Functions ────────────────────────────────────────────────────────────────

# duplicati_install — Pull the Duplicati container image
duplicati_install() {
  step "Duplicati — install"
  compose_pull --profile duplicati
  ok "Duplicati image pulled."
}

# duplicati_configure — Set backup targets and schedules
duplicati_configure() {
  step "Duplicati — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^DUPLICATI_PORT=" "$env_file" 2>/dev/null; then
    printf 'DUPLICATI_PORT=%s\n' "$DUPLICATI_PORT" >> "$env_file"
    info "Added DUPLICATI_PORT=${DUPLICATI_PORT} to .env"
  fi

  info "Web UI: http://localhost:${DUPLICATI_PORT}"
  info "Configure backup targets and schedules via the web UI after start."
  ok "Duplicati configured."
}

# duplicati_start — Bring up Duplicati via compose
duplicati_start() {
  step "Duplicati — start"
  compose_up --profile duplicati
  ok "Duplicati started on port ${DUPLICATI_PORT}."
}

# duplicati_stop — Bring down Duplicati
duplicati_stop() {
  step "Duplicati — stop"
  compose_down --profile duplicati
  ok "Duplicati stopped."
}

# duplicati_health — Probe the Duplicati web UI
duplicati_health() {
  health_probe "Duplicati :${DUPLICATI_PORT}" "http://localhost:${DUPLICATI_PORT}/"
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      duplicati_install
      duplicati_configure
      duplicati_start
      duplicati_health
      ;;
    health)
      duplicati_health
      ;;
    stop)
      duplicati_stop
      ;;
  esac
fi
