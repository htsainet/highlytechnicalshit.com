#!/usr/bin/env bash
# scripts/components/unsloth/unsloth.sh — Unsloth LLM fine-tuning & training studio
#
# Standalone usage:
#   ./scripts/components/unsloth/unsloth.sh              # full: install + configure + start + health
#   ./scripts/components/unsloth/unsloth.sh --install    # install only
#   ./scripts/components/unsloth/unsloth.sh --configure  # configure only
#   ./scripts/components/unsloth/unsloth.sh --start      # start only
#   ./scripts/components/unsloth/unsloth.sh --stop       # stop
#   ./scripts/components/unsloth/unsloth.sh --restart    # restart (stop + start)
#   ./scripts/components/unsloth/unsloth.sh --health     # health check only
#   ./scripts/components/unsloth/unsloth.sh --status     # show status + port + health
#   ./scripts/components/unsloth/unsloth.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
#
# Ref: https://github.com/unslothai/unsloth
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
UNSLOTH_CONTAINER="${UNSLOTH_CONTAINER:-hts-ai-unsloth-1}"
UNSLOTH_PORT="${UNSLOTH_PORT:-8888}"
UNSLOTH_API_PORT="${UNSLOTH_API_PORT:-8000}"

# ── Functions ────────────────────────────────────────────────────────────────

# unsloth_install — Pull the Unsloth Docker image
unsloth_install() {
  step "Unsloth — install"
  compose_build --profile unsloth
  ok "Unsloth image built."
}

# unsloth_configure — Ensure .env has Unsloth settings
unsloth_configure() {
  step "Unsloth — configure"
  local env_file="$REPO_DIR/.env"

  _ensure() {
    local key="$1" default="$2"
    if ! grep -q "^${key}=" "$env_file" 2>/dev/null; then
      printf '%s=%s\n' "$key" "$default" >> "$env_file"
      info "Added ${key}=${default} to .env"
    fi
  }

  _ensure "UNSLOTH_PORT" "$UNSLOTH_PORT"
  _ensure "UNSLOTH_API_PORT" "$UNSLOTH_API_PORT"
  _ensure "UNSLOTH_PASSWORD" "changeme"

  ok "Unsloth configured (studio :${UNSLOTH_PORT}, api :${UNSLOTH_API_PORT})."
  warn "Change UNSLOTH_PASSWORD in .env before exposing to the network."
}

# unsloth_start — Bring up Unsloth via compose
unsloth_start() {
  step "Unsloth — start"
  compose_up --profile unsloth
  ok "Unsloth started (studio :${UNSLOTH_PORT}, api :${UNSLOTH_API_PORT})."
}

# unsloth_stop — Bring down Unsloth
unsloth_stop() {
  step "Unsloth — stop"
  compose_down --profile unsloth
  ok "Unsloth stopped."
}

# unsloth_health — Probe the Unsloth Studio UI
unsloth_health() {
  health_probe "Unsloth :${UNSLOTH_PORT}" "http://localhost:${UNSLOTH_PORT}/"
}

unsloth_restart() {
  unsloth_stop
  unsloth_start
}

unsloth_destroy() {
  step "Unsloth — destroy"
  compose_down --profile unsloth -v
  ok "Unsloth destroyed."
}

unsloth_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=unsloth" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Unsloth is running (port ${UNSLOTH_PORT})"
  else
    warn "Unsloth is not running."
  fi
  unsloth_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   unsloth_install   ;;
    configure) unsloth_configure ;;
    start)     unsloth_start     ;;
    stop)      unsloth_stop      ;;
    restart)   unsloth_restart   ;;
    health)    unsloth_health    ;;
    status)    unsloth_status    ;;
    destroy)   unsloth_destroy   ;;
    default)
      unsloth_install
      unsloth_configure
      unsloth_start
      unsloth_health
      ;;
  esac
fi
