#!/usr/bin/env bash
# scripts/components/comfyui.sh — ComfyUI workflow-based image generation
#
# Standalone usage:
#   ./scripts/components/comfyui.sh            # install + configure + start + health
#   ./scripts/components/comfyui.sh --health   # health check only
#   ./scripts/components/comfyui.sh --stop     # stop ComfyUI
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
COMFYUI_CONTAINER="${COMFYUI_CONTAINER:-hts-ai-comfyui}"
COMFYUI_PORT="${COMFYUI_PORT:-8188}"

# ── Functions ────────────────────────────────────────────────────────────────

# comfyui_install — Pull the ComfyUI container image
comfyui_install() {
  step "ComfyUI — install"
  compose_pull --profile comfyui
  ok "ComfyUI image pulled."
}

# comfyui_configure — Ensure .env has ComfyUI port
comfyui_configure() {
  step "ComfyUI — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^COMFYUI_PORT=" "$env_file" 2>/dev/null; then
    printf 'COMFYUI_PORT=%s\n' "$COMFYUI_PORT" >> "$env_file"
    info "Added COMFYUI_PORT=${COMFYUI_PORT} to .env"
  fi

  ok "ComfyUI configured (port ${COMFYUI_PORT})."
}

# comfyui_start — Bring up ComfyUI via compose
comfyui_start() {
  step "ComfyUI — start"
  compose_up --profile comfyui
  ok "ComfyUI started on port ${COMFYUI_PORT}."
}

# comfyui_stop — Bring down ComfyUI
comfyui_stop() {
  step "ComfyUI — stop"
  compose_down --profile comfyui
  ok "ComfyUI stopped."
}

# comfyui_health — Probe the ComfyUI web UI
comfyui_health() {
  health_probe "ComfyUI :${COMFYUI_PORT}" "http://localhost:${COMFYUI_PORT}/"
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      comfyui_install
      comfyui_configure
      comfyui_start
      comfyui_health
      ;;
    health)
      comfyui_health
      ;;
    stop)
      comfyui_stop
      ;;
  esac
fi
