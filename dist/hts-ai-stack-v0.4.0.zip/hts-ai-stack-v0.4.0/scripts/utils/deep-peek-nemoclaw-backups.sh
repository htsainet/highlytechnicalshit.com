#!/usr/bin/env bash
# deep-peek-nemoclaw-backups.sh — Round 2: the nemoclaw volume tarballs contain
# containerd overlayfs snapshots with OpenClaw (not nemoclaw CLI) inside. This
# script widens the search to:
#   • openclaw (the product) package.json / version
#   • openshell agent inside the sandbox
#   • ANY blueprint.yaml / nemoclaw.yaml / openshell.yaml at any depth
#   • the configs/ sidecar dirs (fstab, env, json captured at backup time —
#     these should include the manifest state and NEMOCLAW_INSTALL_TAG)
#
# Also dumps root entries of each tarball so we can spot any meta/marker files.
#
# Host-side nemoclaw/openshell CLI versions live in ~/.nvm/... which is only
# captured by the full disk image (/mnt/htsai-disk-image/*.img.gz) — that's a
# 235 GB gzip and is handled by a separate loop-mount script if needed.
#
# Usage:
#   sudo ./scripts/utils/deep-peek-nemoclaw-backups.sh

set -eu
# NOTE: deliberately no `pipefail` — we use many `tar | grep | head` pipelines
# where `head` closes the pipe early and SIGPIPEs tar (exit 141). With pipefail
# + set -e that kills the whole script before we reach the large tarballs.

BACKUP_ROOT="/mnt/htsai-docker-volume-backup"
VOL_DIR="$BACKUP_ROOT/volumes"
CFG_DIR="$BACKUP_ROOT/configs"

step() { echo; echo "════ $* ════"; }
info() { echo "    $*"; }
warn() { echo "[WARN] $*" >&2; }

[[ $EUID -eq 0 ]] || { echo "Re-run with: sudo $0" >&2; exit 1; }

# ── 1. configs/ sidecars (small, fast; these capture host manifest state) ────
step "configs/ sidecars (backup-time host state)"
if [[ -d "$CFG_DIR" ]]; then
  for snap in "$CFG_DIR"/*/; do
    [[ -d "$snap" ]] || continue
    echo
    info "── $snap"
    ls -la "$snap" 2>/dev/null | head -20 | sed 's/^/      /'

    # Grep anything naming nemoclaw/openshell/install-tag across the json/env/md files
    grep -rIE 'NEMOCLAW|OPENSHELL|openclaw|install.tag|pinned_version|blueprint' "$snap" 2>/dev/null \
      | grep -v '^Binary' | head -40 | sed 's/^/        /' || true
  done

  # repo-working-tree.tar.gz captured in 20260419-214341: peek inside for nemoclaw manifest
  local_repo_tgz="$CFG_DIR/20260419-214341/repo-working-tree.tar.gz"
  if [[ -f "$local_repo_tgz" ]]; then
    echo
    info "── repo-working-tree.tar.gz → nemoclaw manifest + install script settings"
    tar xzOf "$local_repo_tgz" --wildcards \
        '*/nemoclaw.manifest.json' '*/nemoclaw.sh' 2>/dev/null \
      | grep -E 'pinned_version|NEMOCLAW_INSTALL_TAG|OPENSHELL_VERSION|blueprint' \
      | head -30 | sed 's/^/        /' || info "(no match — fallback dump)"
  fi
else
  warn "No configs/ dir."
fi

# ── 2. nemoclaw volume tarballs — widened pattern ─────────────────────────────
step "Widened scan across volume tarballs"

mapfile -t TARBALLS < <(find "$VOL_DIR" -maxdepth 1 -type f \
  -name 'openshell-cluster-nemoclaw_*.tar.gz' 2>/dev/null | sort)

for tb in "${TARBALLS[@]}"; do
  echo
  info "── $(basename "$tb")  ($(du -sh "$tb" | awk '{print $1}'))"

  # Small tarballs (269M) are pre-onboard empty; skip heavy grep.
  size_bytes=$(stat -c %s "$tb")
  if (( size_bytes < 500 * 1024 * 1024 )); then
    info "      (small tarball — listing root entries only)"
    tar tzf "$tb" 2>/dev/null | head -10 | sed 's/^/        /'
    continue
  fi

  # Widened path list. We look for anything that names versions:
  #   - openclaw top-level package.json
  #   - openshell top-level package.json
  #   - nemoclaw top-level package.json
  #   - any blueprint*.yaml / nemoclaw*.yaml / openshell*.yaml
  #   - any *version* file at reasonable depth (<= 8 slashes)
  info "      key package.json / yaml paths:"
  tar tzf "$tb" 2>/dev/null \
    | awk -F/ 'NF <= 12' \
    | grep -E \
        -e '/(openclaw|openshell|nemoclaw)/package\.json$' \
        -e '/(blueprint|nemoclaw|openshell)[^/]*\.(yaml|yml|json)$' \
        -e '/VERSION$' -e '/version$' \
    | grep -vE '/extensions/|/node_modules/.+/node_modules/' \
    | head -30 | sed 's/^/        /'

  # Now actually dump version fields from each matched file (re-run, limit 10)
  mapfile -t VERSION_FILES < <(
    tar tzf "$tb" 2>/dev/null \
      | awk -F/ 'NF <= 12' \
      | grep -E '/(openclaw|openshell|nemoclaw)/package\.json$' \
      | grep -vE '/extensions/|/node_modules/.+/node_modules/' \
      | head -10
  )

  for f in "${VERSION_FILES[@]}"; do
    echo
    info "      === $f ==="
    tar xzOf "$tb" "$f" 2>/dev/null \
      | grep -E '"(name|version|gitHead|_from|_resolved|_integrity)"' \
      | head -10 | sed 's/^/          /' \
      || info "          (no version fields)"
  done

  # Dump any blueprint yaml content
  mapfile -t BLUEPRINTS < <(
    tar tzf "$tb" 2>/dev/null \
      | grep -E '/(blueprint|nemoclaw|openshell)[^/]*\.(yaml|yml)$' \
      | head -5
  )
  for f in "${BLUEPRINTS[@]}"; do
    echo
    info "      === $f ==="
    tar xzOf "$tb" "$f" 2>/dev/null \
      | grep -E 'version|image|tag|sha256|openshell|nemoclaw' \
      | head -20 | sed 's/^/          /'
  done
done

echo
echo "Done."
echo
echo "If nothing useful surfaced from the volume tarballs, the version record"
echo "almost certainly lives in the host disk image:"
echo "    /mnt/htsai-disk-image/hta-ai-sda-20260417-233419.img.gz  (235G gzip)"
echo "Run scripts/utils/mount-host-disk-image.sh (separate script) to extract"
echo "~/.nvm/versions/node/*/lib/node_modules/{nemoclaw,openshell}/package.json"
echo "without decompressing the whole image."
