$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    Set-Location $script:RepoRoot

    $markdownRaw = [Environment]::GetEnvironmentVariable('REPO_MARKDOWN_FILES_JSON')
    if ([string]::IsNullOrWhiteSpace($markdownRaw)) {
        $script:MarkdownFiles = @()
    }
    else {
        $markdownItems = ConvertFrom-Json $markdownRaw
        if ($markdownItems -is [string]) {
            $script:MarkdownFiles = @($markdownItems)
        }
        else {
            $script:MarkdownFiles = @($markdownItems)
        }
    }

    $shellRaw = [Environment]::GetEnvironmentVariable('REPO_SHELL_FILES_JSON')
    if ([string]::IsNullOrWhiteSpace($shellRaw)) {
        $script:ShellFiles = @()
    }
    else {
        $shellItems = ConvertFrom-Json $shellRaw
        if ($shellItems -is [string]) {
            $script:ShellFiles = @($shellItems)
        }
        else {
            $script:ShellFiles = @($shellItems)
        }
    }

    $configRaw = [Environment]::GetEnvironmentVariable('REPO_CONFIG_FILES_JSON')
    if ([string]::IsNullOrWhiteSpace($configRaw)) {
        $script:ConfigFiles = @()
    }
    else {
        $configItems = ConvertFrom-Json $configRaw
        if ($configItems -is [string]) {
            $script:ConfigFiles = @($configItems)
        }
        else {
            $script:ConfigFiles = @($configItems)
        }
    }
}

Describe 'Markdown checks' {
    It 'lints selected markdown files with markdownlint-cli2' -Skip:($script:MarkdownFiles.Count -eq 0) {
        if (-not (Get-Command npx -ErrorAction SilentlyContinue)) {
            throw 'npx not found. Install Node.js via bootstrap or NVM.'
        }

        if (-not (Test-Path -LiteralPath (Join-Path $script:RepoRoot 'package.json'))) {
            throw 'package.json is missing; markdown tooling is not configured.'
        }

        & npx --no-install markdownlint-cli2 @script:MarkdownFiles
        if ($LASTEXITCODE -ne 0) {
            throw 'markdownlint-cli2 reported markdown lint failures.'
        }
    }
}

Describe 'Shell checks' {
    It 'all selected shell scripts have the executable bit set' -Skip:($script:ShellFiles.Count -eq 0) {
        $notExecutable = @($script:ShellFiles | Where-Object {
            $fullPath = Join-Path $script:RepoRoot $_
            $mode = (Get-Item -LiteralPath $fullPath).UnixFileMode
            ($mode -band [System.IO.UnixFileMode]::UserExecute) -eq 0
        })
        if ($notExecutable.Count -gt 0) {
            throw "Not executable (run: chmod +x <file>):`n$($notExecutable -join "`n")"
        }
    }

    It 'parses selected shell scripts with bash -n' -Skip:($script:ShellFiles.Count -eq 0) {
        if (-not (Get-Command bash -ErrorAction SilentlyContinue)) {
            throw 'bash not found.'
        }

        foreach ($file in $script:ShellFiles) {
            & bash -n $file
            if ($LASTEXITCODE -ne 0) {
                throw "bash -n failed for $file"
            }
        }
    }

    It 'runs shellcheck on selected shell scripts when available' -Skip:($script:ShellFiles.Count -eq 0) {
        if (-not (Get-Command shellcheck -ErrorAction SilentlyContinue)) {
            Set-ItResult -Skipped -Because 'shellcheck is not installed.'
            return
        }

        & shellcheck @script:ShellFiles
        if ($LASTEXITCODE -ne 0) {
            throw 'shellcheck reported shell lint failures.'
        }
    }
}

Describe 'Spell checks' {
    It 'spell-checks selected markdown files with cspell' -Skip:($script:MarkdownFiles.Count -eq 0) {
        if (-not (Get-Command npx -ErrorAction SilentlyContinue)) {
            throw 'npx not found. Install Node.js via bootstrap or NVM.'
        }

        if (-not (Test-Path -LiteralPath (Join-Path $script:RepoRoot 'cspell.json'))) {
            throw 'cspell.json is missing; spell-check config is not configured.'
        }

        & npx --no-install cspell --no-progress @script:MarkdownFiles
        if ($LASTEXITCODE -ne 0) {
            throw 'cspell reported spelling errors.'
        }
    }
}

Describe 'Config checks' {
    It 'parses selected JSON and YAML config files' -Skip:($script:ConfigFiles.Count -eq 0) {
        if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
            throw 'node not found. Install Node.js via bootstrap or NVM.'
        }

        $validator = Join-Path $script:RepoRoot 'tests/validate-config-files.cjs'
        if (-not (Test-Path -LiteralPath $validator)) {
            throw 'tests/validate-config-files.cjs is missing.'
        }

        & node $validator @script:ConfigFiles
        if ($LASTEXITCODE -ne 0) {
            throw 'Config parsing reported JSON/YAML validation failures.'
        }
    }
}