$ErrorActionPreference = 'Stop'

BeforeDiscovery {
    $repoRoot    = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $manifestDir = Join-Path $repoRoot 'scripts/components'

    $validCategories    = @('core','agents','extras','monitoring','admin','training','comms','inference','sandbox','images','music','video','animation','digital-art')
    $validInstallTypes  = @('', 'compose', 'host', 'host-interactive', 'host-automated')
    $validMaturityLevels = @('stable', 'beta', 'untested')
    $validPromptTypes   = @('input', 'yesno', 'menu', 'secret', 'info', 'custom')
    $validWriteTargets  = @('stack.json', 'env', 'secrets.json')
    $validConfigTypes   = @('always', 'boolean', 'enum', 'array_member')
    $validWriteActions  = @('set', 'add_remove')

    $script:ManifestCases = Get-ChildItem -Path $manifestDir -Filter '*.manifest.json' -File -Recurse |
        ForEach-Object {
            $m = Get-Content $_.FullName -Raw | ConvertFrom-Json
            @{
                fileName          = $_.Name
                fullPath          = $_.FullName
                manifest          = $m
                repoRoot          = $repoRoot
                validCategories   = $validCategories
                validInstallTypes = $validInstallTypes
                validPromptTypes  = $validPromptTypes
                validWriteTargets = $validWriteTargets
                validConfigTypes  = $validConfigTypes
                validWriteActions = $validWriteActions
                validMaturityLevels = $validMaturityLevels
            }
        }
}

# ── Inventory ─────────────────────────────────────────────────────────────────

Describe 'Manifest inventory' {
    It 'finds at least one manifest file' -ForEach @(@{ count = $script:ManifestCases.Count }) {
        $count | Should -BeGreaterThan 0
    }

    It '<fileName> filename matches its id field' -TestCases $script:ManifestCases {
        $expected = $fileName -replace '\.manifest\.json$', ''
        $manifest.id | Should -Be $expected
    }
}

# ── JSON validity ─────────────────────────────────────────────────────────────

Describe 'Manifest JSON validity' {
    It '<fileName> is valid JSON' -TestCases $script:ManifestCases {
        { Get-Content $fullPath -Raw | ConvertFrom-Json } | Should -Not -Throw
    }
}

# ── Required top-level fields ─────────────────────────────────────────────────

Describe 'Required top-level fields' {
    It '<fileName> has non-empty id' -TestCases $script:ManifestCases {
        $manifest.id | Should -Not -BeNullOrEmpty
    }

    It '<fileName> has non-empty display_name' -TestCases $script:ManifestCases {
        $manifest.display_name | Should -Not -BeNullOrEmpty
    }

    It '<fileName> has order > 0' -TestCases $script:ManifestCases {
        [int]$manifest.order | Should -BeGreaterThan 0
    }

    It '<fileName> category is in allowed list' -TestCases $script:ManifestCases {
        $manifest.category | Should -Not -BeNullOrEmpty
        $manifest.category | Should -BeIn $validCategories
    }

    It '<fileName> has non-empty script path' -TestCases $script:ManifestCases {
        $manifest.script | Should -Not -BeNullOrEmpty
    }

    It '<fileName> script path exists on disk' -TestCases $script:ManifestCases {
        Join-Path $repoRoot $manifest.script | Should -Exist
    }

    It '<fileName> has func_prefix field' -TestCases $script:ManifestCases {
        $manifest.PSObject.Properties.Name | Should -Contain 'func_prefix'
    }

    It '<fileName> has profile field' -TestCases $script:ManifestCases {
        $manifest.PSObject.Properties.Name | Should -Contain 'profile'
    }

    It '<fileName> has health block with url and timeout' -TestCases $script:ManifestCases {
        $manifest.health | Should -Not -BeNullOrEmpty
        $manifest.health.PSObject.Properties.Name | Should -Contain 'url'
        $manifest.health.PSObject.Properties.Name | Should -Contain 'timeout'
        [int]$manifest.health.timeout | Should -BeGreaterThan 0
    }

    It '<fileName> install_type is in allowed list' -TestCases $script:ManifestCases {
        $manifest.PSObject.Properties.Name | Should -Contain 'install_type'
        $manifest.install_type | Should -BeIn $validInstallTypes
    }

    It '<fileName> wizard_default is a boolean' -TestCases $script:ManifestCases {
        $manifest.PSObject.Properties.Name | Should -Contain 'wizard_default'
        $manifest.wizard_default | Should -BeOfType [bool]
    }

    It '<fileName> maturity is valid when present' -TestCases $script:ManifestCases {
        if ($manifest.PSObject.Properties.Name -contains 'maturity') {
            $manifest.maturity | Should -BeIn $validMaturityLevels
        }
    }

    It '<fileName> has prompts array' -TestCases $script:ManifestCases {
        $manifest.PSObject.Properties.Name | Should -Contain 'prompts'
    }
}

# ── config block ──────────────────────────────────────────────────────────────

Describe 'config block validation' {
    It '<fileName> has config block' -TestCases $script:ManifestCases {
        $manifest.config | Should -Not -BeNullOrEmpty
    }

    It '<fileName> config.toggleable is a boolean' -TestCases $script:ManifestCases {
        $manifest.config.PSObject.Properties.Name | Should -Contain 'toggleable'
        $manifest.config.toggleable | Should -BeOfType [bool]
    }

    It '<fileName> has write_rules when toggleable=true' -TestCases $script:ManifestCases {
        if ($manifest.config.toggleable -eq $true) {
            $manifest.config.write_rules | Should -Not -BeNullOrEmpty
            $manifest.config.write_rules.Count | Should -BeGreaterThan 0
        }
    }

    It '<fileName> write_rule paths start with .' -TestCases $script:ManifestCases {
        if ($manifest.config.toggleable -eq $true -and $manifest.config.write_rules) {
            foreach ($rule in $manifest.config.write_rules) {
                $rule.path | Should -Not -BeNullOrEmpty
                $rule.path | Should -Match '^\.'
            }
        }
    }

    It '<fileName> set-action write_rules have on_enable and on_disable' -TestCases $script:ManifestCases {
        if ($manifest.config.toggleable -eq $true -and $manifest.config.write_rules) {
            foreach ($rule in $manifest.config.write_rules) {
                $action = if ($rule.PSObject.Properties.Name -contains 'action') { $rule.action } else { 'set' }
                if ($action -eq 'set' -or $action -eq '') {
                    $rule.PSObject.Properties.Name | Should -Contain 'on_enable'
                    $rule.PSObject.Properties.Name | Should -Contain 'on_disable'
                }
            }
        }
    }

    It '<fileName> add_remove write_rules have a value' -TestCases $script:ManifestCases {
        if ($manifest.config.toggleable -eq $true -and $manifest.config.write_rules) {
            foreach ($rule in $manifest.config.write_rules) {
                if ($rule.PSObject.Properties.Name -contains 'action' -and $rule.action -eq 'add_remove') {
                    $rule.PSObject.Properties.Name | Should -Contain 'value'
                    $rule.value | Should -Not -BeNullOrEmpty
                }
            }
        }
    }
}

# ── prompts[] schema ──────────────────────────────────────────────────────────

Describe 'prompts schema' {
    It '<fileName> prompt keys are unique' -TestCases $script:ManifestCases {
        if ($manifest.prompts -and $manifest.prompts.Count -gt 0) {
            $keys  = $manifest.prompts | ForEach-Object { $_.key }
            $dupes = $keys | Group-Object | Where-Object { $_.Count -gt 1 } | Select-Object -ExpandProperty Name
            $dupes | Should -BeNullOrEmpty
        }
    }

    It '<fileName> prompts have required fields' -TestCases $script:ManifestCases {
        if ($manifest.prompts -and $manifest.prompts.Count -gt 0) {
            foreach ($p in $manifest.prompts) {
                $p.key   | Should -Not -BeNullOrEmpty
                $p.type  | Should -Not -BeNullOrEmpty
                $p.type  | Should -BeIn $validPromptTypes
                $p.label | Should -Not -BeNullOrEmpty
            }
        }
    }

    It '<fileName> menu prompts have choices' -TestCases $script:ManifestCases {
        if ($manifest.prompts -and $manifest.prompts.Count -gt 0) {
            foreach ($p in $manifest.prompts | Where-Object { $_.type -eq 'menu' }) {
                $p.choices | Should -Not -BeNullOrEmpty
                $p.choices.Count | Should -BeGreaterThan 0
            }
        }
    }

    It '<fileName> prompt write_targets are valid' -TestCases $script:ManifestCases {
        if ($manifest.prompts -and $manifest.prompts.Count -gt 0) {
            foreach ($p in $manifest.prompts) {
                if ($p.PSObject.Properties.Name -contains 'write_target') {
                    $p.write_target | Should -BeIn $validWriteTargets
                }
            }
        }
    }
}

# ── Uniqueness ────────────────────────────────────────────────────────────────

Describe 'id and order uniqueness' {
    It 'no two manifests share the same id' {
        $ids   = $script:ManifestCases | ForEach-Object { $_.manifest.id }
        $dupes = $ids | Group-Object | Where-Object { $_.Count -gt 1 } | Select-Object -ExpandProperty Name
        $dupes | Should -BeNullOrEmpty -Because "duplicate ids: $($dupes -join ', ')"
    }

    It 'no two manifests share the same order value' {
        $orders = $script:ManifestCases | ForEach-Object { $_.manifest.order }
        $dupes  = $orders | Group-Object | Where-Object { $_.Count -gt 1 } | Select-Object -ExpandProperty Name
        $dupes | Should -BeNullOrEmpty -Because "duplicate order values: $($dupes -join ', ')"
    }
}

# ── host-interactive rules ────────────────────────────────────────────────────

Describe 'host-interactive manifest rules' {
    It '<fileName> host-interactive has wizard_default=false' -TestCases $script:ManifestCases {
        if ($manifest.install_type -eq 'host-interactive') {
            $manifest.wizard_default | Should -Be $false
        }
    }
}

# ── config block extended ─────────────────────────────────────────────────────

Describe 'config block extended' {
    It '<fileName> config.type is in allowed list' -TestCases $script:ManifestCases {
        $manifest.config.PSObject.Properties.Name | Should -Contain 'type'
        $manifest.config.type | Should -BeIn $validConfigTypes
    }

    It '<fileName> non-always config has read_path' -TestCases $script:ManifestCases {
        if ($manifest.config.type -ne 'always') {
            $manifest.config.PSObject.Properties.Name | Should -Contain 'read_path'
            $manifest.config.read_path | Should -Not -BeNullOrEmpty
            $manifest.config.read_path | Should -Match '^\.'
        }
    }

    It '<fileName> write_rule actions are in allowed list' -TestCases $script:ManifestCases {
        if ($manifest.config.toggleable -eq $true -and $manifest.config.write_rules) {
            foreach ($rule in $manifest.config.write_rules) {
                $action = if ($rule.PSObject.Properties.Name -contains 'action') { $rule.action } else { 'set' }
                $action | Should -BeIn $validWriteActions
            }
        }
    }
}

# ── dashboard block ───────────────────────────────────────────────────────────

Describe 'dashboard block' {
    It '<fileName> has dashboard block' -TestCases $script:ManifestCases {
        $manifest.PSObject.Properties.Name | Should -Contain 'dashboard'
    }

    It '<fileName> visible dashboard entry has required fields' -TestCases $script:ManifestCases {
        $dash = $manifest.dashboard
        if ($dash -and -not ($dash.PSObject.Properties.Name -contains 'show' -and $dash.show -eq $false)) {
            $dash.PSObject.Properties.Name | Should -Contain 'section'
            $dash.PSObject.Properties.Name | Should -Contain 'title'
            $dash.PSObject.Properties.Name | Should -Contain 'port'
            $dash.section | Should -Not -BeNullOrEmpty
            $dash.title   | Should -Not -BeNullOrEmpty
            [int]$dash.port | Should -BeGreaterThan 0
        }
    }
}

# ── optional field types ──────────────────────────────────────────────────────

Describe 'optional field type safety' {
    It '<fileName> requires_gpu is boolean if present' -TestCases $script:ManifestCases {
        if ($manifest.PSObject.Properties.Name -contains 'requires_gpu') {
            $manifest.requires_gpu | Should -BeOfType [bool]
        }
    }

    It '<fileName> prompt.required is boolean if present' -TestCases $script:ManifestCases {
        foreach ($p in $manifest.prompts) {
            if ($p.PSObject.Properties.Name -contains 'required') {
                $p.required | Should -BeOfType [bool]
            }
        }
    }

    It '<fileName> custom prompt has non-empty custom_func' -TestCases $script:ManifestCases {
        foreach ($p in $manifest.prompts | Where-Object { $_.type -eq 'custom' }) {
            $p.PSObject.Properties.Name | Should -Contain 'custom_func'
            $p.custom_func | Should -Not -BeNullOrEmpty
        }
    }

    It '<fileName> config.group is non-empty string if present' -TestCases $script:ManifestCases {
        if ($manifest.config.PSObject.Properties.Name -contains 'group') {
            $manifest.config.group | Should -BeOfType [string]
            $manifest.config.group | Should -Not -BeNullOrEmpty
        }
    }
}

# ── config type-specific fields ───────────────────────────────────────────────

Describe 'config type-specific fields' {
    It '<fileName> enum config has non-empty match_values' -TestCases $script:ManifestCases {
        if ($manifest.config.type -eq 'enum') {
            $manifest.config.PSObject.Properties.Name | Should -Contain 'match_values'
            $manifest.config.match_values            | Should -Not -BeNullOrEmpty
            $manifest.config.match_values.Count      | Should -BeGreaterThan 0
        }
    }

    It '<fileName> array_member config has non-empty member_value' -TestCases $script:ManifestCases {
        if ($manifest.config.type -eq 'array_member') {
            $manifest.config.PSObject.Properties.Name | Should -Contain 'member_value'
            $manifest.config.member_value            | Should -Not -BeNullOrEmpty
        }
    }
}

# ── health block extended ─────────────────────────────────────────────────────

Describe 'health block extended' {
    It '<fileName> health.url is empty or starts with http' -TestCases $script:ManifestCases {
        $url = $manifest.health.url
        if ($url) {
            $url | Should -Match '^https?://'
        }
    }
}

# ── prompt field constraints ──────────────────────────────────────────────────

Describe 'prompt field constraints' {
    It '<fileName> prompt.write_path starts with . if present' -TestCases $script:ManifestCases {
        foreach ($p in $manifest.prompts) {
            if ($p.PSObject.Properties.Name -contains 'write_path') {
                $p.write_path | Should -Not -BeNullOrEmpty
                $p.write_path | Should -Match '^\.'
            }
        }
    }

    It '<fileName> prompt.env_var is non-empty string if present' -TestCases $script:ManifestCases {
        foreach ($p in $manifest.prompts) {
            if ($p.PSObject.Properties.Name -contains 'env_var') {
                $p.env_var | Should -BeOfType [string]
                $p.env_var | Should -Not -BeNullOrEmpty
            }
        }
    }
}

# ── dashboard port uniqueness ─────────────────────────────────────────────────

Describe 'dashboard port uniqueness' {
    It 'no two visible dashboard entries share the same port' {
        $ports = $script:ManifestCases |
            ForEach-Object { $_.manifest.dashboard } |
            Where-Object { $_ -and -not ($_.PSObject.Properties.Name -contains 'show' -and $_.show -eq $false) } |
            ForEach-Object { $_.port }
        $dupes = $ports | Group-Object | Where-Object { $_.Count -gt 1 } | Select-Object -ExpandProperty Name
        $dupes | Should -BeNullOrEmpty -Because "duplicate dashboard ports: $($dupes -join ', ')"
    }
}
