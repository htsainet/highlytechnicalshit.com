#!/usr/bin/env bash
# scripts/lib/common.sh — Shared colors, logging, and environment helpers
# Source this file; do NOT run directly.

# ── Colors ────────────────────────────────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

# ── Repo root detection ──────────────────────────────────────────────────────
# Callers may override REPO_DIR before sourcing; otherwise auto-detect.
if [[ -z "${REPO_DIR:-}" ]]; then
  REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

# ── Logging ───────────────────────────────────────────────────────────────────
# LOG_FILE can be set by the caller before or after sourcing this file.
_log() {
  local level="$1"; shift
  echo "[$(date '+%F %T')] [$level] $*" >> "${LOG_FILE:-/dev/null}" 2>/dev/null || true
}

info()   { echo -e "${GREEN}[INFO]${NC} $*"; _log INFO "$*"; }
warn()   { echo -e "${YELLOW}[WARN]${NC} $*"; _log WARN "$*"; }
fail()   { echo -e "${RED}[FAIL]${NC} $*"; [[ -n "${LOG_FILE:-}" ]] && echo -e "${RED}[FAIL]${NC} See log: $LOG_FILE"; _log FAIL "$*"; exit 1; }
step()   { echo -e "\n${CYAN}${BOLD}══ $* ══${NC}"; _log STEP "══ $* ══"; }
ok()     { echo -e "${GREEN}[OK]${NC} $*"; _log OK "$*"; }

banner() {
  echo -e "\n${CYAN}${BOLD}╔══════════════════════════════════════════════════════╗${NC}"
  echo -e "${CYAN}${BOLD}║        AI STACK — INSTALLER                         ║${NC}"
  echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════╝${NC}\n"
  _log INFO "=== AI STACK INSTALLER STARTED ==="
}

# ── Environment loader ────────────────────────────────────────────────────────
load_env() {
  local env_file="${1:-$REPO_DIR/.env}"
  if [[ -f "$env_file" ]]; then
    set -a
    # shellcheck source=/dev/null
    source "$env_file"
    set +a
  fi
}
