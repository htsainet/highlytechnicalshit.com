#!/usr/bin/env bash
# setup-android.sh — Set up Ubuntu for Samsung/Android phone access

set -e

echo "==> Installing MTP support..."
sudo apt install -y gvfs-backends libmtp-dev mtp-tools

echo "==> Installing jmtpfs (command-line MTP mounting)..."
sudo apt install -y jmtpfs

echo "==> Installing ADB (Android Debug Bridge)..."
if apt-cache show adb &>/dev/null; then
    sudo apt install -y adb
else
    sudo apt install -y android-tools-adb
fi

echo "==> Creating ~/phone mount point..."
mkdir -p ~/phone

echo ""
echo "Done! Next steps:"
echo ""
echo "  1. Connect your Samsung phone via USB"
echo "  2. Unlock the phone and swipe down the notification shade"
echo "  3. Tap the USB option and select 'File Transfer (MTP)'"
echo ""
echo "  GUI access:  Open the Files app — phone should appear in the sidebar"
echo "  CLI access:  Run: jmtpfs ~/phone"
echo "               To unmount: fusermount -u ~/phone"
echo ""
echo "  ADB access:  Enable Developer Options on the phone (tap Build Number 7x)"
echo "               Enable USB Debugging, then run: adb devices"
