$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/n8n'
    $script:ComponentScript = Join-Path $script:ComponentDir 'n8n.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'n8n.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'n8n file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'n8n manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is n8n' {
        $script:Manifest.id | Should -Be 'n8n'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/n8n/n8n.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is n8n' {
        $script:Manifest.func_prefix | Should -Be 'n8n'
    }

    It 'dashboard port is 5678' {
        [int]$script:Manifest.dashboard.port | Should -Be 5678
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'n8n component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines n8n_install function' {
        $script:ComponentContent | Should -Match 'n8n_install\s*\(\)'
    }

    It 'defines n8n_configure function' {
        $script:ComponentContent | Should -Match 'n8n_configure\s*\(\)'
    }

    It 'defines n8n_start function' {
        $script:ComponentContent | Should -Match 'n8n_start\s*\(\)'
    }

    It 'defines n8n_stop function' {
        $script:ComponentContent | Should -Match 'n8n_stop\s*\(\)'
    }

    It 'defines n8n_health function' {
        $script:ComponentContent | Should -Match 'n8n_health\s*\(\)'
    }

    It 'supports --start, --stop, and --health CLI flags' {
        $script:ComponentContent | Should -Match '--start\)'
        $script:ComponentContent | Should -Match '--stop\)'
        $script:ComponentContent | Should -Match '--health\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/n8n/n8n\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'n8n port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 5678 is registered in portmap.json' {
        $script:Portmap.ports.'5678' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'5678'.service | Should -Be 'n8n'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'n8n no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/n8n\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/n8n/n8n\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
