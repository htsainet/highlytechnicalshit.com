# Install Docker Model Engine

Alternative to Ollama — uses Docker's native model plugin.

## Install

```bash
sudo apt-get install docker-model-plugin
```

## Update

```bash
docker model uninstall-runner --images && docker model install-runner
```
