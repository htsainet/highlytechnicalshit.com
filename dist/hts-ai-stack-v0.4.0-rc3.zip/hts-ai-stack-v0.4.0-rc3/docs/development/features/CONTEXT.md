# Feature Tracker

Proposed features and enhancements for the AI stack, tracked through proposal → implementation → validation.

Last updated: 2026-04-05 18:00:00

## What happens here

This workspace tracks feature proposals, implementation status, and validation results as the stack evolves. Features are proposed, built into the stack, tested by users, and documented before being marked complete and archived.

## Process / Workflow

1. **Proposal** — Create FEATURE-###.md with required metadata fields (see below)
2. **Release Assignment** — Tag feature with target release in metadata + add to [REFERENCES.md](REFERENCES.md)
3. **Implementation** — Feature built and integrated into stack with tests
4. **User Validation** — Feature tested in actual deployment scenarios
5. **Archive** — After validation passes, FEATURE-###.md removed from repo and committed (marks completion)

## Required Feature Metadata

Every `FEATURE-###.md` must include these fields at the top:

```markdown
**Priority:** HIGH | MEDIUM | LOW
**Effort:** Estimated hours (e.g., 8-12 hours)
**Risk:** Low | Medium | High — brief justification
**Target Release:** v0.4.0 | v0.5.0 | v0.6.0+ | Unscheduled
**Depends on:** Nothing — or list prerequisites (e.g., "Dual-inference merged")
**Blocks:** Nothing — or list dependent features
```

### Field Definitions

| Field | Values | Purpose |
|-------|--------|---------|
| **Priority** | `HIGH` `MEDIUM` `LOW` | Drives ordering within a release |
| **Effort** | Hours estimate | Drives release capacity planning |
| **Risk** | `Low` `Medium` `High` + reason | Flags items needing extra testing or design |
| **Target Release** | Semver tag or `Unscheduled` | Which release this ships in |
| **Depends on** | Feature IDs or milestones | What must complete first |
| **Blocks** | Feature IDs | What this unblocks when complete |

### Status Values

Used in [REFERENCES.md](REFERENCES.md) tracking tables:

| Status | Meaning |
|--------|---------|
| `Proposed` | Written up, not yet started |
| `In Progress` | Active development |
| `Testing` | Code complete, under validation |
| `Complete` | Validated, ready for archive |
| `Deferred` | Pushed to a later release |
| `Won't Do` | Rejected (keep in git history for context) |

## Release Tagging System

Features and bugs are organized by release target in [REFERENCES.md](REFERENCES.md).

For the full **Release & Branching Strategy** (why main-only, when to branch, version history),
see [`/docs/planning/CONTEXT.md`](/docs/planning/CONTEXT.md).

### Release Tiers

| Tier | Naming | Meaning |
|------|--------|---------|
| **Current Release** | `v0.4.0` | Actively being built; these ship next |
| **Next Minor** | `v0.5.0` | Planned for the release after current |
| **Future** | `v0.6.0+` | Good ideas without a committed release |
| **Unscheduled** | — | Backlog; may never ship |
| **Next Major** | `v1.0.0` | Breaking changes, large scope items (don't scaffold until needed) |

### Release Plans

Each release has a planning document in [`/docs/planning/`](/docs/planning/) covering
goals, feature list, gate checklist, risks, and draft release notes:

- [RELEASE-v0.4.0.md](/docs/planning/RELEASE-v0.4.0.md) — Current release
- [RELEASE-v0.5.0.md](/docs/planning/RELEASE-v0.5.0.md) — Next minor
- [RELEASE-v0.6.0.md](/docs/planning/RELEASE-v0.6.0.md) — Future placeholder

### Moving Features Between Releases

To defer a feature:

1. Update `Target Release:` in the FEATURE-###.md metadata
2. Move the row in [REFERENCES.md](REFERENCES.md) to the new release section
3. Add a note in the release plan explaining why it was deferred

### GitHub Integration

- **GitHub Milestones** mirror release tiers (v0.4.0, v0.5.0, etc.)
- **GitHub Issues** link back to local FEATURE-###.md files for full context
- **GitHub Labels** tag category: `bug`, `feature`, `enhancement`, `security`
- Local docs are the **authoritative source**; GitHub provides visibility and CI integration

## Files and structure

All active feature proposals are in this folder as `FEATURE-###.md` files, numbered sequentially.

| File | Purpose |
|------|---------|
| `FEATURE-###.md` | Individual feature proposal (metadata + problem + solution + testing) |
| `REFERENCES.md` | Feature index organized by release target |
| `CONTEXT.md` | This file — process, conventions, tagging system |

## What good looks like

- Each feature has its own `FEATURE-###.md` file with all required metadata
- Features are tagged to a specific release (or `Unscheduled`)
- [REFERENCES.md](REFERENCES.md) reflects current release assignments
- Features are built, tested, then archived via commit (audit trail in git)
- Release plans in `/docs/planning/RELEASE-v*.md` track gate checklists
- Deferred features have a clear paper trail (metadata change + commit message)

## Pester Enforcement

`tests/Test-FeatureHygiene.Tests.ps1` validates:

- The `docs/development/features/` directory exists
- No `FEATURE-###.md` file has a `Target Release` that matches an already-shipped git tag

If a release ships and a feature file still targets it, the test fails — the feature must be archived (completed) or re-targeted to a future release.

## Quick Commands

```bash
# What's targeted for a specific release?
grep -rl "Target Release: v0.5.0" docs/development/features/

# What's high priority?
grep -rl "Priority.*HIGH" docs/development/features/

# What's blocked?
grep -l "Depends on:" docs/development/features/ | xargs grep -v "Nothing"

# All features by status
grep "Status" docs/development/features/REFERENCES.md
```

## Tools and skills

- **git** — Version control and feature branching
- **Pester** — Test-driven development for PowerShell features
- **Docker** — Service deployment for feature testing
- **Claude Code** — Feature specification and implementation
- **GitHub** — Issue tracking, milestones, and feature proposals
