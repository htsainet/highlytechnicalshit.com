# LangFlow References

Last updated: 2026-04-15

## Upstream

- [GitHub — langflow-ai/langflow](https://github.com/langflow-ai/langflow)

## Official documentation

- [LangFlow Docs](https://docs.langflow.org/)
