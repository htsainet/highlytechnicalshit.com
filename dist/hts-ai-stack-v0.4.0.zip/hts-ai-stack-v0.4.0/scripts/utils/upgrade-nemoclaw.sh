#!/usr/bin/env bash
# scripts/utils/upgrade-nemoclaw.sh — Full NemoClaw + OpenClaw upgrade
#
# Updates OpenShell CLI on the host (pinned via NVIDIA install-openshell.sh),
# then upgrades sandboxes via the nemoclaw CLI.
#
# Usage:
#   ./scripts/utils/upgrade-nemoclaw.sh                 # full upgrade
#   ./scripts/utils/upgrade-nemoclaw.sh --openshell-only # update host OpenShell CLI only
#   ./scripts/utils/upgrade-nemoclaw.sh --sandbox-only   # update OpenClaw inside sandboxes only
#
# Architecture (Option A):
#   • nemoclaw CLI lives on the host (installed by NVIDIA's nemoclaw.sh).
#   • OpenShell CLI lives on the host (installed by NVIDIA's install-openshell.sh).
#   • OpenClaw runs exclusively inside OpenShell sandboxes managed by nemoclaw.
#   • The "Update now" button inside the OpenClaw Gateway Dashboard does NOT
#     work in NemoClaw-managed environments. NemoClaw owns the OpenShell
#     lifecycle, so updates must go through `nemoclaw upgrade-sandboxes`.
#   See: https://github.com/NVIDIA/NemoClaw#openshell-lifecycle
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
load_env

# OPENSHELL_VERSION: canonical value is in nemoclaw.manifest.json
# upstream.openshell_pinned_version. See DEVIATIONS.md → NemoClaw.
OPENSHELL_VERSION="${OPENSHELL_VERSION:-$(jq -r '.upstream.openshell_pinned_version' \
  "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.manifest.json" 2>/dev/null)}"
[[ -z "$OPENSHELL_VERSION" || "$OPENSHELL_VERSION" == "null" ]] && {
  echo "FATAL: could not read openshell_pinned_version from nemoclaw.manifest.json" >&2
  exit 1
}

# ── Upgrade the host-side OpenShell CLI to the pinned version ────────────────
upgrade_openshell_cli() {
  step "Upgrading OpenShell CLI (via NVIDIA install-openshell.sh)"
  install_openshell_nvidia \
    && ok "OpenShell CLI at pinned version." \
    || warn "OpenShell install encountered issues — check output above."
}

# ── Re-onboard sandboxes (pulls latest gateway + OpenClaw images) ────────────
upgrade_sandboxes() {
  step "Re-onboarding NemoClaw sandboxes"
  info "This recreates the OpenShell gateway and sandbox pods with latest images."
  info "Running: scripts/components/nemoclaw/nemoclaw.sh --update"

  # The component script's --update dispatcher calls _update_openclaw, which
  # follows NVIDIA's two documented paths:
  #   1. nemoclaw upgrade-sandboxes --auto --yes  (batch image refresh)
  #   2. nemoclaw <name> rebuild --yes            (per-sandbox, preserves workspace)
  # After either path, openclaw doctor --fix runs for cross-version repair.
  # Forwards and dashboard tokens are refreshed at the end.
  # (Path 3 / _patch_registry were removed in Option A — destructive re-onboard
  # is no longer part of the upgrade flow.)
  bash "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh" --update
}

# ── Health check ─────────────────────────────────────────────────────────────
verify_health() {
  step "Verifying NemoClaw health"
  bash "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh" --health
}

# ── Main ─────────────────────────────────────────────────────────────────────
main() {
  local mode="full"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --openshell-only)  mode="openshell"; shift ;;
      --sandbox-only)    mode="sandbox";   shift ;;
      --help|-h)
        echo "Usage: $(basename "$0") [--openshell-only | --sandbox-only]"
        echo ""
        echo "  (no flag)          Full upgrade: OpenShell CLI + re-onboard sandboxes"
        echo "  --openshell-only   Update the host OpenShell CLI only (no sandbox changes)"
        echo "  --sandbox-only     Re-onboard sandboxes only (no CLI change)"
        echo ""
        echo "NemoClaw and OpenShell CLIs live on the host; OpenClaw still runs"
        echo "inside sandboxes managed by NemoClaw. The 'Update now' button in"
        echo "the OpenClaw Gateway Dashboard does NOT work in NemoClaw-managed"
        echo "environments — use this script instead."
        exit 0
        ;;
      *) shift ;;
    esac
  done

  case "$mode" in
    full)
      upgrade_openshell_cli
      upgrade_sandboxes
      verify_health
      ;;
    openshell)
      upgrade_openshell_cli
      ;;
    sandbox)
      upgrade_sandboxes
      verify_health
      ;;
  esac

  ok "NemoClaw upgrade complete."
}

main "$@"
