#!/usr/bin/env bash
# scripts/components/kdenlive/kdenlive.sh — Kdenlive: install, configure, health
#
# Host-native installer for Kdenlive, the KDE non-linear video editor.
# Full-featured timeline editing, effects, transitions, and multi-track audio.
#
# Standalone usage:
#   ./scripts/components/kdenlive/kdenlive.sh              # full: install + configure + health
#   ./scripts/components/kdenlive/kdenlive.sh --install    # install only
#   ./scripts/components/kdenlive/kdenlive.sh --configure  # configure only
#   ./scripts/components/kdenlive/kdenlive.sh --start      # no-op (desktop app)
#   ./scripts/components/kdenlive/kdenlive.sh --stop       # no-op (desktop app)
#   ./scripts/components/kdenlive/kdenlive.sh --restart    # no-op (desktop app)
#   ./scripts/components/kdenlive/kdenlive.sh --health     # health check only
#   ./scripts/components/kdenlive/kdenlive.sh --status     # show status + health
#   ./scripts/components/kdenlive/kdenlive.sh --destroy    # uninstall Kdenlive
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# ── Functions ────────────────────────────────────────────────────────────────

kdenlive_install() {
  step "Kdenlive — install"
  if command -v kdenlive &>/dev/null; then
    skip "Kdenlive already installed."
  else
    info "Installing Kdenlive..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq kdenlive
    ok "Kdenlive installed."
  fi
}

kdenlive_configure() {
  step "Kdenlive — configure"
  info "Launch Kdenlive from the desktop to complete first-run configuration."
  ok "Kdenlive configured."
}

kdenlive_start() {
  step "Kdenlive — start"
  info "Desktop application — launch from your desktop environment."
  ok "Kdenlive start complete."
}

kdenlive_stop() {
  step "Kdenlive — stop"
  info "Desktop application — close from the GUI."
  ok "Kdenlive stop complete."
}

kdenlive_health() {
  local label="Kdenlive"
  printf "  %-35s" "$label"
  if command -v kdenlive &>/dev/null; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (kdenlive not found in PATH)"
    return 1
  fi
}

kdenlive_restart() {
  kdenlive_stop
  kdenlive_start
}

kdenlive_destroy() {
  step "Kdenlive — destroy"
  sudo apt-get remove -y kdenlive 2>/dev/null || true
  sudo apt-get autoremove -y -qq
  ok "Kdenlive removed."
}

kdenlive_status() {
  step "Kdenlive — status"
  if command -v kdenlive &>/dev/null; then
    ok "Kdenlive installed"
  else
    warn "Kdenlive NOT installed"
  fi
  kdenlive_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   kdenlive_install   ;;
    configure) kdenlive_configure ;;
    start)     kdenlive_start     ;;
    stop)      kdenlive_stop      ;;
    restart)   kdenlive_restart   ;;
    health)    kdenlive_health    ;;
    status)    kdenlive_status    ;;
    destroy)   kdenlive_destroy   ;;
    default)
      kdenlive_install
      kdenlive_configure
      kdenlive_health
      ;;
  esac
fi
