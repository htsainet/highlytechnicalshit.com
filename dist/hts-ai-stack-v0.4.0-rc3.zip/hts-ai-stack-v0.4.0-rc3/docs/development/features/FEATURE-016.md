# Public Distribution Mirror — Sanitized Release Workflow

**Priority:** HIGH
**Effort:** 10–14 hours
**Risk:** Medium — must ensure no secrets, internal paths, or private config
leak to the public repo. Requires careful .gitignore and sanitization review.
**Target Release:** v0.5.0
**Depends on:** Nothing
**Blocks:** Nothing — but enables community adoption

## Problem

The stack is developed in a private repo (`htsainet/hts-ai-stack`). To share
milestone releases publicly, we need a sanitized mirror that strips secrets,
internal references, and work-in-progress content.

## Solution

Create a public GitHub repo (`htsainet/hts-ai-stack-public`) with a GitHub
Actions workflow that mirrors sanitized milestone releases from the private
repo on each tagged release.

### Architecture

```text
Private repo (htsainet/hts-ai-stack)
  └─ git tag v0.5.0
     └─ GitHub Actions workflow triggers
        ├─ Sanitize: strip secrets, internal paths, WIP docs
        ├─ Validate: no secrets in output (gitleaks scan)
        └─ Push: mirror to htsainet/hts-ai-stack-public
```

## Implementation Steps

### Phase 1 — Define Milestone Criteria

Document what qualifies a release for public mirroring:

- All Pester tests pass
- No `TODO` or `FIXME` in shipped scripts
- Security review checklist complete for the release
- README accurate for the public audience
- No secrets or internal-only references in shipped files

### Phase 2 — Create Public Repo

- Create `htsainet/hts-ai-stack-public` on GitHub
- Add README, LICENSE (choose license), and minimal docs
- Configure branch protection on `main`

### Phase 3 — Sanitization Script

Create `scripts/utils/sanitize-for-public.sh`:

- Strip `config/stack.secrets.json` and any `*.secrets.*` files
- Remove `docs/planning/` (internal planning)
- Remove `docs/security-review/` (internal threat model)
- Remove `config/backups/` directory
- Remove `instances/` (environment-specific)
- Remove `logs/` directory
- Rewrite any hardcoded internal hostnames/IPs
- Strip git history (fresh commit per release)

### Phase 4 — Gitleaks Validation

Run `gitleaks detect` on the sanitized output to catch any leaked secrets
before pushing to the public repo.

### Phase 5 — GitHub Actions Workflow

Create `.github/workflows/mirror-public.yml`:

- Trigger: on push of `v*` tags
- Steps: checkout → sanitize → gitleaks scan → push to public repo
- Uses a deploy key or PAT for cross-repo push
- Fails the workflow if gitleaks finds any issues

### Phase 6 — Documentation

- Add distribution workflow docs to `docs/guides/`
- Document milestone criteria checklist
- Add public repo link to main README

## Acceptance Criteria

- [ ] Public repo created with LICENSE and README
- [ ] Sanitization script strips all sensitive content
- [ ] Gitleaks scan passes on sanitized output
- [ ] GitHub Actions workflow mirrors on tag push
- [ ] At least one test release successfully mirrored
- [ ] Milestone criteria documented and enforced
