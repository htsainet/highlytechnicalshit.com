#!/usr/bin/env bash
# scripts/components/cogvideox/cogvideox.sh — CogVideoX: install, configure, start, health
#
# ZhipuAI CogVideoX — AI text-to-video generation. The 2B model fits
# comfortably in ~6GB VRAM, making it viable on RTX 3060 (12GB).
# Runs via Gradio on GPU with CUDA acceleration.
#
# Standalone usage:
#   ./scripts/components/cogvideox/cogvideox.sh              # full: install + configure + start + health
#   ./scripts/components/cogvideox/cogvideox.sh --install    # install only (build image)
#   ./scripts/components/cogvideox/cogvideox.sh --configure  # configure only
#   ./scripts/components/cogvideox/cogvideox.sh --start      # start only
#   ./scripts/components/cogvideox/cogvideox.sh --stop       # stop
#   ./scripts/components/cogvideox/cogvideox.sh --restart    # restart (stop + start)
#   ./scripts/components/cogvideox/cogvideox.sh --health     # health check only
#   ./scripts/components/cogvideox/cogvideox.sh --status     # show status + port + health
#   ./scripts/components/cogvideox/cogvideox.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
COGVIDEOX_PORT="${COGVIDEOX_PORT:-7865}"

# ── Functions ────────────────────────────────────────────────────────────────

cogvideox_install() {
  step "CogVideoX — install"
  local dockerfile="$REPO_DIR/docker/cogvideox/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    warn "CogVideoX Dockerfile not found: $dockerfile"
    return 1
  fi
  compose_build --profile cogvideox
  ok "CogVideoX image built."
}

cogvideox_configure() {
  step "CogVideoX — configure"
  info "Gradio UI port: ${COGVIDEOX_PORT}"
  info "Model: THUDM/CogVideoX-2b (~6GB VRAM)"
  info "Model downloaded from HuggingFace on first start."
  ok "CogVideoX configured."
}

cogvideox_start() {
  step "CogVideoX — start"
  compose_up --profile cogvideox
  ok "CogVideoX started on port ${COGVIDEOX_PORT}."
}

cogvideox_stop() {
  step "CogVideoX — stop"
  compose_down --profile cogvideox
  ok "CogVideoX stopped."
}

cogvideox_health() {
  local label="CogVideoX :${COGVIDEOX_PORT}"
  printf "  %-35s" "$label"
  if curl -sf "http://localhost:${COGVIDEOX_PORT}/" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${COGVIDEOX_PORT}/)"
    return 1
  fi
}

cogvideox_restart() {
  cogvideox_stop
  cogvideox_start
}

cogvideox_destroy() {
  step "CogVideoX — destroy"
  compose_down --profile cogvideox -v
  ok "CogVideoX destroyed."
}

cogvideox_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=cogvideox" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "CogVideoX is running (port ${COGVIDEOX_PORT})"
  else
    warn "CogVideoX is not running."
  fi
  cogvideox_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   cogvideox_install   ;;
    configure) cogvideox_configure ;;
    start)     cogvideox_start     ;;
    stop)      cogvideox_stop      ;;
    restart)   cogvideox_restart   ;;
    health)    cogvideox_health    ;;
    status)    cogvideox_status    ;;
    destroy)   cogvideox_destroy   ;;
    default)
      cogvideox_install
      cogvideox_configure
      cogvideox_start
      cogvideox_health
      ;;
  esac
fi
