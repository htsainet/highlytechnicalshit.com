# Current Project

Last updated: 2026-04-19 23:31:00

## What we are building

We are building a reproducible installation procedure for a customizable, Linux AI stack utilizing a locally hosted LLM to act as an AI Agent.  

Repo: https://github.com/htsai-net/hts-ai-stack-release

[Core Services]
OpenClaw: https://openclaw.ai/
NemoClaw: https://www.nvidia.com/en-us/ai/nemoclaw/
OpenShell: https://docs.nvidia.com/openshell/latest/index.html
Ollama: https://ollama.com/

### Stack Categories

Beyond the core AI services, the stack includes optional components across several categories:

- **Creative Writing** — KoboldCpp, Ghostwriter, SillyTavern (AI-assisted fiction & writing)
- **Music Production** — Ardour, AudioCraft/MusicGen, Ubuntu Studio Audio
- **Video Production** — Kdenlive, OBS, CogVideoX, Open-Sora
- **Animation** — Blender, Synfig, OpenToonz, AnimateDiff
- **Digital Art & Design** — GIMP, Krita, Inkscape, Darktable
- **Voice & Avatar** — Open-LLM-VTuber, Coqui TTS, Faster-Whisper
- **Developer Tools** — Tabby, OpenCode, Aider, Gitea, Gitea Runner
- **Agents & Chat** — OpenClaw, NemoClaw, Open WebUI, LibreChat, Agnai, AnythingLLM
- **Automation** — n8n, Flowise, Langflow, DeerFlow
- **Monitoring** — Grafana, Prometheus, Portainer
- **Search** — SearXNG
- **Backup** — Duplicati

See [REFERENCES.md](REFERENCES.md) for links, ports, and architecture details.

## What good looks like

User can securely run and manage a local clawbot instance without having to install everything manually.

## Completed Projects

- **Install pipeline refactor** — restructured scripts into `lib/`, `host/`, `components/`, `bundles/`. All 16 tasks completed. See [refactor/CONTEXT.md](refactor/CONTEXT.md) for decisions and archive.
- **Config-driven convergence** (FEATURE-009) — single declarative orchestrator (`converge.sh`) that reads `stack.json` via component manifests and converges the host to the desired state. `full-stack.sh` deprecated; `install.sh` now calls `converge.sh` directly. See [docs/development/features/FEATURE-009.md](docs/development/features/FEATURE-009.md).
- **Manifest-driven components** (FEATURE-038) — every component has a `manifest.json` with metadata, config mapping, health check definitions, and deployment order. Manifests drive both converge.sh and the dashboard.
- **Pure Python wizard** — replaced fragile bash/whiptail/heredoc wizard (`ai_stack_setup.sh`) with `config/wizard/configure.py`. The old wizard had a fundamentally broken bash→tempfile→Python pipeline that silently dropped service selections. The new wizard is stdlib-only Python, reads manifests directly, and writes `stack.json` without intermediate files. See [Wizard Architecture](#wizard-architecture).
- **Manifest-driven env vars** — `apply_config.sh` auto-derives `_ENABLED` env vars from manifests instead of maintaining a hardcoded `SERVICE_CATALOG`. Services with custom env var names (e.g., `stable-diffusion` → `SD_ENABLED`) are handled by dedicated sections.
- **Dashboard service visibility** — fixed three compounding bugs (phantom catalog entries, missing catalog entries, health-action exclusion) that caused the dashboard to show only 5 of many selected services.

## Active Projects

- **Wizard domain extraction** — extracting inference profile from the wizard into `scripts/wizard/inference-profile.sh`. Model selection was removed from the wizard (FEATURE-064); a starter model is pulled during install and `model-select.sh` serves as the day-2 upgrade path.
- **Dual-inference backend** — adding BitNet + llama-swap alongside Ollama for GPU/CPU split inference. See `feature/dual-inference` branch.
- **Dashboard auto-login** — tokenized URLs for Open WebUI and NemoClaw sandboxes so the dashboard provides one-click authenticated access without manual sign-in. Uses a same-origin login bridge page and JWT sidecar files.
- **OpenClaw auto-update** — `nemoclaw.sh --update` automatically updates OpenClaw inside GPU/CPU sandboxes to the latest version.
- **NemoClaw host-side install** — the nemoclaw CLI lives on the host machine, matching NVIDIA's documented design. The prior (inverted) install ran nemoclaw inside the OpenShell sandbox, which blocked lifecycle commands (`upgrade-sandboxes`, `rebuild`, `snapshot create`) from the host and caused `libsignal-node` npm failures (ssh:// blocked by network policy). OpenShell install logic lives in `install_openshell_nvidia()` in `scripts/lib/common.sh`.
- **Docker image pinning + NAS mirroring** — all 38 Dockerfiles pinned to version tags + sha256 digests. `MIRROR` build arg enables a global toggle to pull from a local NAS registry instead of upstream. See `docker-images.md`, `scripts/host/nas-setup.sh`.
- **Agent skills evaluation** — tracking 5 cross-platform AI agent skills for use with OpenClaw and DeerFlow agents. See `docs/planning/agent-skills/`.

## Install Lifecycle

```text
bootstrap.sh      → prereqs, Docker, NVIDIA drivers (ALWAYS LAST — requires reboot)
  └─ reboot
install.sh        → wizard → apply_config → preflight → converge.sh --yes
  └─ preflight.sh → nvidia-ctk, docker, node, tools (post-reboot host setup)
reconfigure.sh    → wizard → converge.sh (day-2, no host setup)
configure.sh      → [planned] targeted day-2 reconfiguration (inference, models, etc.)
converge.sh       → stack.json → manifests → desired vs actual → start/stop/health
```

> **NVIDIA drivers are ONLY installed from `bootstrap.sh` and ALWAYS LAST because
> they require a forced reboot. Nothing else requires a reboot.**

### What `converge.sh` does NOT do

Convergence brings containers to the desired *configured* state; it does not
perform one-shot data operations. The following are **explicit post-converge
steps** and will not be triggered by `install.sh`, `reconfigure.sh`, or
`converge.sh`:

| Operation | Trigger | Notes |
|-----------|---------|-------|
| Ollama additional-model pulls | `scripts/components/ollama/ollama.sh --pull-models` (all env=prod), or the end-of-`install.sh` prompt which backgrounds the same command | Converge now pulls the configured `$OLLAMA_MODEL` starter synchronously via `ollama_ensure_models` (see *Starter-model pull*, below). The *other* prod models (qwen2.5:7b-instruct-q4_K_M, mistral-nemo, deepseek-r1, etc.) are still multi-GB each and remain consent-gated at install time. |
| Open WebUI admin bootstrap | runs once automatically on first `open-webui.sh` default action | Idempotent; skipped if `WEBUI_API_KEY` already present in `.env`. |
| NVIDIA driver install / reboot | `bootstrap.sh` only | See above. |
| GPU / VRAM sizing decisions | wizard (`install.sh` / `reconfigure.sh`) | Not re-evaluated on every converge. |
| Secret rotation | manual, or `scripts/maintenance/*` helpers | Converge never regenerates an existing secret. |

### Starter-model pull (FEATURE-064, MVP scope)

Converge **does** now pull the configured starter model synchronously via
`ollama_ensure_models` in `scripts/components/ollama/ollama.sh`:

- Runs at the end of `ollama_health` (the path every reconciler action hits).
  This means changing `$OLLAMA_MODEL` in `.env` and re-running `converge.sh
  --yes` will pull the new starter automatically.
- `nemoclaw.sh`'s `_do_onboard` preflight calls it as a belt-and-suspenders
  guard so onboard can't race the starter pull.
- Idempotent: a no-op when the starter is already in `/api/tags`.
- Escape hatch: `OLLAMA_SKIP_PULL=1` skips the whole step (for CI / no-net).
- Verified with `assert_postcondition` from `scripts/lib/` — see *Postcondition
  verification* below.

The *other* prod models (qwen2.5:7b-instruct-q4_K_M, mistral-nemo, deepseek-r1, etc.) remain
out-of-converge. They're offered via an end-of-`install.sh` opt-in prompt
that backgrounds `ollama.sh --pull-models`; no reconciler or health pass
ever pulls them.

### Postcondition verification

Several recurring bugs in this stack share one shape: an external CLI printed
a success marker (`✓`, `ok`, `Updated`) while the actual invariant wasn't met.
Examples:

- `docker compose up -d` returned success while the image was stale.
- `converge.sh` reported `success` for Ollama while `/api/tags` was empty.
- `openshell provider update compatible-endpoint → ✓ Updated` while the
  sandbox still couldn't reach the routing surface.

**Rule:** if a component runs an external CLI that prints `✓` on success,
verify the actual artifact independently before trusting it. Use
`assert_postcondition` from [`scripts/lib/assert-postcondition.sh`](scripts/lib/assert-postcondition.sh):

```bash
source "${REPO_DIR}/scripts/lib/assert-postcondition.sh"

_probe_starter_present() {
  curl -fsS --max-time 5 http://localhost:11434/api/tags \
    | grep -q "\"name\":\"${OLLAMA_MODEL}\""
}
assert_postcondition "starter model present in /api/tags" _probe_starter_present
```

On pass the helper prints `[verified] <label>`; on fail it prints the label,
the check command, and the captured stderr tail, and exits 2.

### Repo-invariant checks (report-only)

Two standalone checkers live in `scripts/maintenance/` and are safe to run any
time. Both are **report-only** by default (exit 0 even on drift); pass
`--strict` to turn drift into a non-zero exit for CI / pre-commit gating later.

| Check | Enforces |
|-------|----------|
| `bash-write-check.sh` | CLAUDE.md ban on `awk` / `sed -i` / `tee` writing repo-tracked config files (`.env`, `config/*.{json,yaml}`). Ignores legitimate edits to system config like `/etc/ssh/sshd_config`. |
| `registry-llama-swap-check.py` | Every Ollama model routed by `config/llama-swap.yaml` is pullable via `scripts/install/models/registry.json`, and every prod-env model in the registry is routable. |
| `llamaswap-routing-check.py` | **llama-swap is the single LLM routing surface.** No component config or component script may hardcode `ollama:11434`, `http://ollama:…`, `bitnet:8080`, or `http://bitnet:…` as a backend URL — consumers must point at `http://llama-swap:${LLAMA_SWAP_PORT:-8081}/v1` and select BitNet by setting `model: bitnet` (NOT via a second URL). Prometheus scrape targets and the component scripts that own the raw backends are allow-listed. Wired into `.githooks/pre-commit`. |

## AI Instruction Files

A single `CLAUDE.md` at the repo root is the source of truth for all AI assistant
instructions ([Clief Notes Framework](CLIEF-NOTES-FRAMEWORK.md) Layer 1). Two
symlinks ensure every major AI coding tool picks it up automatically:

```text
CLAUDE.md                         ← source of truth (identity, rules, quick-nav)
AGENTS.md                         → CLAUDE.md   (GitHub Copilot CLI convention)
.github/copilot-instructions.md   → ../CLAUDE.md (GitHub Copilot in-editor convention)
```

### Release handling

All three files ship in the public release. `release-export.sh` applies two
redactions to generalize the content:

1. **Identity line** — removes the developer name ("helping Tim build" → "helping build")
2. **Refactor Quick-Nav row** — deleted because `refactor/` is excluded from release

The `.claude/` directory (Claude Code local state) is blacklisted from release
snapshots and should never be committed.

### Maintenance rules

- Edit `CLAUDE.md` only — the symlinks follow automatically
- Keep it under 50 lines (framework constraint)
- After editing, run `npx markdownlint-cli2 CLAUDE.md` to lint

## Wizard Architecture

The wizard (`config/wizard/configure.py`) is a pure-Python terminal UI that
reads component manifests, presents toggle checklists grouped by category, and
writes `stack.json` directly. No external dependencies (stdlib only).

```text
config/wizard/
  configure.py                    ← main wizard (Python 3, stdlib only)
  ai_stack_setup.sh               ← legacy wizard (kept as fallback, not called)
  ai_stack_setup.py               ← unused questionary-based wizard (not called)
  apply_config.sh                 ← maps stack.json → .env variables
scripts/wizard/
  inference-profile.sh            ← inference stack selection (STUB — not yet wired)
  model-select.sh                 ← day-2 model upgrade (post-install)
```

### How configure.py works

1. **Manifest scan** — reads all `scripts/components/*/manifest.json` files, filters to `config.toggleable: true`, groups by `category`
2. **Backend step** — presents backend engine choices (ollama / dual / localai / custom)
3. **Sandbox step** — presents sandbox engine choices (openshell / gvisor / both)
4. **Category checklists** — for each of 16 categories, displays a numbered toggle list. Enter numbers to toggle, `a`=all, `n`=none, `d`=done
5. **Write rules** — applies each manifest's `config.write_rules` to build the final `stack.json`. Handles three formats:
   - `action: "add_remove"` — array membership (add/remove from `extras.components`)
   - `on_enable: "add:value"` — implicit array membership (same behavior)
   - `on_enable: true/false` — boolean path set
6. **Save** — writes `stack.json` with metadata, creates timestamped backup

### Why the old wizard was replaced

The bash wizard (`ai_stack_setup.sh`) used whiptail for checkboxes, serialized
selections to a JSON temp file, then a Python heredoc read that file and applied
write rules. This bash→tempfile→Python pipeline silently dropped service
selections — the wizard summary showed 24 services selected but `stack.json`
remained empty. The root cause was multi-layered: bash associative array
serialization failures, temp file path issues, and the Python heredoc's
`enabled_services.get()` defaulting to `False` for missing entries.

### Inference Profiles

Five profiles replace the old two-option backend menu. Profiles are VRAM-gated:

| # | Profile | BACKEND | Components | Min VRAM |
|---|---|---|---|---|
| 1 | `ollama` | ollama | Ollama only | 0 |
| 2 | `dual` ★ | dual | Ollama + BitNet + llama-swap | 0 (BitNet is CPU) |
| 3 | `dual-lms` | dual | + LM Studio peer | 0 (LMS on host) |
| 4 | `localai` | localai | LocalAI only | 16384 MiB (16 GB) |
| 5 | `custom` | * | User-selected components | 0 |

★ default. On a 12 GB GPU, profile 4 (localai) is hidden from the menu.

The `vram_minimum` field in each component's `manifest.json` drives this filtering.
`GPU_VRAM_TOTAL` is detected via `nvidia-smi` at wizard startup.

### Model Selection

Install pulls a single starter model (`smollm2:135m`, ~100 MB) for fast
bootstrap.  Upgrade to a larger model post-install via `model-select.sh`.

VRAM-aware upgrade recommendations (shown by `model-select.sh`):

| GPU VRAM | Recommended model |
|---|---|
| < 6 GB | smollm2:135m (starter) |
| 6–8 GB | gemma3:4b |
| 8–12 GB | qwen2.5:7b-instruct-q4_K_M |
| 12–16 GB | mistral-nemo:latest *(NemoClaw default, strong tool-caller)* |
| 16–24 GB | llama3.1:8b |
| ≥ 24 GB | llama3.3:70b-q4 |

## What to avoid

Avoid using cloud based LLMs within the app so spend can be controlled.

### Never run entry-point scripts as root

`bootstrap.sh`, `install.sh`, `converge.sh`, and `nuke-stack.sh` must **never**
be invoked with `sudo` or from a root shell. Each script calls `sudo` internally
only where needed (apt, systemctl, dpkg). Running the whole script as root
creates files owned by `root` inside the repo (`logs/`, `resources/dashboard/`,
`config/backups/`, `.env`), which then causes permission-denied errors on
subsequent non-root runs.

The `admin.sudo_keepalive` wizard option is the correct mechanism for unattended
installs — it caches sudo credentials so internal `sudo` calls don't prompt, but
the main process stays as the regular user.

Each entry-point script has a guard that rejects `EUID == 0`.

### Banned bash idioms (enforced by pre-commit)

`sed` is blocked by the `banned-shell-idioms` pre-commit hook
(`scripts/lint/check-banned-shell-idioms.sh`, wired via
`.pre-commit-config.yaml` and `.github/workflows/pre-commit.yml`).

Why `sed` specifically: regex find-and-replace is guesswork — matches greedily,
eats newlines, causes silent corruption. The bite-history in this repo is 100%
sed-regex (NVIDIA Step-17 patch chain, output-formatting reflex in diag
scripts, etc.). `cat`/`awk`/`tee` are documented discipline but not
enforced — heredocs are deterministic and read-only `awk`/`tee` are fine.

The hook only checks **lines added** in the staged diff (or the PR diff in
CI), not whole files — existing legacy uses are grandfathered, so this rule
costs zero retroactive cleanup. New violations are blocked locally and in CI.

Suggested replacements:

- Replace text in a file → use the agent's `edit` tool (exact literal match,
  refuses on ambiguity).
- Create a new file → use the agent's `create` tool.
- Output formatting (e.g. indenting log lines) → bash `while IFS= read -r line;
  do printf ...; done` loop, **not** `sed 's/^/  /'`.

Escape hatch (rare, must justify on the same line):

```bash
some_command  # allow-banned-idiom: <reason>
```

One-time setup per clone:

```bash
pip install --user pre-commit   # or: pipx install pre-commit
pre-commit install
```

## Tools and dependencies

- **Ubuntu 24.04 LTS** — Target Linux distribution
- **Docker** — Container orchestration
- **NVIDIA CUDA** — GPU acceleration
- **Ollama** — Local LLM inference
- **llama-swap** — Model multiplexer for GPU/CPU split inference
- **NemoClaw** — Sandbox security enforcement
- **OpenClaw** — AI agent runtime
- **Open WebUI** — Chat frontend (all models via llama-swap)
- **Claude Code** — Documentation and script generation
- **Pester** — Configuration and integration testing
- **skopeo** — Container image inspection and digest resolution (no Docker daemon required)

## Docker Image Pinning + NAS Mirroring

All 38 Dockerfiles use `ARG MIRROR=` before each `FROM` line. When `MIRROR` is empty (default), images pull from upstream registries. When set to a local registry (e.g., `<nas>:5000/`), all builds pull from the NAS mirror instead.

### Key files

| File | Purpose |
|---|---|
| `docker-images.md` | Sorted reference table of all base images, tags, and digests |
| `scripts/release/pin-docker-images.sh` | Resolves `latest` tags to version numbers + sha256 digests via skopeo |
| `scripts/release/pull-all-images.sh` | Pulls all 30 base images onto a Synology NAS (run via SSH) |
| `scripts/release/push-to-nas.sh` | Tags + pushes all 30 images to NAS registry (skopeo fallback) |
| `scripts/host/nas-setup.sh` | Interactive whiptail menu — configures Docker mirror + NFS share mounts |
| `scripts/host/nas.sh` | NFS plumbing — idmapd, fstab, mount, validate |
| `scripts/host/backup-models.sh` | Rsync Docker model volumes → NAS (never deletes) |
| `scripts/host/migrate-nas-folders.sh` | One-off: reorganize flat NAS layout into nested structure |
| `scripts/utils/seed-model-cache.sh` | Populate NAS model cache from registry.json |

### MIRROR toggle

Set in `.env` (gitignored — per-user):

```env
# Pull from upstream (default)
MIRROR=

# Pull from local NAS registry
MIRROR=<nas>:5000/
```

Passed to all 38 services in `docker-compose.yml` via `build.args.MIRROR`.

### NFS share names

| Share | Mount point | Purpose |
|---|---|---|
| `htsai-model-backup` | `/mnt/htsai-model-backup` | AI model cache (Ollama, SD, ComfyUI, etc.) |
| `htsai-docker-volume-backup` | `/mnt/htsai-docker-volume-backup` | Docker volume backups |
| `htsai-timeshift-backup` | `/mnt/htsai-timeshift-backup` | Timeshift system snapshots |
| `htsai-disk-image` | `/mnt/htsai-disk-image` | Full disk images for disaster recovery |

NFS settings live in `~/.config/htsai/nas.env` (survives repo nuke-and-pave).
Docker MIRROR stays in repo `.env` (build concern only, disposable).

### NAS model cache layout

```text
/mnt/htsai-model-backup/
├── ollama/models/             ← Ollama blobs + manifests
├── stable-diffusion/
│   ├── checkpoints/           ← .safetensors model files
│   ├── loras/
│   ├── embeddings/
│   └── vae/
├── comfyui/
│   ├── models/
│   ├── custom_nodes/
│   └── output/
├── bitnet/models/
├── localai/models/
├── coqui-tts/models/
└── vosk/models/
```

### How model caching works (install → NAS → restore)

**Backup (host → NAS):**

```bash
sudo ./scripts/host/backup-models.sh
```

Rsyncs each Docker volume to its NAS subfolder. No `--delete` flag, so NAS
files are never removed. Safe to re-run — skips already-synced files.

**Restore (NAS → host, automatic at install time):**

Each component script checks for models on the NAS before downloading:

1. **Already in Docker volume?** → skip
2. **Available on NAS mount?** → copy locally (fast, no internet)
3. **Neither?** → download from internet, then seed NAS cache

| Component | NAS cache env var | Default path |
|---|---|---|
| Ollama | `NAS_MODEL_CACHE` | `/mnt/htsai-model-backup/ollama/models` |
| Stable Diffusion | `NAS_SD_CACHE` | `/mnt/htsai-model-backup/stable-diffusion/checkpoints` |
| ComfyUI | `NAS_SD_CACHE` | `/mnt/htsai-model-backup/stable-diffusion/checkpoints` |

**Nuke-and-pave workflow:**

1. `sudo ./backups/pre-nuke-checklist.sh --disk` — runs all backup layers
2. Delete repo / `docker system prune -a --volumes`
3. Reinstall Ubuntu, same hostname and user
4. `git clone` + `./install.sh` — rebuilds containers
5. `sudo ./scripts/host/nas-setup.sh` — restores NFS mounts
6. Restore Docker volumes from NAS archives
7. Component scripts auto-pull models from NAS on first run (no re-download)

See [docs/guides/disaster-recovery.md](docs/guides/disaster-recovery.md) for the full runbook.

## Vendor-Instruction Deviations

All knowing deviations from vendor install instructions are tracked in
[`DEVIATIONS.md`](DEVIATIONS.md). Supporting links (vendor docs, upstream
issues, PRs) live in `REFERENCES.md` under each component's section.
Do not duplicate deviation entries in this file.

## Backup & Disaster Recovery

Five backup layers protect against data loss at every level:

| Layer | Script | Destination | What it covers |
|---|---|---|---|
| OS snapshots | `backups/timeshift/setup-timeshift.sh` | `/mnt/htsai-timeshift-backup` | System packages, drivers, configs |
| Docker volumes | `backups/docker/backup-volumes.sh` | `/mnt/htsai-docker-volume-backup` | Chat history, workflows, repos, settings |
| Model weights | `scripts/host/backup-models.sh` | `/mnt/htsai-model-backup` | Ollama, SD, ComfyUI, TTS, Vosk models |
| System configs | `backups/pre-nuke-checklist.sh` | `/mnt/htsai-docker-volume-backup/configs/` | .env, fstab, daemon.json, stack.json |
| Full disk image | `backups/disk-image/backup-disk.sh` | `/mnt/htsai-disk-image` | Byte-for-byte dd+gzip clone (nuclear option) |

### Key files

| File | Purpose |
|---|---|
| `backups/pre-nuke-checklist.sh` | Orchestrates all backup layers in sequence before a nuke-and-pave |
| `backups/disk-image/backup-disk.sh` | Full disk image via `dd + gzip` piped directly to NAS |
| `backups/docker/backup-volumes.sh` | Pause → tar → archive Docker volumes to NAS (26 volumes) |
| `backups/timeshift/setup-timeshift.sh` | Install and configure Timeshift with AI-stack-tuned exclusions |
| `backups/synology/setup-nas-mount.sh` | TPM2-encrypted Synology CIFS mount (credentials never on disk) |
| `docs/guides/disaster-recovery.md` | Step-by-step nuke-and-pave restoration runbook |
| `docs/guides/release-pipeline.md` | End-to-end release process: source tag → public mirror snapshot → website zip + bootstrap.sh |
| `docs/guides/synology-nfs-shares.md` | Synology DSM NFS share setup guide (4 shares) |
