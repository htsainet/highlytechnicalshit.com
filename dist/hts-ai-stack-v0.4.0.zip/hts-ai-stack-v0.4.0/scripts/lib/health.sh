#!/usr/bin/env bash
# scripts/lib/health.sh — Unified health-check helpers
# Source this file; do NOT run directly.
# Requires: common.sh sourced first (for colors and logging)

# health_probe <label> <url> [max_attempts] [sleep_seconds]
# Polls a URL until it returns HTTP 2xx or the attempt limit is hit.
health_probe() {
  local label="$1"
  local url="$2"
  local max_attempts="${3:-30}"
  local sleep_secs="${4:-2}"
  local attempts=0

  printf "  %-35s" "$label"
  if ! curl -sf "$url" >/dev/null 2>&1; then
    printf "${YELLOW}[Waiting for container]${NC} "
    until curl -sf "$url" >/dev/null 2>&1; do
      sleep "$sleep_secs"
      attempts=$((attempts + 1))
      if [[ $attempts -ge $max_attempts ]]; then
        printf "\r  %-35s${RED}FAIL${NC} (%s)\n" "$label" "$url"
        return 1
      fi
    done
    # Clear the waiting message and reprint cleanly
    printf "\r  %-35s${GREEN}OK${NC}  \n" "$label"
  else
    echo -e "${GREEN}OK${NC}"
  fi
}

# port_check <port> — returns 0 if something is listening on the given TCP port
port_check() {
  local port="$1"
  if command -v ss &>/dev/null; then
    ss -tln 2>/dev/null | awk -v p=":$port" '$4 == p || $4 ~ ":" p "$" {found=1} END{exit !found}' && return 0
  fi
  if command -v nc &>/dev/null; then
    nc -z -w1 127.0.0.1 "$port" 2>/dev/null && return 0
  fi
  return 1
}

# wait_for_healthy <container_name> [timeout_seconds]
# Polls `docker inspect` until .State.Health.Status == "healthy" or timeout.
wait_for_healthy() {
  local container="$1"
  local timeout="${2:-120}"
  local elapsed=0
  local status

  while [[ $elapsed -lt $timeout ]]; do
    status=$(docker inspect --format='{{.State.Health.Status}}' "$container" 2>/dev/null || echo "missing")
    case "$status" in
      healthy)   return 0 ;;
      unhealthy) return 1 ;;
    esac
    sleep 2
    elapsed=$((elapsed + 2))
  done
  return 1
}
