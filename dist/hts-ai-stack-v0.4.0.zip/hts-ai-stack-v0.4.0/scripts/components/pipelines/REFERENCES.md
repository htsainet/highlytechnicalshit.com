# Pipelines References

Last updated: 2026-04-15

## Upstream

- [GitHub — open-webui/pipelines](https://github.com/open-webui/pipelines)

## Official documentation

- [Pipelines README](https://github.com/open-webui/pipelines#readme)
- [Open WebUI Pipelines Docs](https://docs.openwebui.com/pipelines/)
