# Model Registry Context

The **model registry** is a JSON file (`model-registry.json`) placed at the repository root. It enumerates every model that any component in the stack may need, together with:

* **Download URL** – the source from which the model can be fetched.
* **License** – SPDX‑style identifier (e.g., `MIT`, `OpenRAIL`).
* **Trust level** – a simple rating (`high`, `medium`, `low`, `unknown`) used by our security‑review scripts.

Components reference this registry via two new manifest keys:

* `options_source` – a JSON‑Pointer that points to the list of selectable filenames.
* `default_source` – a JSON‑Pointer that points to the default choice.

During the installation wizard, the manifest loader resolves those pointers, builds a **select** prompt, and writes the chosen value to an environment variable (e.g., `SD_CHECKPOINT`). The component script then reads that variable and uses the generic download helper (`model_download_if_missing`) to fetch the file into the appropriate Docker volume.

This approach makes model handling **declarative**, **auditable**, and **re‑usable** across the entire stack.
