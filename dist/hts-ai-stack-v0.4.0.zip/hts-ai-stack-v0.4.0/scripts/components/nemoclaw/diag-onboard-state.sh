#!/usr/bin/env bash
# Diagnostic for inspecting the state of a NemoClaw onboard attempt.
# One-shot: gateway list, sandbox list, blueprint pin, last 80 lines of log.
set -u
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
SANDBOX="${1:-hts-ai-openshell-nemoclaw}"
GATEWAY="${NEMOCLAW_GATEWAY_NAME:-nemoclaw}"

echo "=== exit / log tail ==="
tail -n 80 "$REPO_DIR/logs/nemoclaw-gateway-${SANDBOX}.log" 2>&1
echo
echo "=== nemoclaw version ==="
nemoclaw --version 2>&1
echo
echo "=== gateway list ==="
openshell gateway list 2>&1 || true
echo
echo "=== sandbox list (gateway: ${GATEWAY}) ==="
openshell sandbox list -g "$GATEWAY" 2>&1 || true
echo
echo "=== sandbox list (gateway: ${SANDBOX}) ==="
openshell sandbox list -g "$SANDBOX" 2>&1 || true
echo
echo "=== blueprint pin ==="
grep -E 'min_openshell_version|max_openshell_version' \
  "$HOME/.nemoclaw/source/nemoclaw-blueprint/blueprint.yaml" 2>&1
