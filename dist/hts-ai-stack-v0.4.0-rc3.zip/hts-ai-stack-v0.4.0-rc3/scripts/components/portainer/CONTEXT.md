# Portainer Component

Last updated: 2026-04-15

## What happens here

Portainer provides a web UI for managing Docker containers, images,
volumes, and networks. Used in the stack for visual container management
and troubleshooting without needing the CLI.

## Files and structure

| File | Purpose |
|------|---------|
| `portainer.sh` | Full lifecycle: install, configure, start, stop, health |
| `portainer.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
