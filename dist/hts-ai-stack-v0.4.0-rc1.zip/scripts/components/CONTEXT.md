# Component Scripts

Last updated: 2026-04-04 23:00:00

## What happens here

Each file in this folder manages the full lifecycle (install, start, stop, health, remove) of a single stack service. Component scripts can run standalone or be sourced by bundle scripts for individual function access.

## Process / Workflow

1. Bundle script (e.g. `bundles/chat.sh`) sources component scripts for the services it needs
2. Each component exposes functions like `{service}_install()`, `{service}_start()`, `{service}_health()`
3. When run standalone, a component installs + starts + health-checks its service
4. All components source `lib/common.sh` and optionally `lib/compose.sh`, `lib/health.sh`

## Files and structure

| File | Service | Notes |
|------|---------|-------|
| `ollama.sh` | Ollama LLM inference | Model pull, swap (lean/mean/claw), health |
| `open-webui.sh` | Open WebUI chat frontend | |
| `bitnet.sh` | BitNet 1-bit LLM | Docker build from `docker/bitnet/` |
| `llama-swap.sh` | llama-swap model router | GPU/CPU flip-flop scheduling |
| `nemoclaw.sh` | NemoClaw sandbox | NVIDIA security enforcement. Flags: `--update` (OpenClaw binary), `--upgrade` handled by `utils/upgrade-nemoclaw.sh` |
| `openspace.sh` | OpenSpace agent skills | |
| `dashboard.sh` | Nginx dashboard | Landing page on port 80 |
| `gitea.sh` | Gitea self-hosted Git | |
| `stable-diffusion.sh` | Stable Diffusion | Image generation |
| `comfyui.sh` | ComfyUI | Visual workflow for SD |
| `sillytavern.sh` | SillyTavern | Character card management |
| `deerflow.sh` | DeerFlow | Multi-agent orchestration |
| `gvisor-sandbox.sh` | gVisor Sandbox | CPU agent sandbox — OpenClaw on runsc |
| `unsloth.sh` | Unsloth | Fine-tuning toolkit |
| `signal.sh` | Signal messenger | Bot integration |
| `telegram.sh` | Telegram bot | Bot integration |
| `tailscale.sh` | Tailscale VPN | Mesh networking |
| `duplicati.sh` | Duplicati backup | Backup automation |
| `timeshift.sh` | Timeshift snapshots | System restore points |

## What good looks like

- One file per service — no multi-service scripts
- Filename matches the service name (lowercase, kebab-case)
- Can run standalone (`./scripts/components/ollama.sh`) or be sourced by bundles
- Functions follow `{service}_install`, `{service}_start`, `{service}_stop`, `{service}_health` pattern
- All components source `lib/common.sh` for consistent logging and environment

## Tools and skills

- **Docker Compose** — Most services managed via `lib/compose.sh` wrappers
- **Bash** — Script language for all components
- **curl** — Health checks via `lib/health.sh`
