# CrewAI Component — REFERENCES

## Official

- Docs: https://docs.crewai.com
- Installation: https://docs.crewai.com/en/installation
- Introduction: https://docs.crewai.com/en/introduction
- GitHub: https://github.com/crewAIInc/crewAI
- PyPI: https://pypi.org/project/crewai/

## uv (package manager)

- Docs: https://docs.astral.sh/uv/
- Install: https://astral.sh/uv/install.sh

## Integration guides

- Ollama integration: https://docs.crewai.com/en/how-to/llm-connections
- Custom LLM endpoints (OpenAI-compatible): set OPENAI_API_BASE in project .env

## Related components in this stack

- llama-swap: https://github.com/mostlygeek/llama-swap (preferred backend)
- deerflow: https://github.com/bytedance/deer-flow (alternative orchestrator)
- flowise: https://flowiseai.com (visual LLM chain builder)
