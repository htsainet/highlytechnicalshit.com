# Component Usage

Run the component script with `--help` to see the supported commands.

Common command patterns (may vary per component):
- `--install` – Install the service.
- `--configure` – Apply configuration.
- `--start` – Start the service.
- `--stop` – Stop the service.
- `--restart` – Restart the service.
- `--health` – Run a health check.
- `--status` – Show status information.
- `--destroy` – Remove containers and volumes.

Refer to the script's help output for the full list.
