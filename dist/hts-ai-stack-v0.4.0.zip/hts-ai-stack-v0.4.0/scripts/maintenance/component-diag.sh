#!/usr/bin/env bash
# scripts/maintenance/component-diag.sh — Generic per-component diagnostic
# dumper. Given a component id (the directory name under
# `scripts/components/`), locate its compose service via the manifest and
# emit:
#
#   1. container inspect (status, exit code, OOM, restart count, health)
#   2. last healthcheck log (if any)
#   3. last 300 lines of container logs
#   4. host port bind check (if the manifest declares dashboard.port)
#   5. compose config for that service (resolved)
#
# Usage:
#   ./scripts/maintenance/component-diag.sh <component-id> [--save]
#   ./scripts/maintenance/component-diag.sh nemoclaw open-llm-vtuber --save
#
# Multiple component ids may be passed; a shared --save flag will tee each
# component's output into `logs/<id>-diag-<timestamp>.log`.
#
# Read-only. Never starts, stops, or rebuilds anything.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/common.sh" 2>/dev/null || true
[[ -f "$REPO_DIR/.env" ]] && set -a && . "$REPO_DIR/.env" && set +a || true

SAVE=false
IDS=()
for arg in "$@"; do
  case "$arg" in
    --save) SAVE=true ;;
    -*)     printf '[diag] unknown flag: %s\n' "$arg" >&2; exit 2 ;;
    *)      IDS+=("$arg") ;;
  esac
done

if [[ ${#IDS[@]} -eq 0 ]]; then
  printf 'Usage: %s <component-id> [<component-id>...] [--save]\n' "$0" >&2
  exit 2
fi

_section() {
  printf '\n── %s ──────────────────────────────────────────────────\n' "$1"
}

_run() {
  local label="$1"; shift
  _section "$label"
  "$@" 2>&1 || printf '[diag] command failed (exit %d): %s\n' "$?" "$*"
}

diag_one() {
  local id="$1"
  local manifest="$REPO_DIR/scripts/components/$id/$id.manifest.json"
  printf '\n╔══ %s ═════════════════════════════════════════════════════════════╗\n' "$id"
  printf 'manifest: %s\n' "$manifest"

  if [[ ! -f "$manifest" ]]; then
    printf '[diag] no manifest found — aborting for %s\n' "$id"
    return
  fi

  # Prefer an explicit `container_name` hint from the manifest if someone
  # has added one, otherwise assume the convention used throughout this
  # repo: the compose service name equals the component id, and its
  # container_name is `hts-ai-<id>`.
  local svc container port
  svc=$(jq -r '.compose_service // .id' "$manifest")
  container=$(jq -r '.container_name // empty' "$manifest")
  [[ -z "$container" ]] && container="hts-ai-${id}"
  port=$(jq -r '.dashboard.port // empty' "$manifest")
  printf 'service: %s   container: %s   port: %s\n' "$svc" "$container" "${port:-<none>}"

  _run "container inspect" docker inspect "$container" \
    --format 'status={{.State.Status}} running={{.State.Running}} exit={{.State.ExitCode}} oom={{.State.OOMKilled}} restarts={{.RestartCount}} started={{.State.StartedAt}} finished={{.State.FinishedAt}}
error={{.State.Error}}
health={{if .State.Health}}{{.State.Health.Status}} failing={{.State.Health.FailingStreak}}{{else}}<no healthcheck state>{{end}}
image={{.Config.Image}}
cmd={{join .Config.Cmd " "}}'

  _run "last healthcheck log" bash -c \
    "docker inspect '$container' --format '{{if .State.Health}}{{range .State.Health.Log}}--- exit={{.ExitCode}} @ {{.Start}} ---
{{.Output}}
{{end}}{{end}}' 2>/dev/null | tail -80"

  _run "container logs (tail 300)" docker logs --tail 300 "$container"

  _run "compose config ($svc)" bash -c \
    "cd '$REPO_DIR' && docker compose config '$svc' 2>&1 || docker compose --profile '*' config '$svc'"

  if [[ -n "$port" ]]; then
    _run "port bind :$port" bash -c \
      "ss -tlnp 2>/dev/null | grep -E ':${port}\\b' || echo 'no listener on :${port}'"
  fi

  printf '\n╚══ end %s ═════════════════════════════════════════════════════════╝\n' "$id"
}

main() {
  printf '==== component diagnostics — %s ====\n' "$(date -Iseconds)"
  _run "docker version" docker version --format 'client={{.Client.Version}} server={{.Server.Version}}'
  for id in "${IDS[@]}"; do
    if [[ "$SAVE" == "true" ]]; then
      mkdir -p "$REPO_DIR/logs"
      local out="$REPO_DIR/logs/${id}-diag-$(date +%Y%m%d-%H%M%S).log"
      diag_one "$id" | tee "$out"
      printf '[diag] saved %s → %s\n' "$id" "$out"
    else
      diag_one "$id"
    fi
  done
  printf '\n==== end ====\n'
}

main
