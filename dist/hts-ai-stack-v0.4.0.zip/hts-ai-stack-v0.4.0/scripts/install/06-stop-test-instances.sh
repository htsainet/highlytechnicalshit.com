#!/usr/bin/env bash
# 06-stop-test-instances.sh — Stop test-only containers
#
# Stops containers with the "test" role label, leaving production services
# running.  In single-instance mode (no prod/test split) this is a no-op.
#
# NemoClaw sandboxes are managed separately by the nemoclaw CLI.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

source "$REPO_DIR/scripts/lib/common.sh"

echo ""
step "Stopping test instances"

# Stop containers labelled as test instances
TEST_CONTAINERS=$(docker ps -q --filter "label=com.htsai.instance=test" 2>/dev/null || true)

if [[ -z "$TEST_CONTAINERS" ]]; then
  info "No test-instance containers running — nothing to stop."
else
  echo "$TEST_CONTAINERS" | xargs docker stop
  ok "Test instances stopped."
fi

# Also stop any instance-based test compose if it exists
TEST_COMPOSE="$REPO_DIR/instances/test/docker-compose.yml"
if [[ -f "$TEST_COMPOSE" ]]; then
  docker compose -f "$TEST_COMPOSE" stop 2>/dev/null || true
  ok "Test compose stack stopped."
fi

echo ""
echo "Done."
