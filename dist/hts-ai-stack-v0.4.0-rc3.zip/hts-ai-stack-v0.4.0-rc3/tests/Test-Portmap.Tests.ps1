BeforeDiscovery {
    $script:RepoRoot = (git -C $PSScriptRoot rev-parse --show-toplevel 2>$null) ??
                       (Split-Path $PSScriptRoot)
    $script:PortmapPath = Join-Path $script:RepoRoot 'config/portmap.json'
    $script:Portmap = Get-Content $script:PortmapPath -Raw | ConvertFrom-Json

    # Build lookup of manifest ports keyed by service id
    $script:ManifestPorts = @{}
    Get-ChildItem (Join-Path $script:RepoRoot 'scripts/components') -Filter '*.manifest.json' -Recurse |
        ForEach-Object {
            $m = Get-Content $_.FullName -Raw | ConvertFrom-Json
            $dash = $m.dashboard
            if ($dash -and $dash.port) {
                $script:ManifestPorts[$m.id] = [int]$dash.port
            }
        }
}

Describe 'Port Map Validation' {

    Context 'portmap.json structure' {

        It 'portmap.json exists' {
            $script:PortmapPath | Should -Exist
        }

        It 'is valid JSON with a ports object' {
            $script:Portmap.ports | Should -Not -BeNullOrEmpty
        }

        It 'every port entry has required fields' {
            $entries = $script:Portmap.ports.PSObject.Properties
            foreach ($entry in $entries) {
                $port = $entry.Name
                $val  = $entry.Value
                $val.service | Should -Not -BeNullOrEmpty -Because "port $port needs a service"
                $val.internal | Should -Not -BeNullOrEmpty -Because "port $port needs an internal port"
                $val.scope | Should -BeIn @('compose','host-native','instance') -Because "port $port needs a valid scope"
                $val.desc | Should -Not -BeNullOrEmpty -Because "port $port needs a description"
            }
        }

        It 'all port keys are valid integers' {
            $entries = $script:Portmap.ports.PSObject.Properties
            foreach ($entry in $entries) {
                { [int]$entry.Name } | Should -Not -Throw -Because "'$($entry.Name)' should be numeric"
            }
        }
    }

    Context 'no host port collisions' {

        It 'no duplicate host ports in main ports section' {
            $ports = $script:Portmap.ports.PSObject.Properties.Name
            $unique = $ports | Select-Object -Unique
            $ports.Count | Should -Be $unique.Count -Because 'host ports must be unique'
        }

        It 'instance ports do not collide within the same instance' {
            foreach ($inst in $script:Portmap.instances.PSObject.Properties) {
                $name  = $inst.Name
                $ports = $inst.Value.PSObject.Properties.Name
                $unique = $ports | Select-Object -Unique
                $ports.Count | Should -Be $unique.Count -Because "instance '$name' ports must be unique"
            }
        }
    }

    Context 'manifest port consistency' {

        It 'every manifest port matches portmap.json' {
            foreach ($svcId in $script:ManifestPorts.Keys) {
                $manifestPort = $script:ManifestPorts[$svcId]
                # Find ALL portmap entries for this service
                $matches = $script:Portmap.ports.PSObject.Properties |
                    Where-Object { $_.Value.service -eq $svcId }
                $matches | Should -Not -BeNullOrEmpty -Because "service '$svcId' with manifest port $manifestPort should be in portmap.json"
                $matchedPorts = $matches | ForEach-Object { [int]$_.Name }
                $matchedPorts | Should -Contain $manifestPort -Because "portmap should include manifest port $manifestPort for '$svcId'"
            }
        }
    }

    Context 'reserved ports are not allocated' {

        It 'reserved ports are not used in the main ports section' {
            $reserved = $script:Portmap.reserved.PSObject.Properties.Name
            $allocated = $script:Portmap.ports.PSObject.Properties.Name
            foreach ($rp in $reserved) {
                $rp | Should -Not -BeIn $allocated -Because "port $rp is reserved: $($script:Portmap.reserved.$rp)"
            }
        }
    }

    Context 'REFERENCES.md port map consistency' {

        BeforeAll {
            $script:ReferencesContent = Get-Content (Join-Path $script:RepoRoot 'REFERENCES.md') -Raw
        }

        It 'every portmap.json main port appears in REFERENCES.md' {
            $entries = $script:Portmap.ports.PSObject.Properties
            foreach ($entry in $entries) {
                $port = $entry.Name
                $script:ReferencesContent | Should -Match $port -Because "port $port ($($entry.Value.desc)) should be documented in REFERENCES.md"
            }
        }
    }

    Context 'docker-compose.yml consistency' {

        BeforeAll {
            $script:ComposeContent = Get-Content (Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
        }

        It 'compose-scoped ports appear in docker-compose.yml' {
            $composeEntries = $script:Portmap.ports.PSObject.Properties |
                Where-Object { $_.Value.scope -eq 'compose' }
            foreach ($entry in $composeEntries) {
                $hostPort = $entry.Name
                $internal = $entry.Value.internal
                # Check for the port mapping pattern (host:internal or env-var form)
                $pattern = "$hostPort|$($entry.Value.env)"
                $script:ComposeContent | Should -Match $pattern -Because "port $hostPort ($($entry.Value.desc)) should appear in docker-compose.yml"
            }
        }
    }

    Context 'no service uses port 0 or negative' {

        It 'all ports are positive integers in valid range' {
            $entries = $script:Portmap.ports.PSObject.Properties
            foreach ($entry in $entries) {
                $port = [int]$entry.Name
                $port | Should -BeGreaterThan 0
                $port | Should -BeLessOrEqual 65535
                $internal = [int]$entry.Value.internal
                $internal | Should -BeGreaterThan 0
                $internal | Should -BeLessOrEqual 65535
            }
        }
    }
}
