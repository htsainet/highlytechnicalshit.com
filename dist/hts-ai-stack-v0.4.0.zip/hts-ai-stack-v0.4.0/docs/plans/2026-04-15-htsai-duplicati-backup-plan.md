# HTS-AI-Stack — Duplicati Backup Setup Plan

Created: 2026-04-15
Duplicati UI: http://localhost:8200

---

## Overview

Duplicati is a web-based backup tool already in the stack as an optional Docker
service (profile: `duplicati`). It provides encrypted, incremental, scheduled
backups with deduplication. It's NOT a bare-metal restore tool — that's Timeshift.

### Backup layer architecture

```text
┌─────────────────────────────────────────────────────────────────┐
│                    BACKUP STRATEGY                               │
├─────────────────┬───────────────────┬───────────────────────────┤
│ Layer           │ Tool              │ What it protects           │
├─────────────────┼───────────────────┼───────────────────────────┤
│ Bare-metal OS   │ Timeshift         │ System files, packages,   │
│ restore         │ → htsai-timeshift │ /etc, boot config         │
│                 │   -backup (NAS)   │ Full OS rollback           │
├─────────────────┼───────────────────┼───────────────────────────┤
│ Docker model    │ backup-models.sh  │ Ollama weights, SD        │
│ weights         │ → htsai-model     │ checkpoints, ComfyUI      │
│ (large, rsync)  │   -backup (NAS)   │ models — re-downloadable  │
├─────────────────┼───────────────────┼───────────────────────────┤
│ Docker volumes  │ backup-volumes.sh │ Chat history, workflows,  │
│ (stateful data) │ → htsai-docker    │ user accounts, git repos  │
│                 │   -volume (NAS)   │ — IRREPLACEABLE            │
├─────────────────┼───────────────────┼───────────────────────────┤
│ File-level      │ Duplicati         │ Stack configs, user home,  │
│ encrypted       │ → NAS or cloud    │ scripts, any host files    │
│ incremental     │                   │ Versioned, encrypted,      │
│                 │                   │ deduplicated               │
├─────────────────┼───────────────────┼───────────────────────────┤
│ Config snapshot │ backup-configs.sh │ .env, stack.json, fstab,  │
│ (lightweight)   │ → htsai-docker    │ daemon.json, nas.env       │
│                 │   -volume (NAS)   │ Quick restore reference    │
└─────────────────┴───────────────────┴───────────────────────────┘
```

**Why Duplicati on top of the others?**

- Encrypted (the others are plaintext on NAS)
- Versioned (keep N versions, roll back to any point)
- Deduplicated (only stores changed blocks)
- Can target cloud storage (S3, B2, Google Drive) as offsite backup
- Has a web UI for monitoring and restore
- Covers files the other tools miss (user home, custom scripts, etc.)

---

## TASK 1: Enable Duplicati Service

### Step 1: Add to .env or start with profile

```bash
# Option A: Start manually
docker compose --profile duplicati up -d duplicati

# Option B: Add to default profile in .env
# Add DUPLICATI_ENABLED=true and wire it in compose
```

### Step 2: Verify it's running

```bash
docker ps | grep duplicati
curl -s http://localhost:8200/  # should return Duplicati web UI
```

### Step 3: Access the web UI

Open `http://<host-ip>:8200` in a browser.

---

## TASK 2: Configure Backup Jobs in Duplicati UI

Duplicati mounts the entire host as `/source:ro` inside the container.
The backup destination volume is at `/backups` inside the container.

### Recommended backup jobs

#### Job 1: "Stack Configs" (daily, lightweight)

```text
Source:      /source/home/<user>/hts/hts-ai-stack/.env
             /source/home/<user>/hts/hts-ai-stack/config/
             /source/home/<user>/hts/hts-ai-stack/.last-applied.json
             /source/home/<user>/hts/hts-ai-stack/docker-compose.override.yml
             /source/etc/docker/daemon.json
             /source/etc/fstab
             /source/etc/idmapd.conf
             /source/home/<user>/.config/htsai/
Destination: /backups/stack-configs/
             OR NAS path: /source/mnt/htsai-docker-volume-backup/duplicati/stack-configs/
Schedule:    Daily at 2:00 AM
Retention:   Keep last 30 versions
Encryption:  AES-256 (set a passphrase you won't forget!)
```

#### Job 2: "User Home" (daily, medium)

```text
Source:      /source/home/<user>/
Exclude:     /source/home/<user>/hts/           (repo is in git)
             /source/home/<user>/.cache/
             /source/home/<user>/snap/
             /source/home/<user>/.local/share/Trash/
             *.tmp
             *.log
Destination: NAS: /source/mnt/htsai-docker-volume-backup/duplicati/user-home/
Schedule:    Daily at 3:00 AM
Retention:   Keep last 14 versions
Encryption:  AES-256
```

#### Job 3: "Docker Volumes — Stateful" (weekly, larger)

```text
Source:      /source/var/lib/docker/volumes/hts-ai-stack_open_webui_data/
             /source/var/lib/docker/volumes/hts-ai-stack_gitea_data/
             /source/var/lib/docker/volumes/hts-ai-stack_sillytavern_data/
             /source/var/lib/docker/volumes/hts-ai-stack_sillytavern_config/
             /source/var/lib/docker/volumes/hts-ai-stack_n8n_data/
             /source/var/lib/docker/volumes/hts-ai-stack_flowise_data/
             /source/var/lib/docker/volumes/hts-ai-stack_langflow_data/
             /source/var/lib/docker/volumes/hts-ai-stack_grafana_data/
             /source/var/lib/docker/volumes/hts-ai-stack_sd_outputs/
             /source/var/lib/docker/volumes/hts-ai-stack_comfyui_output/
             /source/var/lib/docker/volumes/hts-ai-stack_comfyui_custom_nodes/
Destination: NAS: /source/mnt/htsai-docker-volume-backup/duplicati/docker-volumes/
Schedule:    Weekly, Sunday at 1:00 AM
Retention:   Keep last 4 versions
Encryption:  AES-256
```

NOTE: This overlaps with `backup-volumes.sh` (which does pause/tar).
Duplicati adds versioning + encryption + dedup on top. The tar approach
is simpler for quick restore; Duplicati is the "belt AND suspenders" layer.

#### Job 4: "Offsite Cloud Backup" (optional, weekly)

```text
Source:      Same as Job 1 (configs) + key volumes
Destination: Backblaze B2, AWS S3, Google Drive, etc.
Schedule:    Weekly
Retention:   Keep last 8 versions
Encryption:  AES-256 (CRITICAL for cloud — data leaves your network)
```

---

## TASK 3: Create Dedicated NAS Share for Duplicati

### Why a separate share?

- Duplicati backups are versioned + encrypted — can grow large independently
- Separate Synology quota and space alerts per share
- Independent retention policies (Duplicati manages its own)
- Clean separation: each NAS share has exactly one purpose

### NAS shares (complete list)

```text
htsai-model-backup          → /mnt/htsai-model-backup           (rsync model weights)
htsai-docker-volume-backup  → /mnt/htsai-docker-volume-backup   (tar'd volume snapshots + configs)
htsai-timeshift-backup      → /mnt/htsai-timeshift-backup       (Timeshift OS snapshots)
htsai-duplicati-backup      → /mnt/htsai-duplicati-backup       (Duplicati encrypted incremental) ← NEW
```

### Synology setup

1. **Control Panel → Shared Folder → Create**
   - Name: `htsai-duplicati-backup`
   - Location: Volume 1
2. **Edit → NFS Permissions → Create**
   - Hostname/IP: `192.168.77.152` (your host)
   - Privilege: Read/Write
   - Squash: Map root to admin
   - Async: Yes
   - Non-privileged port: Allowed
   - Cross-mount: Allowed
   - Security: sys

### Update nas-setup.sh

Add `htsai-duplicati-backup` to the NFS share list alongside the existing 3.
Add corresponding env vars:

```bash
NAS_DUPLICATI_SHARE="/volume1/htsai-duplicati-backup"
NAS_DUPLICATI_MOUNT="/mnt/htsai-duplicati-backup"
```

### Update docker-compose.yml

Mount the NAS share into the Duplicati container:

```yaml
duplicati:
  volumes:
    - duplicati_config:/config
    - duplicati_backups:/backups
    - /:/source:ro
    - /mnt/htsai-duplicati-backup:/nas-backup    # ← dedicated NAS share
```

### Update stack.json

Add `duplicati_backup` to the NAS `uses` array and share/mount mappings.

### Update nas.sh

Add fstab entry for the 4th mount:

```text
<nas>:/volume1/htsai-duplicati-backup /mnt/htsai-duplicati-backup nfs4 ...
```

---

## TASK 4: Point Duplicati Backups at NAS

### Option A: Use dedicated NFS mount (recommended — see Task 3)

With the dedicated share mounted, Duplicati writes to `/nas-backup/` inside
the container, which maps to `/mnt/htsai-duplicati-backup` on the host.

### Option B: Use Duplicati's built-in S3/SFTP/SMB targets

Duplicati natively supports remote storage backends:

- **SFTP** to Synology (recommended if NFS isn't reliable)
- **SMB/CIFS** to Synology share
- **S3-compatible** (Synology supports MinIO/S3)

Configure in the Duplicati web UI under destination settings.

---

## TASK 5: Automate Duplicati Setup (Optional)

### Script: `scripts/components/duplicati/configure-jobs.sh`

Duplicati has a CLI and API. Backup job configs are JSON files stored in
`/config/` inside the container. You could:

1. Create job config JSON templates in the repo
2. Script copies them into the `duplicati_config` volume
3. Jobs auto-appear in the web UI

**Alternative:** Just document the manual setup (Tasks 2+3) and let users
configure via the web UI. Duplicati's UI is user-friendly and most people
prefer to set their own encryption passphrase interactively.

**Recommendation:** Document manual setup. Only automate if you're deploying
multiple hosts. The web UI at port 8200 is the intended workflow.

---

## TASK 6: Document in CONTEXT.md

Add to the backup strategy documentation:

```markdown
### Backup Layers

| Layer | Tool | Target | Schedule | What |
|---|---|---|---|---|
| OS restore | Timeshift | htsai-timeshift-backup | Daily | Full OS rollback |
| Model weights | backup-models.sh | htsai-model-backup | On-demand | Ollama, SD, ComfyUI weights |
| Docker state | backup-volumes.sh | htsai-docker-volume-backup | Weekly | Chat history, workflows, git |
| Config snapshot | backup-configs.sh | htsai-docker-volume-backup | Daily | .env, stack.json, fstab |
| Encrypted incremental | Duplicati | NAS or cloud | Daily/Weekly | Everything above + versioning |
```

---

## Key Technical Notes

### Duplicati container access

- Mounts entire host as `/source:ro` — can see everything but can't modify
- `/config` volume stores Duplicati's own database + job configs
- `/backups` volume is the default local backup destination
- Web UI on port 8200 (configurable via DUPLICATI_PORT in .env)

### Encryption

- Duplicati encrypts backup data client-side before writing to destination
- **STORE YOUR PASSPHRASE SAFELY** — without it, backups are unrecoverable
- Consider storing passphrase in `~/.config/htsai/duplicati-passphrase.txt`
  (chmod 600) or a password manager

### Restore from Duplicati

- Use the web UI: Restore → pick backup job → pick version → select files
- Or CLI: `duplicati-cli restore <backup-url> --passphrase=...`
- Can restore individual files or entire directories

### Duplicati vs backup-volumes.sh

| Feature | backup-volumes.sh | Duplicati |
|---|---|---|
| Speed | Fast (tar) | Slower (dedup + encrypt) |
| Versioning | Manual (timestamped tars) | Automatic (N versions) |
| Encryption | No | AES-256 |
| Deduplication | No | Yes (block-level) |
| Restore UX | Manual tar extract | Web UI file picker |
| Cloud targets | No | Yes (S3, B2, GDrive, etc.) |
| Consistency | Pauses containers | Reads live (slight risk) |

**They're complementary**, not competing. Use both:

- `backup-volumes.sh` for quick, consistent snapshots (maintenance windows)
- Duplicati for ongoing versioned encrypted backup (daily/weekly)

### Synology ActiveProtect

Your NAS may also support Synology's own backup tools (ActiveProtect, Hyper Backup).
These can back up the NAS shares themselves to another NAS or cloud — giving you
a third copy (3-2-1 backup rule: 3 copies, 2 media types, 1 offsite).

---

## Priority Order

1. **Task 1** — Enable Duplicati (5 min)
2. **Task 3** — Create NAS share + NFS mount + compose mount (15 min)
3. **Task 2** — Configure backup jobs in web UI (15-30 min)
4. **Task 4** — Verify NAS destination works
5. **Task 6** — Document in CONTEXT.md
6. **Task 5** — Automate setup (optional, low priority)
