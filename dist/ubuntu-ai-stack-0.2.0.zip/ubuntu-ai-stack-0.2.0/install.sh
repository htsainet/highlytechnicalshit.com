#!/usr/bin/env bash
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; exit 1; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

ensure_env_var_set() {
  local env_file="$1"
  local key="$2"

  if [ ! -f "$env_file" ]; then
    fail "$env_file is missing. Run ./01-autoinstall.sh first."
  fi

  if ! grep -Eq "^${key}=[^[:space:]].*" "$env_file"; then
    fail "${key} is missing or empty in $env_file. Run ./01-autoinstall.sh to repair tokens."
  fi
}

# Try to read clone path saved by 00-bootstrap.sh, fall back to default
REPO_CONFIG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/ubuntu-ai-stack"
if [ -f "$REPO_CONFIG_DIR/clone-path" ]; then
  REPO_DIR=$(cat "$REPO_CONFIG_DIR/clone-path")
else
  REPO_DIR="$HOME/github/ubuntu-ai-stack"
fi

# Verify the repo exists
if [ ! -d "$REPO_DIR" ]; then
  fail "Repo directory not found: $REPO_DIR"
fi

SCRIPTS=(
  "$REPO_DIR/01-autoinstall.sh"
  "$REPO_DIR/02-setup-docker.sh"
  "$REPO_DIR/03-setup-models.sh"
  "$REPO_DIR/04-setup-nemoclaw.sh"
  "$REPO_DIR/06-start-stack.sh"
  "$REPO_DIR/07-setup-connectivity.sh"
)

step "Sequential Installation"
info "Running steps 01-07 (05 skipped — not implemented)"

for script in "${SCRIPTS[@]}"; do
  if [ ! -f "$script" ]; then
    fail "Missing: $script"
  fi

  if [ "$(basename "$script")" = "02-setup-docker.sh" ]; then
    ENV_FILE="$REPO_DIR/.env"
    step "Preflight — Validate .env tokens"
    ensure_env_var_set "$ENV_FILE" "WEBUI_SECRET_KEY"
    ensure_env_var_set "$ENV_FILE" "OPENCLAW_TOKEN"
    info ".env tokens are present."
  fi

  step "Running: $script"
  if bash "$script"; then
    info "Completed: $script"
  else
    rc=$?
    if [ "$rc" -gt 128 ]; then
      sig=$((rc - 128))
      echo -e "${RED}[FAIL]${NC} Script terminated by signal ${sig}: $script (exit ${rc})"
    else
      echo -e "${RED}[FAIL]${NC} Script failed with exit code ${rc}: $script"
    fi
    exit "$rc"
  fi
done

echo ""
info "All installation steps completed successfully!"
echo ""
step "What's Next?"
info "Your AI stack is now deployed. Here are your next steps:"
echo ""
echo "  1. View the dashboard:"
echo "     → http://localhost:5173"
echo ""
echo "  2. Set up git hooks (optional):"
echo "     → pwsh -NoLogo -NoProfile -File $REPO_DIR/tests/Install-GitHooks.ps1"
echo ""
echo "  3. Monitor logs:"
echo "     → docker compose -f $REPO_DIR/docker-compose.yml logs -f"
echo ""
echo "  4. Check service status:"
echo "     → docker compose -f $REPO_DIR/docker-compose.yml ps"
echo ""
echo "  For more info, see: $REPO_DIR/README.md"
echo ""
