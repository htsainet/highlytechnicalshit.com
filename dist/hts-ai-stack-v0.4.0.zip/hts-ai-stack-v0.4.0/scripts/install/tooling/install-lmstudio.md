# install-lmstudio.sh — LM Studio

LM Studio is a desktop GUI for running GGUF models locally. This script
downloads and installs LM Studio, bootstraps the CLI (`lms`), and pulls a
curated set of models.

---

## Automated Install

The setup wizard (`install.sh`) offers to install LM Studio during the
full-stack pipeline. Select **Yes** at the "Install LM Studio" prompt and
the installer runs this script automatically.

The deb package is installed unattended, but LM Studio is a desktop GUI app
and must be **launched once** before the `lms` CLI can bootstrap. If the
installer detects that the GUI hasn't run yet, it installs the `.deb` and
skips the CLI bootstrap + model pulls. After the install finishes:

1. Open **LM Studio** from your desktop application menu
2. Let it finish initial setup
3. Re-run the script to bootstrap the CLI and pull models:

   ```bash
   bash scripts/install/tooling/install-lmstudio.sh
   ```

If LM Studio is already installed the wizard detects the `lmstudio` deb
package and skips the install offer.

---

## What It Does

1. Downloads LM Studio `.deb` from the official installer CDN
2. Installs it with `dpkg` and fixes any missing dependencies
3. Runs `lms bootstrap` to initialize `~/.lmstudio` and the `lms` CLI
4. No models are pulled by default — use `lms get <url> -y` to pull models manually.

---

## Prerequisites

- Ubuntu 24.04 desktop (LM Studio requires a display)
- NVIDIA GPU with drivers installed (see `00-bootstrap.sh` step 13)
- `wget` available

---

## Usage

```bash
bash install-lmstudio.sh
```

> This script has no `set -e` guard — steps can partially fail without aborting.
> Check output manually if a model pull fails.

---

## Notes

- LM Studio also runs a local OpenAI-compatible server on port **1234** (when
  started from the GUI under the Local Server tab).
- Models are stored in `~/.lmstudio/models/`.
- `lms` CLI can be used headlessly after bootstrap:

  ```bash
  lms server start
  lms ls
  ```
