---
name: stable-diffusion
description: Generate images from text prompts using the local Stable Diffusion WebUI
metadata:
  openclaw:
    emoji: 🎨
    requires:
      bins: ["curl", "base64"]
---

# Stable Diffusion Image Generation

Use this skill when the user asks to generate, create, or draw an image.

The Stable Diffusion API is available at `http://stable-diffusion:7860`.

## Generating an image

```bash
curl -s -X POST http://stable-diffusion:7860/sdapi/v1/txt2img \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "PROMPT_HERE",
    "negative_prompt": "ugly, blurry, low quality, watermark",
    "steps": 25,
    "cfg_scale": 7,
    "sampler_name": "DPM++ 2M Karras",
    "width": 512,
    "height": 512,
    "seed": -1
  }' | jq -r '.images[0]' | base64 -d > /tmp/output.png
```

Replace `PROMPT_HERE` with the user's description. After generating, tell the user the image was saved to `/tmp/output.png` and show the canvas if available.

## Tips

- Default size is 512×512. Use 768×512 for landscape, 512×768 for portrait.
- For photorealistic results add: `photorealistic, 8k, detailed`
- For anime style add: `anime, illustration, detailed linework`
- Available checkpoints can be listed with:

  ```bash
  curl -s http://stable-diffusion:7860/sdapi/v1/sd-models | jq '.[].title'
  ```

- Switch checkpoint with:

  ```bash
  curl -s -X POST http://stable-diffusion:7860/sdapi/v1/options \
    -H "Content-Type: application/json" \
    -d '{"sd_model_checkpoint": "MODEL_NAME_HERE"}'
  ```
