$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/timeshift'
    $script:ComponentScript = Join-Path $script:ComponentDir 'timeshift.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'timeshift.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'timeshift file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists (TDD — needs creation)' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'timeshift component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines timeshift_install function' {
        $script:ComponentContent | Should -Match 'timeshift_install\s*\(\)'
    }

    It 'defines timeshift_configure function' {
        $script:ComponentContent | Should -Match 'timeshift_configure\s*\(\)'
    }

    It 'defines timeshift_start function' {
        $script:ComponentContent | Should -Match 'timeshift_start\s*\(\)'
    }

    It 'defines timeshift_stop function' {
        $script:ComponentContent | Should -Match 'timeshift_stop\s*\(\)'
    }

    It 'defines timeshift_health function' {
        $script:ComponentContent | Should -Match 'timeshift_health\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/timeshift/timeshift\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'timeshift no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/timeshift\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/timeshift/timeshift\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
