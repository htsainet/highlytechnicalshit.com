# Feature Request: Model Selection Checklist (Option B)

**Status:** Planned  
**Priority:** Medium  
**Related:** #synology-onboarding

## Summary

Currently users can only choose between:
- "Download all production models" (50GB+)
- "Download only the default model" (~5-10GB)

This feature would allow granular model selection via a checklist during setup, so users can pick exactly which models they want without using the command line.

## Current Behavior

In `config/wizard/ai_stack_setup.sh`, the user:
1. Selects backend (Ollama, BitNet)
2. Selects a single default model
3. Wizard asks: "Download all models?" → Yes/No

If yes, `scripts/install/models/prod.sh` pulls all hardcoded models from `OLLAMA_MODELS_PROD[]`.

## Proposed Behavior

**New Step 2b (after default model selection):**

```
┌─────────────────────────────────────────────┐
│  Select Production Models to Download       │
│                                             │
│  ☑ smollm2:135m (500MB VRAM)                │
│  ☑ mistral-nemo:latest (8GB VRAM) [default]│
│  ☐ deepseek-r1:14b (9GB VRAM)               │
│  ☐ phi4:14b (12GB VRAM)                     │
│                                             │
│           [ OK ]    [ Cancel ]              │
└─────────────────────────────────────────────┘
```

Features:
- Checklist with model names + VRAM requirements
- Default model pre-selected
- Can uncheck "all but default" to minimize disk usage
- Can select all for comprehensive library
- Shows estimated sizes/requirements
- "Quick presets" option: Minimal / Balanced / Full

## Implementation

### Files to Modify

1. **`config/wizard/ai_stack_setup.sh`** — Add model checklist logic
   - Parse `OLLAMA_MODELS_PROD` array
   - Build whiptail checklist dynamically
   - Export selected models as `PULL_SELECTED_MODELS` (space-separated list)

2. **`config/wizard/ai_stack_setup.sh` (Python config)** — Save selection
   - Add `"selected_models"` to stack.json under `"backend"` section

3. **`config/wizard/apply_config.sh`** — Write to .env
   - Export `PULL_SELECTED_MODELS=<space-separated-list>`

4. **`scripts/install/models/prod.sh`** — Use selection
   - Replace hardcoded `OLLAMA_MODELS_PROD[]` loop with selected list
   - If `PULL_SELECTED_MODELS` is set, only pull those; else pull all

5. **`scripts/install/models/test.sh`** — Same as prod

### Backward Compatibility

- If `PULL_SELECTED_MODELS` is empty or unset, fall back to default behavior (PULL_ALL_MODELS)
- Existing configs without the new field continue to work

### Metadata to Display

For each model, display:
- **Name** (e.g., `mistral-nemo:latest`)
- **Size** (e.g., `7B parameters`, `~5GB disk`)
- **VRAM requirements** (e.g., `8GB VRAM`)
- **Description** (e.g., "Balanced chat — general purpose")

Example metadata structure (could go in `instances/prod/models.sh`):
```bash
declare -A OLLAMA_MODELS_META=(
  ["smollm2:135m"]="135M|500MB|Lightweight sidecar"
  ["mistral-nemo:latest"]="7B|5GB|General chat (DEFAULT)"
  ["deepseek-r1:14b"]="14B|10GB|Chain-of-thought reasoning"
  ["phi4:14b"]="14B|12GB|Reasoning + structured output"
)
```

## Benefits

- **Disk space conscious** — Users can avoid downloading huge models they won't use
- **Faster initial setup** — Minimal config takes 10 min instead of 1 hour
- **Clearer choices** — See VRAM/disk tradeoffs upfront
- **Still flexible** — Users can add models later via manual `ollama pull`

## Design Considerations

- **Whiptail complexity** — whiptail checklist can only show ~10-15 items; if list grows, consider menu/selection approach
- **Model metadata** — Need to maintain sizes and descriptions; keep in sync with actual models
- **Test models** — Same UI for test models? (probably yes, but test is optional)

## Testing

- [ ] Checklist renders correctly
- [ ] Pre-selection of default works
- [ ] Can deselect all (edge case)
- [ ] Env var exports correctly
- [ ] Scripts honor selection
- [ ] Backward compat: old configs still work

## Out of Scope

- Model search/filtering (future)
- Custom model URLs (future)
- Automatic model removal (dangerous, skip for now)
