#!/usr/bin/env bash
# upstream-watch.sh — Daily cron script to check tracked upstream issues
# and append status changes to logs/upstream-watch.log
#
# Usage:  ./scripts/utils/upstream-watch.sh
# Cron:   0 8 * * * /home/<user>/hts/hts-ai-stack/scripts/utils/upstream-watch.sh
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
LOG_FILE="${REPO_ROOT}/logs/upstream-watch.log"

# ── Tracked issues ──────────────────────────────────────────────────────
# Add entries as: "OWNER/REPO ISSUE_NUMBER DESCRIPTION"
# Corresponding .md files live in docs/upstream/issues/OWNER-REPO-NUMBER.md
WATCHED_ISSUES=(
  "NVIDIA/NemoClaw 1685 sandbox-base:latest stale OpenClaw version"
  "NVIDIA/NemoClaw 1640 Sandbox image missing gnupg package"
  "NVIDIA/NemoClaw 1641 nemoclaw list resurrects destroyed sandboxes"
  "NVIDIA/NemoClaw 1642 Lots of errors in openclaw log"
  "NVIDIA/NemoClaw 1686 tls: terminate deprecated in blueprints"
  "NVIDIA/NemoClaw 2689 v0.0.29 Step 17 Patch 4 fails vs OpenClaw 2026.4.24"
  "NVIDIA/NemoClaw 2686 rebuild Patch 4 literal-string assert breaks"
  "NVIDIA/NemoClaw 2740 v0.0.30 Step 51 workspace/media symlink ENOENT"
)

# ── Ensure gh is available ──────────────────────────────────────────────
if ! command -v gh &>/dev/null; then
  echo "[$(date -Iseconds)] ERROR: gh CLI not found" >> "$LOG_FILE"
  exit 1
fi

mkdir -p "$(dirname "$LOG_FILE")"

# ── Check each issue ───────────────────────────────────────────────────
for entry in "${WATCHED_ISSUES[@]}"; do
  read -r repo number desc <<< "$entry"

  result=$(gh issue view "$number" --repo "$repo" \
    --json state,title,labels,comments,updatedAt \
    --jq '{
      state: .state,
      title: .title,
      updatedAt: .updatedAt,
      labels: [.labels[].name] | join(", "),
      commentCount: (.comments | length),
      lastComment: (if (.comments | length) > 0 then .comments[-1].body[:200] else "none" end)
    }' 2>&1) || {
    echo "[$(date -Iseconds)] ERROR checking ${repo}#${number}: ${result}" >> "$LOG_FILE"
    continue
  }

  state=$(echo "$result" | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['state'])" 2>/dev/null || echo "UNKNOWN")
  updated=$(echo "$result" | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['updatedAt'])" 2>/dev/null || echo "?")
  labels=$(echo "$result" | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['labels'])" 2>/dev/null || echo "?")
  comments=$(echo "$result" | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['commentCount'])" 2>/dev/null || echo "?")
  last_comment=$(echo "$result" | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['lastComment'])" 2>/dev/null || echo "?")

  {
    echo "──────────────────────────────────────────────────"
    echo "[$(date -Iseconds)] ${repo}#${number} — ${desc}"
    echo "  State:        ${state}"
    echo "  Updated:      ${updated}"
    echo "  Labels:       ${labels}"
    echo "  Comments:     ${comments}"
    echo "  Last comment: ${last_comment}"
  } >> "$LOG_FILE"

  # Alert if the issue was closed
  if [[ "$state" == "CLOSED" ]]; then
    echo "  *** CLOSED — re-onboard sandboxes to pick up fix ***" >> "$LOG_FILE"
  fi
done
