#!/usr/bin/env bash
# preformat-safety-net.sh
#
# Captures the minimum set of host-local artifacts that Duplicati may not
# cover (or that you want a belt-and-suspenders copy of) before a full OS
# reinstall:
#
#   - config/stack.secrets.json
#   - .env
#   - Named Docker volumes that hold non-regenerable user data
#     (SillyTavern personas/chats, Open WebUI accounts/chats, flow tools, etc.)
#
# Output goes to an external destination (NAS / USB). The script refuses to
# write anywhere under the repo or $HOME to guarantee nothing lands in a
# place that could later be pushed to git.
#
# Usage:
#   DEST=/mnt/htsai-disk-image/preformat-safety-net ./preformat-safety-net.sh
#   ./preformat-safety-net.sh --dest /media/usb/preformat
#
# Requires: sudo (for reading /var/lib/docker/volumes), tar, sha256sum.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
HOST="$(hostname -s)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"

# Named docker volumes that hold user-generated data we cannot re-download.
# Excludes model/weight volumes (regenerable) and cache volumes.
CRITICAL_VOLUMES=(


    hts-ai-stack_open_webui_data
    hts-ai-stack_flowise_data
    hts-ai-stack_n8n_data
    hts-ai-stack_langflow_data
    hts-ai-stack_openspace_skills
    hts-ai-stack_openspace_config
    hts-ai-stack_paperclip_data
    hts-ai-stack_pipelines_data
    hts-ai-stack_portainer_data
    hts-ai-stack_duplicati_config
    hts-ai-stack_grafana_data
    hts-ai-stack_deerflow_data
    hts-ai-stack_claw3d_data
)

DEST="${DEST:-}"
while (($#)); do
    case "$1" in
        --dest) DEST="$2"; shift 2 ;;
        -h|--help)
            sed -n '2,25p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "unknown arg: $1" >&2; exit 2 ;;
    esac
done

[[ -n "$DEST" ]] || {
    echo "error: --dest or DEST env var required" >&2
    echo "example: --dest /mnt/htsai-disk-image/preformat-safety-net" >&2
    exit 2
}

DEST="$(readlink -f "$DEST" 2>/dev/null || echo "$DEST")"

# Refuse to write inside the repo or inside $HOME (must be external/NAS/USB)
case "$DEST" in
    "$REPO_ROOT"|"$REPO_ROOT"/*)
        echo "error: DEST is inside the repo ($REPO_ROOT) — refusing" >&2
        exit 3 ;;
    "$HOME"|"$HOME"/*)
        echo "error: DEST is inside \$HOME — must be an external mount" >&2
        exit 3 ;;
esac

OUT="$DEST/$HOST-$STAMP"
mkdir -p "$OUT"
case "$(readlink -f "$OUT")" in
    "$REPO_ROOT"/*|"$HOME"/*)
        echo "error: resolved OUT path leaks into repo/\$HOME — aborting" >&2
        exit 3 ;;
esac

echo "==> preformat safety-net"
echo "    repo:  $REPO_ROOT"
echo "    dest:  $OUT"
echo

manifest="$OUT/MANIFEST.txt"
: > "$manifest"
{
    echo "# preformat-safety-net manifest"
    echo "host:     $HOST"
    echo "utc:      $STAMP"
    echo "repo-rev: $(cd "$REPO_ROOT" && git rev-parse HEAD 2>/dev/null || echo 'not-a-repo')"
    echo "repo-tag: $(cd "$REPO_ROOT" && git describe --tags --exact-match HEAD 2>/dev/null || echo 'untagged')"
    echo
} >> "$manifest"

copy_file() {
    local src="$1" label="$2"
    if [[ -f "$src" ]]; then
        install -m 600 "$src" "$OUT/$label"
        echo "    + $label"
        printf '%s  %s\n' "$(sha256sum "$OUT/$label" | awk '{print $1}')" "$label" >> "$manifest"
    else
        echo "    - $label (missing, skipped)"
        echo "# missing: $label" >> "$manifest"
    fi
}

echo "==> copying secrets"
copy_file "$REPO_ROOT/config/stack.secrets.json" "stack.secrets.json"
copy_file "$REPO_ROOT/.env" ".env"

echo
echo "==> archiving $(( ${#CRITICAL_VOLUMES[@]} )) named docker volumes"
vols_dir="$OUT/volumes"
mkdir -p "$vols_dir"

for vol in "${CRITICAL_VOLUMES[@]}"; do
    src="/var/lib/docker/volumes/$vol/_data"
    if ! sudo test -d "$src"; then
        echo "    - $vol (volume not found, skipped)"
        echo "# missing: volumes/$vol" >> "$manifest"
        continue
    fi
    out_tgz="$vols_dir/${vol}.tar.gz"
    sudo tar -C "/var/lib/docker/volumes/$vol" -czf "$out_tgz" _data
    sudo chown "$(id -u):$(id -g)" "$out_tgz"
    size=$(du -h "$out_tgz" | awk '{print $1}')
    sum=$(sha256sum "$out_tgz" | awk '{print $1}')
    echo "    + $vol  ($size)"
    printf '%s  volumes/%s.tar.gz\n' "$sum" "$vol" >> "$manifest"
done

echo
echo "==> manifest: $manifest"
total=$(du -sh "$OUT" | awk '{print $1}')
echo "==> total:    $total"
echo
echo "RESTORE QUICK REF"
echo "  secrets:  cp $OUT/stack.secrets.json ~/hts/hts-ai-stack/config/"
echo "            cp $OUT/.env               ~/hts/hts-ai-stack/"
echo "  volumes:  for f in $OUT/volumes/*.tar.gz; do"
echo "              vol=\$(basename \"\$f\" .tar.gz)"
echo "              docker volume create \"\$vol\""
echo "              sudo tar -C \"/var/lib/docker/volumes/\$vol\" -xzf \"\$f\""
echo "            done"
echo
echo "==> done"
