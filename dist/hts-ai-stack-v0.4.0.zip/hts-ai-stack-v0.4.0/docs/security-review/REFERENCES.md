# Security Review References

Cross-reference hub for security artifacts across rooms.

## Papers (12 total, 0 deep-read yet)

Full paper tracking table: **[../planning/security-whitepapers/REFERENCES.md](../planning/security-whitepapers/REFERENCES.md)**

| Priority | arXiv | Title | Key Relevance |
|----------|-------|-------|---------------|
| TIER 1 | 2603.26221 | Clawed and Dangerous | 6-dimensional taxonomy, evaluation scorecard, reference doctrine for secure agent platforms |
| TIER 1 | 2603.23064 | Mind Your HEARTBEAT | OpenClaw background execution enables silent memory pollution |
| TIER 1 | 2603.10387 | Don't Let the Claw Grip Your Hand | 47 adversarial scenarios, 17% native defense rate |
| TIER 1 | 2603.16572 | Malicious Or Not | 238K skill ecosystem analysis, supply chain classification |
| TIER 1 | 2603.11619 | Taming OpenClaw | Five-layer lifecycle security framework |
| TIER 2 | 2602.11416 | Optimizing Agent Planning for Security and Autonomy | Security-aware planning, autonomy metrics, HITL design |
| TIER 2 | 2602.06258 | GRP-Obliteration (Russinovich) | Safety alignment removable with single prompt — affects local Ollama models |
| TIER 2 | 2603.19469 | Framework for Formalizing LLM Agent Security | Four security properties: task alignment, action alignment, source auth, data isolation |
| TIER 3 | 2603.22868 | Agent-Sentry | Behavioral bounding via execution provenance graphs |
| TIER 3 | 2310.02238 | Who's Harry Potter? (Russinovich) | LLM unlearning — lower priority |
| TIER 3 | 2602.20044 | Let There Be Claws | AI agent social network analysis — tangential |
| TIER 3 | 2404.01833 | Crescendo (Russinovich) | Multi-turn jailbreak attack — recommended addition |

## Repos reviewed (7 of ~45)

Full security repo tracking table: **[../planning/security-repos/REFERENCES.md](../planning/security-repos/REFERENCES.md)**
Per-repo review artifacts: `../planning/security-repos/results/`

| Repo | Verdict | Key Value |
|------|---------|-----------|
| **slowmist/openclaw-security-practice-guide** | **ADOPT** | Three-layer defense matrix (pre/in/post-action), nightly audit, Git brain backup, skill audit |
| **prompt-security/clawsec** | **ADOPT** | Drift detection for SOUL.md/IDENTITY.md, SHA256 skill verification, NVD CVE feed, audit watchdog |
| **adversa-ai/secureclaw** | **REFERENCE** | 56 audits, 5 hardening modules, OWASP ASI 10/10 + MITRE ATLAS alignment. No license |
| **tophant-ai/ClawVault** | **ADOPT** | Atomic capability controls, generative policies, transparent proxy gateway, sensitive data detection |
| **Atlas-Cowork/openclaw-reference-setup** | **REFERENCE** | Production-grade hardened setup, 15+ custom tools, purple-team audited |
| **gendigitalinc/sage** | **ADOPT** | Lightweight ADR: command guard, file access control, web request filtering. Norton/Gen Digital |
| **Tencent/AI-Infra-Guard** | **REFERENCE** | Full-stack AI red teaming: agent/skill/MCP scanning, jailbreak evaluation |

**Key insight:** SlowMist + ClawSec are complementary, not competing. SlowMist = behavioral framework + nightly audit. ClawSec = skill verification + drift detection + CVE feed. Both should be adopted.

### Repos Remaining for Review (Tier 1, next batch)

| Repo | Why |
|------|-----|
| sinewaveai/agent-security-scanner-mcp | MCP-based security scanner |
| pegasi-ai/clawreins | HITL approval controls |
| SeyZ/clawbands | Alternative sandboxing (compare with OpenShell) |
| Drakon-Systems-Ltd/ShieldCortex | Security layer for agents |
| onecli/onecli | Credential vault gateway |
| clawshell/clawshell | PII/DLP + credential protection |
| knostic/openclaw-shield | 5-layer defense-in-depth |
| darfaz/clawmoat | Agent firewall |
