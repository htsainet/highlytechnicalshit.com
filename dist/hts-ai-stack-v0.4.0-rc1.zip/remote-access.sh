#!/usr/bin/env bash
# remote-access.sh — Unified SSH and GNOME Remote Desktop manager
#
# Manages remote access configuration:
#   • SSH server (port, auth, security)
#   • GNOME Remote Desktop (VNC)
#   • Security hardening
#
# Usage:
#   ./remote-access.sh                 # Opens main menu
#   ./remote-access.sh ssh             # SSH configuration directly
#   ./remote-access.sh vnc             # VNC (desktop) configuration directly
#   ./remote-access.sh --help          # Show help

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$SCRIPT_DIR/scripts/utils/remote-access.sh" "$@"
