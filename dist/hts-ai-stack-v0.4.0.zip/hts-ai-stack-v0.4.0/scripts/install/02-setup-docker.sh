#!/usr/bin/env bash
# 02-setup-docker.sh — Pull all stack images to local cache
#
# Run once after cloning, or any time you want to refresh images before
# starting the stack. Does not start any containers.
#
# To start the stack after pulling:
#   converge.sh --yes

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
# shellcheck source=scripts/install/tooling/ui.sh
source "$REPO_DIR/scripts/install/tooling/ui.sh"

htsai_banner "02 — Docker Setup"

info() { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already exists" >&2; }
fail() { echo -e "${RED}[FAIL]${NC} $*" >&2; exit 1; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

# ── Pre-run checklist ─────────────────────────────────────────────────────────
checklist_start
if [ -f "$REPO_DIR/.env" ]; then checklist_item true "1. .env tokens"; else checklist_item false "1. .env tokens"; fi
checklist_item false "2. Pull container images"
checklist_end

# ── Step 1: Verify .env ───────────────────────────────────────────────────────
step "1 — Check .env"

ENV_FILE="$REPO_DIR/.env"

if [ -f "$ENV_FILE" ]; then
  skip ".env"
else
  fail ".env not found. Run ./01-autoinstall.sh to generate tokens, or create it manually:
  openssl rand -hex 32  # WEBUI_SECRET_KEY"
fi

# Export .env so compose interpolation succeeds for nested compose files.
set -a
# shellcheck source=/dev/null
source "$ENV_FILE"
set +a

# ── Step 2: Pull images ───────────────────────────────────────────────────────
step "2 — Pull images"

info "Pulling stack images..."

# Build profile flags from .env so conditional services get pulled too
PULL_PROFILES=()
[[ "${DASHBOARD_ENABLED:-false}" == "true" ]]   && PULL_PROFILES+=(--profile dashboard)
[[ "${MONITORING_ENABLED:-false}" == "true" ]]   && PULL_PROFILES+=(--profile monitoring)
[[ "${PORTAINER_ENABLED:-false}" == "true" ]]    && PULL_PROFILES+=(--profile portainer)

docker compose --env-file "$ENV_FILE" -f "$REPO_DIR/docker-compose.yml" \
  "${PULL_PROFILES[@]}" pull

info "All images pulled."
echo ""
info "To start the stack, run:  ./install.sh"

