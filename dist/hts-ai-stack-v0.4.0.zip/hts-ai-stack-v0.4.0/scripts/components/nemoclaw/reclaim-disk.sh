#!/usr/bin/env bash
# Safe disk reclaim for NemoClaw / openshell gateway disk-pressure recovery.
# Touches ONLY: docker build cache, dangling images, unused images.
# Does NOT touch: running containers, named volumes, or any hts-ai-* image
# that has a container attached.
set -euo pipefail

echo "=== before ==="
df -h / | sed 's/^/  /'
docker system df 2>/dev/null | sed 's/^/  /'
echo

echo "=== docker builder prune (build cache) ==="
docker builder prune -af
echo

echo "=== docker image prune -a (unused images, no running container) ==="
docker image prune -af
echo

echo "=== docker container prune (stopped containers) ==="
docker container prune -f
echo

echo "=== after ==="
df -h / | sed 's/^/  /'
docker system df 2>/dev/null | sed 's/^/  /'
