#!/usr/bin/env bash
# shellcheck disable=all
# scripts/maintenance/diagnose-ssh-tailscale.sh — Diagnose SSH-over-Tailscale
# from mobile clients (Terminus Android, Termius, Blink, etc.).
#
# Checks everything that commonly prevents a phone on the tailnet from reaching
# sshd on this host, and prints the exact fix for each failure.
#
# Usage:
#   sudo ./scripts/maintenance/diagnose-ssh-tailscale.sh [--fix] [--peer <name|ip>]
#
# Flags:
#   --fix           Apply safe auto-fixes (restart services, add ufw rules,
#                   disable Tailscale SSH hijack). Never rewrites sshd_config
#                   without an explicit prompt.
#   --peer <id>     Tailscale hostname or 100.x IP of the phone to test
#                   reachability from (ping + ACL probe).
#   --trace [N]     Live-capture mode. Tails sshd journal AND tcpdump on every
#                   interface for N seconds (default 30) so you can hit Connect
#                   on the phone and see exactly which interface + source IP the
#                   packets land on. Also reports fail2ban bans.
#
# Read-only by default. Exit code 0 if all checks pass, 1 otherwise.

set -euo pipefail

FIX=false
PEER=""
TRACE=false
TRACE_SECS=30
DEEP=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --fix)  FIX=true; shift ;;
    --peer) PEER="${2:-}"; shift 2 ;;
    --trace)
      TRACE=true; shift
      if [[ "${1:-}" =~ ^[0-9]+$ ]]; then TRACE_SECS="$1"; shift; fi ;;
    --deep) DEEP=true; shift ;;
    -h|--help)
      grep -E '^# ' "$0" | head -30 | cut -c3-
      exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done

if [[ $EUID -ne 0 ]]; then
  echo "This script needs root (sudo) to inspect sshd_config and firewall rules." >&2
  exit 2
fi

PASS="✅"; FAIL="❌"; WARN="⚠️ "; FIX_ICON="🔧"; INFO="ℹ️ "
FAILS=0

section() { echo; echo "━━━ $1 ━━━"; }
ok()      { echo "  ${PASS} $1"; }
fail()    { echo "  ${FAIL} $1"; FAILS=$((FAILS+1)); }
warn()    { echo "  ${WARN} $1"; }
fixed()   { echo "  ${FIX_ICON} $1"; }
info()    { echo "  ${INFO} $1"; }
hint()    { echo "     → $1"; }

# ── 1. Tailscale daemon & node state ──────────────────────────────────────────
section "Tailscale daemon"

if ! command -v tailscale &>/dev/null; then
  fail "tailscale CLI not installed"
  hint "Install: curl -fsSL https://tailscale.com/install.sh | sh"
  exit 1
fi

TS_JSON="$(tailscale status --json 2>/dev/null || echo '{}')"
TS_BACKEND="$(python3 -c 'import json,sys; print(json.loads(sys.stdin.read()).get("BackendState","unknown"))' <<<"$TS_JSON")"
TS_IP4="$(tailscale ip -4 2>/dev/null | head -1 || true)"
TS_HOSTNAME="$(python3 -c 'import json,sys; print(json.loads(sys.stdin.read()).get("Self",{}).get("HostName",""))' <<<"$TS_JSON")"

if [[ "$TS_BACKEND" == "Running" ]]; then
  ok "Backend: Running  (hostname=${TS_HOSTNAME}, ip=${TS_IP4})"
else
  fail "Tailscale backend state: ${TS_BACKEND}"
  if $FIX; then tailscale up && fixed "Ran: tailscale up"
  else hint "Run: sudo tailscale up"; fi
fi

# ── 1b. Tailscale Shields-Up + ACL probe ─────────────────────────────────────
section "Tailscale ACL / Shields-Up"

TS_SHIELDS="$(python3 -c 'import json,sys; print(json.loads(sys.stdin.read()).get("Self",{}).get("ShieldsUp",False))' <<<"$TS_JSON")"
if [[ "$TS_SHIELDS" == "True" ]]; then
  fail "Shields-Up is ENABLED — tailscaled drops ALL inbound connections."
  if $FIX; then
    tailscale set --shields-up=false && fixed "Disabled shields-up"
  else
    hint "sudo tailscale set --shields-up=false"
  fi
else
  ok "Shields-Up is off."
fi

# Check tailscale prefs for any AdvertisedRoutes or unusual settings, and dump
# the raw debug prefs which include the netmap-applied filter rules.
if tailscale debug prefs &>/dev/null; then
  PREFS_JSON="$(tailscale debug prefs 2>/dev/null || echo '{}')"
  HOSTNAME_PREF="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read() or "{}"); print(d.get("Hostname",""))' <<<"$PREFS_JSON" 2>/dev/null || true)"
  [[ -n "$HOSTNAME_PREF" ]] && info "Tailscale Hostname pref: ${HOSTNAME_PREF}"
fi

# Live netmap filter — this is the smoking-gun source. tailscaled stores the
# parsed ACL filter rules here. If port 22 is missing from the allowed dsts
# for your user/tag, packets are silently dropped before the kernel sees them.
if NM="$(tailscale debug netmap 2>/dev/null)"; then
  if grep -qi 'packetfilter' <<<"$NM"; then
    info "Inbound ACL packet-filter rules applied to this node:"
    # Extract the PacketFilter block and print dst CIDRs/ports.
    # NM is exported so python reads it from env, NOT from a herestring
    # collision with the heredoc.
    NM="$NM" python3 <<'PYEOF' || true
import os, re, json
text = os.environ.get("NM", "")
# netmap output embeds PacketFilter as a JSON array under the key
# "PacketFilter": [ ... ]   — capture from the opening bracket and
# walk the brackets to find the matching close (regex can't balance).
key = re.search(r'"PacketFilter"\s*:\s*\[', text)
if not key:
    print("    (could not locate PacketFilter in netmap output)")
    raise SystemExit(0)
start = key.end() - 1  # index of the '['
depth = 0
end = None
for i in range(start, len(text)):
    c = text[i]
    if c == '[':
        depth += 1
    elif c == ']':
        depth -= 1
        if depth == 0:
            end = i + 1
            break
if end is None:
    print("    (PacketFilter array unterminated in netmap output)")
    raise SystemExit(0)
blob = text[start:end]
try:
    rules = json.loads(blob)
except Exception as e:
    print(f"    (PacketFilter present but not parseable: {e})")
    print("    " + blob[:800].replace("\n", " "))
    raise SystemExit(0)

found_22 = False
for r in rules:
    srcs = r.get("Srcs", [])
    dsts = r.get("Dsts", [])
    for d in dsts:
        net = d.get("Net", "*")
        ports = d.get("Ports", {}) or {}
        first = ports.get("First")
        last  = ports.get("Last")
        if first is not None and last is not None and first <= 22 <= last:
            found_22 = True
            if first == 0 and last == 65535:
                print(f"    ✅ ALL ports allowed from {srcs} to {net}")
            else:
                print(f"    ✅ port 22 allowed from {srcs} to {net} (ports {first}-{last})")
        else:
            print(f"       allowed: {srcs} → {net} ports {first}-{last}")
if not found_22:
    print("    ❌ NO ACL rule grants inbound port 22 to this node.")
    print("       This is why tailscale0 sees zero :22 SYNs from the phone.")
    print("       Fix in admin console: https://login.tailscale.com/admin/acls")
    print("       Add an ACL like:")
    print('         {"action":"accept","src":["YOUR_PHONE_USER_OR_TAG"],"dst":["'+'tag:server'+':22","'+'YOUR_HOST'+':22"]}')
PYEOF
  else
    warn "Could not locate PacketFilter in 'tailscale debug netmap' output."
  fi
else
  warn "'tailscale debug netmap' unavailable — older tailscale version."
fi

# ── 2. Tailscale SSH hijack (conflicts with 3rd-party mobile clients) ─────────
section "Tailscale SSH (port 22 hijack)"

# The authoritative source is `tailscale debug prefs` → RunSSH.
# `tailscale status --json`.Self.TailscaleSSHEnabled does NOT exist and always
# returns False, which previously caused this check to silently report "disabled"
# even when SSH hijack was active.
TS_RUNSSH="$(tailscale debug prefs 2>/dev/null \
  | python3 -c 'import json,sys; d=json.loads(sys.stdin.read() or "{}"); print(d.get("RunSSH",False))' 2>/dev/null \
  || echo "False")"

if [[ "$TS_RUNSSH" == "True" ]]; then
  fail "Tailscale SSH is ENABLED on this host (prefs.RunSSH=true)."
  hint "Tailscale SSH intercepts tailnet port 22 in userspace and requires"
  hint "Tailscale-native auth. Terminus/Termius/Blink/ConnectBot on Android"
  hint "CANNOT authenticate through it — packets never reach tailscale0 in"
  hint "the kernel, so tcpdump on tailscale0 sees zero :22 traffic."
  if $FIX; then
    tailscale set --ssh=false
    fixed "Disabled Tailscale SSH (tailscale set --ssh=false)"
  else
    hint "Fix: sudo tailscale set --ssh=false   (keeps mesh VPN, releases port 22)"
  fi
else
  ok "Tailscale SSH is disabled — native sshd owns port 22 on the tailnet."
fi

# ── 3. sshd service ───────────────────────────────────────────────────────────
section "sshd service"

SSH_UNIT=""
for u in ssh sshd; do
  if systemctl list-unit-files "${u}.service" &>/dev/null; then SSH_UNIT="$u"; break; fi
done

if [[ -z "$SSH_UNIT" ]]; then
  fail "No ssh/sshd systemd unit found. Install openssh-server."
  hint "sudo apt-get install -y openssh-server"
else
  if systemctl is-active --quiet "$SSH_UNIT"; then
    ok "${SSH_UNIT}.service is active"
  else
    fail "${SSH_UNIT}.service is NOT active"
    if $FIX; then
      systemctl enable --now "$SSH_UNIT"
      fixed "Started ${SSH_UNIT}"
    else
      hint "sudo systemctl enable --now ${SSH_UNIT}"
    fi
  fi
fi

# ── 4. sshd listeners ─────────────────────────────────────────────────────────
section "sshd listeners"

LISTENERS="$(ss -tlnpH 2>/dev/null | awk '/sshd/ {print $4}' | sort -u)"
if [[ -z "$LISTENERS" ]]; then
  fail "No sshd listener found in ss output."
else
  echo "$LISTENERS" | while read -r L; do info "listening on ${L}"; done
  if echo "$LISTENERS" | grep -qE '(^|[^0-9])0\.0\.0\.0:|^\[?::\]?:'; then
    ok "sshd binds to all interfaces (includes tailscale0)."
  elif [[ -n "$TS_IP4" ]] && echo "$LISTENERS" | grep -qF "$TS_IP4:"; then
    ok "sshd binds to tailscale IP ${TS_IP4}."
  else
    fail "sshd is NOT listening on tailscale0 / ${TS_IP4}."
    hint "Check /etc/ssh/sshd_config[.d/*] for a ListenAddress that excludes"
    hint "the tailnet. Either remove it, add 'ListenAddress ${TS_IP4}', or"
    hint "add 'ListenAddress 0.0.0.0'."
  fi
fi

# Effective sshd config (authoritative — includes drop-ins)
section "sshd effective config"

SSHD_BIN="$(command -v sshd || echo /usr/sbin/sshd)"
if EFF="$("$SSHD_BIN" -T 2>/dev/null)"; then
  get() { awk -v k="$1" 'tolower($1)==k {print $2; exit}' <<<"$EFF"; }
  PORT="$(get port)"
  PWA="$(get passwordauthentication)"
  PKA="$(get pubkeyauthentication)"
  KBI="$(get kbdinteractiveauthentication)"
  ALLOW_USERS="$(awk 'tolower($1)=="allowusers" {$1=""; print; exit}' <<<"$EFF" | xargs || true)"
  ALLOW_GROUPS="$(awk 'tolower($1)=="allowgroups" {$1=""; print; exit}' <<<"$EFF" | xargs || true)"

  info "Port=${PORT}  PasswordAuth=${PWA}  PubkeyAuth=${PKA}  KbdInteractive=${KBI}"
  [[ -n "$ALLOW_USERS"  ]] && info "AllowUsers: ${ALLOW_USERS}"
  [[ -n "$ALLOW_GROUPS" ]] && info "AllowGroups: ${ALLOW_GROUPS}"

  [[ "$PORT" != "22" ]] && warn "sshd on non-standard port ${PORT} — set this in Terminus."

  if [[ "$PWA" == "no" && "$PKA" == "no" ]]; then
    fail "Both password and pubkey auth are disabled — nothing can log in."
  elif [[ "$PWA" == "no" ]]; then
    info "Password auth disabled — Terminus must use an SSH key."
  fi
else
  warn "Could not run '${SSHD_BIN} -T' — skipping effective-config check."
fi

# ── 5. Firewall ───────────────────────────────────────────────────────────────
section "Firewall"

if command -v ufw &>/dev/null && ufw status &>/dev/null; then
  UFW_HEAD="$(ufw status | head -1)"
  info "ufw: ${UFW_HEAD}"
  if grep -qi inactive <<<"$UFW_HEAD"; then
    ok "ufw inactive — not blocking."
  else
    if ufw status | grep -Eq '(^|\s)22(/tcp)?\s' \
       || ufw status | grep -Eq 'on tailscale0.*22\b' \
       || ufw status | grep -qi 'openssh'; then
      ok "ufw has a rule allowing port 22."
    else
      fail "ufw is active but has no visible rule for port 22."
      if $FIX; then
        ufw allow in on tailscale0 to any port 22 proto tcp comment "SSH — tailnet only"
        fixed "Added: ufw allow in on tailscale0 to any port 22 proto tcp"
      else
        hint "sudo ufw allow in on tailscale0 to any port 22 proto tcp"
      fi
    fi
  fi
else
  ok "ufw not active or not installed."
fi

if command -v nft &>/dev/null && nft list ruleset 2>/dev/null | grep -qiE 'drop|reject'; then
  warn "nftables has drop/reject rules — inspect: sudo nft list ruleset | grep -i ssh"
fi

# ── 5b. fail2ban ─────────────────────────────────────────────────────────────
section "fail2ban"

if systemctl is-active --quiet fail2ban 2>/dev/null; then
  info "fail2ban is active"
  F2B_JAILS="$(fail2ban-client status 2>/dev/null | awk -F: '/Jail list/{print $2}' | tr -d ', \t')"
  if [[ -n "$F2B_JAILS" ]]; then
    for J in ${F2B_JAILS//,/ }; do
      BANS="$(fail2ban-client status "$J" 2>/dev/null | awk -F: '/Banned IP list/{print $2}' | xargs || true)"
      if [[ -n "$BANS" ]]; then
        warn "Jail '${J}' has banned IPs: ${BANS}"
        if [[ -n "$PEER" ]] && grep -qF "$PEER" <<<"$BANS"; then
          fail "Peer ${PEER} is BANNED by fail2ban jail '${J}'."
          if $FIX; then
            fail2ban-client set "$J" unbanip "$PEER" >/dev/null && fixed "Unbanned ${PEER} from ${J}"
          else
            hint "sudo fail2ban-client set ${J} unbanip ${PEER}"
          fi
        fi
      else
        ok "Jail '${J}': no current bans"
      fi
    done
  fi
else
  ok "fail2ban not active."
fi

# ── 6. Tailnet peer reachability ──────────────────────────────────────────────
section "Tailnet peers"

PEER_COUNT="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(len(d.get("Peer",{}) or {}))' <<<"$TS_JSON")"
info "Peers visible to this node: ${PEER_COUNT}"

if [[ "$PEER_COUNT" -eq 0 ]]; then
  warn "No peers — phone not on the tailnet, or ACL hides it. Check admin console."
fi

if [[ -n "$PEER" ]]; then
  info "Testing peer: ${PEER}"
  if tailscale ping --c 3 --timeout 3s "$PEER" 2>&1 | tee /tmp/tsping.$$ | grep -q 'pong'; then
    ok "tailscale ping → ${PEER} succeeded"
  else
    fail "tailscale ping → ${PEER} failed"
    hint "Phone's Tailscale app must be ON. Check admin console for the device."
  fi
  rm -f /tmp/tsping.$$ || true
else
  info "Pass --peer <phone-hostname-or-100.x.y.z> to probe connectivity from the phone's node."
fi

# ── 7. Loopback sshd probe on the tailnet IP ─────────────────────────────────
section "Local sshd probe on tailscale0"

if [[ -n "$TS_IP4" ]] && command -v ssh-keyscan &>/dev/null; then
  if timeout 5 ssh-keyscan -T 3 -p "${PORT:-22}" "$TS_IP4" 2>/dev/null | grep -q 'ssh-'; then
    ok "ssh-keyscan ${TS_IP4}:${PORT:-22} returned host keys — sshd is reachable on the tailnet IP."
  else
    fail "ssh-keyscan ${TS_IP4}:${PORT:-22} got no banner. sshd is not reachable via the tailscale interface from this host."
    hint "Combine with section 4/5 above to locate the block."
  fi
fi

# ── 8. Live trace mode ───────────────────────────────────────────────────────
if $TRACE; then
  section "Live trace (${TRACE_SECS}s)"
  if ! command -v tcpdump &>/dev/null; then
    fail "tcpdump not installed — sudo apt-get install -y tcpdump"
  else
    TRACE_DIR="$(mktemp -d)"
    PCAP_LOG="${TRACE_DIR}/tcpdump.log"
    JOURNAL_LOG="${TRACE_DIR}/journal.log"

    info "Capturing on ALL interfaces for ${TRACE_SECS}s. Tap Connect on the phone NOW."
    info "Watching: tcp port 22, plus traffic to/from peer ${PEER:-<none>}"
    echo

    FILTER="tcp port 22"
    if [[ -n "$PEER" ]]; then FILTER="(tcp port 22) or (host ${PEER})"; fi

    tcpdump -i any -n -l -tttt "$FILTER" >"$PCAP_LOG" 2>/dev/null &
    TCPDUMP_PID=$!

    journalctl -u ssh -u sshd -f --since "now" >"$JOURNAL_LOG" 2>/dev/null &
    JOURNAL_PID=$!

    trap 'kill '"$TCPDUMP_PID"' '"$JOURNAL_PID"' 2>/dev/null || true' EXIT INT TERM

    for ((i=TRACE_SECS; i>0; i--)); do
      printf "\r  ⏱  %02ds remaining — try connecting from the phone..." "$i"
      sleep 1
    done
    printf "\r%-70s\r" " "

    kill "$TCPDUMP_PID" "$JOURNAL_PID" 2>/dev/null || true
    wait 2>/dev/null || true
    trap - EXIT INT TERM

    PKT_COUNT="$(wc -l <"$PCAP_LOG" | tr -d ' ')"
    PORT22_COUNT="$(grep -cE '\.22 >|> [0-9.]+\.22\b' "$PCAP_LOG" || true)"
    JNL_COUNT="$(wc -l <"$JOURNAL_LOG" | tr -d ' ')"

    echo "── Packets captured: ${PKT_COUNT} (of which ${PORT22_COUNT} touched port 22) ──"
    if [[ "$PORT22_COUNT" -eq 0 ]]; then
      fail "No port-22 packets seen on ANY interface during the trace."
      if [[ "$PKT_COUNT" -gt 0 ]]; then
        hint "Other traffic was flowing (likely browser/openwebui), so the tailnet"
        hint "path is fine. The SSH client on the phone never sent a SYN to port 22."
        hint "→ Wrong host/port in the client app, DNS hang, or VPN permission denied"
        hint "  for that one app. Test with Termux: 'nc -vz ${TS_IP4} 22'"
      else
        hint "The phone never sent a SYN that reached this host. Check on the phone:"
        hint "  • Tailscale app is in foreground & 'Connected' (force-stop & relaunch)"
        hint "  • Battery → Unrestricted for the SSH client AND Tailscale"
        hint "  • Try: open http://${TS_IP4}:3000 in phone browser FIRST, then SSH"
        hint "  • In SSH client, host = ${TS_IP4} (literal IP, not MagicDNS name)"
      fi
    else
      # shellcheck disable=SC2002
cat "$PCAP_LOG" | head -40
      echo
      info "Interfaces seen:"
      awk '{print "    "$3}' "$PCAP_LOG" | sort -u | head -10
      info "Source IPs to port 22:"
      P22_SRCS="$(grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+ > [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\.22\b' "$PCAP_LOG" \
        | awk '{print "    "$1" → "$3}' | sort -u | head -10)"
      if [[ -n "$P22_SRCS" ]]; then echo "$P22_SRCS"; else echo "    (none — no port-22 traffic captured)"; fi

      if grep -qE " tailscale0 " "$PCAP_LOG" && grep -qE '\.22\b' "$PCAP_LOG"; then
        ok "Saw port-22 traffic on tailscale0 — tailnet SSH path is being used."
      elif grep -qE " (eth[0-9]|enp[0-9a-z]+|wlp[0-9a-z]+|wlan[0-9]+) " "$PCAP_LOG" \
           && grep -qE '\.22\b' "$PCAP_LOG"; then
        fail "Port-22 traffic arrived on a non-tailnet interface (LAN/WAN)."
        hint "The phone resolved the host to a LAN/public IP and is bypassing the tailnet."
        hint "In the SSH client, set Host = ${TS_IP4} (literal tailnet IP)."
        hint "Also turn ON 'Use Tailscale DNS' in the Tailscale Android app."
      fi
    fi

    echo
    echo "── sshd journal during trace (${JNL_COUNT} lines) ──"
    if [[ "$JNL_COUNT" -gt 0 ]]; then
      tail -20 "$JOURNAL_LOG"
    else
      info "No new sshd log lines — sshd never saw a connection attempt."
    fi

    info "Full captures: ${PCAP_LOG}  ${JOURNAL_LOG}"
  fi
fi

# ── 9. Deep host-side dump ───────────────────────────────────────────────────
if $DEEP; then
  section "Deep dump: who/what could intercept :22 on this host"

  echo "── ALL listeners on port 22 ──"
  ss -tlnp 2>/dev/null | awk 'NR==1 || /:22\b/' || true

  echo
  echo "── iptables filter INPUT (with packet counters) ──"
  iptables -L INPUT -v -n --line-numbers 2>/dev/null || echo "  (iptables unavailable)"

  echo
  echo "── iptables nat PREROUTING (DNAT/REDIRECT can hijack :22) ──"
  iptables -t nat -L PREROUTING -v -n --line-numbers 2>/dev/null || true
  echo "── iptables nat OUTPUT ──"
  iptables -t nat -L OUTPUT -v -n --line-numbers 2>/dev/null || true

  echo
  echo "── iptables raw PREROUTING (ingress drops happen here) ──"
  iptables -t raw -L PREROUTING -v -n --line-numbers 2>/dev/null || true

  echo
  echo "── iptables mangle PREROUTING ──"
  iptables -t mangle -L PREROUTING -v -n --line-numbers 2>/dev/null || true

  echo
  echo "── nftables ruleset (look for tailscale0 / dport 22 drops) ──"
  if command -v nft &>/dev/null; then
    nft list ruleset 2>/dev/null | grep -E '(tailscale|dport 22|hook ingress|drop)' | head -40 \
      || echo "  (no matching nftables rules)"
  else
    echo "  (nft not installed)"
  fi

  echo
  echo "── tc ingress filters on tailscale0 (drop here is invisible to tcpdump) ──"
  tc -s qdisc show dev tailscale0 2>/dev/null || echo "  (tc not available)"
  tc -s filter show dev tailscale0 ingress 2>/dev/null || true
  tc -s filter show dev tailscale0 2>/dev/null || true

  echo
  echo "── /etc/hosts.allow + /etc/hosts.deny (TCP wrappers) ──"
  for f in /etc/hosts.allow /etc/hosts.deny; do
    if [[ -s "$f" ]]; then echo "  ── ${f} ──"; awk '{print "    "$0}' "$f"; else echo "  ${f}: empty/absent"; fi
  done

  echo
  echo "── ufw rule details (verbose) ──"
  ufw status verbose 2>/dev/null | awk '{print "    "$0}' || true

  echo
  echo "── Routes for the tailnet (where do tailnet packets land?) ──"
  ip route show table all 2>/dev/null | grep -E '100\.' | head -20 || true

  echo
  echo "── Docker iptables chains (Docker often inserts DNAT rules) ──"
  iptables -L DOCKER-USER -v -n 2>/dev/null || echo "  (no DOCKER-USER chain)"
  iptables -L DOCKER -v -n 2>/dev/null      || echo "  (no DOCKER chain)"
  iptables -t nat -L DOCKER -v -n 2>/dev/null || true

  echo
  echo "── Tailscale prefs + netmap excerpt ──"
  tailscale debug prefs 2>/dev/null | head -40 || true
  echo "── netmap PacketFilter (first 60 lines) ──"
  tailscale debug netmap 2>/dev/null | grep -A40 -i 'packetfilter' | head -60 || true

  echo
  echo "── conntrack for source ${PEER:-<peer>}:* → host:22 ──"
  if command -v conntrack &>/dev/null && [[ -n "$PEER" ]]; then
    conntrack -L 2>/dev/null | grep -E "(${PEER}|dport=22|sport=22)" | head -20 || echo "  (no entries)"
  else
    echo "  (conntrack not installed or --peer not specified)"
  fi

  echo
  echo "── Live test from THIS host to its OWN tailscale IP on :22 ──"
  if [[ -n "$TS_IP4" ]]; then
    timeout 4 bash -c "</dev/tcp/${TS_IP4}/22 && echo '  ✅ TCP connect to ${TS_IP4}:22 succeeded' || echo '  ❌ TCP connect to ${TS_IP4}:22 FAILED'"
  fi
fi

# ── Summary ───────────────────────────────────────────────────────────────────
section "Summary"
echo "  Tailscale IP : ${TS_IP4:-unavailable}"
echo "  SSH target   : ${TS_IP4:-<tailscale-ip>}:${PORT:-22}"
echo "  Failures     : ${FAILS}"
echo
if [[ "$FAILS" -eq 0 ]]; then
  echo "  ${PASS} All checks passed. In Terminus:"
  echo "     • Host: ${TS_IP4:-<100.x.y.z>}   (use the IP, not the MagicDNS name)"
  echo "     • Port: ${PORT:-22}"
  echo "     • Ensure the Tailscale Android app is toggled ON before connecting."
  exit 0
else
  echo "  ${FAIL} ${FAILS} issue(s) found. Re-run with --fix to apply safe repairs,"
  echo "     or address the hints above manually."
  exit 1
fi
