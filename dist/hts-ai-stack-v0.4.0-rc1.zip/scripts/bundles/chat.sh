#!/usr/bin/env bash
# scripts/bundles/chat.sh — Minimal chat setup
#
# Installs host dependencies and brings up the inference backend + Open WebUI.
# Lightest useful bundle — just AI chat.
#
# Usage:
#   ./scripts/bundles/chat.sh [--chat lean|mean|claw]
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "Chat Bundle"
load_env

CHAT_MODE="mean"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --chat) CHAT_MODE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-false}"

# ── Host ──────────────────────────────────────────────────────────────────────
step "Host dependencies"
bash "$REPO_DIR/scripts/host/docker.sh"
bash "$REPO_DIR/scripts/host/nvidia.sh"

# ── Services (dual-backend + llama-swap) ──────────────────────────────────────
step "Chat services"
bash "$REPO_DIR/scripts/components/ollama.sh" --swap "$CHAT_MODE"
bash "$REPO_DIR/scripts/components/bitnet.sh"
bash "$REPO_DIR/scripts/components/llama-swap.sh"
bash "$REPO_DIR/scripts/components/open-webui.sh"

if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/components/dashboard.sh"
fi

echo ""
ok "Chat bundle ready — dual-backend (GPU+CPU) chat:${CHAT_MODE}"
