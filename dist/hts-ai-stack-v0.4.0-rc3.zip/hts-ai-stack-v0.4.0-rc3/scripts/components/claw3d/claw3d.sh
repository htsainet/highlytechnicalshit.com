#!/usr/bin/env bash
# scripts/components/claw3d/claw3d.sh — Claw3D 3D Agent Workspace: install, start, health
#
# Standalone usage:
#   ./scripts/components/claw3d/claw3d.sh              # full: install + configure + start + health
#   ./scripts/components/claw3d/claw3d.sh --install    # install only
#   ./scripts/components/claw3d/claw3d.sh --configure  # configure only
#   ./scripts/components/claw3d/claw3d.sh --start      # start only
#   ./scripts/components/claw3d/claw3d.sh --stop       # stop
#   ./scripts/components/claw3d/claw3d.sh --restart    # restart (stop + start)
#   ./scripts/components/claw3d/claw3d.sh --health     # health check only
#   ./scripts/components/claw3d/claw3d.sh --status     # show status + port + health
#   ./scripts/components/claw3d/claw3d.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
CLAW3D_PORT="${CLAW3D_PORT:-3006}"

# ── Functions ────────────────────────────────────────────────────────────────

# claw3d_install — Build Claw3D image from docker/claw3d/Dockerfile
claw3d_install() {
  step "Claw3D — install"
  local dockerfile="$REPO_DIR/docker/claw3d/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    fail "Claw3D Dockerfile not found: $dockerfile"
    return 1
  fi
  compose_pull --profile claw3d
  ok "Claw3D image ready."
}

# claw3d_configure — Validate config and env vars
claw3d_configure() {
  step "Claw3D — configure"
  info "Claw3D port: ${CLAW3D_PORT}"
  info "OpenClaw gateway: ws://localhost:18789"
  ok "Claw3D configured."
}

# claw3d_start — Bring up Claw3D via compose
claw3d_start() {
  step "Claw3D — start"
  compose_up --profile claw3d
  ok "Claw3D started (UI :${CLAW3D_PORT})."
}

# claw3d_stop — Bring down Claw3D
claw3d_stop() {
  step "Claw3D — stop"
  compose_down --profile claw3d
  ok "Claw3D stopped."
}

# claw3d_health — Probe the Claw3D health endpoint
claw3d_health() {
  local label="Claw3D :${CLAW3D_PORT}"
  local url="http://localhost:${CLAW3D_PORT}/api/health"
  local max_attempts=30
  local sleep_secs=2
  local attempts=0

  printf "  %-35s" "$label"
  while true; do
    if curl -sf --max-time 3 "$url" >/dev/null 2>&1; then
      printf "\r  %-35s${GREEN}OK${NC}  \n" "$label"
      return 0
    fi
    sleep "$sleep_secs"
    attempts=$((attempts + 1))
    if [[ $attempts -ge $max_attempts ]]; then
      printf "\r  %-35s${RED}FAIL${NC} (%s)\n" "$label" "$url"
      return 1
    fi
  done
}

claw3d_restart() {
  claw3d_stop
  claw3d_start
}

claw3d_destroy() {
  step "Claw3D — destroy"
  compose_down --profile claw3d -v
  ok "Claw3D destroyed."
}

claw3d_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=claw3d" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Claw3D is running (port ${CLAW3D_PORT})"
  else
    warn "Claw3D is not running."
  fi
  claw3d_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   claw3d_install   ;;
    configure) claw3d_configure ;;
    start)     claw3d_start     ;;
    stop)      claw3d_stop      ;;
    restart)   claw3d_restart   ;;
    health)    claw3d_health    ;;
    status)    claw3d_status    ;;
    destroy)   claw3d_destroy   ;;
    default)
      claw3d_install
      claw3d_configure
      claw3d_start
      claw3d_health
      ;;
  esac
fi
