# 4-setup-nemoclaw.sh — NemoClaw + OpenShell

> **Alpha:** NemoClaw is pre-1.0. APIs and behaviour change without notice.
> `NEMOCLAW_EXPERIMENTAL=1` is **required** for local inference (the install
> step `[3/8] Configuring inference` aborts without it under
> `NEMOCLAW_PROVIDER=custom`).

NemoClaw documentation has moved alongside the component. See:

- [`scripts/components/nemoclaw/CONTEXT.md`](../../scripts/components/nemoclaw/CONTEXT.md)
  — operational runbook, working configuration, lessons learned.
- [`scripts/components/nemoclaw/REFERENCES.md`](../../scripts/components/nemoclaw/REFERENCES.md)
  — architecture diagram, OpenShell install path, working-config table,
  smoke-test plan, rollback procedure, official CLI tables.
- [`scripts/components/nemoclaw/DEVIATIONS.md`](../../scripts/components/nemoclaw/DEVIATIONS.md)
  — current deviations grounded to the manifest pin
  (NemoClaw `v0.0.31`, OpenShell `0.0.36`).
- [`scripts/components/nemoclaw/DEVIATIONS-history.md`](../../scripts/components/nemoclaw/DEVIATIONS-history.md)
  — historical context (v0.0.21 → v0.0.29 → v0.0.31 transition).

The pipeline entry point itself is
[`scripts/components/nemoclaw/nemoclaw.sh`](../../scripts/components/nemoclaw/nemoclaw.sh)
(invoked by `converge.sh`).
