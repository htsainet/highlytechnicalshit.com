# CrewAI Component — CONTEXT

## What is CrewAI?

CrewAI is the leading open-source Python framework for orchestrating autonomous
multi-agent AI workflows. It provides two complementary primitives:

- **Crews**: Teams of role-playing agents that collaborate on complex tasks
- **Flows**: Structured, event-driven workflows that manage state and delegate
  tasks to Crews at the right moment

- Source: <https://github.com/crewAIInc/crewAI>
- Docs: <https://docs.crewai.com>

## How it fits into the HTS AI Stack

A custom Streamlit UI runs in Docker (`hts-ai-crewai`, port 8501). It connects
to the local inference stack via the OpenAI-compatible API:

```text
CrewAI UI (8501)  →  llama-swap :8080/v1  →  bitnet/ollama
```

No GPU required — all inference is external. The UI fetches available models
live from llama-swap at startup.

## Docker image

Custom build: `docker/crewai/Dockerfile`

- Installs `crewai[tools]` via **uv** (official install method)
- Copies custom Streamlit app from `docker/crewai/app/`
- No database — config and run logs stored as YAML/JSON in the named volume
- Streamlit health endpoint: `/_stcore/health`

## Persistence

All data lives in the `crewai_data` named volume mounted at `/app/data`:

```text
/app/data/
  agents.yaml       — saved agent definitions
  tasks.yaml        — saved task definitions
  crews.yaml        — saved crew definitions
  runs/<run_id>/
    meta.json       — status, timestamps, model
    output.log      — step/task callback output + final result
  outputs/          — task output_file writes (path-constrained)
```

## Tier placement

Order 122 — agents tier (100–299). Placed after `deerflow` (120) and before
`flowise` (125).

## LLM Routing — Important (do not revert)

CrewAI uses **LiteLLM** under the hood for all LLM calls. LiteLLM infers the
provider from the model name — if the name doesn't have a known prefix it will
try to call `openai.com` and fail with an auth error.

**Rule:** All model names passed to crewai agents **must** be prefixed with
`openai/` and an explicit `base_url` pointing to llama-swap must be provided.

This is handled in `docker/crewai/app/utils/runner.py` by `_make_llm()`:

```python
LLM(
    model=f"openai/{model_name}",
    base_url=os.environ["LLAMA_SWAP_URL"] + "/v1",
    api_key=os.environ.get("OPENAI_API_KEY", "not-needed"),
    temperature=temperature,
)
```

Setting `OPENAI_API_BASE` alone is **not sufficient** — the model name prefix is
also required. `OPENAI_API_KEY` must be set to any non-empty string (LiteLLM
validates presence, not value).

Temperature is applied on the `LLM` object, not on `Agent` directly.

## Tools — RAG / Embedding tools

Several crewai tools (`CSVSearchTool`, `PDFSearchTool`, `TXTSearchTool`,
`JSONSearchTool`, `DOCXSearchTool`, `WebsiteSearchTool`,
`YoutubeVideoSearchTool`) call `/v1/embeddings` internally via chromadb.
**llama-swap does not serve an embeddings endpoint** — these tools will fail
silently unless a separate embedding server is configured.

These tools are marked `requires_config: True` in `docker/crewai/app/utils/tools.py`
and display a ⚠️ warning in the UI until `EMBEDDING_MODEL` is set.

`CodeInterpreterTool` has been **permanently removed** from the registry — it
executes arbitrary Python with access to the `/app/data` volume and is unsafe
without an additional execution sandbox.

## Related components

- `deerflow` (120) — ByteDance research + task workflow (Next.js web UI)
- `flowise` (125) — drag-and-drop LLM chain builder (Node.js web UI)
- `n8n` (127) — workflow automation (Node.js web UI)
- `langflow` (128) — Python-native LLM workflow builder (React + Python)
- `llama-swap` (40) — preferred local inference backend for crews

See [usage.md](./usage.md) for command usage.
