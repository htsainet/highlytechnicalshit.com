#!/usr/bin/env bash
# scripts/components/tailscale.sh — Tailscale VPN: install, configure, connect
#
# Standalone usage:
#   ./scripts/components/tailscale.sh            # install + configure + start + health
#   ./scripts/components/tailscale.sh --health   # health check only
#   ./scripts/components/tailscale.sh --stop     # tailscale down
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
TAILSCALE_AUTHKEY="${TAILSCALE_AUTHKEY:-}"

# ── Functions ────────────────────────────────────────────────────────────────

# tailscale_install — Install Tailscale package
tailscale_install() {
  step "Tailscale — install"
  if tailscale version &>/dev/null; then
    info "Tailscale already installed ($(tailscale version | head -1))"
  else
    info "Installing Tailscale for Ubuntu 24.04 (noble)..."
    sudo apt-get update -qq
    sudo apt-get install -y ca-certificates curl

    curl -fsSL https://pkgs.tailscale.com/stable/ubuntu/noble.noarmor.gpg | \
      sudo tee /usr/share/keyrings/tailscale-archive-keyring.gpg >/dev/null
    curl -fsSL https://pkgs.tailscale.com/stable/ubuntu/noble.tailscale-keyring.list | \
      sudo tee /etc/apt/sources.list.d/tailscale.list >/dev/null

    sudo apt-get update -qq
    sudo apt-get install -y tailscale
  fi

  if ! tailscale version &>/dev/null; then
    fail "Tailscale install failed."
    return 1
  fi
  ok "Tailscale installed."
}

# tailscale_configure — Apply authkey from .env or prompt for it
tailscale_configure() {
  step "Tailscale — configure"

  # Check if already connected
  local ts_status
  ts_status=$(tailscale status 2>&1 || true)
  if echo "$ts_status" | grep -qE "^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"; then
    local ts_ip
    ts_ip=$(tailscale ip -4 2>/dev/null || true)
    info "Already connected (${ts_ip})"
    return 0
  fi

  # Read authkey from .env
  local env_file="$REPO_DIR/.env"
  if [[ -z "$TAILSCALE_AUTHKEY" ]] && [[ -f "$env_file" ]]; then
    TAILSCALE_AUTHKEY=$(grep '^TAILSCALE_AUTHKEY=' "$env_file" | cut -d= -f2- | tr -d '[:space:]' || true)
  fi

  if [[ -z "$TAILSCALE_AUTHKEY" ]]; then
    echo ""
    warn "No TAILSCALE_AUTHKEY found in .env."
    echo "  Option A — Paste a reusable/ephemeral auth key from:"
    echo "             https://login.tailscale.com/admin/settings/keys"
    echo "  Option B — Press Enter to authenticate via browser URL instead."
    echo ""
    read -r -p "  Auth key (or Enter for browser auth): " TAILSCALE_AUTHKEY

    if [[ -n "$TAILSCALE_AUTHKEY" ]]; then
      echo "TAILSCALE_AUTHKEY=${TAILSCALE_AUTHKEY}" >> "$env_file"
      info "Auth key saved to .env."
    fi
  else
    info "TAILSCALE_AUTHKEY: ${TAILSCALE_AUTHKEY:0:10}..."
  fi

  ok "Tailscale configured."
}

# tailscale_start — Connect to Tailscale network
tailscale_start() {
  step "Tailscale — start"

  sudo systemctl enable --now tailscaled 2>/dev/null || true

  if [[ -n "$TAILSCALE_AUTHKEY" ]]; then
    info "Authenticating with auth key..."
    sudo tailscale up --authkey="${TAILSCALE_AUTHKEY}"
  else
    info "Starting browser-based auth..."
    warn "Copy the URL below and open it in a browser to authenticate."
    echo ""
    sudo tailscale up
  fi

  ok "Tailscale connected."
}

# tailscale_stop — Disconnect from Tailscale
tailscale_stop() {
  step "Tailscale — stop"
  sudo tailscale down 2>/dev/null || true
  ok "Tailscale disconnected."
}

# tailscale_health — Check Tailscale connection status
tailscale_health() {
  step "Tailscale — health"
  if ! tailscale version &>/dev/null; then
    warn "Tailscale is not installed."
    return 1
  fi

  local ts_status
  ts_status=$(tailscale status 2>&1 || true)
  if echo "$ts_status" | grep -qE "^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"; then
    local ts_ip
    ts_ip=$(tailscale ip -4 2>/dev/null || echo "unknown")
    ok "Tailscale connected. IP: ${ts_ip}"
    echo ""
    tailscale status
    echo ""
    info "Services reachable over Tailscale at ${ts_ip}:"
    echo "  Open WebUI        : http://${ts_ip}:3000"
    echo "  Ollama API        : http://${ts_ip}:11434"
    echo "  Stable Diffusion  : http://${ts_ip}:7860"
  else
    warn "Tailscale not connected."
  fi
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      tailscale_install
      tailscale_configure
      tailscale_start
      tailscale_health
      ;;
    health)
      tailscale_health
      ;;
    stop)
      tailscale_stop
      ;;
  esac
fi
