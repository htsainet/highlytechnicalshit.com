# Skill Supply Chain Vetting

**Priority:** MEDIUM
**Effort:** 6-8 hours
**Risk:** Low — additive validation layer. Does not block skill installation, only flags risks.
**Target Release:** v0.6.0
**Threat:** Malicious or compromised OpenClaw skills can execute arbitrary code, access the
file system, make network requests, and persist across sessions. Paper 2603.16572 found
0.52% of 238K marketplace skills are genuinely malicious after context-aware analysis.
**Depends on:** Nothing
**Blocks:** Nothing

## Problem

OpenClaw skills (SKILL.md + tool definitions) define agent capabilities. Skills can:

- Execute shell commands
- Read/write files
- Make HTTP requests to arbitrary endpoints
- Persist data across sessions

The current stack has one custom skill (stable-diffusion). As the skill library grows
(or users install third-party skills), the attack surface expands. There is no automated
vetting, no signature verification, and no capability audit.

## Solution

Two-stage vetting process for any new skill:

1. **Static analysis** — scan SKILL.md and tool definitions for suspicious patterns
2. **Repository context** — check provenance (repo age, stars, maintainer, license)

## Implementation Steps

### 1. Create `scripts/utils/skill-vet.sh`

Static analysis checks:

- Network calls to unknown hosts (allowlist: localhost, Ollama, llama-swap)
- File system access outside of expected paths
- Shell command execution patterns
- Credential access patterns (env vars, config files)
- Persistence mechanisms (cron, systemd, startup scripts)

### 2. Create `resources/agents/skill-allowlist.json`

Allowlist of vetted skills with SHA256 hashes. New skills must pass vetting before
being added to the allowlist.

### 3. Add pre-commit check

Validate that all skills in `.openclaw/skills/` are either in the allowlist or
flagged for review.

### 4. Add Pester test

Test that no unvetted skills are present in the deployment.

## Acceptance Criteria

- [ ] Vet script flags test skill with known-bad patterns
- [ ] Vet script passes for existing stable-diffusion skill
- [ ] Allowlist prevents unauthorized skill additions
- [ ] Pre-commit hook catches unvetted skills

## Paper References

- 2603.16572 — 238K skill ecosystem, 0.52% true positive malicious rate
- 2603.11619 — initialization-stage skill contamination
- slowmist/openclaw-security-practice-guide — skill audit methodology
- adversa-ai/secureclaw — OWASP ASI skill scanning patterns
