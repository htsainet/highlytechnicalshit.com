#!/usr/bin/env bash
# scripts/utils/upgrade-nemoclaw.sh — Full NemoClaw + OpenClaw upgrade
#
# Updates the NemoClaw CLI, re-onboards sandboxes to get the latest OpenShell
# gateway images and OpenClaw versions, and verifies health.
#
# Usage:
#   ./scripts/utils/upgrade-nemoclaw.sh             # full upgrade (CLI + re-onboard)
#   ./scripts/utils/upgrade-nemoclaw.sh --cli-only   # update NemoClaw CLI only
#   ./scripts/utils/upgrade-nemoclaw.sh --sandbox-only  # update OpenClaw inside sandboxes only
#
# Why this exists:
#   The "Update now" button inside the OpenClaw Gateway Dashboard does NOT work
#   in NemoClaw-managed environments. NemoClaw owns the OpenShell lifecycle,
#   so updates must go through `nemoclaw onboard` (not `openshell self-update`).
#   See: https://github.com/NVIDIA/NemoClaw#openshell-lifecycle
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

# ── NVM helper ───────────────────────────────────────────────────────────────
_source_nvm() {
  NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
  set +eu
  # shellcheck disable=SC1091
  if [[ -s "$NVM_DIR/nvm.sh" ]]; then source "$NVM_DIR/nvm.sh"; fi
  set -eu
}

# ── Upgrade the NemoClaw CLI from source ─────────────────────────────────────
upgrade_nemoclaw_cli() {
  step "Upgrading NemoClaw CLI"
  _source_nvm

  local old_version
  old_version=$(nemoclaw --version 2>/dev/null || echo "not installed")
  info "Current NemoClaw CLI: ${old_version}"

  local nemoclaw_src="$HOME/.nemoclaw/source"
  local npm_bin npm_prefix
  npm_bin=$(command -v npm)
  npm_prefix=$("$npm_bin" config get prefix)

  # Unlink existing install so npm link will overwrite cleanly
  if [[ -d "$nemoclaw_src" ]]; then
    info "Removing previous NemoClaw source..."
    (cd "$nemoclaw_src" && "$npm_bin" unlink 2>/dev/null || true)
    rm -rf "$nemoclaw_src"
  fi

  # Resolve latest release ref
  local release_ref=""
  release_ref=$(curl -fsSL --max-time 10 \
    https://api.github.com/repos/NVIDIA/NemoClaw/releases/latest 2>/dev/null \
    | grep '"tag_name"' | sed -E 's/.*"tag_name":[[:space:]]*"([^"]+)".*/\1/' | head -1 || true)
  if ! [[ "$release_ref" =~ ^v[0-9] ]]; then
    release_ref=$(curl -fsSL --max-time 10 \
      https://api.github.com/repos/NVIDIA/NemoClaw/tags?per_page=20 2>/dev/null \
      | grep '"name"' | sed -E 's/.*"name":[[:space:]]*"([^"]+)".*/\1/' \
      | grep -E '^v[0-9]' | head -1 || true)
  fi
  [[ "$release_ref" =~ ^v[0-9] ]] || release_ref="main"
  info "Target ref: ${release_ref}"

  mkdir -p "$(dirname "$nemoclaw_src")"
  git clone --depth 1 --branch "$release_ref" https://github.com/NVIDIA/NemoClaw.git "$nemoclaw_src"

  (cd "$nemoclaw_src" && "$npm_bin" install --ignore-scripts)
  # NOTE: Do NOT run `npm audit fix` here. Upstream NVIDIA never does.
  # It can break pinned dependency versions and cause silent CLI failures.
  (cd "$nemoclaw_src/nemoclaw" && "$npm_bin" install --ignore-scripts)
  (cd "$nemoclaw_src/nemoclaw" && "$npm_bin" run build)
  (cd "$nemoclaw_src" && "$npm_bin" link)

  local new_version
  new_version=$(nemoclaw --version 2>/dev/null || echo "unknown")
  ok "NemoClaw CLI upgraded: ${old_version} → ${new_version}"
}

# ── Re-onboard sandboxes (pulls latest gateway + OpenClaw images) ────────────
upgrade_sandboxes() {
  step "Re-onboarding NemoClaw sandboxes"
  info "This recreates the OpenShell gateway and sandbox pods with latest images."
  info "Running: scripts/components/nemoclaw.sh (onboard + configure + health)"

  # The component script handles the full lifecycle: cgroup fix, onboard,
  # registry patching, provider config, port forwards, tokens, personas.
  bash "$REPO_DIR/scripts/components/nemoclaw.sh"
}

# ── Update OpenClaw inside sandboxes via re-onboard (the supported path) ──────
upgrade_openclaw_only() {
  step "Updating OpenClaw inside sandboxes"
  info "Per NVIDIA guidance, using nemoclaw onboard (not npm install inside sandboxes)."
  info "Running: scripts/components/nemoclaw.sh --update"
  bash "$REPO_DIR/scripts/components/nemoclaw.sh" --update
}

# ── Health check ─────────────────────────────────────────────────────────────
verify_health() {
  step "Verifying NemoClaw health"
  bash "$REPO_DIR/scripts/components/nemoclaw.sh" --health
}

# ── Main ─────────────────────────────────────────────────────────────────────
main() {
  local mode="full"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --cli-only)      mode="cli"; shift ;;
      --sandbox-only)  mode="sandbox"; shift ;;
      --help|-h)
        echo "Usage: $(basename "$0") [--cli-only | --sandbox-only]"
        echo ""
        echo "  (no flag)        Full upgrade: NemoClaw CLI + re-onboard sandboxes"
        echo "  --cli-only       Update the NemoClaw CLI only (no sandbox changes)"
        echo "  --sandbox-only   Update OpenClaw inside sandboxes only (no CLI change)"
        echo ""
        echo "The 'Update now' button in the OpenClaw Gateway Dashboard does NOT work"
        echo "in NemoClaw-managed environments. Use this script instead."
        exit 0
        ;;
      *) shift ;;
    esac
  done

  case "$mode" in
    full)
      upgrade_nemoclaw_cli
      upgrade_sandboxes
      verify_health
      ;;
    cli)
      upgrade_nemoclaw_cli
      ;;
    sandbox)
      upgrade_openclaw_only
      verify_health
      ;;
  esac

  ok "NemoClaw upgrade complete."
}

main "$@"
