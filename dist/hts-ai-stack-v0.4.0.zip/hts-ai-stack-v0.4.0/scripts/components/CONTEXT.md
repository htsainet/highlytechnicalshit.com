# Component Scripts

Last updated: 2026-04-15

## What happens here

Each component manages the full lifecycle (install, start, stop, health, remove) of a single stack service. Component scripts can run standalone or be sourced by bundle scripts for individual function access.

## Structure

Components are organized in per-component subfolders:

```text
scripts/components/
  {service}/
    {service}.sh               # lifecycle script
    {service}.manifest.json    # metadata and config schema
    CONTEXT.md                 # per-component context (optional)
```

During the migration from the flat layout, some components may still
exist as flat files (`{service}.sh` and `{service}.manifest.json`)
directly in this directory. The manifest loader supports both layouts.

## Process / Workflow

1. Bundle script (e.g. `bundles/chat.sh`) sources component scripts for the services it needs
2. Each component exposes functions like `{service}_install()`, `{service}_start()`, `{service}_health()`
3. When run standalone, a component installs + starts + health-checks its service
4. All components source `lib/common.sh` and optionally `lib/compose.sh`, `lib/health.sh`

## Files and structure

| File | Service | Notes |
|------|---------|-------|
| `nemoclaw/nemoclaw.sh` | NemoClaw sandbox | NVIDIA security enforcement. Flags: `--update` (OpenClaw binary), `--upgrade` handled by `utils/upgrade-nemoclaw.sh` |
| `ollama.sh` | Ollama LLM inference | Model pull, swap (lean/mean/claw), health |
| `open-webui.sh` | Open WebUI chat frontend | |
| `bitnet.sh` | BitNet 1-bit LLM | Docker build from `docker/bitnet/` |
| `llama-swap.sh` | llama-swap model router | GPU/CPU flip-flop scheduling |
| `openspace.sh` | OpenSpace agent skills | |
| `dashboard.sh` | Nginx dashboard | Landing page on port 80 |
| `gitea.sh` | Gitea self-hosted Git | |
| `stable-diffusion.sh` | Stable Diffusion | Image generation |
| `comfyui.sh` | ComfyUI | Visual workflow for SD |
| `sillytavern.sh` | SillyTavern | Character card management |
| `deerflow.sh` | DeerFlow | Multi-agent orchestration |
| `gvisor-sandbox.sh` | gVisor Sandbox | CPU agent sandbox — OpenClaw on runsc |
| `unsloth.sh` | Unsloth | Fine-tuning toolkit |
| `signal.sh` | Signal messenger | Bot integration |
| `telegram.sh` | Telegram bot | Bot integration |
| `tailscale.sh` | Tailscale VPN | Mesh networking |
| `duplicati.sh` | Duplicati backup | Backup automation |
| `timeshift.sh` | Timeshift snapshots | System restore points |

## Manifest schema

Every component has a `{service}.manifest.json`. Key fields:

| Field | Required | Notes |
|-------|----------|-------|
| `id` | ✅ | Matches folder/script name |
| `display_name` | ✅ | Human-readable label |
| `order` | ✅ | Sort order within category |
| `category` | ✅ | e.g. `agents`, `inference`, `tools` |
| `install_type` | ✅ | `compose`, `script`, `host`, `host-interactive` |
| `profile` | compose only | Docker Compose profile name |
| `health.url` | ✅ | Health-check endpoint |
| `dashboard` | ✅ | Port, title, section, description for the landing page |
| `vram_minimum` | ✅ | Minimum VRAM MB (0 = CPU-only) |
| `upstream` | ✅ | Source tracking — see below |

### `upstream` field (required for all new components)

The manifest's `upstream` block is the **canonical source of truth** for where a
component should be installed from. `REFERENCES.md` mirrors this for humans; on
any conflict, the manifest wins. Any install step not traceable to the
`install_docs` URL below is a deviation and must be recorded in `DEVIATIONS.md`.

```json
"upstream": {
  "vendor":         "crewAIInc",
  "repo":           "https://github.com/crewAIInc/crewAI",
  "docs":           "https://docs.crewai.com",
  "install_docs":   "https://docs.crewai.com/installation",
  "install_method": "docker-image",
  "image":          "hts-ai-crewai",
  "artifact":       "crewai",
  "pinned_version": "0.70.1"
}
```

| Sub-field | Required | Notes |
|-----------|----------|-------|
| `vendor` | ✅ | Org / maintainer name (e.g. `KDE`, `NVIDIA`, `crewAIInc`) |
| `repo` | ✅ | Upstream source repository |
| `docs` | ✅ | Upstream documentation landing page |
| `install_docs` | ✅ | Direct URL to the install/quickstart page we follow |
| `install_method` | ✅ | One of: `apt`, `flatpak`, `snap`, `docker-image`, `docker-build`, `script`, `pip`, `npm`, `source`, `host-binary` |
| `pinned_version` | ✅ | Version/tag we install; `latest` is not acceptable |
| `image` | compose only | Our built image name, or upstream pre-built image (e.g. `ghcr.io/org/img`) |
| `artifact` | optional | Package/binary name when `install_method` is `apt`, `flatpak`, `snap`, `pip`, `npm` |

CrewAI is the reference example. Update `upstream` when creating or updating any
component manifest. If any required field is unknown, open a TODO and fill it
before the component ships.

- One file per service — no multi-service scripts
- Filename matches the service name (lowercase, kebab-case)
- Can run standalone (`./scripts/components/ollama/ollama.sh`) or be sourced by bundles
- Functions follow `{service}_install`, `{service}_start`, `{service}_stop`, `{service}_health` pattern
- All components source `lib/common.sh` for consistent logging and environment

## Tools and skills

- **Docker Compose** — Most services managed via `lib/compose.sh` wrappers
- **Bash** — Script language for all components
- **curl** — Health checks via `lib/health.sh`
