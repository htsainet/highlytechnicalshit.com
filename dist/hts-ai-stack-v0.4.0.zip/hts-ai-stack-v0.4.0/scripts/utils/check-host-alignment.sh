#!/usr/bin/env bash
# check-host-alignment.sh — Unified host-state alignment check
#
# Cross-references prerequisites.json, stack.json, manifest.json,
# and Docker service state to produce an alignment report.
#
# Usage:
#   ./check-host-alignment.sh            # human-readable summary
#   ./check-host-alignment.sh --json     # structured JSON report
#   ./check-host-alignment.sh --scope core  # check only 'core' scope
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

PREREQ_FILE="$REPO_DIR/scripts/host/prerequisites.json"
STACK_JSON="$REPO_DIR/config/stack.json"
MANIFEST_FILE="$REPO_DIR/logs/manifest.json"
COMPOSE_FILE="$REPO_DIR/docker-compose.yml"

# ── Parse arguments ──────────────────────────────────────────────────────────
JSON_OUTPUT=false
SCOPE_FILTER=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --json)  JSON_OUTPUT=true; shift ;;
    --scope) SCOPE_FILTER="$2"; shift 2 ;;
    --help|-h)
      echo "Usage: $0 [--json] [--scope <scope>]"
      echo "Scopes: core, optional, networking, service, admin, dev, tooling"
      exit 0
      ;;
    *) fail "Unknown argument: $1" ;;
  esac
done

# ── Preflight ────────────────────────────────────────────────────────────────
[[ -f "$PREREQ_FILE" ]] || fail "prerequisites.json not found at $PREREQ_FILE"
command -v jq &>/dev/null || fail "jq is required but not installed"

# ── Determine active scopes from stack.json ──────────────────────────────────
# Scope activation rules:
#   core       — always required
#   optional   — always checked (user may not need all, but we report them)
#   dev        — requires admin.install_dev_tools == true
#   admin      — requires items present in admin.tools array
#   networking — always checked
#   service    — always checked
#   tooling    — always checked
active_scopes() {
  local scopes=("core" "optional" "networking" "service" "tooling")

  if [[ -f "$STACK_JSON" ]]; then
    # dev scope: gated on install_dev_tools
    if jq -e '.admin.install_dev_tools == true' "$STACK_JSON" &>/dev/null; then
      scopes+=("dev")
    fi
    # admin scope: gated on admin.tools having entries
    if jq -e '.admin.tools | length > 0' "$STACK_JSON" &>/dev/null; then
      scopes+=("admin")
    fi
  fi

  printf '%s\n' "${scopes[@]}"
}

# ── Check if a specific admin package is needed ──────────────────────────────
admin_pkg_needed() {
  local pkg="$1"
  [[ -f "$STACK_JSON" ]] || return 1
  case "$pkg" in
    openssh-server)  jq -e '.admin.tools | index("ssh_server")'  "$STACK_JSON" &>/dev/null ;;
    *)               return 0 ;;  # unknown admin packages: assume needed
  esac
}

# ── Check package installation ───────────────────────────────────────────────
pkg_installed() {
  local pkg="$1"
  dpkg -s "$pkg" &>/dev/null || command -v "$pkg" &>/dev/null
}

# ── Get version from manifest or dpkg ────────────────────────────────────────
pkg_version() {
  local pkg="$1"
  # Try manifest first
  if [[ -f "$MANIFEST_FILE" ]]; then
    local ver
    ver=$(jq -r --arg c "$pkg" '.[] | select(.component == $c) | .version' "$MANIFEST_FILE" 2>/dev/null | head -1)
    if [[ -n "$ver" && "$ver" != "null" && "$ver" != "unknown" ]]; then
      echo "$ver"
      return
    fi
  fi
  # Fall back to dpkg
  dpkg -s "$pkg" 2>/dev/null | awk '/^Version:/ {print $2}' | head -1
}

# ══════════════════════════════════════════════════════════════════════════════
# 1. PREREQUISITE ALIGNMENT
# ══════════════════════════════════════════════════════════════════════════════

declare -a PKG_RESULTS=()
TOTAL=0; INSTALLED=0; MISSING=0; SKIPPED=0

if [[ -n "$SCOPE_FILTER" ]]; then
  SCOPES_TO_CHECK=("$SCOPE_FILTER")
else
  mapfile -t SCOPES_TO_CHECK < <(active_scopes)
fi

for scope in "${SCOPES_TO_CHECK[@]}"; do
  while IFS=$'\t' read -r pkg reason installer; do
    TOTAL=$((TOTAL + 1))

    # Admin scope: skip packages not enabled in stack.json
    if [[ "$scope" == "admin" ]] && ! admin_pkg_needed "$pkg"; then
      SKIPPED=$((SKIPPED + 1))
      PKG_RESULTS+=("{\"package\":\"$pkg\",\"scope\":\"$scope\",\"status\":\"skipped\",\"reason\":\"not enabled in stack.json\"}")
      continue
    fi

    if pkg_installed "$pkg"; then
      INSTALLED=$((INSTALLED + 1))
      ver=$(pkg_version "$pkg")
      PKG_RESULTS+=("{\"package\":\"$pkg\",\"scope\":\"$scope\",\"status\":\"installed\",\"version\":\"${ver:-unknown}\"}")
    else
      MISSING=$((MISSING + 1))
      PKG_RESULTS+=("{\"package\":\"$pkg\",\"scope\":\"$scope\",\"status\":\"missing\",\"installer\":\"$installer\",\"reason\":\"$reason\"}")
    fi
  done < <(jq -r --arg s "$scope" \
    '.prerequisites[] | select(.scope == $s) | [.package, .reason, .installer] | @tsv' \
    "$PREREQ_FILE")
done

# ══════════════════════════════════════════════════════════════════════════════
# 2. DOCKER SERVICE ALIGNMENT
# ══════════════════════════════════════════════════════════════════════════════

declare -a SVC_RESULTS=()
DOCKER_OK=true

if command -v docker &>/dev/null && docker info &>/dev/null 2>&1; then
  # Map stack.json features to expected Docker service profiles
  declare -A FEATURE_PROFILES=(
    ["dashboard"]="dashboard.enabled"
    ["ollama-gpu"]="_always"
    ["open-webui"]="_always"
  )

  # Conditional features
  if [[ -f "$STACK_JSON" ]]; then
    if jq -e '.sandbox.nemoclaw == true' "$STACK_JSON" &>/dev/null; then
      FEATURE_PROFILES["llama-swap"]="sandbox.nemoclaw"
    fi
  fi

  # Check running containers with our label
  for svc in "${!FEATURE_PROFILES[@]}"; do
    container="hts-ai-${svc}"
    feature="${FEATURE_PROFILES[$svc]}"

    if docker inspect "$container" &>/dev/null 2>&1; then
      status=$(docker inspect --format '{{.State.Status}}' "$container" 2>/dev/null || echo "unknown")
      health=$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$container" 2>/dev/null || echo "unknown")
      has_label=$(docker inspect --format '{{index .Config.Labels "com.htsai.stack"}}' "$container" 2>/dev/null || echo "")
      SVC_RESULTS+=("{\"container\":\"$container\",\"status\":\"$status\",\"health\":\"$health\",\"labeled\":$([ "$has_label" = "hts-ai-stack" ] && echo true || echo false)}")
    else
      SVC_RESULTS+=("{\"container\":\"$container\",\"status\":\"not-found\",\"feature\":\"$feature\"}")
    fi
  done
else
  DOCKER_OK=false
fi

# ══════════════════════════════════════════════════════════════════════════════
# 3. MANIFEST CHECK
# ══════════════════════════════════════════════════════════════════════════════

MANIFEST_EXISTS=false
MANIFEST_COUNT=0
if [[ -f "$MANIFEST_FILE" ]]; then
  MANIFEST_EXISTS=true
  MANIFEST_COUNT=$(jq 'length' "$MANIFEST_FILE" 2>/dev/null || echo 0)
fi

# ══════════════════════════════════════════════════════════════════════════════
# OUTPUT
# ══════════════════════════════════════════════════════════════════════════════

ALIGNED=true
[[ "$MISSING" -gt 0 ]] && ALIGNED=false

if [[ "$JSON_OUTPUT" == "true" ]]; then
  # ── JSON output ──────────────────────────────────────────────────────────
  PKG_JSON=$(printf '%s\n' "${PKG_RESULTS[@]}" | jq -s '.')
  SVC_JSON="[]"
  if [[ ${#SVC_RESULTS[@]} -gt 0 ]]; then
    SVC_JSON=$(printf '%s\n' "${SVC_RESULTS[@]}" | jq -s '.')
  fi

  jq -n \
    --argjson aligned "$ALIGNED" \
    --arg    timestamp "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" \
    --argjson total "$TOTAL" \
    --argjson installed "$INSTALLED" \
    --argjson missing "$MISSING" \
    --argjson skipped "$SKIPPED" \
    --argjson manifest_exists "$MANIFEST_EXISTS" \
    --argjson manifest_entries "$MANIFEST_COUNT" \
    --argjson docker_available "$DOCKER_OK" \
    --argjson packages "$PKG_JSON" \
    --argjson services "$SVC_JSON" \
    '{
      aligned: $aligned,
      timestamp: $timestamp,
      summary: {
        total: $total,
        installed: $installed,
        missing: $missing,
        skipped: $skipped
      },
      manifest: {
        exists: $manifest_exists,
        entries: $manifest_entries
      },
      docker: {
        available: $docker_available,
        services: $services
      },
      packages: $packages
    }'
else
  # ── Human-readable output ────────────────────────────────────────────────
  banner
  step "Host Alignment Check"

  # Active scopes
  info "Active scopes: $(IFS=', '; echo "${SCOPES_TO_CHECK[*]}")"
  echo ""

  # Prerequisites
  step "Prerequisites ($TOTAL packages)"

  # Group by scope for cleaner output
  for scope in "${SCOPES_TO_CHECK[@]}"; do
    scope_missing=()
    scope_installed=0
    scope_total=0

    for entry in "${PKG_RESULTS[@]}"; do
      entry_scope=$(echo "$entry" | jq -r '.scope')
      [[ "$entry_scope" != "$scope" ]] && continue
      scope_total=$((scope_total + 1))
      entry_status=$(echo "$entry" | jq -r '.status')
      entry_pkg=$(echo "$entry" | jq -r '.package')
      if [[ "$entry_status" == "installed" ]]; then
        scope_installed=$((scope_installed + 1))
      elif [[ "$entry_status" == "missing" ]]; then
        scope_missing+=("$entry_pkg")
      fi
    done

    [[ "$scope_total" -eq 0 ]] && continue

    if [[ ${#scope_missing[@]} -eq 0 ]]; then
      ok "$scope: $scope_installed/$scope_total installed"
    else
      warn "$scope: $scope_installed/$scope_total installed — MISSING: ${scope_missing[*]}"
    fi
  done

  # Docker services
  echo ""
  step "Docker Services"

  if [[ "$DOCKER_OK" == "true" ]]; then
    if [[ ${#SVC_RESULTS[@]} -gt 0 ]]; then
      for entry in "${SVC_RESULTS[@]}"; do
        cname=$(echo "$entry" | jq -r '.container')
        status=$(echo "$entry" | jq -r '.status')
        health=$(echo "$entry" | jq -r '.health // "n/a"')
        labeled=$(echo "$entry" | jq -r '.labeled // false')
        if [[ "$status" == "running" ]]; then
          label_flag=""
          [[ "$labeled" == "true" ]] && label_flag=" [labeled]"
          ok "$cname: running (health: $health)$label_flag"
        elif [[ "$status" == "not-found" ]]; then
          warn "$cname: not running"
        else
          warn "$cname: $status (health: $health)"
        fi
      done
    fi
  else
    warn "Docker daemon not available — skipping service checks"
  fi

  # Manifest
  echo ""
  step "Install Manifest"

  if [[ "$MANIFEST_EXISTS" == "true" ]]; then
    ok "manifest.json: $MANIFEST_COUNT entries"
  else
    info "manifest.json: not yet created (run installer to populate)"
  fi

  # Summary
  echo ""
  step "Summary"

  if [[ "$ALIGNED" == "true" ]]; then
    ok "Host is aligned — $INSTALLED/$TOTAL prerequisites installed, $SKIPPED skipped"
  else
    warn "Host has drift — $MISSING/$TOTAL prerequisites missing"
    echo ""
    info "To fix: ./scripts/utils/remediate-prerequisites.sh"
  fi
fi

# Exit code: 0 = aligned, 1 = drift
[[ "$ALIGNED" == "true" ]]
