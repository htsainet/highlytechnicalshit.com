# FEATURE-059 — Vaultwarden (Self-Hosted Bitwarden) Password Manager

| Field | Value |
|-------|-------|
| Status | Proposed |
| Category | Security / Credential Management |
| Target Release | v0.5.0 |
| Priority | HIGH |
| Effort | M |
| Components | `vaultwarden` (new) |
| Dependencies | FEATURE-055 (Authelia SSO + Traefik) — vaultwarden sits behind it |
| Related | FEATURE-060 (YubiKey), SECURITY-009 (secret scoping) |

## Summary

Add a self-hosted Bitwarden-compatible password manager (Vaultwarden,
Rust rewrite of the Bitwarden server) as a new stack component. Gives
the user a local, encrypted credential vault usable from all official
Bitwarden clients (web, desktop, mobile, browser extension, CLI).

This closes the loop on the credential plane:
- **Authelia** (FEATURE-055) = SSO for all stack apps
- **Vaultwarden** = vault for the one Authelia master + API tokens + all non-stack logins
- **YubiKey** (FEATURE-060) = hardware 2FA for both of the above

## Why Vaultwarden over hosted options

| Factor | Vaultwarden | 1Password | Bitwarden Cloud | Proton Pass |
|---|---|---|---|---|
| Self-hosted | ✅ | ❌ | ❌ | ❌ |
| Open source | ✅ | ❌ | Partial | Clients only |
| Resource footprint | ~50MB RAM | N/A | N/A | N/A |
| Official Bitwarden clients compatible | ✅ | ❌ | ✅ | ❌ |
| Cost | Free | $36/yr | Free/tier | $24/yr |
| Matches stack philosophy (100% local) | ✅ | ❌ | ❌ | ❌ |

Aligns with the same "no cloud IdP" decision that drove Authelia over
Cloudflare Access.

## Architecture

```
Client (browser ext / mobile / desktop)
  ↓ HTTPS
Traefik (TLS termination)
  ↓ forward-auth (optional — see below)
Authelia
  ↓
Vaultwarden container
  ↓
SQLite volume (encrypted by vault master password)
```

**Auth tier:** `gated` or `bypass` — see Open Questions. Vaultwarden has
its own strong auth (Argon2id master password + optional 2FA), and
putting Authelia in front can interfere with mobile/browser extension
sync flows. Recommended: **bypass Authelia, rely on Vaultwarden's own
master-password + YubiKey**. L3 microsegmentation (FEATURE-056) still
limits network reach.

## Phases

### Phase 1 — Component + basic install
- `scripts/components/vaultwarden/vaultwarden.sh` — lifecycle
- `scripts/components/vaultwarden/vaultwarden.manifest.json`
- docker-compose service: vaultwarden/server image (official), SQLite
  backend (default; Postgres option for heavier use)
- Volume: `vaultwarden_data` for vault + attachments
- Env: `ADMIN_TOKEN` generated at install (for `/admin` panel)
- Port: 8222 (host) → 80 (container)

### Phase 2 — Traefik integration
- Subdomain: `vault.hts.local`
- TLS via mkcert wildcard (from FEATURE-055)
- WebSocket routing for live sync (`/notifications/hub`)
- Decision on Authelia bypass vs. gated (Phase 1 ships as bypass;
  can tighten later)

### Phase 3 — Client configuration
- Docs for pointing official Bitwarden apps at `https://vault.hts.local`
- mkcert CA export to Android/iOS/other devices for wildcard cert trust
- Browser extension setup guide
- `bw` CLI configuration for terminal workflows

### Phase 4 — Backup & recovery
- Hook into Duplicati: add `vaultwarden_data` volume to default backup job
- Document emergency-export workflow (encrypted JSON export to USB)
- Master password recovery: there isn't one. Document this clearly.
  Mitigation: YubiKey 2FA + emergency export kept in a safe place.

### Phase 5 — Organization / shared vaults (optional later)
- Vaultwarden supports orgs/collections for free (unlike Bitwarden Cloud)
- Useful for a household/fiancé shared-vault in the future
- Out of scope for initial deployment but worth documenting as available

## Defaults

| Setting | Value |
|---|---|
| `SIGNUPS_ALLOWED` | `false` (admin invites only after first user) |
| `ADMIN_TOKEN` | Generated 64-char at install, stored in `.env` (0600) |
| `PASSWORD_HINTS_ALLOWED` | `false` |
| `WEBSOCKET_ENABLED` | `true` |
| `SMTP_*` | unconfigured by default (no email) |
| `DOMAIN` | `https://vault.hts.local` |

## Secrets in `.env`

- `VAULTWARDEN_ADMIN_TOKEN` (64 bytes)
- Backed up via pre-nuke-checklist

## Risks & mitigations

| Risk | Mitigation |
|---|---|
| Master password loss = data loss | YubiKey 2FA + emergency export; document clearly |
| Vaultwarden DB corruption | Regular Duplicati backups of the volume |
| Browser extension not trusting wildcard cert | Document mkcert CA export per-device |
| Mobile app won't connect behind Authelia | Default to Authelia-bypass for vaultwarden |
| Single point of failure for all credentials | Backup vault + test restore quarterly |
| Supply-chain (vaultwarden image compromise) | Pin digests (pin-docker-images.sh), watch upstream |

## Acceptance criteria

- [ ] Vaultwarden installs as a component; health check passes
- [ ] Accessible at `https://vault.hts.local` with valid mkcert TLS
- [ ] Official Bitwarden browser extension syncs against it
- [ ] Official Bitwarden mobile app syncs against it
- [ ] `bw` CLI authenticates and lists entries
- [ ] Backup of `vaultwarden_data` volume via Duplicati works
- [ ] Documented YubiKey 2FA enrollment flow
- [ ] Emergency export procedure documented and tested

## Out of scope

- SMTP / email-based flows (password reset, invites via email) — can
  add later if wanted
- Postgres backend (SQLite is plenty for personal use)
- Cross-stack SSO via SCIM / OIDC provider role
- Self-hosted Bitwarden (not Vaultwarden) — heavier, .NET-based, overkill
