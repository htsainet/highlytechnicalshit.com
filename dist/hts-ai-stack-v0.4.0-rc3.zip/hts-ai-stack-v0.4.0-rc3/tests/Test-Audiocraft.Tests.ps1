$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/audiocraft'
    $script:ComponentScript = Join-Path $script:ComponentDir 'audiocraft.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'audiocraft.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'audiocraft file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }

    It 'CONTEXT.md exists' {
        Join-Path $script:RepoRoot 'CONTEXT.md' | Should -Exist
    }

    It 'REFERENCES.md exists' {
        Join-Path $script:RepoRoot 'REFERENCES.md' | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'audiocraft manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is audiocraft' {
        $script:Manifest.id | Should -Be 'audiocraft'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/audiocraft/audiocraft.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is audiocraft_' {
        $script:Manifest.func_prefix | Should -Be 'audiocraft_'
    }

    It 'dashboard port is 8602' {
        [int]$script:Manifest.dashboard.port | Should -Be 8602
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'audiocraft component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines audiocraft_install function' {
        $script:ComponentContent | Should -Match 'audiocraft_install\s*\(\)'
    }

    It 'defines audiocraft_configure function' {
        $script:ComponentContent | Should -Match 'audiocraft_configure\s*\(\)'
    }

    It 'defines audiocraft_start function' {
        $script:ComponentContent | Should -Match 'audiocraft_start\s*\(\)'
    }

    It 'defines audiocraft_stop function' {
        $script:ComponentContent | Should -Match 'audiocraft_stop\s*\(\)'
    }

    It 'defines audiocraft_health function' {
        $script:ComponentContent | Should -Match 'audiocraft_health\s*\(\)'
    }

    It 'defines audiocraft_restart function' {
        $script:ComponentContent | Should -Match 'audiocraft_restart\s*\(\)'
    }

    It 'defines audiocraft_destroy function' {
        $script:ComponentContent | Should -Match 'audiocraft_destroy\s*\(\)'
    }

    It 'defines audiocraft_status function' {
        $script:ComponentContent | Should -Match 'audiocraft_status\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/audiocraft/audiocraft\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'audiocraft port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8602 is registered in portmap.json' {
        if ($script:Portmap.ports.PSObject.Properties['8602']) {
            $script:Portmap.ports.'8602' | Should -Not -BeNullOrEmpty
            $script:Portmap.ports.'8602'.service | Should -Be 'audiocraft'
        } else {
            Set-ItResult -Skipped -Because 'port 8602 not yet registered in portmap.json'
        }
    }
}

# ── Docker file existence ────────────────────────────────────────────────────

Describe 'audiocraft Docker artifacts' {

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/audiocraft/Dockerfile' | Should -Exist
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'audiocraft no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/audiocraft\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/audiocraft/audiocraft\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
