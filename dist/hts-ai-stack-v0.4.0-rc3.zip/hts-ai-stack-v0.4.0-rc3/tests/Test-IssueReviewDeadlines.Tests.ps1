$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:IssueFile = Join-Path $script:RepoRoot 'docs/development/issues/setup-issues.md'
}

Describe 'Issue review deadlines' {

    BeforeAll {
        $script:OverdueIssues = [System.Collections.Generic.List[string]]::new()

        if (Test-Path $script:IssueFile) {
            $content = Get-Content $script:IssueFile -Raw

            # Find all issues with status: fixed-pending-review and a Review by: date
            $pattern = '(?ms)^### (ISSUE-\d+).*?- Review by:\s*(\d{4}-\d{2}-\d{2}).*?- Status:\s*fixed-pending-review'
            $matches = [regex]::Matches($content, $pattern)

            foreach ($m in $matches) {
                $issueId = $m.Groups[1].Value
                $reviewDate = [datetime]::ParseExact($m.Groups[2].Value, 'yyyy-MM-dd', $null)
                if ([datetime]::Now.Date -gt $reviewDate) {
                    $daysOverdue = ([datetime]::Now.Date - $reviewDate).Days
                    $script:OverdueIssues.Add("$issueId — review was due $($m.Groups[2].Value) ($daysOverdue days overdue)")
                }
            }
        }
    }

    It 'setup-issues.md exists' {
        $script:IssueFile | Should -Exist
    }

    It 'no fixed-pending-review issues are past their review deadline' {
        if ($script:OverdueIssues.Count -gt 0) {
            $detail = $script:OverdueIssues -join "`n  "
            "Overdue issues:`n  $detail" | Should -Be '' -Because 'all fixed-pending-review issues must be reviewed by their deadline'
        }
    }
}
