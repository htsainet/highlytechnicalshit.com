# CogVideoX Component

Last updated: 2026-04-17

## What happens here

CogVideoX is ZhipuAI/Tsinghua's text-to-video generation model. The 2B
variant fits in ~6GB VRAM, making it viable on RTX 3060 (12GB). Runs as
a Dockerised Gradio web app on port 7865.

## Files and structure

| File | Purpose |
|------|---------|
| `cogvideox.sh` | Full lifecycle: install, configure, start, stop, health |
| `cogvideox.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- Runs in Docker with NVIDIA GPU passthrough (CUDA)
- Default model: `THUDM/CogVideoX-2b` (2B params, ~6GB VRAM)
- Upgradeable to `CogVideoX-5b` (5B params, ~12GB VRAM)
- Models auto-download from HuggingFace on first start
- Generates 6-second video clips from text prompts
- Apache 2.0 license
