BeforeAll {
    $RepoRoot = Split-Path -Parent $PSScriptRoot
    $NemoclawScript = Join-Path $RepoRoot "scripts/components/nemoclaw/nemoclaw.sh"
    $NemoclawContent = Get-Content $NemoclawScript -Raw

    $HtsclawFirewall  = Join-Path $RepoRoot "scripts/htsclaw/sandbox/firewall.sh"
    $HtsclawTokens    = Join-Path $RepoRoot "scripts/htsclaw/dashboard/tokens.sh"
    $HtsclawOrigins   = Join-Path $RepoRoot "scripts/htsclaw/dashboard/origins.sh"

    $HtsclawFirewallContent = Get-Content $HtsclawFirewall -Raw
    $HtsclawTokensContent   = Get-Content $HtsclawTokens -Raw
    $HtsclawOriginsContent  = Get-Content $HtsclawOrigins -Raw
}

Describe "Security Parity — htsclaw ≥ NemoClaw" {

    Context "Firewall — UFW rules" {

        It "NemoClaw allows SSH (22/tcp)" {
            $NemoclawContent | Should -Match "ufw allow 22/tcp"
        }

        It "htsclaw allows SSH (22/tcp)" {
            $HtsclawFirewallContent | Should -Match "ufw allow 22/tcp"
        }

        It "NemoClaw restricts llama-swap to Docker subnet (172.16.0.0/12)" {
            $NemoclawContent | Should -Match '172\.16\.0\.0/12'
            $NemoclawContent | Should -Match 'ufw allow from.*docker_subnet.*swap_port.*proto tcp'
        }

        It "htsclaw restricts llama-swap to Docker subnet (172.16.0.0/12)" {
            $HtsclawFirewallContent | Should -Match '172\.16\.0\.0/12'
            $HtsclawFirewallContent | Should -Match 'ufw allow from.*docker_subnet.*LLAMA_SWAP_PORT.*proto tcp'
        }

        It "NemoClaw denies llama-swap from LAN/WAN" {
            $NemoclawContent | Should -Match 'ufw deny.*swap_port.*/tcp'
        }

        It "htsclaw denies llama-swap from LAN/WAN" {
            $HtsclawFirewallContent | Should -Match 'ufw deny.*LLAMA_SWAP_PORT.*/tcp'
        }

        It "NemoClaw enables UFW" {
            $NemoclawContent | Should -Match 'ufw --force enable'
        }

        It "htsclaw enables UFW" {
            $HtsclawFirewallContent | Should -Match 'ufw --force enable'
        }

        It "htsclaw additionally restricts sandbox port to Tailscale + localhost" {
            $HtsclawFirewallContent | Should -Match '100\.64\.0\.0/10' -Because "sandbox port should be Tailscale-only"
            $HtsclawFirewallContent | Should -Match '127\.0\.0\.0/8' -Because "sandbox port should allow localhost"
            $HtsclawFirewallContent | Should -Match 'ufw deny.*HTSCLAW_PORT.*/tcp' -Because "sandbox port should deny LAN/WAN"
        }
    }

    Context "Token handling — extraction and permissions" {

        It "NemoClaw extracts token from gateway.auth.token path" {
            $NemoclawContent | Should -Match "gateway.*auth.*token"
        }

        It "htsclaw extracts token from gateway.auth.token path" {
            $HtsclawTokensContent | Should -Match "gateway.*auth.*token"
        }

        It "NemoClaw writes token to resources/dashboard/ sidecar" {
            $NemoclawContent | Should -Match 'resources/dashboard/nemoclaw-tokens\.json'
        }

        It "htsclaw writes token to resources/dashboard/ sidecar" {
            $HtsclawTokensContent | Should -Match 'resources/dashboard/htsclaw-tokens\.json'
        }

        It "htsclaw sets restrictive permissions (chmod 600) on token file" {
            $HtsclawTokensContent | Should -Match 'chmod 600.*token_file'
        }
    }

    Context "CORS — allowedOrigins enforcement" {

        It "NemoClaw patches controlUi.allowedOrigins to localhost only" {
            $NemoclawContent | Should -Match "allowedOrigins.*127\.0\.0\.1"
            $NemoclawContent | Should -Match "allowedOrigins.*localhost"
        }

        It "htsclaw patches controlUi.allowedOrigins to localhost only" {
            $HtsclawOriginsContent | Should -Match "allowedOrigins.*127\.0\.0\.1"
            $HtsclawOriginsContent | Should -Match "allowedOrigins.*localhost"
        }

        It "NemoClaw restarts gateway after patching origins" {
            $NemoclawContent | Should -Match '_sandbox_root_restart_gw'
        }

        It "htsclaw restarts gateway after patching origins" {
            $HtsclawOriginsContent | Should -Match '_htsclaw_restart_gateway'
        }
    }

    Context "Privilege — root exec for config modifications" {

        It "NemoClaw uses containerd root exec (uid 0) for config changes" {
            $NemoclawContent | Should -Match '--user 0'
            $NemoclawContent | Should -Match '_sandbox_root_exec'
        }

        It "htsclaw uses containerd root exec (uid 0) for config changes" {
            $HtsclawOriginsContent | Should -Match '--user 0'
            $HtsclawOriginsContent | Should -Match '_htsclaw_root_exec'
        }
    }

    # TODO v0.5.0: htsclaw-only bonus tests
    # - Policy YAML validation (defaultAction: deny, denied paths)
    # - Filesystem read-only mounts from openclaw-sandbox.yaml
    # - Health timer systemd unit validation
    # - Auto-recovery forward revival function
}
