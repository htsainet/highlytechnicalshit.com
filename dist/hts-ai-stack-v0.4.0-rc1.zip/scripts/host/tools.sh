#!/usr/bin/env bash
# scripts/host/tools.sh — Core host setup + optional dev tooling
# Independently runnable. Idempotent — skips already-installed components.
#
# Core (always):  jq, .env tokens
# Dev  (opt-in):  VS Code, extensions, MCP servers, PowerShell, Pester,
#                 repo tooling, nvtop, tmux, ripgrep, btop, bat, remmina,
#                 wireguard, ffmpeg, exfatprogs, ~/models dirs
# Admin (per-flag): SSH server
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/manifest.sh"
source "$REPO_DIR/scripts/lib/tokens.sh"

STACK_JSON="$REPO_DIR/config/stack.json"

# Read dev-tools flag (default: false for handoff users)
DEV_TOOLS=false
if [[ -f "$STACK_JSON" ]] && jq -e '.admin.install_dev_tools == true' "$STACK_JSON" &>/dev/null; then
  DEV_TOOLS=true
fi

# ══════════════════════════════════════════════════════════════════════════════
# CORE — always installed
# ══════════════════════════════════════════════════════════════════════════════

# ── Core host packages ────────────────────────────────────────────────────────
step "Core host packages"

CORE_PKGS=()
for pkg in jq curl; do
  dpkg -s "$pkg" &>/dev/null || CORE_PKGS+=("$pkg")
done

if [ ${#CORE_PKGS[@]} -eq 0 ]; then
  info "Core packages already installed (jq, curl)"
else
  info "Installing: ${CORE_PKGS[*]}"
  sudo apt-get update -qq
  sudo apt-get install -y "${CORE_PKGS[@]}"
fi
for pkg in jq curl; do manifest_add "$pkg" "apt"; done

# ── Visual Studio Code ────────────────────────────────────────────────────────
if [[ "$DEV_TOOLS" == "true" ]]; then
  step "Visual Studio Code"

  VSCODE_PREEXISTING=false
  if command -v code &>/dev/null; then
    VSCODE_PREEXISTING=true
    info "VS Code already installed ($(code --version 2>/dev/null | head -1)) — skipping extensions and MCP servers"
  else
  # Clean up conflicting VS Code apt sources
  sudo rm -f /usr/share/keyrings/microsoft.gpg 2>/dev/null || true
  sudo rm -f /etc/apt/sources.list.d/vscode.list /etc/apt/sources.list.d/vscode.sources 2>/dev/null || true

  for src_file in /etc/apt/sources.list /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources; do
    [ -f "$src_file" ] || continue
    if grep -q 'packages.microsoft.com/repos/code' "$src_file"; then
      if [[ "$src_file" == /etc/apt/sources.list.d/* ]]; then
        sudo rm -f "$src_file"
        continue
      fi
      sudo sed -i '/packages\.microsoft\.com\/repos\/code/d' "$src_file"
    fi
  done

  info "Installing Microsoft signing key for VS Code..."
  sudo install -d -m 0755 /etc/apt/keyrings
  curl -fsSL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor | sudo tee /etc/apt/keyrings/packages.microsoft.gpg >/dev/null
  sudo chmod 644 /etc/apt/keyrings/packages.microsoft.gpg

  if [ ! -f /etc/apt/sources.list.d/vscode.list ]; then
    info "Adding VS Code apt repository..."
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main" | sudo tee /etc/apt/sources.list.d/vscode.list >/dev/null
  fi

  sudo apt-get update -qq
  sudo apt-get install -y -qq code
  info "VS Code installed."
  manifest_add "code" "apt" "$(code --version 2>/dev/null | head -1)"
fi

# ── GitHub Copilot CLI (terminal agent) ────────────────────────────────────
step "GitHub Copilot CLI"
if command -v copilot &>/dev/null; then
  info "Copilot CLI already installed — skipping"
else
  info "Installing GitHub Copilot CLI..."
  curl -fsSL https://gh.io/copilot-install | bash
  info "Copilot CLI installed."
fi

if [[ "$VSCODE_PREEXISTING" == "false" ]] && command -v code &>/dev/null; then
  VSCODE_EXTENSIONS=(
    davidanson.vscode-markdownlint
    yzhang.markdown-all-in-one
    streetsidesoftware.code-spell-checker
    timonwong.shellcheck
    ms-python.python
    ms-python.vscode-pylance
    ms-python.python-environ-manager
    ms-vscode-remote.remote-ssh
    ms-vscode-remote.remote-containers
    ms-azuretools.vscode-docker
    ms-vscode.powershell
    eamodio.gitlens
    github.vscode-pull-request-github
    github.copilot
    github.copilot-chat
    anthropic.claude-code
  )

  for ext in "${VSCODE_EXTENSIONS[@]}"; do
    if code --list-extensions 2>/dev/null | grep -q "^${ext}$"; then
      info "Extension already installed: $ext"
    else
      info "Installing extension: $ext"
      if code --install-extension "$ext" >/dev/null 2>&1; then
        info "Installed extension: $ext"
      else
        warn "Failed to install extension: $ext (may not be available in this environment)"
      fi
    fi
  done
  info "VS Code extensions synced."

  # ── VS Code MCP Servers ────────────────────────────────────────────────────
  step "VS Code MCP servers"

  _mcp_server_exists() {
    local name="$1"
    local settings="${HOME}/.config/Code/User/settings.json"
    [[ -f "$settings" ]] && jq -e ".mcp.servers[\"$name\"]" "$settings" &>/dev/null
  }

  if _mcp_server_exists "docker"; then
    info "MCP server: docker (already configured)"
  else
    code --add-mcp '{"name":"docker","command":"docker","args":["mcp","gateway","run"]}' && \
      info "MCP server configured: docker" || \
      warn "MCP server: docker — failed (requires Docker with mcp subcommand)"
  fi

  if _mcp_server_exists "filesystem"; then
    info "MCP server: filesystem (already configured)"
  else
    code --add-mcp "{\"name\":\"filesystem\",\"command\":\"npx\",\"args\":[\"-y\",\"@modelcontextprotocol/server-filesystem\",\"${HOME}/github\",\"/mnt/nas\"]}" && \
      info "MCP server configured: filesystem" || \
      warn "MCP server: filesystem — failed"
  fi

  if _mcp_server_exists "ollama"; then
    info "MCP server: ollama (already configured)"
  else
    code --add-mcp '{"name":"ollama","command":"npx","args":["-y","mcp-ollama"]}' && \
      info "MCP server configured: ollama" || \
      warn "MCP server: ollama — failed"
  fi

  info "VS Code MCP servers configured."
fi
else
  info "Dev tools disabled — skipping VS Code, extensions, MCP servers"
fi

# ── Tokens (.env) ────────────────────────────────────────────────────────────
step "Tokens (.env)"

ENV_FILE="$REPO_DIR/.env"

if [ ! -f "$ENV_FILE" ]; then
  info "Creating .env and generating secure tokens..."
  cat > "$ENV_FILE" <<EOF
# Generated by host/tools.sh — do not commit this file

# ── Backend engine ────────────────────────────────────────────────────────────
# Set to 'ollama' (default) or 'bitnet' to switch inference backends.
BACKEND_ENGINE=ollama

# ── BitNet settings (only used when BACKEND_ENGINE=bitnet) ────────────────────
# BITNET_MODEL=BitNet-b1.58-2B-4T
# BITNET_HF_REPO=microsoft/BitNet-b1.58-2B-4T-gguf
# HF_TOKEN=
EOF
else
  info ".env exists — validating required tokens."
fi

if ! grep -q "^BACKEND_ENGINE=" "$ENV_FILE"; then
  printf '\n# Backend engine: ollama (default) or bitnet\nBACKEND_ENGINE=ollama\n' >> "$ENV_FILE"
  info "Added BACKEND_ENGINE=ollama to .env"
fi

ensure_env_key "WEBUI_SECRET_KEY"
chmod 600 "$ENV_FILE"
info ".env ready: $ENV_FILE"

# ══════════════════════════════════════════════════════════════════════════════
# DEV TOOLS — only when admin.install_dev_tools is true
# ══════════════════════════════════════════════════════════════════════════════

if [[ "$DEV_TOOLS" == "true" ]]; then

  # ── Dev host packages ─────────────────────────────────────────────────────
  step "Dev host packages"

  DEV_PKGS=()
  for pkg in nvtop tmux ffmpeg ripgrep btop bat remmina wireguard exfatprogs; do
    dpkg -s "$pkg" &>/dev/null || DEV_PKGS+=("$pkg")
  done

  if [ ${#DEV_PKGS[@]} -eq 0 ]; then
    info "Dev packages already installed"
  else
    info "Installing: ${DEV_PKGS[*]}"
    sudo apt-get update -qq
    sudo apt-get install -y "${DEV_PKGS[@]}"
  fi
  for pkg in nvtop tmux ffmpeg ripgrep btop bat remmina wireguard exfatprogs; do
    dpkg -s "$pkg" &>/dev/null && manifest_add "$pkg" "apt" || true
  done

  # ── PowerShell 7 ─────────────────────────────────────────────────────────
  step "PowerShell 7"

  if command -v pwsh &>/dev/null; then
    info "PowerShell already installed ($(pwsh --version 2>/dev/null | head -1))"
  else
    info "Registering Microsoft package repository..."
    # shellcheck source=/dev/null
    source /etc/os-release
    curl -fsSL "https://packages.microsoft.com/config/ubuntu/${VERSION_ID}/packages-microsoft-prod.deb" -o /tmp/packages-microsoft-prod.deb
    sudo dpkg -i /tmp/packages-microsoft-prod.deb
    rm /tmp/packages-microsoft-prod.deb
    sudo apt-get update -qq

    info "Installing PowerShell..."
    sudo apt-get install -y -qq powershell
    info "PowerShell installed: $(pwsh --version 2>/dev/null | head -1)"
  fi
  manifest_add "powershell" "apt" "$(pwsh --version 2>/dev/null | awk '{print $2}')"

  info "Ensuring Pester is available..."
  pwsh -NoLogo -NoProfile -Command "if ((Get-PSRepository -Name PSGallery).InstallationPolicy -ne 'Trusted') { Set-PSRepository -Name PSGallery -InstallationPolicy Trusted }; if (-not (Get-Module -ListAvailable -Name Pester)) { Install-Module -Name Pester -Scope CurrentUser -Force -SkipPublisherCheck -Repository PSGallery }"

  # ── Build tools ───────────────────────────────────────────────────────────
  step "Build tools (cmake, clang, .NET SDK)"

  BUILD_PKGS=()
  for pkg in build-essential cmake clang-18; do
    dpkg -s "$pkg" &>/dev/null || BUILD_PKGS+=("$pkg")
  done

  if [ ${#BUILD_PKGS[@]} -eq 0 ]; then
    info "Build tools already installed (build-essential, cmake, clang-18)"
  else
    info "Installing: ${BUILD_PKGS[*]}"
    sudo apt-get update -qq
    sudo apt-get install -y "${BUILD_PKGS[@]}"
  fi
  for pkg in build-essential cmake clang-18; do
    dpkg -s "$pkg" &>/dev/null && manifest_add "$pkg" "apt" || true
  done

  if dpkg -s dotnet-sdk-8.0 &>/dev/null; then
    info ".NET SDK 8.0 already installed"
  else
    info "Installing .NET SDK 8.0 (uses Microsoft repo from PowerShell step)..."
    sudo apt-get install -y -qq dotnet-sdk-8.0
  fi
  dpkg -s dotnet-sdk-8.0 &>/dev/null && manifest_add "dotnet-sdk-8.0" "apt"

  # ── Repo tooling ──────────────────────────────────────────────────────────
  step "Repo tooling"

  cd "$REPO_DIR"

  if [ -f package.json ]; then
    info "Installing repo-local Node tooling..."
    npm install

    info "Running npm dependency audit..."
    if "$REPO_DIR/scripts/utils/npm-audit.sh"; then
      info "npm audit complete — see .logs/npm-audit.log for details"
    else
      warn "npm audit finished with warnings — check .logs/npm-audit.log"
    fi
  fi

  if [ -f tests/Install-GitHooks.ps1 ]; then
    info "Configuring repo-local git hooks..."
    pwsh -NoLogo -NoProfile -File tests/Install-GitHooks.ps1
  fi

  # ── Model staging directories ─────────────────────────────────────────────
  step "Model directories"

  if [ -d "$HOME/models/approved" ] && [ -d "$HOME/models/testing" ]; then
    info "Model folders already exist."
  else
    info "Creating model folders..."
    mkdir -p "$HOME/models"/{approved,testing}
  fi

else
  info "Dev tools disabled (admin.install_dev_tools is false) — skipping dev packages, PowerShell, repo tooling"
fi

# ══════════════════════════════════════════════════════════════════════════════
# ADMIN SERVICES — gated on admin.tools array
# ══════════════════════════════════════════════════════════════════════════════

SSH_ENABLED=false
if [[ -f "$STACK_JSON" ]]; then
  if jq -e '.admin.tools | index("ssh_server")' "$STACK_JSON" &>/dev/null; then
    SSH_ENABLED=true
  fi
fi

# Note: xRDP (Microsoft RDP on port 3389) has been deprecated in favor of
# GNOME Remote Desktop (RDP on port 3389 primary, VNC on port 5900 optional),
# which provides better compatibility with modern Ubuntu + Wayland.
# Use ./scripts/utils/remote-access.sh to configure.

if [[ "$SSH_ENABLED" == "true" ]]; then
  step "SSH Server"

  if systemctl is-active --quiet sshd 2>/dev/null || systemctl is-active --quiet ssh 2>/dev/null; then
    info "SSH server already running"
  else
    info "Installing openssh-server..."
    sudo apt-get install -y -qq openssh-server
    sudo systemctl enable ssh
    sudo systemctl start ssh
    info "SSH server installed and running on port 22."
  fi
  manifest_add "openssh-server" "apt"

  if [[ -f "$STACK_JSON" ]] && jq -e '.admin.ssh_pubkey_only == true' "$STACK_JSON" &>/dev/null; then
    if grep -q "^PasswordAuthentication no" /etc/ssh/sshd_config 2>/dev/null; then
      info "SSH pubkey-only auth already configured"
    else
      info "Hardening SSH: disabling password authentication..."
      sudo sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
      sudo sed -i 's/^#\?ChallengeResponseAuthentication.*/ChallengeResponseAuthentication no/' /etc/ssh/sshd_config
      sudo systemctl reload ssh
      info "SSH hardened — password auth disabled, pubkey only"
      warn "Ensure your SSH key is in ~/.ssh/authorized_keys before disconnecting!"
    fi
  fi
else
  info "SSH server skipped (not in admin.tools)"
fi

info "Host tools setup complete."
