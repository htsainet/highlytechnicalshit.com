$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/cogvideox'
    $script:ComponentScript = Join-Path $script:ComponentDir 'cogvideox.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'cogvideox.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'cogvideox file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }

    It 'CONTEXT.md exists' {
        Join-Path $script:ComponentDir 'CONTEXT.md' | Should -Exist
    }

    It 'REFERENCES.md exists' {
        Join-Path $script:ComponentDir 'REFERENCES.md' | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'cogvideox manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is cogvideox' {
        $script:Manifest.id | Should -Be 'cogvideox'
    }

    It 'script path points to subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/cogvideox/cogvideox.sh'
    }

    It 'script path resolves to existing file' {
        Join-Path $script:RepoRoot $script:Manifest.script | Should -Exist
    }

    It 'func_prefix is cogvideox_' {
        $script:Manifest.func_prefix | Should -Be 'cogvideox_'
    }

    It 'dashboard port is 7865' {
        [int]$script:Manifest.dashboard.port | Should -Be 7865
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'cogvideox component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines cogvideox_install function' {
        $script:ComponentContent | Should -Match 'cogvideox_install\s*\(\)'
    }

    It 'defines cogvideox_configure function' {
        $script:ComponentContent | Should -Match 'cogvideox_configure\s*\(\)'
    }

    It 'defines cogvideox_start function' {
        $script:ComponentContent | Should -Match 'cogvideox_start\s*\(\)'
    }

    It 'defines cogvideox_stop function' {
        $script:ComponentContent | Should -Match 'cogvideox_stop\s*\(\)'
    }

    It 'defines cogvideox_health function' {
        $script:ComponentContent | Should -Match 'cogvideox_health\s*\(\)'
    }

    It 'defines cogvideox_restart function' {
        $script:ComponentContent | Should -Match 'cogvideox_restart\s*\(\)'
    }

    It 'defines cogvideox_destroy function' {
        $script:ComponentContent | Should -Match 'cogvideox_destroy\s*\(\)'
    }

    It 'defines cogvideox_status function' {
        $script:ComponentContent | Should -Match 'cogvideox_status\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/cogvideox/cogvideox\.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'cogvideox port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 7865 is registered in portmap.json' {
        $script:Portmap.ports.'7865' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'7865'.service | Should -Be 'cogvideox'
    }
}

# ── Docker file existence ───────────────────────────────────────────────────

Describe 'cogvideox Docker artifacts' {

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/cogvideox/Dockerfile' | Should -Exist
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'cogvideox no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/cogvideox\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/cogvideox/cogvideox\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
