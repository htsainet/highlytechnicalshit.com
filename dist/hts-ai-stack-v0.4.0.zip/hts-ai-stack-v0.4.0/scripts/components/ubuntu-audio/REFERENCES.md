# Ubuntu Studio Audio References

Last updated: 2026-04-17

## Upstream

- [Ubuntu Studio](https://ubuntustudio.org/)
- [Ubuntu Studio Audio Wiki](https://help.ubuntu.com/community/UbuntuStudio/AudioHandbook)
- [JACK Audio Connection Kit](https://jackaudio.org/)
- [QjackCtl](https://qjackctl.sourceforge.io/)

## Packages

- `jackd2` — JACK2 audio server (low-latency, multi-CPU)
- `pulseaudio-module-jack` — PulseAudio ↔ JACK bridge
- `qjackctl` — Qt GUI for JACK management
- `a2jmidid` — ALSA MIDI ↔ JACK MIDI bridge
- `linux-lowlatency` — Low-latency kernel for realtime audio
- `ubuntustudio-audio-plugins` — Curated audio plugin collection
