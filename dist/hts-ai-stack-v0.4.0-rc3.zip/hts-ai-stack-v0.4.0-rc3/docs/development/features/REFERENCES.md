# Feature Index

Active feature proposals and development tracking by release target.

## Current Release (v0.4.0)

No feature files — v0.4.0 focus is core infrastructure and install pipeline.

## Next Minor Release (v0.5.0)

| Feature | Priority | Status | File |
|---------|----------|--------|------|
| Ollama Model Review & Registry Audit | MEDIUM | Proposed | [FEATURE-043.md](FEATURE-043.md) |
| KoboldCpp Local Inference Service | HIGH | Proposed | [FEATURE-031.md](FEATURE-031.md) |
| Image Generation & Voice Services | MEDIUM | ✅ Complete | [FEATURE-004.md](FEATURE-004.md) |
| Granular Model Selection Checklist | MEDIUM | In Progress | [FEATURE-003.md](FEATURE-003.md) |
| Config-Driven Convergence | HIGH | ✅ Complete | [FEATURE-009.md](FEATURE-009.md) |
| Dependency Version Dashboard & Image Pinning | MEDIUM | Proposed | [FEATURE-011.md](FEATURE-011.md) |
| gVisor Sandbox — Secure CPU Agent Runtime | HIGH | In Progress | [FEATURE-012.md](FEATURE-012.md) |
| Daytona Sandbox — Devcontainer Agent Runtime | LOW | Deferred to v0.6.0 | [FEATURE-013.md](FEATURE-013.md) |
| NemoClaw Built-in OpenClaw Instance Review | HIGH | Proposed | [FEATURE-014.md](FEATURE-014.md) |
| Public Distribution Mirror | HIGH | Proposed | [FEATURE-016.md](FEATURE-016.md) |
| reconfigure.sh — Day-2 Reconfiguration Script | HIGH | ✅ Complete | [FEATURE-038.md](FEATURE-038.md) |
| htsclaw — Self-Managed OpenClaw Sandbox | HIGH | In Progress | [FEATURE-019.md](FEATURE-019.md) |

## Future Releases (v0.6.0)

| Feature | Priority | Status | File |
|---------|----------|--------|------|
| DeerFlow gVisor Agent Sandbox Integration | MEDIUM | Proposed | [FEATURE-037.md](FEATURE-037.md) |
| ComfyUI GPU Image Generation Service | MEDIUM | In Progress | [FEATURE-039.md](FEATURE-039.md) |

| Feature | Priority | Status | File |
|---------|----------|--------|------|
| Tailscale ACL Policy with Escape Hatch | HIGH | ~~Superseded~~ → [SECURITY-001](../../security-review/features/SECURITY-001.md) | [FEATURE-000.md](FEATURE-000.md) |
| Docker Isolated Network Mode | LOW | Proposed | [FEATURE-001.md](FEATURE-001.md) |
| KoboldCpp + SillyTavern Bundle | MEDIUM | ~~Superseded~~ → FEATURE-005 | [FEATURE-002.md](FEATURE-002.md) |
| Deferred Services (SCM, Creative, Agents) | LOW | Proposed | [FEATURE-005.md](FEATURE-005.md) |
| ONNX Runtime — Lightweight CPU Inference | LOW | Proposed | [FEATURE-006.md](FEATURE-006.md) |
| code-review-graph — Structural Code Knowledge MCP | MEDIUM | Proposed | [FEATURE-007.md](FEATURE-007.md) |
| Goose — General-Purpose AI Agent Runtime | LOW | Proposed | [FEATURE-008.md](FEATURE-008.md) |
| Full Drift Detection — Live State Convergence | MEDIUM | Proposed | [FEATURE-010.md](FEATURE-010.md) |
| n8n — Workflow Automation Service | MEDIUM | Proposed | [FEATURE-015.md](FEATURE-015.md) |
| goat-agent — C# AI Agent Pattern Review | LOW | Proposed | [FEATURE-017.md](FEATURE-017.md) |
| Alternative Inference Backends (vLLM, llama.cpp) | LOW | Proposed | [FEATURE-018.md](FEATURE-018.md) |
| Agnai — Multi-User AI Roleplay Chat | LOW | Proposed | [FEATURE-032.md](FEATURE-032.md) |
| LibreChat — Feature-Rich Multi-User Chat UI | MEDIUM | Proposed | [FEATURE-033.md](FEATURE-033.md) |
| text-generation-webui — Inference Backend + Training UI | MEDIUM | Proposed | [FEATURE-034.md](FEATURE-034.md) |
| AnythingLLM — Document Chat + RAG Workspace Platform | MEDIUM | Proposed | [FEATURE-035.md](FEATURE-035.md) |
| RisuAI — RP Chat with Emotion Sprites, Regex Scripting & Translation | LOW | Proposed | [FEATURE-036.md](FEATURE-036.md) |
| OpenFang — Agent OS Service | MEDIUM | Proposed | [FEATURE-020.md](FEATURE-020.md) |
| ZeroClaw — Personal AI Assistant | HIGH | Proposed | [FEATURE-021.md](FEATURE-021.md) |
| CrewAI — Multi-Agent Orchestration | MEDIUM | Proposed | [FEATURE-022.md](FEATURE-022.md) |
| AutoGen | — | ~~Superseded~~ → Microsoft Agent Framework | [FEATURE-023.md](FEATURE-023.md) |
| LangGraph — Stateful Agent Orchestration | MEDIUM | Proposed | [FEATURE-024.md](FEATURE-024.md) |
| Coqui TTS — Text-to-Speech Service | MEDIUM | Proposed | [FEATURE-025.md](FEATURE-025.md) |
| Faster-Whisper — GPU Speech-to-Text | MEDIUM | Proposed | [FEATURE-026.md](FEATURE-026.md) |
| Nerd Dictation — Desktop Voice Input | LOW | Proposed | [FEATURE-027.md](FEATURE-027.md) |
| Vosk API — Offline CPU Speech-to-Text | MEDIUM | Proposed | [FEATURE-028.md](FEATURE-028.md) |
| Open-Sora — Text-to-Video Generation | LOW | ~~Deferred~~ → Disqualified (RTX 3060 12GB < 24GB min) | [FEATURE-029.md](FEATURE-029.md) |
| HunyuanVideo — Text-to-Video (Premium) | LOW | ~~Deferred~~ → Disqualified (RTX 3060 12GB < 16GB min) | [FEATURE-030.md](FEATURE-030.md) |
| PostHog — Product Analytics Platform | LOW | Proposed | [FEATURE-044.md](FEATURE-044.md) |
| Chatwoot — Customer Support Platform | LOW | Proposed | [FEATURE-045.md](FEATURE-045.md) |
| LanguageTool — Grammar & Style Checker | MEDIUM | In Progress | [FEATURE-046.md](FEATURE-046.md) |
| Continue — AI Coding Assistant Extension | LOW | In Progress | [FEATURE-047.md](FEATURE-047.md) |
| ML Systems Reference Book (Harvard CS249r) | LOW | In Progress | [FEATURE-048.md](FEATURE-048.md) |
| Claude-Mem Persistent Memory | LOW | In Progress | [FEATURE-049.md](FEATURE-049.md) |
| Lean-Ctx AI Context Runtime | LOW | In Progress | [FEATURE-050.md](FEATURE-050.md) |
| Agent Skills for Context Engineering | LOW | In Progress | [FEATURE-051.md](FEATURE-051.md) |
| GPU VRAM Validator & Model VRAM Display | MEDIUM | In Progress | [FEATURE-052.md](FEATURE-052.md) |
| Authelia SSO + Traefik Reverse Proxy | HIGH | Proposed | [FEATURE-055.md](FEATURE-055.md) |
| L3 Microsegmentation (Per-Service Spoke Networks) | MEDIUM | Proposed (Future) | [FEATURE-056.md](FEATURE-056.md) |
| Runtime Threat Detection (Falco + Alerting) | MEDIUM | Proposed | [FEATURE-057.md](FEATURE-057.md) |
| OpenShell Sandbox Tier (Agent / Code-Exec Services) | MEDIUM | Proposed | [FEATURE-058.md](FEATURE-058.md) |
| Vaultwarden (Self-Hosted Bitwarden) Password Manager | HIGH | Proposed | [FEATURE-059.md](FEATURE-059.md) |
| YubiKey Integration (Auth + Disk + Signing) | HIGH | Proposed | [FEATURE-060.md](FEATURE-060.md) |
| Repo Hygiene: Pre-Commit Data Scrubber + Secret Scan | HIGH | Proposed | [FEATURE-062.md](FEATURE-062.md) |
| Agent Registry & Lifecycle Governance (`agentctl`) | HIGH | Proposed | [FEATURE-061.md](FEATURE-061.md) |
