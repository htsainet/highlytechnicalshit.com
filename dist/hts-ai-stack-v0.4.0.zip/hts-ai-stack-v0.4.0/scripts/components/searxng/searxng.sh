#!/usr/bin/env bash
# scripts/components/searxng/searxng.sh — SearXNG privacy meta-search engine
#
# Standalone usage:
#   ./scripts/components/searxng/searxng.sh              # full: install + configure + start + health
#   ./scripts/components/searxng/searxng.sh --install    # install only
#   ./scripts/components/searxng/searxng.sh --configure  # configure only
#   ./scripts/components/searxng/searxng.sh --start      # start only
#   ./scripts/components/searxng/searxng.sh --stop       # stop
#   ./scripts/components/searxng/searxng.sh --restart    # restart (stop + start)
#   ./scripts/components/searxng/searxng.sh --health     # health check only
#   ./scripts/components/searxng/searxng.sh --status     # show status + port + health
#   ./scripts/components/searxng/searxng.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

load_env
SEARXNG_PORT="${SEARXNG_PORT:-8787}"
SEARXNG_CONTAINER="${SEARXNG_CONTAINER:-hts-ai-searxng}"

# ── Lifecycle functions ───────────────────────────────────────────────────────

searxng_install() {
  step "SearXNG — install"
  compose_build --profile searxng
  ok "SearXNG image built."
}

searxng_configure() {
  step "SearXNG — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^SEARXNG_PORT=" "$env_file" 2>/dev/null; then
    printf 'SEARXNG_PORT=%s\n' "$SEARXNG_PORT" >> "$env_file"
    info "Added SEARXNG_PORT=${SEARXNG_PORT} to .env"
  fi

  # Note: SEARXNG_SECRET_KEY is NOT read by the container image. The entrypoint
  # auto-generates a secret key directly inside settings.yml on first start.
  # Do not pass a secret via env var — the image will silently ignore it.

  ok "SearXNG configured (port ${SEARXNG_PORT})."
}

searxng_start() {
  step "SearXNG — start"
  compose_up --profile searxng
  ok "SearXNG started on port ${SEARXNG_PORT}."
}

searxng_stop() {
  step "SearXNG — stop"
  compose_down --profile searxng
  ok "SearXNG stopped."
}

searxng_health() {
  health_probe "SearXNG :${SEARXNG_PORT}" "http://localhost:${SEARXNG_PORT}/healthz"
}

searxng_restart() {
  searxng_stop
  searxng_start
}

searxng_destroy() {
  step "SearXNG — destroy"
  compose_down --profile searxng -v
  ok "SearXNG destroyed."
}

searxng_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=searxng" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "SearXNG is running (port ${SEARXNG_PORT})"
  else
    warn "SearXNG is not running."
  fi
  searxng_health 2>/dev/null || true
}

# ── Standalone execution ──────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   searxng_install   ;;
    configure) searxng_configure ;;
    start)     searxng_start     ;;
    stop)      searxng_stop      ;;
    restart)   searxng_restart   ;;
    health)    searxng_health    ;;
    status)    searxng_status    ;;
    destroy)   searxng_destroy   ;;
    default)
      searxng_install
      searxng_configure
      searxng_start
      searxng_health
      ;;
  esac
fi
