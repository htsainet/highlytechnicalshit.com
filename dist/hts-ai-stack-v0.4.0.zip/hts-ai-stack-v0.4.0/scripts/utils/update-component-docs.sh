#!/usr/bin/env bash
# scripts/utils/update-component-docs.sh — Ensure each component script has early help,
# a usage.md file listing supported commands, and a CONTEXT.md that references usage.md.
# Commits each component separately so the history tracks progress.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO_ROOT"

# Early help block to insert
EARLY_HELP_BLOCK=$(cat <<'EOF'
# Early help – prints script description and exits on --help.
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  for arg in "$@"; do
    case "$arg" in
      --help|-h)
        # Print comment header (skip shebang)
        awk 'NR>1 && /^#/{sub(/^# ?/, ""); print}' "${BASH_SOURCE[0]}"
        exit 0
        ;;
    esac
  done
fi
EOF
)

add_early_help() {
  local script="$1"
  # If script already has a help case, skip
  if grep -q '--help' "$script"; then
    return
  fi
  # Insert after shebang (line 1)
  local tmp
  tmp=$(mktemp)
  head -n1 "$script" > "$tmp"
  printf "%s\n" "$EARLY_HELP_BLOCK" >> "$tmp"
  tail -n +2 "$script" >> "$tmp"
  mv "$tmp" "$script"
  chmod +x "$script"
}

create_usage_md() {
  local comp_dir="$1"
  local usage_file="$comp_dir/usage.md"
  if [[ -f "$usage_file" ]]; then
    return
  fi
  cat > "$usage_file" <<'EOF'
# Component Usage

Run the component script with `--help` to see the supported commands.

Common command patterns (may vary per component):
- `--install` – Install the service.
- `--configure` – Apply configuration.
- `--start` – Start the service.
- `--stop` – Stop the service.
- `--restart` – Restart the service.
- `--health` – Run a health check.
- `--status` – Show status information.
- `--destroy` – Remove containers and volumes.

Refer to the script's help output for the full list.
EOF
}

ensure_context_md() {
  local comp_dir="$1"
  local context_file="$comp_dir/CONTEXT.md"
  local link_line="See [usage.md](./usage.md) for command usage."
  if [[ -f "$context_file" ]]; then
    if grep -q "\[usage\.md\]" "$context_file"; then
      return
    fi
    echo -e "\n$link_line" >> "$context_file"
  else
    cat > "$context_file" <<EOF
# Component Context

$link_line
EOF
  fi
}

# Iterate over top-level component directories
for comp_dir in scripts/components/*/; do
  [[ -d "$comp_dir" ]] || continue
  comp_name=$(basename "$comp_dir")
  # Determine main script – prefers <comp>/<comp>.sh
  main_script="${comp_dir}/${comp_name}.sh"
  if [[ ! -f "$main_script" ]]; then
    # Fallback: first .sh file (excluding test/troubleshoot)
    main_script=$(find "$comp_dir" -maxdepth 1 -type f -name "*.sh" ! -name "*test*" ! -name "*troubleshoot*" | head -n1)
  fi
  if [[ -z "$main_script" || ! -f "$main_script" ]]; then
    echo "[WARN] No script found for $comp_name – skipping"
    continue
  fi

  # Apply modifications
  add_early_help "$main_script"
  create_usage_md "$comp_dir"
  ensure_context_md "$comp_dir"

  # Stage and commit for this component
  git add "$main_script"
  git add -f "$comp_dir/usage.md" "$comp_dir/CONTEXT.md"
  git commit -m 'Add early help, usage.md, and CONTEXT link for component $comp_name'
  echo "Committed docs for $comp_name"
done