#!/usr/bin/env bash
# scripts/components/openspace.sh — OpenSpace MCP agent skills: install, start, health
#
# Standalone usage:
#   ./scripts/components/openspace.sh            # install + configure + start + health
#   ./scripts/components/openspace.sh --health   # health check only
#   ./scripts/components/openspace.sh --stop     # stop OpenSpace
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
OPENSPACE_CONTAINER="${OPENSPACE_CONTAINER:-hts-ai-openspace}"
OPENSPACE_PORT="${OPENSPACE_PORT:-5000}"
OPENSPACE_DASHBOARD_PORT="${OPENSPACE_DASHBOARD_PORT:-3001}"

# ── Functions ────────────────────────────────────────────────────────────────

# openspace_install — Build OpenSpace image from docker/openspace/Dockerfile
openspace_install() {
  step "OpenSpace — install"
  local dockerfile="$REPO_DIR/docker/openspace/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    fail "OpenSpace Dockerfile not found: $dockerfile"
    return 1
  fi
  compose_pull --profile openspace
  ok "OpenSpace image ready."
}

# openspace_configure — Validate config and env vars
openspace_configure() {
  step "OpenSpace — configure"
  local config="$REPO_DIR/docker/openspace/config.yml"
  if [[ -f "$config" ]]; then
    info "OpenSpace config.yml found"
  else
    warn "No config.yml at $config — using defaults"
  fi

  info "LLM backend: llama-swap (unified router)"
  info "MCP server port: ${OPENSPACE_PORT}"
  info "Dashboard port: ${OPENSPACE_DASHBOARD_PORT}"
  ok "OpenSpace configured."
}

# openspace_start — Bring up OpenSpace via compose
openspace_start() {
  step "OpenSpace — start"
  compose_up --profile openspace
  ok "OpenSpace started (MCP :${OPENSPACE_PORT}, dashboard :${OPENSPACE_DASHBOARD_PORT})."
}

# openspace_stop — Bring down OpenSpace
openspace_stop() {
  step "OpenSpace — stop"
  compose_down --profile openspace
  ok "OpenSpace stopped."
}

# openspace_health — Probe the OpenSpace MCP SSE endpoint
# The SSE server has no /health route; instead we connect to /sse and check
# for the initial "endpoint" event (same approach as the Docker healthcheck).
openspace_health() {
  local label="OpenSpace :${OPENSPACE_PORT}"
  local url="http://localhost:${OPENSPACE_PORT}/sse"
  local max_attempts=30
  local sleep_secs=2
  local attempts=0

  printf "  %-35s" "$label"
  while true; do
    # Capture curl output to avoid SIGPIPE exit code with pipefail
    local body
    body="$(curl -s --max-time 3 "$url" 2>/dev/null || true)"
    if echo "$body" | head -1 | grep -q endpoint; then
      printf "\r  %-35s${GREEN}OK${NC}  \n" "$label"
      return 0
    fi
    sleep "$sleep_secs"
    attempts=$((attempts + 1))
    if [[ $attempts -ge $max_attempts ]]; then
      printf "\r  %-35s${RED}FAIL${NC} (%s)\n" "$label" "$url"
      return 1
    fi
  done
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --health) ACTION="health"; shift ;;
      --stop)   ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      openspace_install
      openspace_configure
      openspace_start
      openspace_health
      ;;
    health)
      openspace_health
      ;;
    stop)
      openspace_stop
      ;;
  esac
fi
