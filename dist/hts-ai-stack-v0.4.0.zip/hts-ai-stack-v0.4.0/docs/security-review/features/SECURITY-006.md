# Data Retention & Cleanup Policy

**Priority:** MEDIUM
**Effort:** 4-6 hours
**Risk:** Low — additive policy enforcement. Worst case: data deleted earlier than intended
(mitigated by configurable retention windows).
**Target Release:** v0.5.0
**Threat:** Sensitive data persists indefinitely in Docker volumes with no rotation, encryption,
or access controls. Whisper transcripts, XTTS voice clones, and Stable Diffusion outputs
accumulate without bounds.
**Depends on:** Nothing
**Blocks:** Nothing

## Problem

| Data | Volume | Sensitivity | Current Retention |
|------|--------|-------------|-------------------|
| Whisper transcripts | `whisper_cache` | HIGH — may contain dictated passwords, PII | Indefinite |
| XTTS voice models | `xtts_models` | MEDIUM — voice biometrics | Indefinite |
| SD generated images | `sd_outputs_prod` | MEDIUM — may contain sensitive visual content | Indefinite |
| Ollama chat history | Open WebUI DB | HIGH — full conversation logs | Indefinite |
| Agent action logs | NemoClaw sandbox logs | HIGH — tool invocations, file access | Indefinite |

No automated cleanup exists. Disk usage grows unbounded. A compromised container with
volume access can exfiltrate historical data going back to initial install.

## Solution

1. **Configurable retention windows** in `stack.json` per data category
2. **Automated cleanup script** run via cron or systemd timer
3. **Volume encryption at rest** for HIGH sensitivity data (stretch goal)

## Implementation Steps

### 1. Add retention config to `stack.json`

```json
{
  "data_retention": {
    "whisper_cache_days": 7,
    "sd_outputs_days": 30,
    "xtts_models_days": 90,
    "chat_history_days": 365
  }
}
```

### 2. Create `scripts/utils/data-cleanup.sh`

Script that reads retention config and removes files older than the configured window.
Run as a daily cron job.

### 3. Add systemd timer

Install via `scripts/host/` during setup.

## Acceptance Criteria

- [ ] Cleanup script removes files older than configured retention
- [ ] Default retention values set in `stack.json.example`
- [ ] Dry-run mode available (`--dry-run`)
- [ ] Cleanup logged to stdout (captured by SECURITY-005 observability)

## Paper References

- Session 1 finding H4
- 2603.19469 — data isolation property requires bounded data lifetime
