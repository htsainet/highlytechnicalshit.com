# OpenSpace — Self-Evolving Agent Skills Framework

OpenSpace is a framework that enables AI agents to autonomously develop, improve, and share reusable skills. It reduces token consumption and increases task performance through self-learning.

## Features

- **Self-evolving skills** — Skills auto-fix, auto-improve, and auto-learn from execution
- **Collective intelligence** — Skills are shareable across agents
- **Token efficiency** — Up to 46% cost reduction on professional tasks
- **MCP integration** — Works with Claude Code, OpenClaw, and other agents
- **Local LLM support** — Uses your locally-hosted Ollama instance

## Quick Start

### Prerequisites

- Docker and Docker Compose
- Ollama service running (or BitNet if using OpenAI API)
- At least 2GB RAM available for OpenSpace

### Launch OpenSpace

```bash
# Start OpenSpace with Ollama backend
docker-compose --profile openspace up -d openspace

# Verify it's running
docker-compose logs openspace

# Check health
curl http://localhost:5000/health
```

### Access OpenSpace

- **MCP Server**: `http://localhost:5000` — for agent integration
- **Dashboard**: `http://localhost:3001` — optional UI (once fully running)

## Configuration

Edit `docker/openspace/config.yml` to customize:

```yaml
llm:
  backend: ollama
  ollama:
    base_url: http://ollama:11434
    model: mistral-nemo
```

### Environment Variables

Pass via docker-compose or `.env`:

| Variable | Default | Purpose |
|----------|---------|---------|
| `LLM_BACKEND` | ollama | Backend: `ollama` or `openai` |
| `OLLAMA_BASE_URL` | http://ollama:11434 | Ollama endpoint |
| `OLLAMA_MODEL` | mistral-nemo | Model to use |
| `OPENSPACE_LOG_LEVEL` | INFO | Logging level |

### Using BitNet (OpenAI-compatible) instead of Ollama

Set in `.env`:

```bash
LLM_BACKEND=openai
OPENAI_API_BASE_URL=http://bitnet:8080/v1
OPENAI_API_KEY=sk-local
```

## Skills Management

Skills are stored in the `openspace_skills` volume:

```bash
# View learned skills
docker exec openspace ls -la /app/skills

# Export a skill
docker exec openspace cat /app/skills/my-skill.md > exported-skill.md
```

## Integration with Agents

### Claude Code Integration

Add OpenSpace as an MCP server in your Claude Code settings:

```json
{
  "mcp_servers": [
    {
      "name": "openspace",
      "url": "http://localhost:5000",
      "type": "mcp"
    }
  ]
}
```

### OpenClaw Integration

Configure OpenClaw to use OpenSpace skills:

```yaml
agent:
  name: openspace-agent
  mcp_servers:
    - host: openspace
      port: 5000
```

## Monitoring

### View Logs

```bash
docker-compose logs -f openspace
```

### Check Metrics

```bash
# Skill performance metrics
curl http://localhost:5000/api/metrics/skills

# Agent statistics
curl http://localhost:5000/api/stats
```

### Health Check

```bash
# Detailed health info
curl http://localhost:5000/api/health
```

## Troubleshooting

### OpenSpace won't start

Check if Ollama is healthy:

```bash
docker-compose logs ollama
curl http://localhost:11434/api/tags
```

### Skills not persisting

Ensure volume is mounted correctly:

```bash
docker volume ls | grep openspace
```

### Memory issues

Increase memory limit in docker-compose.yml:

```yaml
deploy:
  resources:
    limits:
      memory: 4g
```

## Development

### Build with custom changes

```bash
docker-compose --profile openspace build openspace
docker-compose --profile openspace up openspace
```

### Shell access

```bash
docker exec -it openspace bash
```

### Test MCP server

```bash
python -c "import openspace; print(openspace.__version__)"
```

## Advanced Configuration

### Custom Skills Directory

Mount your own skills:

```yaml
# docker-compose.yml
openspace:
  volumes:
    - ./my-skills:/app/skills
```

### Persistent Logs

Logs are stored in `openspace_logs` volume. Export them:

```bash
docker run --rm -v openspace_logs:/logs ubuntu tar czf - /logs > openspace-logs.tar.gz
```

## References

- OpenSpace GitHub: https://github.com/HKUDS/OpenSpace
- OpenSpace Documentation: https://openspace.readthedocs.io/
- MCP Protocol: https://modelcontextprotocol.io/
