# Tailscale Component

Last updated: 2026-04-15

## What happens here

Tailscale provides a zero-config mesh VPN (WireGuard-based) for secure
remote access to the stack. Enables accessing AI services from any device
on the tailnet without port forwarding or public IP exposure.

## Files and structure

| File | Purpose |
|------|---------|
| `tailscale.sh` | Full lifecycle: install, configure, start, stop, health |
| `tailscale.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
