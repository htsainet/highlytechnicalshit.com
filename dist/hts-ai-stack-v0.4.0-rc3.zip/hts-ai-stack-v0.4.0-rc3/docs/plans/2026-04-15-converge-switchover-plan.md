# Converge Switchover Plan
# Created: 2026-04-15
# Status: ✅ COMPLETE (2026-04-16)
# Context: Replace full-stack.sh with converge.sh as the primary orchestration path

---

## Outcome

All 5 tasks completed. `full-stack.sh` is deprecated. `install.sh` now calls
host setup scripts directly and delegates all Docker service deployment to
`converge.sh --yes`.

### Key commits (feature/manifest-wizard branch)

| Commit | Description |
|--------|-------------|
| `061f619` | Fix config pipeline: wizard selections now reach .env |
| `cbf99f3` | Fix 11 manifests + refactor full-stack.sh → thin wrapper |
| `72f8c43` | Eliminate full-stack.sh: install.sh calls converge.sh directly |

## Background

FEATURE-009 (config-driven convergence) is complete. The convergence
engine is fully operational:

- converge.sh — 3 modes (dry-run, yes, interactive), dashboard early-launch
- reconfigure.sh — day-2 wizard + converge integration
- 33 component manifests with full metadata
- state-desired.sh, state-actual.sh, converge-diff.sh — all working
- manifest-loader.sh — populates COMPONENT_* arrays from manifests

**Component --health audit (2026-04-15): ALL 35 components pass.**
Every component script has `--health` CLI flag, a `*_health()` function,
and appropriate manifest health configuration. No remediation needed.

The remaining work is **Phase 6** (wire converge.sh into the install
pipeline) and **Phase 7** validation (drift detection edge cases).

---

## TASK 1: Validate converge.sh Against Live Stack

### Prerequisite
Full nuke-and-pave via install.sh must complete successfully with all
components enabled.

### Steps

1. Run `converge.sh --dry-run` against the live stack
   ```bash
   ./scripts/utils/converge.sh --dry-run
   ```
   **Expected:** Every enabled service shows action=`health`, no starts/stops.
   If any service shows `install` or `start`, investigate why actual state
   probing missed it.

2. Run `converge.sh --yes` (no-op confirmation)
   ```bash
   ./scripts/utils/converge.sh --yes
   ```
   **Expected:** All health checks pass. Reconciliation report shows all
   green. `.last-applied.json` written.

3. Toggle a single service and converge
   ```bash
   # Disable duplicati in stack.json
   jq '.extras.components -= ["duplicati"]' config/stack.json > /tmp/s.json \
     && mv /tmp/s.json config/stack.json

   ./scripts/utils/converge.sh --dry-run   # should show stop:duplicati
   ./scripts/utils/converge.sh --yes       # should stop duplicati only

   # Re-enable and converge again
   jq '.extras.components += ["duplicati"]' config/stack.json > /tmp/s.json \
     && mv /tmp/s.json config/stack.json

   ./scripts/utils/converge.sh --yes       # should start duplicati only
   ```

4. Test interactive mode
   ```bash
   ./scripts/utils/converge.sh --interactive
   ```
   Verify pre-flight checklists render correctly, deselecting a service
   skips it.

---

## TASK 2: Refactor full-stack.sh → Thin Wrapper

### Current Structure (287 lines)
```
full-stack.sh:
  1. set -euo pipefail, source libs
  2. CLI parsing (--chat mode)
  3. Read 15 boolean env vars
  4. Build install manifest
  5. Host setup (nvidia, docker, node, tools, NAS)
  6. Dashboard early launch
  7. Monitoring + Portainer
  8. Core services (ollama, bitnet, llama-swap, open-webui)
  9. Optional services (htsclaw, nemoclaw, openspace, deerflow, etc.)
  10. Connectivity (tailscale, telegram, signal)
  11. install_status_complete
```

### Target Structure (~50 lines)
```
full-stack.sh:
  1. set -euo pipefail, source libs
  2. CLI parsing (--chat mode)
  3. Host setup (nvidia, docker, node, tools, NAS)  ← KEEP
  4. LM Studio host install                          ← KEEP (host-level, not Docker)
  5. converge.sh --yes                               ← REPLACES steps 6-10
  6. Post-converge: chat mode swap, final banner
```

### Changes

#### Keep in full-stack.sh (host-level, not in converge)
- `scripts/host/nvidia.sh`
- `scripts/host/docker.sh`
- `scripts/host/node.sh`
- `scripts/host/tools.sh`
- `scripts/host/nas.sh` (conditional on NAS_ENABLED)
- LM Studio .deb install (host-interactive)
- Sudo keep-alive loop

#### Remove from full-stack.sh (converge handles these)
- All 15 boolean flag reads (HTSCLAW_DEPLOY, NEMOCLAW_DEPLOY, etc.)
- Install manifest builder (_SVCS array)
- Dashboard early launch (converge.sh has _ensure_dashboard)
- All per-service install/status blocks
- Monitoring + Portainer blocks

#### Wire converge.sh
```bash
# After host setup completes:
step "Stack convergence"
bash "$REPO_DIR/scripts/utils/converge.sh" --yes
```

#### Chat mode swap
The `--chat` flag (lean|mean|claw) currently triggers
`ollama.sh --swap "$CHAT_MODE"` inline. This needs to either:
- (A) Move into ollama's component script as a post-start hook
- (B) Stay in full-stack.sh as a post-converge step

**Recommendation:** Option B — keep it as a post-converge step since it's
a one-time install preference, not a convergence concern.

---

## TASK 3: Wire install.sh --reconfigure → reconfigure.sh

### Current (install.sh line ~309)
```bash
run_script "$REPO_DIR/scripts/bundles/full-stack.sh"
```

### Changes
1. The main install path keeps calling full-stack.sh (which now calls
   converge.sh internally)
2. Add/update the `--reconfigure` flag handler:
   ```bash
   --reconfigure)
     exec bash "$REPO_DIR/scripts/utils/reconfigure.sh" "$@"
     ;;
   ```

---

## TASK 4: Test reconfigure.sh Workflow

1. Enable a new service via reconfigure wizard
   ```bash
   ./reconfigure.sh
   # Toggle on a disabled service (e.g., comfyui)
   ```
   **Expected:** Only the newly enabled service starts. Everything else
   untouched.

2. Disable a running service
   ```bash
   ./reconfigure.sh
   # Toggle off a running service (e.g., duplicati)
   ```
   **Expected:** Only that service stops. Everything else stays running.

3. No-wizard mode
   ```bash
   # Manually edit stack.json, then:
   ./reconfigure.sh --no-wizard
   ```
   **Expected:** Converges to match edited stack.json without prompts.

---

## TASK 5: Phase 7 — Drift Detection Edge Cases

### Port changes
1. Change a service port in stack.json (e.g., dashboard port 80 → 8080)
2. Run converge.sh — should detect the config change and restart the
   service with the new port
3. If converge-diff doesn't detect port changes today, the fix is in
   state-desired.sh (hash the full config block, not just enabled/disabled)

### Model changes
1. Change chat mode or model selection in stack.json
2. Run converge.sh — verify it triggers the appropriate model swap

### Force mode
```bash
./scripts/utils/converge.sh --force --dry-run
```
**Expected:** All services show as actionable (ignores .last-applied.json).

---

## Priority Order

1. **Task 1** — Validate converge.sh against live stack (prerequisite: install.sh complete)
2. **Task 2** — Refactor full-stack.sh
3. **Task 3** — Wire install.sh --reconfigure
4. **Task 4** — Test reconfigure.sh workflow
5. **Task 5** — Phase 7 edge cases

---

## Key Files

| File | Role |
|------|------|
| `scripts/utils/converge.sh` | Config-driven convergence engine |
| `scripts/utils/reconfigure.sh` | Day-2 reconfiguration (wizard + converge) |
| `scripts/bundles/full-stack.sh` | Install pipeline (to be slimmed down) |
| `install.sh` | Top-level installer entry point |
| `config/stack.json` | Desired state (source of truth) |
| `.last-applied.json` | Snapshot for drift detection |
| `scripts/lib/converge-diff.sh` | Desired vs actual comparison |
| `scripts/lib/state-desired.sh` | Reads stack.json → DESIRED array |
| `scripts/lib/state-actual.sh` | Probes runtime → ACTUAL array |
| `scripts/lib/component-registry.sh` | Loads manifests → COMPONENT_* arrays |
| `scripts/lib/manifest-loader.sh` | Parses *.manifest.json files |

## Health Check Audit Results (2026-04-15)

All 35 components PASS — no remediation needed:

| Component | --health | *_health() | Probe Method |
|-----------|----------|------------|-------------|
| audio-flamingo | ✅ | ✅ | HTTP :8601/ |
| bitnet | ✅ | ✅ | docker exec curl :PORT/v1/models |
| comfyui | ✅ | ✅ | HTTP :8188/ |
| coqui-tts | ✅ | ✅ | HTTP :5002/api/healthcheck |
| dashboard | ✅ | ✅ | HTTP :80/ |
| deerflow | ✅ | ✅ | HTTP :3002/ |
| duplicati | ✅ | ✅ | HTTP :8200/ |
| faster-whisper | ✅ | ✅ | HTTP :8600/health |
| flowise | ✅ | ✅ | HTTP :3005/api/v1/ping |
| gitea | ✅ | ✅ | Docker healthcheck |
| grafana | ✅ | ✅ | HTTP :3001/api/health |
| gvisor-sandbox | ✅ | ✅ | HTTP :18791/healthz |
| htsclaw | ✅ | ✅ | HTTP :18790/healthz |
| langflow | ✅ | ✅ | HTTP :7870/health |
| languagetool | ✅ | ✅ | HTTP :8010/v2/languages |
| llama-swap | ✅ | ✅ | HTTP :8081/health |
| lmstudio | ✅ | ✅ | CLI + HTTP :1234/v1/models |
| localai | ✅ | ✅ | HTTP :8080/readyz |
| n8n | ✅ | ✅ | HTTP :5678/healthz |
| nemoclaw | ✅ | ✅ | OpenShell CLI / Docker |
| ollama | ✅ | ✅ | HTTP :11434/api/tags |
| open-webui | ✅ | ✅ | HTTP :3000/ |
| openspace | ✅ | ✅ | HTTP :5000/sse |
| pipelines | ✅ | ✅ | HTTP :9099/v1/models |
| portainer | ✅ | ✅ | Docker healthcheck |
| prometheus | ✅ | ✅ | HTTP :9090/-/ready |
| searxng | ✅ | ✅ | HTTP :8787/healthz |
| signal | ✅ | ✅ | Docker healthcheck |
| sillytavern | ✅ | ✅ | HTTP :8001/ |
| stable-diffusion | ✅ | ✅ | HTTP :7860/ |
| tailscale | ✅ | ✅ | tailscale status CLI |
| telegram | ✅ | ✅ | Docker healthcheck |
| timeshift | ✅ | ✅ | systemd / CLI |
| unsloth | ✅ | ✅ | HTTP :8888/ |
| vosk | ✅ | ✅ | HTTP health_probe |
