#!/usr/bin/env bash
# Diagnose disk pressure for NemoClaw / openshell gateway k3s eviction loops.
set -u

echo "=== df host ==="
df -h / /var/lib/docker 2>&1 | sed 's/^/  /'
echo

echo "=== docker system df ==="
if command -v docker >/dev/null 2>&1; then
  docker system df 2>&1 | sed 's/^/  /'
  echo
  echo "=== docker system df -v (top reclaimable) ==="
  docker system df -v 2>&1 | sed 's/^/  /' | head -80
else
  echo "  docker not on PATH"
fi
echo

echo "=== ~/.nemoclaw size ==="
du -sh "$HOME/.nemoclaw" 2>/dev/null | sed 's/^/  /' || echo "  (missing)"
du -sh "$HOME/.nemoclaw"/* 2>/dev/null | sed 's/^/  /'
echo

echo "=== ~/.cache size ==="
du -sh "$HOME/.cache" 2>/dev/null | sed 's/^/  /'
echo

echo "=== gateway container df (if running) ==="
if docker ps --format '{{.Names}}' 2>/dev/null | grep -q '^openshell-cluster-nemoclaw$'; then
  docker exec openshell-cluster-nemoclaw df -h / 2>&1 | sed 's/^/  /'
else
  echo "  openshell-cluster-nemoclaw not running"
fi
echo

echo "=== top 10 largest dirs under / (excluding /proc /sys) ==="
sudo du -hxd 1 / 2>/dev/null | sort -hr | head -12 | sed 's/^/  /'
