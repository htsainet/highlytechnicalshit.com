#!/usr/bin/env bash
# scripts/wizard/model-select.sh — Model selection and pull for the active backend
#
# PURPOSE
#   Encapsulates all model selection and download logic so it can be called
#   from multiple entry points without duplication:
#
#     install.sh       → first-time model pull
#     configure.sh     → day-2 model change ("switch my default model")
#     ollama.sh        → standalone model pull/switch
#     reconfigure.sh   → wizard re-run (sources this file)
#
# USAGE (sourced — do NOT run directly)
#
#   source "$REPO_DIR/scripts/wizard/model-select.sh"
#
#   select_model          # interactive: shows model menu for active backend
#   pull_selected_models  # non-interactive: pulls MODEL + INFERENCE_BITNET_MODEL
#   list_available_models # prints models available for current BACKEND
#
# INPUTS (must be set in calling scope before select_model)
#
#   BACKEND             — from inference-profile.sh or stack.json:
#                           "ollama" | "dual" | "localai" | "custom"
#   GPU_VRAM_TOTAL      — MiB, used to recommend models that fit
#   GPU_AVAILABLE       — "true"/"false"
#
# OUTPUTS (env vars exported after select_model)
#
#   MODEL               — default Ollama model tag (e.g. "gemma3:4b")
#   PULL_ALL_MODELS     — "true" if all curated models should be pulled
#   INFERENCE_BITNET_MODEL — BitNet model id (only for dual/dual-lms backends)
#
# MODEL CATALOG (per backend)
#
#   BACKEND = ollama or dual:
#
#     VRAM      Recommended model         Notes
#     ────────────────────────────────────────────────────────────────────────
#     <6GB      smollm2:135m              135M — starter, fast bootstrap
#     6–8GB     gemma3:4b                 4B MoE — fast, good context
#     8–12GB    qwen2.5:7b-instruct-q4_K_M  7B Q4 — non-thinking, fits 8GB cleanly
#     12–16GB   mistral-nemo:latest       12B Q4 — NemoClaw default, strong tool-caller
#     16–24GB   llama3.1:8b              8B full precision
#     24GB+     llama3.3:70b-q4          70B quantised
#
#   BACKEND = localai:
#
#     Uses LocalAI model gallery IDs (format differs from Ollama tags).
#     Model list sourced from: https://models.localai.io/
#
#   BACKEND = dual (BitNet):
#
#     INFERENCE_BITNET_MODEL is always "bitnet" (the bundled 1.58-bit model).
#     No user selection needed — BitNet's model is baked into the container.
#
# VRAM-AWARE DEFAULTS
#
#   select_model pre-selects the recommended model based on GPU_VRAM_TOTAL:
#
#     GPU_VRAM_TOTAL (MiB)   Default MODEL
#     ──────────────────────────────────────
#     < 6144                 smollm2:135m
#     6144 – 8191            gemma3:4b
#     8192 – 12287           qwen2.5:7b-instruct-q4_K_M  ← RTX 3060 8GB
#     12288 – 16383          mistral-nemo:latest         ← RTX 3060 12GB / NemoClaw default
#     16384 – 24575          llama3.1:8b
#     ≥ 24576                llama3.3:70b-q4
#
# NAS MODEL CACHE
#
#   pull_selected_models checks the NAS cache before downloading:
#     1. Model already in Docker volume?   → skip pull
#     2. Model available on NAS mount?     → copy from NAS (fast, no internet)
#     3. Neither?                          → ollama pull, then seed NAS cache
#
#   NAS cache path: $NAS_MODEL_CACHE (default /mnt/htsai-model-backup/ollama/models)
#
# STANDALONE DAY-2 USAGE
#
#   Switch the default model without re-running the full wizard:
#
#     source scripts/wizard/model-select.sh
#     select_model          # pick interactively
#     pull_selected_models  # pull if not cached
#     # then re-run apply_config.sh to update stack.json + .env
#
# DEPENDENCIES
#   - common.sh (step/info/ok/warn helpers)
#   - BACKEND must be set (from inference-profile.sh output or stack.json)
#   - GPU_VRAM_TOTAL must be set
#   - ollama must be running for pull_selected_models
#   - whiptail for select_model
#
# STATUS: Day-2 model management helper.
#         The install wizard no longer includes a model selection menu.
#         A single starter model (smollm2:135m) is pulled during install.
#         Use this file post-install to upgrade to a larger model:
#
#           source scripts/wizard/model-select.sh
#           select_model          # interactive menu
#           pull_selected_models  # download selected model
#
#         See also: FEATURE-064 — Starter Model Pull + Day-2 Upgrade
# ─────────────────────────────────────────────────────────────────────────────

# Guard: must be sourced, not executed
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  echo "[ERROR] model-select.sh must be sourced, not executed directly." >&2
  exit 1
fi

# ── Defaults ─────────────────────────────────────────────────────────────────
MODEL="${MODEL:-}"
PULL_ALL_MODELS="${PULL_ALL_MODELS:-false}"
INFERENCE_BITNET_MODEL="${INFERENCE_BITNET_MODEL:-bitnet}"

# ── _vram_default_model ───────────────────────────────────────────────────────
# Internal: return the recommended model tag for a given VRAM amount.
_vram_default_model() {
  local vram="${1:-0}"
  if   [[ $vram -lt 6144  ]]; then echo "smollm2:135m"
  elif [[ $vram -lt 8192  ]]; then echo "gemma3:4b"
  elif [[ $vram -lt 12288 ]]; then echo "qwen2.5:7b-instruct-q4_K_M"
  elif [[ $vram -lt 16384 ]]; then echo "mistral-nemo:latest"
  elif [[ $vram -lt 24576 ]]; then echo "llama3.1:8b"
  else                              echo "llama3.3:70b-q4"
  fi
}

# ── select_model ─────────────────────────────────────────────────────────────
# Interactive: show a model selection menu appropriate for BACKEND.
# Pre-selects the VRAM-recommended model.
#
# Reads:  BACKEND, GPU_VRAM_TOTAL, GPU_AVAILABLE
# Writes: MODEL, PULL_ALL_MODELS, INFERENCE_BITNET_MODEL
select_model() {
  # Non-interactive (and optional whiptail) model selection.
  # Expects BACKEND, GPU_VRAM_TOTAL, GPU_AVAILABLE to be set in caller.
  BACKEND="${BACKEND:-ollama}"
  GPU_VRAM_TOTAL="${GPU_VRAM_TOTAL:-0}"
  GPU_AVAILABLE="${GPU_AVAILABLE:-false}"

  local _default
  _default="$(_vram_default_model "${GPU_VRAM_TOTAL}")"

  # If user already supplied MODEL, respect it.
  if [[ -n "${MODEL:-}" ]]; then
    echo "[INFO] MODEL already set to '${MODEL}', skipping selection" >&2
    export MODEL PULL_ALL_MODELS INFERENCE_BITNET_MODEL
    return 0
  fi

  case "$BACKEND" in
    localai)
      # Provide a sensible LocalAI default
      MODEL="${MODEL:-localai/opt-6.7b}"
      ;;
    ollama|dual|*)
      MODEL="${MODEL:-${_default}}"
      ;;
  esac

  # Interactive menu when whiptail is available and running in a TTY.
  if command -v whiptail >/dev/null 2>&1 && [ -t 1 ]; then
    local choices=()
    if [[ "$BACKEND" == "localai" ]]; then
      choices+=( "localai/opt-6.7b" "OPT 6.7B (recommended for LocalAI)" "localai/opt-2.7b" "OPT 2.7B (smaller)")
    else
      choices+=( "smollm2:135m" "SmolLM2 135M - starter" "gemma3:4b" "Gemma3 4B (recommended for 6–8GB VRAM)" "qwen2.5:7b-instruct-q4_K_M" "Qwen2.5 7B Instruct (recommended for 8–12GB VRAM, non-thinking)" "mistral-nemo:latest" "Mistral NeMo - 12B Q4 (recommended for 12–16GB VRAM, NemoClaw default, strong tool-caller)" "llama3.1:8b" "Llama 3.1 8B")
    fi

    local sel
    sel=$(whiptail --title "Select model" --menu "Recommended: ${_default}" 20 76 10 "${choices[@]}" 3>&1 1>&2 2>&3) || sel=""
    if [[ -n "$sel" ]]; then
      MODEL="$sel"
    fi

    if whiptail --yesno "Pull curated models in addition to the selected model? (slower)" 8 60; then
      PULL_ALL_MODELS="true"
    else
      PULL_ALL_MODELS="${PULL_ALL_MODELS:-false}"
    fi
  fi

  # Ensure BitNet model is set for dual backends
  INFERENCE_BITNET_MODEL="${INFERENCE_BITNET_MODEL:-bitnet}"

  export MODEL PULL_ALL_MODELS INFERENCE_BITNET_MODEL
  echo "[INFO] Selected MODEL=${MODEL} (PULL_ALL_MODELS=${PULL_ALL_MODELS})" >&2
}

# ── _ollama_exec ─────────────────────────────────────────────────────────────
# Run `ollama <args...>` against the actual running Ollama service.
#
# The stack's Ollama is containerized (see docker-compose.yml: container
# `hts-ai-ollama`, volume `ollama_data:/home/ollama/.ollama`). The host does
# not install the `ollama` CLI by default (bootstrap.sh doesn't do it). We
# therefore route all ollama commands through `docker exec` into the running
# container. Falls back to a host `ollama` CLI if (and only if) the container
# is not running, to support odd dev environments.
#
# Returns the exit code of the underlying `ollama` invocation, or 127 if
# neither a running container nor a host CLI is available.
_ollama_exec() {
  local container="${OLLAMA_CONTAINER:-hts-ai-ollama}"
  local running
  running=$(docker inspect -f '{{.State.Running}}' "$container" 2>/dev/null || echo false)
  if [[ "$running" == "true" ]]; then
    docker exec "$container" ollama "$@"
    return $?
  fi
  if command -v ollama >/dev/null 2>&1; then
    ollama "$@"
    return $?
  fi
  echo "[ERROR] Neither the '$container' container is running nor a host 'ollama' CLI is available." >&2
  return 127
}

# _ollama_has_model <tag> — exit 0 if ollama already has <tag>, else 1.
_ollama_has_model() {
  local tag="$1"
  _ollama_exec list 2>/dev/null | awk 'NR>1 {print $1}' | grep -qxF "$tag"
}

# ── pull_selected_models ─────────────────────────────────────────────────────
# Non-interactive: pull MODEL (and BitNet model if dual backend).
#
# Note on the NAS model cache: the NAS share at $NAS_MODEL_CACHE
# (/mnt/htsai-model-backup/ollama/…) is a *backup snapshot* of the Ollama
# data root — a `models/{blobs,manifests}` tree produced by
# scripts/utils/seed-model-cache.sh. It is NOT a per-tag directory layout
# (there is no `.../ollama/models/qwen2.5-coder:7b/`). Re-hydrating the
# live Ollama volume from that snapshot is the job of the volume-restore
# tooling (rsync / docker volume restore), not this function. Here we
# simply ask the running Ollama service for the tag; if the live volume
# has been re-hydrated, `ollama list` reflects that and we skip the pull.
#
# Reads:  MODEL, BACKEND, INFERENCE_BITNET_MODEL
pull_selected_models() {
  MODEL="${MODEL:-}"
  BACKEND="${BACKEND:-ollama}"

  local to_pull=()

  if [[ "${PULL_ALL_MODELS:-false}" == "true" ]]; then
    to_pull=( "smollm2:135m" "gemma3:4b" "qwen2.5:7b-instruct-q4_K_M" "mistral-nemo:latest" "llama3.1:8b" )
  elif [[ -n "$MODEL" ]]; then
    to_pull=("$MODEL")
  else
    echo "[WARN] No MODEL set and PULL_ALL_MODELS != true; nothing to pull" >&2
    return 1
  fi

  for m in "${to_pull[@]}"; do
    if [[ "$BACKEND" == "ollama" || "$BACKEND" == "dual" ]]; then
      if _ollama_has_model "$m"; then
        echo "[INFO] ollama already has model $m; skipping"
        continue
      fi

      echo "[INFO] Pulling $m via ollama..."
      if _ollama_exec pull "$m"; then
        echo "[OK] pulled $m"
      else
        echo "[ERROR] ollama pull failed for $m" >&2
      fi
    elif [[ "$BACKEND" == "localai" ]]; then
      echo "[INFO] localai backend: model pulls should be performed by LocalAI tooling; skipping $m"
    else
      echo "[INFO] custom backend: skipping automated model pull for $m"
    fi
  done

  if [[ "$BACKEND" == "dual" ]]; then
    echo "[INFO] Ensuring BitNet container/model: ${INFERENCE_BITNET_MODEL:-bitnet}"
  fi
}

# ── pull_coding_tier ─────────────────────────────────────────────────────────
# Coding-tier preset (FEATURE-067) — pulls the three Aider-oriented coder
# models used by the architect+editor config in
# scripts/components/aider/aider.sh:
#
#   qwen2.5-coder:7b    — editor (fast, ~5GB)
#   qwen2.5-coder:14b   — optional middle tier (~8.5GB)
#   deepseek-r1:14b     — architect / reasoning (~9GB)
#
# Routes through `_ollama_exec`, so the pull happens inside the running
# ollama container (the host CLI isn't installed by bootstrap.sh). See the
# note on the NAS model cache in pull_selected_models — cache re-hydration
# is a volume-level operation, not a per-model import.
#
# VRAM-gated: refuses on <8GB GPUs, warns on 8–11GB.
#
# Usage (day-2):
#   source scripts/wizard/model-select.sh
#   pull_coding_tier
#
# Reads:  GPU_VRAM_TOTAL (MiB), OLLAMA_CONTAINER (default: hts-ai-ollama)
# Side effect: models listed in config/llama-swap.yaml become usable via
# the OpenAI-compatible endpoint once this function completes.
pull_coding_tier() {
  GPU_VRAM_TOTAL="${GPU_VRAM_TOTAL:-0}"

  local tier_models=( "qwen2.5-coder:7b" "qwen2.5-coder:14b" "deepseek-r1:14b" )

  # VRAM gate
  if [[ $GPU_VRAM_TOTAL -lt 8192 ]]; then
    echo "[ERROR] pull_coding_tier: GPU_VRAM_TOTAL=${GPU_VRAM_TOTAL} MiB — preset requires ≥8GB (recommended ≥12GB). Aborting." >&2
    return 1
  elif [[ $GPU_VRAM_TOTAL -lt 12288 ]]; then
    echo "[WARN] pull_coding_tier: ${GPU_VRAM_TOTAL} MiB VRAM is below the 12GB recommendation. Sequential-only (llama-swap eviction required); consider Q3 quantized tags (e.g. qwen2.5-coder:14b:q3_K_M) if you hit OOM." >&2
  fi

  local m
  for m in "${tier_models[@]}"; do
    if _ollama_has_model "$m"; then
      echo "[INFO] ollama already has $m; skipping"
      continue
    fi

    echo "[INFO] Pulling $m via ollama …"
    if _ollama_exec pull "$m"; then
      echo "[OK] pulled $m"
    else
      echo "[ERROR] ollama pull failed for $m" >&2
    fi
  done

  echo "[OK] pull_coding_tier complete."
  echo "     Aider (configured by scripts/components/aider/aider.sh) will route"
  echo "     through llama-swap using these models in architect+editor mode."
}

# ── list_available_models ────────────────────────────────────────────────────
# Non-interactive: print all models available for the current backend.
# Useful for scripts that need to enumerate models without a UI.
list_available_models() {
  BACKEND="${BACKEND:-ollama}"
  if [[ "$BACKEND" == "localai" ]]; then
    cat <<'EOF'
localai/opt-2.7b
localai/opt-6.7b
localai/opt-13b
EOF
  else
    cat <<'EOF'
smollm2:135m
gemma3:4b
qwen2.5:7b-instruct-q4_K_M
mistral-nemo:latest
llama3.1:8b
llama3.3:70b-q4
EOF
  fi
}
