#!/usr/bin/env bash
# Get onto feat/nemoclaw-v0.0.29-upgrade rebased on latest origin/main,
# preserving the dirty docker-compose.yml that Tim is iterating on.
#
# Safe to re-run.

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "$REPO_DIR"

BRANCH="feat/nemoclaw-v0.0.29-upgrade"
STASH_TAG="nemoclaw-v0.0.29-prep-$(date +%s)"

echo "==> Working in $REPO_DIR"

# 1. Make sure we're on the right branch.
current="$(git rev-parse --abbrev-ref HEAD)"
if [[ "$current" != "$BRANCH" ]]; then
  echo "==> Switching to $BRANCH"
  git checkout "$BRANCH"
fi

# 2. Fetch latest from origin.
echo "==> Fetching origin"
git fetch origin

# 3. Stash tracked changes if any (untracked files are left alone —
#    PLAN-MITIGATIONS.md will be removed by Opus later, open-pr.sh is
#    a leftover helper).
stashed=0
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "==> Stashing tracked changes as $STASH_TAG"
  git stash push -m "$STASH_TAG"
  stashed=1
else
  echo "==> No tracked changes to stash"
fi

# 4. Rebase onto origin/main.
echo "==> Rebasing onto origin/main"
if ! git rebase origin/main; then
  echo
  echo "FATAL: rebase hit a conflict. Resolve manually, then run:"
  echo "  git rebase --continue"
  echo "  git stash pop   # to restore your working-tree changes"
  exit 1
fi

# 5. Pop the stash if we made one.
if [[ $stashed -eq 1 ]]; then
  echo "==> Restoring stashed changes"
  if ! git stash pop; then
    echo
    echo "WARN: stash pop hit a conflict. Resolve manually."
    echo "      Your stash is still listed in 'git stash list' as $STASH_TAG."
    exit 1
  fi
fi

# 6. Show final state.
echo
echo "==> Done. Current state:"
echo "    Branch  : $(git rev-parse --abbrev-ref HEAD)"
echo "    Head    : $(git log --oneline -1)"
echo "    vs main : $(git rev-list --left-right --count origin/main...HEAD | awk '{print "ahead "$2", behind "$1}')"
echo
echo "==> Working tree:"
git status --short || true
echo
echo "Ready. Start a fresh Sonnet session and hand it:"
echo "  scripts/components/nemoclaw/PROMPT-PHASE-0-1-SONNET.md"
