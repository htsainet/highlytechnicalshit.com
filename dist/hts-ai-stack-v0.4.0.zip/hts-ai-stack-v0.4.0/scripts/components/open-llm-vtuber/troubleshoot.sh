#!/usr/bin/env bash
# scripts/components/open-llm-vtuber/troubleshoot.sh — deterministic diagnostics
#
# Surfaces the exact signals needed to identify why Open-LLM-VTuber's web UI
# becomes unreachable (e.g. after `--choose-avatar`). Each section is labelled
# and self-contained so the output can be pasted verbatim into an issue.
#
# Usage:
#   ./scripts/components/open-llm-vtuber/troubleshoot.sh
#   ./scripts/components/open-llm-vtuber/troubleshoot.sh > vtuber-diag.txt 2>&1
#
# Exit code: 0 if the script ran to completion. Individual checks never abort;
# every probe records its own status so the full picture is always captured.

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# Best-effort .env load; do not fail if absent.
if [[ -f "$REPO_DIR/.env" ]]; then
  set -a; . "$REPO_DIR/.env"; set +a
fi

CONTAINER="${OPEN_LLM_VTUBER_CONTAINER:-hts-ai-open-llm-vtuber}"
SERVICE="open-llm-vtuber"
PORT="${OPEN_LLM_VTUBER_PORT:-12393}"
IMAGE_TAG="hts-ai-open-llm-vtuber"
HOST_CONF="$REPO_DIR/config/open-llm-vtuber/conf.yaml"
HOST_MODELS="$REPO_DIR/live2d-models"
LOG_TAIL="${VTUBER_DIAG_LOG_TAIL:-200}"

section() {
  printf '\n── %s ─────────────────────────────────────────────────────────────\n' "$1"
}

note() { printf '[info] %s\n' "$*"; }
warn() { printf '[warn] %s\n' "$*"; }
fail() { printf '[fail] %s\n' "$*"; }
ok()   { printf '[ ok ] %s\n' "$*"; }

# Run a command, label it, never abort on failure.
run() {
  local label="$1"; shift
  section "$label"
  printf '[cmd] %s\n' "$*"
  if "$@"; then
    return 0
  fi
  local rc=$?
  printf '[rc ] %d\n' "$rc"
  return 0
}

# ── 0. Environment ───────────────────────────────────────────────────────────
section "0. Environment"
printf 'date           : %s\n' "$(date -Iseconds)"
printf 'host           : %s\n' "$(hostname)"
printf 'repo           : %s\n' "$REPO_DIR"
printf 'container      : %s\n' "$CONTAINER"
printf 'service (compose): %s\n' "$SERVICE"
printf 'port           : %s\n' "$PORT"
printf 'host conf.yaml : %s\n' "$HOST_CONF"
printf 'host models dir: %s\n' "$HOST_MODELS"
printf 'VTUBER_DEFAULT_AVATAR (.env): %s\n' "${VTUBER_DEFAULT_AVATAR:-<unset>}"

# ── 1. Tooling availability ──────────────────────────────────────────────────
section "1. Tooling"
for tool in docker curl jq python3 awk stat; do
  if command -v "$tool" >/dev/null 2>&1; then
    ok "$tool: $(command -v "$tool")"
  else
    warn "$tool: not found"
  fi
done

if ! command -v docker >/dev/null 2>&1; then
  fail "docker not on PATH — most subsequent checks will be skipped"
  HAS_DOCKER=0
else
  HAS_DOCKER=1
fi

# ── 2. Container state ───────────────────────────────────────────────────────
if (( HAS_DOCKER )); then
  run "2a. docker ps (all states)" \
    docker ps -a --filter "name=$CONTAINER" \
      --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}\t{{.Image}}'

  run "2b. docker inspect (state, restartcount, exitcode, oom, healthcheck)" \
    bash -c "docker inspect '$CONTAINER' --format '
state.status      : {{.State.Status}}
state.running     : {{.State.Running}}
state.restarting  : {{.State.Restarting}}
state.oomkilled   : {{.State.OOMKilled}}
state.exitcode    : {{.State.ExitCode}}
state.error       : {{.State.Error}}
state.startedat   : {{.State.StartedAt}}
state.finishedat  : {{.State.FinishedAt}}
restartcount      : {{.RestartCount}}
image (id)        : {{.Image}}
config.image      : {{.Config.Image}}
health.status     : {{if .State.Health}}{{.State.Health.Status}}{{else}}<no healthcheck record>{{end}}
health.failingstreak: {{if .State.Health}}{{.State.Health.FailingStreak}}{{else}}-{{end}}
' 2>&1"

  run "2c. last 5 healthcheck probes" \
    bash -c "docker inspect '$CONTAINER' --format '{{json .State.Health}}' 2>/dev/null \
      | { command -v jq >/dev/null && jq '.Log[-5:] // \"<none>\"' || cat; }"
fi

# ── 3. Container logs ────────────────────────────────────────────────────────
if (( HAS_DOCKER )); then
  run "3a. docker logs --tail $LOG_TAIL" \
    docker logs --tail "$LOG_TAIL" --timestamps "$CONTAINER"

  run "3b. log lines matching error|exception|traceback|fatal (case-insensitive, last 200)" \
    bash -c "docker logs --tail 1000 --timestamps '$CONTAINER' 2>&1 \
      | grep -iE 'error|exception|traceback|fatal|critical|model.*not.*found|conf\\.yaml|live2d_model_name' \
      | tail -n 200 || true"
fi

# ── 4. Image vs running container drift ──────────────────────────────────────
if (( HAS_DOCKER )); then
  run "4. image vs running container" \
    bash -c "
      tag_id=\$(docker image inspect '$IMAGE_TAG' --format '{{.Id}}' 2>/dev/null || echo MISSING)
      cont_id=\$(docker inspect '$CONTAINER' --format '{{.Image}}' 2>/dev/null || echo MISSING)
      printf 'tag $IMAGE_TAG points to image id : %s\n' \"\$tag_id\"
      printf 'container is running image id    : %s\n' \"\$cont_id\"
      if [[ \"\$tag_id\" != \"MISSING\" && \"\$cont_id\" != \"MISSING\" && \"\$tag_id\" != \"\$cont_id\" ]]; then
        printf '[warn] DRIFT: container is running an OLD image — compose up did not recreate.\n'
      else
        printf '[ ok ] image ids match (or one side missing).\n'
      fi
      docker image inspect '$IMAGE_TAG' --format 'image created : {{.Created}}' 2>/dev/null || true
    "
fi

# ── 5. Bind-mount integrity (conf.yaml inode, live2d-models) ─────────────────
section "5a. host conf.yaml"
if [[ -f "$HOST_CONF" ]]; then
  ok "host file exists: $HOST_CONF"
  stat -c 'host inode=%i  size=%s  mtime=%y' "$HOST_CONF"
  printf '── host conf.yaml content (filtered to identity) ──\n'
  grep -nE '^\s*(host|port|live2d_model_name|conf_name|conf_uid|character_name)' "$HOST_CONF" || true
else
  fail "host conf.yaml MISSING — bind mount source does not exist; container will see a stale or empty file"
fi

if (( HAS_DOCKER )); then
  run "5b. container view of /app/conf.yaml" \
    bash -c "
      docker exec '$CONTAINER' sh -c 'ls -l /app/conf.yaml; stat -c \"container inode=%i size=%s mtime=%y\" /app/conf.yaml; echo ---; grep -nE \"^[[:space:]]*(host|port|live2d_model_name|conf_name|conf_uid|character_name)\" /app/conf.yaml' 2>&1
    "

  # Compare inodes — if container's inode != host's, the bind-mount is pinned
  # to a deleted/replaced file and the container is reading stale config.
  run "5c. inode drift check (host vs container)" \
    bash -c "
      host_ino=\$(stat -c '%i' '$HOST_CONF' 2>/dev/null || echo MISSING)
      cont_ino=\$(docker exec '$CONTAINER' stat -c '%i' /app/conf.yaml 2>/dev/null || echo MISSING)
      printf 'host inode      : %s\n' \"\$host_ino\"
      printf 'container inode : %s\n' \"\$cont_ino\"
      if [[ \"\$host_ino\" != \"MISSING\" && \"\$cont_ino\" != \"MISSING\" && \"\$host_ino\" != \"\$cont_ino\" ]]; then
        printf '[warn] INODE DRIFT: host conf.yaml was replaced after the container started — the container is still reading the OLD file.\n'
      fi
    "

  run "5d. md5 drift check (host vs container)" \
    bash -c "
      host_md5=\$(md5sum '$HOST_CONF' 2>/dev/null | awk '{print \$1}')
      cont_md5=\$(docker exec '$CONTAINER' md5sum /app/conf.yaml 2>/dev/null | awk '{print \$1}')
      printf 'host md5      : %s\n' \"\${host_md5:-MISSING}\"
      printf 'container md5 : %s\n' \"\${cont_md5:-MISSING}\"
      if [[ -n \"\$host_md5\" && -n \"\$cont_md5\" && \"\$host_md5\" != \"\$cont_md5\" ]]; then
        printf '[warn] CONTENT DRIFT: container conf.yaml does not match host conf.yaml.\n'
      fi
    "
fi

# ── 6. Avatar selection sanity ───────────────────────────────────────────────
section "6a. live2d-models directories on host"
if [[ -d "$HOST_MODELS" ]]; then
  printf '%s contains %d entries\n' "$HOST_MODELS" "$(ls -1 "$HOST_MODELS" 2>/dev/null | wc -l)"
  # shellcheck disable=SC2011
ls -1d "$HOST_MODELS"/*/ 2>/dev/null | xargs -I{} basename {} | sort
else
  fail "host live2d-models dir missing: $HOST_MODELS"
fi

avatar="${VTUBER_DEFAULT_AVATAR:-}"
section "6b. selected avatar '$avatar' validity"
if [[ -z "$avatar" ]]; then
  warn "VTUBER_DEFAULT_AVATAR not set in environment"
elif [[ ! -d "$HOST_MODELS/$avatar" ]]; then
  fail "avatar directory missing: $HOST_MODELS/$avatar"
else
  ok "avatar dir exists: $HOST_MODELS/$avatar"
  # Either a top-level *.model3.json or one inside runtime/ (per routes_patched.py logic)
  m3=$(find "$HOST_MODELS/$avatar" -maxdepth 2 -name '*.model3.json' 2>/dev/null | head -3)
  if [[ -n "$m3" ]]; then
    ok "found model3.json:"
    printf '  %s\n' $m3
  else
    fail "no *.model3.json found under $HOST_MODELS/$avatar (top-level or runtime/) — server cannot load this avatar"
  fi
fi

# What does the container's conf.yaml actually have for live2d_model_name?
if (( HAS_DOCKER )); then
  run "6c. live2d_model_name as seen INSIDE the container" \
    bash -c "docker exec '$CONTAINER' sh -c \"grep -nE '^[[:space:]]*live2d_model_name' /app/conf.yaml\" 2>&1 || true"
fi

# ── 7. Port reachability ─────────────────────────────────────────────────────
if command -v curl >/dev/null 2>&1; then
  run "7a. curl http://localhost:$PORT/ (HTTP code + 0.5s timing)" \
    curl -sS -o /dev/null -w 'http_code=%{http_code}  time_total=%{time_total}s\n' \
      --max-time 5 "http://localhost:$PORT/"

  run "7b. curl http://localhost:$PORT/live2d-models/info (custom route)" \
    curl -sS --max-time 5 "http://localhost:$PORT/live2d-models/info" \
      || true
else
  warn "curl not available; skipping HTTP probes"
fi

if command -v ss >/dev/null 2>&1; then
  run "7c. listeners on :$PORT" bash -c "ss -ltnp 2>/dev/null | grep -E ':$PORT(\s|$)' || echo '(no listener)'"
fi

# ── 8. Compose drift ─────────────────────────────────────────────────────────
if (( HAS_DOCKER )); then
  run "8a. compose ps (this service)" \
    bash -c "cd '$REPO_DIR' && docker compose --profile open-llm-vtuber ps $SERVICE 2>&1"

  run "8b. compose config (resolved service block)" \
    bash -c "cd '$REPO_DIR' && docker compose --profile open-llm-vtuber config $SERVICE 2>&1 | head -120"
fi

# ── 9. Summary heuristic ─────────────────────────────────────────────────────
section "9. Summary heuristic"
if (( HAS_DOCKER )); then
  status=$(docker inspect "$CONTAINER" --format '{{.State.Status}}' 2>/dev/null || echo missing)
  rc=$(docker inspect "$CONTAINER" --format '{{.RestartCount}}' 2>/dev/null || echo 0)
  health=$(docker inspect "$CONTAINER" --format '{{if .State.Health}}{{.State.Health.Status}}{{end}}' 2>/dev/null || echo "")
  oom=$(docker inspect "$CONTAINER" --format '{{.State.OOMKilled}}' 2>/dev/null || echo false)
  exitcode=$(docker inspect "$CONTAINER" --format '{{.State.ExitCode}}' 2>/dev/null || echo 0)

  printf 'state.status   : %s\n' "$status"
  printf 'restartcount   : %s\n' "$rc"
  printf 'health.status  : %s\n' "${health:-<none>}"
  printf 'oomkilled      : %s\n' "$oom"
  printf 'last exitcode  : %s\n' "$exitcode"

  case "$status" in
    missing)    fail "Container does not exist — run --start.";;
    restarting) fail "Container is in a restart loop. Most common cause: invalid conf.yaml or unloadable avatar. See section 3b for stack traces.";;
    exited)     fail "Container has exited. See section 3a for crash output and 2b for exitcode.";;
    running)
      if [[ "$health" == "unhealthy" ]]; then
        fail "Running but unhealthy — uvicorn likely crashed inside; see section 3b."
      elif (( rc > 2 )); then
        warn "Running but has restarted $rc times — flapping. Investigate logs (section 3b)."
      else
        ok "Container appears healthy at the docker level. If Firefox still can't load, check sections 5c/5d (config drift) and 7a (HTTP code)."
      fi
      ;;
  esac
else
  warn "Docker not available — re-run this script on the host where the stack is deployed."
fi

section "Done"
note "Capture full output with:  $0 > vtuber-diag.txt 2>&1"
