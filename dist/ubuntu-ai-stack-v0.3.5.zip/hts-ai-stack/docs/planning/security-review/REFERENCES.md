# Security Review References

## Papers resolved (12 total, 0 deep-read yet)

Full paper tracking table: **[../security-whitepapers/REFERENCES.md](../security-whitepapers/REFERENCES.md)**

| Priority | arXiv | Title | Key Relevance |
|----------|-------|-------|---------------|
| TIER 1 | 2603.26221 | Clawed and Dangerous | 6-dimensional taxonomy, evaluation scorecard, reference doctrine for secure agent platforms |
| TIER 1 | 2603.23064 | Mind Your HEARTBEAT | OpenClaw background execution enables silent memory pollution |
| TIER 1 | 2603.10387 | Don't Let the Claw Grip Your Hand | 47 adversarial scenarios, 17% native defense rate |
| TIER 1 | 2603.16572 | Malicious Or Not | 238K skill ecosystem analysis, supply chain classification |
| TIER 1 | 2603.11619 | Taming OpenClaw | Five-layer lifecycle security framework |
| TIER 2 | 2602.11416 | Optimizing Agent Planning for Security and Autonomy | Security-aware planning, autonomy metrics, HITL design |
| TIER 2 | 2602.06258 | GRP-Obliteration (Russinovich) | Safety alignment removable with single prompt — affects local Ollama models |
| TIER 2 | 2603.19469 | Framework for Formalizing LLM Agent Security | Four security properties: task alignment, action alignment, source auth, data isolation |
| TIER 3 | 2603.22868 | Agent-Sentry | Behavioral bounding via execution provenance graphs |
| TIER 3 | 2310.02238 | Who's Harry Potter? (Russinovich) | LLM unlearning — lower priority |
| TIER 3 | 2602.20044 | Let There Be Claws | AI agent social network analysis — tangential |
| TIER 3 | 2404.01833 | Crescendo (Russinovich) | Multi-turn jailbreak attack — recommended addition |

## Repos reviewed (2 of ~45)

Full security repo tracking table: **[../security-repos/REFERENCES.md](../security-repos/REFERENCES.md)**
Per-repo review artifacts: `../security-repos/owner-reponame.md`

| Repo | Verdict | Key Value |
|------|---------|-----------|
| **slowmist/openclaw-security-practice-guide** | **ADOPT** | Three-layer defense matrix (pre/in/post-action), nightly audit script with 13 metrics, Git brain backup, skill installation audit. Also install companion: slowmist/slowmist-agent-security |
| **prompt-security/clawsec** | **ADOPT** | Drift detection for SOUL.md/IDENTITY.md, SHA256 skill verification, NVD CVE feed, audit watchdog. From Prompt Security / SentinelOne. |

**Key insight:** SlowMist + ClawSec are complementary, not competing. SlowMist = behavioral framework + nightly audit. ClawSec = skill verification + drift detection + CVE feed. Both should be adopted.

### Repos Remaining for Review (Tier 1, next batch)

| Repo | Why |
|------|-----|
| adversa-ai/secureclaw | AI red-teaming firm — agent security tooling |
| tophant-ai/ClawVault | Credential/secret management for agents |
| Atlas-Cowork/openclaw-reference-setup | Production-grade OpenClaw config to compare against |
| Tencent/AI-Infra-Guard | AI infrastructure security from Tencent |
| gendigitalinc/sage | Agent security from Gen Digital (NortonLifeLock parent) |
| sinewaveai/agent-security-scanner-mcp | MCP-based security scanner |
| pegasi-ai/clawreins | HITL approval controls |
| SeyZ/clawbands | Alternative sandboxing (compare with OpenShell) |
| Drakon-Systems-Ltd/ShieldCortex | Security layer for agents |
