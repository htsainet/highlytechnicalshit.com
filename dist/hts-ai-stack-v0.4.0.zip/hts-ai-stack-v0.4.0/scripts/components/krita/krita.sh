#!/usr/bin/env bash
# scripts/components/krita/krita.sh — Krita: install, configure, health
#
# Host-native installer for Krita, a professional digital painting application.
# Features brush engines, layer management, and built-in frame-by-frame animation.
#
# Standalone usage:
#   ./scripts/components/krita/krita.sh              # full: install + configure + health
#   ./scripts/components/krita/krita.sh --install    # install only
#   ./scripts/components/krita/krita.sh --configure  # configure only
#   ./scripts/components/krita/krita.sh --start      # no-op (desktop app)
#   ./scripts/components/krita/krita.sh --stop       # no-op (desktop app)
#   ./scripts/components/krita/krita.sh --restart    # no-op (desktop app)
#   ./scripts/components/krita/krita.sh --health     # health check only
#   ./scripts/components/krita/krita.sh --status     # show status + health
#   ./scripts/components/krita/krita.sh --destroy    # uninstall Krita
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

load_env

krita_install() {
  step "Krita — install"
  if command -v krita &>/dev/null; then
    skip "Krita already installed."
  else
    info "Installing Krita via snap (latest stable)..."
    sudo snap install krita
    ok "Krita installed."
  fi
}

krita_configure() {
  step "Krita — configure"
  info "Krita is a desktop application — no service configuration needed."
  info "GPU-accelerated canvas rendering is enabled automatically."
  ok "Krita configured."
}

krita_start() {
  step "Krita — start"
  info "Krita is a desktop application. Launch from your application menu."
}

krita_stop() {
  step "Krita — stop"
  info "Krita is a desktop application. Close it from the window."
}

krita_restart() { krita_stop; krita_start; }

krita_health() {
  step "Krita — health"
  if command -v krita &>/dev/null; then
    ok "Krita is installed."
    return 0
  else
    warn "Krita is not installed."
    return 1
  fi
}

krita_status() { step "Krita — status"; krita_health; }

krita_destroy() {
  step "Krita — destroy"
  if snap list krita &>/dev/null 2>&1; then
    info "Removing Krita snap..."
    sudo snap remove krita
    ok "Krita removed."
  elif dpkg -l krita &>/dev/null 2>&1; then
    info "Removing Krita apt package..."
    sudo apt-get remove -y krita
    ok "Krita removed."
  else
    skip "Krita is not installed."
  fi
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  case "${1:-}" in
    --install)   krita_install   ;;
    --configure) krita_configure ;;
    --start)     krita_start     ;;
    --stop)      krita_stop      ;;
    --restart)   krita_restart   ;;
    --health)    krita_health    ;;
    --status)    krita_status    ;;
    --destroy)   krita_destroy   ;;
    *)
      krita_install
      krita_configure
      krita_health
      ;;
  esac
fi
