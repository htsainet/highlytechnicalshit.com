# Evaluate NVIDIA Blueprints for NAT PoC

Purpose

- Investigate NVIDIA-provided blueprints (if any) for NAT / NeMo deployments and determine integration effort.

Checklist

- Inventory available blueprints and their requirements.
- Assess compatibility with OpenShell sandboxes and Docker-first rule.
- Note any licensing or runtime constraints.

Deliverables

- Short summary report with recommended approach and any blockers.

Next steps

- If blueprints look promising, attempt a small deploy in an isolated environment and capture logs.
