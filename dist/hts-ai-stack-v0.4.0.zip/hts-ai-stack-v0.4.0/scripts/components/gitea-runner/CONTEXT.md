# Gitea Runner Component — CONTEXT

Last updated: 2026-04-21

## What is the Gitea Runner?

`act_runner` is Gitea's official CI/CD runner — a daemon that polls a
Gitea instance for queued Actions workflows and executes them in
Docker containers, following the same `.gitea/workflows/*.yaml` schema
as GitHub Actions.

- Source: <https://gitea.com/gitea/act_runner>
- Docs: <https://docs.gitea.com/usage/actions/act-runner>

## How it fits into the HTS AI Stack

A **containerized service**, introduced by FEATURE-054 as part of the
Developer Tools Suite. Runs as `hts-ai-gitea-runner` under Docker
Compose (`profile: gitea-runner`) and registers against the stack's
local Gitea instance (`hts-ai-gitea`) at `http://gitea:3001`. Executes
workflow jobs in ephemeral `node:20-bookworm` containers by default
(configurable via `GITEA_RUNNER_LABELS`).

```text
Developer pushes → Gitea → queues workflow
                           ↓
               act_runner polls → spawns ephemeral docker container
                                   (via mounted /var/run/docker.sock)
```

The runner shares the host's Docker socket so it can spin up sibling
containers for each job. It does **not** use the GPU.

## Install method

Compose-based — `install_type: compose` in the manifest. Image built
from `docker/gitea-runner/` (tag `hts-ai-gitea-runner`). Lifecycle
functions (`gitea_runner_install`, `_start`, `_stop`, `_health`,
`_destroy`) use `docker compose` helpers from
`scripts/lib/compose.sh`.

## Files and structure

| File | Purpose |
|------|---------|
| `gitea-runner.sh` | Lifecycle: install (build image), configure (token handoff), start, stop, restart, health, destroy, status |
| `gitea-runner.manifest.json` | Component metadata (install_type: compose; depends on `gitea`) |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and related features |

## Runner registration

`act_runner` needs a **registration token** from Gitea to bind to the
instance. `gitea_runner_configure` fetches or accepts
`GITEA_RUNNER_TOKEN` from `.env`; the token is ephemeral (single-use)
and is regenerated on the Gitea admin page
(`/-/admin/actions/runners`) if the runner needs to re-register (e.g.
after a volume wipe).

## Security posture

- Mounts `/var/run/docker.sock` — **the runner has full Docker daemon
  access on the host**. Workflow YAML is effectively trusted code. Keep
  Gitea to internal users only (UFW + auth); do not expose Gitea
  publicly without runner network isolation.
- Runs only when the `gitea-runner` Compose profile is active.

## Logging conventions

All log calls use the project-wide helpers defined in
`scripts/lib/common.sh`: `info`, `ok`, `warn`, `fail`, `step`. The
previously used `log_info` / `log_ok` / `log_warn` names were never
defined anywhere in `scripts/lib/` and have been renamed stack-wide —
see FEATURE-067 commit for the cleanup.

## Related components

- Gitea (`scripts/components/gitea/`) — the server this runner
  registers against; must be up and reachable at `gitea:3001` inside
  the `ai-network` before the runner can start.
- OpenCode / Aider / Tabby — sibling FEATURE-054 dev-tools (not
  dependencies).

See [usage.md](./usage.md) for command usage.
