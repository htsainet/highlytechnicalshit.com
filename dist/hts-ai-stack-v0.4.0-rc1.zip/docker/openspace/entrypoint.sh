#!/bin/sh
set -e

# Start the dashboard backend (serves the built frontend at /app/frontend/dist)
openspace-dashboard --host 0.0.0.0 --port 7788 &

# Start MCP server in the foreground
exec openspace-mcp --transport sse --host 0.0.0.0 --port 5000
