# Ollama References

Last updated: 2026-04-21 09:33:00

## Upstream

- [GitHub — ollama/ollama](https://github.com/ollama/ollama)

## Official documentation

- [Ollama Docs](https://github.com/ollama/ollama/tree/main/docs)
- [Ollama Model Library](https://ollama.com/library)
- [Ollama API Reference](https://github.com/ollama/ollama/blob/main/docs/api.md)
- [Ollama Modelfile Reference](https://github.com/ollama/ollama/blob/main/docs/modelfile.md) — `FROM`, `TEMPLATE`, `PARAMETER stop`, `SYSTEM`
- [Ollama Import Guide](https://github.com/ollama/ollama/blob/main/docs/import.md) — importing GGUF files and custom Modelfiles

## Chat template references

- [Mistral v1 prompt format](https://docs.mistral.ai/guides/prompting-capabilities/) — `<s>[INST] … [/INST]` wrapping, `</s>` EOS
- [Meta Llama 2 prompt format](https://llama.meta.com/docs/model-cards-and-prompt-formats/meta-llama-2/) — `[INST] <<SYS>> … <</SYS>>` system wrapping
- [Meta Llama 3 prompt format](https://llama.meta.com/docs/model-cards-and-prompt-formats/meta-llama-3/) — `<|start_header_id|>`, `<|eot_id|>` tokens
- [Gemma model card](https://huggingface.co/google/gemma-7b-it) — `<start_of_turn>user` / `<start_of_turn>model` / `<end_of_turn>` tokens
- [Cohere Command-R prompt format](https://docs.cohere.com/docs/prompting-command-r) — `<|START_OF_TURN_TOKEN|><|USER_TOKEN|>` / `<|CHATBOT_TOKEN|>` / `<|END_OF_TURN_TOKEN|>`
- [Alpaca/Stanford instruction format](https://github.com/tatsu-lab/stanford_alpaca) — `### Instruction:` / `### Response:` sections; also used by Vicuna and WizardLM
- [DeepSeek v1 model card](https://huggingface.co/deepseek-ai/deepseek-llm-7b-chat) — `User:` / `Assistant:` turns with `<|end_of_sentence|>` EOS (v2/v3 use ChatML)
- [Falcon model card](https://huggingface.co/tiiuae/falcon-7b-instruct) — `User:` / `Falcon:` turns (TII v1; Falcon 2 uses ChatML)
- [Phi-2 model card](https://huggingface.co/microsoft/phi-2) — `Instruct:` / `Output:` single-turn (Phi-3/4 use ChatML)
- [ChatML format](https://github.com/openai/openai-python/blob/release-v0.28.0/chatml.md) — `<|im_start|>` / `<|im_end|>` used by Qwen, Phi-3/4, Nemotron, DeepSeek v2+

## HuggingFace GGUF notes

- HuggingFace GGUF files embed a `tokenizer.chat_template` in Jinja2 format.
  Ollama converts it at pull time, but conversion can fail when the template
  uses unsupported Jinja2 features or the field is absent entirely.
- `ollama create` does **not** accept `hf.co/` as an output model namespace —
  that prefix is reserved for remote HuggingFace pulls. Fixed models must be
  registered under a plain local name that preserves the quantization tag,
  e.g. `mistral-7b-instruct-v0.2-q4_k_m`. Models without a tag get a tagless
  alias, e.g. `model-7b`. The org is omitted; same-tag cross-org collisions
  are caught by a collision guard in `_ollama_fix_template_for`.
- `mradermacher` on HuggingFace is a major source for Mistral-family GGUF
  quantisations. Base Mistral Instruct models from that org use Mistral v1
  prompt format; ChatML fine-tunes (OpenHermes-2/2.5, Nous-Hermes-2,
  dolphin-2.x, OpenOrca) also hosted there use ChatML — the autofix routes
  them correctly based on the model name.
