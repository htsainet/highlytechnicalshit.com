# GIMP — References

## Upstream

- **Homepage**: <https://www.gimp.org/>
- **Source**: <https://gitlab.gnome.org/GNOME/gimp>
- **Snap package**: <https://snapcraft.io/gimp>
- **Documentation**: <https://docs.gimp.org/>

## Notes

- GPLv3+ license
- Snap provides latest stable without PPA management
- Supports Python-Fu (Python scripting) and Script-Fu (Scheme scripting)
