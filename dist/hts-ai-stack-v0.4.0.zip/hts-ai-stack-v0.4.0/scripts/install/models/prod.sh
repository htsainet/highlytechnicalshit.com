#!/usr/bin/env bash
set -euo pipefail
# ─────────────────────────────────────────────────────────────────────────────
# prod.sh
# Seeds ollama-prod with approved models and starts sd-prod.

# Leaves both containers RUNNING after completion.
# ─────────────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(dirname "$0")"
if [[ -f "${SCRIPT_DIR}/helpers.sh" ]]; then
  source "${SCRIPT_DIR}/helpers.sh"
else
  echo "[FAIL] helpers.sh not found in ${SCRIPT_DIR}" >&2
  exit 1
fi
export COMPOSE_FILE="$(cd "${SCRIPT_DIR}/../../.." && pwd)/instances/prod/docker-compose.yml"
ensure_ai_network

OLLAMA_CONTAINER="hts-ai-ollama-prod"
OLLAMA_PORT="11434"
OLLAMA_DEFAULT="smollm2:135m"
SD_SERVICE="hts-ai-stable-diffusion-prod"

# ─────────────────────────────────────────────────────────────────────────────
# PROD OLLAMA MODELS — starter only; upgrade later via model-select.sh
# ─────────────────────────────────────────────────────────────────────────────
OLLAMA_MODELS_PROD=(
  "smollm2:135m"
)

# ─────────────────────────────────────────────────────────────────────────────

step "0 — Host directories"
create_model_dirs

# ── Step 1: Ollama prod ───────────────────────────────────────────────────────
step "1 — Ollama prod models"

start_container "$OLLAMA_CONTAINER"
wait_for_ollama "$OLLAMA_CONTAINER" "$OLLAMA_PORT"

info "Pulling default model first: $OLLAMA_DEFAULT"
pull_ollama_if_missing "$OLLAMA_CONTAINER" "$OLLAMA_PORT" "$OLLAMA_DEFAULT"

if [[ "${PULL_ALL_MODELS:-true}" == "true" ]]; then
  info "Pulling remaining prod models in background..."
  pids=()
  for model in "${OLLAMA_MODELS_PROD[@]}"; do
    if [[ "$model" == "$OLLAMA_DEFAULT" ]]; then
      continue
    fi

    (
      pull_ollama_if_missing "$OLLAMA_CONTAINER" "$OLLAMA_PORT" "$model"
    ) &
    pids+=("$!")
  done

  for pid in "${pids[@]}"; do
    wait "$pid"
  done
  ok "All prod ollama models are ready."
else
  info "PULL_ALL_MODELS=false — skipping additional models (only default loaded)"
fi

# ── Step 2: Stable Diffusion prod ─────────────────────────────────────────────
if [[ "${IMAGES_ENABLED:-false}" == "true" ]]; then
  step "2 — Stable Diffusion prod checkpoints"

  # ─────────────────────────────────────────────────────────────────────────────
  # PROD SD MODELS
  # High-quality checkpoints for production image generation.
  # Full VRAM mode (no --medvram) — activate via converge.sh
  #
  # dreamshaper_v8       — versatile, characters, fantasy, stylized realism
  # majicmixRealistic_v7 — photorealistic portraits, highly detailed
  # ─────────────────────────────────────────────────────────────────────────────
  SD_MODELS_PROD=(
    "dreamshaper_v8.safetensors|https://huggingface.co/Lykon/DreamShaper/resolve/main/DreamShaper_8_pruned.safetensors"
    "majicmixRealistic_v7.safetensors|https://huggingface.co/digiplay/majicMIX_realistic_v7/resolve/main/majicmixRealistic_v7.safetensors"
  )

  SD_VOLUME=$(find_or_create_sd_volume "sd_models_prod" "$SD_SERVICE")
  info "Using volume: $SD_VOLUME"

  for entry in "${SD_MODELS_PROD[@]}"; do
    filename="${entry%%|*}"
    url="${entry##*|}"
    download_sd_if_missing "$SD_VOLUME" "$filename" "$url"
  done

  info "Stopping $SD_SERVICE — use converge.sh to start in SD mode."
  stop_container "$SD_SERVICE"
else
  info "Image generation disabled — skipping Stable Diffusion setup"
fi

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
ok "Prod setup complete."
info "  ollama-prod  → running on port $OLLAMA_PORT (default: $OLLAMA_DEFAULT)"
info "  sd-prod      → stopped (port 7860 when running)"
info "  SD models    → dreamshaper_v8, majicmixRealistic_v7"
info ""
info "Operating modes:"
info "  Use converge.sh to manage services"
info ""
info "Next: run ./scripts/install/models/test.sh"
