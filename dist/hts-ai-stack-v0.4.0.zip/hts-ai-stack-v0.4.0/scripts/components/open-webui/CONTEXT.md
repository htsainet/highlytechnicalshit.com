# Open WebUI Component

Last updated: 2026-04-15

## What happens here

Open WebUI is the primary chat interface for the stack. It provides a
ChatGPT-style web UI that connects to Ollama (and other OpenAI-compatible
backends) for local LLM conversations, RAG, and tool use.

## Files and structure

| File | Purpose |
|------|---------|
| `open-webui.sh` | Full lifecycle: install, configure, start, stop, health |
| `open-webui.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

See [usage.md](./usage.md) for command usage.
