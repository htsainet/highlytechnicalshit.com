#!/usr/bin/env bash
# 7.1-setup-civitai.sh — Install CivitAI Shortcut extension into Stable Diffusion WebUI
#
# Clones the extension into the persistent sd_extensions volume, then restarts
# the container so SD WebUI picks it up.
#
# Run once. Safe to re-run — skips clone if already installed.
#
# Access after install:
#   http://<server-ip>:7860  →  Extensions tab  →  CivitAI Shortcut
#   (or directly: CivitAI icon in the top navigation bar)

set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already installed"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; exit 1; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

EXT_DIR="/app/stable-diffusion-webui/extensions"
EXT_NAME="civitai-shortcut"
EXT_REPO="https://github.com/sunnyark/civitai-shortcut.git"
CONTAINER_PREFIX="stable-diffusion-"

# ── Step 1: Discover existing Stable Diffusion containers ────────────────────
step "1 — Discover Stable Diffusion containers"

mapfile -t SD_CONTAINERS < <(docker ps -a --format '{{.Names}}' | grep -E "^${CONTAINER_PREFIX}" || true)

(( ${#SD_CONTAINERS[@]} > 0 )) \
  || fail "No containers found with prefix '${CONTAINER_PREFIX}'. Create/start them with: docker compose up -d stable-diffusion-prod"

info "Found ${#SD_CONTAINERS[@]} container(s): ${SD_CONTAINERS[*]}"

# ── Step 2: Install extension in each container ──────────────────────────────
step "2 — Install CivitAI Shortcut extension in each container"

for CONTAINER in "${SD_CONTAINERS[@]}"; do
  echo
  info "Processing '$CONTAINER'..."

  WAS_RUNNING="false"
  if docker inspect --format '{{.State.Running}}' "$CONTAINER" 2>/dev/null | grep -q true; then
    WAS_RUNNING="true"
  else
    info "Starting '$CONTAINER' temporarily for install..."
    docker start "$CONTAINER" >/dev/null
  fi

  if docker exec "$CONTAINER" test -d "$EXT_DIR/$EXT_NAME"; then
    skip "$CONTAINER: $EXT_NAME"
  else
    info "Cloning $EXT_NAME into $CONTAINER:$EXT_DIR..."
    docker exec "$CONTAINER" git clone "$EXT_REPO" "$EXT_DIR/$EXT_NAME"
    info "$CONTAINER: extension cloned."
  fi

  if [[ "$WAS_RUNNING" == "true" ]]; then
    info "Restarting '$CONTAINER' to load extension..."
    docker restart "$CONTAINER" >/dev/null
  else
    info "Stopping '$CONTAINER' (it was not running before)."
    docker stop "$CONTAINER" >/dev/null
  fi
done

# ── Step 3: Print access URLs ────────────────────────────────────────────────
step "3 — Access URLs"

HOST_IP="$(hostname -I | awk '{print $1}')"
info "Done. Extension install applied to all existing Stable Diffusion containers."

for CONTAINER in "${SD_CONTAINERS[@]}"; do
  HOST_PORT="$(docker port "$CONTAINER" 7860/tcp 2>/dev/null | awk -F: 'NR==1{print $NF}')"
  if [[ -n "$HOST_PORT" ]]; then
    info "  $CONTAINER -> http://$HOST_IP:$HOST_PORT"
  else
    info "  $CONTAINER -> container port 7860 (no host port published)"
  fi
done