# n8n Component

Last updated: 2026-04-15

## What happens here

n8n is a workflow automation platform with a visual node editor. Used
in the stack for connecting AI services, triggering actions, and
building automated pipelines between LLMs and external tools.

## Files and structure

| File | Purpose |
|------|---------|
| `n8n.sh` | Full lifecycle: install, configure, start, stop, health |
| `n8n.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

See [usage.md](./usage.md) for command usage.
