# slowmist/openclaw-security-practice-guide

> **Source:** [repo-review-batch1.md](../repo-review/results/repo-review-batch1.md) — Repo 1
> **Reviewed:** 2026-03-30 | **Verdict:** ADOPT

**Stars:** 185 | **Forks:** 16 | **Trust:** HIGH-ADOPT

## Summary

A three-layer "Agentic Zero-Trust Architecture" defense guide injected directly into OpenClaw's cognition — not a human checklist. SlowMist calls it a "Mental Seal" (思想钢印), reshaping the agent's baseline judgment.

## Three-Layer Defense Matrix

1. **Pre-action:** Behavior blacklist (red/yellow lines) + skill installation audit
   - Red lines: exfiltration, reverse shells, auth tampering, code injection, blind dependency installation
   - Supply chain defense: full-text scan of skills before installation

2. **In-action:** Permission narrowing + hash baselines + audit logs + pre-flight checks
   - Cross-skill business risk controls before high-risk operations
   - Human confirmation required for irreversible actions

3. **Post-action:** Nightly automated audit (13 core metrics) + OpenClaw brain Git backup
   - Config baseline hash verification
   - Gateway process env-var scanning for leaked secrets
   - Regex scanning for private keys/mnemonics in workspace

## Companion Skill: slowmist-agent-security

Installable OpenClaw skill with structured review frameworks for: skill/MCP review, GitHub repo review, URL/document review, on-chain address review, product/service review, social share review. Includes pattern libraries: 11 red-flag code patterns, 8 social engineering patterns, 7 supply chain attack patterns.

## Stack Mapping

| SlowMist Concept | Stack Component | Action |
|-----------------|----------------|--------|
| Nightly audit script | Not implemented | Adopt as starting point |
| Git brain backup | Not implemented | Adopt immediately |
| Red-line blacklist | OpenShell network policy | Complementary |
| Skill installation audit | Not implemented | Adopt full-text scan |
| Hash baseline | Not implemented | Implement for openclaw.json, OpenShell policy, character cards |
| Pre-flight checks | OpenShell HITL approval | Complementary layers |

## Risks

- Guide itself acknowledges bypass via prompt injection of guide contents
- Relies on agent compliance for behavior conventions — not hard enforcement
- Does NOT replace NemoClaw/OpenShell — complementary layer

## Verdict

**ADOPT.** Install slowmist-agent-security skill. Adapt nightly audit script. Implement Git brain backup. Most mature, practical OpenClaw security framework found. Directly addresses 4 threat model items: prompt injection, skill supply chain, audit gaps, sensitive data retention.

Complementary with: [prompt-security/clawsec](prompt-security-clawsec.md)
