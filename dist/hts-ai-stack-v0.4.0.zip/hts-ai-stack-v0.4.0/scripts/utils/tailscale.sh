#!/usr/bin/env bash
# scripts/utils/tailscale.sh — Manage Tailscale VPN configuration and status
#
# Provides interactive menu to:
#   • Check Tailscale installation and status
#   • Enable/disable Tailscale service
#   • View Tailscale IP address and node info
#   • Manage firewall rules for Tailscale
#   • Show connected peers on tailnet
#
# Usage:
#   ./tailscale.sh                 # Opens interactive menu
#   ./tailscale.sh status          # Show status directly
#   ./tailscale.sh --help          # Show this help
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source common logging functions
# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/common.sh" || {
  # Fallback if common.sh not available
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  RED='\033[0;31m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
}

# ── Helper functions ──────────────────────────────────────────────────────

is_tailscale_installed() {
  command -v tailscale >/dev/null 2>&1 && echo "yes" || echo "no"
}

is_tailscale_active() {
  systemctl is-active tailscaled >/dev/null 2>&1 && echo "yes" || echo "no"
}

is_tailscale_enabled() {
  systemctl is-enabled tailscaled >/dev/null 2>&1 && echo "yes" || echo "no"
}

get_tailscale_ip() {
  if [[ $(is_tailscale_active) == "yes" ]]; then
    tailscale ip -4 2>/dev/null | head -1 || echo ""
  else
    echo ""
  fi
}

is_tailscale_connected() {
  if [[ $(is_tailscale_active) == "yes" ]]; then
    tailscale status 2>/dev/null | grep -q "^[0-9]" && echo "yes" || echo "no"
  else
    echo "no"
  fi
}

get_tailscale_hostname() {
  if [[ $(is_tailscale_active) == "yes" ]]; then
    tailscale status 2>/dev/null | grep "node_key" | grep -oP '(?<=\s)\w+$' | head -1 || echo ""
  else
    echo ""
  fi
}

# Display status with color coding
show_status() {
  local label="$1"
  local value="$2"
  local color="${GREEN}"
  [[ "$value" == "no" ]] && color="${RED}"
  printf "  %-40s ${color}%-16s${NC}\n" "$label" "$value"
}

# ── Main Menu ─────────────────────────────────────────────────────────────

show_main_menu() {
  local ts_installed=$(is_tailscale_installed)
  local ts_enabled=$(is_tailscale_enabled)
  local ts_active=$(is_tailscale_active)
  local ts_connected=$(is_tailscale_connected)
  local ts_ip=$(get_tailscale_ip)

  # Build status display for the menu
  local status_text="Tailscale Status:\n\n"
  status_text+="  Installed: $ts_installed\n"
  status_text+="  Enabled: $ts_enabled\n"
  status_text+="  Running: $ts_active\n"
  status_text+="  Connected: $ts_connected\n"
  
  if [[ -n "$ts_ip" ]]; then
    status_text+="  IP address: $ts_ip\n"
  fi
  
  status_text+="\nChoose an action:"

  # Build menu items based on installation status
  local -a menu_items=()

  if [[ "$ts_installed" == "no" ]]; then
    menu_items=("1" "Install Tailscale"
                "2" "Show help"
                "3" "Exit")
  else
    menu_items=("1" "View full status"
                "2" "Enable Tailscale (at startup)"
                "3" "Start Tailscale service"
                "4" "Disconnect from Tailscale"
                "5" "View firewall rules"
                "6" "Reset to defaults")
    
    if [[ "$ts_connected" == "no" && "$ts_active" == "yes" ]]; then
      menu_items+=("7" "Login to Tailscale")
    fi
  fi

  # Present menu with embedded status
  local choice
  choice=$(whiptail --title "Tailscale VPN Manager" \
    --menu "$status_text" 0 0 0 \
    "${menu_items[@]}" \
    3>&1 1>&2 2>&3) || return 0  # Exit if user clicks Cancel

  handle_menu_choice "$choice"
}

# ── Menu handlers ─────────────────────────────────────────────────────────

handle_menu_choice() {
  local choice="$1"

  case "$choice" in
    1)
      if [[ $(is_tailscale_installed) == "no" ]]; then
        install_tailscale
      else
        show_detailed_status
      fi
      ;;
    2)
      if [[ $(is_tailscale_installed) == "no" ]]; then
        show_help
      else
        enable_tailscale
      fi
      ;;
    3)
      if [[ $(is_tailscale_installed) == "yes" ]]; then
        start_tailscale
      fi
      ;;
    4)
      disconnect_tailscale
      ;;
    5)
      show_firewall_rules
      ;;
    6)
      confirm_reset_tailscale
      ;;
    7)
      login_tailscale
      ;;
    *)
      ;;
  esac
}

install_tailscale() {
  sudo_or_warn "install Tailscale" || return 0

  whiptail --yesno "Install Tailscale VPN client?\n\nThis will:\n• Add Tailscale package repository\n• Install tailscale and tailscaled\n• Enable at startup\n\nWARNING: Requires sudo." 0 0 || return 0

  whiptail --infobox "Installing Tailscale...\nPlease wait..." 8 50

  if bash "$REPO_DIR/scripts/install/networking/setup-tailscale.sh" 2>&1 | tee >(while IFS= read -r line; do
    whiptail --infobox "Installing Tailscale...\n\n$line" 10 60
  done); then
    whiptail --msgbox "✓ Tailscale installed and enabled\n\nYou can now login to your Tailnet." 10 50
  else
    whiptail --msgbox "✗ Tailscale installation failed\n\nCheck the logs for details." 8 50
  fi
  show_main_menu
}

show_detailed_status() {
  local ts_version=$(tailscale version 2>/dev/null | head -1 || echo "unknown")
  local ts_ip=$(get_tailscale_ip)
  local ts_hostname=$(get_tailscale_hostname)
  local ts_enabled=$(is_tailscale_enabled)
  local ts_active=$(is_tailscale_active)
  local ts_connected=$(is_tailscale_connected)

  local msg="DETAILED TAILSCALE STATUS\n\n"
  msg+="━━━━━━━━━━ SERVICE STATE ━━━━━━━━━━\n"
  msg+="  Version: $ts_version\n"
  msg+="  Enabled: $ts_enabled\n"
  msg+="  Running: $ts_active\n"
  msg+="  Connected: $ts_connected\n"
  
  if [[ -n "$ts_ip" ]]; then
    msg+="  Tailscale IP: $ts_ip\n"
  fi
  
  if [[ -n "$ts_hostname" ]]; then
    msg+="  Hostname: $ts_hostname\n"
  fi
  
  msg+="\n━━━━━━━━ FULL STATUS OUTPUT ━━━━━━━━\n"
  
  # Get actual status output
  if [[ $(is_tailscale_active) == "yes" ]]; then
    local status_output
    status_output=$(tailscale status 2>/dev/null | head -15 || echo "Unable to fetch status")
    msg+="$status_output\n"
  else
    msg+="(Tailscale service not running)\n"
  fi

  whiptail --msgbox "$msg" 0 0
  show_main_menu
}

enable_tailscale() {
  sudo_or_warn "enable Tailscale" || return 0

  whiptail --yesno "Enable Tailscale to start at boot?\n\nThis will:\n• Enable tailscaled systemd service\n• Start it now\n\nWARNING: Requires sudo." 0 0 || return 0

  sudo systemctl enable tailscaled || {
    whiptail --msgbox "✗ Failed to enable Tailscale" 8 40
    show_main_menu
    return
  }

  sudo systemctl start tailscaled || {
    whiptail --msgbox "✗ Failed to start Tailscale" 8 40
    show_main_menu
    return
  }

  whiptail --msgbox "✓ Tailscale enabled and started\n\nYou're now ready to login to your Tailnet." 8 50
  show_main_menu
}

start_tailscale() {
  sudo_or_warn "start Tailscale" || return 0

  whiptail --yesno "Start Tailscale service now?\n\nWARNING: Requires sudo." 0 0 || return 0

  if sudo systemctl start tailscaled; then
    whiptail --msgbox "✓ Tailscale service started" 8 40
  else
    whiptail --msgbox "✗ Failed to start Tailscale" 8 40
  fi
  show_main_menu
}

login_tailscale() {
  sudo_or_warn "login to Tailscale" || return 0

  whiptail --msgbox "Opening Tailscale login...\n\nA browser window will open. Follow the prompts to authenticate and join your Tailnet." 8 60

  if sudo tailscale login; then
    local ts_ip
    ts_ip=$(get_tailscale_ip)
    whiptail --msgbox "✓ Successfully connected to Tailnet!\n\nYour Tailscale IP: $ts_ip" 8 50
  else
    whiptail --msgbox "✗ Login failed or cancelled" 8 40
  fi
  show_main_menu
}

disconnect_tailscale() {
  sudo_or_warn "disconnect from Tailscale" || return 0

  whiptail --yesno "Disconnect from Tailscale?\n\nThis will:\n• Revoke your device from the Tailnet\n• Close the VPN connection\n\nWARNING: You'll need to re-login to reconnect.\nWARNING: Requires sudo." 0 0 || return 0

  if sudo tailscale logout; then
    whiptail --msgbox "✓ Disconnected from Tailscale" 8 40
  else
    whiptail --msgbox "✗ Failed to disconnect" 8 40
  fi
  show_main_menu
}

show_firewall_rules() {
  if ! command -v ufw >/dev/null 2>&1; then
    whiptail --msgbox "UFW firewall not found.\n\nInstall with: sudo apt install ufw" 8 40
    show_main_menu
    return
  fi

  local msg="UFW FIREWALL STATUS\n\n"
  msg+="$(sudo ufw status | head -20)\n\n"
  msg+="To restrict access to Tailscale only:\n"
  msg+="  sudo ufw allow from 100.64.0.0/10\n"
  msg+="  sudo ufw default deny"

  whiptail --msgbox "$msg" 0 0
  show_main_menu
}

confirm_reset_tailscale() {
  sudo_or_warn "reset Tailscale" || return 0

  whiptail --yesno "Reset Tailscale to defaults?\n\nThis will:\n• Disable Tailscale at startup\n• Stop the service\n• Disconnect from Tailnet\n\nWARNING: Requires sudo. To reconnect, you'll need to re-login." 0 0 || return 0

  sudo systemctl disable tailscaled 2>/dev/null || true
  sudo systemctl stop tailscaled 2>/dev/null || true

  whiptail --msgbox "✓ Tailscale reset to defaults\n\n• Disabled at startup\n• Service stopped\n• Disconnected" 10 50
  show_main_menu
}

# ── Utility: Check for sudo or warn ───────────────────────────────────────
sudo_or_warn() {
  local action="${1:-perform action}"
  if ! sudo -l >/dev/null 2>&1; then
    whiptail --msgbox "ERROR: sudo access required to $action\n\nPlease configure sudoers or run with: sudo $0" 8 50
    return 1
  fi
  return 0
}

# ── Help ──────────────────────────────────────────────────────────────────

show_help() {
  cat <<EOF
${CYAN}Tailscale VPN Manager${NC}

Manage Tailscale connectivity and configuration interactively.

${BOLD}Usage:${NC}
  $0                 Opens interactive menu
  $0 status          Show current status
  $0 --help          Show this help

${BOLD}Features:${NC}
  • Install Tailscale
  • Enable/disable at startup
  • View Tailscale IP and status
  • Login/logout from Tailnet
  • View firewall integration
  • Reset to defaults

${BOLD}Requirements:${NC}
  • whiptail (usually pre-installed)
  • sudo (for service and package management)
  • systemctl (for systemd integration)

${BOLD}Tailscale Basics:${NC}
  • Free VPN service for personal use
  • Create your own Tailnet (private network)
  • Access machines securely from anywhere
  • Works across firewalls and networks
  • https://tailscale.com/

${BOLD}Getting Started:${NC}
  1. Run: ./tailscale.sh
  2. Select "Install Tailscale"
  3. Select "Login to Tailscale"
  4. Follow browser prompts
  5. Device joins your Tailnet

EOF
}

# ── Command-line argument handling ─────────────────────────────────────────

handle_args() {
  case "${1:-}" in
    --help|-h)
      show_help
      exit 0
      ;;
    status)
      show_detailed_status
      exit 0
      ;;
    *)
      ;;
  esac
}

# ── Entry point ───────────────────────────────────────────────────────────

main() {
  handle_args "$@"

  # Check dependencies
  if ! command -v whiptail >/dev/null 2>&1; then
    echo -e "${RED}whiptail not found. Install: sudo apt install whiptail${NC}"
    exit 1
  fi

  if [[ "$USER" == "root" ]]; then
    echo -e "${YELLOW}WARNING: Running as root. Some operations may not work as expected.${NC}"
  fi

  show_main_menu
}

main "$@"
