#!/usr/bin/env bash
# install-lmstudio.sh — Install LM Studio and pull default models
#
# Idempotent: skips deb install if lmstudio package is already installed.
# Model pulls via `lms get` are idempotent by design.
#
# NOTE: LM Studio requires a desktop session.  The `lms` CLI cannot
#       bootstrap until the GUI has been launched at least once (creates
#       ~/.lmstudio).  This script will install the deb, attempt bootstrap,
#       and skip model pulls if the CLI isn't ready yet.

set -euo pipefail

LMS_VERSION="0.4.9-1"
LMS_DEB="LM-Studio-${LMS_VERSION}-x64.deb"
LMS_URL="https://installers.lmstudio.ai/linux/x64/${LMS_VERSION}/${LMS_DEB}"
LMS_BUNDLED_CLI="/opt/LM-Studio/resources/app/.webpack/lms"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already installed"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

# ── Step 1: Install LM Studio ─────────────────────────────────────────────────
step "1 — Install LM Studio ${LMS_VERSION}"

if dpkg -s lmstudio &>/dev/null 2>&1; then
  skip "LM Studio ($(dpkg-query -W -f='${Version}' lmstudio 2>/dev/null))"
else
  info "Downloading LM Studio ${LMS_VERSION}..."
  wget -q --show-progress -O "/tmp/${LMS_DEB}" "$LMS_URL"

  info "Installing..."
  sudo dpkg -i "/tmp/${LMS_DEB}"
  sudo apt-get install -f -y -qq   # fix any missing dependencies
  rm "/tmp/${LMS_DEB}"

  info "LM Studio ${LMS_VERSION} installed."
fi

# ── Step 2: Bootstrap LM Studio CLI ──────────────────────────────────────────
step "2 — Bootstrap lms CLI"

if command -v lms &>/dev/null; then
  skip "lms CLI already on PATH"
elif [[ -d "$HOME/.lmstudio" ]] && [[ -x "$LMS_BUNDLED_CLI" ]]; then
  info "Running lms bootstrap..."
  "$LMS_BUNDLED_CLI" bootstrap
  info "lms CLI bootstrapped."
else
  # LM Studio needs one GUI launch to create ~/.lmstudio before CLI works.
  # Launch it in the background so the install script keeps running.
  if [[ -x /usr/bin/lm-studio ]] && [[ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]]; then
    info "Launching LM Studio once to initialise ~/.lmstudio ..."
    /usr/bin/lm-studio &>/dev/null &
    disown
    info "LM Studio opened on your desktop — it will stay open while the script continues."
  else
    warn "LM Studio must be launched once before the CLI can bootstrap."
    warn "Open LM Studio from your desktop, let it finish initial setup,"
    warn "then re-run this script (or run: $LMS_BUNDLED_CLI bootstrap)"
  fi
fi

# ── Step 3: Pull models ───────────────────────────────────────────────────────
step "3 — Pull models (lms get — idempotent)"

if ! command -v lms &>/dev/null; then
  warn "lms CLI not yet on PATH — skipping model pulls."
  warn "After launching LM Studio and bootstrapping, run:"
  warn "  bash $0"
  info "LM Studio .deb is installed — launch it from the desktop to continue."
  exit 0
fi

info "lms CLI is ready. Pull models manually with:"
info "  lms get <huggingface-url> -y"
info ""
info "No default model pulls configured — add URLs to this script or use lms get directly."
