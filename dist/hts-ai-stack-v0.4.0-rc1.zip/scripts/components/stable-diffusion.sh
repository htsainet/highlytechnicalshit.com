#!/usr/bin/env bash
# scripts/components/stable-diffusion.sh — Stable Diffusion: image gen setup, checkpoints, NAS cache
#
# Standalone usage:
#   ./scripts/components/stable-diffusion.sh              # install + start + health
#   ./scripts/components/stable-diffusion.sh --download    # download checkpoints only
#   ./scripts/components/stable-diffusion.sh --health      # health check only
#   ./scripts/components/stable-diffusion.sh --stop        # stop SD
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
SD_PORT="${SD_PORT:-7860}"
SD_CONTAINER="${SD_CONTAINER:-hts-ai-stable-diffusion}"
SD_USE_EXTERNAL="${SD_USE_EXTERNAL:-false}"
NAS_SD_CACHE="${NAS_SD_CACHE:-/mnt/nas/llm-cache/sd-checkpoints}"
IMAGES_ENABLED="${IMAGES_ENABLED:-false}"

# ── Functions ─────────────────────────────────────────────────────────────────

# sd_install — Pull the SD Docker image via compose
sd_install() {
  step "Stable Diffusion — pull image"
  compose_pull --profile sd
  ok "Stable Diffusion image pulled."
}

# sd_configure — Ensure .env has SD-related vars
sd_configure() {
  step "Stable Diffusion — configure"
  local env_file="$REPO_DIR/.env"

  _ensure_key() {
    local key="$1" default="$2"
    if ! grep -q "^${key}=" "$env_file" 2>/dev/null; then
      printf '%s=%s\n' "$key" "$default" >> "$env_file"
      info "Added ${key}=${default} to .env"
    fi
  }

  _ensure_key "SD_PORT" "$SD_PORT"
  _ensure_key "IMAGES_ENABLED" "$IMAGES_ENABLED"
  ok "Stable Diffusion .env keys verified."
}

# sd_start — Bring up SD via compose
sd_start() {
  step "Stable Diffusion — start"
  if [[ "$SD_USE_EXTERNAL" == "true" ]]; then
    info "Using external Stable Diffusion — skipping local start."
    return 0
  fi
  compose_up --profile sd
  ok "Stable Diffusion container started."
}

# sd_stop — Bring down SD
sd_stop() {
  step "Stable Diffusion — stop"
  compose_down --profile sd
  ok "Stable Diffusion stopped."
}

# sd_health — Probe the SD web UI
sd_health() {
  health_probe "Stable Diffusion :${SD_PORT}" "http://localhost:${SD_PORT}"
}

# sd_download_models — Download checkpoints from registry or NAS cache
sd_download_models() {
  step "Stable Diffusion — download checkpoints"

  if [[ "$IMAGES_ENABLED" != "true" ]]; then
    info "Image generation disabled (IMAGES_ENABLED!=true) — skipping checkpoint download."
    return 0
  fi

  local registry="$REPO_DIR/scripts/install/models/registry.json"
  if [[ ! -f "$registry" ]]; then
    warn "Registry file not found: $registry — skipping SD download."
    return 0
  fi

  # Find the SD volume
  local sd_volume
  sd_volume=$(docker volume ls --format '{{.Name}}' | grep "sd_models" | head -1 || true)
  if [[ -z "$sd_volume" ]]; then
    info "SD volume not found — starting SD container briefly to create it..."
    compose_up --profile sd
    sleep 5
    sd_volume=$(docker volume ls --format '{{.Name}}' | grep "sd_models" | head -1 || true)
    if [[ -z "$sd_volume" ]]; then
      warn "Could not find or create SD volume. Run docker compose up first."
      return 1
    fi
  fi

  info "Using volume: $sd_volume"

  # Read SD models from registry (if present)
  local models
  models=$(jq -r '.sd[]? | "\(.filename)|\(.url)"' "$registry" 2>/dev/null) || true

  if [[ -z "$models" ]]; then
    info "No SD entries in registry.json — using hardcoded prod checkpoints."
    models="dreamshaper_v8.safetensors|https://huggingface.co/Lykon/DreamShaper/resolve/main/DreamShaper_8_pruned.safetensors
majicmixRealistic_v7.safetensors|https://huggingface.co/digiplay/majicMIX_realistic_v7/resolve/main/majicmixRealistic_v7.safetensors"
  fi

  while IFS= read -r entry; do
    [[ -z "$entry" ]] && continue
    local filename="${entry%%|*}"
    local url="${entry##*|}"
    _sd_download_if_missing "$sd_volume" "$filename" "$url"
  done <<< "$models"

  ok "Checkpoint download complete."
}

# ── Internal helpers ──────────────────────────────────────────────────────────

# _sd_download_if_missing <volume> <filename> <url>
# Resolution order: 1) already in volume → skip  2) NAS cache → copy  3) internet → download
_sd_download_if_missing() {
  local volume="$1"
  local filename="$2"
  local url="$3"

  if [[ "$url" == "REPLACE_WITH_URL" ]]; then
    warn "Skipping $filename — URL not set."
    return
  fi

  # 1. Already in the volume?
  local already_exists
  already_exists=$(docker run --rm \
    -v "${volume}:/models" \
    alpine sh -c "[ -f /models/Stable-diffusion/${filename} ] && echo yes || echo no")

  if [[ "$already_exists" == "yes" ]]; then
    info "Already present: $filename"
    return
  fi

  # 2. Available on NAS?
  local nas_file="${NAS_SD_CACHE}/${filename}"
  if [[ -f "$nas_file" ]]; then
    local nas_size
    nas_size=$(stat -c%s "$nas_file" 2>/dev/null || echo 0)
    if [[ "$nas_size" -gt 1000000 ]]; then
      info "$filename — copying from NAS cache..."
      docker run --rm \
        -v "${volume}:/models" \
        -v "${NAS_SD_CACHE}:/nas-cache:ro" \
        alpine sh -c "
          mkdir -p /models/Stable-diffusion
          cp /nas-cache/${filename} /models/Stable-diffusion/${filename}
        " && ok "$filename copied from NAS." \
          || { warn "$filename — NAS copy failed"; return 1; }
      return
    fi
  fi

  # 3. Download from internet
  info "$filename — downloading from internet..."
  local tmp_dir
  tmp_dir=$(mktemp -d)
  local tmp_file="${tmp_dir}/${filename}"

  if curl -fSL --retry 3 --retry-delay 5 --progress-bar \
      -o "$tmp_file" "$url"; then
    info "$filename — copying into volume..."
    docker run --rm \
      -v "${volume}:/models" \
      -v "${tmp_dir}:/downloads:ro" \
      alpine sh -c "
        mkdir -p /models/Stable-diffusion
        cp /downloads/${filename} /models/Stable-diffusion/${filename}
      " && ok "$filename downloaded and stored." \
        || warn "$filename — copy into volume failed."
  else
    warn "$filename — download failed from $url"
  fi

  rm -rf "$tmp_dir"
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --download) ACTION="download"; shift ;;
      --health)   ACTION="health"; shift ;;
      --stop)     ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      sd_install
      sd_configure
      sd_start
      sd_health
      ;;
    download)
      sd_download_models
      ;;
    health)
      sd_health
      ;;
    stop)
      sd_stop
      ;;
  esac
fi
