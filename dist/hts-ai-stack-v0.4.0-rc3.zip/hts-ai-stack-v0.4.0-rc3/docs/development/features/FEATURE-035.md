# FEATURE-035 — AnythingLLM

## Metadata

| Field | Value |
|-------|-------|
| **Feature ID** | FEATURE-035 |
| **Title** | AnythingLLM — Document Chat + RAG Workspace Platform |
| **Priority** | MEDIUM |
| **Effort** | 1–2 hours |
| **Risk** | Low (MIT, active, single-container Docker) |
| **Status** | Proposed |
| **Target** | v0.6.0 |
| **Depends on** | Ollama (FEATURE-001), llama-swap routing (FEATURE-003) |
| **Blocks** | nothing |
| **Repo** | [mintplex-labs/anything-llm](https://github.com/Mintplex-Labs/anything-llm) |
| **License** | ✅ MIT |
| **Stars** | 58,153 |
| **Language** | JavaScript (Node.js + React) |
| **Docker image** | `mintplexlabs/anythingllm` |
| **Default port** | 3001 (CONFLICT — OpenSpace) |
| **Stack port** | 3004 |

---

## Problem / Rationale

Open WebUI and LibreChat are general-purpose chat frontends. AnythingLLM fills
a distinct gap: **document-first RAG chat with workspace-level isolation**.

Key differentiators not covered by other frontends in the stack:

- **Workspace model** — each workspace has its own documents, vector store,
  LLM config, and system prompt. Isolated contexts per project/topic.
- **Document pipeline** — drag-and-drop PDF/DOCX/TXT ingestion with automatic
  chunking, embedding, and vector storage. No manual RAG wiring required.
- **No-code agent builder** with intelligent tool selection (up to 80% token
  reduction)
- **Embeddable chat widget** — drop a `<script>` tag on any website to expose
  a workspace as a chat widget (Docker version)
- **Browser extension** — clip web content directly into workspaces
- Multi-user with workspace-level permissions (Docker version)
- ⚠️ **Telemetry enabled by default** — must set `DISABLE_TELEMETRY=true`

---

## Stack Position

```text
Chat / RAG Frontends
  ├─ Open WebUI    (:3000)  General Ollama-native chat           FEATURE-001
  ├─ LibreChat     (:3080)  Power-user: code interpreter, agents FEATURE-033
  └─ AnythingLLM  (:3004)  Document/RAG workspaces, embed widget FEATURE-035
                                │
                                └─ Ollama endpoint → hts-ai-ollama:11434
                                   llama-swap      → hts-ai-llama-swap:8081/v1
```

AnythingLLM uses SQLite by default (no external DB required) and bundles its
own vector store (LanceDB by default). Zero mandatory external dependencies.

---

## Capability Overview

| Capability | Detail |
|---|---|
| **RAG / Document chat** | PDF, DOCX, TXT, CSV, MDX + more; drag-and-drop ingestion |
| **Vector databases** | LanceDB (built-in), Chroma, PGVector, Pinecone, Weaviate, Qdrant |
| **Workspaces** | Isolated doc sets, LLM configs, system prompts per workspace |
| **No-code agents** | Agent builder with MCP compatibility |
| **Intelligent tool selection** | Reduces token usage ≤80% per query |
| **Embeddable widget** | `<script>` tag chat widget per workspace (Docker only) |
| **Browser extension** | Clip web content into workspaces |
| **Multi-user + permissions** | Docker version; user roles per workspace |
| **Developer API** | Full REST API for custom integrations |
| **TTS/STT** | Browser built-in + PiperTTS (local, runs in browser) |
| **Multimodal** | Images via vision-capable LLMs |
| **Telemetry** | ⚠️ Opt-out: `DISABLE_TELEMETRY=true` |
| **SQLite** | Default storage — no MongoDB/Redis/Postgres required |

---

## Architecture

```text
Browser → AnythingLLM UI (:3004)
                │
                └─ Node.js server + collector
                        ├─ LanceDB (built-in vector store)
                        ├─ SQLite (metadata, users, workspaces)
                        ├─ Ollama → hts-ai-ollama:11434
                        └─ llama-swap → hts-ai-llama-swap:8081/v1
```

---

## Port Assignment

| Port | Purpose |
|------|---------|
| 3004 | AnythingLLM web UI + API |

Port 3004 is clear in the Host Port Map (checked 2026-04-12).

---

## Docker Service Sketch

```yaml
hts-ai-anythingllm:
  image: mintplexlabs/anythingllm:latest
  container_name: hts-ai-anythingllm
  profiles: [anythingllm]
  ports:
    - "${ANYTHINGLLM_PORT:-3004}:3001"
  environment:
    STORAGE_DIR: /app/server/storage
    DISABLE_TELEMETRY: "true"
    LLM_PROVIDER: ollama
    OLLAMA_BASE_PATH: "http://hts-ai-ollama:11434"
    OLLAMA_MODEL_PREF: "llama3.2"
    OLLAMA_MODEL_TOKEN_LIMIT: "4096"
    EMBEDDING_ENGINE: ollama
    EMBEDDING_BASE_PATH: "http://hts-ai-ollama:11434"
    EMBEDDING_MODEL_PREF: "nomic-embed-text:latest"
    VECTOR_DB: lancedb
    JWT_SECRET: "${ANYTHINGLLM_JWT_SECRET}"
  volumes:
    - anythingllm-storage:/app/server/storage
  restart: unless-stopped
```

---

## Implementation Steps

1. Create `docs/development/features/FEATURE-035.md` (this file)
2. Add port 3004 to `REFERENCES.md` Host Port Map
3. Add `FEATURE-035` row to `docs/development/features/REFERENCES.md` v0.6.0 table
4. Add `mintplex-labs/anything-llm` row to `docs/planning/feature-repos/REFERENCES.md`
5. Write `scripts/components/anythingllm/anythingllm.sh` — `anythingllm_install`,
   `anythingllm_configure`, `anythingllm_start`, `anythingllm_stop`,
   `anythingllm_health`
6. Add `docker-compose.yml` service `hts-ai-anythingllm` under profile `anythingllm`
7. Add `.env.example` vars: `ANYTHINGLLM_PORT`, `ANYTHINGLLM_JWT_SECRET`
8. Pull embedding model in Ollama: `nomic-embed-text:latest`
9. Validate: `curl http://localhost:3004` returns 200; workspace creation works
10. Verify `DISABLE_TELEMETRY=true` is confirmed off in the Privacy settings UI

---

## Acceptance Criteria

- [ ] AnythingLLM UI loads on port 3004
- [ ] Workspace creation works with Ollama as the LLM provider
- [ ] Document upload (PDF) ingests, chunks, and embeds successfully
- [ ] Chat with an uploaded document returns sourced responses
- [ ] Telemetry confirmed disabled in Privacy settings
- [ ] `docker compose --profile anythingllm up` / `down` cycle is clean

---

## License Note

MIT License — no copyleft concerns. Free for private self-hosted use with no
source-disclosure obligations.

---

## Notes

- **Telemetry is opt-out by default.** Always set `DISABLE_TELEMETRY=true` in
  the environment. Verify in-app under Sidebar → Privacy.
- **Embedding model:** Ollama's `nomic-embed-text` is the recommended local
  embedder. Pull it before first use: `docker exec hts-ai-ollama ollama pull nomic-embed-text`.
- **Vector DB:** LanceDB is built-in and requires no extra container. Chroma
  can be substituted if you want a standalone vector DB shared across services.
- **JWT secret:** Generate a strong random secret for `ANYTHINGLLM_JWT_SECRET`
  and store it in `.env` — do not hardcode.
- **vs LibreChat RAG:** LibreChat's RAG requires the separate `rag_api`
  companion. AnythingLLM's RAG is fully built-in with zero extra services.
- **Embeddable widget use case:** If you want a chat widget on an internal
  knowledge base site or wiki, AnythingLLM is the only frontend in the stack
  that provides this natively.
