# Sandbox — Lifecycle Management

Last updated: 2026-04-11 23:11:00

## What happens here

Shell functions for creating, destroying, upgrading, and executing commands
inside OpenShell sandboxes — the direct replacements for `nemoclaw onboard`,
`nemoclaw connect`, `nemoclaw destroy`, and `nemoclaw update`.

## Files and structure

| File | Purpose |
|------|---------|
| `lifecycle.sh` | Core functions: `htsclaw_create`, `htsclaw_destroy`, `htsclaw_upgrade` |
| `provider.sh` | Configure llama-swap as LLM backend via `openclaw config set` |
| `firewall.sh` | UFW rules restricting sandbox port to Tailscale + localhost |

## Key commands mapped

| htsclaw function | openshell command underneath |
|---|---|
| `htsclaw_create` | `openshell gateway start -g htsclaw` + `openshell sandbox create` |
| `htsclaw_destroy` | `openshell forward stop` + `openshell sandbox delete` |
| `htsclaw_upgrade` | `openshell sandbox exec -- npm install --prefix /sandbox openclaw@latest` + restart |
| `htsclaw_exec` | `openshell sandbox exec -n <sandbox> -- <cmd>` |
| `htsclaw_forward` | `openshell forward --background <port>` |
| `htsclaw_patch` | `openshell sandbox exec -- npm audit fix` |

## Process

1. `htsclaw_create` starts gateway, creates sandbox, configures LLM provider
2. `htsclaw_forward` opens port forwarding for dashboard access
3. `htsclaw_upgrade` / `htsclaw_patch` for maintenance (preserves config)
4. `htsclaw_destroy` tears down sandbox and cleans up port forwarding

## Configuration

- Gateway name: `htsclaw` (container: `openshell-cluster-htsclaw`)
- Default sandbox name: `hts-ai-openshell-htsclaw-gpu` (configurable via menu)
- Default port: `18792` (avoids conflict with NemoClaw's 18789)
- LLM endpoint: `http://host.openshell.internal:8081/v1` (llama-swap)

## Tools and dependencies

- **openshell CLI** — sandbox lifecycle (create, destroy, exec, forward)
- **openclaw** — configuration management inside sandbox
- **ufw** — firewall rule management for sandbox ports

## What good looks like

- Create and destroy are idempotent — safe to re-run
- Upgrade preserves sandbox config (personas, provider settings)
- `htsclaw_patch` runs `npm audit fix` without destroying the sandbox
- UFW rules match NemoClaw's pattern: sandbox port restricted to Tailscale + localhost
- All functions sourceable by bundle scripts for individual access
