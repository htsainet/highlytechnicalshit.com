#!/usr/bin/env bash
# scripts/components/lmstudio/lmstudio.sh — LM Studio: install, configure, health
#
# Host-interactive model staging sandbox.  LM Studio is installed via .deb
# package on the host (not containerised).  Requires a desktop session for
# initial setup — the lms CLI can only bootstrap after the GUI has run once.
#
# Standalone usage:
#   ./scripts/components/lmstudio/lmstudio.sh              # full: install + configure + health
#   ./scripts/components/lmstudio/lmstudio.sh --install    # install only (.deb + CLI bootstrap)
#   ./scripts/components/lmstudio/lmstudio.sh --configure  # configure only (pull default model)
#   ./scripts/components/lmstudio/lmstudio.sh --start      # start LM Studio server
#   ./scripts/components/lmstudio/lmstudio.sh --stop       # stop LM Studio server
#   ./scripts/components/lmstudio/lmstudio.sh --restart    # restart (stop + start)
#   ./scripts/components/lmstudio/lmstudio.sh --health     # health check only
#   ./scripts/components/lmstudio/lmstudio.sh --status     # show status + health
#   ./scripts/components/lmstudio/lmstudio.sh --destroy    # uninstall LM Studio
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env
LMSTUDIO_PORT="${LMSTUDIO_PORT:-1234}"
LMS_VERSION="${LMS_VERSION:-0.4.9-1}"
LMS_DEB="LM-Studio-${LMS_VERSION}-x64.deb"
LMS_URL="https://installers.lmstudio.ai/linux/x64/${LMS_VERSION}/${LMS_DEB}"
LMS_BUNDLED_CLI="/opt/LM-Studio/resources/app/.webpack/lms"
LMS_DEFAULT_MODEL="${LMS_DEFAULT_MODEL:-lmstudio-community/gemma-3-4b-it-GGUF/gemma-3-4b-it-Q4_K_M.gguf}"

# ── Functions ────────────────────────────────────────────────────────────────

lmstudio_install() {
  step "LM Studio — install (v${LMS_VERSION})"

  if dpkg -s lmstudio &>/dev/null 2>&1; then
    skip "LM Studio already installed ($(dpkg-query -W -f='${Version}' lmstudio 2>/dev/null))"
  else
    info "Downloading LM Studio ${LMS_VERSION}..."
    wget -q --show-progress -O "/tmp/${LMS_DEB}" "$LMS_URL"
    info "Installing..."
    sudo dpkg -i "/tmp/${LMS_DEB}"
    sudo apt-get install -f -y -qq
    rm -f "/tmp/${LMS_DEB}"
    ok "LM Studio ${LMS_VERSION} installed."
  fi

  # Bootstrap CLI
  if command -v lms &>/dev/null; then
    skip "lms CLI already on PATH"
  elif [[ -d "$HOME/.lmstudio" ]] && [[ -x "$LMS_BUNDLED_CLI" ]]; then
    info "Running lms bootstrap..."
    "$LMS_BUNDLED_CLI" bootstrap
    ok "lms CLI bootstrapped."
  else
    if [[ -x /usr/bin/lm-studio ]] && [[ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]]; then
      info "Launching LM Studio once to initialise ~/.lmstudio ..."
      /usr/bin/lm-studio &>/dev/null &
      disown
      info "LM Studio opened — let it finish setup, then re-run."
    else
      warn "LM Studio must be launched once before the CLI can bootstrap."
      warn "Open LM Studio from your desktop, then re-run this script."
    fi
  fi
}

lmstudio_configure() {
  step "LM Studio — configure"
  if ! command -v lms &>/dev/null; then
    warn "lms CLI not available — skipping model pull."
    warn "Launch LM Studio GUI first, then re-run."
    return 0
  fi
  info "Pulling default model: ${LMS_DEFAULT_MODEL}..."
  if lms get "$LMS_DEFAULT_MODEL" -y; then
    ok "Default model ready."
  else
    warn "Model pull failed — retry with: lms get ${LMS_DEFAULT_MODEL} -y"
  fi
}

lmstudio_start() {
  step "LM Studio — start"
  if ! command -v lms &>/dev/null; then
    warn "lms CLI not available — cannot start server."
    return 1
  fi
  lms server start 2>/dev/null || true
  ok "LM Studio server started on port ${LMSTUDIO_PORT}."
}

lmstudio_stop() {
  step "LM Studio — stop"
  if command -v lms &>/dev/null; then
    lms server stop 2>/dev/null || true
  fi
  ok "LM Studio server stopped."
}

lmstudio_health() {
  local label="LM Studio :${LMSTUDIO_PORT}"
  printf "  %-35s" "$label"
  if curl -sf "http://localhost:${LMSTUDIO_PORT}/v1/models" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${LMSTUDIO_PORT}/v1/models)"
    return 1
  fi
}

lmstudio_restart() {
  lmstudio_stop
  lmstudio_start
}

lmstudio_destroy() {
  step "LM Studio — destroy"
  lmstudio_stop
  warn "LM Studio is a host package — run 'sudo apt remove lmstudio' for full removal."
  ok "LM Studio destroy complete."
}

lmstudio_status() {
  step "LM Studio — status"
  if command -v lms &>/dev/null; then
    ok "LM Studio is installed."
  elif dpkg -s lmstudio &>/dev/null 2>&1; then
    warn "LM Studio installed but CLI not bootstrapped."
  else
    warn "LM Studio is not installed."
  fi
  lmstudio_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   lmstudio_install   ;;
    configure) lmstudio_configure ;;
    start)     lmstudio_start     ;;
    stop)      lmstudio_stop      ;;
    restart)   lmstudio_restart   ;;
    health)    lmstudio_health    ;;
    status)    lmstudio_status    ;;
    destroy)   lmstudio_destroy   ;;
    default)
      lmstudio_install
      lmstudio_configure
      lmstudio_health
      ;;
  esac
fi
