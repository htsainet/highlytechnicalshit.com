# NVIDIA/NemoClaw#1686 — tls: terminate deprecated in blueprints

| Field | Value |
|-------|-------|
| **Repo** | [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) |
| **Issue** | [#1686](https://github.com/NVIDIA/NemoClaw/issues/1686) |
| **State** | OPEN |
| **Severity** | low |
| **Labels** | bug, status: triage |
| **Opened** | 2026-04-09 |
| **Subscribed** | No |

## Impact on us

Blueprint files shipped with NemoClaw contain deprecated `tls: terminate` directives, causing WARN-level log spam during sandbox operations. No functional impact — the TLS termination still works, but the warnings clutter output.

Affected files:

- Sandbox blueprint configs (inside NemoClaw, not our repo)

## Workaround

Ignore the warnings. They are cosmetic only.

## Action when resolved

1. Upgrade NemoClaw CLI to pick up updated blueprints
2. Verify warnings are gone during `nemoclaw onboard`

## Status log

- **2026-04-09** — Reported upstream. In triage.
- **2026-04-09** — Identified during our upstream issue scan. Low priority — cosmetic only.
