# Granular Model Selection Checklist

**Priority:** Medium  
**Effort:** 8-12 hours (core UI + per-engine implementation)  
**Risk:** Low — additive feature, backward compatible default fallback  
**Target Release:** Next Minor (v0.5.0)  
**Depends on:** Nothing — can be built independently  
**Blocks:** Nothing — feature independent  
**Related:** Backend abstraction refactor (reduces per-engine effort)

## Problem

Currently users have only two options during setup:

- "Download all production models" (50GB+, hours of download)
- "Download only the default model" (~5-10GB)

This forces users into "all-or-nothing" model selection, wasting bandwidth and disk space for models they won't use. Users need fine-grained control over which models are pre-installed during initial stack deployment.

## Proposed Solution

Add an interactive **model selection checklist** integrated into the wizard that:

1. Displays available models with metadata (VRAM, disk, description)
2. Pre-selects the configured default model
3. Allows granular selection or quick presets (Minimal / Balanced / Full)
4. Saves selection to `stack.json` for reproducibility
5. Honors selection during installation without requiring CLI intervention

**New Step 2b (after default model selection):**

```text
┌─────────────────────────────────────────────┐
│  Select Production Models to Download       │
│                                             │
│  ☑ smollm2:135m (135M, ~500MB VRAM)         │
│  ☑ mistral-nemo:latest (7B, ~5GB) [DEFAULT]│
│  ☐ deepseek-r1:14b (14B, ~9GB VRAM)         │
│  ☐ phi4:14b (14B, ~12GB VRAM)               │
│                                             │
│  [ Use Preset: Minimal | Balanced | Full ]  │
│           [ OK ]    [ Cancel ]              │
└─────────────────────────────────────────────┘
```

### Features

- **Checklist UI** — whiptail checklist with model names, sizes, VRAM, descriptions
- **Metadata display** — Per-model VRAM and disk size estimates
- **Default pre-selected** — Configured default model checked by default
- **Quick presets** — Minimal (default only), Balanced (common models), Full (all)
- **Per-engine support** — Works with Ollama, BitNet, and future engines (StableDiff, etc.)
- **Reproducible** — Selection saved to stack.json for sharing configurations

## Implementation Phases

### Phase 1: Shared UI Abstraction (3 hours, FIRST RELEASE)

Create reusable model selection framework:

- **`config/wizard/model-selection-ui.sh`** — Generic whiptail checklist builder
  - Accepts metadata file and engine name
  - Returns space-separated list of selected models
  - Handles presets and edge cases
  - Reusable for any inference engine

### Phase 2: Ollama Integration (3-5 hours, THIS RELEASE)

Integrate with existing Ollama pipeline:

1. **`instances/prod/models-meta.sh`** — Ollama model metadata

   ```bash
   declare -A OLLAMA_MODELS_META=(
     ["smollm2:135m"]="135M|500MB|Fast lightweight chat"
     ["mistral-nemo:12b"]="12B|8GB|Balanced general-purpose"
     ["deepseek-r1:14b"]="14B|10GB|Chain-of-thought reasoning"
     ["phi4:14b"]="14B|12GB|Structured reasoning output"
   )
   ```

2. **`config/wizard/ai_stack_setup.sh`** — Call model selection UI
   - Source model metadata
   - Call `build_model_checklist "ollama"` → get selections
   - Export `BACKEND_SELECTED_MODELS="model1 model2 ..."`
   - Save to stack.json under `backend.selected_models`

3. **`scripts/install/models/prod.sh`** — Honor selections
   - Check `BACKEND_SELECTED_MODELS` from env/stack.json
   - Loop over selected models only (fallback to all if unset)
   - Same download logic, just filtered list

### Phase 3: Multi-Engine Support (2-4 hours EACH, FUTURE RELEASES)

- **BitNet** — Add `instances/prod/models-bitnet-meta.sh` + adapt Phase 2 steps
- **StableDiff** — Add `instances/prod/models-stablediff-meta.sh` + safety filtering UI

### Files Modified

| File | Change | Phase |
|------|--------|-------|
| `config/wizard/model-selection-ui.sh` | Create reusable checklist builder | 1 |
| `instances/prod/models-meta.sh` | Add Ollama model metadata | 2 |
| `config/wizard/ai_stack_setup.sh` | Call model selection UI for Ollama | 2 |
| `config/wizard/ai_stack_setup.py` | Save `backend.selected_models` to stack.json | 2 |
| `scripts/install/models/prod.sh` | Honor `BACKEND_SELECTED_MODELS` (fallback to all) | 2 |
| `scripts/install/models/test.sh` | Same as prod (optional) | 2 |

## Backward Compatibility

- If `BACKEND_SELECTED_MODELS` is empty or unset → fall back to downloading all models (current behavior)
- Existing configs without `backend.selected_models` field → continue to work (no breaking changes)
- Configs from v0.2.x → automatically upgraded with defaults on next wizard run

## Benefits

| Benefit | Impact |
|---------|--------|
| **Disk conscious** | Users avoid 50GB+ downloads of unused models |
| **Faster initial setup** | Minimal config: 5–10 min vs. 45–60 min+ with full download |
| **Clearer choices** | VRAM/disk tradeoffs visible during config, not after surprised user |
| **Flexible later** | Users can still `ollama pull` additional models post-install |
| **Reproducible** | Model selection saved in stack.json (shareable configs) |
| **Extensible** | Same UI works for BitNet, StableDiff, future engines |

## Design Considerations

### Whiptail Checklist Limits

- Whiptail checklist works best with ~10-15 items; if model list grows, consider:
  - Sub-menus (chat models / code models / reasoning models)
  - Hybrid: menu for category, then checklist within each
- Current plan: monolithic checklist for v0.5.0, revisit if > 15 models

### Model Metadata Maintenance

- Metadata file must stay in sync with actual available Ollama/BitNet/StableDiff models
- *Automated approach (future):* Scrape Ollama registry at install time
- *Current approach:* Manual maintenance in metadata file (low burden; ~5 models today)

### Test vs. Prod Models

- Proposal: Same UI for test models, BUT default to minimal set (default only)
- Rationale: Test instances are optional and space-constrained; full suite rarely needed

## Testing

- [ ] Checklist renders and displays all models
- [ ] Default model pre-selected correctly
- [ ] Preset buttons (Minimal / Balanced / Full) work
- [ ] Edge case: Can deselect all (error handling)
- [ ] Selection exports to `BACKEND_SELECTED_MODELS` env var
- [ ] stack.json saves selection correctly
- [ ] prod.sh honors selection (uses only selected models)
- [ ] Backward compat: Old configs with no selection field still install all (no error)
- [ ] Multiple engine backends tested (Ollama, BitNet if available)

## Out of Scope (Future Features)

- [ ] Model search/filtering UI (consider if list grows > 20)
- [ ] Custom model URLs from Hugging Face
- [ ] Automatic model removal (dangerous; skip for now)
- [ ] Model auto-upgrade checks
- [ ] Per-container model assignment (belongs in next release planning)

## Release Notes Entry (Draft)

```markdown
## v0.5.0 (Next Minor)

### New Features

- **Granular Model Selection** — Choose exactly which models to pre-install during setup
  via interactive checklist. Select minimal (default only), balanced, or full library.
  Reduces initial download time from 1hr to 5–10 min for minimal installs.
  Configuration saved to stack.json for reproducible deployments.

### Benefits

- Faster first-run setup for resource-constrained environments
- Clearer model VRAM/disk tradeoffs during configuration
- Shareable stack.json configs with specific model selections
- Foundation for multi-engine model selection (BitNet, StableDiff coming soon)
```

## Dependencies & Sequencing

- **Must come after:** Dual-inference backend refactor (so structure is in place)
- **Can happen in parallel with:** Other Phase 1 features  
- **Enables:** BitNet/StableDiff multi-engine support (Phase 3)
