#!/usr/bin/env bash
# scripts/htsclaw/sandbox/provider.sh — Configure llama-swap as LLM backend
#
# Registers/updates the llama-swap provider in openshell so the sandbox's
# OpenClaw instance routes inference requests to the host's llama-swap.
#
# Can be sourced by lifecycle.sh or run standalone.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
LLAMA_SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"
LLAMA_SWAP_HOST_URL="http://host.openshell.internal:${LLAMA_SWAP_PORT}/v1"
OLLAMA_MODEL="${OLLAMA_MODEL:-gemma4:e4b}"
HTSCLAW_GATEWAY_NAME="htsclaw"

# ── Provider setup ───────────────────────────────────────────────────────────

# htsclaw_provider — Configure llama-swap as the inference backend.
# Creates or updates the llama-swap-local provider in openshell so
# sandboxes can route inference to the host's llama-swap instance.
htsclaw_provider() {
  step "htsclaw — inference provider (llama-swap)"

  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not found — skipping provider configuration."
    return 0
  fi

  info "Endpoint: ${LLAMA_SWAP_HOST_URL}"

  # Update compatible-endpoint if it exists (created by initial sandbox setup)
  if openshell provider list -g "$HTSCLAW_GATEWAY_NAME" 2>/dev/null | grep -q "compatible-endpoint"; then
    info "Updating compatible-endpoint → ${LLAMA_SWAP_HOST_URL}"
    openshell provider update -g "$HTSCLAW_GATEWAY_NAME" compatible-endpoint \
      --config "OPENAI_BASE_URL=${LLAMA_SWAP_HOST_URL}" 2>/dev/null || \
      warn "Failed to update compatible-endpoint provider."
  fi

  # Create or update the llama-swap-local provider
  if ! openshell provider list -g "$HTSCLAW_GATEWAY_NAME" 2>/dev/null | grep -q "llama-swap-local"; then
    info "Registering llama-swap-local provider..."
    openshell provider create -g "$HTSCLAW_GATEWAY_NAME" \
      --name llama-swap-local \
      --type openai \
      --credential OPENAI_API_KEY=not-needed \
      --config "OPENAI_BASE_URL=${LLAMA_SWAP_HOST_URL}" || {
      warn "Failed to register llama-swap-local provider."
      return 1
    }
  else
    openshell provider update -g "$HTSCLAW_GATEWAY_NAME" llama-swap-local \
      --config "OPENAI_BASE_URL=${LLAMA_SWAP_HOST_URL}" 2>/dev/null || \
      warn "Failed to update llama-swap-local provider."
  fi

  # Set inference route so sandboxes reach llama-swap via inference.local
  info "Setting inference route → llama-swap-local / ${OLLAMA_MODEL}..."
  openshell inference set -g "$HTSCLAW_GATEWAY_NAME" \
    --provider llama-swap-local \
    --model "$OLLAMA_MODEL" \
    --no-verify 2>/dev/null || {
    warn "Failed to set inference route."
  }

  ok "Inference provider configured (llama-swap routes by model name: ${OLLAMA_MODEL})."
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  htsclaw_provider
fi
