#!/usr/bin/env bash
#
# xrdp-gnome-toggle.sh - Switch between GNOME Remote Desktop and xrdp on Ubuntu 24.04
#
# Usage:
#   sudo ./xrdp-gnome-toggle.sh apply     # install xrdp, disable GNOME RD
#   sudo ./xrdp-gnome-toggle.sh rollback  # remove xrdp, restore GNOME RD
#   sudo ./xrdp-gnome-toggle.sh status    # show what's currently active
#
# Notes:
#  - xrdp starts a NEW GNOME session on connect. You should LOG OUT at the
#    physical console before connecting via RDP from Windows.
#  - This script forces an Xorg-based GNOME session for the RDP login because
#    Wayland through xrdp does not work reliably.
#  - Both servers use TCP 3389. Only one can run at a time.

set -euo pipefail

STATE_DIR="/var/lib/xrdp-gnome-toggle"
STATE_FILE="$STATE_DIR/state"
BACKUP_DIR="$STATE_DIR/backup"
LOG_TAG="xrdp-toggle"

REAL_USER="${SUDO_USER:-}"
if [[ -z "$REAL_USER" || "$REAL_USER" == "root" ]]; then
    REAL_USER="$(logname 2>/dev/null || echo "")"
fi

log()  { echo "[$LOG_TAG] $*"; }
die()  { echo "[$LOG_TAG][ERROR] $*" >&2; exit 1; }

require_root() {
    [[ $EUID -eq 0 ]] || die "Run with sudo."
}

ensure_state_dir() {
    mkdir -p "$STATE_DIR" "$BACKUP_DIR"
}

# --- helpers --------------------------------------------------------------

pkg_installed() {
    dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}

backup_file() {
    local src="$1"
    if [[ -e "$src" && ! -e "$BACKUP_DIR/$(basename "$src").orig" ]]; then
        cp -a "$src" "$BACKUP_DIR/$(basename "$src").orig"
        log "Backed up $src"
    fi
}

restore_file() {
    local src="$1"
    local backup="$BACKUP_DIR/$(basename "$src").orig"
    if [[ -e "$backup" ]]; then
        cp -a "$backup" "$src"
        log "Restored $src"
    fi
}

run_as_user() {
    [[ -n "$REAL_USER" ]] || return 0
    sudo -u "$REAL_USER" \
        XDG_RUNTIME_DIR="/run/user/$(id -u "$REAL_USER")" \
        DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$(id -u "$REAL_USER")/bus" \
        "$@"
}

gnome_rd_active() {
    [[ -n "$REAL_USER" ]] || return 1
    run_as_user systemctl --user is-active gnome-remote-desktop.service 2>/dev/null \
        | grep -q "^active$"
}

# --- apply ---------------------------------------------------------------

cmd_apply() {
    require_root
    ensure_state_dir

    if [[ -f "$STATE_FILE" ]] && grep -q "^applied=1" "$STATE_FILE"; then
        log "Already applied. Run 'rollback' first if you want to redo."
        exit 0
    fi

    # --- record current state for rollback -------------------------------
    : > "$STATE_FILE"
    {
        echo "applied=1"
        echo "applied_at=$(date -Iseconds)"
        echo "real_user=$REAL_USER"
        if pkg_installed xrdp; then
            echo "xrdp_was_installed=1"
        else
            echo "xrdp_was_installed=0"
        fi
        if gnome_rd_active; then
            echo "gnome_rd_was_active=1"
        else
            echo "gnome_rd_was_active=0"
        fi
    } > "$STATE_FILE"

    # --- disable GNOME Remote Desktop ------------------------------------
    if [[ -n "$REAL_USER" ]] && gnome_rd_active; then
        log "Stopping GNOME Remote Desktop user service..."
        run_as_user systemctl --user stop gnome-remote-desktop.service || true
        run_as_user systemctl --user disable gnome-remote-desktop.service || true
    else
        log "GNOME Remote Desktop not active, skipping stop."
    fi

    # --- install xrdp ----------------------------------------------------
    log "Installing xrdp..."
    DEBIAN_FRONTEND=noninteractive apt-get update -y
    DEBIAN_FRONTEND=noninteractive apt-get install -y xrdp dbus-x11

    # ssl-cert group lets xrdp read the TLS key
    if id xrdp &>/dev/null; then
        adduser xrdp ssl-cert >/dev/null 2>&1 || true
    fi

    # --- configure GNOME-on-Xorg session for RDP -------------------------
    backup_file /etc/xrdp/startwm.sh

    cat > /etc/xrdp/startwm.sh <<'EOF'
#!/bin/sh
# Managed by xrdp-gnome-toggle.sh - launches GNOME on Xorg for xrdp sessions.

if test -r /etc/profile; then
    . /etc/profile
fi

if test -r ~/.profile; then
    . ~/.profile
fi

export GNOME_SHELL_SESSION_MODE=ubuntu
export XDG_CURRENT_DESKTOP=ubuntu:GNOME
export XDG_SESSION_TYPE=x11
export XDG_DATA_DIRS=/usr/share/ubuntu:/usr/local/share:/usr/share:/var/lib/snapd/desktop
export GDMSESSION=ubuntu

exec dbus-run-session -- gnome-session --session=ubuntu
EOF
    chmod 755 /etc/xrdp/startwm.sh

    # --- polkit rules to avoid auth pop-ups inside xrdp session ----------
    backup_file /etc/polkit-1/localauthority/50-local.d/45-allow-colord.pkla 2>/dev/null || true
    mkdir -p /etc/polkit-1/localauthority/50-local.d
    cat > /etc/polkit-1/localauthority/50-local.d/45-allow-colord.pkla <<'EOF'
[Allow Colord all Users]
Identity=unix-user:*
Action=org.freedesktop.color-manager.create-device;org.freedesktop.color-manager.create-profile;org.freedesktop.color-manager.delete-device;org.freedesktop.color-manager.delete-profile;org.freedesktop.color-manager.modify-device;org.freedesktop.color-manager.modify-profile
ResultAny=no
ResultInactive=no
ResultActive=yes
EOF

    # --- enable + start xrdp ---------------------------------------------
    log "Enabling and starting xrdp..."
    systemctl enable xrdp
    systemctl restart xrdp

    log "Apply complete."
    log "From Windows mstsc, connect to: 192.168.77.152"
    log "IMPORTANT: log out at the Ubuntu console first, then connect."
}

# --- rollback ------------------------------------------------------------

cmd_rollback() {
    require_root
    ensure_state_dir

    if [[ ! -f "$STATE_FILE" ]] || ! grep -q "^applied=1" "$STATE_FILE"; then
        log "No applied state found; nothing to roll back."
        exit 0
    fi

    # shellcheck disable=SC1090
    source <(grep '=' "$STATE_FILE")

    log "Stopping xrdp..."
    systemctl disable --now xrdp 2>/dev/null || true
    systemctl disable --now xrdp-sesman 2>/dev/null || true

    if [[ "${xrdp_was_installed:-0}" == "0" ]]; then
        log "Removing xrdp packages installed by apply..."
        DEBIAN_FRONTEND=noninteractive apt-get purge -y xrdp || true
        DEBIAN_FRONTEND=noninteractive apt-get autoremove -y || true
    else
        log "xrdp was preinstalled; leaving it installed."
    fi

    # Restore startwm.sh if backed up
    restore_file /etc/xrdp/startwm.sh

    # Remove polkit rule we added
    rm -f /etc/polkit-1/localauthority/50-local.d/45-allow-colord.pkla
    log "Removed polkit rule for colord."

    # Re-enable GNOME Remote Desktop if it was active before
    REAL_USER="${real_user:-$REAL_USER}"
    if [[ "${gnome_rd_was_active:-0}" == "1" && -n "$REAL_USER" ]]; then
        log "Re-enabling GNOME Remote Desktop user service..."
        run_as_user systemctl --user enable gnome-remote-desktop.service || true
        run_as_user systemctl --user start gnome-remote-desktop.service || true
    fi

    rm -f "$STATE_FILE"
    log "Rollback complete. State file removed."
    log "Backups remain in $BACKUP_DIR (delete manually if you don't want them)."
}

# --- status --------------------------------------------------------------

cmd_status() {
    echo "== xrdp =="
    if pkg_installed xrdp; then
        echo "installed: yes"
        systemctl is-active xrdp 2>/dev/null | sed 's/^/active: /'
        systemctl is-enabled xrdp 2>/dev/null | sed 's/^/enabled: /'
    else
        echo "installed: no"
    fi
    echo
    echo "== GNOME Remote Desktop (user service) =="
    if [[ -n "$REAL_USER" ]]; then
        run_as_user systemctl --user is-active gnome-remote-desktop.service 2>/dev/null \
            | sed 's/^/active: /' || true
        run_as_user systemctl --user is-enabled gnome-remote-desktop.service 2>/dev/null \
            | sed 's/^/enabled: /' || true
    else
        echo "no real user detected; skip"
    fi
    echo
    echo "== state file =="
    if [[ -f "$STATE_FILE" ]]; then
        cat "$STATE_FILE"
    else
        echo "(none)"
    fi
}

# --- main ----------------------------------------------------------------

case "${1:-}" in
    apply)    cmd_apply ;;
    rollback) cmd_rollback ;;
    status)   cmd_status ;;
    *)
        echo "Usage: sudo $0 {apply|rollback|status}" >&2
        exit 2
        ;;
esac
