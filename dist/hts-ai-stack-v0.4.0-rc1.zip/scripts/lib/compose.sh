#!/usr/bin/env bash
# scripts/lib/compose.sh — Docker Compose wrapper helpers
# Source this file; do NOT run directly.
# Requires: common.sh sourced first (for REPO_DIR, colors, logging, load_env)

_compose_base() {
  local args=("docker" "compose" "-f" "$REPO_DIR/docker-compose.yml" "--env-file" "$REPO_DIR/.env")
  # Append any --profile flags passed as leading arguments
  while [[ $# -gt 0 && "$1" == "--profile" ]]; do
    args+=("--profile" "$2")
    shift 2
  done
  args+=("$@")
  "${args[@]}"
}

# compose_up [--profile <name>]... [extra docker compose up flags]
# Brings up services with optional profile flags.
compose_up() {
  local profiles=()
  while [[ $# -gt 0 && "$1" == "--profile" ]]; do
    profiles+=("--profile" "$2")
    shift 2
  done
  info "Starting containers — waiting for healthchecks (this may take 1-2 minutes)..."
  _compose_base "${profiles[@]}" up -d --wait "$@"
}

# compose_down [--profile <name>]... [extra flags]
compose_down() {
  local profiles=()
  while [[ $# -gt 0 && "$1" == "--profile" ]]; do
    profiles+=("--profile" "$2")
    shift 2
  done
  _compose_base "${profiles[@]}" down "$@"
}

# compose_pull [--profile <name>]... [extra flags]
compose_pull() {
  local profiles=()
  while [[ $# -gt 0 && "$1" == "--profile" ]]; do
    profiles+=("--profile" "$2")
    shift 2
  done
  echo -e "\n${CYAN}${BOLD}┌──────────────────────────────────────────────────┐${NC}"
  echo -e "${CYAN}${BOLD}│  Pulling Docker images...                        │${NC}"
  echo -e "${CYAN}${BOLD}└──────────────────────────────────────────────────┘${NC}"
  # List images that will be pulled
  local images
  images=$(_compose_base "${profiles[@]}" config --images 2>/dev/null) || true
  if [[ -n "$images" ]]; then
    while IFS= read -r img; do
      [[ -n "$img" ]] && echo -e "  ${YELLOW}↓${NC} $img"
    done <<< "$images"
    echo ""
  fi
  _compose_base "${profiles[@]}" pull --ignore-buildable "$@"
}

# compose_build [--profile <name>]... [extra flags]
# Builds images for services that have a build: directive.
compose_build() {
  local profiles=()
  while [[ $# -gt 0 && "$1" == "--profile" ]]; do
    profiles+=("--profile" "$2")
    shift 2
  done
  echo -e "\n${CYAN}${BOLD}┌──────────────────────────────────────────────────┐${NC}"
  echo -e "${CYAN}${BOLD}│  Building Docker image from source...             │${NC}"
  echo -e "${CYAN}${BOLD}└──────────────────────────────────────────────────┘${NC}\n"
  _compose_base "${profiles[@]}" build --progress=plain "$@"
}

# ensure_backend_exclusive — DEPRECATED (dual-inference)
# Both backends (ollama-gpu + bitnet-cpu) now run simultaneously,
# fronted by llama-swap. Kept as no-op for backward compatibility.
ensure_backend_exclusive() {
  :  # no-op — dual backends are the default
}
