# install-lmstudio.sh — LM Studio

LM Studio is a desktop GUI for running GGUF models locally. This script
downloads and installs LM Studio, bootstraps the CLI (`lms`), and pulls a
curated set of models.

---

## What It Does

1. Downloads LM Studio `.deb` from the official installer CDN
2. Installs it with `dpkg` and fixes any missing dependencies
3. Runs `lms bootstrap` to initialize `~/.lmstudio` and the `lms` CLI
4. Pulls the following models via `lms get`:

| Model | Notes |
|-------|-------|
| `HauhauCS/Qwen3.5-9B-Uncensored-HauhauCS-Aggressive` | Uncensored Qwen 3.5 9B |
| `ThijsL202/Merged_Roleplay_Dominant_Model_TEST-Q5_K_S-GGUF` | Roleplay merge, Q5_K_S |
| `nvidia/NVIDIA-Nemotron-3-Nano-4B-GGUF:Q4_K_M` | NVIDIA Nemotron 4B |
| `bartowski/nvidia_Nemotron-Cascade-8B-GGUF:QUANT_TAG` | Nemotron Cascade 8B |
| `Jackrong/Qwen3.5-9B-Claude-4.6-Opus-Reasoning-Distilled-v2-GGUF:Q4_K_M` | Reasoning distill |

---

## Prerequisites

- Ubuntu 24.04 desktop (LM Studio requires a display)
- NVIDIA GPU with drivers installed (see `00-bootstrap.sh` step 13)
- `wget` available

---

## Usage

```bash
bash install-lmstudio.sh
```

> This script has no `set -e` guard — steps can partially fail without aborting.
> Check output manually if a model pull fails.

---

## Notes

- LM Studio also runs a local OpenAI-compatible server on port **1234** (when
  started from the GUI under the Local Server tab).
- Models are stored in `~/.lmstudio/models/`.
- `lms` CLI can be used headlessly after bootstrap:

  ```bash
  lms server start
  lms ls
  ```
