# Refactor Recap — 2024-04-14

## Summary

Comprehensive restructure of the component system: moved all 29 components
into per-component subfolders, created a machine-readable port map,
standardized every component script to an 8-flag CLI interface, built
Pester tests for every component, created 3 missing component scripts,
updated all documentation references, and fixed install-blocking path bugs.

**Branch:** `feature/manifest-wizard`
**Scope:** 170 files changed — 7,123 insertions, 1,243 deletions

## Commits (oldest → newest)

| SHA | Description |
|-----|-------------|
| `6dd1d35` | Pilot: move nemoclaw into per-component subfolder |
| `55c9e17` | Add nemoclaw `REFERENCES.md` with upstream quickstart link |
| `f6ce8c7` | Move all 24 remaining components into subfolders |
| `4ede909` | Rename sandbox identifiers; reassign htsclaw port 18792→18790 |
| `7d49aa9` | Create `config/portmap.json` (42 entries) + `Test-Portmap.Tests.ps1` |
| `fd5b443` | Add per-component Pester tests for all 29 components |
| `5a7777f` | Split htsclaw/nemoclaw tests into standard + extended |
| `b43c2f7` | Standardize CLI interface + fix REPO_DIR for all 25 scripts |
| `e668984` | Create grafana, portainer, lmstudio component scripts |
| `3f81575` | Update 84 doc path references to subfolder layout |
| `c8caa49` | Fix NEMOCLAW_PORT default (18790→18789) |
| `56a3b7e` | Fix 15 stale component paths in `full-stack.sh` |

## What Changed

### 1. Per-Component Subfolder Layout

Every component now lives in its own directory:

```text
# Before
scripts/components/ollama.sh
scripts/components/ollama.manifest.json

# After
scripts/components/ollama/ollama.sh
scripts/components/ollama/ollama.manifest.json
```

`manifest-loader.sh` supports dual-layout (checks subfolder first, flat fallback)
so nothing breaks if a component hasn't migrated yet.

### 2. Standardized CLI Interface (8 Flags)

Every component script now supports a consistent set of flags:

```text
--install      Full install sequence
--configure    Apply/update configuration
--start        Start the service
--stop         Stop the service
--restart      Stop then start
--health       Run health checks
--status       Show running state, port, and health
--destroy      Tear down (compose down -v or component-specific)
(no flag)      Equivalent to --install + --configure + --start + --health
```

Custom flags are preserved where needed:

- `ollama.sh` → `--pull-models`, `--swap`
- `comfyui.sh` → `--seed-models`
- `stable-diffusion.sh` → `--download`
- `nemoclaw.sh` → `--onboard`, `--tokens`, `--update`

### 3. REPO_DIR Fix

All 25 scripts had `REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"` — correct
when scripts lived at `scripts/components/NAME.sh` (2 levels deep) but wrong
after the subfolder move to `scripts/components/NAME/NAME.sh` (3 levels deep).

Fixed to: `REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"`

### 4. Port Map (`config/portmap.json`)

Single source of truth for all host port assignments — 42 entries covering
every service. Replaces the previous markdown table in `REFERENCES.md` as
the canonical machine-readable reference.

Used by `--status` functions and validated by `Test-Portmap.Tests.ps1`.

### 5. Pester Tests (29 Components)

Created test files for all 29 components following a standard template:

- Script exists at expected path
- Manifest exists and has valid JSON
- Manifest `script` field points to the correct path
- Port is reserved in `portmap.json`
- Script supports all 8 standard CLI flags
- Docker Compose profile exists (for compose-based components)

htsclaw and nemoclaw also have `*Extended.Tests.ps1` files covering
component-specific behavior (firewall rules, onboarding, health timers, etc.).

### 6. New Component Scripts

| Component | Type | Port(s) |
|-----------|------|---------|
| `grafana.sh` | Docker Compose (monitoring profile) | 3100 |
| `portainer.sh` | Docker Compose (portainer profile) | 9000, 9443 |
| `lmstudio.sh` | Host-native (.deb + lms CLI) | 1234 |

### 7. Documentation Path Updates

84 path references across 37 markdown files updated from
`scripts/components/NAME.sh` to `scripts/components/NAME/NAME.sh`.

### 8. Bug Fixes

| Bug | Fix |
|-----|-----|
| `state-actual.sh` had NEMOCLAW_PORT default 18790 | Changed to 18789 |
| `full-stack.sh` had 15 stale flat component paths | Updated all to subfolder layout |
| All 25 scripts had wrong REPO_DIR (`../..` → `../../..`) | Fixed in CLI standardization pass |

## Component Inventory

### Docker Compose Components (22)

bitnet, comfyui, dashboard, deerflow, duplicati, flowise, gitea, grafana,
gvisor-sandbox, langflow, llama-swap, lmstudio, n8n, ollama, open-webui,
openspace, pipelines, portainer, searxng, sillytavern, stable-diffusion,
unsloth

### Host-Native Components (6)

htsclaw, nemoclaw, signal, tailscale, telegram, timeshift

### Manifest-Only (No Script Yet)

prometheus — manifest exists at `scripts/components/prometheus/prometheus.manifest.json`

## Dispatch Pattern

All scripts unified to **Pattern A**:

```bash
while [[ $# -gt 0 ]]; do
  case "$1" in
    --install)    ACTION="install"    ;;
    --configure)  ACTION="configure"  ;;
    --start)      ACTION="start"      ;;
    --stop)       ACTION="stop"       ;;
    --restart)    ACTION="restart"    ;;
    --health)     ACTION="health"     ;;
    --status)     ACTION="status"     ;;
    --destroy)    ACTION="destroy"    ;;
    *)            err "Unknown flag: $1"; exit 1 ;;
  esac
  shift
done

case "${ACTION:-default}" in
  install)    _install   ;;
  configure)  _configure ;;
  start)      _start     ;;
  stop)       _stop      ;;
  restart)    _restart   ;;
  health)     _health    ;;
  status)     _status    ;;
  destroy)    _destroy   ;;
  default)    _install; _configure; _start; _health ;;
esac
```

## Known Remaining Items

- **`setup.sh`** — thin wrapper that execs `06-start-stack.sh` directly,
  fails after nuke because `.env` hasn't been created yet. Pre-existing issue;
  use `./install.sh` instead.
- **`prometheus.sh`** — manifest exists but no component script yet.
- **Lean/Mean/Claw rename** — user considering renaming model tiers to
  small/default/power. Parked as future feature.
- **`--upgrade` flag** — not yet implemented for any component. Tracked as
  next-release feature.
