$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/faster-whisper'
    $script:ComponentScript = Join-Path $script:ComponentDir 'faster-whisper.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'faster-whisper.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'faster-whisper file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'faster-whisper manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is faster-whisper' {
        $script:Manifest.id | Should -Be 'faster-whisper'
    }

    It 'category is audio' {
        $script:Manifest.category | Should -Be 'audio'
    }

    It 'profile is faster-whisper' {
        $script:Manifest.profile | Should -Be 'faster-whisper'
    }

    It 'dashboard port is 8600' {
        [int]$script:Manifest.dashboard.port | Should -Be 8600
    }

    It 'health URL targets health endpoint' {
        $script:Manifest.health.url | Should -Match '/health'
    }

    It 'script path points to component subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/faster-whisper/faster-whisper.sh'
    }

    It 'install_type is compose' {
        $script:Manifest.install_type | Should -Be 'compose'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'faster-whisper port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8600 is registered in portmap.json' {
        $script:Portmap.ports.'8600' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'8600'.service | Should -Be 'faster-whisper'
    }
}

# ── CLI flags ────────────────────────────────────────────────────────────────

Describe 'faster-whisper CLI flags' {

    BeforeAll {
        $script:ScriptContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'supports --install flag' {
        $script:ScriptContent | Should -Match '--install'
    }

    It 'supports --configure flag' {
        $script:ScriptContent | Should -Match '--configure'
    }

    It 'supports --start flag' {
        $script:ScriptContent | Should -Match '--start'
    }

    It 'supports --stop flag' {
        $script:ScriptContent | Should -Match '--stop'
    }

    It 'supports --restart flag' {
        $script:ScriptContent | Should -Match '--restart'
    }

    It 'supports --health flag' {
        $script:ScriptContent | Should -Match '--health'
    }

    It 'supports --status flag' {
        $script:ScriptContent | Should -Match '--status'
    }

    It 'supports --destroy flag' {
        $script:ScriptContent | Should -Match '--destroy'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'faster-whisper compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'faster-whisper service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'faster-whisper:'
    }

    It 'uses faster-whisper profile' {
        $script:ComposeContent | Should -Match 'faster-whisper'
    }

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/faster-whisper/Dockerfile' | Should -Exist
    }
}
