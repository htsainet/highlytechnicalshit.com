# DeerFlow References

Last updated: 2026-04-15

## Upstream

- [GitHub — bytedance/deer-flow](https://github.com/bytedance/deer-flow)

## Official documentation

- [DeerFlow README](https://github.com/bytedance/deer-flow#readme)
