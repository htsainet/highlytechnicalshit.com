#!/usr/bin/env bash
# scripts/host/node.sh — Node.js via NVM
# Independently runnable. Idempotent — skips if already installed.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/manifest.sh"

step "Node.js (NVM)"

NVM_DIR="${NVM_DIR:-$HOME/.nvm}"

# NVM requires relaxed error handling during sourcing
set +eu
if [ -s "$NVM_DIR/nvm.sh" ]; then
  # shellcheck source=/dev/null
  source "$NVM_DIR/nvm.sh"
  nvm use default 2>/dev/null || true
  set -eu
  info "NVM already installed ($(nvm --version))"
else
  set -eu
  info "Installing NVM..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
  set +eu
  # shellcheck source=/dev/null
  source "$NVM_DIR/nvm.sh"
  set -eu
fi

if node --version &>/dev/null; then
  info "Node.js already installed ($(node --version))"
else
  info "Installing Node.js LTS..."
  nvm install --lts
  NODE_VER=$(node --version | cut -d. -f1 | tr -d v)
  nvm alias default "$NODE_VER"
  info "Node.js $(node --version) installed."
fi

step "Node.js validation"
ok "Node: $(node --version)"
ok "npm: $(npm --version)"
manifest_add "nvm" "curl" "$(nvm --version 2>/dev/null || echo unknown)"
manifest_add "nodejs" "nvm" "$(node --version)"

info "Node.js setup complete."
