#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
# shellcheck source=scripts/install/tooling/ui.sh
source "$REPO_DIR/scripts/install/tooling/ui.sh"

htsai_banner "01 — Auto-Install"

info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already installed"; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }
session_has_docker_group() { id -nG | grep -qw docker; }
user_configured_for_docker_group() { id -nG "$USER" | grep -qw docker; }
run_docker() {
  local cmd=()

  if session_has_docker_group; then
    docker "$@"
    return
  fi

  for arg in docker "$@"; do
    cmd+=("$(printf '%q' "$arg")")
  done

  sg docker -c "${cmd[*]}"
}

# ── Pre-run checklist ─────────────────────────────────────────────────────────
checklist_start
if command -v docker &>/dev/null; then checklist_item true "1. Docker Engine"; else checklist_item false "1. Docker Engine"; fi
if command -v nvidia-ctk &>/dev/null; then checklist_item true "2. NVIDIA Container Toolkit"; else checklist_item false "2. NVIDIA Container Toolkit"; fi
if command -v nvcc &>/dev/null; then checklist_item true "3. CUDA Toolkit"; else checklist_item false "3. CUDA Toolkit"; fi
if command -v node &>/dev/null; then checklist_item true "4. Node.js (NVM)"; else checklist_item false "4. Node.js (NVM)"; fi
if command -v code &>/dev/null; then checklist_item true "5. Visual Studio Code"; else checklist_item false "5. Visual Studio Code"; fi
if command -v pwsh &>/dev/null; then checklist_item true "6. PowerShell 7"; else checklist_item false "6. PowerShell 7"; fi
if [ -f .env ]; then checklist_item true "7. Tokens (.env)"; else checklist_item false "7. Tokens (.env)"; fi
if systemctl is-active --quiet xrdp 2>/dev/null; then checklist_item true "8. xRDP (Remote Desktop)"; else checklist_item false "8. xRDP (Remote Desktop)"; fi
checklist_end

# ── Step 0: Host utilities ────────────────────────────────────────────────────
# nvtop     : GPU VRAM monitor (host-level, spans all containers)
# tmux      : keep SSH sessions alive during long pulls / NemoClaw runs
# ffmpeg    : host-side audio tooling (Whisper/XTTS bundle their own inside containers)
# jq        : parse JSON from Ollama/OpenClaw API responses in terminal
# ripgrep   : fast search — VS Code uses the host rg binary directly
# btop      : system monitor (CPU/RAM/disk/net across all containers)
# bat       : syntax-highlighted cat for reading configs
# remmina   : remote desktop client (RDP/VNC/SSH)
# wireguard : VPN client
# tailscale : installed on demand by scripts/install/networking/setup-tailscale.sh
# NOTE: build-essential omitted — DKMS pulls it as a dep when needed.
#       python3 / pip intentionally absent — all Python workloads run inside containers.
step "0 — Host utilities"

PKGS=()
for pkg in nvtop tmux ffmpeg jq ripgrep btop bat remmina wireguard; do
  dpkg -s "$pkg" &>/dev/null || PKGS+=("$pkg")
done

if [ ${#PKGS[@]} -eq 0 ]; then
  skip "nvtop, tmux, ffmpeg, jq, ripgrep, btop, bat, remmina, wireguard"
else
  info "Installing: ${PKGS[*]}"
  sudo apt-get update -qq
  sudo apt-get install -y "${PKGS[@]}"
  info "Host utilities ready."
fi

# ── Step 1: CUDA Toolkit ─────────────────────────────────────────────────────
step "1 — CUDA Toolkit"

if nvidia-smi &>/dev/null; then
  skip "NVIDIA drivers ($(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1))"
else
  info "NVIDIA drivers not found — installing (auto-detect best driver)..."
  sudo apt-get update -qq
  sudo apt-get install -y ubuntu-drivers-common
  sudo ubuntu-drivers install
  echo ""
  warn "══════════════════════════════════════════════════════════════════"
  warn "  NVIDIA drivers installed — REBOOT REQUIRED"
  warn "  After reboot, run:  ./install.sh"
  warn "══════════════════════════════════════════════════════════════════"
  exit 0
fi

if nvcc --version &>/dev/null; then
  skip "CUDA toolkit ($(nvcc --version | grep release | awk '{print $5}' | tr -d ','))"
else
  info "Installing CUDA toolkit..."
  sudo apt install -y nvidia-cuda-toolkit nvidia-cuda-toolkit-gcc
  nvcc --version
fi

# ── Step 2: Docker group ──────────────────────────────────────────────────────
step "2 — Docker group"

if getent group docker >/dev/null 2>&1; then
  info "docker group already exists."
else
  info "Creating docker group..."
  sudo groupadd docker
fi

if user_configured_for_docker_group; then
  skip "docker group membership for $USER"
else
  info "Adding $USER to docker group..."
  sudo usermod -aG docker "$USER"
fi

if session_has_docker_group; then
  info "Current shell already has docker group access."
else
  warn "Current shell has not picked up docker group membership yet."
  warn "Using 'sg docker' for Docker commands in this run; future shells will work after logout/login."
fi

# ── Step 3: Docker Engine ─────────────────────────────────────────────────────
step "3 — Docker Engine"

if docker --version &>/dev/null; then
  skip "Docker ($(docker --version | awk '{print $3}' | tr -d ','))"
else
  info "Installing Docker prerequisites..."
  sudo apt update
  sudo apt install -y ca-certificates curl gnupg

  sudo install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
    sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  sudo chmod a+r /etc/apt/keyrings/docker.gpg

  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
    https://download.docker.com/linux/ubuntu \
    $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
    sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

  sudo apt update
  sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

# ── Step 4: NVIDIA Container Toolkit ─────────────────────────────────────────
step "4 — NVIDIA Container Toolkit"

if nvidia-ctk --version &>/dev/null; then
  skip "NVIDIA Container Toolkit"
else
  info "Installing NVIDIA Container Toolkit..."
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | \
    sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg

  curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

  sudo apt-get update
  sudo apt-get install -y nvidia-container-toolkit

  info "Configuring Docker runtime for NVIDIA..."
  sudo nvidia-ctk runtime configure --runtime=docker
  sudo systemctl restart docker

  info "Verifying GPU access in Docker..."
  run_docker run --rm --runtime=nvidia --gpus all nvidia/cuda:12.0.1-base-ubuntu22.04 nvidia-smi
fi

# ── Step 5: Node.js (NVM) ─────────────────────────────────────────────────────
step "5 — Node.js (NVM)"

NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
set +eu
if [ -s "$NVM_DIR/nvm.sh" ]; then
  # shellcheck source=/dev/null
  source "$NVM_DIR/nvm.sh"
  nvm use default 2>/dev/null || true
  set -eu
  skip "NVM ($(nvm --version))"
else
  set -eu
  info "Installing NVM..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
  set +eu
  # shellcheck source=/dev/null
  source "$NVM_DIR/nvm.sh"
  set -eu
fi

if node --version &>/dev/null; then
  skip "Node.js ($(node --version))"
else
  info "Installing Node.js LTS..."
  nvm install --lts
  NODE_VER=$(node --version | cut -d. -f1 | tr -d v)
  nvm alias default "$NODE_VER"
  info "Node.js $(node --version) installed."
fi

# ── Step 6: Visual Studio Code ─────────────────────────────────────────────────
step "6 — Visual Studio Code"

# Clean up conflicting VS Code apt sources first (list + deb822 sources)
sudo rm -f /usr/share/keyrings/microsoft.gpg 2>/dev/null || true
sudo rm -f /etc/apt/sources.list.d/vscode.list /etc/apt/sources.list.d/vscode.sources 2>/dev/null || true

for src_file in /etc/apt/sources.list /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources; do
  [ -f "$src_file" ] || continue
  if grep -q 'packages.microsoft.com/repos/code' "$src_file"; then
    # Remove any source file that defines the VS Code repo so only our canonical
    # entry below remains.
    if [[ "$src_file" == /etc/apt/sources.list.d/* ]]; then
      sudo rm -f "$src_file"
      continue
    fi
    sudo sed -i '/packages\.microsoft\.com\/repos\/code/d' "$src_file"
  fi
done

info "Installing Microsoft signing key for VS Code..."
sudo install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor | sudo tee /etc/apt/keyrings/packages.microsoft.gpg >/dev/null
sudo chmod 644 /etc/apt/keyrings/packages.microsoft.gpg

if [ ! -f /etc/apt/sources.list.d/vscode.list ]; then
  info "Adding VS Code apt repository..."
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main" | sudo tee /etc/apt/sources.list.d/vscode.list >/dev/null
fi

sudo apt-get update -qq
sudo apt-get install -y -qq code
info "VS Code installed."

VSCODE_EXTENSIONS=(
  davidanson.vscode-markdownlint          # MD lint (matches pre-commit hook rules)
  yzhang.markdown-all-in-one             # Markdown formatting, ToC, shortcuts
  streetsidesoftware.code-spell-checker   # Spell checker (respects cspell.json)
  timonwong.shellcheck                   # Shell script linting
  ms-python.python                       # Python language support
  ms-python.vscode-pylance               # Pylance — fast Python type checking
  ms-python.python-environ-manager       # Python Environment Manager
  ms-vscode-remote.remote-ssh            # Remote SSH editing
  ms-vscode-remote.remote-containers     # Dev Containers support
  ms-azuretools.vscode-docker            # Docker Compose / Dockerfile support
  ms-vscode.powershell                   # PowerShell language support
  eamodio.gitlens                        # GitLens — enhanced Git history/blame
  github.vscode-pull-request-github      # GitHub Pull Requests and Issues
  github.copilot                         # GitHub Copilot
  github.copilot-chat                    # GitHub Copilot Chat
  anthropic.claude-code                  # Claude Code
)

if command -v code &>/dev/null; then
  for ext in "${VSCODE_EXTENSIONS[@]}"; do
    code --install-extension "$ext" --force >/dev/null 2>&1 && \
      info "Installed extension: $ext" || \
      warn "Failed to install extension: $ext (may not be available in this environment)"
  done
  info "VS Code extensions installed."
  info "To sync settings across machines: Code → Settings Sync → Turn On (sign in with GitHub)"
else
  warn "VS Code CLI (code) not found in PATH; skipping extension install."
fi

# ── Step 6b: VS Code MCP Servers ─────────────────────────────────────────────
# Configures local MCP servers for GitHub Copilot Chat tool use.
# Uses `code --add-mcp` (requires VS Code 1.99+).
# Detection reads ~/.config/Code/User/settings.json via jq.

_mcp_server_exists() {
  local name="$1"
  local settings="${HOME}/.config/Code/User/settings.json"
  [[ -f "$settings" ]] && jq -e ".mcp.servers[\"$name\"]" "$settings" &>/dev/null
}

if command -v code &>/dev/null; then
  # Docker MCP server — inspect containers, images, volumes, logs
  if _mcp_server_exists "docker"; then
    skip "MCP server: docker (already configured)"
  else
    code --add-mcp '{"name":"docker","command":"docker","args":["mcp","gateway","run"]}' && \
      info "MCP server configured: docker" || \
      warn "MCP server: docker — failed (requires Docker with mcp subcommand)"
  fi

  # Filesystem MCP server — read files outside the VS Code workspace (e.g. NAS mount)
  if _mcp_server_exists "filesystem"; then
    skip "MCP server: filesystem (already configured)"
  else
    code --add-mcp "{\"name\":\"filesystem\",\"command\":\"npx\",\"args\":[\"-y\",\"@modelcontextprotocol/server-filesystem\",\"${HOME}/github\",\"/mnt/nas\"]}" && \
      info "MCP server configured: filesystem" || \
      warn "MCP server: filesystem — failed"
  fi

  # Ollama MCP server — query running Ollama instances (list models, pull, check tags)
  # Uses community package mcp-ollama (npx, no global install required)
  if _mcp_server_exists "ollama"; then
    skip "MCP server: ollama (already configured)"
  else
    code --add-mcp '{"name":"ollama","command":"npx","args":["-y","mcp-ollama"]}' && \
      info "MCP server configured: ollama" || \
      warn "MCP server: ollama — failed"
  fi

  info "VS Code MCP servers configured."
else
  warn "VS Code CLI (code) not found in PATH; skipping MCP server setup."
fi

# ── Step 7: PowerShell 7 ──────────────────────────────────────────────────────
step "7 — PowerShell 7"

if command -v pwsh &>/dev/null; then
  skip "PowerShell $(pwsh --version 2>/dev/null | head -1)"
else
  info "Registering Microsoft package repository..."
  # shellcheck source=/dev/null
  source /etc/os-release
  curl -fsSL "https://packages.microsoft.com/config/ubuntu/${VERSION_ID}/packages-microsoft-prod.deb" -o /tmp/packages-microsoft-prod.deb
  sudo dpkg -i /tmp/packages-microsoft-prod.deb
  rm /tmp/packages-microsoft-prod.deb
  sudo apt-get update -qq

  info "Installing PowerShell..."
  sudo apt-get install -y -qq powershell

  info "PowerShell installed: $(pwsh --version 2>/dev/null | head -1)"
fi

info "Ensuring Pester is available..."
pwsh -NoLogo -NoProfile -Command "if ((Get-PSRepository -Name PSGallery).InstallationPolicy -ne 'Trusted') { Set-PSRepository -Name PSGallery -InstallationPolicy Trusted }; if (-not (Get-Module -ListAvailable -Name Pester)) { Install-Module -Name Pester -Scope CurrentUser -Force -SkipPublisherCheck -Repository PSGallery }"

# ── Step 8: Generate .env tokens ──────────────────────────────────────────────
step "8 — Tokens (.env)"

ENV_FILE="$REPO_DIR/.env"

ensure_env_key() {
  local key="$1"
  local value

  # Missing key or empty value: generate and write a secure token.
  if ! grep -Eq "^${key}=" "$ENV_FILE" || grep -Eq "^${key}=[[:space:]]*$" "$ENV_FILE"; then
    value=$(openssl rand -hex 32)
    if grep -Eq "^${key}=" "$ENV_FILE"; then
      sed -i "s|^${key}=.*|${key}=${value}|" "$ENV_FILE"
    else
      printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
    fi
    info "Set ${key}: ${value:0:8}..."
  else
    info "${key} already present."
  fi
}

if [ ! -f "$ENV_FILE" ]; then
  info "Creating .env and generating secure tokens..."
  cat > "$ENV_FILE" <<EOF
# Generated by 01-autoinstall.sh — do not commit this file

# ── Backend engine ────────────────────────────────────────────────────────────
# Set to 'ollama' (default) or 'bitnet' to switch inference backends.
BACKEND_ENGINE=ollama

# ── BitNet settings (only used when BACKEND_ENGINE=bitnet) ────────────────────
# BITNET_MODEL=Llama3-8B-1.58-100B-tokens
# BITNET_HF_REPO=HF1BitLLM/Llama3-8B-1.58-100B-tokens-GGUF
# HF_TOKEN=
EOF
else
  info ".env exists — validating required tokens."
fi

# Ensure BACKEND_ENGINE is present (for existing .env files)
if ! grep -q "^BACKEND_ENGINE=" "$ENV_FILE"; then
  printf '\n# Backend engine: ollama (default) or bitnet\nBACKEND_ENGINE=ollama\n' >> "$ENV_FILE"
  info "Added BACKEND_ENGINE=ollama to .env"
fi

ensure_env_key "WEBUI_SECRET_KEY"
ensure_env_key "OPENCLAW_TOKEN"
chmod 600 "$ENV_FILE"
info ".env ready: $ENV_FILE"

# ── Step 9: Repo tooling ──────────────────────────────────────────────────────
step "9 — Repo tooling"

cd "$REPO_DIR"

if [ -f package.json ]; then
  info "Installing repo-local Node tooling..."
  npm install
fi

if [ -f tests/Install-GitHooks.ps1 ]; then
  info "Configuring repo-local git hooks..."
  pwsh -NoLogo -NoProfile -File tests/Install-GitHooks.ps1
fi

# ── Step 10: Install exFAT support ────────────────────────────────────────────
step "10 — Install exFAT support"

sudo apt install -y exfatprogs

# ── Step 11: xRDP — Remote Desktop (inbound RDP) ─────────────────────────────
step "11 — xRDP (Remote Desktop)"

if systemctl is-active --quiet xrdp 2>/dev/null; then
  skip "xRDP already running (port 3389)"
else
  info "Installing xrdp..."
  sudo apt install -y xrdp

  # Add xrdp user to ssl-cert group so it can read the TLS cert
  sudo adduser xrdp ssl-cert

  # Use the existing desktop session (Gnome/Xorg) rather than spawning a new one
  # This prevents the blank-screen issue on Ubuntu 24.04 with Wayland
  echo "gnome-session" | sudo tee /etc/xrdp/sesman-Xsession
  sudo bash -c 'echo "exec /usr/bin/gnome-session" > /etc/xrdp/startwm.sh'
  sudo chmod +x /etc/xrdp/startwm.sh

  sudo systemctl enable xrdp
  sudo systemctl restart xrdp

  info "xRDP installed and running on port 3389."
  info "Connect from Windows: mstsc → hostname or IP"
  info "Connect from Mac:     Microsoft Remote Desktop app"
  warn "If using Wayland, log out and log back in with 'Ubuntu on Xorg' first."
fi

# ── Step 12: Verify prerequisites ─────────────────────────────────────────────
step "12 — Verify prerequisites"

if ! docker --version &>/dev/null; then
  warn "Docker not found — re-run this script or check Step 3."
else
  info "Docker: $(docker --version)"
  info "Compose: $(run_docker compose version)"
fi

if ! nvidia-ctk --version &>/dev/null; then
  warn "NVIDIA Container Toolkit not found — re-run this script or check Step 4."
else
  info "NVIDIA CTK: $(nvidia-ctk --version | head -1)"
fi

if ! nvidia-smi &>/dev/null; then
  warn "nvidia-smi not responding — check NVIDIA driver install (Step 1)."
else
  info "GPU: $(nvidia-smi --query-gpu=name --format=csv,noheader | head -1)"
fi

if [ -d "$HOME/models/approved" ] && [ -d "$HOME/models/testing" ]; then
  skip "Model folders (approved, testing)"
else
  info "Creating model folders..."
  mkdir -p "$HOME/models"/{approved,testing}
fi

echo ""
info "Host setup complete. install.sh will continue with remaining steps."
