#!/usr/bin/env bash
# scripts/components/duplicati/duplicati.sh — Duplicati file-level backups
#
# Standalone usage:
#   ./scripts/components/duplicati/duplicati.sh              # full: install + configure + start + health
#   ./scripts/components/duplicati/duplicati.sh --install    # install only
#   ./scripts/components/duplicati/duplicati.sh --configure  # configure only
#   ./scripts/components/duplicati/duplicati.sh --start      # start only
#   ./scripts/components/duplicati/duplicati.sh --stop       # stop
#   ./scripts/components/duplicati/duplicati.sh --restart    # restart (stop + start)
#   ./scripts/components/duplicati/duplicati.sh --health     # health check only
#   ./scripts/components/duplicati/duplicati.sh --status     # show status + port + health
#   ./scripts/components/duplicati/duplicati.sh --reset-password  # regenerate web UI password
#   ./scripts/components/duplicati/duplicati.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
DUPLICATI_CONTAINER="${DUPLICATI_CONTAINER:-hts-ai-duplicati}"
DUPLICATI_PORT="${DUPLICATI_PORT:-8200}"

# ── Functions ────────────────────────────────────────────────────────────────

# duplicati_install — Pull the Duplicati container image
duplicati_install() {
  step "Duplicati — install"
  compose_build --profile duplicati
  ok "Duplicati image built."
}

# duplicati_configure — Set backup targets and schedules
duplicati_configure() {
  step "Duplicati — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^DUPLICATI_PORT=" "$env_file" 2>/dev/null; then
    printf 'DUPLICATI_PORT=%s\n' "$DUPLICATI_PORT" >> "$env_file"
    info "Added DUPLICATI_PORT=${DUPLICATI_PORT} to .env"
  fi

  if ! grep -q "^DUPLICATI_ENCRYPTION_KEY=" "$env_file" 2>/dev/null; then
    local enc_key
    enc_key=$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')
    printf 'DUPLICATI_ENCRYPTION_KEY=%s\n' "$enc_key" >> "$env_file"
    info "Generated DUPLICATI_ENCRYPTION_KEY"
  fi

  if ! grep -q "^DUPLICATI_WEB_PASSWORD=" "$env_file" 2>/dev/null; then
    local web_pw
    web_pw=$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')
    printf 'DUPLICATI_WEB_PASSWORD=%s\n' "$web_pw" >> "$env_file"
    info "Generated DUPLICATI_WEB_PASSWORD (see .env)"
  fi

  info "Web UI:     http://localhost:${DUPLICATI_PORT}"
  info "Password:   \$DUPLICATI_WEB_PASSWORD in .env  (no username — Duplicati is single-user)"
  info "Configure backup targets and schedules via the web UI after start."
  ok "Duplicati configured."
}

# duplicati_reset_password — Regenerate and apply a new web UI password
duplicati_reset_password() {
  step "Duplicati — reset web password"
  local env_file="$REPO_DIR/.env"
  local new_pw
  new_pw=$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')

  if grep -q "^DUPLICATI_WEB_PASSWORD=" "$env_file" 2>/dev/null; then
    sed -i "s|^DUPLICATI_WEB_PASSWORD=.*|DUPLICATI_WEB_PASSWORD=${new_pw}|" "$env_file"
  else
    printf 'DUPLICATI_WEB_PASSWORD=%s\n' "$new_pw" >> "$env_file"
  fi
  info "New password written to .env"

  # Force container to pick up the new env var.
  # Duplicati reads DUPLICATI__WEBSERVICE_PASSWORD on startup and overwrites
  # the stored password each boot, so a restart is sufficient.
  if docker ps --format '{{.Names}}' | grep -q "^${DUPLICATI_CONTAINER}$"; then
    info "Restarting container to apply new password..."
    compose_down --profile duplicati
    compose_up --profile duplicati
  fi

  ok "Duplicati password reset. New value is in .env as DUPLICATI_WEB_PASSWORD."
  warn "Duplicati is single-user: leave the username field blank on login."
}

# duplicati_start — Bring up Duplicati via compose
duplicati_start() {
  step "Duplicati — start"
  compose_up --profile duplicati
  ok "Duplicati started on port ${DUPLICATI_PORT}."
}

# duplicati_stop — Bring down Duplicati
duplicati_stop() {
  step "Duplicati — stop"
  compose_down --profile duplicati
  ok "Duplicati stopped."
}

# duplicati_health — Probe the Duplicati web UI
duplicati_health() {
  health_probe "Duplicati :${DUPLICATI_PORT}" "http://localhost:${DUPLICATI_PORT}/" 45
}

duplicati_restart() {
  duplicati_stop
  duplicati_start
}

duplicati_destroy() {
  step "Duplicati — destroy"
  compose_down --profile duplicati -v
  ok "Duplicati destroyed."
}

duplicati_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=duplicati" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Duplicati is running (port ${DUPLICATI_PORT})"
  else
    warn "Duplicati is not running."
  fi
  duplicati_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)        ACTION="install";        shift ;;
      --configure)      ACTION="configure";      shift ;;
      --start)          ACTION="start";          shift ;;
      --stop)           ACTION="stop";           shift ;;
      --restart)        ACTION="restart";        shift ;;
      --health)         ACTION="health";         shift ;;
      --status)         ACTION="status";         shift ;;
      --reset-password) ACTION="reset_password"; shift ;;
      --destroy)        ACTION="destroy";        shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)        duplicati_install        ;;
    configure)      duplicati_configure      ;;
    start)          duplicati_start          ;;
    stop)           duplicati_stop           ;;
    restart)        duplicati_restart        ;;
    health)         duplicati_health         ;;
    status)         duplicati_status         ;;
    reset_password) duplicati_reset_password ;;
    destroy)        duplicati_destroy        ;;
    default)
      duplicati_install
      duplicati_configure
      duplicati_start
      duplicati_health
      ;;
  esac
fi
