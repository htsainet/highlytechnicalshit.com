#!/usr/bin/env bash
# scripts/components/opentoonz/opentoonz.sh — OpenToonz: install, configure, health
#
# Host-native installer for OpenToonz, the professional 2D animation software
# originally developed by Digital Video and used by Studio Ghibli.
# Open-sourced in 2016 under the BSD license.
#
# Standalone usage:
#   ./scripts/components/opentoonz/opentoonz.sh              # full: install + configure + health
#   ./scripts/components/opentoonz/opentoonz.sh --install    # install only
#   ./scripts/components/opentoonz/opentoonz.sh --configure  # configure only
#   ./scripts/components/opentoonz/opentoonz.sh --start      # no-op (desktop app)
#   ./scripts/components/opentoonz/opentoonz.sh --stop       # no-op (desktop app)
#   ./scripts/components/opentoonz/opentoonz.sh --restart    # no-op (desktop app)
#   ./scripts/components/opentoonz/opentoonz.sh --health     # health check only
#   ./scripts/components/opentoonz/opentoonz.sh --status     # show status + health
#   ./scripts/components/opentoonz/opentoonz.sh --destroy    # uninstall OpenToonz
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# ── Functions ────────────────────────────────────────────────────────────────

opentoonz_install() {
  step "OpenToonz — install"
  if command -v opentoonz &>/dev/null; then
    skip "OpenToonz already installed."
  else
    info "Adding OpenToonz PPA and installing..."
    sudo add-apt-repository -y ppa:morevnaproject/opentoonz
    sudo apt-get update -qq
    sudo apt-get install -y -qq opentoonz
    ok "OpenToonz installed."
  fi
}

opentoonz_configure() {
  step "OpenToonz — configure"
  info "OpenToonz is a desktop application — no service configuration needed."
  ok "OpenToonz configured."
}

opentoonz_start() {
  step "OpenToonz — start"
  info "OpenToonz is a desktop application. Launch from your application menu."
}

opentoonz_stop() {
  step "OpenToonz — stop"
  info "OpenToonz is a desktop application. Close it from the window."
}

opentoonz_restart() {
  opentoonz_stop
  opentoonz_start
}

opentoonz_health() {
  step "OpenToonz — health"
  if command -v opentoonz &>/dev/null; then
    ok "OpenToonz is installed."
    return 0
  else
    warn "OpenToonz is not installed."
    return 1
  fi
}

opentoonz_status() {
  step "OpenToonz — status"
  opentoonz_health
}

opentoonz_destroy() {
  step "OpenToonz — destroy"
  if dpkg -l opentoonz &>/dev/null 2>&1; then
    info "Removing OpenToonz..."
    sudo apt-get remove -y opentoonz
    sudo add-apt-repository -y --remove ppa:morevnaproject/opentoonz
    ok "OpenToonz removed."
  else
    skip "OpenToonz is not installed."
  fi
}

# ── CLI entry point ──────────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  case "${1:-}" in
    --install)   opentoonz_install   ;;
    --configure) opentoonz_configure ;;
    --start)     opentoonz_start     ;;
    --stop)      opentoonz_stop      ;;
    --restart)   opentoonz_restart   ;;
    --health)    opentoonz_health    ;;
    --status)    opentoonz_status    ;;
    --destroy)   opentoonz_destroy   ;;
    *)
      opentoonz_install
      opentoonz_configure
      opentoonz_health
      ;;
  esac
fi
