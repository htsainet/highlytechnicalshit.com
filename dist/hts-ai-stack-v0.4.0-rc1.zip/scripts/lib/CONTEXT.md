# Shared Function Libraries

Last updated: 2026-04-04 23:00:00

## What happens here

This workspace contains shared bash function libraries that are **sourced** (not executed) by component and bundle scripts. Every script in the stack that needs logging, compose wrappers, health checks, or token management sources these files.

## Process / Workflow

1. Component or bundle script sources `lib/common.sh` first (always required)
2. Additional libraries sourced as needed (`compose.sh`, `health.sh`, `tokens.sh`)
3. Libraries provide functions — they never run standalone

## Files and structure

| File | Purpose |
|------|---------|
| `common.sh` | Colors, logging (`info`, `warn`, `fail`, `banner`), `REPO_DIR` detection, `load_env`, config helpers |
| `compose.sh` | Docker Compose wrappers (`compose_up`, `compose_down`, `compose_pull`, `compose_build`) with profile support |
| `health.sh` | Unified health probes (`health_probe <label> <url>`) with retry and timeout |
| `tokens.sh` | Crypto-random token generation (`generate_token`) and `.env` key management (`ensure_env_key`) |

## What good looks like

- Every file has `# Source this file; do NOT run directly` header comment
- Functions are pure helpers — no side effects on source
- `common.sh` always sourced first (others depend on it)
- No duplicate logic — if two components need the same thing, it belongs here
- All `.sh` files have `#!/usr/bin/env bash` shebang

## Tools and skills

- **Bash** — All libraries are POSIX-compatible bash
- **Docker Compose** — `compose.sh` wraps the `docker compose` CLI
- **OpenSSL** — `tokens.sh` uses `openssl rand` for cryptographic tokens
