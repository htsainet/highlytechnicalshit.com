#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "[WARN] nuke-stack.sh is deprecated; use ./reset-stack.sh instead." >&2
exec "$SCRIPT_DIR/reset-stack.sh" "$@"
