#!/usr/bin/env bash
# scripts/components/open-llm-vtuber/open-llm-vtuber.sh — Open-LLM-VTuber avatar chat
#
# Docker-based installer for Open-LLM-VTuber, a hands-free voice-interactive
# Live2D avatar chat powered by local LLM, TTS, and STT. Connects to the
# stack's Ollama, Faster-Whisper, and Coqui TTS services.
#
# Standalone usage:
#   ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh              # full lifecycle
#   ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --install    # install only
#   ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --configure  # configure only
#   ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --start      # start only
#   ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --stop       # stop
#   ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --restart    # restart
#   ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --health     # health check
#   ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --status     # status + health
#   ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --destroy    # destroy
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
OPEN_LLM_VTUBER_CONTAINER="${OPEN_LLM_VTUBER_CONTAINER:-hts-ai-open-llm-vtuber}"
OPEN_LLM_VTUBER_PORT="${OPEN_LLM_VTUBER_PORT:-12393}"

# ── Functions ────────────────────────────────────────────────────────────────

# open_llm_vtuber_install — Build the Open-LLM-VTuber container image
open_llm_vtuber_install() {
  step "Open-LLM-VTuber — install"
  warn "Image is large (~13–25 GB). Build may take a while."
  compose_build --profile open-llm-vtuber
  ok "Open-LLM-VTuber image built."
}

# open_llm_vtuber_configure — Ensure .env has port + inject conf.yaml
open_llm_vtuber_configure() {
  step "Open-LLM-VTuber — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^OPEN_LLM_VTUBER_PORT=" "$env_file" 2>/dev/null; then
    printf 'OPEN_LLM_VTUBER_PORT=%s\n' "$OPEN_LLM_VTUBER_PORT" >> "$env_file"
    info "Added OPEN_LLM_VTUBER_PORT=${OPEN_LLM_VTUBER_PORT} to .env"
  fi

  # Inject conf.yaml pointing to stack services
  local vol_name
  vol_name=$(docker volume ls --format '{{.Name}}' | grep open_llm_vtuber_data || true)
  if [[ -z "$vol_name" ]]; then
    vol_name="hts-ai-stack_open_llm_vtuber_data"
    docker volume create "$vol_name" >/dev/null 2>&1 || true
  fi

  docker run --rm -v "${vol_name}:/data" busybox sh -c '
    cat > /data/conf.yaml <<YAML
# Open-LLM-VTuber configuration — managed by hts-ai-stack
# Connects to stack services on the ai-network Docker bridge.

# LLM backend — uses the stack Ollama instance
llm_provider: ollama
ollama_base_url: http://ollama:11434
ollama_model: llama3.2

# Speech-to-text — uses the stack Faster-Whisper instance
asr_provider: faster-whisper-api
faster_whisper_api_url: http://faster-whisper:8600

# Text-to-speech — uses the stack Coqui TTS instance
tts_provider: coqui-api
coqui_api_url: http://coqui-tts:5002

# Web UI
host: 0.0.0.0
port: 12393
YAML
    chmod 644 /data/conf.yaml
  '
  info "Injected conf.yaml (Ollama + Faster-Whisper + Coqui TTS)"
  info "Edit the volume conf.yaml to change models or providers."

  ok "Open-LLM-VTuber configured (port ${OPEN_LLM_VTUBER_PORT})."
}

# open_llm_vtuber_start — Bring up Open-LLM-VTuber via compose
open_llm_vtuber_start() {
  step "Open-LLM-VTuber — start"
  compose_up --profile open-llm-vtuber
  ok "Open-LLM-VTuber started on port ${OPEN_LLM_VTUBER_PORT}."
}

# open_llm_vtuber_stop — Bring down Open-LLM-VTuber
open_llm_vtuber_stop() {
  step "Open-LLM-VTuber — stop"
  compose_down --profile open-llm-vtuber
  ok "Open-LLM-VTuber stopped."
}

# open_llm_vtuber_health — Probe the Open-LLM-VTuber web UI
open_llm_vtuber_health() {
  health_probe "Open-LLM-VTuber :${OPEN_LLM_VTUBER_PORT}" "http://localhost:${OPEN_LLM_VTUBER_PORT}/"
}

open_llm_vtuber_restart() {
  open_llm_vtuber_stop
  open_llm_vtuber_start
}

open_llm_vtuber_destroy() {
  step "Open-LLM-VTuber — destroy"
  compose_down --profile open-llm-vtuber -v
  ok "Open-LLM-VTuber destroyed."
}

open_llm_vtuber_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=open-llm-vtuber" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Open-LLM-VTuber is running (port ${OPEN_LLM_VTUBER_PORT})"
  else
    warn "Open-LLM-VTuber is not running."
  fi
  open_llm_vtuber_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   open_llm_vtuber_install   ;;
    configure) open_llm_vtuber_configure ;;
    start)     open_llm_vtuber_start     ;;
    stop)      open_llm_vtuber_stop      ;;
    restart)   open_llm_vtuber_restart   ;;
    health)    open_llm_vtuber_health    ;;
    status)    open_llm_vtuber_status    ;;
    destroy)   open_llm_vtuber_destroy   ;;
    default)
      open_llm_vtuber_install
      open_llm_vtuber_configure
      open_llm_vtuber_start
      open_llm_vtuber_health
      ;;
  esac
fi
