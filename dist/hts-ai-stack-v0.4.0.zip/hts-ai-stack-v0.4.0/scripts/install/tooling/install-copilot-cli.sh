#!/usr/bin/env bash
# install-copilot-cli.sh — Install GitHub Copilot CLI extension for gh
#
# Installs the `gh copilot` extension and prompts for auth on first run.
# Idempotent: skips if already installed.

set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already installed" >&2; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

# ── Step 1: Check prerequisites ───────────────────────────────────────────────
step "1 — Prerequisites"

if ! command -v gh &>/dev/null; then
  echo "gh (GitHub CLI) is required but not installed. Run ./00-bootstrap.sh first." >&2
  exit 1
fi

if ! gh auth status &>/dev/null; then
  echo "GitHub CLI is not authenticated. Run: gh auth login" >&2
  exit 1
fi

info "GitHub CLI authenticated."

# ── Step 2: Install copilot extension ─────────────────────────────────────────
step "2 — Install gh copilot extension"

# Prefer snap-packaged copilot-cli when available; fallback to gh extension
if command -v snap &>/dev/null; then
  if snap list copilot-cli >/dev/null 2>&1; then
    skip "copilot-cli (snap)"
  else
    info "Installing copilot-cli via snap (requires sudo)..."
    if sudo snap install copilot-cli --classic; then
      info "copilot-cli installed via snap"
    else
      warn "snap install failed — falling back to gh extension installation"
      if gh extension list 2>/dev/null | grep -q "github/gh-copilot"; then
        skip "gh copilot extension"
      else
        info "Installing gh copilot extension..."
        gh extension install github/gh-copilot || warn "gh extension install failed"
      fi
    fi
  fi
elif gh extension list 2>/dev/null | grep -q "github/gh-copilot"; then
  skip "gh copilot extension"
else
  info "Installing gh copilot extension..."
  gh extension install github/gh-copilot || warn "gh extension install failed"
  info "gh copilot extension installed."
fi

# ── Step 3: Auth ──────────────────────────────────────────────────────────────
step "3 — Authenticate Copilot"

info "To authenticate Copilot CLI, run:"
echo ""
echo "    gh copilot auth"
echo ""
info "Or use it directly — it will prompt for auth on first use:"
echo ""
echo "    gh copilot suggest 'list all running docker containers'"
echo "    gh copilot explain 'docker compose up -d'"
echo ""
info "Copilot CLI is ready."
