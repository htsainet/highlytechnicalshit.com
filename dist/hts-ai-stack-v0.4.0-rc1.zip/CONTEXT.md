# Current Project

Last updated: 2026-04-05 20:30:00

## What we are building

We are building a reproducible installation procedure for a customizable, Linux AI stack utilizing a locally hosted LLM to act as an AI Agent.  

Repo: https://github.com/htsai-net/hts-ai-stack-release

[Core Services]
OpenClaw: https://openclaw.ai/
NemoClaw: https://www.nvidia.com/en-us/ai/nemoclaw/
OpenShell: https://docs.nvidia.com/openshell/latest/index.html
Ollama: https://ollama.com/

## What good looks like

User can securely run and manage a local clawbot instance without having to install everything manually.

## Completed Projects

- **Install pipeline refactor** — restructured scripts into `lib/`, `host/`, `components/`, `bundles/`. All 16 tasks completed. See [refactor/CONTEXT.md](refactor/CONTEXT.md) for decisions and archive.

## Active Projects

- **Dual-inference backend** — adding BitNet + llama-swap alongside Ollama for GPU/CPU split inference. See `feature/dual-inference` branch.
- **Dashboard auto-login** — tokenized URLs for Open WebUI and NemoClaw sandboxes so the dashboard provides one-click authenticated access without manual sign-in. Uses a same-origin login bridge page and JWT sidecar files.
- **OpenClaw auto-update** — `nemoclaw.sh --update` automatically updates OpenClaw inside GPU/CPU sandboxes to the latest version.

## What to avoid

Avoid using cloud based LLMs within the app so spend can be controlled.

## Tools and dependencies

- **Ubuntu 24.04 LTS** — Target Linux distribution
- **Docker** — Container orchestration
- **NVIDIA CUDA** — GPU acceleration
- **Ollama** — Local LLM inference
- **llama-swap** — Model multiplexer for GPU/CPU split inference
- **NemoClaw** — Sandbox security enforcement
- **OpenClaw** — AI agent runtime
- **Open WebUI** — Chat frontend (all models via llama-swap)
- **Claude Code** — Documentation and script generation
- **Pester** — Configuration and integration testing
