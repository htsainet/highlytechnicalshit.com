# FEATURE-045 — Chatwoot Customer Support Platform

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | LOW |
| **Effort** | 4–6 hours |
| **Risk** | Medium — requires PostgreSQL + Redis sub-dependencies |
| **Target Release** | Unscheduled |
| **Depends on** | Nothing |
| **Blocks** | Nothing |

## Problem

There is no customer-facing support or communication platform in the stack. As the stack evolves toward multi-user or MSP (Managed Service Provider) deployments, a unified inbox for handling support requests across channels (email, chat, Telegram, etc.) will be needed.

## Solution

Self-host [Chatwoot](https://github.com/chatwoot/chatwoot) — an open-source customer engagement platform with live chat, multi-channel inbox, and team collaboration features.

### Why deferred

The current stack is a single-admin AI dev environment. Customer support tooling becomes relevant when:

- The stack is deployed for a team or clients (MSP use case)
- End-users interact with AI services and need a support channel
- Chatwoot is paired with an MSP platform for ticketing and SLA management

### MSP integration opportunity

Chatwoot pairs naturally with open-source MSP/PSA software for a complete managed services stack:

- **Chatwoot** → customer-facing live chat + multi-channel inbox
- **MSP platform** → ticketing, SLA tracking, asset management, billing
- **Ollama/llama-swap** → AI-powered auto-responses and ticket triage
- **n8n** → workflow automation bridging Chatwoot ↔ MSP ↔ AI

This combination could form a self-hosted AI-enhanced managed services offering.

### LLM integration (future)

- Wire Chatwoot webhook → n8n → Ollama for AI-assisted response drafting
- Use LanguageTool (FEATURE-046) to polish outgoing messages
- Sentiment analysis on incoming messages via pipeline

## Upstream

| Resource | Link |
|----------|------|
| GitHub | <https://github.com/chatwoot/chatwoot> |
| Self-host docs | <https://www.chatwoot.com/docs/self-hosted/> |
| Docker setup | <https://www.chatwoot.com/docs/self-hosted/deployment/docker> |
| API docs | <https://www.chatwoot.com/developers/api/> |

## Notes

- Requires PostgreSQL and Redis — consider whether these can be shared with other services or need dedicated instances
- Chatwoot has a built-in SDK for website live chat widgets
- Supports Telegram and Signal channels, which already have component scripts in this stack
