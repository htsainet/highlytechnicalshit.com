# Tabby Component — REFERENCES

## Official

- Homepage / docs: <https://tabby.tabbyml.com/>
- GitHub: <https://github.com/TabbyML/tabby>
- Docker deployment: <https://tabby.tabbyml.com/docs/quick-start/installation/docker/>
- Supported models: <https://tabby.tabbyml.com/docs/models/>

## IDE integrations

- VS Code extension: <https://marketplace.visualstudio.com/items?itemName=TabbyML.vscode-tabby>
- JetBrains plugin: <https://plugins.jetbrains.com/plugin/22379-tabby>
- Vim / Neovim: <https://github.com/TabbyML/vim-tabby>

## Related components in this stack

- Ollama: <https://ollama.com> — separate model backend
- Aider: <https://aider.chat> — complementary editing agent
- OpenCode: <https://opencode.ai> — complementary editing agent
- Gitea Runner: <https://gitea.com/gitea/act_runner> — sibling FEATURE-054 tool

## Related features

- FEATURE-054 — Developer Tools Suite (OpenCode, Aider, Tabby, Gitea Runner)

## Vendor-instruction deviations

None. Install follows Tabby's documented Docker deployment
instructions. No entry in `/DEVIATIONS.md` is required.
