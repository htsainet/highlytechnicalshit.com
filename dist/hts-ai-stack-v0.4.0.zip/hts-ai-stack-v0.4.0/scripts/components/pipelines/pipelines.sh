#!/usr/bin/env bash
# scripts/components/pipelines/pipelines.sh — Open WebUI Pipelines plugin framework
#
# Standalone usage:
#   ./scripts/components/pipelines/pipelines.sh              # full: install + configure + start + health
#   ./scripts/components/pipelines/pipelines.sh --install    # install only
#   ./scripts/components/pipelines/pipelines.sh --configure  # configure only
#   ./scripts/components/pipelines/pipelines.sh --start      # start only
#   ./scripts/components/pipelines/pipelines.sh --stop       # stop
#   ./scripts/components/pipelines/pipelines.sh --restart    # restart (stop + start)
#   ./scripts/components/pipelines/pipelines.sh --health     # health check only
#   ./scripts/components/pipelines/pipelines.sh --status     # show status + port + health
#   ./scripts/components/pipelines/pipelines.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

load_env
PIPELINES_PORT="${PIPELINES_PORT:-9099}"
PIPELINES_CONTAINER="${PIPELINES_CONTAINER:-hts-ai-pipelines-1}"

# ── Lifecycle functions ───────────────────────────────────────────────────────

pipelines_install() {
  step "Pipelines — install"
  compose_build --profile pipelines
  ok "Pipelines image built."
}

pipelines_configure() {
  step "Pipelines — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^PIPELINES_PORT=" "$env_file" 2>/dev/null; then
    printf 'PIPELINES_PORT=%s\n' "$PIPELINES_PORT" >> "$env_file"
    info "Added PIPELINES_PORT=${PIPELINES_PORT} to .env"
  fi

  ok "Pipelines configured (port ${PIPELINES_PORT})."
}

pipelines_start() {
  step "Pipelines — start"
  compose_up --profile pipelines
  ok "Pipelines started on port ${PIPELINES_PORT}."
}

pipelines_stop() {
  step "Pipelines — stop"
  compose_down --profile pipelines
  ok "Pipelines stopped."
}

pipelines_health() {
  health_probe "Pipelines :${PIPELINES_PORT}" "http://localhost:${PIPELINES_PORT}/v1" 60
}

pipelines_restart() {
  pipelines_stop
  pipelines_start
}

pipelines_destroy() {
  step "Pipelines — destroy"
  compose_down --profile pipelines -v
  ok "Pipelines destroyed."
}

pipelines_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=pipelines" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Pipelines is running (port ${PIPELINES_PORT})"
  else
    warn "Pipelines is not running."
  fi
  pipelines_health 2>/dev/null || true
}

# ── Standalone execution ──────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   pipelines_install   ;;
    configure) pipelines_configure ;;
    start)     pipelines_start     ;;
    stop)      pipelines_stop      ;;
    restart)   pipelines_restart   ;;
    health)    pipelines_health    ;;
    status)    pipelines_status    ;;
    destroy)   pipelines_destroy   ;;
    default)
      pipelines_install
      pipelines_configure
      pipelines_start
      pipelines_health
      ;;
  esac
fi
