# NemoClaw + OpenClaw → llama-swap wiring guide
# ============================================================
# With the dual-backend architecture, llama-swap handles all
# routing between Ollama (GPU) and BitNet (CPU). The NemoClaw
# GPU sandbox uses a single provider pointing at llama-swap.
#
# NOTE: The CPU sandbox (hts-ai-assistant-cpu) has been removed.
# The gateway's `openshell inference set --model` forces ALL
# sandboxes to the same model, making per-sandbox model routing
# impossible. Alternative sandbox technologies (gVisor, Daytona)
# are being evaluated — see FEATURE-012 and FEATURE-013.
# ============================================================

# ARCHITECTURE
# ────────────
#                               ┌──→ hts-ai-ollama-gpu  (GPU, port 11434)
# hts-ai-llama-swap:8080 ──────┤
#                               └──→ hts-ai-bitnet-cpu  (CPU, internal)
#
# NemoClaw Gateway (hts-ai-nemoclaw) ──→ llama-swap:8080
#   └── hts-ai-openshell-nemoclaw-gpu: model = "gemma4:e4b" → routed to Ollama


# 1. VERIFY LLAMA-SWAP IS RUNNING
# ────────────────────────────────
curl -sf http://localhost:8080/health && echo "llama-swap OK"

# Check available models (shows both Ollama and BitNet models):
curl -s http://localhost:8080/v1/models | jq '.data[].id'


# 2. REGISTER LLAMA-SWAP AS AN OPENSHELL PROVIDER
# ──────────────────────────────────────────────────
# Run on the HOST (not inside the sandbox).
# host.openshell.internal resolves to the host from inside the sandbox.

openshell provider create \
  --name  llama-swap-local \
  --type  openai \
  --credential OPENAI_API_KEY=not-needed \
  --config baseUrl=http://host.openshell.internal:8080/v1

# Verify:
openshell provider list


# 3. SET INFERENCE FOR GPU SANDBOX
# ─────────────────────────────────
# GPU sandbox → uses gemma4:e4b (routed to Ollama GPU by llama-swap)
nemoclaw hts-ai-openshell-nemoclaw-gpu connect -- \
  openclaw config set agents.defaults.model.primary "llama-swap-local/gemma4:e4b"


# 4. UFW RULES (only if UFW is enabled)
# ──────────────────────────────────────
# Allow OpenShell sandbox to reach llama-swap on port 8080:
sudo ufw allow proto tcp from 172.18.0.0/16 to any port 8080 comment 'OpenShell → llama-swap'
sudo ufw allow proto tcp from 172.17.0.0/16 to any port 8080 comment 'Docker bridge → llama-swap'


# 5. NETWORK POLICY UPDATE
# ─────────────────────────
# NemoClaw's sandbox denies all unlisted egress by default.
# Add this to nemoclaw-blueprint/policies/openclaw-sandbox.yaml
# under the `endpoints:` key, then run:
#   openshell policy set --policy openclaw-sandbox.yaml <sandbox-name>
#
#   - name: llama-swap
#     host: host.openshell.internal
#     port: 8080
#     protocol: rest
#     enforcement: enforce
#     rules:
#       - allow: { method: "*", path: "/v1/**" }
#     binaries:
#       - { path: /usr/local/bin/openclaw }
#
# Or apply it dynamically (session-only, resets on restart):
openshell policy set --policy openclaw-sandbox.yaml <your-sandbox-name> --wait


# 5. CONFIGURE OPENCLAW INSIDE THE SANDBOX
# ──────────────────────────────────────────
# Connect to the sandbox and set the model:
nemoclaw <your-sandbox-name> connect

# Inside the sandbox shell:
openclaw config set models.providers.bitnet-local.apiKey "not-needed"
openclaw config set agents.defaults.model.primary "bitnet-local/bitnet"

# Test it:
openclaw agent --agent main --local \
  -m "Are you running on BitNet?" \
  --session-id test


# 6. SWITCHING BACK TO OLLAMA
# ────────────────────────────
# If you ever want to revert to your previous Ollama provider:
openshell inference set --provider ollama-local --model '<your-ollama-model>'
