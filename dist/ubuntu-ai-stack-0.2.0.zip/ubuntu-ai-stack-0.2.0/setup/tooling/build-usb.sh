#!/usr/bin/env bash
# build-usb.sh — Build a self-contained Ubuntu 24.04 autoinstall USB
#
# Downloads Ubuntu 24.04 Server ISO, injects autoinstall config,
# patches GRUB to boot unattended, and writes to a USB drive.
#
# Usage:
#   ./build-usb.sh                  # prompts for USB device
#   ./build-usb.sh /dev/sdX         # specify device directly
#
# Requirements: xorriso, wget, 7zip or p7zip-full

set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; exit 1; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

ISO_URL="https://releases.ubuntu.com/24.04.2/ubuntu-24.04.2-live-server-amd64.iso"
ISO_FILE="ubuntu-24.04.2-live-server-amd64.iso"
ISO_SHA256="d6dab0c3a657988501b4bd76f1297c053df710e06e0c3aece60dead24f270b4d"
WORK_DIR="/tmp/ubuntu-ai-stack-usb"
OUTPUT_ISO="ubuntu-ai-stack.iso"

# ── Step 1: Check tools ───────────────────────────────────────────────────────
step "1 — Check tools"

for tool in xorriso wget sha256sum; do
  if ! command -v "$tool" &>/dev/null; then
    fail "$tool not found. Install with: sudo apt install -y xorriso wget"
  fi
  info "$tool: ok"
done

# ── Step 2: Download ISO ──────────────────────────────────────────────────────
step "2 — Download ISO"

if [ -f "$ISO_FILE" ]; then
  info "ISO already downloaded — verifying checksum..."
else
  info "Downloading Ubuntu 24.04.2 Server ISO (~2.7 GB)..."
  wget -c --show-progress "$ISO_URL" -O "$ISO_FILE"
fi

info "Verifying checksum..."
echo "${ISO_SHA256}  ${ISO_FILE}" | sha256sum --check \
  || fail "Checksum mismatch — re-download: rm $ISO_FILE && ./build-usb.sh"
info "Checksum OK."

# ── Step 3: Extract ISO ───────────────────────────────────────────────────────
step "3 — Extract ISO"

rm -rf "$WORK_DIR"
mkdir -p "$WORK_DIR"

info "Extracting ISO contents..."
xorriso -osirrox on \
  -indev "$ISO_FILE" \
  -extract / "$WORK_DIR" </dev/null &>/dev/null
chmod -R u+w "$WORK_DIR"
info "Extracted to $WORK_DIR"

# ── Step 4: Inject autoinstall files ─────────────────────────────────────────
step "4 — Inject autoinstall files"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[ -f "$SCRIPT_DIR/autoinstall.yaml" ] \
  || fail "autoinstall.yaml not found in $SCRIPT_DIR"

grep -v '^\s*#' "$SCRIPT_DIR/autoinstall.yaml" | grep -Eq "REPLACE_WITH_YOUR_PAT|REPLACE_WITH_BOOTSTRAP_AUTH" \
  && fail "autoinstall.yaml still has an unattended bootstrap auth placeholder — replace it before building the USB."

cp "$SCRIPT_DIR/autoinstall.yaml" "$WORK_DIR/user-data"
touch "$WORK_DIR/meta-data"
touch "$WORK_DIR/vendor-data"

info "Injected: user-data, meta-data, vendor-data"

# ── Step 5: Patch GRUB ────────────────────────────────────────────────────────
step "5 — Patch GRUB"

GRUB_CFG="$WORK_DIR/boot/grub/grub.cfg"
[ -f "$GRUB_CFG" ] || fail "GRUB config not found at $GRUB_CFG"

# Prepend an autoinstall entry that boots immediately
cat > /tmp/autoinstall-grub-entry.cfg << 'EOF'
# ── Autoinstall entry (added by build-usb.sh) ─────────────────────────────
set default="autoinstall"
set timeout=5

menuentry "Ubuntu AI Stack — Autoinstall" --id autoinstall {
    set gfxpayload=keep
    linux   /casper/vmlinuz quiet autoinstall ds=nocloud\;s=/cdrom/ ---
    initrd  /casper/initrd
}

# ── Original entries below ─────────────────────────────────────────────────
EOF

# Remove any existing default/timeout lines from original cfg, then append
grep -v '^\s*set default\|^\s*set timeout' "$GRUB_CFG" >> /tmp/autoinstall-grub-entry.cfg
cp /tmp/autoinstall-grub-entry.cfg "$GRUB_CFG"

info "GRUB patched — autoinstall boots in 5 seconds (existing entries preserved)."

# Also patch GRUB EFI config if present
EFI_GRUB="$WORK_DIR/EFI/boot/grub.cfg"
if [ -f "$EFI_GRUB" ]; then
  cp /tmp/autoinstall-grub-entry.cfg "$EFI_GRUB"
  info "EFI GRUB also patched."
fi

# ── Step 6: Extract boot sectors from original ISO ────────────────────────────
step "6 — Extract boot sectors"

info "Extracting MBR from original ISO..."
dd if="$ISO_FILE" bs=1 count=432 of=/tmp/ubuntu-mbr.img 2>/dev/null

info "Extracting EFI partition from original ISO..."
EFIPART_START=$(fdisk -l "$ISO_FILE" 2>/dev/null | awk '/EFI/{print $2}')
EFIPART_SIZE=$(fdisk -l  "$ISO_FILE" 2>/dev/null | awk '/EFI/{print $4}')
dd if="$ISO_FILE" bs=512 skip="$EFIPART_START" count="$EFIPART_SIZE" \
   of=/tmp/ubuntu-efi.img 2>/dev/null

info "Boot sectors extracted."

# ── Step 7: Repack ISO ────────────────────────────────────────────────────────
step "7 — Repack ISO"

rm -f "$OUTPUT_ISO"

info "Building $OUTPUT_ISO..."
xorriso -as mkisofs \
  --grub2-mbr /tmp/ubuntu-mbr.img \
  --protective-msdos-label \
  -partition_cyl_align off \
  -partition_offset 16 \
  -partition_hd_cyl 255 \
  -partition_sec_hd 63 \
  -append_partition 2 0xef /tmp/ubuntu-efi.img \
  -iso_mbr_part_type 0x00 \
  -c '/boot.catalog' \
  -b '/boot/grub/i386-pc/eltorito.img' \
  -no-emul-boot \
  -boot-load-size 4 \
  -boot-info-table \
  --grub2-boot-info \
  -eltorito-alt-boot \
  -e '--interval:appended_partition_2:::' \
  -no-emul-boot \
  -V "Ubuntu-AI-Stack" \
  -r \
  -o "$OUTPUT_ISO" \
  "$WORK_DIR" 2>/dev/null

info "ISO built: $OUTPUT_ISO ($(du -sh "$OUTPUT_ISO" | cut -f1))"

# ── Step 8: Write to USB ──────────────────────────────────────────────────────
step "8 — Write to USB"

USB_DEV="${1:-}"

if [ -z "$USB_DEV" ]; then
  echo ""
  info "Available disks:"
  lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS | grep -v loop
  echo ""
  read -r -p "  Enter USB device (e.g. /dev/sdb): " USB_DEV < /dev/tty
fi

[ -b "$USB_DEV" ] || fail "$USB_DEV is not a block device."

# Safety check — refuse to write to a mounted system disk
if mount | grep -q "^$USB_DEV.* on / "; then
  fail "$USB_DEV appears to be a system disk. Aborting."
fi

echo ""
warn "About to write $OUTPUT_ISO to $USB_DEV — ALL DATA ON $USB_DEV WILL BE LOST."
read -r -p "  Type 'yes' to confirm: " confirm < /dev/tty
[ "$confirm" = "yes" ] || fail "Aborted."

# Unmount any partitions on the device
for part in "${USB_DEV}"?*; do
  if mount | grep -q "^$part"; then
    info "Unmounting $part..."
    sudo umount "$part" || true
  fi
done

info "Writing ISO to $USB_DEV..."
sudo dd if="$OUTPUT_ISO" of="$USB_DEV" bs=4M status=progress oflag=sync
sudo sync

echo ""
info "Done. USB is ready."
info "Boot the new machine from this USB — install runs unattended."
info "After first boot, SSH in and run: ./02-setup-docker.sh"
