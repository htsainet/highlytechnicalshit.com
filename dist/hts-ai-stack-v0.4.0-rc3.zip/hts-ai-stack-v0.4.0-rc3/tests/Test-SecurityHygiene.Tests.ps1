$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:SecurityFeaturesDir = Join-Path $script:RepoRoot 'docs/security-review/features'
}

Describe 'Security feature hygiene' {

    BeforeAll {
        # Collect shipped git tags (semver-style v* tags)
        $script:ShippedTags = @()
        try {
            $script:ShippedTags = git -C $script:RepoRoot tag --list 'v*' |
                ForEach-Object { $_.Trim() } |
                Where-Object { $_ -match '^v\d+\.\d+\.\d+$' }
        } catch {
            # git unavailable or not a repo — tests will pass vacuously
        }

        # Scan SECURITY-###.md files for stale Target Release fields
        $script:StaleFeatures = [System.Collections.Generic.List[string]]::new()

        # Scan SECURITY-###.md files missing the required Threat field
        $script:MissingThreat = [System.Collections.Generic.List[string]]::new()

        $securityFiles = Get-ChildItem -Path $script:SecurityFeaturesDir -Filter 'SECURITY-*.md' -ErrorAction SilentlyContinue

        foreach ($file in $securityFiles) {
            $content = Get-Content $file.FullName -Raw

            # Check for stale Target Release (targeting an already-shipped git tag)
            if ($content -match '\*?\*?Target Release\*?\*?:\s*.*?(v\d+\.\d+\.\d+)') {
                $targetVersion = $Matches[1]
                if ($script:ShippedTags -contains $targetVersion) {
                    $script:StaleFeatures.Add("$($file.Name) targets $targetVersion which is already shipped")
                }
            }

            # Check for required Threat field
            if ($content -notmatch '\*?\*?Threat\*?\*?:') {
                $script:MissingThreat.Add($file.Name)
            }
        }
    }

    It 'security features directory exists' {
        $script:SecurityFeaturesDir | Should -Exist
    }

    It 'security features directory has a CONTEXT.md' {
        Join-Path $script:SecurityFeaturesDir 'CONTEXT.md' | Should -Exist
    }

    It 'security features directory has a REFERENCES.md' {
        Join-Path $script:SecurityFeaturesDir 'REFERENCES.md' | Should -Exist
    }

    It 'no SECURITY file targets an already-shipped git tag' {
        if ($script:StaleFeatures.Count -gt 0) {
            $detail = $script:StaleFeatures -join "`n  "
            "Stale security features:`n  $detail" |
                Should -Be '' -Because 'security features must not target a release that has already shipped — update Target Release or archive the feature'
        }
    }

    It 'every SECURITY file has a Threat field' {
        if ($script:MissingThreat.Count -gt 0) {
            $detail = $script:MissingThreat -join "`n  "
            "Missing Threat field:`n  $detail" |
                Should -Be '' -Because 'every SECURITY-###.md must map to a threat from the threat model in docs/security-review/CONTEXT.md'
        }
    }
}
