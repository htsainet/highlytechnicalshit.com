#!/usr/bin/env bash
# Downgrade host openshell CLI from 0.0.32 -> 0.0.26.
#
# IMPORTANT: NemoClaw v0.0.23's blueprint.yaml pins min=max=0.0.32. If that
# NemoClaw is still installed, `nemoclaw onboard` will reject 0.0.26 or
# reinstall 0.0.32. Roll NemoClaw back separately (or edit the blueprint)
# BEFORE relying on this downgrade.
#
# Usage:
#   bash downgrade-openshell-to-0.0.26.sh
#
# Safe to re-run: idempotent. Requires sudo.

set -euo pipefail

TARGET_VER="0.0.26"
BIN="/usr/local/bin/openshell"

say() { printf '\n\033[1;36m[openshell-downgrade]\033[0m %s\n' "$*"; }

# 1. Stop consumers so the binary isn't in use
say "Stopping NemoClaw sandboxes and gateway (ignore errors if not running)"
nemoclaw hts-ai-openshell-nemoclaw      stop 2>/dev/null || true
openshell gateway stop                        2>/dev/null || true

# 2. Show current version and remove
if command -v openshell >/dev/null 2>&1; then
  CURRENT=$(openshell --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
  say "Current openshell: v${CURRENT} -> removing ${BIN}"
  sudo rm -f "$BIN"
else
  say "openshell not on PATH — skipping removal"
fi

if command -v openshell >/dev/null 2>&1; then
  echo "ERROR: openshell still on PATH at $(command -v openshell) — remove manually and re-run" >&2
  exit 1
fi

# 3. Download + install 0.0.26 from NVIDIA GitHub releases
ARCH=$(uname -m)
TARBALL="openshell-${ARCH}-unknown-linux-musl.tar.gz"
URL="https://github.com/NVIDIA/OpenShell/releases/download/v${TARGET_VER}/${TARBALL}"
TMP=$(mktemp -d /tmp/openshell-dg.XXXXXX)
trap 'rm -rf "$TMP"' EXIT

say "Downloading ${URL}"
curl -fsSL "$URL" -o "${TMP}/${TARBALL}"

say "Extracting and installing to ${BIN}"
tar xzf "${TMP}/${TARBALL}" -C "$TMP"
sudo install -m 755 "${TMP}/openshell" "$BIN"

# 4. Verify
INSTALLED=$(openshell --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
if [[ "$INSTALLED" == "$TARGET_VER" ]]; then
  say "SUCCESS: openshell --version = ${INSTALLED}"
else
  echo "ERROR: expected v${TARGET_VER}, got v${INSTALLED:-<none>}" >&2
  exit 1
fi

say "Done. Next: update repo pins (run update-repo-pins-to-0.0.26.sh) and"
say "      confirm NemoClaw blueprint allows 0.0.26 before 'nemoclaw onboard'."
