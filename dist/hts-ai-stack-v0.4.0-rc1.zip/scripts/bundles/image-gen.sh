#!/usr/bin/env bash
# scripts/bundles/image-gen.sh — Image generation bundle
#
# Sets up host GPU dependencies, Stable Diffusion, and ComfyUI.
#
# Usage:
#   ./scripts/bundles/image-gen.sh
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "Image Generation Bundle"
load_env

# ── Host ──────────────────────────────────────────────────────────────────────
step "Host dependencies"
bash "$REPO_DIR/scripts/host/docker.sh"
bash "$REPO_DIR/scripts/host/nvidia.sh"

# ── Services ──────────────────────────────────────────────────────────────────
step "Image generation services"
bash "$REPO_DIR/scripts/components/stable-diffusion.sh"
bash "$REPO_DIR/scripts/components/comfyui.sh"

echo ""
ok "Image generation bundle ready."
