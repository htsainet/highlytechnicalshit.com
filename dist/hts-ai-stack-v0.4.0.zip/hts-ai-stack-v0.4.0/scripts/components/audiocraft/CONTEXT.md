# AudioCraft / MusicGen Component

Last updated: 2026-04-21 (rev 2)

## What happens here

AudioCraft is Meta's AI audio generation framework. The primary model,
MusicGen, generates music from text descriptions using GPU-accelerated
inference. Runs as a Dockerised Gradio web app on port 8602.

## Files and structure

| File | Purpose |
|------|---------|
| `audiocraft.sh` | Full lifecycle: install, configure, start, stop, health |
| `audiocraft.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Notes

- Runs in Docker with NVIDIA GPU passthrough (CUDA)
- Default model: `facebook/musicgen-small` (300M params, ~1.2 GB)
- Upgradeable to `musicgen-medium` (1.5B) or `musicgen-large` (3.3B)
- Models auto-download from HuggingFace on first start
- Gradio web UI for interactive text-to-music generation
- Supports melody conditioning (hum/upload a melody + text prompt)

## PyAV build dependency (important)

`audiocraft` pins `av==11.0.0` (PyAV), which **builds from source** during
`docker build`. The source build requires `pkg-config` to locate several
`libav*` libraries. The Dockerfile originally had most of them but was missing
two that PyAV 11+ needs:

| Library | Provides |
|---------|---------|
| `libavdevice-dev` | `libavdevice` — device I/O support |
| `libavfilter-dev` | `libavfilter` — audio/video filter graph |

Without both, the wheel build fails with:

```text
No package libavdevice found
```

Fix committed 2026-04-21 (`236de79`): added `libavdevice-dev` and
`libavfilter-dev` to the `apt-get install` block in
`docker/audiocraft/Dockerfile`.

See [usage.md](./usage.md) for command usage.
