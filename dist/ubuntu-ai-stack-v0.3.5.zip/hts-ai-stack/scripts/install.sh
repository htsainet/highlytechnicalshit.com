#!/usr/bin/env bash
# install.sh — AI Stack installer / re-installer
#
# Flow:
#   1. Resolve repo dir
#   2. Back up config/stack.json + .env to config/backups/YYYYMMDD-HHMMSS/
#   3. If no config/stack.json: run setup menu (required first time)
#      If config exists: ask whether to reconfigure or use existing
#   4. Apply config/stack.json to .env via apply_config.sh
#   5. Run pipeline scripts: 01-autoinstall (host setup + NVIDIA drivers)
#      → 02-setup-docker → 04-setup-nemoclaw → 06-start-stack → 07-setup-connectivity
#
# Flags:
#   --reconfigure      Always run setup menu even if config exists
#   --skip-config      Skip menu and apply step; use existing .env as-is
#   --dry-run          Print actions without executing install scripts
#   --force-install    Skip conflict-detection prompts (continue despite port conflicts)
#   -h, --help         Show this help
#
# Post-reinstall recovery (NAS / nuke-and-pave):
#   git clone <repo> && cd hts-ai-stack
#   ./install.sh --skip-config
#   → restores /etc/fstab NFS mounts, /etc/idmapd.conf, and stack from
#     config/stack.json without re-running the setup wizard.
#   Prerequisite: DHCP reservation set on router so machine keeps same IP
#   (Synology NFS allowlist is IP-specific — different IP = access denied).

set -euo pipefail

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
RED='\033[0;31m'; BOLD='\033[1m'; NC='\033[0m'

# LOG_FILE is set after REPO_DIR is resolved (see below); functions reference it by name.
_log()   { echo "[$(date '+%F %T')] [$1] $2" >> "${LOG_FILE:-/dev/null}" 2>/dev/null || true; }
info()   { echo -e "${GREEN}[INFO]${NC} $*"; _log INFO "$*"; }
warn()   { echo -e "${YELLOW}[WARN]${NC} $*"; _log WARN "$*"; }
fail()   { echo -e "${RED}[FAIL]${NC} $*"; [[ -n "${LOG_FILE:-}" ]] && echo -e "${RED}[FAIL]${NC} See log: $LOG_FILE"; _log FAIL "$*"; exit 1; }
step()   { echo -e "\n${CYAN}${BOLD}══ $* ══${NC}"; _log STEP "══ $* ══"; }
banner() {
  echo -e "\n${CYAN}${BOLD}╔══════════════════════════════════════════════════════╗${NC}"
  echo -e "${CYAN}${BOLD}║        AI STACK — INSTALLER                         ║${NC}"
  echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════╝${NC}\n"
  _log INFO "=== AI STACK INSTALLER STARTED ==="
}

# Detect if the repo is still checked out with the old directory name and offer to rename it.
_check_repo_dir_name() {
  [[ "$(basename "$REPO_DIR")" == "ubuntu-ai-stack" ]] || return 0
  local parent new_dir
  parent="$(dirname "$REPO_DIR")"
  new_dir="$parent/hts-ai-stack"
  echo -e "\n${YELLOW}[WARN]${NC} This repo is checked out as ${BOLD}ubuntu-ai-stack${NC} (old name)."
  echo -e "       The project has been renamed to ${BOLD}hts-ai-stack${NC}."
  echo -e "       Proposed new path: ${BOLD}${new_dir}${NC}\n"
  if [[ -d "$new_dir" ]]; then
    warn "Cannot rename: $new_dir already exists. Continuing with old directory name."
    return 0
  fi
  printf "Rename directory now? [Y/n] "
  local ans; IFS= read -r ans; ans="${ans:-Y}"
  if [[ "$ans" =~ ^[Yy] ]]; then
    mv "$REPO_DIR" "$new_dir"
    REPO_DIR="$new_dir"
    info "Directory renamed → $REPO_DIR"
    warn "Reminder: update your VS Code workspace, shell bookmarks, and git remote URL."
    warn "  git remote set-url origin https://github.com/htsainet/hts-ai-stack.git"
  else
    info "Skipped rename — continuing from existing path."
  fi
}

# ── Flags ─────────────────────────────────────────────────────────────────────
RECONFIGURE=false
SKIP_CONFIG=false
DRY_RUN=false
export HTSAI_FORCE_INSTALL=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --reconfigure)    RECONFIGURE=true;           shift ;;
    --skip-config)    SKIP_CONFIG=true;            shift ;;
    --dry-run)        DRY_RUN=true;               shift ;;
    --force-install)  HTSAI_FORCE_INSTALL=true;   shift ;;
    -h|--help)        grep '^#' "$0" | sed 's/^# \?//'; exit 0 ;;
    *) fail "Unknown option: $1" ;;
  esac
done

# ── Locate repo ───────────────────────────────────────────────────────────────
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_CONFIG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/hts-ai-stack"
if [ -f "$REPO_CONFIG_DIR/clone-path" ]; then
  REPO_DIR=$(cat "$REPO_CONFIG_DIR/clone-path")
fi
[ -d "$REPO_DIR" ] || fail "Repo directory not found: $REPO_DIR"
_check_repo_dir_name

# ── Logging ───────────────────────────────────────────────────────────────────
_LOG_STAMP="$(date +%Y%m%d-%H%M%S)"
LOG_FILE="/var/log/ai-stack/install-${_LOG_STAMP}.log"
if ! mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null; then
  LOG_FILE="$REPO_DIR/logs/install-${_LOG_STAMP}.log"
  mkdir -p "$(dirname "$LOG_FILE")"
fi
echo "Logging to: $LOG_FILE"
trap '_log ERROR "Unexpected failure at line $LINENO (exit $?)"' ERR

CONFIG_DIR="$REPO_DIR/config"
BACKUP_BASE="$CONFIG_DIR/backups"
STACK_JSON="$CONFIG_DIR/stack.json"
ENV_FILE="$REPO_DIR/.env"
SETUP_MENU="$REPO_DIR/config/wizard/ai_stack_setup.sh"
APPLY_SCRIPT="$REPO_DIR/config/wizard/apply_config.sh"

# ── Helpers ───────────────────────────────────────────────────────────────────
ensure_env_var_set() {
  local key="$1"
  if [ ! -f "$ENV_FILE" ]; then
    fail ".env is missing. Run ./01-autoinstall.sh first."
  fi
  if ! grep -Eq "^${key}=[^[:space:]].*" "$ENV_FILE"; then
    fail "${key} is missing or empty in .env. Run ./01-autoinstall.sh to repair tokens."
  fi
}

run_script() {
  local script="$1"
  [ -f "$script" ] || fail "Missing: $script"
  if "$DRY_RUN"; then
    info "[dry-run] would run: $script"
    return
  fi
  step "Running: $(basename "$script")"
  _log INFO "--- BEGIN: $script ---"
  if bash "$script" 2>&1 | tee -a "$LOG_FILE"; then
    _log INFO "--- END (success): $script ---"
    info "Completed: $(basename "$script")"
  else
    local rc=$?
    _log FAIL "--- END (exit $rc): $script ---"
    if [ "$rc" -gt 128 ]; then
      fail "Script killed by signal $((rc - 128)): $script (exit $rc)"
    else
      fail "Script failed (exit $rc): $script"
    fi
  fi
}

run_reset_stack() {
  local reset_script=""
  # Canonical entrypoint is reset-stack.sh.
  # Fall back to the internal script if the root launcher is missing.
  if [ -x "$REPO_DIR/reset-stack.sh" ]; then
    reset_script="$REPO_DIR/reset-stack.sh"
  elif [ -x "$REPO_DIR/scripts/utils/nuke-stack.sh" ]; then
    reset_script="$REPO_DIR/scripts/utils/nuke-stack.sh"
  else
    fail "No reset script found (expected reset-stack.sh)."
  fi

  warn "Reset stack selected — this is destructive and will prompt for confirmation."
  if "$reset_script"; then
    info "Reset stack completed."
  else
    fail "Reset stack failed."
  fi
}

# ── Main ──────────────────────────────────────────────────────────────────────
banner

# ── Step 1: Backup existing config ────────────────────────────────────────────
step "Config backup"

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p "$BACKUP_BASE"

if [ -f "$STACK_JSON" ]; then
  BACKUP_SLOT="$BACKUP_BASE/$TIMESTAMP"
  mkdir -p "$BACKUP_SLOT"
  cp "$STACK_JSON" "$BACKUP_SLOT/stack.json"
  info "stack.json backed up → config/backups/$TIMESTAMP/"
  # .env backup (gitignored per config/.gitignore)
  if [ -f "$ENV_FILE" ]; then
    cp "$ENV_FILE" "$BACKUP_SLOT/.env.bak"
    info ".env backed up      → config/backups/$TIMESTAMP/.env.bak"
  fi
else
  info "No existing config/stack.json — first-time install"
fi

# ── Step 2: Configure ─────────────────────────────────────────────────────────
if ! "$SKIP_CONFIG"; then
  step "Configuration"

  RUN_MENU=false

  if [ ! -f "$STACK_JSON" ]; then
    info "No config found — launching setup menu (required)"
    RUN_MENU=true
  elif "$RECONFIGURE"; then
    info "--reconfigure flag set — launching setup menu"
    RUN_MENU=true
  else
    warn "Existing config found: config/stack.json"
    warn "  Last saved: $(python3 -c "import json; d=json.load(open('$STACK_JSON')); print(d.get('_meta',{}).get('saved_at','(default — never customised)'))" 2>/dev/null || echo '(unreadable)')"
    echo ""
    while true; do
      read -rp "  [c] Reconfigure  [s] Skip (use existing)  [r] Reset stack  [q] Quit  → " choice
      case "${choice,,}" in
        c) RUN_MENU=true; break ;;
        s) info "Using existing config"; break ;;
        r) run_reset_stack ;;
        q) echo "Aborted."; exit 0 ;;
        *) warn "Invalid choice — enter c, s, r, or q" ;;
      esac
    done
  fi

  if "$RUN_MENU"; then
    [ -f "$SETUP_MENU" ] || fail "Setup menu not found: $SETUP_MENU"
    # Clean up any stale .venv left by old Python-based approach
    VENV_DIR="$(dirname "$SETUP_MENU")/.venv"
    [ -d "$VENV_DIR" ] && rm -rf "$VENV_DIR" && info "Removed stale .venv"
    # Pre-scan for existing services so the wizard can pre-fill sensible defaults
    if [ -f "$REPO_DIR/scripts/install/00-check-conflicts.sh" ]; then
      bash "$REPO_DIR/scripts/install/00-check-conflicts.sh" --detect-only 2>/dev/null || true
    fi
    bash "$SETUP_MENU"
  fi

  # ── Step 3: Apply config → .env ───────────────────────────────────────────
  if [ -f "$STACK_JSON" ]; then
    step "Apply config/stack.json → .env"
    [ -x "$APPLY_SCRIPT" ] || fail "apply_config.sh not found or not executable: $APPLY_SCRIPT"
    if "$DRY_RUN"; then
      info "[dry-run] would run: apply_config.sh $STACK_JSON"
    else
      "$APPLY_SCRIPT" "$STACK_JSON" --env-file "$ENV_FILE"
    fi
  else
    fail "config/stack.json still missing after setup. Cannot continue."
  fi
fi

# ── Step 4: Run install scripts ───────────────────────────────────────────────
step "Sequential Installation"
info "conflicts → autoinstall → docker → models → nemoclaw → setup → connectivity"

run_script "$REPO_DIR/scripts/install/00-check-conflicts.sh"
run_script "$REPO_DIR/scripts/install/01-autoinstall.sh"

# ── Step 5: Preflight .env ────────────────────────────────────────────────────
# 01-autoinstall is the source of truth for creating/repairing secure tokens.
step "Preflight — validate .env"
ensure_env_var_set "WEBUI_SECRET_KEY"
ensure_env_var_set "OPENCLAW_TOKEN"
info ".env tokens present"

# Continue remaining install pipeline
run_script "$REPO_DIR/scripts/install/02-setup-docker.sh"
run_script "$REPO_DIR/scripts/install/03-setup-models.sh"
run_script "$REPO_DIR/scripts/install/04-setup-nemoclaw.sh"
run_script "$REPO_DIR/scripts/install/06-start-stack.sh"
run_script "$REPO_DIR/scripts/install/07-setup-connectivity.sh"

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
info "All installation steps completed successfully!"
_log INFO "=== AI STACK INSTALLER COMPLETE ==="
echo ""
step "What's Next?"
info "Your AI stack is now deployed. Here are your next steps:"
echo ""
echo "  1. View the dashboard:"
echo "     → http://localhost:80"
echo ""
echo "  2. Reconfigure at any time:"
echo "     → ./install.sh --reconfigure"
echo ""
echo "  3. Review config history:"
echo "     → ls config/backups/"
echo ""
echo "  4. Verify the stack:"
echo "     → $REPO_DIR/scripts/utils/verify.sh"
echo ""
echo "  5. Stop the stack:"
echo "     → $REPO_DIR/scripts/utils/teardown.sh"
echo ""
echo "  For more info, see: $REPO_DIR/README.md"
echo ""
