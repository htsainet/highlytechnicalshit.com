#!/usr/bin/env bash
# install-lmstudio.sh — Install LM Studio and pull default models
#
# Idempotent: skips deb install if lmstudio package is already installed.
# Model pulls via `lms get` are idempotent by design.

set -euo pipefail

LMS_VERSION="0.4.7-4"
LMS_DEB="LM-Studio-${LMS_VERSION}-x64.deb"
LMS_URL="https://installers.lmstudio.ai/linux/x64/${LMS_VERSION}/${LMS_DEB}"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC} $* — already installed"; }
step() { echo -e "\n${GREEN}══ $* ══${NC}"; }

# ── Step 1: Install LM Studio ─────────────────────────────────────────────────
step "1 — Install LM Studio ${LMS_VERSION}"

if dpkg -s lmstudio &>/dev/null 2>&1; then
  skip "LM Studio ($(dpkg-query -W -f='${Version}' lmstudio 2>/dev/null))"
else
  info "Downloading LM Studio ${LMS_VERSION}..."
  wget -q --show-progress -O "/tmp/${LMS_DEB}" "$LMS_URL"

  info "Installing..."
  sudo dpkg -i "/tmp/${LMS_DEB}"
  sudo apt-get install -f -y -qq   # fix any missing dependencies
  rm "/tmp/${LMS_DEB}"

  info "LM Studio ${LMS_VERSION} installed."
fi

# ── Step 2: Bootstrap LM Studio CLI ──────────────────────────────────────────
step "2 — Bootstrap lms CLI"

if command -v lms &>/dev/null; then
  skip "lms CLI already on PATH"
else
  info "Running lms bootstrap..."
  ~/.lmstudio/bin/lms bootstrap
  info "lms CLI bootstrapped."
fi

# ── Step 3: Pull models ───────────────────────────────────────────────────────
step "3 — Pull models (lms get — idempotent)"

lms get https://huggingface.co/HauhauCS/Qwen3.5-9B-Uncensored-HauhauCS-Aggressive -y
lms get https://huggingface.co/ThijsL202/Merged_Roleplay_Dominant_Model_TEST-Q5_K_S-GGUF -y
lms get https://huggingface.co/nvidia/NVIDIA-Nemotron-3-Nano-4B-GGUF:Q4_K_M -y
lms get https://huggingface.co/bartowski/nvidia_Nemotron-Cascade-8B-GGUF:QUANT_TAG -y
lms get https://huggingface.co/Jackrong/Qwen3.5-9B-Claude-4.6-Opus-Reasoning-Distilled-v2-GGUF:Q4_K_M -y

info "Models ready."
