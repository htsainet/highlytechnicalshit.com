# NAT PoC Security Notes

Guidelines

- Run all NAT runs inside isolated sandboxes or containers.
- Do not expose secret keys in logs. Use environment variables and secrets store.
- Build SBOM for any downloaded models and audit provenance.

Runtime controls

- Limit network access for evaluation runners.
- Run model inference under unprivileged users where possible.

Further work

- Add CI step that checks for accidental secret leaks in NAT workflows.
