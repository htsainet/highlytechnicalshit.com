# BitNet References

Last updated: 2026-04-15

## Upstream

- [GitHub — microsoft/BitNet](https://github.com/microsoft/BitNet)
- [BitNet paper (arXiv)](https://arxiv.org/abs/2310.11453)

## Official documentation

- [BitNet README](https://github.com/microsoft/BitNet#readme)
