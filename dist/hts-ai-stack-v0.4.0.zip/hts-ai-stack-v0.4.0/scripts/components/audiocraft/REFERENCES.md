# AudioCraft / MusicGen References

Last updated: 2026-04-17

## Upstream

- [GitHub — facebookresearch/audiocraft](https://github.com/facebookresearch/audiocraft)
- [AudioCraft Documentation](https://facebookresearch.github.io/audiocraft/)

## Models (HuggingFace)

- [facebook/musicgen-small](https://huggingface.co/facebook/musicgen-small) — 300M params (~1.2 GB)
- [facebook/musicgen-medium](https://huggingface.co/facebook/musicgen-medium) — 1.5B params (~6 GB)
- [facebook/musicgen-large](https://huggingface.co/facebook/musicgen-large) — 3.3B params (~13 GB)
- [facebook/musicgen-melody](https://huggingface.co/facebook/musicgen-melody) — melody-conditioned variant

## Papers

- [Simple and Controllable Music Generation (arXiv)](https://arxiv.org/abs/2306.05284)
- [High Fidelity Neural Audio Compression (arXiv)](https://arxiv.org/abs/2210.13438)

## API

- Gradio web UI: `http://localhost:8602/`
- Gradio API: `http://localhost:8602/api/`
