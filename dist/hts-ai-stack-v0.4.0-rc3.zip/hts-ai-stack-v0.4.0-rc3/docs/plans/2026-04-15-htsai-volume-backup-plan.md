# HTS-AI-Stack — Docker Volume & Config Backup Plan
# Created: 2026-04-15
# Target NAS share: /mnt/htsai-docker-volume-backup

---

## Overview

The stack has ~32 named Docker volumes. Some contain irreplaceable user state
(chat history, characters, workflows, git repos). Others contain re-downloadable
model weights. The goal is a reliable backup system that copies stateful volumes
and configs to the Synology NAS so a nuke-and-pave can be fully restored.

### What already exists
- `backups/docker/backup-volumes.sh` — pause/tar/resume backup script
  - Already handles stateful vs model volume separation
  - Has `--dry-run`, `--no-pause`, `--dest` flags
  - ⚠️ Currently hardcoded to old path `/mnt/nas/llm-cache/backups/volumes`
  - ⚠️ References deprecated `nas-llm-cache.service`
- `scripts/host/backup-models.sh` — rsyncs model volumes to NAS (created this session)

### What's missing
1. Config backup (stack.json, .env, daemon.json, fstab, nas.env, etc.)
2. Volume restore script (NAS → host after nuke-and-pave)
3. Updated paths in backup-volumes.sh
4. Scheduled/automated backups (cron or systemd timer)
5. Backup verification/listing tool

---

## TASK 1: Fix backup-volumes.sh Paths

### Changes Required
Update `backups/docker/backup-volumes.sh`:

```bash
# Line 9 — comment:
# OLD: "Requires: NAS mounted at /mnt/nas/llm-cache (setup-nas-mount.sh)"
# NEW: "Requires: NAS mounted at /mnt/htsai-docker-volume-backup (scripts/host/nas-setup.sh)"

# Line 16 — help text:
# OLD: "(default: /mnt/nas/llm-cache/backups/volumes)"
# NEW: "(default: /mnt/htsai-docker-volume-backup/volumes)"

# Line 38 — default destination:
# OLD: DEST="/mnt/nas/llm-cache/backups/volumes"
# NEW: DEST="/mnt/htsai-docker-volume-backup/volumes"

# Line 81 — error message:
# OLD: "Check: systemctl status nas-llm-cache.service"
# NEW: "Check: mountpoint -q /mnt/htsai-docker-volume-backup"
```

### Also update the VOLUMES list
The current list only covers a subset. Review against `docker-compose.yml` volumes
section and add any missing stateful volumes. Current compose has these volumes
that contain user state:

**Already in backup list (good):**
- `gitea_data` — git repos, user accounts
- `open_webui_data` — chat history, user accounts, model configs
- `sillytavern_config` — characters, personas, chat logs
- `comfyui_models_test` — custom workflows (test instance)

**Should be added:**
- `sillytavern_data` — main SillyTavern data (not just config)
- `flowise_data` — Flowise workflow definitions
- `n8n_data` — n8n automation workflows
- `langflow_data` — Langflow flow definitions
- `searxng_data` — SearXNG search preferences
- `grafana_data` — Grafana dashboards and data sources
- `portainer_data` — Portainer settings
- `openspace_skills` — OpenSpace skill definitions
- `openspace_config` — OpenSpace configuration
- `deerflow_data` — DeerFlow research data
- `duplicati_config` — Duplicati backup job configs
- `sd_outputs` — generated images (may be large but irreplaceable)
- `comfyui_output` — ComfyUI generated images
- `comfyui_custom_nodes` — installed ComfyUI extensions

**Skip (re-downloadable, handled by backup-models.sh):**
- `ollama_data` — model weights
- `bitnet_models` — model weights
- `sd_models` — SD checkpoints
- `comfyui_models` — ComfyUI model files
- `localai_models` — LocalAI models
- `coqui_tts_models` — TTS models
- `vosk_models` — STT models
- `faster_whisper_cache` — whisper model cache
- `audio_flamingo_cache` — audio model cache

**Skip (ephemeral/regenerable):**
- `prometheus_data` — metrics (regenerated)
- `tailscale_state` — re-authenticates
- `unsloth_workspace` — training scratch space
- `openspace_logs` — logs
- `deerflow_logs` — logs
- `deerflow_home` — re-created
- `duplicati_backups` — this IS the backup destination, don't back it up
- `languagetool_data` — dictionary cache

---

## TASK 2: Create Config Backup Script

### What configs should be backed up?

**Repo-level (inside ~/hts/hts-ai-stack/):**
- `.env` — all *_ENABLED flags, MIRROR, ports, passwords
- `config/stack.json` — central stack configuration
- `config/profiles/*.json` — wizard profile templates (if customized)
- `.last-applied.json` — last wizard output
- `docker-compose.yml` — if user has local overrides
- `docker-compose.override.yml` — if exists (user customizations)

**System-level (outside repo, survives nuke-and-pave on its own):**
- `~/.config/htsai/nas.env` — NAS config (already persists, but good to backup)
- `/etc/docker/daemon.json` — insecure-registries, runtime config
- `/etc/fstab` — NFS mount entries (already backed up by nas.sh)
- `/etc/idmapd.conf` — NFSv4 domain config

**Per-service configs (inside Docker volumes or bind mounts):**
- These are covered by the volume backup in Task 1

### Script: `scripts/host/backup-configs.sh`

```bash
#!/usr/bin/env bash
# scripts/host/backup-configs.sh — Backup stack + system configs to NAS
#
# Creates a timestamped config snapshot on the NAS containing:
#   - Repo config files (.env, stack.json, profiles, compose overrides)
#   - System config files (daemon.json, fstab, idmapd.conf)
#   - NAS config (nas.env)
#
# Usage:  sudo ./scripts/host/backup-configs.sh
#         sudo ./scripts/host/backup-configs.sh --dest /custom/path

set -euo pipefail

DEST="${1:-/mnt/htsai-docker-volume-backup/configs}"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
SNAPSHOT_DIR="$DEST/$TIMESTAMP"

mkdir -p "$SNAPSHOT_DIR/repo" "$SNAPSHOT_DIR/system"

# Repo configs
for f in .env config/stack.json .last-applied.json docker-compose.override.yml; do
  [[ -f "$REPO_DIR/$f" ]] && cp "$REPO_DIR/$f" "$SNAPSHOT_DIR/repo/"
done
cp -r "$REPO_DIR/config/profiles" "$SNAPSHOT_DIR/repo/" 2>/dev/null || true

# System configs
cp /etc/docker/daemon.json "$SNAPSHOT_DIR/system/" 2>/dev/null || true
cp /etc/fstab "$SNAPSHOT_DIR/system/"
cp /etc/idmapd.conf "$SNAPSHOT_DIR/system/" 2>/dev/null || true

# NAS config
_REAL_HOME="${HOME}"
[[ -n "${SUDO_USER:-}" ]] && _REAL_HOME=$(eval echo "~${SUDO_USER}")
cp "${_REAL_HOME}/.config/htsai/nas.env" "$SNAPSHOT_DIR/system/" 2>/dev/null || true

echo "[OK] Config snapshot saved to: $SNAPSHOT_DIR"

# Keep last N snapshots (default 10), prune older ones
MAX_SNAPSHOTS=10
ls -1dt "$DEST"/*/ 2>/dev/null | tail -n +$((MAX_SNAPSHOTS + 1)) | xargs rm -rf 2>/dev/null || true
```

### NAS layout for config backups:
```
/mnt/htsai-docker-volume-backup/
├── configs/
│   ├── 20260415-174400/
│   │   ├── repo/
│   │   │   ├── .env
│   │   │   ├── stack.json
│   │   │   ├── .last-applied.json
│   │   │   └── profiles/
│   │   └── system/
│   │       ├── daemon.json
│   │       ├── fstab
│   │       ├── idmapd.conf
│   │       └── nas.env
│   └── 20260414-120000/
│       └── ...
└── volumes/
    ├── 20260415-174400/
    │   ├── gitea_data-20260415-174400.tar.gz
    │   ├── open_webui_data-20260415-174400.tar.gz
    │   └── ...
    └── ...
```

---

## TASK 3: Create Volume Restore Script

### Script: `scripts/host/restore-volumes.sh`

Should support:
1. List available backup timestamps on NAS
2. Pick a timestamp to restore from
3. For each volume tar, create a fresh Docker volume and extract into it
4. Optionally restore configs too

### Key design decisions:
- **Stop all services before restore** — `docker compose down` first
- **Don't overwrite existing volumes** — prompt user or use `--force` flag
- **Restore is selective** — user picks which volumes to restore
- **Config restore is separate** — `--configs` flag to also restore .env, stack.json, etc.

### Usage:
```bash
sudo ./scripts/host/restore-volumes.sh                    # interactive: list + pick
sudo ./scripts/host/restore-volumes.sh --latest            # restore most recent backup
sudo ./scripts/host/restore-volumes.sh --timestamp 20260415-174400
sudo ./scripts/host/restore-volumes.sh --latest --configs  # also restore configs
sudo ./scripts/host/restore-volumes.sh --list              # just show available backups
```

### Restore flow:
```
1. Check NAS is mounted
2. List available backup timestamps
3. User picks one (or --latest)
4. Stop all compose services
5. For each .tar.gz in the selected backup:
   a. Create Docker volume if it doesn't exist
   b. Extract tar into volume mountpoint
6. If --configs: copy .env, stack.json, etc. back to repo
7. Start services: docker compose up -d
```

---

## TASK 4: Create Unified Backup Command

### Script: `scripts/host/backup-all.sh`

One command to run both model backup + volume backup + config backup:

```bash
sudo ./scripts/host/backup-all.sh
```

This calls:
1. `backup-configs.sh` — fast, small files
2. `backup-volumes.sh` — pause/tar/resume stateful volumes
3. `backup-models.sh` — rsync model volumes (large but incremental)

### Why separate scripts too?
- `backup-models.sh` is safe to run anytime (no pause needed, rsync is incremental)
- `backup-volumes.sh` pauses services briefly (best done during maintenance window)
- `backup-configs.sh` is instant and non-disruptive
- Users may want to run them independently

---

## TASK 5: Scheduled Backups (Optional)

### Approach: systemd timer (preferred over cron for logging)

Create two timers:
1. **Daily config backup** — `htsai-backup-configs.timer` (lightweight, no disruption)
2. **Weekly volume backup** — `htsai-backup-volumes.timer` (pauses services briefly)
3. **Daily model sync** — `htsai-backup-models.timer` (rsync, no disruption)

### Timer files go in `/etc/systemd/system/`:
```ini
# htsai-backup-configs.timer
[Unit]
Description=Daily HTS-AI config backup to NAS

[Timer]
OnCalendar=*-*-* 02:00:00
Persistent=true

[Install]
WantedBy=timers.target
```

### Corresponding service files:
```ini
# htsai-backup-configs.service
[Unit]
Description=HTS-AI config backup

[Service]
Type=oneshot
ExecStart=/home/<user>/hts/hts-ai-stack/scripts/host/backup-configs.sh
User=root
```

### Setup script: `scripts/host/setup-backup-timers.sh`
- Installs timer + service files
- Enables and starts timers
- Shows status

NOTE: Timers should be installed OUTSIDE the repo (in /etc/systemd/system)
so they survive nuke-and-pave. The scripts they call are in the repo, so after
a nuke-and-pave you'd need to re-clone before timers work again. Consider
copying the backup scripts to `~/.local/bin/` as well.

---

## TASK 6: Backup Verification

### Script: `scripts/host/backup-status.sh`

Quick health check:
```
══ Backup Status ══
Last config backup:   2026-04-15 17:44  (2 hours ago)  ✓
Last volume backup:   2026-04-14 02:00  (1 day ago)    ✓
Last model sync:      2026-04-15 14:30  (5 hours ago)  ✓

Config snapshots:     8 / 10 max
Volume snapshots:     4 / 10 max
NAS free space:       1.2 TB

Volumes backed up:    12 / 14 stateful volumes
Models synced:        3 / 3 (ollama, comfyui, sd)
```

---

## NAS Folder Layout (Complete)

```
/mnt/htsai-docker-volume-backup/          ← Docker state backups
├── configs/                               ← timestamped config snapshots
│   ├── 20260415-174400/
│   │   ├── repo/                          ← .env, stack.json, profiles
│   │   └── system/                        ← daemon.json, fstab, nas.env
│   └── ...
└── volumes/                               ← timestamped volume tarballs
    ├── 20260415-174400/
    │   ├── gitea_data-20260415-174400.tar.gz
    │   ├── open_webui_data-20260415-174400.tar.gz
    │   ├── sillytavern_data-20260415-174400.tar.gz
    │   ├── n8n_data-20260415-174400.tar.gz
    │   └── ...
    └── ...

/mnt/htsai-model-backup/                  ← Model weights (rsync, not tar)
├── ollama/models/
├── stable-diffusion/
│   ├── checkpoints/
│   ├── loras/
│   ├── embeddings/
│   └── vae/
├── comfyui/
│   ├── models/
│   ├── custom_nodes/
│   └── output/
├── bitnet/models/
├── localai/models/
├── coqui-tts/models/
└── vosk/models/

/mnt/htsai-timeshift-backup/              ← System snapshots (managed by Timeshift)
└── (Timeshift manages its own layout)
```

---

## Priority Order
1. **Task 1** — Fix backup-volumes.sh paths + expand volume list
2. **Task 2** — Create backup-configs.sh
3. **Task 3** — Create restore-volumes.sh
4. **Task 4** — Create backup-all.sh (wraps 1+2+models)
5. **Task 5** — Scheduled timers (nice-to-have)
6. **Task 6** — Backup status checker (nice-to-have)

---

## Key Technical Notes

### Docker volume backup technique
The existing `backup-volumes.sh` uses this pattern:
1. `docker compose pause <service>` — freezes the container (no writes)
2. `docker run --rm -v <volume>:/data alpine tar czf - /data > backup.tar.gz`
3. `docker compose unpause <service>` — resumes

This ensures consistent backups without stopping the container entirely.

### Volume restore technique
```bash
# Create volume if needed
docker volume create my_volume
# Extract tar into it
docker run --rm -v my_volume:/data -v /path/to/backup:/backup alpine \
  sh -c "cd /data && tar xzf /backup/my_volume-timestamp.tar.gz --strip-components=1"
```

### Compose project prefix
All volumes are prefixed with `hts-ai-stack_` in Docker (e.g., `hts-ai-stack_ollama_data`).
The backup script needs to handle this — the existing script already does via
`docker volume inspect`.

### NFS permissions
Backups run as root (sudo). NAS NFS rules use "Map root to admin" so root writes
are allowed. Use `--no-owner --no-group` on any rsync operations.
Tar operations don't have this issue since they write as a single file.

### Retention policy
- Config snapshots: keep last 10 (small, ~1MB each)
- Volume snapshots: keep last 4-5 (can be large depending on data)
- Model sync: no retention needed (rsync is always current state)
