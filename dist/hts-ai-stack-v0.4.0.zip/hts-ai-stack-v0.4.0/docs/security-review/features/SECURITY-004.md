# Service Authentication Gaps

**Priority:** HIGH
**Effort:** 10-15 hours (per-service work, can be phased)
**Risk:** Medium — adding auth to inference APIs (Ollama, llama-swap) may break
integrations that call them unauthenticated (Open WebUI, NemoClaw sandbox).
Each service requires separate testing.
**Target Release:** v0.6.0
**Threat:** Unauthenticated inference, metrics exposure, data exfiltration. Any host able to
reach the stack (LAN device before SECURITY-000, tailnet device before SECURITY-001) can
send arbitrary prompts to Ollama, read all Prometheus metrics, or access Gitea without
credentials.
**Depends on:** SECURITY-000 (bind to localhost reduces attack surface while auth is added per-service)
**Blocks:** Nothing

## Problem

| Service | Port | Current Auth | Risk |
|---------|------|-------------|------|
| Ollama | 11434 | None | Free LLM inference for any LAN device |
| llama-swap | 8081 | None | Full model routing, no auth |
| BitNet | 8082 | None | Unauthenticated inference |
| Prometheus | 9090 | None | Full metrics — uptime, model names, resource usage |
| OpenSpace MCP | 5000 | None | Agent skill invocation, no auth |
| OpenSpace dashboard | 3001 | None | Unauthenticated |
| DeerFlow backend | 8003 | None | Unauthenticated API |
| Dashboard (nginx) | 80 | None | Reveals service topology |
| Stable Diffusion | 7860 | None | Unauthenticated image generation |
| Unsloth Studio | 8888 | Weak (`changeme`) | Default password, never changed |
| Grafana | 3100 | Yes (admin/changeme) | Default password must be changed |

## Solution

Phase the fixes by attack impact:

### Phase 1 — Quick wins (v0.5.0, alongside SECURITY-000)

- **Grafana**: Change default `admin/changeme` password during install
- **Unsloth**: Generate a random `JUPYTER_PASSWORD` in `.env` (replace `changeme`)
- **Prometheus**: Restrict to localhost — no external auth needed if SECURITY-000 binds it to 127.0.0.1

### Phase 2 — API key auth for inference (v0.6.0)

- **Ollama**: Set `OLLAMA_API_KEY` environment variable (supported since Ollama v0.3.0).
  Update Open WebUI config to pass the key.
- **llama-swap**: Add `api_key` to `config/llama-swap.yaml`. Update all callers.
- **BitNet**: Add nginx reverse proxy with `auth_basic` in front of port 8082.

### Phase 3 — Agent service auth (v0.6.0)

- **OpenSpace MCP**: Add API key auth or restrict to localhost-only binding
- **DeerFlow backend**: Configure `BETTER_AUTH_SECRET` with a generated value (not the static default)
- **Dashboard (nginx)**: Consider HTTP Basic Auth or restrict to Tailscale-only

## Implementation Notes

### Ollama API key

```bash
# .env
OLLAMA_API_KEY=$(openssl rand -hex 32)
```

```yaml
# docker-compose.yml
environment:
  - OLLAMA_API_KEY=${OLLAMA_API_KEY}
```

Callers must include `Authorization: Bearer ${OLLAMA_API_KEY}`.

### llama-swap API key

```yaml
# config/llama-swap.yaml
api_key: "${LLAMA_SWAP_API_KEY}"
```

### Prometheus — localhost-only

With SECURITY-000 in place, Prometheus binds to `127.0.0.1:9090` — accessible only from
Grafana (same host) and not from the network. No auth change needed.

## Acceptance Criteria

- `curl http://localhost:11434/api/tags` fails with 401 without API key
- Open WebUI, NemoClaw sandbox, and llama-swap continue to work with key configured
- Grafana login fails with `admin/changeme` (password changed during install)
- Unsloth Studio rejects access without the generated `JUPYTER_PASSWORD`
- DeerFlow uses a generated `BETTER_AUTH_SECRET` (not empty or default string)
