# FEATURE-033 — LibreChat

## Metadata

| Field | Value |
|-------|-------|
| **Feature ID** | FEATURE-033 |
| **Title** | LibreChat — Feature-Rich Multi-User Chat UI |
| **Priority** | MEDIUM |
| **Effort** | 2–4 hours |
| **Risk** | Low (MIT, active, well-documented) |
| **Status** | Proposed |
| **Target** | v0.6.0 |
| **Depends on** | Ollama (FEATURE-001), llama-swap routing (FEATURE-003) |
| **Blocks** | nothing |
| **Repo** | [danny-avila/LibreChat](https://github.com/danny-avila/LibreChat) |
| **License** | ✅ MIT |
| **Stars** | 35,542 |
| **Language** | TypeScript (Node.js + React) |
| **Docker image** | `ghcr.io/danny-avila/librechat-dev-api:latest` |
| **Default port** | 3080 |
| **Stack port** | 3080 |

---

## Problem / Rationale

Open WebUI (FEATURE-001) is the current primary chat interface but is primarily
optimised for Ollama direct connections. LibreChat provides a deeper feature set
including native MCP support, no-code Agents, sandboxed Code Interpreter, RAG,
multi-user auth (OAuth2/LDAP), conversation branching, and broad model-provider
support — all under an MIT license with 35k+ stars and daily commits.

Both frontends connect to the same llama-swap backend, so they complement rather
than conflict. This feature tracks LibreChat for evaluation alongside Open WebUI
to decide which ships as the primary interface in v0.6.0.

---

## Feature Comparison: LibreChat vs Open WebUI

| Capability | LibreChat | Open WebUI |
|---|---|---|
| **License** | MIT ✅ | Apache 2.0 ✅ |
| **Stars** | 35,542 | ~22k |
| **Ollama native** | ✅ (endpoint config) | ✅ (native integration) |
| **KoboldCpp native** | ✅ (built-in provider) | Via OpenAI-compat only |
| **MCP support** | ✅ native | ✅ native |
| **Agents / no-code** | ✅ Agent marketplace | ✅ Pipelines |
| **Code Interpreter** | ✅ sandboxed (Python, Go, Rust, …) | Via tools |
| **RAG** | ✅ via `rag_api` companion | ✅ built-in |
| **Multi-user auth** | ✅ OAuth2, LDAP, email | ✅ built-in |
| **Conversation search** | ✅ | ✅ |
| **Conversation branching** | ✅ fork + edit + resubmit | Limited |
| **Resumable streams** | ✅ multi-tab/multi-device | ✅ |
| **Image generation** | ✅ DALL-E, SD, Flux, MCP | ✅ ComfyUI, AUTOMATIC1111 |
| **STT/TTS** | ✅ (OpenAI/Azure/ElevenLabs; local via OpenAI-compat) | ✅ |
| **Artifacts (React/HTML/Mermaid)** | ✅ | ✅ |
| **Mandatory DB** | ⚠️ MongoDB required | ✅ SQLite (no external DB) |
| **Optional Redis** | For multi-device sync | For task queues |
| **Active dev** | ✅ daily commits | ✅ |

**Key differentiator:** LibreChat's sandboxed Code Interpreter and Agent
marketplace give it a substantial edge for power-user workflows. The mandatory
MongoDB is the main operational overhead compared to Open WebUI's SQLite.

---

## Architecture

```text
              │
              ├─ /api → LibreChat API (Node.js)
              │              │
              │              ├─ Ollama endpoint  → hts-ai-ollama:11434
              │              ├─ llama-swap proxy → hts-ai-llama-swap:8081/v1
              │              └─ KoboldCpp        → hts-ai-koboldcpp:5001 (FEATURE-031)
              │
              ├─ MongoDB (hts-ai-librechat-mongo:27017)
              └─ Redis optional (hts-ai-librechat-redis:6379) — multi-device streams
```

**Note:** LibreChat can be pointed directly at Ollama *or* at llama-swap. Using
llama-swap as the single endpoint simplifies provider config — one API base URL
surfaces all available models.

---

## Port Assignment

| Port | Purpose |
|------|---------|
| 3080 | LibreChat web UI + API |

Port 3080 is clear in the Host Port Map (checked 2026-04-12).

---

## Docker Service Sketch

```yaml
hts-ai-librechat:
  image: ghcr.io/danny-avila/librechat-dev-api:latest
  container_name: hts-ai-librechat
  profiles: [librechat]
  ports:
    - "${LIBRECHAT_PORT:-3080}:3080"
  environment:
    OPENAI_API_KEY: "not-needed"
    OPENAI_REVERSE_PROXY: "http://hts-ai-llama-swap:8081/v1"
    MONGO_URI: "mongodb://hts-ai-librechat-mongo:27017/LibreChat"
    REDIS_URI: "redis://hts-ai-librechat-redis:6379"
    APP_TITLE: "HTS AI Stack"
    ALLOW_REGISTRATION: "true"
    SESSION_EXPIRY: "900000"
    REFRESH_TOKEN_EXPIRY: "604800000"
  volumes:
    - librechat-uploads:/app/client/public/images
    - librechat-logs:/app/api/logs
  depends_on:
    - hts-ai-librechat-mongo
  restart: unless-stopped

hts-ai-librechat-mongo:
  image: mongo:7
  container_name: hts-ai-librechat-mongo
  profiles: [librechat]
  volumes:
    - librechat-mongo:/data/db
  restart: unless-stopped
```

---

## Implementation Steps

1. Create `docs/development/features/FEATURE-033.md` (this file)
2. Add port 3080 to `REFERENCES.md` Host Port Map
3. Add `FEATURE-033` row to `docs/development/features/REFERENCES.md` v0.6.0 table
4. Add `danny-avila/LibreChat` row to `docs/planning/feature-repos/REFERENCES.md`
5. Write `scripts/components/librechat/librechat.sh` — `librechat_install`, `librechat_configure`,
   `librechat_start`, `librechat_stop`, `librechat_health`
6. Add `docker-compose.yml` services: `hts-ai-librechat` + `hts-ai-librechat-mongo` +
   optional `hts-ai-librechat-redis` (all under profile `librechat`)
7. Copy and adapt `librechat.example.yaml` → `config/librechat.yaml` with
   llama-swap as custom endpoint
8. Create `resources/librechat/` — sample `librechat.yaml` with Ollama + llama-swap endpoints
9. Add `.env.example` vars: `LIBRECHAT_PORT`, `LIBRECHAT_MONGO_URI`
10. Validate: `curl http://localhost:3080` returns 200; login page renders

---

## Acceptance Criteria

- [ ] LibreChat UI loads on port 3080
- [ ] User registration and login work (local auth, no external provider required)
- [ ] llama-swap endpoint visible as model list in LibreChat
- [ ] Chat with a local model completes a round-trip successfully
- [ ] MongoDB container is healthy and persistent across restarts
- [ ] `docker compose --profile librechat up` / `down` cycle is clean

---

## License Note

MIT License — no copyleft concerns. Free for personal and commercial self-hosted
use with no source-disclosure obligation.

---

## Dependencies

| Dependency | Status |
|---|---|
| `hts-ai-llama-swap` (llama-swap proxy) | FEATURE-003 — merged |
| `hts-ai-ollama` (Ollama GPU inference) | FEATURE-001 — merged |
| `hts-ai-koboldcpp` (KoboldCpp inference, optional) | FEATURE-031 — Proposed |
| MongoDB 7 | New dependency — added to docker-compose under `librechat` profile |

---

## Notes

- **RAG API:** Companion repo `danny-avila/rag_api` adds retrieval-augmented
  generation. Tracked separately; not required for basic deployment.
- **Code Interpreter:** Runs in fully sandboxed containers per-user session.
  No GPU required — pure CPU execution.
- **KoboldCpp integration:** LibreChat has built-in KoboldCpp provider support.
  When FEATURE-031 is deployed, add KoboldCpp as a second endpoint in
  `config/librechat.yaml` alongside llama-swap.
- **vs Open WebUI decision:** Both can run simultaneously on different ports.
  A/B test both before deciding which to document as the "primary" chat UI.
