#!/usr/bin/env bash
# scripts/save-profile.sh — Snapshot current stack.json as a named profile
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"

PROFILES_DIR="$REPO_DIR/config/profiles"
STACK_JSON="$REPO_DIR/config/stack.json"

usage() {
  echo "Usage: $(basename "$0") <profile-name> [--force]"
  echo ""
  echo "  Saves the current stack.json as a named profile."
  echo "  Profile names must be lowercase alphanumeric, hyphens, or underscores."
  echo ""
  echo "Options:"
  echo "  --force   Overwrite an existing profile"
  exit 1
}

# ── Parse args ────────────────────────────────────────────────────────────────
FORCE=false
NAME=""
for arg in "$@"; do
  case "$arg" in
    --force) FORCE=true ;;
    -h|--help) usage ;;
    *) NAME="$arg" ;;
  esac
done

[[ -z "$NAME" ]] && usage

# Validate name (ASCII lowercase, digits, hyphens, underscores)
if [[ ! "$NAME" =~ ^[a-z0-9_-]+$ ]]; then
  fail "Profile name must be lowercase alphanumeric, hyphens, or underscores: $NAME"
fi

# ── Preflight ─────────────────────────────────────────────────────────────────
[[ -f "$STACK_JSON" ]] || fail "No stack.json found at $STACK_JSON — run setup first"

mkdir -p "$PROFILES_DIR"

PROFILE_FILE="$PROFILES_DIR/${NAME}.json"

if [[ -f "$PROFILE_FILE" && "$FORCE" != true ]]; then
  fail "Profile '$NAME' already exists. Use --force to overwrite."
fi

# ── Save ──────────────────────────────────────────────────────────────────────
step "Saving profile: $NAME"

# Remove read-only if overwriting
[[ -f "$PROFILE_FILE" ]] && chmod 644 "$PROFILE_FILE"

cp "$STACK_JSON" "$PROFILE_FILE"
chmod 444 "$PROFILE_FILE"

# Update active symlink
ln -sf "${NAME}.json" "$PROFILES_DIR/active"

ok "Profile saved → config/profiles/${NAME}.json (read-only)"
info "Active profile: $NAME"
