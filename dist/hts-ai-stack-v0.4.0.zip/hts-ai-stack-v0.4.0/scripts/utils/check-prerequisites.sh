#!/usr/bin/env bash
# check-prerequisites.sh — Verify all packages in prerequisites.json are installed
#
# Usage:
#   ./check-prerequisites.sh            # check all packages
#   ./check-prerequisites.sh --scope core   # check only 'core' scope
#   ./check-prerequisites.sh --scope dev    # check only 'dev' scope
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

PREREQ_FILE="$REPO_DIR/scripts/host/prerequisites.json"

if [[ ! -f "$PREREQ_FILE" ]]; then
  fail "prerequisites.json not found at $PREREQ_FILE"
fi

if ! command -v jq &>/dev/null; then
  fail "jq is required but not installed"
fi

# ── Parse arguments ──────────────────────────────────────────────────────────
SCOPE_FILTER=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --scope) SCOPE_FILTER="$2"; shift 2 ;;
    --help|-h)
      echo "Usage: $0 [--scope <scope>]"
      echo "Scopes: core, dev, admin, optional, service, networking, tooling"
      exit 0
      ;;
    *) fail "Unknown argument: $1" ;;
  esac
done

# ── Build package list ───────────────────────────────────────────────────────
if [[ -n "$SCOPE_FILTER" ]]; then
  step "Checking prerequisites (scope: $SCOPE_FILTER)"
  PACKAGES=$(jq -r --arg scope "$SCOPE_FILTER" \
    '.prerequisites[] | select(.scope == $scope) | .package' "$PREREQ_FILE")
else
  step "Checking all prerequisites"
  PACKAGES=$(jq -r '.prerequisites[].package' "$PREREQ_FILE")
fi

if [[ -z "$PACKAGES" ]]; then
  warn "No packages found${SCOPE_FILTER:+ for scope '$SCOPE_FILTER'}"
  exit 0
fi

TOTAL=0
INSTALLED=0
MISSING=0
MISSING_LIST=()

while IFS= read -r pkg; do
  TOTAL=$((TOTAL + 1))

  # Check dpkg first, then fall back to command -v for non-apt packages
  if dpkg -s "$pkg" &>/dev/null; then
    INSTALLED=$((INSTALLED + 1))
  elif command -v "$pkg" &>/dev/null; then
    INSTALLED=$((INSTALLED + 1))
  else
    MISSING=$((MISSING + 1))
    MISSING_LIST+=("$pkg")

    # Look up the reason and installer for context
    REASON=$(jq -r --arg p "$pkg" '.prerequisites[] | select(.package == $p) | .reason' "$PREREQ_FILE" | head -1)
    INSTALLER=$(jq -r --arg p "$pkg" '.prerequisites[] | select(.package == $p) | .installer' "$PREREQ_FILE" | head -1)
    SCOPE=$(jq -r --arg p "$pkg" '.prerequisites[] | select(.package == $p) | .scope' "$PREREQ_FILE" | head -1)
    warn "MISSING: $pkg  [$SCOPE]  — $REASON  (installed by: $INSTALLER)"
  fi
done <<< "$PACKAGES"

# ── Summary ──────────────────────────────────────────────────────────────────
echo ""
step "Results"
info "Total: $TOTAL  |  Installed: $INSTALLED  |  Missing: $MISSING"

if [[ $MISSING -gt 0 ]]; then
  echo ""
  warn "Missing packages: ${MISSING_LIST[*]}"
  exit 1
else
  ok "All prerequisites are installed."
  exit 0
fi
