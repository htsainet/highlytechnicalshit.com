#!/usr/bin/env bash
# scripts/utils/provision-webui-functions.sh — Register Open WebUI Functions via API
#
# Reads Python function files from resources/open-webui-functions/ and
# registers them in Open WebUI so they're available as /slash commands.
#
# Usage:
#   ./scripts/utils/provision-webui-functions.sh          # provision all functions
#   ./scripts/utils/provision-webui-functions.sh --check   # list currently installed
#
# Requirements:
#   - Open WebUI running and healthy on WEBUI_PORT (default: 3000)
#   - WEBUI_API_KEY in .env (generate from Open WebUI → Settings → Account → API Keys)
#
# Called automatically by: scripts/components/open-webui.sh after first start.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
FUNCTIONS_DIR="$REPO_DIR/resources/open-webui-functions"

source "$REPO_DIR/scripts/lib/common.sh"

load_env
WEBUI_PORT="${WEBUI_PORT:-3000}"
WEBUI_URL="http://localhost:${WEBUI_PORT}"

# ── Auth ─────────────────────────────────────────────────────────────────────

_get_api_key() {
  local api_key="${WEBUI_API_KEY:-}"

  if [[ -z "$api_key" ]]; then
    warn "WEBUI_API_KEY not set in .env — skipping function provisioning."
    warn "Generate one from Open WebUI → Settings → Account → API Keys"
    warn "Then add to .env:  WEBUI_API_KEY=sk-..."
    return 1
  fi

  echo "$api_key"
}

# ── Function CRUD ────────────────────────────────────────────────────────────

_list_functions() {
  local api_key="$1"
  curl -sf --max-time 10 "${WEBUI_URL}/api/v1/functions/" \
    -H "Authorization: Bearer ${api_key}" 2>/dev/null
}

_function_exists() {
  local api_key="$1" func_id="$2"
  local existing
  existing=$(_list_functions "$api_key") || return 1
  echo "$existing" | python3 -c "
import sys, json
funcs = json.load(sys.stdin)
ids = [f['id'] for f in funcs]
sys.exit(0 if '${func_id}' in ids else 1)
" 2>/dev/null
}

_create_or_update_function() {
  local api_key="$1" func_id="$2" py_file="$3"

  # Extract metadata from the Python docstring header
  local name description
  name=$(python3 -c "
import re, sys
txt = open('${py_file}').read()
m = re.search(r'title:\s*(.+)', txt)
print(m.group(1).strip() if m else '${func_id}')
" 2>/dev/null)

  description=$(python3 -c "
import re, sys
txt = open('${py_file}').read()
m = re.search(r'description:\s*(.+)', txt)
print(m.group(1).strip() if m else '')
" 2>/dev/null)

  local content
  content=$(python3 -c "import json,sys; print(json.dumps(open('${py_file}').read()))" 2>/dev/null)

  local payload
  payload=$(python3 -c "
import json
print(json.dumps({
    'id': '${func_id}',
    'name': $(python3 -c "import json; print(json.dumps('${name}'))"),
    'description': $(python3 -c "import json; print(json.dumps('${description}'))"),
    'content': json.loads(${content}),
    'type': 'pipe',
    'is_active': True,
    'is_global': True
}))
" 2>/dev/null)

  if _function_exists "$api_key" "$func_id"; then
    # Update existing
    curl -sf --max-time 10 "${WEBUI_URL}/api/v1/functions/id/${func_id}/update" \
      -X POST \
      -H "Authorization: Bearer ${api_key}" \
      -H "Content-Type: application/json" \
      -d "$payload" >/dev/null 2>&1 && {
      info "  Updated: ${func_id} (${name})"
      return 0
    }
  else
    # Create new
    curl -sf --max-time 10 "${WEBUI_URL}/api/v1/functions/create" \
      -X POST \
      -H "Authorization: Bearer ${api_key}" \
      -H "Content-Type: application/json" \
      -d "$payload" >/dev/null 2>&1 && {
      info "  Created: ${func_id} (${name})"
      return 0
    }
  fi

  warn "  Failed to provision: ${func_id}"
  return 1
}

# ── Main ─────────────────────────────────────────────────────────────────────

ACTION="${1:-provision}"

api_key=$(_get_api_key) || exit 0  # soft-fail: don't block stack startup

case "$ACTION" in
  --check)
    step "Open WebUI — installed functions"
    _list_functions "$api_key" | python3 -c "
import sys, json
funcs = json.load(sys.stdin)
if not funcs:
    print('  No functions installed.')
else:
    for f in funcs:
        active = '✅' if f.get('is_active') else '❌'
        print(f\"  {active} {f['id']:30s} {f.get('name','?')}\")
" 2>/dev/null
    ;;
  *)
    if [[ ! -d "$FUNCTIONS_DIR" ]] || [[ -z "$(ls -A "$FUNCTIONS_DIR"/*.py 2>/dev/null)" ]]; then
      info "No functions found in resources/open-webui-functions/"
      exit 0
    fi

    step "Open WebUI — provisioning functions"
    count=0
    for py_file in "$FUNCTIONS_DIR"/*.py; do
      func_id=$(basename "$py_file" .py)
      _create_or_update_function "$api_key" "$func_id" "$py_file" && ((count++)) || true
    done
    ok "Provisioned ${count} function(s)."
    ;;
esac
