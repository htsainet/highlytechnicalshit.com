#!/usr/bin/env bash
# scripts/utils/rdp.sh — Manage GNOME Remote Desktop (RDP/VNC) via interactive menu
#
# Manages GNOME Remote Desktop on Ubuntu 22.04+ using grdctl (modern approach):
#   • RDP enabled/disabled (port 3389, primary protocol)
#   • VNC enabled/disabled (port 5900, optional secondary)
#   • Current user GNOME session check
#   • Auto-login for GDM (persistent + ephemeral)
#
# Usage:
#   ./rdp.sh                 # Opens interactive menu
#   ./rdp.sh --help          # Show this help
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source common logging functions
# shellcheck source=/dev/null
source "$REPO_DIR/scripts/lib/common.sh" || {
  # Fallback if common.sh not available
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  RED='\033[0;31m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
}

# ── State file for ephemeral settings ─────────────────────────────────────
EPHEMERAL_STATE="/tmp/.rdp-ephemeral-${USER}.conf"

# ── Tailscale detection ──────────────────────────────────────────────────────

is_tailscale_available() {
  command -v tailscale >/dev/null 2>&1 && echo "yes" || echo "no"
}

is_tailscale_active() {
  if systemctl is-active tailscaled >/dev/null 2>&1; then
    echo "yes"
  else
    echo "no"
  fi
}

get_tailscale_ip() {
  if [[ $(is_tailscale_active) == "yes" ]]; then
    tailscale ip -4 2>/dev/null | head -1
  else
    echo ""
  fi
}

is_rdp_firewall_restricted() {
  # Check if there are firewall rules restricting RDP to Tailscale
  if command -v ufw >/dev/null 2>&1; then
    ufw status | grep -q "3389.*100.64" && echo "yes" || echo "no"
  else
    echo "no"
  fi
}

# ── Helper functions ──────────────────────────────────────────────────────

# Check if RDP is enabled via grdctl
is_rdp_enabled() {
  if command -v grdctl >/dev/null 2>&1; then
    grdctl status 2>/dev/null | grep -qi "RDP.*Enabled\|rdp.*true" && echo "yes" || echo "no"
  else
    echo "no"
  fi
}

# Check if VNC is enabled via grdctl
is_vnc_enabled() {
  if command -v grdctl >/dev/null 2>&1; then
    grdctl status 2>/dev/null | grep -qi "VNC.*Enabled\|vnc.*true" && echo "yes" || echo "no"
  else
    echo "no"
  fi
}

# Check if current user has a GNOME session available
has_gnome_session() {
  if systemctl --user is-enabled gnome-session@gnome.target >/dev/null 2>&1; then
    echo "yes"
  elif [[ -d "$HOME/.local/share/gnome-session/sessions" ]]; then
    echo "yes"
  else
    echo "no"
  fi
}

# Check if auto-login is enabled in GDM (persistent)
is_autologin_enabled() {
  if [[ ! -f /etc/gdm3/custom.conf ]]; then
    echo "no"
    return
  fi
  grep -q "^AutomaticLoginEnable=true" /etc/gdm3/custom.conf 2>/dev/null && echo "yes" || echo "no"
}

# Get auto-login user from GDM config
get_autologin_user() {
  grep "^AutomaticLogin=" /etc/gdm3/custom.conf 2>/dev/null | cut -d= -f2 || echo ""
}

# Check if auto-login is enabled for next reboot only (ephemeral)
is_autologin_next_boot_enabled() {
  if [[ -f "$EPHEMERAL_STATE" ]]; then
    grep -q "^AUTOLOGIN_NEXT_BOOT=true" "$EPHEMERAL_STATE" && echo "yes" || echo "no"
  else
    echo "no"
  fi
}

# Toggle RDP via grdctl (primary protocol)
toggle_rdp() {
  local new_state="$1"  # "true" or "false"
  
  if ! command -v grdctl >/dev/null 2>&1; then
    echo -e "${RED}grdctl not found. Install: sudo apt install gnome-remote-desktop${NC}"
    return 1
  fi

  if [[ "$new_state" == "true" ]]; then
    sudo grdctl rdp enable 2>/dev/null || {
      echo -e "${RED}Failed to enable RDP via grdctl${NC}"
      return 1
    }
    info "RDP (port 3389) enabled"
  else
    sudo grdctl rdp disable 2>/dev/null || {
      echo -e "${RED}Failed to disable RDP via grdctl${NC}"
      return 1
    }
    info "RDP disabled"
  fi
}

# Toggle VNC via grdctl (optional secondary protocol)
toggle_vnc() {
  local new_state="$1"  # "true" or "false"
  
  if ! command -v grdctl >/dev/null 2>&1; then
    echo -e "${RED}grdctl not found. Install: sudo apt install gnome-remote-desktop${NC}"
    return 1
  fi

  if [[ "$new_state" == "true" ]]; then
    sudo grdctl vnc enable 2>/dev/null || {
      echo -e "${RED}Failed to enable VNC via grdctl${NC}"
      return 1
    }
    info "VNC (port 5900) enabled"
  else
    sudo grdctl vnc disable 2>/dev/null || {
      echo -e "${RED}Failed to disable VNC via grdctl${NC}"
      return 1
    }
    info "VNC disabled"
  fi
}

# Enable/disable auto-login in GDM (persistent)
set_autologin_persistent() {
  local enable="$1"  # "true" or "false"
  local guser="${2:-$USER}"

  if [[ ! -f /etc/gdm3/custom.conf ]]; then
    echo -e "${RED}/etc/gdm3/custom.conf not found${NC}"
    return 1
  fi

  if [[ "$enable" == "true" ]]; then
    # Remove existing lines, then add new ones
    sudo sed -i '/^AutomaticLoginEnable=/d; /^AutomaticLogin=/d' /etc/gdm3/custom.conf
    # Add after [daemon] section if exists, or append
    if grep -q "^\[daemon\]" /etc/gdm3/custom.conf; then
      sudo sed -i '/^\[daemon\]/a AutomaticLoginEnable=true\nAutomaticLogin='"$guser" /etc/gdm3/custom.conf
    else
      echo -e "[daemon]\nAutomaticLoginEnable=true\nAutomaticLogin=$guser" | sudo tee -a /etc/gdm3/custom.conf >/dev/null
    fi
    info "Auto-login ENABLED persistently for user: $guser"
  else
    sudo sed -i '/^AutomaticLoginEnable=/d; /^AutomaticLogin=/d' /etc/gdm3/custom.conf
    info "Auto-login DISABLED persistently"
  fi
}

# Enable/disable auto-login for next reboot only (ephemeral)
set_autologin_next_boot() {
  local enable="$1"  # "true" or "false"

  mkdir -p "$(dirname "$EPHEMERAL_STATE")"
  if [[ "$enable" == "true" ]]; then
    echo "AUTOLOGIN_NEXT_BOOT=true" > "$EPHEMERAL_STATE"
    chmod 600 "$EPHEMERAL_STATE"
    info "Auto-login ENABLED for next reboot only"
    echo -e "${CYAN}This setting will be cleared after reboot.${NC}"
  else
    rm -f "$EPHEMERAL_STATE"
    info "Auto-login for next reboot DISABLED"
  fi
}
# Restrict RDP to Tailscale network via firewall
set_rdp_tailscale_only() {
  local enable="$1"  # "true" or "false"

  if ! command -v ufw >/dev/null 2>&1; then
    echo -e "${YELLOW}ufw firewall not found. Skipping firewall rules.${NC}"
    echo -e "Install with: sudo apt install ufw${NC}"
    return 1
  fi

  if [[ "$enable" == "true" ]]; then
    # Restrict RDP port 3389 to Tailscale subnet only (100.64.0.0/10)
    sudo ufw delete allow 3389/tcp 2>/dev/null || true
    sudo ufw delete allow 3389/udp 2>/dev/null || true
    sudo ufw allow from 100.64.0.0/10 to any port 3389 proto tcp 2>/dev/null || true
    info "RDP (Remote Desktop) restricted to Tailscale network (100.64.0.0/10) via firewall"
  else
    # Open RDP to all
    sudo ufw delete allow from 100.64.0.0/10 to any port 3389 proto tcp 2>/dev/null || true
    sudo ufw allow 3389/tcp 2>/dev/null || true
    info "RDP (Remote Desktop) opened to all networks"
  fi
}
# Display status with color coding
show_status() {
  local label="$1"
  local value="$2"
  local color="${GREEN}"
  [[ "$value" == "no" ]] && color="${RED}"
  printf "  %-40s ${color}%-8s${NC}\n" "$label" "$value"
}

# ── Main Menu ─────────────────────────────────────────────────────────────

show_main_menu() {
  local rdp_state=$(is_rdp_enabled)
  local vnc_state=$(is_vnc_enabled)
  local session_state=$(has_gnome_session)
  local al_state=$(is_autologin_enabled)
  local al_next=$(is_autologin_next_boot_enabled)
  local ts_available=$(is_tailscale_available)
  local ts_active=$(is_tailscale_active)
  local ts_restricted=$(is_rdp_firewall_restricted)

  # Build status display for the menu
  local status_text="GNOME Remote Desktop Status:\n\n"
  status_text+="  RDP (primary, port 3389): $rdp_state\n"
  status_text+="  VNC (optional, port 5900): $vnc_state\n"
  status_text+="  GNOME session: $session_state\n"
  status_text+="  Auto-login (persistent): $al_state\n"
  status_text+="  Auto-login (next boot): $al_next\n"
  
  if [[ "$ts_available" == "yes" && "$ts_active" == "yes" ]]; then
    local ts_ip
    ts_ip=$(get_tailscale_ip)
    status_text+="  Tailscale: $ts_ip  RDP restricted: $ts_restricted\n"
  fi
  
  status_text+="\nChoose an action:"

  local rdp_toggle="Enable" || rdp_toggle="Disable"
  [[ "$rdp_state" == "yes" ]] && rdp_toggle="Disable" || rdp_toggle="Enable"

  local vnc_toggle="Enable" || vnc_toggle="Disable"
  [[ "$vnc_state" == "yes" ]] && vnc_toggle="Disable" || vnc_toggle="Enable"

  local al_toggle="Enable" || al_toggle="Disable"
  [[ "$al_state" == "yes" ]] && al_toggle="Disable" || al_toggle="Enable"

  local al_next_toggle="Enable" || al_next_toggle="Disable"
  [[ "$al_next" == "yes" ]] && al_next_toggle="Disable" || al_next_toggle="Enable"

  # Build menu items array
  local -a menu_items=("1" "$rdp_toggle RDP (primary, port 3389)"
                       "2" "$vnc_toggle VNC (optional, port 5900)"
                       "3" "$al_toggle Auto-login (persistent)"
                       "4" "$al_next_toggle Auto-login (next reboot)"
                       "5" "Show detailed settings"
                       "6" "Reset all to defaults")
  
  # Add Tailscale option if available
  if [[ "$ts_available" == "yes" && "$ts_active" == "yes" ]]; then
    local ts_toggle="Restrict"
    [[ "$ts_restricted" == "yes" ]] && ts_toggle="Unrestrict"
    menu_items+=("7" "$ts_toggle RDP to Tailscale only")
  fi

  # Present menu with embedded status
  local choice
  choice=$(whiptail --title "GNOME Remote Desktop Configuration" \
    --menu "$status_text" 0 0 0 \
    "${menu_items[@]}" \
    3>&1 1>&2 2>&3) || return 0  # Exit if user clicks Cancel

  handle_menu_choice "$choice"
}

# ── Menu handlers ─────────────────────────────────────────────────────────

handle_menu_choice() {
  local choice="$1"

  case "$choice" in
    1)
      toggle_rdp_menu
      ;;
    2)
      toggle_vnc_menu
      ;;
    3)
      toggle_autologin_persistent_menu
      ;;
    4)
      toggle_autologin_next_boot_menu
      ;;
    5)
      show_detailed_settings
      ;;
    6)
      confirm_reset_all
      ;;
    7)
      # Tailscale option (only if available)
      if [[ $(is_tailscale_available) == "yes" && $(is_tailscale_active) == "yes" ]]; then
        toggle_tailscale_restricted_menu
      fi
      ;;
    *)
      ;;
  esac
}

toggle_rdp_menu() {
  local current=$(is_rdp_enabled)
  local new_state="false"
  [[ "$current" == "no" ]] && new_state="true"

  whiptail --yesno "Toggle RDP to: $new_state (persistent)\n\nRDP uses port 3389 (Microsoft Remote Desktop Protocol).\nThis is the modern primary protocol for GNOME Remote Desktop.\n\nWill apply immediately." 0 0 || return 0

  sudo_or_warn "toggle RDP" || return 0
  
  toggle_rdp "$new_state"
  whiptail --msgbox "✓ RDP is now: $new_state\n\nPort: 3389\nCan connect with mstsc.exe, macOS Remote Desktop, or RDP clients." 10 50
  show_main_menu
}

toggle_vnc_menu() {
  local current=$(is_vnc_enabled)
  local new_state="false"
  [[ "$current" == "no" ]] && new_state="true"

  whiptail --yesno "Toggle VNC to: $new_state (persistent)\n\nVNC is an optional secondary protocol on port 5900.\nUseful for headless scenarios or legacy clients.\n\nWill apply immediately." 0 0 || return 0

  sudo_or_warn "toggle VNC" || return 0
  
  toggle_vnc "$new_state"
  whiptail --msgbox "✓ VNC is now: $new_state\n\nPort: 5900\nCan connect with VNC clients." 8 50
  show_main_menu
}

toggle_autologin_persistent_menu() {
  local current=$(is_autologin_enabled)
  local new_state="false"
  [[ "$current" == "no" ]] && new_state="true"

  local action="disable"
  [[ "$new_state" == "true" ]] && action="enable"

  sudo_or_warn "set auto-login" || return 0

  if whiptail --yesno "Toggle persistent auto-login to: $new_state\n\nThis will:\n• $action auto-login at next session\n• Remain after reboot\n\nWARNING: Requires sudo to modify GDM config." 0 0; then
    set_autologin_persistent "$new_state" "$USER"
    whiptail --msgbox "✓ Auto-login is now: $new_state (persistent)" 8 40
  fi
  show_main_menu
}

toggle_autologin_next_boot_menu() {
  local current=$(is_autologin_next_boot_enabled)
  local new_state="false"
  [[ "$current" == "no" ]] && new_state="true"

  if whiptail --yesno "Toggle auto-login for next reboot only: $new_state\n\nThis setting is ephemeral and will clear after reboot." 0 0; then
    set_autologin_next_boot "$new_state"
    whiptail --msgbox "✓ One-time auto-login is now: $new_state\n\n(Resets after reboot)" 8 40
  fi
  show_main_menu
}

toggle_tailscale_restricted_menu() {
  local current=$(is_rdp_firewall_restricted)
  local new_state="false"
  [[ "$current" == "no" ]] && new_state="true"

  local action="restrict"
  [[ "$new_state" == "true" ]] && action="restrict to Tailscale" || action="open to all networks"

  sudo_or_warn "restrict RDP access" || return 0

  local ts_ip
  ts_ip=$(get_tailscale_ip)

  if whiptail --yesno "Toggle RDP Tailscale restriction to: $new_state\n\nYour Tailscale IP: $ts_ip\n\nThis will ${action} via firewall rules.\nWARNING: Requires sudo and ufw firewall." 0 0; then
    if set_rdp_tailscale_only "$new_state"; then
      if [[ "$new_state" == "true" ]]; then
        whiptail --msgbox "✓ RDP is now restricted to Tailscale only\n\nFirewall rules applied for subnet 100.64.0.0/10\nYour Tailscale IP: $ts_ip" 10 50
      else
        whiptail --msgbox "✓ RDP is now open to all networks" 8 40
      fi
    else
      whiptail --msgbox "✗ Failed to update RDP firewall rules\n\nEnsure ufw is installed and running." 8 50
    fi
  fi
  show_main_menu
}

show_detailed_settings() {
  local rdp_state=$(is_rdp_enabled)
  local vnc_state=$(is_vnc_enabled)
  local session_state=$(has_gnome_session)
  local al_persistent=$(is_autologin_enabled)
  local al_next=$(is_autologin_next_boot_enabled)
  local al_user=$(get_autologin_user)

  local msg="DETAILED SETTINGS\n\n"
  msg+="GNOME Remote Desktop (grdctl):\n"
  msg+="  RDP (port 3389): $rdp_state (primary protocol)\n"
  msg+="  VNC (port 5900): $vnc_state (optional secondary)\n\n"
  msg+="User GNOME Session: $session_state\n"
  msg+="  Check: systemd user units\n\n"
  msg+="Auto-login (persistent): $al_persistent\n"
  msg+="  Config: /etc/gdm3/custom.conf\n"
  msg+="  User: ${al_user:-none}\n\n"
  msg+="Auto-login (next boot): $al_next\n"
  msg+="  Config: $EPHEMERAL_STATE\n\n"
  msg+="To check RDP/VNC status manually:\n"
  msg+="  grdctl status"

  whiptail --msgbox "$msg" 20 70
  show_main_menu
}

confirm_reset_all() {
  whiptail --yesno "Reset ALL settings to defaults?\n\n• RDP (port 3389): disable\n• VNC (port 5900): disable\n• Auto-login (persistent): disable\n• Auto-login (next boot): disable\n\nWARNING: This requires sudo." 0 0 || return 0

  sudo_or_warn "reset settings" || return 0

  toggle_rdp "false" 2>/dev/null || true
  toggle_vnc "false" 2>/dev/null || true
  set_autologin_persistent "false" 2>/dev/null || true
  set_autologin_next_boot "false" 2>/dev/null || true

  whiptail --msgbox "✓ All GNOME Remote Desktop settings reset to defaults" 8 50
  show_main_menu
}

# ── Utility: Check for sudo or warn ───────────────────────────────────────
sudo_or_warn() {
  local action="${1:-perform action}"
  if ! sudo -l >/dev/null 2>&1; then
    whiptail --msgbox "ERROR: sudo access required to $action\n\nPlease configure sudoers or run with: sudo $0" 8 50
    return 1
  fi
  return 0
}

# ── Help ──────────────────────────────────────────────────────────────────

show_help() {
  cat <<EOF
${CYAN}GNOME Remote Desktop Configuration Manager${NC}

Modern interface for managing GNOME Remote Desktop on Ubuntu 22.04+ using grdctl.

${BOLD}Usage:${NC}
  $0                 Opens interactive menu
  $0 --help          Show this help

${BOLD}Features:${NC}
  • Toggle RDP (primary, port 3389)
  • Toggle VNC (optional, port 5900)
  • Configure auto-login (persistent or one-time)
  • View detailed settings
  • Reset all to defaults

${BOLD}RDP vs VNC:${NC}
  RDP: Modern, primary protocol. Windows uses mstsc.exe, Mac uses Microsoft Remote Desktop app.
  VNC: Legacy option. Useful for headless or specialty clients.

${BOLD}Requirements:${NC}
  • whiptail (usually pre-installed)
  • grdctl (from gnome-remote-desktop package)
  • sudo (for GDM config changes)

${BOLD}Auto-login Behavior:${NC}
  Persistent: Survives reboot. Configured in /etc/gdm3/custom.conf
  Next Boot Only: Clears after reboot. Useful for testing.

EOF
}

# ── Entry point ───────────────────────────────────────────────────────────

main() {
  if [[ "${1:-}" == "--help" ]] || [[ "${1:-}" == "-h" ]]; then
    show_help
    exit 0
  fi

  # Check dependencies
  if ! command -v whiptail >/dev/null 2>&1; then
    echo -e "${RED}whiptail not found. Install: sudo apt install whiptail${NC}"
    exit 1
  fi

  if ! command -v grdctl >/dev/null 2>&1; then
    echo -e "${RED}grdctl not found. Install: sudo apt install gnome-remote-desktop${NC}"
    exit 1
  fi

  if [[ "$USER" == "root" ]]; then
    echo -e "${YELLOW}WARNING: Running as root. Some operations may not work as expected.${NC}"
  fi

  show_main_menu
}

main "$@"
