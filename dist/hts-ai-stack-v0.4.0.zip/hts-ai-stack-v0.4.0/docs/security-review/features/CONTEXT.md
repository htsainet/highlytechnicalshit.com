# Security Feature Tracker

Last updated: 2026-04-08 12:00:00

## What happens here

This workspace tracks security hardening proposals for the AI stack — separate from regular
feature development in `docs/development/features/`. Security features address vulnerabilities,
access controls, network hardening, and authentication gaps identified in the threat model or
through security review sessions.

## Process / Workflow

1. **Threat identification** — Security review, audit finding, CVE, or red-team result
2. **Proposal** — Create `SECURITY-###.md` with required metadata (see below)
3. **Release assignment** — Tag feature with target release + add row to [REFERENCES.md](REFERENCES.md)
4. **Implementation** — Built and integrated into install scripts, with tests
5. **User validation** — Tested in actual deployment against the threat scenario
6. **Archive** — After validation passes, `SECURITY-###.md` removed from repo (marks completion)

## Required Security Feature Metadata

Every `SECURITY-###.md` must include these fields at the top:

```markdown
**Priority:** HIGH | MEDIUM | LOW
**Effort:** Estimated hours (e.g., 4-6 hours)
**Risk:** Low | Medium | High — brief justification
**Target Release:** v0.5.0 | v0.6.0+ | Unscheduled
**Threat:** Which threat(s) from the threat model this addresses
**Depends on:** Nothing — or list SECURITY-### prerequisites
**Blocks:** Nothing — or list dependent SECURITY-### items
```

### Field Definitions

| Field | Values | Purpose |
|-------|--------|---------|
| **Priority** | `HIGH` `MEDIUM` `LOW` | Drives ordering within a release |
| **Effort** | Hours estimate | Drives release capacity planning |
| **Risk** | `Low` `Medium` `High` + reason | Flags items needing extra testing |
| **Target Release** | Semver tag or `Unscheduled` | Which release this ships in |
| **Threat** | Free text — maps to threat model | Keeps proposals grounded in real risks |
| **Depends on** | `SECURITY-###` IDs or milestones | What must complete first |
| **Blocks** | `SECURITY-###` IDs | What this unblocks when complete |

### Status Values

Used in [REFERENCES.md](REFERENCES.md) tracking tables:

| Status | Meaning |
|--------|---------|
| `Proposed` | Written up, not yet started |
| `In Progress` | Active development |
| `Validating` | Implemented, under user testing |
| `Complete` | Validated — file removed from repo |

## Files and structure

| File | Description |
|------|-------------|
| `REFERENCES.md` | Security feature index — all `SECURITY-###.md` files listed by release |
| `SECURITY-###.md` | Individual security feature proposals |

## What good looks like

- Every feature maps to one or more named threats from [../CONTEXT.md](../CONTEXT.md)
- Priority reflects attack impact, not implementation complexity
- HIGH priority items are not deferred past one minor release
- Risk field quantifies rollout impact (e.g., "misconfigured UFW rule locks out all access")
- Depends on ordering is respected before implementation begins
- No SECURITY-### file exists without a matching row in REFERENCES.md

## Tools and skills

- **UFW** — Ubuntu Uncomplicated Firewall (`ufw` CLI)
- **fail2ban** — Host-level brute-force protection (`fail2ban-client`)
- **Tailscale ACL editor** — login.tailscale.com → Access Controls
- **Docker networking** — Bridge network segmentation via Compose
- **iptables / DOCKER-USER chain** — Required for Docker-aware fail2ban actions
