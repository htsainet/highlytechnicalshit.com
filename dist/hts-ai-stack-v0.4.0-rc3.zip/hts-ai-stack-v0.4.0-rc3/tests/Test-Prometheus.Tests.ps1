$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/prometheus'
    $script:ComponentScript = Join-Path $script:ComponentDir 'prometheus.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'prometheus.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'prometheus file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists (TDD — needs creation)' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'prometheus manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is prometheus' {
        $script:Manifest.id | Should -Be 'prometheus'
    }

    It 'category is monitoring' {
        $script:Manifest.category | Should -Be 'monitoring'
    }

    It 'profile is monitoring' {
        $script:Manifest.profile | Should -Be 'monitoring'
    }

    It 'dashboard port is 9090' {
        [int]$script:Manifest.dashboard.port | Should -Be 9090
    }

    It 'health URL targets readiness endpoint' {
        $script:Manifest.health.url | Should -Match '/-/ready'
    }

    It 'script path should point to component subfolder (TDD)' {
        $script:Manifest.script | Should -Be 'scripts/components/prometheus/prometheus.sh'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'prometheus port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 9090 is registered in portmap.json' {
        $script:Portmap.ports.'9090' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'9090'.service | Should -Be 'prometheus'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'prometheus compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'prometheus service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'prometheus'
    }

    It 'uses monitoring profile' {
        $script:ComposeContent | Should -Match 'monitoring'
    }
}
