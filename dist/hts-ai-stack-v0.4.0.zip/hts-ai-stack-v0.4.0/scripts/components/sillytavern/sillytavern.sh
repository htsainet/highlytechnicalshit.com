#!/usr/bin/env bash
# scripts/components/sillytavern/sillytavern.sh — SillyTavern character chat frontend
#
# Standalone usage:
#   ./scripts/components/sillytavern/sillytavern.sh              # full: install + configure + start + health
#   ./scripts/components/sillytavern/sillytavern.sh --install    # install only
#   ./scripts/components/sillytavern/sillytavern.sh --configure  # configure only
#   ./scripts/components/sillytavern/sillytavern.sh --start      # start only
#   ./scripts/components/sillytavern/sillytavern.sh --stop       # stop
#   ./scripts/components/sillytavern/sillytavern.sh --restart    # restart (stop + start)
#   ./scripts/components/sillytavern/sillytavern.sh --health     # health check only
#   ./scripts/components/sillytavern/sillytavern.sh --status     # show status + port + health
#   ./scripts/components/sillytavern/sillytavern.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
SILLYTAVERN_CONTAINER="${SILLYTAVERN_CONTAINER:-hts-ai-sillytavern}"
SILLYTAVERN_PORT="${SILLYTAVERN_PORT:-8001}"

# ── Functions ────────────────────────────────────────────────────────────────

# sillytavern_install — Pull the SillyTavern container image
sillytavern_install() {
  step "SillyTavern — install"
  compose_build --profile sillytavern
  ok "SillyTavern image built."
}

# sillytavern_configure — Ensure .env has SillyTavern port + inject config.yaml
sillytavern_configure() {
  step "SillyTavern — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^SILLYTAVERN_PORT=" "$env_file" 2>/dev/null; then
    printf 'SILLYTAVERN_PORT=%s\n' "$SILLYTAVERN_PORT" >> "$env_file"
    info "Added SILLYTAVERN_PORT=${SILLYTAVERN_PORT} to .env"
  fi

  # Inject config.yaml into the config volume with user accounts enabled.
  # User accounts are managed within the SillyTavern UI itself.
  local vol_name
  vol_name=$(docker volume ls --format '{{.Name}}' | grep sillytavern_config || true)
  if [[ -z "$vol_name" ]]; then
    vol_name="hts-ai-stack_sillytavern_config"
    docker volume create "$vol_name" >/dev/null 2>&1 || true
  fi

  docker run --rm -v "${vol_name}:/cfg" busybox sh -c '
    cat > /cfg/config.yaml <<YAML
# SillyTavern configuration — managed by hts-ai-stack
listen: true
port: 8000
whitelistMode: false
basicAuthMode: false
enableUserAccounts: true
autorun: false
enableCorsProxy: false
securityOverride: true
YAML
    chmod 644 /cfg/config.yaml
  '
  info "Injected config.yaml (user accounts enabled)"

  ok "SillyTavern configured (port ${SILLYTAVERN_PORT})."
}

# sillytavern_start — Bring up SillyTavern via compose
sillytavern_start() {
  step "SillyTavern — start"
  compose_up --profile sillytavern
  ok "SillyTavern started on port ${SILLYTAVERN_PORT}."
}

# sillytavern_stop — Bring down SillyTavern
sillytavern_stop() {
  step "SillyTavern — stop"
  compose_down --profile sillytavern
  ok "SillyTavern stopped."
}

# sillytavern_health — Probe the SillyTavern web UI
sillytavern_health() {
  health_probe "SillyTavern :${SILLYTAVERN_PORT}" "http://localhost:${SILLYTAVERN_PORT}/"
}

sillytavern_restart() {
  sillytavern_stop
  sillytavern_start
}

sillytavern_destroy() {
  step "SillyTavern — destroy"
  compose_down --profile sillytavern -v
  ok "SillyTavern destroyed."
}

sillytavern_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=sillytavern" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "SillyTavern is running (port ${SILLYTAVERN_PORT})"
  else
    warn "SillyTavern is not running."
  fi
  sillytavern_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   sillytavern_install   ;;
    configure) sillytavern_configure ;;
    start)     sillytavern_start     ;;
    stop)      sillytavern_stop      ;;
    restart)   sillytavern_restart   ;;
    health)    sillytavern_health    ;;
    status)    sillytavern_status    ;;
    destroy)   sillytavern_destroy   ;;
    default)
      sillytavern_install
      sillytavern_configure
      sillytavern_start
      sillytavern_health
      ;;
  esac
fi
