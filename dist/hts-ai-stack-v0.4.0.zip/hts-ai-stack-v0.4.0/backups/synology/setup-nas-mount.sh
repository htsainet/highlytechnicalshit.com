#!/usr/bin/env bash
# setup-nas-mount.sh — Synology NAS model-cache mount using systemd-creds + TPM2
#
# Creates a oneshot systemd service (nas-llm-cache.service) that mounts a
# Synology SMB/CIFS share using credentials encrypted with TPM2 via
# systemd-creds.  Plaintext credentials are never written to disk.
#
# Requires:
#   - systemd >= 250
#   - TPM2 device (/dev/tpm0 or /dev/tpmrm0)
#   - cifs-utils  (installed automatically if absent)
#
# Usage:
#   sudo ./setup-nas-mount.sh [options]
#
# Options:
#   --nas-ip <ip|host>    NAS address (Tailscale IP strongly recommended)
#   --share  <name>       SMB share name                (default: llm-cache)
#   --user   <username>   Synology SMB account username (prompted if omitted)
#   --domain <domain>     SMB domain                    (default: WORKGROUP)
#   --mount  <path>       Local mount point             (default: /mnt/nas/llm-cache)
#   --uid    <uid>        Mount ownership UID           (default: invoking user)
#   --gid    <gid>        Mount ownership GID           (default: invoking user)
#   --dry-run             Print every action without making changes
#   -h, --help            Show this help

set -euo pipefail

# ── constants ──────────────────────────────────────────────────────────────────
readonly SERVICE_NAME="nas-llm-cache"
readonly UNIT_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
readonly CRED_STORE="/etc/credstore/${SERVICE_NAME}.creds"
# Credentials directory path that systemd creates at service start-time
readonly CRED_PATH="/run/credentials/${SERVICE_NAME}.service/nas-creds"

# ── defaults ───────────────────────────────────────────────────────────────────
MOUNT_POINT="/mnt/nas/llm-cache"
NAS_SHARE="llm-cache"
NAS_DOMAIN="WORKGROUP"
# Use invoking user's UID/GID when run via sudo
_real_user="${SUDO_USER:-$USER}"
MOUNT_UID=$(id -u "$_real_user" 2>/dev/null || echo 1000)
MOUNT_GID=$(id -g "$_real_user" 2>/dev/null || echo 1000)
DRY_RUN=false
NAS_IP=""
NAS_USER=""
NAS_PASS=""

# ── helpers ────────────────────────────────────────────────────────────────────
usage() { grep '^# ' "$0" | sed 's/^# \?//'; exit 0; }
die()    { echo "ERROR: $*" >&2; exit 1; }
info()   { echo "    $*"; }
step()   { echo; echo "==> $*"; }

run() {
  if "$DRY_RUN"; then
    echo "  [dry-run] $*"
  else
    "$@"
  fi
}

# ── argument parsing ───────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --nas-ip)  NAS_IP="$2";     shift 2 ;;
    --share)   NAS_SHARE="$2";  shift 2 ;;
    --user)    NAS_USER="$2";   shift 2 ;;
    --domain)  NAS_DOMAIN="$2"; shift 2 ;;
    --mount)   MOUNT_POINT="$2"; shift 2 ;;
    --uid)     MOUNT_UID="$2";  shift 2 ;;
    --gid)     MOUNT_GID="$2";  shift 2 ;;
    --dry-run) DRY_RUN=true;    shift ;;
    -h|--help) usage ;;
    *) die "Unknown option: $1" ;;
  esac
done

# ── root check ─────────────────────────────────────────────────────────────────
[[ $EUID -eq 0 ]] || die "Must be run as root: sudo $0 $*"

# ── phase 1: prerequisites ─────────────────────────────────────────────────────
check_prereqs() {
  step "Checking prerequisites"

  local sd_ver
  sd_ver=$(systemctl --version | awk 'NR==1{print $2}')
  [[ "$sd_ver" -ge 250 ]] || die "systemd >= 250 required (found ${sd_ver})"
  info "systemd ${sd_ver} ✓"

  if [[ ! -e /dev/tpm0 && ! -e /dev/tpmrm0 ]]; then
    die "No TPM2 device found. /dev/tpm0 and /dev/tpmrm0 are both absent.\n" \
        "TPM2 is required for hardware-bound credential encryption."
  fi
  info "TPM2 present ✓"

  if ! command -v mount.cifs &>/dev/null; then
    info "cifs-utils not found — installing..."
    run apt-get install -y --no-install-recommends cifs-utils
  else
    info "cifs-utils ✓"
  fi
}

# ── phase 2: gather credentials ────────────────────────────────────────────────
gather_credentials() {
  step "Gathering NAS credentials"

  if [[ -z "$NAS_IP" ]]; then
    read -rp "    NAS IP or hostname (Tailscale IP recommended): " NAS_IP
  fi
  [[ -n "$NAS_IP" ]] || die "NAS IP/hostname is required"

  if [[ -z "$NAS_USER" ]]; then
    read -rp "    Synology SMB username: " NAS_USER
  fi
  [[ -n "$NAS_USER" ]] || die "Username is required"

  if [[ -z "$NAS_PASS" ]]; then
    read -rsp "    Password for ${NAS_USER}@${NAS_IP}: " NAS_PASS
    echo
    local confirm
    read -rsp "    Confirm password: " confirm
    echo
    [[ "$NAS_PASS" == "$confirm" ]] || die "Passwords do not match"
  fi

  info "Credentials collected ✓"
}

# ── phase 3: encrypt credentials with TPM2 ────────────────────────────────────
encrypt_credentials() {
  step "Encrypting credentials with TPM2 (systemd-creds)"

  if "$DRY_RUN"; then
    echo "  [dry-run] Would create ${CRED_STORE} bound to this machine's TPM2"
    echo "  [dry-run]   username=${NAS_USER}  domain=${NAS_DOMAIN}  password=<redacted>"
    return
  fi

  run mkdir -p /etc/credstore
  run chmod 700 /etc/credstore

  # Pipe plaintext credentials directly into systemd-creds encrypt.
  # The ciphertext is TPM2-bound: useless if copied to another machine.
  # Plaintext is never written to disk.
  printf 'username=%s\npassword=%s\ndomain=%s\n' \
    "$NAS_USER" "$NAS_PASS" "$NAS_DOMAIN" \
    | systemd-creds encrypt \
        --name=nas-creds \
        --tpm2-device=auto \
        - "$CRED_STORE"

  chmod 600 "$CRED_STORE"
  info "Encrypted credential store: ${CRED_STORE} ✓"
  info "(Bound to this machine's TPM2 — file is useless if copied elsewhere)"

  # Clear from shell memory as soon as possible
  NAS_PASS=""
  unset NAS_PASS 2>/dev/null || true
}

# ── phase 4: create mount point ────────────────────────────────────────────────
create_mount_point() {
  step "Preparing mount point"
  run mkdir -p "$MOUNT_POINT"
  run chown "${MOUNT_UID}:${MOUNT_GID}" "$MOUNT_POINT"
  info "${MOUNT_POINT} ✓"
}

# ── phase 5: write systemd unit ────────────────────────────────────────────────
write_unit() {
  step "Writing systemd unit: ${UNIT_FILE}"

  if [[ -f "$UNIT_FILE" ]] && ! "$DRY_RUN"; then
    echo "    Unit already exists — stopping and replacing."
    systemctl stop  "${SERVICE_NAME}.service" 2>/dev/null || true
    systemctl disable "${SERVICE_NAME}.service" 2>/dev/null || true
  fi

  # Build the CIFS mount options string
  local mount_opts
  mount_opts="credentials=${CRED_PATH},uid=${MOUNT_UID},gid=${MOUNT_GID},iocharset=utf8,nofail,_netdev"

  if "$DRY_RUN"; then
    cat <<DRY
  [dry-run] Would write ${UNIT_FILE}:

[Unit]
Description=NAS LLM model cache – Synology CIFS with TPM-bound credentials
After=network-online.target tailscaled.service
Wants=network-online.target
Before=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
LoadCredentialEncrypted=nas-creds:${CRED_STORE}
ExecStartPre=/bin/mkdir -p ${MOUNT_POINT}
ExecStart=/bin/mount -t cifs //${NAS_IP}/${NAS_SHARE} ${MOUNT_POINT} -o ${mount_opts}
ExecStop=/bin/umount ${MOUNT_POINT}
TimeoutStartSec=30s
TimeoutStopSec=10s

[Install]
WantedBy=multi-user.target
DRY
    return
  fi

  cat > "$UNIT_FILE" <<EOF
[Unit]
Description=NAS LLM model cache – Synology CIFS with TPM-bound credentials
Documentation=https://github.com/htsai-net/hts-ai-stack-release
After=network-online.target tailscaled.service
Wants=network-online.target
Before=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
LoadCredentialEncrypted=nas-creds:${CRED_STORE}
ExecStartPre=/bin/mkdir -p ${MOUNT_POINT}
ExecStart=/bin/mount -t cifs //${NAS_IP}/${NAS_SHARE} ${MOUNT_POINT} -o ${mount_opts}
ExecStop=/bin/umount ${MOUNT_POINT}
TimeoutStartSec=30s
TimeoutStopSec=10s

[Install]
WantedBy=multi-user.target
EOF

  chmod 644 "$UNIT_FILE"
  info "Unit written ✓"
}

# ── phase 6: enable and start ──────────────────────────────────────────────────
enable_and_start() {
  step "Enabling and starting ${SERVICE_NAME}.service"
  run systemctl daemon-reload
  run systemctl enable "${SERVICE_NAME}.service"
  run systemctl start  "${SERVICE_NAME}.service"

  if "$DRY_RUN"; then return; fi

  sleep 2

  if mountpoint -q "$MOUNT_POINT"; then
    info "Mount verified at ${MOUNT_POINT} ✓"
  else
    echo
    echo "WARNING: ${MOUNT_POINT} is not currently mounted."
    echo "  This usually means the NAS is unreachable right now (nofail suppresses boot failure)."
    echo "  Check: journalctl -u ${SERVICE_NAME}.service --no-pager"
  fi
}

# ── main ───────────────────────────────────────────────────────────────────────
echo
echo "NAS Secure Mount Setup — systemd-creds + TPM2"
echo "================================================"
echo "  Service : ${SERVICE_NAME}.service"
echo "  Credstore: ${CRED_STORE}"
if [[ -n "$NAS_IP" ]]; then
  echo "  Target  : //${NAS_IP}/${NAS_SHARE}  →  ${MOUNT_POINT}"
fi
"$DRY_RUN" && echo "  Mode    : DRY RUN (no changes will be made)"

check_prereqs
gather_credentials
encrypt_credentials
create_mount_point
write_unit
enable_and_start

echo
echo "Setup complete."
echo
echo "Useful commands:"
echo "  systemctl status   ${SERVICE_NAME}.service        # mount status"
echo "  journalctl     -u  ${SERVICE_NAME}.service        # mount logs"
echo "  systemctl stop     ${SERVICE_NAME}.service        # unmount"
echo "  systemctl start    ${SERVICE_NAME}.service        # remount"
echo "  systemd-creds cat  --name=nas-creds ${CRED_STORE} # inspect (requires root + TPM)"
