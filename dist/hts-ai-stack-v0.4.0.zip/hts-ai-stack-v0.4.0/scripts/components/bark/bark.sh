#!/usr/bin/env bash
# scripts/components/bark/bark.sh — Bark text-to-audio: install, start, health
#
# Suno AI Bark: transformer-based text-to-audio model producing speech,
# music, sound effects, and non-verbal sounds. MIT licensed, GPU-accelerated.
# VRAM: ~4GB (small models), ~8GB (full models). Fits RTX 3060 comfortably.
#
# Standalone usage:
#   ./scripts/components/bark/bark.sh              # full: install + configure + start + health
#   ./scripts/components/bark/bark.sh --install     # install only
#   ./scripts/components/bark/bark.sh --configure   # configure only
#   ./scripts/components/bark/bark.sh --start       # start only
#   ./scripts/components/bark/bark.sh --stop        # stop
#   ./scripts/components/bark/bark.sh --restart     # restart (stop + start)
#   ./scripts/components/bark/bark.sh --health      # health check only
#   ./scripts/components/bark/bark.sh --status      # show status + port + health
#   ./scripts/components/bark/bark.sh --destroy     # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
BARK_CONTAINER="${BARK_CONTAINER:-hts-ai-bark}"
BARK_PORT="${BARK_PORT:-8400}"

# bark_install — Build the Docker image
bark_install() {
  step "Bark — install"
  compose_build --profile bark
  ok "Bark image built."
}

# bark_configure — Ensure .env has all required keys
bark_configure() {
  step "Bark — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^BARK_PORT=" "$env_file" 2>/dev/null; then
    printf 'BARK_PORT=%s\n' "$BARK_PORT" >> "$env_file"
    info "Added BARK_PORT=${BARK_PORT} to .env"
  fi
  if ! grep -q "^BARK_USE_SMALL_MODELS=" "$env_file" 2>/dev/null; then
    printf 'BARK_USE_SMALL_MODELS=false\n' >> "$env_file"
    info "Added BARK_USE_SMALL_MODELS=false to .env"
  fi
  ok "Bark configured (port ${BARK_PORT})."
}

# bark_start — Bring up via docker compose
bark_start() {
  step "Bark — start"
  compose_up --profile bark
  ok "Bark started on port ${BARK_PORT}."
}

# bark_stop — Bring down via docker compose
bark_stop() {
  step "Bark — stop"
  compose_down --profile bark
  ok "Bark stopped."
}

# bark_health — Probe the health endpoint
bark_health() {
  health_probe "Bark :${BARK_PORT}" "http://localhost:${BARK_PORT}/health"
}

# bark_restart — Stop then start
bark_restart() {
  bark_stop
  bark_start
}

# bark_destroy — Remove containers and volumes
bark_destroy() {
  step "Bark — destroy"
  compose_down --profile bark -v
  ok "Bark destroyed."
}

# bark_status — Show running status
bark_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=bark" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Bark is running (port ${BARK_PORT})"
  else
    warn "Bark is not running."
  fi
  bark_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   bark_install   ;;
    configure) bark_configure ;;
    start)     bark_start     ;;
    stop)      bark_stop      ;;
    restart)   bark_restart   ;;
    health)    bark_health    ;;
    status)    bark_status    ;;
    destroy)   bark_destroy   ;;
    default)
      bark_install
      bark_configure
      bark_start
      bark_health
      ;;
  esac
fi
