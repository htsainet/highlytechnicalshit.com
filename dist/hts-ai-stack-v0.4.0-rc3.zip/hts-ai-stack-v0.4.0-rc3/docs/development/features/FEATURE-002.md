# KoboldCpp + SillyTavern Bundle (Creative Stack)

> **Superseded** — merged into [FEATURE-005](FEATURE-005.md) (Deferred Services).
> All KoboldCpp + SillyTavern architecture and bundle details now live there.

**Priority:** ~~MEDIUM~~ → Superseded
**Target Release:** v0.6.0 (via FEATURE-005)
**Status:** Superseded → FEATURE-005
**Effort:** Half-day implementation, separate testing pass
**Risk:** Low — additive optional services, no impact on existing stack
**Depends on:** `feature/dual-inference` merged (llama-swap router, BitNet CPU backend)
**Blocks:** Nothing

## Problem

The current stack serves assistant/coding workloads (Ollama + Open WebUI) and agent workloads (NemoClaw). There is no support for creative writing use cases, which benefit from specialised models and a purpose-built frontend (SillyTavern).

## Solution

Add **KoboldCpp** as a GPU inference backend for creative models and **SillyTavern** as the frontend, both optional and routed through llama-swap. Combined with NemoClaw for agent work and BitNet for CPU inference, this creates a zero-contention stack:

- GPU is dedicated to KoboldCpp (full 12 GB VRAM)
- CPU handles agent workloads via BitNet
- No Ollama in this configuration — no VRAM swapping needed

## Architecture

```text
            llama-swap :8081
           (unified router)
        ┌────────┼────────┐
        ▼                 ▼
     BitNet           KoboldCpp
     (CPU)            (GPU, 12 GB)
        ▲                 ▲
        │                 │
     NemoClaw          SillyTavern
     sandbox             :8000
     (agent tasks)    (creative)
```

### Port Mapping

| Service | Host Port | Container Port | Notes |
|---------|-----------|----------------|-------|
| `hts-ai-koboldcpp` | *(none)* | `5001` | Internal only — llama-swap routes to it |
| `hts-ai-sillytavern` | `8000` | `8000` | User-facing creative frontend |
| `hts-ai-llama-swap` | `8081` | `8080` | Unified router (existing) |
| `hts-ai-bitnet-cpu` | *(none)* | `8080` | Internal only (existing) |

### llama-swap Routing

```yaml
# config/llama-swap.yaml additions
models:
  # Creative model → KoboldCpp
  mistral-nemo-12b:
    proxy: http://hts-ai-koboldcpp:5001
    # or whichever GGUF the user configures

  # Agent model → BitNet (existing)
  bitnet:
    proxy: http://hts-ai-bitnet-cpu:8080
```

## Bundle: `scripts/bundles/creative.sh`

New bundle providing the creative + agent stack without Ollama:

```text
1. HOST SETUP
   ├── scripts/host/nvidia.sh
   ├── scripts/host/docker.sh
   ├── scripts/host/node.sh
   └── scripts/host/tools.sh

2. CORE SERVICES
   ├── scripts/components/koboldcpp/koboldcpp.sh      (NEW — GPU creative inference)
   ├── scripts/components/bitnet/bitnet.sh         (CPU agent inference)
   ├── scripts/components/llama-swap/llama-swap.sh     (unified router)
   ├── scripts/components/sillytavern/sillytavern.sh    (creative frontend)
   └── scripts/components/gitea/gitea.sh          (self-hosted Git)

3. OPTIONAL
   ├── scripts/components/nemoclaw/nemoclaw.sh       (if NEMOCLAW_DEPLOY=true)
   └── scripts/components/dashboard/dashboard.sh      (if DASHBOARD_ENABLED=true)
```

## New Files

### Docker

- `docker/koboldcpp/Dockerfile` — KoboldCpp with CUDA support
- `docker/koboldcpp/entrypoint.sh` — Model download + server startup

### Component Script

- `scripts/components/koboldcpp/koboldcpp.sh` — Install, configure, start, health, stop

### Bundle

- `scripts/bundles/creative.sh` — Orchestrates the creative stack

### Config

- `.env` additions: `KOBOLDCPP_ENABLED`, `KOBOLDCPP_MODEL`, `KOBOLDCPP_HF_REPO`
- `docker-compose.yml` — New `koboldcpp` service with `profiles: [koboldcpp]`
- `config/llama-swap.yaml` — Route for creative model

## Docker Compose Service (Draft)

```yaml
koboldcpp:
  build: ./docker/koboldcpp
  image: hts-ai-koboldcpp
  container_name: hts-ai-koboldcpp
  labels:
    <<: *stack-labels
    com.htsai.role: inference
    com.htsai.compute: gpu
  profiles: [koboldcpp]
  restart: unless-stopped
  volumes:
    - koboldcpp_models:/app/models
  networks:
    - ai-network
  environment:
    - KOBOLDCPP_MODEL=${KOBOLDCPP_MODEL:-mistral-nemo-instruct-2407}
    - KOBOLDCPP_HF_REPO=${KOBOLDCPP_HF_REPO:-bartowski/Mistral-Nemo-Instruct-2407-GGUF}
    - KOBOLDCPP_QUANT=${KOBOLDCPP_QUANT:-Q4_K_M}
    - KOBOLDCPP_CONTEXT=${KOBOLDCPP_CONTEXT:-8192}
    - KOBOLDCPP_GPU_LAYERS=${KOBOLDCPP_GPU_LAYERS:-99}
  healthcheck:
    test: ["CMD", "curl", "-sf", "http://localhost:5001/api/v1/model"]
    interval: 30s
    timeout: 10s
    retries: 5
    start_period: 60s
  deploy:
    resources:
      reservations:
        devices:
          - driver: nvidia
            count: all
            capabilities: [gpu]
```

## SillyTavern Wiring

SillyTavern connects to llama-swap as an OpenAI-compatible backend:

- API type: **Chat Completions (OpenAI)**
- Base URL: `http://hts-ai-llama-swap:8080/v1`
- API key: `not-needed`
- Model: user selects from llama-swap model list (sees both `bitnet` and `mistral-nemo-12b`)

## VRAM Budget

| Component | VRAM | Notes |
|-----------|------|-------|
| KoboldCpp (Mistral Nemo 12B Q4_K_M) | ~7-8 GB | Full GPU, no contention |
| BitNet | 0 GB | CPU-only |
| SillyTavern | 0 GB | Node.js frontend |
| NemoClaw | 0 GB | Uses BitNet via llama-swap |
| **Total** | **~7-8 GB** | **Fits 12 GB RTX 3060** |

## Implementation Checklist

- [ ] Create `docker/koboldcpp/Dockerfile` (CUDA base + KoboldCpp build)
- [ ] Create `docker/koboldcpp/entrypoint.sh` (model download + launch)
- [ ] Add `koboldcpp` service to `docker-compose.yml`
- [ ] Create `scripts/components/koboldcpp/koboldcpp.sh` (lifecycle script)
- [ ] Create `scripts/bundles/creative.sh` (bundle orchestrator)
- [ ] Add `KOBOLDCPP_ENABLED` and related keys to wizard and `.env`
- [ ] Add KoboldCpp model route to `config/llama-swap.yaml`
- [ ] Wire SillyTavern to llama-swap (update SillyTavern component config)
- [ ] Update `prerequisites.json` if new host packages are needed
- [ ] Pester test: `Test-StackValidation.Tests.ps1` covers KoboldCpp health
- [ ] Add KoboldCpp component manifest for converge.sh (replaces old full-stack.sh boolean)
