#!/usr/bin/env bash
# scripts/utils/refresh-status.sh — Probe enabled services and refresh dashboard status
#
# Reads config/stack.json to determine which services are enabled, probes each
# one, then writes resources/dashboard/install-status.json with phase "complete"
# so the dashboard exits install mode and transitions to live port probing.
#
# Usage:
#   ./scripts/utils/refresh-status.sh             # probe + write status file
#   ./scripts/utils/refresh-status.sh --clear     # delete status file (live probes only)
#   ./scripts/utils/refresh-status.sh --dry-run   # probe + print, no file write
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

load_env

STATUS_FILE="$REPO_DIR/resources/dashboard/install-status.json"
STACK_JSON="$REPO_DIR/config/stack.json"
DRY_RUN=false
CLEAR_MODE=false

# ── Arg parsing ───────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run) DRY_RUN=true; shift ;;
    --clear)   CLEAR_MODE=true; shift ;;
    *) shift ;;
  esac
done

# ── Clear mode ────────────────────────────────────────────────────────────────
if [[ "$CLEAR_MODE" == "true" ]]; then
  step "refresh-status — clear"
  rm -f "$STATUS_FILE"
  ok "install-status.json removed — dashboard will use live port probing."
  exit 0
fi

step "refresh-status — probing services"

# ── Read enabled flags from stack.json ───────────────────────────────────────
_jq() {
  python3 -c "
import json, sys
d = json.load(open('$STACK_JSON'))
try:
    keys = '$1'.split('.')
    v = d
    for k in keys:
        v = v[k]
    print(str(v).lower())
except (KeyError, TypeError):
    print('false')
"
}

MONITORING_ENABLED=$(_jq "monitoring.enabled")
OPENSPACE_ENABLED=$(_jq "openspace.enabled")
DEERFLOW_ENABLED=$(_jq "deerflow.enabled")
IMAGES_ENGINE=$(_jq "images.engine")
[[ "$IMAGES_ENGINE" == "comfyui" ]] && COMFYUI_ENABLED="true" || COMFYUI_ENABLED="false"
UNSLOTH_ENABLED=$(_jq "unsloth.enabled")
PORTAINER_ENABLED=$(_jq "portainer.enabled")
LMSTUDIO_ENABLED=$(_jq "inference.lmstudio.enabled")
NEMOCLAW_ENABLED=$(_jq "services.nemoclaw.deploy")
SANDBOX_ENGINE=$(_jq "sandbox.engine")

# ── HTTP probe (python3, no curl dependency) ──────────────────────────────────
# _probe <url> — echoes "running" or "error"
_probe() {
  local url="$1"
  python3 -c "
import urllib.request, sys
try:
    r = urllib.request.urlopen('$url', timeout=5)
    sys.exit(0 if r.status < 500 else 1)
except Exception:
    sys.exit(1)
" 2>/dev/null && echo "running" || echo "error"
}

# _probe_port <host> <port> — TCP connect probe; echoes "running" or "error"
_probe_port() {
  local host="${1:-localhost}" port="$2"
  python3 -c "
import socket, sys
try:
    s = socket.create_connection(('$host', $port), timeout=5)
    s.close(); sys.exit(0)
except Exception:
    sys.exit(1)
" 2>/dev/null && echo "running" || echo "error"
}

# ── Service probe definitions ─────────────────────────────────────────────────
# Each entry: installId | state_variable
declare -A SVC_STATUS=()
declare -A SVC_INCLUDED=()

_include() {
  local id="$1"
  SVC_INCLUDED["$id"]=1
}

_probe_svc() {
  local id="$1" url="$2"
  info "  Probing ${id} → ${url}"
  SVC_STATUS["$id"]=$(_probe "$url")
}

_probe_svc_port() {
  local id="$1" port="$2"
  info "  Probing ${id} → :${port} (TCP)"
  SVC_STATUS["$id"]=$(_probe_port "localhost" "$port")
}

# ── Always-on services ────────────────────────────────────────────────────────
# IDs must match "installId" in resources/dashboard/services.json
_include "ollama"
_probe_svc "ollama" "http://localhost:${OLLAMA_PORT:-11434}/api/tags"

_include "bitnet"
_probe_svc_port "bitnet" "8082"

_include "llama-swap"
_probe_svc "llama-swap" "http://localhost:${LLAMA_SWAP_PORT:-8081}/health"

_include "open-webui"
_probe_svc "open-webui" "http://localhost:3000/"

# dashboard and tailscale are not probed here — dashboard serves this
# file (can't probe itself) and tailscale is UDP/systemd (no TCP port).

# ── Monitoring stack ──────────────────────────────────────────────────────────
if [[ "$MONITORING_ENABLED" == "true" ]]; then
  _include "prometheus"
  _probe_svc "prometheus" "http://localhost:9090/-/ready"

  _include "grafana"
  _probe_svc "grafana" "http://localhost:3100/api/health"
fi

if [[ "$PORTAINER_ENABLED" == "true" ]]; then
  _include "portainer"
  _probe_svc_port "portainer" "9000"
fi

# ── LM Studio (host process) ──────────────────────────────────────────────────
if [[ "$LMSTUDIO_ENABLED" == "true" ]]; then
  _include "lmstudio"
  _probe_svc_port "lmstudio" "1234"
fi

# ── Agent sandboxes ───────────────────────────────────────────────────────────
if [[ "$SANDBOX_ENGINE" == "htsclaw" || "$SANDBOX_ENGINE" == "both" ]]; then
  _include "htsclaw"
  _probe_svc "htsclaw" "http://localhost:${HTSCLAW_PORT:-18790}/healthz"
fi

if [[ "$SANDBOX_ENGINE" == "nemoclaw" || "$SANDBOX_ENGINE" == "both" || "$NEMOCLAW_ENABLED" == "true" ]]; then
  _include "nemoclaw"
  _probe_svc_port "nemoclaw" "${NEMOCLAW_PORT:-18789}"
fi

# ── Agent applications ────────────────────────────────────────────────────────
if [[ "$OPENSPACE_ENABLED" == "true" ]]; then
  _include "openspace"
  _probe_svc "openspace" "http://localhost:${OPENSPACE_PORT:-5000}/sse"
fi

if [[ "$DEERFLOW_ENABLED" == "true" ]]; then
  _include "deerflow"
  _probe_svc "deerflow" "http://localhost:${DEERFLOW_PORT:-3002}/"
fi

# ── Creative & training ───────────────────────────────────────────────────────
if [[ "$COMFYUI_ENABLED" == "true" ]]; then
  _include "comfyui"
  _probe_svc "comfyui" "http://localhost:${COMFYUI_PORT:-8188}/"
fi

if [[ "$UNSLOTH_ENABLED" == "true" ]]; then
  _include "unsloth"
  _probe_svc "unsloth" "http://localhost:${UNSLOTH_PORT:-8888}/"
fi

# ── Build JSON ────────────────────────────────────────────────────────────────
step "refresh-status — building status JSON"

RUNNING=0; TOTAL=0; ERRORS=()
for id in "${!SVC_INCLUDED[@]}"; do
  TOTAL=$(( TOTAL + 1 ))
  state="${SVC_STATUS[$id]:-error}"
  if [[ "$state" == "running" ]]; then
    RUNNING=$(( RUNNING + 1 ))
  else
    ERRORS+=("$id")
  fi
done

_build_json() {
  python3 -c "
import json, sys
ids = sys.argv[1].split(',')
statuses = dict(p.split('=',1) for p in sys.argv[2].split(',') if '=' in p)
d = {
    'phase': 'complete',
    'updated': __import__('datetime').datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ'),
    'services': {i: statuses.get(i, 'error') for i in ids},
    'messages': {}
}
print(json.dumps(d, indent=2))
" "$1" "$2"
}

INCLUDED_IDS=$(IFS=','; echo "${!SVC_INCLUDED[*]}")
STATUS_PAIRS=""
for id in "${!SVC_INCLUDED[@]}"; do
  STATUS_PAIRS+="${id}=${SVC_STATUS[$id]:-error},"
done
STATUS_PAIRS="${STATUS_PAIRS%,}"

JSON=$(_build_json "$INCLUDED_IDS" "$STATUS_PAIRS")

# ── Output ────────────────────────────────────────────────────────────────────
echo
info "Results:"
for id in $(echo "$INCLUDED_IDS" | tr ',' '\n' | sort); do
  state="${SVC_STATUS[$id]:-error}"
  if [[ "$state" == "running" ]]; then
    echo "  [✓] ${id}"
  else
    echo "  [✗] ${id}"
  fi
done
echo

if [[ "$DRY_RUN" == "true" ]]; then
  info "Dry run — no file written."
  echo "$JSON"
  exit 0
fi

printf '%s\n' "$JSON" > "$STATUS_FILE"
ok "install-status.json updated — ${RUNNING}/${TOTAL} services running."

if [[ ${#ERRORS[@]} -gt 0 ]]; then
  warn "Services not responding: ${ERRORS[*]}"
fi
