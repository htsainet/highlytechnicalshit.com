#!/usr/bin/env bash
# scripts/components/portainer/portainer.sh — Portainer: install, configure, start, health
#
# Docker container management UI.
#
# Standalone usage:
#   ./scripts/components/portainer/portainer.sh              # full: install + configure + start + health
#   ./scripts/components/portainer/portainer.sh --install    # install only (build image)
#   ./scripts/components/portainer/portainer.sh --configure  # configure only
#   ./scripts/components/portainer/portainer.sh --start      # start only
#   ./scripts/components/portainer/portainer.sh --stop       # stop
#   ./scripts/components/portainer/portainer.sh --restart    # restart (stop + start)
#   ./scripts/components/portainer/portainer.sh --health     # health check only
#   ./scripts/components/portainer/portainer.sh --status     # show status + port + health
#   ./scripts/components/portainer/portainer.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
PORTAINER_PORT="${PORTAINER_PORT:-9000}"
PORTAINER_HTTPS_PORT="${PORTAINER_HTTPS_PORT:-9443}"

# ── Functions ────────────────────────────────────────────────────────────────

portainer_install() {
  step "Portainer — install"
  local dockerfile="$REPO_DIR/docker/portainer/Dockerfile"
  if [[ ! -f "$dockerfile" ]]; then
    fail "Portainer Dockerfile not found: $dockerfile"
    return 1
  fi
  compose_build --profile portainer
  ok "Portainer image built."
}

portainer_configure() {
  step "Portainer — configure"
  info "HTTP port:  ${PORTAINER_PORT}"
  info "HTTPS port: ${PORTAINER_HTTPS_PORT}"
  ok "Portainer configured."
}

portainer_start() {
  step "Portainer — start"
  compose_up --profile portainer
  ok "Portainer started on port ${PORTAINER_PORT}."
}

portainer_stop() {
  step "Portainer — stop"
  compose_down --profile portainer
  ok "Portainer stopped."
}

# Portainer uses NONE healthcheck in compose — probe the HTTP API
portainer_health() {
  local label="Portainer :${PORTAINER_PORT}"
  printf "  %-35s" "$label"
  if curl -sf "http://localhost:${PORTAINER_PORT}/api/system/status" >/dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
  else
    echo -e "${RED}FAIL${NC} (curl http://localhost:${PORTAINER_PORT}/api/system/status)"
    return 1
  fi
}

portainer_restart() {
  portainer_stop
  portainer_start
}

portainer_destroy() {
  step "Portainer — destroy"
  compose_down --profile portainer -v
  ok "Portainer destroyed."
}

portainer_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=portainer" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Portainer is running (HTTP ${PORTAINER_PORT}, HTTPS ${PORTAINER_HTTPS_PORT})"
  else
    warn "Portainer is not running."
  fi
  portainer_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   portainer_install   ;;
    configure) portainer_configure ;;
    start)     portainer_start     ;;
    stop)      portainer_stop      ;;
    restart)   portainer_restart   ;;
    health)    portainer_health    ;;
    status)    portainer_status    ;;
    destroy)   portainer_destroy   ;;
    default)
      portainer_install
      portainer_configure
      portainer_start
      portainer_health
      ;;
  esac
fi
