#!/usr/bin/env bash
# scripts/components/nemoclaw/diag-llamaswap-route.sh
#
# Diagnose nemoclaw → llama-swap timeouts. Read-only. No changes to host or sandbox.
#
# Usage: ./scripts/components/nemoclaw/diag-llamaswap-route.sh
#
# Tests three layers in order:
#   1. UFW rules — is the Docker subnet → llama-swap allow rule present?
#   2. Host-side reachability — does llama-swap respond on localhost:8081?
#   3. Sandbox-side reachability — can the sandbox reach host.openshell.internal:8081?
#
# If layer 2 passes but layer 3 fails → networking/UFW issue.
# If both 2 and 3 fail → llama-swap is the problem.

set -uo pipefail

GATEWAY="${NEMOCLAW_GATEWAY_NAME:-nemoclaw}"
SANDBOX="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"
SWAP_PORT="${LLAMA_SWAP_PORT:-8081}"

bar() { printf '\n── %s ─────────────────────────────────────────\n' "$*"; }

bar "1. UFW rules touching :${SWAP_PORT} or Docker/Tailscale subnets"
if command -v ufw >/dev/null 2>&1; then
  sudo ufw status numbered 2>/dev/null | grep -E "${SWAP_PORT}|172\.16|100\.64" || echo "  (no matching rules)"
else
  echo "  ufw not installed"
fi

bar "2. Host → llama-swap (localhost:${SWAP_PORT}/v1/models)"
echo "  HTTP code:"
curl -sS -o /tmp/diag-llamaswap-host.out -w "    %{http_code}  in %{time_total}s\n" \
     -m 5 "http://localhost:${SWAP_PORT}/v1/models" || echo "    (curl failed: $?)"
echo "  Body (first 300 chars):"
head -c 300 /tmp/diag-llamaswap-host.out 2>/dev/null | sed 's/^/    /'
echo
rm -f /tmp/diag-llamaswap-host.out

bar "3. llama-swap container status"
if command -v docker >/dev/null 2>&1; then
  docker ps --filter name=llama-swap --format '  {{.Names}}\t{{.Status}}' || true
  echo "  Last 10 log lines:"
  docker logs --tail 10 hts-ai-llama-swap 2>&1 | sed 's/^/    /' || true
else
  echo "  docker not in PATH"
fi

bar "4. Sandbox → host.openshell.internal:${SWAP_PORT}/v1/models"
if command -v openshell >/dev/null 2>&1; then
  echo "  Running curl from inside sandbox '${SANDBOX}' (gateway '${GATEWAY}')..."
  # openshell 0.0.36 syntax: `sandbox exec` takes the sandbox via -s/--sandbox
  # (or last-used by default). Positional args after `--` go to the command.
  openshell -g "${GATEWAY}" sandbox exec -s "${SANDBOX}" -- \
    curl -sS -m 10 -w '\n    HTTP %{http_code}  in %{time_total}s\n' \
    "http://host.openshell.internal:${SWAP_PORT}/v1/models" 2>&1 | head -c 800 | sed 's/^/    /'
  echo
else
  echo "  openshell not in PATH"
fi

bar "5. Sandbox DNS — does host.openshell.internal resolve?"
if command -v openshell >/dev/null 2>&1; then
  openshell -g "${GATEWAY}" sandbox exec -s "${SANDBOX}" -- \
    sh -c 'getent hosts host.openshell.internal 2>&1 || nslookup host.openshell.internal 2>&1 | head -5' \
    2>&1 | sed 's/^/  /'
fi

bar "Verdict guide"
cat <<'EOF'
  - Layer 2 (host) works, layer 4 (sandbox) fails  → networking / UFW / docker bridge
  - Layer 2 fails, layer 4 fails                   → llama-swap is the problem
  - Layer 2 works, layer 4 works                   → nemoclaw verify path / timeout-only issue
  - Layer 5 fails to resolve                       → sandbox missing host-gateway DNS
EOF
