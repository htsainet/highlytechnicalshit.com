# Central Model Registry – Implementation Plan

## Goal
Create a **single source of truth** for all model files required by the AI stack (Stable Diffusion checkpoints, VAE files, Whisper ASR models, Open‑LLM‑VTuber avatars, etc.) and expose a **generic Bash library** so every component can fetch models in a uniform way.

## Steps
1. **Add `model-registry.json`** at the repo root.
   * Structure: `{ "service": { "model_type": { "default": "...", "options": { "filename": { "url": "…", "license": "…", "trust": "…" } } } }`.
   * Populate it with Stable Diffusion entries (checkpoint & VAE) and a placeholder for Whisper.
2. **Create `scripts/lib/model.sh`** – a lightweight library that:
   * Resolves the repository root (`REPO_DIR`).
   * Provides `model_get_url <service> <type> <filename>` to fetch the URL from the JSON.
   * Provides `model_get_license` (optional) for compliance checks.
   * Provides a generic `model_download_if_missing` stub that components can call or extend.
3. **Update component manifests** (Stable Diffusion as a proof‑of‑concept):
   * Replace hard‑coded `options` arrays with `options_source` and `default_source` JSON‑Pointer strings pointing into `model-registry.json`.
   * Keep the `required` flag to enforce mandatory models.
4. **Modify component scripts** to source the new library and use the generic download function.
   * In `stable-diffusion.sh`, replace the internal `_sd_download_if_missing` loop with a call to `model_download_if_missing "stable_diffusion" "checkpoint" "$SD_CHECKPOINT" "$sd_volume" "$NAS_SD_CACHE"` (and similarly for VAE).
   * Add the same pattern to any other component that needs models (e.g., Whisper, VTuber).
5. **Wizard integration** – Extend the wizard loader (already present in `scripts/lib/common.sh`) to recognise the new keys `options_source` and `default_source`. It will:
   * Load `model-registry.json`.
   * Resolve the JSON‑Pointer, extract the option list (filenames), and default value.
   * Present a `select` prompt to the user.
6. **Documentation** – Add `scripts/lib/model/CONTEXT.md` and `resources.md` explaining the library, its API, and how to extend it.
   * Add `docs/model-registry/CONTEXT.md` and `resources.md` for high‑level overview.
7. **Testing** – Add a small unit test under `tests/` that loads the library, queries a known entry, and verifies the URL matches the registry.
8. **Compliance check** – Update Phase 2 review scripts to verify that any model referenced by a component has a non‑`unknown` `trust` level and an acceptable license.

## Timeline (one dev day)
* **0‑2 h** – Add `model-registry.json` and write the first entries.
* **2‑4 h** – Implement `model.sh` and basic helper functions.
* **4‑6 h** – Update Stable Diffusion manifest and script; test locally.
* **6‑7 h** – Add documentation files (`CONTEXT.md`, `resources.md`).
* **7‑8 h** – Stub out the same pattern for Whisper (no code change required beyond manifest).
* **8‑9 h** – Run the wizard, ensure prompts resolve correctly; fix any JSON‑Pointer bugs.
* **9‑10 h** – Add unit test and run the test suite.

## Benefits
* **Consistency** – All components use the same download logic.
* **Security** – Central registry makes it easy to audit licenses and trust levels.
* **User experience** – The wizard shows a single selectable list per model type, reducing confusion.
* **Future‑proof** – Adding a new model only requires updating `model-registry.json`; no script changes.

---

Feel free to let me know if you’d like any part of the plan expanded, or if you want me to start committing the concrete changes (manifest updates, script modifications, documentation).