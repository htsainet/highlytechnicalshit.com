#!/usr/bin/env bash
# ai_stack_setup.sh — AI Stack interactive configurator (whiptail)
#
# All UI is provided by whiptail, which is pre-installed on every
# Ubuntu system (no Python deps, no pip, no venv).
# Python3 is used ONLY at the very end to write the JSON — that's
# always available without any extra packages.
#
# Writes: config/stack.json  (committed, no secrets)
#         config/stack.secrets.json  (gitignored, chmod 600)
#         config/backups/YYYYMMDD-HHMMSS/  (timestamped snapshots)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
REPO_DIR="$REPO_ROOT"   # manifest-loader.sh expects REPO_DIR
CONFIG_DIR="$REPO_ROOT/config"
BACKUP_DIR="$CONFIG_DIR/backups"
STACK_JSON="$CONFIG_DIR/stack.json"
SECRETS_JSON="$CONFIG_DIR/stack.secrets.json"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; BOLD='\033[1m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }

TOTAL=8
W=72   # dialog width

# ── Manifest system ───────────────────────────────────────────────────────────
# shellcheck source=../../scripts/lib/manifest-loader.sh
source "$REPO_ROOT/scripts/lib/manifest-loader.sh"
manifest_load_all

# GPU availability (used to annotate GPU-required services in checklists)
GPU_AVAILABLE=false
nvidia-smi &>/dev/null 2>&1 && GPU_AVAILABLE=true

# Tracking maps populated by the dynamic checklist (Phase 4)
declare -A ENABLED_SERVICES   # id -> "true"/"false"
declare -A PROMPT_RESULTS     # "id.key" -> value

# ── Source detection file written by 00-check-conflicts.sh --detect-only ──────
_DETECT_FILE="${TMPDIR:-/tmp}/htsai-detected.env"
_DETECT_MAX_AGE=300   # seconds — discard stale data older than 5 minutes
if [[ -f "$_DETECT_FILE" ]]; then
  # shellcheck source=/dev/null
  source "$_DETECT_FILE"
  _now=$(date +%s)
  _age=$(( _now - ${HTSAI_DETECTED_AT:-0} ))
  if [[ $_age -gt $_DETECT_MAX_AGE ]]; then
    info "Detection data is stale ($_age s old) — ignoring. Re-run 00-check-conflicts.sh to refresh."
    HTSAI_DETECTED_AT=0
    HTSAI_DETECTED_OLLAMA=false
    HTSAI_OLLAMA_PORT_CONFLICT=false
    HTSAI_DETECTED_SD=false
    HTSAI_SD_PORT_CONFLICT=false
    HTSAI_DETECTED_BITNET=false
    HTSAI_DETECTED_VOICE=false
    HTSAI_DETECTED_NEMOCLAW=false
    HTSAI_DETECTED_OPENSHELL=false
  fi
fi
HTSAI_DETECTED_OLLAMA="${HTSAI_DETECTED_OLLAMA:-false}"
HTSAI_OLLAMA_PORT_CONFLICT="${HTSAI_OLLAMA_PORT_CONFLICT:-false}"
HTSAI_DETECTED_SD="${HTSAI_DETECTED_SD:-false}"
HTSAI_SD_PORT_CONFLICT="${HTSAI_SD_PORT_CONFLICT:-false}"
HTSAI_DETECTED_BITNET="${HTSAI_DETECTED_BITNET:-false}"
HTSAI_DETECTED_VOICE="${HTSAI_DETECTED_VOICE:-false}"
HTSAI_DETECTED_NEMOCLAW="${HTSAI_DETECTED_NEMOCLAW:-false}"
HTSAI_DETECTED_OPENSHELL="${HTSAI_DETECTED_OPENSHELL:-false}"
HTSAI_DETECTED_OPENWEBUI="${HTSAI_DETECTED_OPENWEBUI:-false}"

# ── whiptail helpers ──────────────────────────────────────────────────────────

# Single-select menu. Exits script cleanly if user presses Escape/Cancel.
# Usage: wt_menu STEP TITLE PROMPT tag1 label1 [tag2 label2 ...]
wt_menu() {
  local step="$1" title="$2" prompt="$3"
  shift 3
  local result
  result=$(whiptail --title "[$step/$TOTAL] $title" \
                    --menu "$prompt" 18 $W 10 "$@" \
                    3>&1 1>&2 2>&3) || { echo -e "\n  Setup cancelled.\n"; exit 0; }
  echo "$result"
}

# Multi-select checklist. Cancel/Escape → empty selection (all optional).
# Usage: wt_check STEP TITLE PROMPT tag1 label1 ON/OFF ...
wt_check() {
  local step="$1" title="$2" prompt="$3"
  shift 3
  local result
  result=$(whiptail --title "[$step/$TOTAL] $title" \
                    --checklist "$prompt\n(Space=toggle, Enter=confirm)" \
                    18 $W 8 "$@" \
                    3>&1 1>&2 2>&3) || true
  # Strip surrounding double-quotes whiptail adds to each selected value
  echo "$result" | tr -d '"'
}

# Text input box.
# Usage: wt_input STEP TITLE PROMPT [default]
wt_input() {
  local step="$1" title="$2" prompt="$3" default="${4:-}"
  whiptail --title "[$step/$TOTAL] $title" \
           --inputbox "$prompt" 10 $W "$default" \
           3>&1 1>&2 2>&3 || { echo -e "\n  Setup cancelled.\n"; exit 0; }
}

# Yes/No question → echoes "true" or "false".
# Usage: wt_yesno STEP TITLE PROMPT [yes|no]
wt_yesno() {
  local step="$1" title="$2" prompt="$3" default="${4:-yes}"
  local extra_flag=""
  [[ "$default" == "no" ]] && extra_flag="--defaultno"
  # shellcheck disable=SC2086
  if whiptail --title "[$step/$TOTAL] $title" \
              --yesno "$prompt" 10 $W $extra_flag \
              3>&1 1>&2 2>&3; then
    echo "true"
  else
    echo "false"
  fi
}

# ── Manifest-driven helper functions ─────────────────────────────────────────

# _build_checklist_args <category> [stack_json_path]
# Populates global CHECKLIST_ARGS array with (tag label ON/OFF ...) triples
# for all toggleable manifests in <category>.
# Pre-populates ON/OFF from existing stack.json if provided (reconfigure flow).
_build_checklist_args() {
  local category="$1"
  local stack_json="${2:-}"
  CHECKLIST_ARGS=()

  for id in "${COMPONENT_ORDER[@]}"; do
    local file; file="$(manifest_file "$id")"
    local toggleable; toggleable=$(jq -r '.config.toggleable // false' "$file")
    [[ "$toggleable" != "true" ]] && continue

    local cat; cat=$(jq -r '.category // ""' "$file")
    [[ "$cat" != "$category" ]] && continue

    # Skip host-interactive services — handled separately
    local install_type; install_type=$(component_install_type "$id")
    [[ "$install_type" == "host-interactive" ]] && continue

    local display; display=$(component_display_name "$id")
    local requires_gpu; requires_gpu=$(jq -r '.requires_gpu // false' "$file")

    # GPU annotation
    if [[ "$requires_gpu" == "true" ]] && [[ "$GPU_AVAILABLE" == "false" ]]; then
      display="${display} [no GPU]"
    fi

    # Determine ON/OFF: prefer existing stack.json, fall back to wizard_default
    local state="OFF"
    if [[ -n "$stack_json" && -f "$stack_json" ]]; then
      local read_path; read_path=$(jq -r '.config.read_path // ""' "$file")
      if [[ -n "$read_path" ]]; then
        local current_val
        current_val=$(python3 -c "
import json, sys
try:
    d = json.load(open('$stack_json'))
    keys = '${read_path#.}'.split('.')
    for k in keys:
        d = d[k]
    cfg_type = '$(jq -r '.config.type // ""' "$file")'
    if cfg_type == 'array_member':
        member = '$(jq -r '.config.member_value // ""' "$file")'
        print('true' if isinstance(d, list) and member in d else 'false')
    else:
        print('true' if d else 'false')
except:
    print('default')
" 2>/dev/null)
        [[ "$current_val" == "true" ]] && state="ON"
        [[ "$current_val" == "default" ]] && {
          local wdefault; wdefault=$(component_wizard_default "$id")
          [[ "$wdefault" == "true" ]] && state="ON"
        }
      fi
    else
      local wdefault; wdefault=$(component_wizard_default "$id")
      [[ "$wdefault" == "true" ]] && state="ON"
    fi

    CHECKLIST_ARGS+=("$id" "$display" "$state")
  done
}

# _run_prompts <id>
# Runs follow-up whiptail prompts for a service based on its prompts[] array.
# Stores results in PROMPT_RESULTS["id.key"].
_run_prompts() {
  local id="$1"
  local file; file="$(manifest_file "$id")"
  local count; count=$(jq '.prompts | length' "$file")
  [[ "$count" -eq 0 ]] && return 0

  local display; display=$(component_display_name "$id")

  for i in $(seq 0 $((count - 1))); do
    local ptype; ptype=$(jq -r ".prompts[$i].type" "$file")
    local plabel; plabel=$(jq -r ".prompts[$i].label" "$file")
    local pkey;   pkey=$(jq -r  ".prompts[$i].key"   "$file")
    local pdefault; pdefault=$(jq -r ".prompts[$i].default // \"\"" "$file")

    local result=""
    case "$ptype" in
      input)
        result=$(wt_input 7 "$display — Setup" "$plabel" "$pdefault") || true ;;
      yesno)
        result=$(wt_yesno 7 "$display — Setup" "$plabel" "${pdefault:-yes}") ;;
      secret)
        result=$(wt_input 7 "$display — Setup" "$plabel (leave blank to skip)" "$pdefault") || true ;;
      menu)
        local choices_json; choices_json=$(jq -r ".prompts[$i].choices[]" "$file" 2>/dev/null | head -20)
        # Build menu args: tag label tag label ...
        local menu_args=()
        while IFS= read -r choice; do
          menu_args+=("$choice" "$choice")
        done <<< "$choices_json"
        result=$(wt_menu 7 "$display — Setup" "$plabel" "${menu_args[@]}") || true ;;
      info|custom)
        # info: show msgbox only; custom: wizard can't automate, shows guidance
        whiptail --title "$display — Setup" \
          --msgbox "$plabel" 10 $W || true
        result="" ;;
    esac

    PROMPT_RESULTS["${id}.${pkey}"]="$result"
  done
}

# ── Banner ────────────────────────────────────────────────────────────────────

clear
echo -e "${CYAN}${BOLD}"
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║      AI STACK SETUP CONFIGURATOR                ║"
echo "  ║      Ubuntu AI Environment Builder              ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo -e "${NC}"
echo "  Configures your AI stack and writes config/stack.json."
echo "  Arrow keys to navigate, Space to toggle, Enter to confirm."
echo ""
sleep 1

# Pre-wizard: show detected services info screen
_DET_MSG=""
[[ "$HTSAI_DETECTED_OLLAMA"    == "true" ]] && _DET_MSG+="  ✓  Ollama           (binary / data dir / service detected)\n"
[[ "$HTSAI_DETECTED_BITNET"    == "true" ]] && _DET_MSG+="  ✓  BitNet           (binary or install directory detected)\n"
[[ "$HTSAI_DETECTED_SD"        == "true" ]] && _DET_MSG+="  ✓  Stable Diffusion (install path or container detected)\n"
[[ "$HTSAI_DETECTED_VOICE"     == "true" ]] && _DET_MSG+="  ✓  Voice tools      (Whisper / Piper / Coqui detected)\n"
[[ "$HTSAI_DETECTED_NEMOCLAW"  == "true" ]] && _DET_MSG+="  ✓  NemoClaw         (binary / data dir detected)\n"
[[ "$HTSAI_DETECTED_OPENSHELL" == "true" ]] && _DET_MSG+="  ✓  OpenShell        (binary detected)\n"
if [[ -n "$_DET_MSG" ]]; then
  whiptail --title "Existing Services Detected" \
    --msgbox "The following services were found on this machine:\n\n${_DET_MSG}\nDefaults have been pre-filled to work alongside your existing setup.\nYou can still change any option during setup." \
    18 $W || true
fi

# ── Step 1: Backend ───────────────────────────────────────────────────────────

_OLLAMA_LABEL="Ollama  — Easy setup, broad model support"
[[ "$HTSAI_DETECTED_OLLAMA" == "true" ]] && _OLLAMA_LABEL="Ollama  — Easy setup (detected on this machine)"
_BITNET_LABEL="BitNet  — 1-bit quantised, ultra low memory"
[[ "$HTSAI_DETECTED_BITNET" == "true" ]] && _BITNET_LABEL="BitNet  — 1-bit quantised (detected on this machine)"
BACKEND=$(wt_menu 1 "Backend Engine" "Choose your inference backend:" \
  "dual"    "Dual    — GPU + CPU via llama-swap (recommended)" \
  "ollama"  "$_OLLAMA_LABEL" \
  "bitnet"  "$_BITNET_LABEL")

# ── Step 2: External Services ─────────────────────────────────────────────────
# Ask if user wants to use existing services instead of deploying ours.
# Ollama and Open WebUI are always offered (bare-metal or container).
# Other services gated on detection — re-enable post-MVP.

SERVICES_EXTERNAL_OLLAMA="false"
SERVICES_OLLAMA_URL="http://localhost:11434"

SERVICES_EXTERNAL_OPENWEBUI="false"
SERVICES_OPENWEBUI_URL="http://localhost:3000"

SERVICES_DEPLOY_NEMOCLAW="true"
SERVICES_NEMOCLAW_AGENT_PERSONAS="true"
SANDBOX_ENGINE="htsclaw"
SANDBOX_AGENT_PERSONAS="true"

# MVP-disabled defaults (keep these for the JSON writer)
SERVICES_EXTERNAL_SD="false";        SERVICES_SD_URL="http://localhost:7860"
SERVICES_EXTERNAL_BITNET="false";    SERVICES_BITNET_URL="http://localhost:8080"
SERVICES_EXTERNAL_OPENSPACE="false"; SERVICES_OPENSPACE_URL="http://localhost:5000"

LMSTUDIO_INSTALL="false"
LMSTUDIO_ENABLED="false"
LMSTUDIO_URL="http://localhost:1234"

# Ollama — only ask if detected on this machine; otherwise deploy ours
if [[ "$HTSAI_DETECTED_OLLAMA" == "true" ]]; then
  if [[ "$(wt_yesno 2 "Existing Ollama" \
    "Ollama was detected on this machine.\n\nUse your existing Ollama instead of deploying ours?" "yes")" == "true" ]]; then
    SERVICES_EXTERNAL_OLLAMA="true"
    SERVICES_OLLAMA_URL=$(whiptail --title "Ollama URL" \
      --inputbox "Enter URL to your existing Ollama:" \
      8 60 "http://localhost:11434" 3>&1 1>&2 2>&3)
    [[ -z "$SERVICES_OLLAMA_URL" ]] && SERVICES_OLLAMA_URL="http://localhost:11434"
  fi
fi

# Open WebUI — only ask if detected on this machine; otherwise deploy ours
if [[ "$HTSAI_DETECTED_OPENWEBUI" == "true" ]]; then
  if [[ "$(wt_yesno 2 "Existing Open WebUI" \
    "Open WebUI was detected on this machine.\n\nUse your existing Open WebUI instead of deploying ours?" "yes")" == "true" ]]; then
    SERVICES_EXTERNAL_OPENWEBUI="true"
    SERVICES_OPENWEBUI_URL=$(whiptail --title "Open WebUI URL" \
      --inputbox "Enter URL to your existing Open WebUI:" \
      8 60 "http://localhost:3000" 3>&1 1>&2 2>&3)
    [[ -z "$SERVICES_OPENWEBUI_URL" ]] && SERVICES_OPENWEBUI_URL="http://localhost:3000"
  fi
fi

# Sandbox engine choice (htsclaw = self-managed, nemoclaw = NVIDIA-managed, both, none = skip)
SANDBOX_ENGINE=$(wt_menu 2 "Sandbox Engine" \
  "Choose how to run the OpenClaw sandbox agent:\n\n  htsclaw   — Self-managed (direct OpenShell, full control)\n  nemoclaw  — NVIDIA-managed (upstream NemoClaw CLI)\n  both      — Run both side-by-side (ports 18790 + 18789)\n  none      — Skip sandbox agent entirely" \
  "htsclaw"  "Self-managed sandbox (recommended)" \
  "nemoclaw" "NVIDIA NemoClaw CLI" \
  "both"     "Both engines side-by-side" \
  "none"     "No sandbox agent")

# Derive legacy NEMOCLAW flags for backward compatibility
case "$SANDBOX_ENGINE" in
  nemoclaw|both) SERVICES_DEPLOY_NEMOCLAW="true" ;;
  *)             SERVICES_DEPLOY_NEMOCLAW="false" ;;
esac

# Agent persona injection (shared by both sandbox engines)
if [[ "$SANDBOX_ENGINE" != "none" ]]; then
  _persona_label="$SANDBOX_ENGINE"
  [[ "$SANDBOX_ENGINE" == "both" ]] && _persona_label="htsclaw + nemoclaw"
  if ! wt_yesno 2 "Agent Personas" \
    "Inject character personas into the ${_persona_label} sandbox(es)?\n\n  • GPU sandbox → Haley (factual knowledge-base assistant)\n\nThis replaces the default SOUL.md / IDENTITY.md in each sandbox." "yes"; then
    SANDBOX_AGENT_PERSONAS="false"
    [[ "$SANDBOX_ENGINE" == "nemoclaw" || "$SANDBOX_ENGINE" == "both" ]] && SERVICES_NEMOCLAW_AGENT_PERSONAS="false"
  fi
fi

# LM Studio — host-native model runner (not containerised)
# Offer installation for all backends; llama-swap peering only for dual.
_LMS_DETECTED="false"
dpkg -s lmstudio &>/dev/null 2>&1 && _LMS_DETECTED="true"

if [[ "$_LMS_DETECTED" == "true" ]]; then
  # Already installed — skip install offer
  LMSTUDIO_INSTALL="false"
else
  if [[ "$(wt_yesno 2 "LM Studio" \
    "Install LM Studio on this machine?\n\nLM Studio is a desktop GUI for running GGUF models locally.\nThe installer will download the .deb, set up the lms CLI,\nand pull a curated set of models.\n\nYes → install LM Studio (runs on host, port 1234)\nNo  → skip (you can install it later with\n      scripts/install/tooling/install-lmstudio.sh)" "no")" == "true" ]]; then
    LMSTUDIO_INSTALL="true"
  fi
fi

# llama-swap peer — only relevant for dual backend
if [[ "$BACKEND" == "dual" ]]; then
  if [[ "$_LMS_DETECTED" == "true" || "$LMSTUDIO_INSTALL" == "true" ]]; then
    _LMS_PEER_DEFAULT="yes"
  else
    _LMS_PEER_DEFAULT="no"
  fi
  if [[ "$(wt_yesno 2 "LM Studio Peer" \
    "Add LM Studio as an inference peer in llama-swap?\n\n(model staging sandbox on :1234)\n\nNo  → skip (you can add it later in config/llama-swap.yaml)" "$_LMS_PEER_DEFAULT")" == "true" ]]; then
    LMSTUDIO_ENABLED="true"
    LMSTUDIO_URL=$(whiptail --title "LM Studio URL" \
      --inputbox "Enter URL to your LM Studio server:" \
      8 60 "http://localhost:1234" 3>&1 1>&2 2>&3)
    [[ -z "$LMSTUDIO_URL" ]] && LMSTUDIO_URL="http://localhost:1234"
  fi
fi

# ── MVP-disabled: SD, BitNet, OpenSpace external detection ────────────────────
: <<'FUTURE_EXTERNAL_SERVICES'
# Stable Diffusion
if [[ "$HTSAI_DETECTED_SD" == "true" ]]; then
  if wt_yesno 1 "Existing Stable Diffusion Detected" \
    "Stable Diffusion is already installed on this machine.\n\nUse existing SD instead of deploying ours?" "yes"; then
    SERVICES_EXTERNAL_SD="true"
    SERVICES_SD_URL=$(whiptail --title "Stable Diffusion URL" \
      --inputbox "Enter URL to your existing SD WebUI (default: http://localhost:7860):" \
      8 60 "http://localhost:7860" 3>&1 1>&2 2>&3)
    [[ -z "$SERVICES_SD_URL" ]] && SERVICES_SD_URL="http://localhost:7860"
  fi
fi

# BitNet
if [[ "$HTSAI_DETECTED_BITNET" == "true" ]]; then
  if wt_yesno 1 "Existing BitNet Detected" \
    "BitNet is already installed on this machine.\n\nUse existing BitNet instead of deploying ours?" "yes"; then
    SERVICES_EXTERNAL_BITNET="true"
    SERVICES_BITNET_URL=$(whiptail --title "BitNet URL" \
      --inputbox "Enter URL to your existing BitNet (default: http://localhost:8080):" \
      8 60 "http://localhost:8080" 3>&1 1>&2 2>&3)
    [[ -z "$SERVICES_BITNET_URL" ]] && SERVICES_BITNET_URL="http://localhost:8080"
  fi
fi

# OpenSpace (treated as OpenShell for now)
if [[ "$HTSAI_DETECTED_OPENSHELL" == "true" ]]; then
  if wt_yesno 1 "Existing OpenShell Detected" \
    "OpenShell is already installed on this machine.\n\nUse existing OpenShell instead of deploying ours?" "yes"; then
    SERVICES_EXTERNAL_OPENSPACE="true"
    SERVICES_OPENSPACE_URL=$(whiptail --title "OpenShell URL" \
      --inputbox "Enter URL to your existing OpenShell (default: http://localhost:5000):" \
      8 60 "http://localhost:5000" 3>&1 1>&2 2>&3)
    [[ -z "$SERVICES_OPENSPACE_URL" ]] && SERVICES_OPENSPACE_URL="http://localhost:5000"
  fi
fi
FUTURE_EXTERNAL_SERVICES

# ── Step 3: Model ─────────────────────────────────────────────────────────────

if [[ "$BACKEND" == "dual" ]]; then
  # Dual: Ollama model for GPU, BitNet model baked into image
  MODEL=$(wt_menu 3 "Default Model (GPU)" "Select default Ollama model for GPU inference:" \
    "gemma4:e4b"                 "Gemma 4 E4B        — recommended default" \
    "mistral-nemo"               "Mistral Nemo" \
    "llama3.2:3b"                "Llama 3.2 3B       — small, fast" \
    "llama3.1:8b"                "Llama 3.1 8B" \
    "llama3.1:70b"               "Llama 3.1 70B      — large, slow" \
    "mistral:7b"                 "Mistral 7B" \
    "phi3:mini"                  "Phi-3 Mini" \
    "phi3:medium"                "Phi-3 Medium" \
    "gemma2:9b"                  "Gemma 2 9B" \
    "gemma2:27b"                 "Gemma 2 27B" \
    "qwen2.5:7b"                 "Qwen 2.5 7B" \
    "deepseek-r1:7b"             "DeepSeek R1 7B" \
    "codellama:13b"              "CodeLlama 13B")
  INFERENCE_BITNET_MODEL="bitnet"
elif [[ "$BACKEND" == "ollama" ]]; then
  MODEL=$(wt_menu 3 "Default Model" "Select default model for Ollama:" \
    "llama3.2:3b"                "Llama 3.2 3B      — small, fast" \
    "llama3.1:8b"                "Llama 3.1 8B" \
    "llama3.1:70b"               "Llama 3.1 70B     — large, slow" \
    "mistral:7b"                 "Mistral 7B" \
    "gemma4:e4b"                 "Gemma 4 E4B" \
    "mistral-nemo"               "Mistral Nemo" \
    "phi3:mini"                  "Phi-3 Mini" \
    "phi3:medium"                "Phi-3 Medium" \
    "gemma2:9b"                  "Gemma 2 9B" \
    "gemma2:27b"                 "Gemma 2 27B" \
    "qwen2.5:7b"                 "Qwen 2.5 7B" \
    "deepseek-r1:7b"             "DeepSeek R1 7B" \
    "codellama:13b"              "CodeLlama 13B")
else
  MODEL=$(wt_menu 3 "Default Model" "Select default model for BitNet:" \
    "bitnet-b1.58-2B-4T"         "BitNet B1.58 2B-4T" \
    "bitnet-b1.58-3B"            "BitNet B1.58 3B" \
    "Llama3-8B-1.58-100B-tokens" "Llama3 8B 1.58-bit" \
    "Falcon3-1B-1.58B"           "Falcon3 1B 1.58-bit" \
    "Falcon3-3B-1.58B"           "Falcon3 3B 1.58-bit" \
    "Falcon3-7B-1.58B"           "Falcon3 7B 1.58-bit")
fi

# ── Step 3b: Model Library Size ──────────────────────────────────────────────
# Only ask for Ollama/dual (BitNet has limited model selection)
PULL_ALL_MODELS="true"
if [[ "$BACKEND" == "ollama" || "$BACKEND" == "dual" ]]; then
  PULL_ALL_MODELS=$(wt_yesno 3 "Model Library" \
    "Download all production Ollama models?\n\nYes  → Pull default + 10+ other vetted models (~50GB)\nNo   → Pull only the default model (~5-10GB), add others later" \
    "no")
fi

# ── Step 4: Instances ─────────────────────────────────────────────────────────

INSTANCES_PROD_PORT="11434"
INSTANCES_TEST_PORT="11435"

if [[ "$BACKEND" == "dual" ]]; then
  # Dual backend always runs single instance (no prod/test split)
  INSTANCES_MODE="single"
else
  INSTANCES_MODE=$(wt_menu 4 "Deployment Instances" "Instance topology:" \
    "single"    "Single     — One instance, simple setup" \
    "prod_test" "Prod/Test  — Separate production & test stacks")

  if [[ "$INSTANCES_MODE" == "prod_test" ]]; then
    _PROD_PORT_DEFAULT="11434"
    _TEST_PORT_DEFAULT="11435"
    _PORT_NOTE=""
    if [[ "$HTSAI_OLLAMA_PORT_CONFLICT" == "true" ]]; then
      _PROD_PORT_DEFAULT="11436"
      _TEST_PORT_DEFAULT="11437"
      _PORT_NOTE="\n(Port 11434 is in use by an existing Ollama — suggested alternative ports shown)"
    fi
    INSTANCES_PROD_PORT=$(wt_input 4 "Deployment Instances" "Production API port:${_PORT_NOTE}" "$_PROD_PORT_DEFAULT")
    INSTANCES_TEST_PORT=$(wt_input 4 "Deployment Instances" "Test API port:" "$_TEST_PORT_DEFAULT")
  fi
fi

# ══════════════════════════════════════════════════════════════════════════════
# ── MVP defaults — uncomment steps below as features are added ────────────────
# ══════════════════════════════════════════════════════════════════════════════
INFERENCE_BITNET_MODEL="bitnet"
CACHE_TYPE="none"; CACHE_PATH=""; CACHE_MOUNT=""; CACHE_SHARE_PATH=""
NAS_ENABLED="false"; NAS_HOST=""; NAS_NFS4_DOMAIN="htsai"; NAS_USES=""
NAS_MODEL_CACHE_SHARE=""; NAS_MODEL_CACHE_MOUNT="/mnt/ai_models"
NAS_DOCKER_BACKUP_SHARE=""; NAS_DOCKER_BACKUP_MOUNT="/mnt/nas-backups"
NAS_TIMESHIFT_SHARE=""; NAS_TIMESHIFT_MOUNT="/mnt/nas-timeshift"
VOICE_ENABLED="false"; VOICE_STT=""; VOICE_TTS=""; VOICE_WAKE_WORD="false"
IMAGES_ENABLED="false"; IMAGES_ENGINE=""; IMAGES_GPU_LAYERS=""
CLAW3D_ENABLED="false"; CLAW3D_RENDERER=""; CLAW3D_RESOLUTION=""
PAPERCLIP_ENABLED="false"; PAPERCLIP_MAX_AGENTS="4"
PAPERCLIP_AGENT_MEMORY="In-memory (fast)"; PAPERCLIP_AUTO_RESTART="true"
NETWORK="Single vnet"
COMMS_PLATFORMS=""; COMMS_TELEGRAM_TOKEN=""; COMMS_SIGNAL_PHONE=""; COMMS_DISCORD_TOKEN=""
ADMIN_TOOLS="ssh_server"; ADMIN_TAILSCALE_KEY=""
ADMIN_SSH_PORT="22"; ADMIN_SSH_PUBKEY_ONLY="true"

# ── MVP-disabled: Steps 4-7 (Model Cache, NAS, Voice, Images) ────────────────
: <<'FUTURE_STEPS_4_7'
# ── Step 4: Model Cache ───────────────────────────────────────────────────────

CACHE_TYPE=$(wt_menu 4 "Model Cache" "Model cache location:" \
  "none"    "None     — No caching, pull on demand" \
  "local"   "Local    — Cache on this machine's disk" \
  "network" "Network  — Shared NFS / SMB cache")

CACHE_PATH="" CACHE_MOUNT="" CACHE_SHARE_PATH=""
if [[ "$CACHE_TYPE" == "local" ]]; then
  CACHE_PATH=$(wt_input 4 "Model Cache" "Local cache path:" "/opt/ai_models")
fi

# ── Step 5: NAS / Synology — Pre-gate ───────────────────────────────────────

NAS_ENABLED="false"
NAS_HOST="" NAS_NFS4_DOMAIN="htsai" NAS_USES=""
NAS_MODEL_CACHE_SHARE="" NAS_MODEL_CACHE_MOUNT="/mnt/ai_models"
NAS_DOCKER_BACKUP_SHARE="" NAS_DOCKER_BACKUP_MOUNT="/mnt/nas-backups"
NAS_TIMESHIFT_SHARE="" NAS_TIMESHIFT_MOUNT="/mnt/nas-timeshift"

# Ask if user has a NAS device with NFS 4.1 support
_NAS_PRESENT=$(wt_yesno 5 "NAS Support" \
  "Do you have a NAS device that supports NFS 4.1?\n(Can be used for model caching and/or backups)" "no")

if [[ "$_NAS_PRESENT" == "true" ]]; then
  _IS_SYNOLOGY=$(wt_yesno 5 "NAS — Device Type" \
    "Is it a Synology NAS?" "yes")

  if [[ "$_IS_SYNOLOGY" != "true" ]]; then
    _NAS_PROCEED=$(whiptail --title "[5/$TOTAL] NAS — Untested Device" \
      --menu "Only Synology NAS devices have been tested with this installer.\nYour device may still work via standard NFS 4.1.\n\nWhat would you like to do?" \
      14 $W 2 \
      "y" "Try anyway  — proceed with NFS setup" \
      "s" "Skip        — configure manually later" \
      3>&1 1>&2 2>&3) || _NAS_PROCEED="s"
    [[ "$_NAS_PROCEED" != "y" ]] && _NAS_PRESENT="false"
  fi

  [[ "$_NAS_PRESENT" == "true" ]] && NAS_ENABLED="true"
fi

if [[ "$NAS_ENABLED" == "true" ]]; then

  # ── arp-scan to discover / verify NAS IP ─────────────────────────────────
  _ARP_ITEMS=()
  if command -v arp-scan &>/dev/null; then
    _ARP_RAW=""
    _ARP_SCAN_CMD=()

    # Never block on a hidden sudo password prompt.
    # If sudo credentials are not already cached, skip auto-discovery and
    # continue with manual NAS host entry.
    if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
      _ARP_SCAN_CMD=(arp-scan -l)
    elif command -v sudo &>/dev/null && sudo -n true 2>/dev/null; then
      _ARP_SCAN_CMD=(sudo -n arp-scan -l)
    else
      info "Skipping NAS auto-discovery (sudo auth not cached). Enter NAS host manually."
    fi

    if [[ ${#_ARP_SCAN_CMD[@]} -gt 0 ]]; then
      info "Scanning local network for NAS devices (timeout: 8s)..."
      _ARP_RAW=$(timeout 8s "${_ARP_SCAN_CMD[@]}" 2>/dev/null | grep -E '^[0-9]' | sort -t. -k4 -n) || true
      if [[ -z "$_ARP_RAW" ]]; then
        info "NAS auto-discovery returned no results (or timed out). Continuing with manual host entry."
      fi
    fi

    while IFS=$'\t' read -r ip mac vendor; do
      [[ -z "$ip" ]] && continue
      _ARP_ITEMS+=("$ip" "${vendor:-$mac}")
    done <<< "$_ARP_RAW"
  fi

  if [[ ${#_ARP_ITEMS[@]} -gt 0 ]]; then
    _PICKED=$(whiptail --title "[4/$TOTAL] NAS — Select Device" \
      --menu "Select your NAS from devices found on this network\n(Cancel to enter IP manually):" \
      18 $W 10 "${_ARP_ITEMS[@]}" \
      3>&1 1>&2 2>&3) || _PICKED=""
    NAS_HOST="${_PICKED}"
  fi

  if [[ -z "$NAS_HOST" ]]; then
    NAS_HOST=$(wt_input 4 "NAS / Synology" "NAS hostname or IP address:" "")
  fi

  NAS_NFS4_DOMAIN=$(wt_input 4 "NAS — NFSv4.1 Domain" \
    "NFSv4.1 domain\n(Synology: Control Panel → File Services → NFS → Advanced Settings\n → NFSv4/4.1 domain):" "htsai")

  # ── Share probe loop ──────────────────────────────────────────────────────
  # Expected shares (installer looks for these exact names on the NAS):
  _S_NAMES=( "htsai-model-backup"         "htsai-docker-volume-backup"   "htsai-timeshift-backup"   )
  _S_TAGS=(  "model_cache"                "docker_backups"                "timeshift"                )
  _S_LABELS=("Model cache (AI models)"    "Docker volume backups"         "Timeshift system backups" )

  _EXPORTS=""  # populated in loop; accessible after break for mount-point collection
  while true; do

    # Probe NFS exports
    _EXPORTS=""
    if command -v showmount &>/dev/null && [[ -n "$NAS_HOST" && "$NAS_HOST" != "192.168.1.x" ]]; then
      _EXPORTS=$(showmount -e "$NAS_HOST" 2>/dev/null | awk '{print $1}') || true
    fi

    # Classify each expected share as found or missing
    _FOUND_IDX=() _MISS_IDX=()
    for i in "${!_S_NAMES[@]}"; do
      if echo "$_EXPORTS" | grep -qE "/${_S_NAMES[$i]}$"; then
        _FOUND_IDX+=("$i")
      else
        _MISS_IDX+=("$i")
      fi
    done

    # Build info about missing shares (shown before the checklist)
    _MISS_MSG=""
    if [[ ${#_MISS_IDX[@]} -gt 0 ]]; then
      _MISS_MSG="Not found on ${NAS_HOST}:\n"
      for i in "${_MISS_IDX[@]}"; do
        _MISS_MSG+="  ✗  /volume1/${_S_NAMES[$i]}\n"
      done
      _MISS_MSG+="\nSee docs/guides/synology-nfs-shares.md for setup instructions."
    fi

    if [[ ${#_FOUND_IDX[@]} -eq 0 ]]; then
      # Nothing found — show info, offer retry or skip only
      whiptail --title "[4/$TOTAL] NAS — No Shares Found" \
        --msgbox "No expected NFS shares were found on ${NAS_HOST}.\n\n${_MISS_MSG}" \
        14 $W || true
      _NAS_ACTION=$(whiptail --title "[4/$TOTAL] NAS — What next?" \
        --menu "Select an option:" 10 $W 2 \
        "r" "Retry — re-scan after creating shares on the NAS" \
        "s" "Skip  — configure NAS manually later" \
        3>&1 1>&2 2>&3) || _NAS_ACTION="s"
    else
      # One or more shares found — show missing info if partial
      if [[ ${#_MISS_IDX[@]} -gt 0 ]]; then
        whiptail --title "[4/$TOTAL] NAS — Some Shares Missing" \
          --msgbox "$_MISS_MSG" 12 $W || true
      fi

      # Build checklist: only found shares, pre-selected ON
      _CHECK_ARGS=()
      for i in "${_FOUND_IDX[@]}"; do
        _CHECK_ARGS+=("${_S_TAGS[$i]}" "${_S_LABELS[$i]}" "ON")
      done

      NAS_USES=$(whiptail --title "[4/$TOTAL] NAS — Enable Shares" \
        --checklist "Shares found on ${NAS_HOST}:\n(Space=toggle, Enter=confirm)" \
        16 $W 5 "${_CHECK_ARGS[@]}" \
        3>&1 1>&2 2>&3 | tr -d '"') || NAS_USES=""

      # c/r/s action menu (r only shown when there are missing shares)
      _MENU_ITEMS=("c" "Continue  — use selected shares")
      [[ ${#_MISS_IDX[@]} -gt 0 ]] && _MENU_ITEMS+=("r" "Retry     — re-scan after fixing missing shares")
      _MENU_ITEMS+=("s" "Skip      — skip NAS configuration")

      _NAS_ACTION=$(whiptail --title "[4/$TOTAL] NAS — Proceed?" \
        --menu "What would you like to do?" \
        12 $W 3 "${_MENU_ITEMS[@]}" \
        3>&1 1>&2 2>&3) || _NAS_ACTION="s"
    fi

    case "$_NAS_ACTION" in
      c) break ;;
      r) continue ;;
      s) NAS_ENABLED="false"; NAS_USES=""; break ;;
    esac
  done

  # ── Collect mount points for selected uses ────────────────────────────────
  if [[ "$NAS_ENABLED" == "true" ]]; then
    if echo "$NAS_USES" | grep -qw "model_cache"; then
      _DET=$(echo "$_EXPORTS" | grep -E "/htsai-model-backup$" | head -1)
      NAS_MODEL_CACHE_SHARE=$(wt_input 4 "NAS — Model Cache" \
        "NFS share path for AI models:" "${_DET:-/volume1/htsai-model-backup}")
      NAS_MODEL_CACHE_MOUNT=$(wt_input 4 "NAS — Model Cache" \
        "Local mount point:" "/mnt/ai_models")
    fi
    if echo "$NAS_USES" | grep -qw "docker_backups"; then
      _DET=$(echo "$_EXPORTS" | grep -E "/htsai-docker-volume-backup$" | head -1)
      NAS_DOCKER_BACKUP_SHARE=$(wt_input 4 "NAS — Docker Backups" \
        "NFS share path for Docker backups:" "${_DET:-/volume1/htsai-docker-volume-backup}")
      NAS_DOCKER_BACKUP_MOUNT=$(wt_input 4 "NAS — Docker Backups" \
        "Local mount point:" "/mnt/nas-backups")
    fi
    if echo "$NAS_USES" | grep -qw "timeshift"; then
      _DET=$(echo "$_EXPORTS" | grep -E "/htsai-timeshift-backup$" | head -1)
      NAS_TIMESHIFT_SHARE=$(wt_input 4 "NAS — Timeshift" \
        "NFS share path for Timeshift snapshots:" "${_DET:-/volume1/htsai-timeshift-backup}")
      NAS_TIMESHIFT_MOUNT=$(wt_input 4 "NAS — Timeshift" \
        "Local mount point:" "/mnt/nas-timeshift")
    fi
  fi
fi

# If network cache is selected but NAS integration is not enabled, ask for
# generic mount/share values directly.
if [[ "$CACHE_TYPE" == "network" ]]; then
  if [[ "$NAS_ENABLED" == "true" ]] && echo "$NAS_USES" | grep -qw "model_cache"; then
    CACHE_MOUNT="$NAS_MODEL_CACHE_MOUNT"
    CACHE_SHARE_PATH="${NAS_HOST}:${NAS_MODEL_CACHE_SHARE}"
  else
    CACHE_MOUNT=$(wt_input 5 "Model Cache" "Network share mount point:" "/mnt/ai_models")
    CACHE_SHARE_PATH=$(wt_input 5 "Model Cache" "Share path (e.g. //nas/ai_models):" "")
  fi
fi

# ── Step 6: Voice ─────────────────────────────────────────────────────────────

_VOICE_DEFAULT="no"
[[ "$HTSAI_DETECTED_VOICE" == "true" ]] && _VOICE_DEFAULT="yes"
VOICE_ENABLED=$(wt_yesno 6 "Voice Support" "Enable voice input / output?" "$_VOICE_DEFAULT")
VOICE_STT="" VOICE_TTS="" VOICE_WAKE_WORD="false"
if [[ "$VOICE_ENABLED" == "true" ]]; then
  VOICE_STT=$(wt_menu 6 "Voice Support" "Speech-to-text engine:" \
    "whisper"        "Whisper (local)    — Private, no cloud" \
    "faster_whisper" "Faster-Whisper     — Optimised local STT" \
    "vosk"           "Vosk (offline)     — Lightweight STT")
  VOICE_TTS=$(wt_menu 6 "Voice Support" "Text-to-speech engine:" \
    "piper"  "Piper   — Fast local neural TTS" \
    "coqui"  "Coqui   — High quality local TTS" \
    "espeak" "espeak  — Lightweight, robotic")
  VOICE_WAKE_WORD=$(wt_yesno 6 "Voice Support" "Enable wake-word detection?" "no")
fi
FUTURE_STEPS_4_7

# ── Step 7: Image Generation ──────────────────────────────────────────────────

_IMG_DEFAULT="no"
[[ "$HTSAI_DETECTED_SD" == "true" ]] && _IMG_DEFAULT="yes"
IMAGES_ENABLED=$(wt_yesno 6 "Image Generation" "Enable image generation?" "$_IMG_DEFAULT")
IMAGES_ENGINE="" IMAGES_GPU_LAYERS=""
if [[ "$IMAGES_ENABLED" == "true" ]]; then
  _SD_LABEL="Stable Diffusion  — Full control, GPU heavy"
  [[ "$HTSAI_DETECTED_SD" == "true" ]] && _SD_LABEL="Stable Diffusion  — Full control, GPU heavy (detected)"
  IMAGES_ENGINE=$(wt_menu 6 "Image Generation" "Image generation engine:" \
    "stable_diffusion" "$_SD_LABEL" \
    "comfyui"          "ComfyUI           — Node-based SD pipeline" \
    "invokeai"         "InvokeAI          — Polished SD UI" \
    "fooocus"          "Fooocus           — Simple SD interface")
  IMAGES_GPU_LAYERS=$(wt_menu 6 "Image Generation" "GPU offload layers:" \
    "0"   "0 — CPU only" \
    "16"  "16 layers" \
    "32"  "32 layers" \
    "48"  "48 layers" \
    "All" "All — max GPU offload")
fi

# ── Step 6 & 7: Dynamic service selection (manifest-driven) ──────────────────

declare -a WIZARD_CATEGORIES=("core" "agents" "extras" "monitoring" "admin" "training")
declare -A WIZARD_CATEGORY_TITLES=(
  [core]="Core Services"
  [agents]="Agent & Workflow Services"
  [extras]="Extra Tools & Applications"
  [monitoring]="Monitoring & Management"
  [admin]="Admin & Remote Access"
  [training]="Training & Fine-Tuning"
)
# inference, sandbox, images are controlled by dedicated wizard steps
WIZARD_SKIP_CATEGORIES="inference sandbox images"

_EXISTING_STACK=""
[[ -f "$STACK_JSON" ]] && _EXISTING_STACK="$STACK_JSON"

CHECKLIST_ARGS=()   # global, re-populated per category by _build_checklist_args

for _WIZ_CAT in "${WIZARD_CATEGORIES[@]}"; do
  [[ "$WIZARD_SKIP_CATEGORIES" == *"$_WIZ_CAT"* ]] && continue

  _build_checklist_args "$_WIZ_CAT" "$_EXISTING_STACK"
  [[ ${#CHECKLIST_ARGS[@]} -eq 0 ]] && continue

  _CAT_TITLE="${WIZARD_CATEGORY_TITLES[$_WIZ_CAT]:-$_WIZ_CAT}"

  _SELECTED=$(wt_check 7 "$_CAT_TITLE" \
    "Select ${_CAT_TITLE,,} to enable:" \
    "${CHECKLIST_ARGS[@]}") || true

  for _SVC_ID in $_SELECTED; do
    ENABLED_SERVICES["$_SVC_ID"]="true"
  done

  # Mark services not selected as explicitly disabled (reconfigure flow)
  for i in $(seq 0 3 $(( ${#CHECKLIST_ARGS[@]} - 1 ))); do
    _ID="${CHECKLIST_ARGS[$i]}"
    [[ -z "${ENABLED_SERVICES[$_ID]+x}" ]] && ENABLED_SERVICES["$_ID"]="false"
  done

  # Run follow-up prompts for each enabled service in this category
  for _SVC_ID in $_SELECTED; do
    _run_prompts "$_SVC_ID"
  done
done
unset _WIZ_CAT _CAT_TITLE _SELECTED _SVC_ID _ID _EXISTING_STACK

# GPU warning if GPU-required services selected without GPU
if [[ "$GPU_AVAILABLE" == "false" ]]; then
  _GPU_SVCS=()
  for _SVC_ID in "${!ENABLED_SERVICES[@]}"; do
    [[ "${ENABLED_SERVICES[$_SVC_ID]}" != "true" ]] && continue
    _FILE="$(manifest_file "$_SVC_ID")"
    [[ -f "$_FILE" ]] || continue
    _RG=$(jq -r '.requires_gpu // false' "$_FILE")
    [[ "$_RG" == "true" ]] && _GPU_SVCS+=("$_SVC_ID")
  done
  if [[ ${#_GPU_SVCS[@]} -gt 0 ]]; then
    _GPU_LIST=$(printf '  • %s\n' "${_GPU_SVCS[@]}")
    whiptail --title "GPU Warning" \
      --msgbox "No NVIDIA GPU detected, but these GPU services were selected:\n\n${_GPU_LIST}\n\nThey will be configured but may not start without a GPU." \
      14 $W || true
  fi
  unset _GPU_SVCS _SVC_ID _FILE _RG _GPU_LIST
fi

# ── MVP-disabled: Steps 8-12 (Claw3D, Paperclip, Network, Comms, Admin) ──────
: <<'FUTURE_STEPS_8_12'
# ── Step 8: Claw3D ────────────────────────────────────────────────────────────

CLAW3D_ENABLED=$(wt_yesno 8 "Claw3D (3D Visualisation)" "Enable Claw3D visualisation engine?" "no")
CLAW3D_RENDERER="" CLAW3D_RESOLUTION=""
if [[ "$CLAW3D_ENABLED" == "true" ]]; then
  CLAW3D_RENDERER=$(wt_menu 8 "Claw3D" "Rendering backend:" \
    "OpenGL"         "OpenGL" \
    "Vulkan"         "Vulkan" \
    "WebGL_browser"  "WebGL (browser)")
  CLAW3D_RESOLUTION=$(wt_menu 8 "Claw3D" "Default viewport resolution:" \
    "1280x720"  "1280×720" \
    "1920x1080" "1920×1080 (FHD)" \
    "2560x1440" "2560×1440 (QHD)" \
    "4K"        "4K / UHD")
fi

# ── Step 9: Paperclip ─────────────────────────────────────────────────────────

PAPERCLIP_ENABLED=$(wt_yesno 9 "Paperclip (OpenClaw Agent Manager)" "Enable Paperclip agent manager?" "yes")
PAPERCLIP_MAX_AGENTS="4"
PAPERCLIP_AGENT_MEMORY="In-memory (fast)"
PAPERCLIP_AUTO_RESTART="true"
if [[ "$PAPERCLIP_ENABLED" == "true" ]]; then
  PAPERCLIP_MAX_AGENTS=$(wt_menu 9 "Paperclip" "Max concurrent OpenClaw agents:" \
    "2"  "2 agents" \
    "4"  "4 agents" \
    "8"  "8 agents" \
    "16" "16 agents" \
    "32" "32 agents")
  PAPERCLIP_AGENT_MEMORY=$(wt_menu 9 "Paperclip" "Agent memory backend:" \
    "in_memory" "In-memory (fast)" \
    "redis"     "Redis (persistent)" \
    "sqlite"    "SQLite (lightweight)")
  PAPERCLIP_AUTO_RESTART=$(wt_yesno 9 "Paperclip" "Auto-restart failed agents?" "yes")
fi

# ── Step 10: Docker Network ───────────────────────────────────────────────────

NETWORK=$(wt_menu 10 "Docker Network" "Docker network topology:" \
  "Direct bind" "Direct bind  — Host network, fastest" \
  "Single vnet" "Single vnet  — Shared bridge, simple" \
  "Secure vnet" "Secure vnet  — Isolated networks, firewall rules")

# ── Step 11: Comms ────────────────────────────────────────────────────────────

COMMS_PLATFORMS=$(wt_check 11 "Communications (Bot Integrations)" \
  "Select communication platforms:" \
  "telegram" "Telegram  — Bot API, lightweight"               OFF \
  "signal"   "Signal    — Encrypted messaging via signal-cli" OFF \
  "discord"  "Discord   — Bot with slash commands"            OFF)

COMMS_TELEGRAM_TOKEN="" COMMS_SIGNAL_PHONE="" COMMS_DISCORD_TOKEN=""
if echo "$COMMS_PLATFORMS" | grep -qw "telegram"; then
  COMMS_TELEGRAM_TOKEN=$(wt_input 11 "Comms — Telegram" "Telegram bot token (blank to set later):" "")
fi
if echo "$COMMS_PLATFORMS" | grep -qw "signal"; then
  COMMS_SIGNAL_PHONE=$(wt_input 11 "Comms — Signal" "Signal phone number (e.g. +441234567890):" "")
fi
if echo "$COMMS_PLATFORMS" | grep -qw "discord"; then
  COMMS_DISCORD_TOKEN=$(wt_input 11 "Comms — Discord" "Discord bot token (blank to set later):" "")
fi

# ── Step 12: Admin ────────────────────────────────────────────────────────────

ADMIN_TOOLS=$(wt_check 12 "Admin & Remote Access" \
  "Select remote admin tools:" \
  "tailscale"  "Tailscale   — Zero-config VPN mesh"          OFF \
  "ssh_server" "SSH Server  — OpenSSH daemon"                ON)

ADMIN_TAILSCALE_KEY="" ADMIN_SSH_PORT="22" ADMIN_SSH_PUBKEY_ONLY="true"
if echo "$ADMIN_TOOLS" | grep -qw "tailscale"; then
  ADMIN_TAILSCALE_KEY=$(wt_input 12 "Admin — Tailscale" "Tailscale auth key (blank to auth interactively):" "")
fi
if echo "$ADMIN_TOOLS" | grep -qw "ssh_server"; then
  ADMIN_SSH_PORT=$(wt_input 12 "Admin — SSH" "SSH port:" "22")
  ADMIN_SSH_PUBKEY_ONLY=$(wt_yesno 12 "Admin — SSH" "Disable password login (pubkey only)?" "yes")
fi
FUTURE_STEPS_8_12

# ── Step 7: Non-manifest extras ──────────────────────────────────────────────
# open_webui, nginx, obsidian, sudo_keepalive are not in manifests yet.
# Force nginx ON if dashboard is enabled.

NGINX_DEFAULT="OFF"
[[ "${ENABLED_SERVICES[dashboard]:-false}" == "true" ]] && NGINX_DEFAULT="ON"

SUDO_KEEPALIVE="false"

EXTRAS=$(wt_check 7 "Extra Components" \
  "Select additional components:" \
  "open_webui"      "Open WebUI       — Browser chat interface"  ON  \
  "nginx"           "Nginx proxy      — Reverse proxy / TLS"     "$NGINX_DEFAULT" \
  "obsidian"        "Obsidian         — Personal knowledge mgmt"  OFF \
  "sudo_keepalive"  "Sudo keep-alive  — Unattended install"      OFF) || true

if echo "$EXTRAS" | grep -qw "sudo_keepalive"; then
  SUDO_KEEPALIVE="true"
  EXTRAS=$(echo "$EXTRAS" | sed 's/sudo_keepalive//g' | xargs)
fi

# Force nginx if dashboard is enabled
if [[ "${ENABLED_SERVICES[dashboard]:-false}" == "true" ]] && ! echo "$EXTRAS" | grep -qw "nginx"; then
  EXTRAS="${EXTRAS} nginx"
fi

# ── Step 8: Open WebUI ───────────────────────────────────────────────────────

MODEL_AUDIT_ENABLED="false"
if echo "$EXTRAS" | grep -qw "open_webui" && [[ "$SERVICES_EXTERNAL_OPENWEBUI" == "false" ]]; then
  MODEL_AUDIT_ENABLED=$(wt_yesno 8 "Open WebUI — Model Audit" \
    "Enable model security audit?\n(Adds /audit command in Open WebUI that checks all pulled models\nagainst HuggingFace for security flags, malware scans, etc.)" "yes")
fi

# ── Open WebUI credentials ──────────────────────────────────────────────────

WEBUI_ADMIN_EMAIL="" WEBUI_ADMIN_PASSWORD="" WEBUI_ADMIN_NAME=""
WEBUI_USER_EMAIL="" WEBUI_USER_PASSWORD="" WEBUI_USER_NAME=""

if echo "$EXTRAS" | grep -qw "open_webui" && [[ "$SERVICES_EXTERNAL_OPENWEBUI" == "false" ]]; then
  if [[ "$(wt_yesno 8 "Open WebUI — Credentials" \
    "Set up login accounts for Open WebUI now?\n\nYes → provide admin + user email/password\nNo  → you'll create accounts at first login" "yes")" == "true" ]]; then
    WEBUI_ADMIN_NAME=$(wt_input 8 "Open WebUI — Admin Account" "Admin display name:" "Admin")
    WEBUI_ADMIN_EMAIL=$(wt_input 8 "Open WebUI — Admin Account" "Admin email address:" "admin@hts-ai-stack.local")
    WEBUI_ADMIN_PASSWORD=$(whiptail --title "[8/$TOTAL] Open WebUI — Admin Account" \
      --passwordbox "Admin password (hidden):" 10 $W \
      3>&1 1>&2 2>&3) || { echo -e "\n  Setup cancelled.\n"; exit 0; }

    if [[ "$(wt_yesno 8 "Open WebUI — Regular User" \
      "Also create a regular (non-admin) user?" "no")" == "true" ]]; then
      WEBUI_USER_NAME=$(wt_input 8 "Open WebUI — User Account" "User display name:" "")
      WEBUI_USER_EMAIL=$(wt_input 8 "Open WebUI — User Account" "User email address:" "")
      WEBUI_USER_PASSWORD=$(whiptail --title "[8/$TOTAL] Open WebUI — User Account" \
        --passwordbox "User password (hidden):" 10 $W \
        3>&1 1>&2 2>&3) || { echo -e "\n  Setup cancelled.\n"; exit 0; }
    fi
  fi
fi

# ── Summary + confirm ─────────────────────────────────────────────────────────

clear
echo -e "${CYAN}${BOLD}══ Configuration Summary ══${NC}"
echo ""
printf "  %-18s %s\n" "Backend:"       "$BACKEND"
printf "  %-18s %s\n" "Model:"         "$MODEL"
if [[ "$BACKEND" == "dual" ]]; then
printf "  %-18s %s\n" "BitNet model:"  "${INFERENCE_BITNET_MODEL:-bitnet}"
printf "  %-18s %s\n" "Router:"        "llama-swap :8080"
if [[ "$LMSTUDIO_INSTALL" == "true" ]]; then
printf "  %-18s %s\n" "LM Studio:"     "install → host :1234"
fi
if [[ "$LMSTUDIO_ENABLED" == "true" ]]; then
printf "  %-18s %s\n" "LM Studio peer:" "→ ${LMSTUDIO_URL}"
fi
fi
printf "  %-18s %s\n" "Instances:"     "$INSTANCES_MODE"
if [[ "$SERVICES_EXTERNAL_OLLAMA" == "true" ]]; then
printf "  %-18s %s\n" "Ollama:"        "external → ${SERVICES_OLLAMA_URL}"
else
printf "  %-18s %s\n" "Ollama:"        "install (hts-ai managed)"
fi
if [[ "$SERVICES_EXTERNAL_OPENWEBUI" == "true" ]]; then
printf "  %-18s %s\n" "Open WebUI:"    "external → ${SERVICES_OPENWEBUI_URL}"
else
printf "  %-18s %s\n" "Open WebUI:"    "install (hts-ai managed)"
fi
printf "  %-18s %s\n" "Sandbox engine:" "$SANDBOX_ENGINE"
if [[ "$SANDBOX_ENGINE" != "none" ]]; then
printf "  %-18s %s\n" "  Agent personas:" "$SANDBOX_AGENT_PERSONAS"
fi

# Dynamic service list from manifest checklist
if [[ ${#ENABLED_SERVICES[@]} -gt 0 ]]; then
  _ENABLED_LIST="" _DISABLED_LIST=""
  for _SID in $(printf '%s\n' "${!ENABLED_SERVICES[@]}" | sort); do
    if [[ "${ENABLED_SERVICES[$_SID]}" == "true" ]]; then
      _ENABLED_LIST+="${_SID} "
    fi
  done
  printf "  %-18s %s\n" "Services on:"   "${_ENABLED_LIST:-none}"
  unset _SID _ENABLED_LIST _DISABLED_LIST
fi

printf "  %-18s %s\n" "Extras:"        "${EXTRAS:-none}"
if [[ "$SUDO_KEEPALIVE" == "true" ]]; then
printf "  %-16s %s\n" "  Sudo keep-alive:" "enabled (unattended install)"
fi
if [[ "$MODEL_AUDIT_ENABLED" == "true" ]]; then
printf "  %-16s %s\n" "  Model audit:" "enabled (/audit command)"
fi
echo ""

if ! whiptail --title "Save Configuration?" \
              --yesno "Save this configuration to config/stack.json?" \
              10 $W; then
  echo "  Config not saved."
  exit 0
fi

# ── Backup existing config ────────────────────────────────────────────────────

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
mkdir -p "$CONFIG_DIR" "$BACKUP_DIR"

if [[ -f "$STACK_JSON" ]]; then
  mkdir -p "$BACKUP_DIR/$TIMESTAMP"
  cp "$STACK_JSON" "$BACKUP_DIR/$TIMESTAMP/stack.json"
  [[ -f "$REPO_ROOT/.env" ]] && cp "$REPO_ROOT/.env" "$BACKUP_DIR/$TIMESTAMP/.env.bak"
fi

# ── Write JSON ────────────────────────────────────────────────────────────────
# Export structural values from hardcoded wizard steps.

export BACKEND MODEL PULL_ALL_MODELS
export INFERENCE_BITNET_MODEL
export INSTANCES_MODE INSTANCES_PROD_PORT INSTANCES_TEST_PORT
export NAS_ENABLED NAS_HOST NAS_NFS4_DOMAIN NAS_USES
export NAS_MODEL_CACHE_SHARE NAS_MODEL_CACHE_MOUNT
export NAS_DOCKER_BACKUP_SHARE NAS_DOCKER_BACKUP_MOUNT
export NAS_TIMESHIFT_SHARE NAS_TIMESHIFT_MOUNT
export CACHE_TYPE CACHE_PATH CACHE_MOUNT CACHE_SHARE_PATH
export VOICE_ENABLED VOICE_STT VOICE_TTS VOICE_WAKE_WORD
export IMAGES_ENABLED IMAGES_ENGINE IMAGES_GPU_LAYERS
export LMSTUDIO_INSTALL LMSTUDIO_ENABLED LMSTUDIO_URL
export CLAW3D_ENABLED CLAW3D_RENDERER CLAW3D_RESOLUTION
export PAPERCLIP_ENABLED PAPERCLIP_MAX_AGENTS PAPERCLIP_AGENT_MEMORY PAPERCLIP_AUTO_RESTART
export NETWORK
export COMMS_PLATFORMS COMMS_TELEGRAM_TOKEN COMMS_SIGNAL_PHONE COMMS_DISCORD_TOKEN
export ADMIN_TOOLS ADMIN_TAILSCALE_KEY ADMIN_SSH_PORT ADMIN_SSH_PUBKEY_ONLY
export EXTRAS SUDO_KEEPALIVE
export SERVICES_EXTERNAL_OLLAMA SERVICES_OLLAMA_URL
export SERVICES_EXTERNAL_OPENWEBUI SERVICES_OPENWEBUI_URL
export SERVICES_EXTERNAL_SD SERVICES_SD_URL
export SERVICES_EXTERNAL_BITNET SERVICES_BITNET_URL
export SERVICES_EXTERNAL_OPENSPACE SERVICES_OPENSPACE_URL
export SERVICES_DEPLOY_NEMOCLAW SERVICES_NEMOCLAW_AGENT_PERSONAS
export SANDBOX_ENGINE SANDBOX_AGENT_PERSONAS
export MODEL_AUDIT_ENABLED
export WEBUI_ADMIN_EMAIL WEBUI_ADMIN_PASSWORD WEBUI_ADMIN_NAME
export WEBUI_USER_EMAIL WEBUI_USER_PASSWORD WEBUI_USER_NAME
export TIMESTAMP STACK_JSON SECRETS_JSON

# Serialize manifest-driven wizard state to a temp file.
# Build enabled-services JSON (keys = alphanumeric IDs, values = bool literals).
_ENABLED_JSON="{"
_COMMA=""
for _SID in "${!ENABLED_SERVICES[@]}"; do
  [[ "${ENABLED_SERVICES[$_SID]}" == "true" ]] && _BVAL="true" || _BVAL="false"
  _ENABLED_JSON+="${_COMMA}\"${_SID}\":${_BVAL}"
  _COMMA=","
done
_ENABLED_JSON+="}"
export _WIZ_ENABLED="$_ENABLED_JSON"

# Export prompt results as indexed env var pairs (values may contain any chars).
_IDX=0
for _PKEY in "${!PROMPT_RESULTS[@]}"; do
  export "WIZARD_PK_${_IDX}=${_PKEY}"
  export "WIZARD_PV_${_IDX}=${PROMPT_RESULTS[$_PKEY]}"
  _IDX=$((_IDX + 1))
done
export WIZARD_PROMPT_COUNT="$_IDX"
unset _SID _BVAL _COMMA _ENABLED_JSON _PKEY _IDX

_WIZARD_STATE_FILE="${CONFIG_DIR}/.wizard-state.tmp"
python3 - "$_WIZARD_STATE_FILE" <<'PYSTATE'
import json, os, sys
state_file = sys.argv[1]
enabled = json.loads(os.environ.get('_WIZ_ENABLED', '{}'))
count = int(os.environ.get('WIZARD_PROMPT_COUNT', '0'))
prompts = {}
for i in range(count):
    k = os.environ.get(f'WIZARD_PK_{i}', '')
    v = os.environ.get(f'WIZARD_PV_{i}', '')
    if k:
        prompts[k] = v
json.dump({'enabled': enabled, 'prompts': prompts}, open(state_file, 'w'))
PYSTATE

export WIZARD_STATE_FILE="$_WIZARD_STATE_FILE"
export WIZARD_MANIFEST_DIR="$REPO_ROOT/scripts/components"

python3 - <<'PYEOF'
import json, os, stat, glob, functools

def to_list(s):
    return [x for x in s.split() if x]

def env(key, default=""):
    return os.environ.get(key, default)

def benv(key):
    return env(key) == "true"

def set_nested(obj, path, value):
    keys = path.lstrip('.').split('.')
    for k in keys[:-1]:
        obj = obj.setdefault(k, {})
    obj[keys[-1]] = value

def get_nested(obj, path, default=None):
    keys = path.lstrip('.').split('.')
    try:
        return functools.reduce(lambda o, k: o[k], keys, obj)
    except (KeyError, TypeError, IndexError):
        return default

NETWORK_MODES = {
    "Direct bind": ("host",          "Container uses host network directly. Fastest, least isolated."),
    "Single vnet": ("bridge",        "Containers share a single bridge network. Simple and isolated."),
    "Secure vnet": ("custom_bridge", "Separate networks per service with firewall rules. Most secure."),
}

MEMORY_LABELS = {
    "in_memory": "In-memory (fast)",
    "redis":     "Redis (persistent)",
    "sqlite":    "SQLite (lightweight)",
}

network      = env("NETWORK")
net_mode, net_desc = NETWORK_MODES.get(network, ("bridge", ""))
timestamp    = env("TIMESTAMP")
stack_json   = env("STACK_JSON")
secrets_json = env("SECRETS_JSON")

# ── Load manifest-driven wizard state ────────────────────────────────────────
state_file    = env("WIZARD_STATE_FILE")
manifest_dir  = env("WIZARD_MANIFEST_DIR")
enabled_services = {}
prompt_results   = {}
if state_file and os.path.exists(state_file):
    with open(state_file) as _f:
        _state = json.load(_f)
    enabled_services = _state.get("enabled", {})
    prompt_results   = _state.get("prompts", {})

# Load all manifests
manifests = {}
if manifest_dir:
    for _mfile in sorted(glob.glob(os.path.join(manifest_dir, "*.manifest.json"))):
        with open(_mfile) as _f:
            _m = json.load(_f)
            manifests[_m["id"]] = _m

comms_platforms       = to_list(env("COMMS_PLATFORMS"))
comms_telegram_token  = env("COMMS_TELEGRAM_TOKEN")
comms_signal_phone    = env("COMMS_SIGNAL_PHONE")
comms_discord_token   = env("COMMS_DISCORD_TOKEN")

admin_tools        = to_list(env("ADMIN_TOOLS"))
admin_tailscale_key = env("ADMIN_TAILSCALE_KEY")

# ── Build clean config (no secrets) ──────────────────────────────────────────
backend = env("BACKEND")
cfg = {
    "_meta": {
        "format_version": "2",
        "saved_at": timestamp,
        "note": "Secrets/tokens are never stored here — see stack.secrets.json or .env.",
    },
    "backend":           backend,
    "model":             env("MODEL"),
    "pull_all_models":   benv("PULL_ALL_MODELS"),
}

# Dual-inference: add inference routing section
if backend == "dual":
    cfg["inference"] = {
        "router":       "llama-swap",
        "router_port":  "8081",
        "ollama_port":  "11434",
        "ollama_model": env("MODEL") or "mistral-nemo:latest",
        "bitnet_model": env("INFERENCE_BITNET_MODEL") or "bitnet",
    }
    if benv("LMSTUDIO_ENABLED"):
        cfg["inference"]["lmstudio"] = {
            "enabled": True,
            "url":     env("LMSTUDIO_URL") or "http://localhost:1234",
        }

cfg["lmstudio"] = {
    "install": benv("LMSTUDIO_INSTALL"),
    "peer":    benv("LMSTUDIO_ENABLED"),
    "url":     env("LMSTUDIO_URL") or "http://localhost:1234",
}

cfg.update({
    "instances": {
        "mode":      env("INSTANCES_MODE"),
        "prod_port": env("INSTANCES_PROD_PORT"),
        "test_port": env("INSTANCES_TEST_PORT"),
    },
    "model_cache": {"type": env("CACHE_TYPE")},
    "voice": {
        "enabled":   benv("VOICE_ENABLED"),
        "stt":       env("VOICE_STT"),
        "tts":       env("VOICE_TTS"),
        "wake_word": benv("VOICE_WAKE_WORD"),
    },
    "images": {
        "enabled":    benv("IMAGES_ENABLED"),
        "engine":     env("IMAGES_ENGINE"),
        "gpu_layers": env("IMAGES_GPU_LAYERS"),
    },
    "sandbox": {
        "engine": env("SANDBOX_ENGINE") or "htsclaw",
        "agent_personas": benv("SANDBOX_AGENT_PERSONAS"),
    },
    "claw3d": {
        "enabled":    benv("CLAW3D_ENABLED"),
        "renderer":   env("CLAW3D_RENDERER"),
        "resolution": env("CLAW3D_RESOLUTION"),
    },
    "paperclip": {
        "enabled":      benv("PAPERCLIP_ENABLED"),
        "max_agents":   env("PAPERCLIP_MAX_AGENTS"),
        "agent_memory": MEMORY_LABELS.get(env("PAPERCLIP_AGENT_MEMORY"), env("PAPERCLIP_AGENT_MEMORY")),
        "auto_restart": benv("PAPERCLIP_AUTO_RESTART"),
    },
    "network": {
        "topology":    network,
        "mode":        net_mode,
        "description": net_desc,
    },
    "comms": {
        "platforms": comms_platforms,
        "tokens":    {},          # secrets stripped
    },
    "admin": {
        "tools":          admin_tools,
        "ssh_port":       env("ADMIN_SSH_PORT"),
        "ssh_pubkey_only": benv("ADMIN_SSH_PUBKEY_ONLY"),
        "sudo_keepalive": benv("SUDO_KEEPALIVE"),
    },
    "nas": {
        "enabled":              benv("NAS_ENABLED"),
        "host":                 env("NAS_HOST"),
        "nfs4_domain":          env("NAS_NFS4_DOMAIN", "htsai"),
        "uses":                 to_list(env("NAS_USES")),
        "model_cache_share":    env("NAS_MODEL_CACHE_SHARE"),
        "model_cache_mount":    env("NAS_MODEL_CACHE_MOUNT"),
        "docker_backup_share":  env("NAS_DOCKER_BACKUP_SHARE"),
        "docker_backup_mount":  env("NAS_DOCKER_BACKUP_MOUNT"),
        "timeshift_share":      env("NAS_TIMESHIFT_SHARE"),
        "timeshift_mount":      env("NAS_TIMESHIFT_MOUNT"),
    },
    "services": {
        "ollama": {
            "use_external": benv("SERVICES_EXTERNAL_OLLAMA"),
            "external_url": env("SERVICES_OLLAMA_URL"),
        },
        "open_webui": {
            "use_external": benv("SERVICES_EXTERNAL_OPENWEBUI"),
            "external_url": env("SERVICES_OPENWEBUI_URL"),
        },
        "stable_diffusion": {
            "use_external": benv("SERVICES_EXTERNAL_SD"),
            "external_url": env("SERVICES_SD_URL"),
        },
        "bitnet": {
            "use_external": benv("SERVICES_EXTERNAL_BITNET"),
            "external_url": env("SERVICES_BITNET_URL"),
        },
        "openspace": {
            "use_external": benv("SERVICES_EXTERNAL_OPENSPACE"),
            "external_url": env("SERVICES_OPENSPACE_URL"),
        },
        "nemoclaw": {
            "deploy": benv("SERVICES_DEPLOY_NEMOCLAW"),
            "agent_personas": benv("SERVICES_NEMOCLAW_AGENT_PERSONAS"),
        },
    },
})

# Add llama-swap service config when dual
if backend == "dual":
    cfg["services"]["llama_swap"] = {
        "port":   "8080",
        "config": "config/llama-swap.yaml",
    }

cfg["extras"] = {
    "components": to_list(env("EXTRAS")),
    "model_audit": benv("MODEL_AUDIT_ENABLED"),
}

# ── Section B: Manifest-driven toggleable services ───────────────────────────
# For each toggleable manifest with write_rules, apply the appropriate value
# based on whether the service was enabled in the checklist.

for mid, m in manifests.items():
    if not m.get("config", {}).get("toggleable", False):
        continue
    rules = m.get("config", {}).get("write_rules", [])
    if not rules:
        continue
    is_enabled = enabled_services.get(mid, False)
    for rule in rules:
        path   = rule.get("path", "")
        action = rule.get("action", "set")
        if not path:
            continue
        if action == "add_remove":
            arr   = get_nested(cfg, path, [])
            value = rule.get("value", "")
            if not isinstance(arr, list):
                arr = []
            if is_enabled:
                if value not in arr:
                    arr.append(value)
            else:
                arr = [v for v in arr if v != value]
            set_nested(cfg, path, arr)
        else:
            set_nested(cfg, path, rule["on_enable"] if is_enabled else rule["on_disable"])

# Apply prompt results targeting stack.json
for mid, m in manifests.items():
    for prompt in m.get("prompts", []):
        result_key   = f"{mid}.{prompt['key']}"
        write_target = prompt.get("write_target", "")
        write_path   = prompt.get("write_path", "")
        if write_target != "stack.json" or not write_path:
            continue
        value = prompt_results.get(result_key)
        if value is None:
            continue
        if value in ("true", "false"):
            value = value == "true"
        elif isinstance(value, str) and value.isdigit():
            value = int(value)
        set_nested(cfg, write_path, value)

# Handle model_cache extra fields
cache_type = env("CACHE_TYPE")
if cache_type == "local":
    cfg["model_cache"]["path"] = env("CACHE_PATH")
elif cache_type == "network":
    cfg["model_cache"]["mount"]      = env("CACHE_MOUNT")
    cfg["model_cache"]["share_path"] = env("CACHE_SHARE_PATH")

# Collect prompt secrets (type=secret) for secrets.json
_manifest_secrets = {}
for mid, m in manifests.items():
    for prompt in m.get("prompts", []):
        if prompt.get("type") != "secret":
            continue
        env_var = prompt.get("env_var", "")
        if not env_var:
            continue
        value = prompt_results.get(f"{mid}.{prompt['key']}", "")
        if value:
            _manifest_secrets[env_var] = value

with open(stack_json, "w") as f:
    json.dump(cfg, f, indent=2)
print(f"  ✓  Config saved  → {stack_json}")

# ── Write secrets (gitignored, chmod 600) ─────────────────────────────────────
secrets = {"_meta": {"saved_at": timestamp}}

if "telegram" in comms_platforms and comms_telegram_token:
    secrets.setdefault("comms_tokens", {})["telegram_bot_token"] = comms_telegram_token
if "signal" in comms_platforms and comms_signal_phone:
    secrets.setdefault("comms_tokens", {})["signal_phone_number"] = comms_signal_phone
if "discord" in comms_platforms and comms_discord_token:
    secrets.setdefault("comms_tokens", {})["discord_bot_token"] = comms_discord_token
if "tailscale" in admin_tools and admin_tailscale_key:
    secrets["tailscale_authkey"] = admin_tailscale_key

webui_admin_email = env("WEBUI_ADMIN_EMAIL")
webui_admin_password = env("WEBUI_ADMIN_PASSWORD")
webui_admin_name = env("WEBUI_ADMIN_NAME")
webui_user_email = env("WEBUI_USER_EMAIL")
webui_user_password = env("WEBUI_USER_PASSWORD")
webui_user_name = env("WEBUI_USER_NAME")

if webui_admin_email and webui_admin_password:
    secrets["webui_credentials"] = {
        "admin": {
            "email": webui_admin_email,
            "password": webui_admin_password,
            "name": webui_admin_name or "Admin",
        }
    }
    if webui_user_email and webui_user_password:
        secrets["webui_credentials"]["user"] = {
            "email": webui_user_email,
            "password": webui_user_password,
            "name": webui_user_name or webui_user_email.split("@")[0],
        }

if len(secrets) > 1 or _manifest_secrets:   # more than just _meta
    if _manifest_secrets:
        secrets["env_vars"] = _manifest_secrets
    with open(secrets_json, "w") as f:
        json.dump(secrets, f, indent=2)
    os.chmod(secrets_json, stat.S_IRUSR | stat.S_IWUSR)
    print(f"  ✓  Secrets saved → {secrets_json}  (chmod 600, gitignored)")

# Clean up temp state file
if state_file and os.path.exists(state_file):
    os.unlink(state_file)
PYEOF

echo ""
info "Configuration complete."
echo ""
