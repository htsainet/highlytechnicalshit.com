# Audio Flamingo References

Last updated: 2026-04-15

## Upstream

- [GitHub — NVIDIA/audio-flamingo](https://github.com/NVIDIA/audio-flamingo)

## Models (HuggingFace)

- [nvidia/audio-flamingo-3-hf](https://huggingface.co/nvidia/audio-flamingo-3-hf) — base model (7B)
- [nvidia/audio-flamingo-3-chat](https://huggingface.co/nvidia/audio-flamingo-3-chat) — chat variant with streaming TTS
- [nvidia/music-flamingo-hf](https://huggingface.co/nvidia/music-flamingo-hf) — music-specialized variant

## Official documentation

- [Audio Flamingo 3 paper (arXiv)](https://arxiv.org/abs/2507.08128)
- [Music Flamingo paper (arXiv)](https://arxiv.org/abs/2511.10289)
- [NVIDIA Research — AF3 Demo](https://research.nvidia.com/labs/adlr/AF3/)
