# Bundle Scripts

Last updated: 2026-04-04 23:00:00

## What happens here

Bundle scripts orchestrate groups of component scripts into deployable feature sets. Each bundle represents a user-facing capability (chat, image generation, voice, etc.) and handles the correct install order, dependency wiring, and health verification for all services in the group.

## Process / Workflow

1. User or `install.sh` invokes a bundle: `./scripts/bundles/chat.sh`
2. Bundle sources `lib/common.sh`, calls `banner()` and `load_env()`
3. Bundle sources and calls the component scripts it needs, in dependency order
4. After all components are installed/started, bundle runs aggregate health checks
5. Bundle reports final status

## Files and structure

| File | Bundle | Components orchestrated |
|------|--------|------------------------|
| `chat.sh` | Core chat | ollama, open-webui, dashboard |
| `deerflow.sh` | Research agent | deerflow + chat deps |
| `full-stack.sh` | Everything | All components |
| `image-gen.sh` | Image generation | stable-diffusion and/or comfyui |
| `nemoclaw.sh` | Sandbox security | nemoclaw, bitnet, llama-swap |
| `openspace.sh` | Agent skills | openspace + chat deps |
| `voice.sh` | Voice pipeline | Voice services + chat deps |

## What good looks like

- Bundle names match their feature set
- Always source `lib/common.sh` first
- Call components in dependency order (e.g. ollama before open-webui)
- Idempotent — safe to re-run
- No direct `docker compose` calls — delegate to component scripts
- Exit with clear success/failure status

## Tools and skills

- **Component scripts** — `scripts/components/*.sh` provide per-service lifecycle
- **lib/common.sh** — `banner()`, `load_env()`, logging functions
- **lib/compose.sh** — Docker Compose wrappers (used indirectly via components)
