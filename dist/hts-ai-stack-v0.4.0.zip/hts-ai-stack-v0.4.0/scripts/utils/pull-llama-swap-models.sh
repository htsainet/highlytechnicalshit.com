#!/usr/bin/env bash
# pull-llama-swap-models.sh — pull every Ollama model listed in
# config/llama-swap.yaml into the running `ollama` compose service.
#
# Why: llama-swap only routes to models Ollama already has on disk.
# Running this once after a fresh install (or after editing the
# llama-swap config) pre-populates the cache so every route works on
# first request instead of stalling behind a pull.
#
# Usage:
#   ./scripts/utils/pull-llama-swap-models.sh          # all peers except bitnet
#   ./scripts/utils/pull-llama-swap-models.sh --peer ollama    # explicit peer
#   ./scripts/utils/pull-llama-swap-models.sh --dry-run        # list only
#
# Exit codes:
#   0  all pulls succeeded (or --dry-run completed)
#   1  argument / environment error
#   2  one or more pulls failed — names printed at end
#
# Idempotent: `ollama pull` is a no-op when the model is already present.

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
CONFIG="${REPO_DIR}/config/llama-swap.yaml"
COMPOSE="${REPO_DIR}/docker-compose.yml"
PEER_FILTER="ollama"
DRY_RUN=false

say()  { printf '\n\033[1;36m[pull-models]\033[0m %s\n' "$*"; }
info() { printf '  %s\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n' "$*"; }
fail() { printf '\033[1;31m[FAIL]\033[0m %s\n' "$*" >&2; exit 1; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --peer)    PEER_FILTER="${2:?--peer needs a value}"; shift 2 ;;
    --all)     PEER_FILTER="";                           shift   ;;
    --dry-run) DRY_RUN=true;                             shift   ;;
    -h|--help) sed -n '2,22p' "$0"; exit 0 ;;
    *) fail "Unknown argument: $1" ;;
  esac
done

[[ -f "$CONFIG" ]]  || fail "config not found: $CONFIG"
[[ -f "$COMPOSE" ]] || fail "docker-compose.yml not found: $COMPOSE"

# Extract models from llama-swap.yaml using a small Python parser.
# Avoids guessing YAML indentation with grep/awk — the file is an
# authoritative config, so we parse it properly.
mapfile -t MODELS < <(
  PEER_FILTER="$PEER_FILTER" python3 - "$CONFIG" <<'PY'
import os, sys, re

path = sys.argv[1]
want_peer = os.environ.get("PEER_FILTER", "")

try:
    import yaml  # PyYAML may not be installed on a bare host
    with open(path) as fh:
        doc = yaml.safe_load(fh) or {}
    peers = doc.get("peers", {}) or {}
    for peer, cfg in peers.items():
        if want_peer and peer != want_peer:
            continue
        for m in (cfg or {}).get("models", []) or []:
            if isinstance(m, str) and m.strip():
                print(m.strip())
    sys.exit(0)
except ModuleNotFoundError:
    pass  # fall through to regex parser

# Minimal fallback parser — handles the exact shape of this file:
#   peers:
#     <peer>:
#       models:
#         - <model>
current_peer = None
in_models   = False
with open(path) as fh:
    for raw in fh:
        line = raw.rstrip("\n")
        if re.match(r"^[a-zA-Z0-9_-]+:", line):           # top-level key
            current_peer, in_models = None, False
            continue
        m = re.match(r"^  ([a-zA-Z0-9_-]+):\s*$", line)   # peer
        if m:
            current_peer, in_models = m.group(1), False
            continue
        if re.match(r"^    models:\s*$", line):
            in_models = True
            continue
        if in_models:
            mm = re.match(r"^      -\s+(\S.*?)\s*$", line)
            if mm:
                if want_peer and current_peer != want_peer:
                    continue
                val = mm.group(1)
                if val.startswith("#"):
                    continue
                print(val)
            elif line.strip() and not line.startswith("      "):
                in_models = False
PY
)

if [[ "${#MODELS[@]}" -eq 0 ]]; then
  fail "no models found in $CONFIG (peer filter: '${PEER_FILTER:-<all>}')"
fi

say "Models to pull (${#MODELS[@]}):"
for m in "${MODELS[@]}"; do info "• $m"; done

if [[ "$DRY_RUN" == "true" ]]; then
  say "--dry-run set — exiting without pulling."
  exit 0
fi

# Ensure the ollama service is up
if ! docker compose -f "$COMPOSE" ps --services --status running 2>/dev/null \
     | grep -qx "ollama"; then
  warn "ollama compose service is not running — starting it"
  docker compose -f "$COMPOSE" up -d ollama \
    || fail "could not start ollama service"
fi

say "Pulling models (this may take a while on first run)"
FAILED=()
for model in "${MODELS[@]}"; do
  printf '\n── %s\n' "$model"
  if docker compose -f "$COMPOSE" exec -T ollama ollama pull "$model"; then
    printf '   ✓ %s\n' "$model"
  else
    printf '   ✗ %s — pull failed\n' "$model"
    FAILED+=("$model")
  fi
done

echo
if [[ "${#FAILED[@]}" -gt 0 ]]; then
  warn "Failed pulls (${#FAILED[@]}):"
  for m in "${FAILED[@]}"; do info "• $m"; done
  exit 2
fi

say "All ${#MODELS[@]} models pulled successfully."
