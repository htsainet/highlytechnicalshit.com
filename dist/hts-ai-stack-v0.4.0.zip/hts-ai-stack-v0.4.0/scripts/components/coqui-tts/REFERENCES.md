# Coqui TTS References

Last updated: 2026-04-15

## Upstream

- [GitHub — idiap/coqui-ai-TTS](https://github.com/idiap/coqui-ai-TTS)
  (community fork maintained by Idiap Research Institute)

## Official documentation

- [Coqui TTS README](https://github.com/idiap/coqui-ai-TTS#readme)
- [XTTS v2 Model Card](https://huggingface.co/coqui/XTTS-v2)

## Related

- See [FEATURE-025](../../../docs/development/features/FEATURE-025.md)
  for the original feature proposal.
