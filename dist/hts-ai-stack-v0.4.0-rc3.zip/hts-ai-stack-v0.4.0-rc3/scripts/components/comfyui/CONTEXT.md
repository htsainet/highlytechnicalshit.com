# ComfyUI Component

Last updated: 2026-04-17

## What happens here

ComfyUI is a node-based interface for Stable Diffusion image generation.
Used in the stack as the primary image generation workflow tool with
GPU acceleration via CUDA.

## Files and structure

| File | Purpose |
|------|---------|
| `comfyui.sh` | Full lifecycle: install, configure, start, stop, health, seed-models |
| `comfyui.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Model download guard

`_comfyui_download_model()` checks if a model file already exists and is
larger than 1MB before downloading. Files under 1MB are treated as partial
or corrupted downloads and re-downloaded. This prevents re-downloading
multi-GB checkpoints on every converge run. Ollama and Stable Diffusion
have similar skip-if-exists guards.
