$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/audio-flamingo'
    $script:ComponentScript = Join-Path $script:ComponentDir 'audio-flamingo.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'audio-flamingo.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'audio-flamingo file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }
}

# ── Manifest validation ─────────────────────────────────────────────────────

Describe 'audio-flamingo manifest' {

    BeforeAll {
        $script:Manifest = Get-Content -Path $script:ManifestFile -Raw |
            ConvertFrom-Json
    }

    It 'id is audio-flamingo' {
        $script:Manifest.id | Should -Be 'audio-flamingo'
    }

    It 'category is audio' {
        $script:Manifest.category | Should -Be 'audio'
    }

    It 'profile is audio-flamingo' {
        $script:Manifest.profile | Should -Be 'audio-flamingo'
    }

    It 'dashboard port is 8601' {
        [int]$script:Manifest.dashboard.port | Should -Be 8601
    }

    It 'script path points to component subfolder' {
        $script:Manifest.script | Should -Be 'scripts/components/audio-flamingo/audio-flamingo.sh'
    }

    It 'install_type is compose' {
        $script:Manifest.install_type | Should -Be 'compose'
    }
}

# ── Port allocation ──────────────────────────────────────────────────────────

Describe 'audio-flamingo port allocation' {

    BeforeAll {
        $script:Portmap = Get-Content -Path (
            Join-Path $script:RepoRoot 'config/portmap.json') -Raw | ConvertFrom-Json
    }

    It 'port 8601 is registered in portmap.json' {
        $script:Portmap.ports.'8601' | Should -Not -BeNullOrEmpty
        $script:Portmap.ports.'8601'.service | Should -Be 'audio-flamingo'
    }
}

# ── CLI flags ────────────────────────────────────────────────────────────────

Describe 'audio-flamingo CLI flags' {

    BeforeAll {
        $script:ScriptContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'supports --install flag' {
        $script:ScriptContent | Should -Match '--install'
    }

    It 'supports --configure flag' {
        $script:ScriptContent | Should -Match '--configure'
    }

    It 'supports --start flag' {
        $script:ScriptContent | Should -Match '--start'
    }

    It 'supports --stop flag' {
        $script:ScriptContent | Should -Match '--stop'
    }

    It 'supports --restart flag' {
        $script:ScriptContent | Should -Match '--restart'
    }

    It 'supports --health flag' {
        $script:ScriptContent | Should -Match '--health'
    }

    It 'supports --status flag' {
        $script:ScriptContent | Should -Match '--status'
    }

    It 'supports --destroy flag' {
        $script:ScriptContent | Should -Match '--destroy'
    }

    It 'supports --cpu flag' {
        $script:ScriptContent | Should -Match '--cpu'
    }

    It 'supports --gpu flag' {
        $script:ScriptContent | Should -Match '--gpu'
    }
}

# ── Compose integration ─────────────────────────────────────────────────────

Describe 'audio-flamingo compose integration' {

    BeforeAll {
        $script:ComposeContent = Get-Content -Path (
            Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'audio-flamingo service is defined in docker-compose.yml' {
        $script:ComposeContent | Should -Match 'audio-flamingo:'
    }

    It 'uses audio-flamingo profile' {
        $script:ComposeContent | Should -Match 'audio-flamingo'
    }

    It 'Dockerfile exists' {
        Join-Path $script:RepoRoot 'docker/audio-flamingo/Dockerfile' | Should -Exist
    }
}

# ── Quantization support ────────────────────────────────────────────────────

Describe 'audio-flamingo quantization support' {
    BeforeAll {
        $script:Dockerfile = Get-Content -Path (Join-Path $script:RepoRoot 'docker/audio-flamingo/Dockerfile') -Raw
        $script:ServerPy = Get-Content -Path (Join-Path $script:RepoRoot 'docker/audio-flamingo/server.py') -Raw
        $script:ComposeContent = Get-Content -Path (Join-Path $script:RepoRoot 'docker-compose.yml') -Raw
    }

    It 'Dockerfile installs bitsandbytes for quantization' {
        $script:Dockerfile | Should -Match 'bitsandbytes'
    }

    It 'Dockerfile uses devel base image for CUDA toolkit' {
        $script:Dockerfile | Should -Match 'cudnn9-devel'
    }

    It 'server.py reads AF_QUANTIZE environment variable' {
        $script:ServerPy | Should -Match 'AF_QUANTIZE'
    }

    It 'server.py supports int4 quantization' {
        $script:ServerPy | Should -Match 'load_in_4bit'
    }

    It 'server.py supports int8 quantization' {
        $script:ServerPy | Should -Match 'load_in_8bit'
    }

    It 'server.py auto-detects VRAM for quantization mode' {
        $script:ServerPy | Should -Match 'total_memory'
    }

    It 'compose defines AF_QUANTIZE with auto default' {
        $script:ComposeContent | Should -Match 'AF_QUANTIZE=\$\{AF_QUANTIZE:-auto\}'
    }

    It 'compose defines AF_DEVICE with auto default' {
        $script:ComposeContent | Should -Match 'AF_DEVICE=\$\{AF_DEVICE:-auto\}'
    }
}
