#!/usr/bin/env bash
# scripts/components/signal/signal.sh — Signal CLI messaging integration
#
# Standalone usage:
#   ./scripts/components/signal/signal.sh              # full: install + configure + start + health
#   ./scripts/components/signal/signal.sh --install    # install only
#   ./scripts/components/signal/signal.sh --configure  # configure only
#   ./scripts/components/signal/signal.sh --start      # start only
#   ./scripts/components/signal/signal.sh --stop       # stop (no-op, signal-cli is on-demand)
#   ./scripts/components/signal/signal.sh --restart    # restart (stop + start)
#   ./scripts/components/signal/signal.sh --health     # health check only
#   ./scripts/components/signal/signal.sh --status     # show status + health
#   ./scripts/components/signal/signal.sh --destroy    # destroy (uninstall signal-cli)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
SIGNAL_PHONE="${SIGNAL_PHONE:-}"
SIGNAL_CLI_VERSION="${SIGNAL_CLI_VERSION:-0.14.2}"

# ── Functions ────────────────────────────────────────────────────────────────

# signal_install — Install signal-cli binary
signal_install() {
  step "Signal — install"

  if command -v signal-cli &>/dev/null; then
    info "signal-cli already installed: $(signal-cli --version 2>/dev/null || echo 'unknown version')"
    ok "Signal CLI present."
    return
  fi

  local install_dir="/opt/signal-cli"
  local archive="signal-cli-${SIGNAL_CLI_VERSION}-Linux-native.tar.gz"
  local url="https://github.com/AsamK/signal-cli/releases/download/v${SIGNAL_CLI_VERSION}/${archive}"

  info "Downloading signal-cli v${SIGNAL_CLI_VERSION}..."
  local tmp_dir
  tmp_dir=$(mktemp -d)
  curl -fsSL "$url" -o "$tmp_dir/$archive"

  sudo mkdir -p "$install_dir"
  sudo tar xzf "$tmp_dir/$archive" -C "$install_dir" --strip-components=1
  sudo ln -sf "$install_dir/bin/signal-cli" /usr/local/bin/signal-cli

  rm -rf "$tmp_dir"
  ok "signal-cli v${SIGNAL_CLI_VERSION} installed."
}

# signal_configure — Register or link Signal account
signal_configure() {
  step "Signal — configure"

  local env_file="$REPO_DIR/.env"

  # Read phone from .env or prompt
  if [[ -z "$SIGNAL_PHONE" ]] && [[ -f "$env_file" ]]; then
    SIGNAL_PHONE=$(grep '^SIGNAL_PHONE=' "$env_file" | cut -d= -f2- | tr -d '[:space:]' || true)
  fi

  if [[ -z "$SIGNAL_PHONE" ]]; then
    echo ""
    warn "SIGNAL_PHONE not found in .env."
    echo "  Format: +<country-code><number> (e.g. +15551234567)"
    read -r -p "  Phone number: " SIGNAL_PHONE
    [[ -n "$SIGNAL_PHONE" ]] || { fail "No phone number provided."; return 1; }
    echo "SIGNAL_PHONE=${SIGNAL_PHONE}" >> "$env_file"
    info "Phone number saved to .env."
  else
    info "Signal phone: ${SIGNAL_PHONE}"
  fi

  # Check if already registered
  if signal-cli -u "$SIGNAL_PHONE" receive --timeout 1 &>/dev/null 2>&1; then
    info "Signal account already registered/linked."
    ok "Signal configured."
    return
  fi

  # Offer registration or device linking
  echo ""
  echo "  Signal account setup:"
  echo "    1) Register new account (requires captcha + SMS verification)"
  echo "    2) Link as secondary device (scan QR from existing Signal app)"
  echo ""
  read -r -p "  Choice [1/2]: " setup_choice

  case "${setup_choice:-2}" in
    1)
      info "Starting registration for ${SIGNAL_PHONE}..."
      echo "  Visit https://signalcaptchas.org/registration/generate.html"
      echo "  Complete the captcha and paste the signalcaptcha:// URL."
      read -r -p "  Captcha URL: " captcha_url
      signal-cli -u "$SIGNAL_PHONE" register --captcha "$captcha_url"
      echo ""
      read -r -p "  Enter SMS verification code: " verify_code
      signal-cli -u "$SIGNAL_PHONE" verify "$verify_code"
      ;;
    2)
      info "Generating QR code for device linking..."
      local device_name="${HOSTNAME:-hts-ai-stack}"
      signal-cli link -n "$device_name" &
      local link_pid=$!
      # Give it time to print the QR/URI
      wait "$link_pid" 2>/dev/null || true
      ;;
    *)
      warn "Invalid choice — skipping account setup."
      return 1
      ;;
  esac

  # Set profile name
  local profile_name="${HOSTNAME:-hts-ai-stack}"
  signal-cli -u "$SIGNAL_PHONE" updateProfile --given-name "$profile_name" 2>/dev/null || true

  ok "Signal configured for ${SIGNAL_PHONE}."
}

# signal_start — No-op (signal-cli is an on-demand tool, not a daemon)
signal_start() {
  step "Signal — start"
  info "signal-cli is an on-demand command-line tool, not a daemon."
  info "To send a test message:"
  info "  signal-cli -u \"$SIGNAL_PHONE\" send -m 'Hello from HTS-AI' <recipient>"
  ok "Signal ready for use."
}

# signal_stop — No-op
signal_stop() {
  step "Signal — stop"
  info "signal-cli has no running daemon to stop."
  ok "Signal stop complete."
}

# signal_health — Check if signal-cli is installed and account is configured
signal_health() {
  step "Signal — health"

  if ! command -v signal-cli &>/dev/null; then
    warn "signal-cli not installed."
    return 1
  fi
  info "signal-cli: $(signal-cli --version 2>/dev/null || echo 'installed')"

  if [[ -n "$SIGNAL_PHONE" ]]; then
    # Try a quick receive to validate account
    if signal-cli -u "$SIGNAL_PHONE" receive --timeout 1 &>/dev/null 2>&1; then
      ok "Signal account $SIGNAL_PHONE is active."
    else
      warn "Signal account $SIGNAL_PHONE may not be registered."
    fi
  else
    warn "SIGNAL_PHONE not configured."
  fi
}

signal_restart() {
  signal_stop
  signal_start
}

signal_destroy() {
  step "Signal — destroy"
  signal_stop
  warn "Signal CLI is a host package — run 'sudo apt remove signal-cli' for full removal."
  ok "Signal destroy complete."
}

signal_status() {
  step "Signal — status"
  if command -v signal-cli &>/dev/null; then
    ok "Signal CLI is installed."
  else
    warn "Signal CLI is not installed."
  fi
  signal_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   signal_install   ;;
    configure) signal_configure ;;
    start)     signal_start     ;;
    stop)      signal_stop      ;;
    restart)   signal_restart   ;;
    health)    signal_health    ;;
    status)    signal_status    ;;
    destroy)   signal_destroy   ;;
    default)
      signal_install
      signal_configure
      signal_start
      signal_health
      ;;
  esac
fi
