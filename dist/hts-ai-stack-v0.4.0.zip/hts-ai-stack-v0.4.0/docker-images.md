# Docker Base Images — hts-ai-stack

All images pinned as of 2026-04-15. For Synology NAS mirroring.

## All Images (sorted)

| Image | Pinned Tag | Digest |
|---|---|---|
| `alphacep/kaldi-vosk-server` | `latest` ⚠️ | `sha256:381024347b95...` |
| `docker.n8n.io/n8nio/n8n` | `2.16.1` | `sha256:ad20607cdd24...` |
| `erikvl87/languagetool` | `6.7-dockerupdate-3` | `sha256:e1ea6a975388...` |
| `flowiseai/flowise` | `latest` ⚠️ | `sha256:c99242725f06...` |
| `ghcr.io/coqui-ai/tts` | `v0.22.0` | `sha256:bdbe05ed8594...` |
| `ghcr.io/google/cadvisor` | `0.56.2` | — |
| `ghcr.io/mostlygeek/llama-swap` | `cpu` | `sha256:f6355e100aa9...` |
| `ghcr.io/open-webui/open-webui` | `main` | `sha256:b8095f79a6a8...` |
| `ghcr.io/open-webui/pipelines` | `main` ⚠️ | `sha256:b48e9bc338ce...` |
| `ghcr.io/openclaw/openclaw` | `2026.4.14` | `sha256:7ea070b04d1e...` |
| `ghcr.io/sillytavern/sillytavern` | `latest` ⚠️ | `sha256:5520831198cd...` |
| `ghcr.io/speaches-ai/speaches` | `0.8.1-cuda` | `sha256:6ec12ebf890a...` |
| `gitea/gitea` | `1.25.5` | — |
| `grafana/grafana-oss` | `12.4.2` | — |
| `langflowai/langflow` | `1.9.0` | `sha256:01b48149017d...` |
| `lscr.io/linuxserver/duplicati` | `v2.3.0.0_stable_2026-04-14-ls288` | `sha256:1e4f61e7c4ac...` |
| `mmartial/comfyui-nvidia-docker` | `ubuntu24_cuda12.6.3-latest` | `sha256:20fea207e255...` |
| `nginx` | `1.29-alpine` | — |
| `node` | `20-slim` | — (build stage only) |
| `nvidia/dcgm-exporter` | `4.5.2-4.8.1-distroless` | — |
| `ollama/ollama` | `0.20.2` | `sha256:0455f166da85...` |
| `portainer/portainer-ce` | `2.40.0` | — |
| `prom/prometheus` | `v3.11.0` | — |
| `python` | `3.12-slim` | `sha256:3d5ed973e458...` |
| `pytorch/pytorch` | `2.6.0-cuda12.6-cudnn9-runtime` | — |
| `quay.io/go-skynet/local-ai` | `v4.1.3-gpu-nvidia-cuda-12` | `sha256:8b9688beeaea...` |
| `searxng/searxng` | `2026.4.13-ee66b070a` | `sha256:4c6b4f3e1fc1...` |
| `tailscale/tailscale` | `v1.96.5` | — |
| `ubuntu` | `24.04` | `sha256:186072bba1b2...` |
| `unsloth/unsloth` | `2026.4.4-pt2.9.0-vllm-0.16.0-cu12.8-studio-release-v0.1.35-beta` | — |

> ⚠️ = No version tag found; digest-pinned to `latest`/`main` as of 2026-04-15.
> These repos don't publish version-numbered tags pointing to the same manifest.

## Images Without Version Tags

These 4 images are **digest-locked** but still reference a rolling tag name.
Check for new releases periodically.

| Image | Rolling Tag | Notes |
|---|---|---|
| `alphacep/kaldi-vosk-server` | `latest` | Repo only publishes `latest` |
| `flowiseai/flowise` | `latest` | Version tags exist but don't match `latest` digest |
| `ghcr.io/open-webui/pipelines` | `main` | Only publishes `main` |
| `ghcr.io/sillytavern/sillytavern` | `latest` | Version tags exist but don't match `latest` digest |
