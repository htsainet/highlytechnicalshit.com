#!/usr/bin/env bash
# pin-docker-images.sh
# Resolves all unpinned Docker images to version tags + sha256 digests
# and updates the Dockerfiles in-place.
#
# Requires: skopeo, jq
# Usage: cd /path/to/hts-ai-stack && bash pin-docker-images.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$REPO_DIR"

for cmd in skopeo jq; do
  if ! command -v "$cmd" &>/dev/null; then
    echo "ERROR: $cmd is required but not installed." >&2
    exit 1
  fi
done

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# Images to pin: "dockerfile_path|current_from_reference"
IMAGES=(
  "docker/comfyui/Dockerfile|mmartial/comfyui-nvidia-docker:ubuntu24_cuda12.6.3-latest"
  "docker/coqui-tts/Dockerfile|ghcr.io/coqui-ai/tts:latest"
  "docker/duplicati/Dockerfile|lscr.io/linuxserver/duplicati:latest"
  "docker/faster-whisper/Dockerfile|ghcr.io/speaches-ai/speaches:latest-cuda"
  "docker/flowise/Dockerfile|flowiseai/flowise:latest"
  "docker/gvisor-sandbox/Dockerfile|ghcr.io/openclaw/openclaw:latest"
  "docker/langflow/Dockerfile|langflowai/langflow:latest"
  "docker/languagetool/Dockerfile|erikvl87/languagetool:latest"
  "docker/localai/Dockerfile|quay.io/go-skynet/local-ai:latest-gpu-nvidia-cuda-12"
  "docker/n8n/Dockerfile|docker.n8n.io/n8nio/n8n:latest"
  "docker/pipelines/Dockerfile|ghcr.io/open-webui/pipelines:main"
  "docker/searxng/Dockerfile|searxng/searxng:latest"

  "docker/vosk/Dockerfile|alphacep/kaldi-vosk-server:latest"
)

RESULTS_FILE="pin-results.log"
: > "$RESULTS_FILE"

echo -e "${YELLOW}Pinning ${#IMAGES[@]} Docker images using skopeo...${NC}"
echo ""

FAILED=0
PINNED=0

# Convert image reference to skopeo transport format
to_skopeo_ref() {
  local img="$1"
  # Docker Hub images without a registry prefix need docker.io/library/ or docker.io/
  if [[ "$img" != */* ]]; then
    # Official image (e.g., python, ubuntu, nginx)
    echo "docker://docker.io/library/${img}"
  elif [[ "$img" != *.* ]] || [[ "$img" == */* && "$img" != *.*/* ]]; then
    # Docker Hub user image (e.g., flowiseai/flowise)
    echo "docker://docker.io/${img}"
  else
    echo "docker://${img}"
  fi
}

for entry in "${IMAGES[@]}"; do
  IFS='|' read -r dockerfile image <<< "$entry"

  echo -n "  $image ... "

  img_name=$(echo "$image" | sed 's/:.*$//')
  img_tag=$(echo "$image" | grep -oP ':.+$' | sed 's/^://')
  skopeo_ref=$(to_skopeo_ref "$image")

  # Step 1: Get the digest for the current tag
  digest=$(skopeo inspect --format '{{.Digest}}' "$skopeo_ref" 2>/dev/null || true)

  if [[ -z "$digest" ]]; then
    # Try with --raw for multi-arch manifests
    digest=$(skopeo inspect --raw "$skopeo_ref" 2>/dev/null | jq -r '.manifests[0].digest // empty' 2>/dev/null) || true
  fi

  if [[ -z "$digest" ]]; then
    echo -e "${RED}FAILED (could not get digest)${NC}"
    echo "FAILED|$dockerfile|$image|digest lookup failed" >> "$RESULTS_FILE"
    ((FAILED++)) || true
    continue
  fi

  # Step 2: Try to find a version tag pointing to the same digest
  resolved_tag=""
  skopeo_base=$(to_skopeo_ref "${img_name}:dummy" | sed 's/:dummy$//')

  # List all tags from the registry
  tags_json=$(skopeo list-tags "${skopeo_base}" 2>/dev/null || true)

  if [[ -n "$tags_json" ]]; then
    # Filter for version-like tags (contain digits, exclude 'latest' and rolling tags)
    version_tags=$(echo "$tags_json" | jq -r '.Tags[]' 2>/dev/null \
      | grep -E '^v?[0-9]' \
      | grep -vE 'rc|alpha|beta|dev|nightly|edge|canary' \
      | sort -rV \
      | head -20 || true)

    for vtag in $version_tags; do
      vtag_ref=$(to_skopeo_ref "${img_name}:${vtag}")
      vtag_digest=$(skopeo inspect --format '{{.Digest}}' "$vtag_ref" 2>/dev/null || true)

      if [[ -z "$vtag_digest" ]]; then
        vtag_digest=$(skopeo inspect --raw "$vtag_ref" 2>/dev/null | jq -r '.manifests[0].digest // empty' 2>/dev/null) || true
      fi

      if [[ "$vtag_digest" == "$digest" ]]; then
        resolved_tag="$vtag"
        break
      fi
    done
  fi

  # Step 3: Build the pinned FROM reference
  if [[ -n "$resolved_tag" ]]; then
    pinned="${img_name}:${resolved_tag}@${digest}"
    display_tag="${resolved_tag}"
  else
    pinned="${image}@${digest}"
    display_tag="${img_tag}"
  fi

  # Step 4: Update the Dockerfile
  sed -i "s|FROM ${image}|FROM ${pinned}|g" "$dockerfile"

  if [[ -n "$resolved_tag" && "$resolved_tag" != "$img_tag" ]]; then
    echo -e "${GREEN}${resolved_tag}${NC} ${CYAN}(was ${img_tag})${NC} → ${digest:0:19}..."
  else
    echo -e "${GREEN}${display_tag}${NC} → ${digest:0:19}..."
  fi
  echo "OK|$dockerfile|$image|$pinned|$display_tag" >> "$RESULTS_FILE"
  ((PINNED++)) || true
done

echo ""
echo -e "${GREEN}Pinned: ${PINNED}${NC}  ${RED}Failed: ${FAILED}${NC}"
echo ""
echo "Results saved to $RESULTS_FILE"
echo ""

# Update the docker-images.md reference file
if [[ $PINNED -gt 0 ]]; then
  echo -e "${YELLOW}Updating docker-images.md...${NC}"

  {
    echo "# Docker Base Images — hts-ai-stack"
    echo ""
    echo "All images pinned to sha256 digests ($(date -I))."
    echo ""
    echo "## Version-Pinned Images"
    echo ""
    echo "| Image | Tag | Digest |"
    echo "|---|---|---|"
    echo "| \`ghcr.io/google/cadvisor\` | \`0.56.2\` | — |"
    echo "| \`gitea/gitea\` | \`1.25.5\` | — |"
    echo "| \`grafana/grafana-oss\` | \`12.4.2\` | — |"
    echo "| \`nginx\` | \`1.29-alpine\` | — |"
    echo "| \`node\` | \`20-slim\` | — (build stage) |"
    echo "| \`nvidia/dcgm-exporter\` | \`4.5.2-4.8.1-distroless\` | — |"
    echo "| \`portainer/portainer-ce\` | \`2.40.0\` | — |"
    echo "| \`prom/prometheus\` | \`v3.11.0\` | — |"
    echo "| \`pytorch/pytorch\` | \`2.6.0-cuda12.6-cudnn9-runtime\` | — |"
    echo "| \`tailscale/tailscale\` | \`v1.96.5\` | — |"
    echo "| \`unsloth/unsloth\` | \`2026.4.4-pt2.9.0-vllm-0.16.0-cu12.8-studio-release-v0.1.35-beta\` | — |"
    echo ""
    echo "## SHA256 Digest-Pinned Images"
    echo ""
    echo "| Image | Tag | Digest |"
    echo "|---|---|---|"

    # Existing pinned images
    echo "| \`ghcr.io/mostlygeek/llama-swap\` | \`cpu\` | \`sha256:f6355e...58b04\` |"
    echo "| \`ghcr.io/open-webui/open-webui\` | \`main\` | \`sha256:b8095f...3cfaeb\` |"
    echo "| \`ollama/ollama\` | \`0.20.2\` | \`sha256:0455f1...7fccd\` |"
    echo "| \`python\` | \`3.12-slim\` | \`sha256:3d5ed9...1fcf4\` |"
    echo "| \`ubuntu\` | \`24.04\` | \`sha256:186072...eef0c\` |"

    # Newly pinned images from results
    while IFS='|' read -r status file orig pinned display_tag; do
      if [[ "$status" == "OK" ]]; then
        orig_tag=$(echo "$orig" | grep -oP ':.+$' | sed 's/^://')
        name=$(echo "$orig" | sed "s/:${orig_tag}$//")
        short_digest=$(echo "$pinned" | grep -oP 'sha256:[a-f0-9]+' | head -c 25)
        if [[ "$display_tag" != "$orig_tag" ]]; then
          echo "| \`${name}\` | \`${display_tag}\` (was \`${orig_tag}\`) | \`${short_digest}...\` |"
        else
          echo "| \`${name}\` | \`${display_tag}\` | \`${short_digest}...\` |"
        fi
      fi
    done < "$RESULTS_FILE"

  } > docker-images.md

  echo -e "${GREEN}docker-images.md updated.${NC}"
fi

echo ""
echo "Done! Review changes with:  git diff docker/"
