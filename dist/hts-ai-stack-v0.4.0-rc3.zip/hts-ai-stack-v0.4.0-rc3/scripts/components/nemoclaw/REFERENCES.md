# NemoClaw References

Last updated: 2026-04-15

## Upstream

- [GitHub — NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw)

## Official documentation

- [NemoClaw v0.0.15 Quickstart](https://docs.nvidia.com/nemoclaw/0.0.15/get-started/quickstart.html)
- [NemoClaw Latest Docs](https://docs.nvidia.com/nemoclaw/latest/)
