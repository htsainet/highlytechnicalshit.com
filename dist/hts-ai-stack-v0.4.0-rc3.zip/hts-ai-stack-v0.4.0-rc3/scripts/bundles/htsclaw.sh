#!/usr/bin/env bash
# scripts/bundles/htsclaw.sh — Self-managed sandbox agent bundle
#
# Sets up the inference backend (dual-backend + llama-swap), htsclaw sandbox
# agent (direct OpenShell — no NemoClaw middleman), and optional dashboard.
#
# Usage:
#   ./scripts/bundles/htsclaw.sh [--chat mean|claw]
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "htsclaw Bundle"
load_env

CHAT_MODE="mean"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --chat) CHAT_MODE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

DASHBOARD_ENABLED="${DASHBOARD_ENABLED:-true}"

# ── Services (dual-backend + llama-swap) ──────────────────────────────────────
step "Backend"
bash "$REPO_DIR/scripts/components/ollama/ollama.sh" --swap "$CHAT_MODE"
bash "$REPO_DIR/scripts/components/bitnet/bitnet.sh"
bash "$REPO_DIR/scripts/components/llama-swap/llama-swap.sh"

step "htsclaw"
bash "$REPO_DIR/scripts/components/htsclaw/htsclaw.sh"

if [[ "$DASHBOARD_ENABLED" == "true" ]]; then
  bash "$REPO_DIR/scripts/components/dashboard/dashboard.sh"
fi

echo ""
ok "htsclaw bundle ready — dual-backend (GPU+CPU) chat:${CHAT_MODE}"
