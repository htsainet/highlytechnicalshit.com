# Framework Structure Reference

This document explains the three-layer folder architecture used in this project, what it is for, and why the framework tests exist.

## The Three Layers Explained

The framework is based on three layers that separate concerns and allow Claude (or any AI agent) to work effectively on complex projects.

### Layer 1: The Map (CLAUDE.md)

**What it is:** A single file at the project root that tells Claude where everything is and how to navigate.

**What's in it:**

- Project identity (who you are, what you're building)
- A set of rules (technical constraints, must-haves)
- A routing table that says: for this type of task, go to this folder and read this file

**Why it matters:** This is the spec. A tight spec means Claude knows exactly where to go and what to do. It is not a brain dump of everything you want Claude to know. It is a routing instruction that keeps the context window focused.

**In your project:**

- Identity: "helping Tim build installation and configuration scripts"
- Rules: local LLM, GPU utilization, security best practices
- Routing: 11 task types → specific folders and CONTEXT.md files
- Quick nav: What file to read for each type of work

### Layer 2: The Rooms (Workspace CONTEXT.md files)

**What it is:** Each workspace (folder) has its own CONTEXT.md that describes what happens there.

**What's in each one:**

- Purpose: what this workspace is for
- Process / Workflow: how work flows through (discovery → implementation → validation)
- Files and structure: what files live here and how they're organized
- Standards: what good work looks like, what to avoid
- Tools and skills: which external tools are needed

**Why it matters:** These are your style guides and component registries. When Claude reads `/docs/CONTEXT.md`, it understands the documentation workspace: guides, features, issues, planning. When Claude reads `/scripts/CONTEXT.md`, it understands the installation process: bootstrap → install → validation. Each workspace has its own rules.

**In your project:** 13 CONTEXT.md files across:

- `/` (root project overview)
- `/docs` (documentation hub)
- `/scripts` (installation scripts)
- `/tests` (Pester test suite)
- `/docs/pipeline` (step-by-step guides)
- `/docs/development/features` (feature proposals)
- `/docs/development/issues` (bug tracking)
- `/docs/planning/*` (research, reviews, security)

Each one describes its own workflow and standards.

### Layer 3: The Tools (Tests and Validation)

**What it is:** Tests that validate the framework itself—ensuring Layer 1 and Layer 2 work as intended.

**What they check:**

- Layer 1 (CLAUDE.md) is concise, has a routing table, points to real places
- Layer 2 (CONTEXT.md files) are consistent, current, documented
- References (REFERENCES.md) provide the architecture and tool information
- Workspace structure is logical, not flat
- Links and references are not broken

**Why it matters:** The system is only useful if it works. These tests catch entropy: a routing entry that points to a deleted folder, a CONTEXT.md that goes stale, a broken link. They also enforce consistency—if all CONTEXT files follow the same structure, Claude can navigate any workspace using the same pattern.

## How It Works Together

The workflow (simplified):

1. You tell Claude: "Work on feature X"
2. Claude reads CLAUDE.md, finds the routing entry for feature work
3. Routing says: go to `/docs/development/features`, read `CONTEXT.md`
4. Claude reads that CONTEXT.md, understands the feature workflow
5. Claude works within that structure, aware of tools needed, standards to follow
6. All references point to real files; all tools are documented

What breaks the system:

- CLAUDE.md is bloated (> 50 lines) → too much context, Claude spends tokens reading irrelevant info
- Routing entry points to a folder that doesn't exist → Claude gets confused
- CONTEXT.md is vague ("be creative") instead of specific → Claude guesses instead of following rules
- Tool dependencies are not documented → Claude suggests a tool that isn't available
- Links are broken → Claude can't find referenced documentation
- Timestamps are stale (> 90 days) → you can't tell if a context file is obsolete

How tests prevent this:

Each test validates one aspect of the system. Together, they ensure:

- ✅ The routing table is accurate and points to real workspaces
- ✅ Every workspace CONTEXT file follows the same structure
- ✅ All CONTEXT files document their tools and dependencies
- ✅ Timestamps show currency (files updated within 90 days)
- ✅ All links point to existing files
- ✅ Files are not oversized or empty
- ✅ Framework files use consistent headers and organization

## The Constraints That Make It Work

From the animation example: constraints improve creativity. In this framework:

**CLAUDE.md constraint:** "Fit on one screen" (< 50 lines)

- Forces clarity. You can't hide instructions. The routing table is visible. Decisions must be explicit.

**CONTEXT.md constraint:** "Standard sections" (Purpose, Process, Standards, Tools)

- Claude learns to navigate any workspace the same way. Predictability improves accuracy.

**Living document constraint:** "Last updated within 90 days"

- Forces you to touch and review documentation regularly. Stale docs are dangerous (Claude follows old instructions).

**Routing constraint:** "Every workspace is routed or nested under a routed parent"

- Prevents orphaned folders. Every piece of work has a clear entry point.

## How to Maintain This

Create a new workspace:

1. Create the folder (e.g., `/docs/guides`)
2. Create `/docs/guides/CONTEXT.md` with Purpose, Process, Structure, Standards, Tools
3. Add a line to CLAUDE.md's routing table
4. Run the tests to verify it's wired correctly

Update a CONTEXT.md file:

1. Update the content
2. The timestamp will auto-update next time you run `scripts/utils/Update-ContextTimestamps.ps1`
3. Git commit includes the updated timestamp

Update CLAUDE.md:

1. Keep it under 50 lines
2. Update the routing table if you added/removed workspaces
3. Keep paths and file references accurate (tests will catch errors)

Fix a failing test:

- Read the test name and failure message
- It will tell you exactly what's broken (broken link, missing section, missing routing entry, etc.)
- Fix the specific issue
- Re-run the test to verify

## The Tests (What Each One Validates)

Test-FrameworkStructure.Tests.ps1 contains the framework compliance tests for this repo.

| Context | Tests | What It Validates |
|---------|-------|-------------------|
| CLAUDE.md routing file | 7 | File size, routing table presence, no bloat, proper structure |
| CONTEXT.md files | 4 | File existence, content substantiveness, work-focused (not personality) |
| REFERENCES.md | 3 | Architecture documentation, service links, no hardware inventories |
| Routing table structure | 3 | Table entries count, paths point to real workspaces |
| Workspace structure | 2 | Logical folder nesting, key directories exist |
| Documentation completeness | 2 | README exists, framework files present |
| CONTEXT.md structure consistency | 5 | Purpose/Process/Standards sections, consistent headers |
| Living document markers | 2 | Timestamps present, recent (within 90 days) |
| Layer 3 skills & tools | 1 | Tools/skills documented in each workspace |
| Routing table completeness | 1 | All workspaces routed or under routed parent |
| Section name consistency | 1 | Standard section headers across all CONTEXT files |
| Link validation | 1 | Markdown links point to existing files |
| Anti-patterns | 1 | No oversized files, no empty stubs, no bloat |

Total: 38 tests, all must pass.

## Reference: This Framework in Action

Analogy from the animation example:

- **Spec** = CLAUDE.md (clear, tight routing and identity)
- **Style guide** = REFERENCES.md (architecture, tools, patterns)
- **Component registry** = CONTEXT.md files (reusable patterns per workspace)
- **Implementation** = Claude Code writes scripts/docs/tests following the structure
- **Tests** = Validate that the spec, guides, and registry stay synchronized

Just like Remotion lets you assemble React components into video scenes, this framework lets you assemble Claude-assisted work into larger projects. The constraints (tight specs, documented tools, consistent structure) do not limit you. They clarify what you are building and let Claude focus on execution instead of guessing.

## When to Use This Framework

This framework works well for:

- Multi-stage projects where different work happens in different places
- Work that uses different tools/skills in different workspaces
- Projects where consistency matters (shared language, documentation, naming)
- Systems where multiple people (or multiple AI agents in sequence) need to work without confusion
- Long-lived projects where documentation decay is a risk

It's overkill for:

- Single-file scripts or one-off tasks
- Temporary projects (< 1 week)
- Very small projects with only one person and one workspace

## Quick Start Reference

If you are new to this project:

1. **Read CLAUDE.md** (2 min) — Understand project identity and where to go
2. **Read the routing table** (1 min) — See what type of work maps to which folder
3. **Go to your task's folder** — Find the CONTEXT.md
4. **Read that CONTEXT.md** (3 min) — Understand the workflow, tools, standards
5. **Start work** — You now know what to do and where to do it

---

## Document Info

Last updated: 2026-03-31

This document describes Test-FrameworkStructure.Tests.ps1 and the three-layer architecture it validates.

Framework source attribution lives in `REFERENCES.md` for this folder.
