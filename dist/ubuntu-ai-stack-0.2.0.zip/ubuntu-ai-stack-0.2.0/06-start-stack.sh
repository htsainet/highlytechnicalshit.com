#!/bin/bash

# Usage:
#   ./06-start-stack.sh        # start Ollama and connect both NemoClaw sandboxes
#   ./06-start-stack.sh --test # Ollama only (skip NemoClaw)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=setup/tooling/ui.sh
source "$SCRIPT_DIR/setup/tooling/ui.sh"

htsai_banner "06 — Start Stack"

RUN_NEMOCLAW=true
TEST_MODE=false

info() { echo -e "${GREEN}[INFO]${NC} $*"; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --test) TEST_MODE=true; RUN_NEMOCLAW=false; shift ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
done

# ── Pre-run checklist ─────────────────────────────────────────────────────────
checklist_start
checklist_item false "1. Create/verify AI network"
checklist_item false "2. Start Ollama"
if [ "$RUN_NEMOCLAW" = true ]; then
  checklist_item false "3. Connect NemoClaw (prod & test)"
else
  checklist_item true "3. Connect NemoClaw (prod & test) — skipped in --test mode"
fi
checklist_end

# ---------------------------------------------------------------------------
# Load .env so compose variable substitution (${VAR:?...}) can resolve at
# parse time — compose only auto-discovers .env in the compose file's own
# directory, not the repo root where the file actually lives.
# ---------------------------------------------------------------------------
if [[ -f "$SCRIPT_DIR/.env" ]]; then
  set -a
  # shellcheck source=/dev/null
  source "$SCRIPT_DIR/.env"
  set +a
else
  echo "Warning: .env not found at $SCRIPT_DIR/.env — run 01-autoinstall.sh first"
fi

# ---------------------------------------------------------------------------
# Ensure the shared Docker network exists before any compose up.
# Both instance compose files declare ai-network as external — it must exist
# first. The root compose creates it on first `up`, but this script may run
# before that ever happens.
# ---------------------------------------------------------------------------
AI_NETWORK="ubuntu-ai-stack_ai-network"
if ! docker network inspect "$AI_NETWORK" >/dev/null 2>&1; then
  echo "  Creating network $AI_NETWORK..."
  docker network create "$AI_NETWORK"
fi

# ---------------------------------------------------------------------------
# Step 1: Start Ollama (always)
# ---------------------------------------------------------------------------
echo ""
echo "══ Starting Ollama (prod + test) ══"
docker compose -f "$SCRIPT_DIR/instances/prod/docker-compose.yml" up -d ollama-prod --wait
echo "  ollama-prod  OK (11434)"
docker compose -f "$SCRIPT_DIR/instances/test/docker-compose.yml" up -d ollama-test --wait
echo "  ollama-test  OK (11435)"

# ---------------------------------------------------------------------------
# Step 2: (Optional) NemoClaw — connect both sandboxes
# ---------------------------------------------------------------------------
if [[ "$RUN_NEMOCLAW" == true && "$TEST_MODE" == false ]]; then
  declare -A SANDBOXES=(
    ["ubuntu-ai-assistant-prod"]="18789"
    ["ubuntu-ai-assistant-test"]="18790"
  )

  for sandbox in "ubuntu-ai-assistant-prod" "ubuntu-ai-assistant-test"; do
    port="${SANDBOXES[$sandbox]}"
    echo ""
    echo "══ NemoClaw — ${sandbox} ══"
    if NEMOCLAW_EXPERIMENTAL=1 nemoclaw "${sandbox}" status &>/dev/null; then
      echo "  Sandbox '${sandbox}' found — connecting..."
      NEMOCLAW_EXPERIMENTAL=1 nemoclaw "${sandbox}" connect &
      sleep 3
      echo "  NemoClaw connected (port ${port})"
    else
      echo "  Warning: sandbox '${sandbox}' not found — skipping."
      echo "  Create it with:  ./04-setup-nemoclaw.sh"
    fi
  done
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
echo ""
echo "══ Stack ready ══"
echo "  Ollama prod          : http://localhost:11434"
echo "  Ollama test          : http://localhost:11435"
if [[ "$TEST_MODE" == false ]]; then
  echo "  NemoClaw (prod)      : http://localhost:18789"
  echo "  NemoClaw (test)      : http://localhost:18790"
fi
echo ""
echo "To stop:    docker compose -f instances/prod/docker-compose.yml stop ollama-prod"
echo "            docker compose -f instances/test/docker-compose.yml stop ollama-test"
echo ""
echo "Manual up:  (from repo root) source .env && docker compose -f instances/prod/docker-compose.yml up"
echo "            (from instances/prod/) docker compose --env-file ../../.env up"

