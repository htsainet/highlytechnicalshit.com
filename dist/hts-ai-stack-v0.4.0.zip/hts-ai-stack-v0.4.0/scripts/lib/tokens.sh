#!/usr/bin/env bash
# scripts/lib/tokens.sh — Token/secret generation and .env key management
# Source this file; do NOT run directly.
# Requires: common.sh sourced first (for REPO_DIR, info, fail)

# generate_token [length_bytes] — Print a cryptographically random hex token.
generate_token() {
  local bytes="${1:-32}"
  openssl rand -hex "$bytes"
}

# ensure_env_key <key> — If key is missing or empty in .env, generate and write a token.
ensure_env_key() {
  local key="$1"
  local env_file="${REPO_DIR}/.env"
  local value

  [[ -f "$env_file" ]] || fail ".env not found at $env_file — cannot ensure key $key"

  if ! grep -Eq "^${key}=" "$env_file" || grep -Eq "^${key}=[[:space:]]*$" "$env_file"; then
    value=$(generate_token)
    if grep -Eq "^${key}=" "$env_file"; then
      # Key exists but empty — replace in-place using pure-bash loop (no awk/sed).
      # Matches the pattern used by menu-handler.sh _write_env. Avoids awk FS="="
      # field corruption when values contain '=' (e.g. base64 tokens).
      local tmp found=0
      tmp=$(mktemp)
      while IFS= read -r line; do
        if [[ "$line" == "${key}="* && $found -eq 0 ]]; then
          echo "${key}=${value}"
          found=1
        else
          echo "$line"
        fi
      done < "$env_file" > "$tmp" && mv "$tmp" "$env_file"
    else
      printf '%s=%s\n' "$key" "$value" >> "$env_file"
    fi
    info "Set ${key}: ${value:0:8}..."
  else
    info "${key} already present."
  fi
}

# read_env_key <key> — Print the value of a key from .env (empty string if not found).
read_env_key() {
  local key="$1"
  local env_file="${REPO_DIR}/.env"

  if [[ -f "$env_file" ]]; then
    grep -E "^${key}=" "$env_file" 2>/dev/null | head -1 | cut -d'=' -f2-
  fi
}
