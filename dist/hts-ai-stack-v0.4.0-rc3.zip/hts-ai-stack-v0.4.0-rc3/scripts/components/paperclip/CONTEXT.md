# Paperclip Component

Last updated: 2026-04-17

## What happens here

Paperclip is an open-source AI agent orchestration platform for
zero-human companies. Provides org charts, budgets, governance,
and multi-agent coordination with a web UI and API.

## Files and structure

| File | Purpose |
|------|---------|
| `paperclip.sh` | Full lifecycle: install, configure, start, stop, health |
| `Dockerfile` | Multi-stage build with tsx runtime and non-root user |
| `CONTEXT.md` | This file — component-level context |

## Upstream

- [GitHub — PaperclipAI/paperclip](https://github.com/PaperclipAI/paperclip) (assumed)

## Deployment modes

Only two valid modes (defined in `packages/shared/src/constants.ts`):

| Mode | Bind | Use case |
|------|------|----------|
| `local_trusted` | loopback only (127.0.0.1) | Direct host access, no Docker |
| `authenticated` | any (`lan`, `tailnet`, `custom`) | Docker, remote access |

We use `authenticated` + `lan` (0.0.0.0) because Docker port mapping
requires binding to all interfaces inside the container.

## Environment variables

| Variable | Purpose | Default |
|----------|---------|---------|
| `PAPERCLIP_DEPLOYMENT_MODE` | `authenticated` or `local_trusted` | `authenticated` |
| `PAPERCLIP_BIND` | `loopback`, `lan`, `tailnet`, `custom` | `lan` |
| `HOST` | Listen address | `0.0.0.0` |
| `PORT` | Server port | `3101` |
| `BETTER_AUTH_SECRET` | Session signing key (≥32 chars) | Auto-generated |
| `NODE_ENV` | Node environment | `production` |

## Build details

The monorepo workspace packages export raw `.ts` files via their
`exports` field — Node.js cannot handle these natively. The Dockerfile
installs `tsx` (TypeScript Execute) and runs:

```
CMD ["npx", "tsx", "server/src/index.ts"]
```

A non-root `paperclip` user is created because embedded PostgreSQL
refuses to run as root.

## Auto-onboard

`paperclip_configure()` auto-generates a 32-byte `PAPERCLIP_AUTH_SECRET`
in `.env` if not already set.

`paperclip_start()` calls `_paperclip_auto_onboard()` after compose_up:
1. Waits for the health endpoint (`/api/health`) to respond
2. Checks if already onboarded (config.json exists in container)
3. Runs `npx tsx /app/cli/src/index.ts onboard` with quickstart defaults
4. Restarts the container to apply the new config
5. Generates a bootstrap CEO invite URL
6. Writes the invite URL to `resources/dashboard/notifications.json`

The dashboard displays the invite as an [ACCEPT INVITE] button on the
Paperclip card. The invite expires after 72 hours.

## Gotchas

- The `onboard` CLI starts a SECOND server instance internally,
  causing port conflicts with the already-running main server.
  The main process binds 3101; onboard picks the next free port.
- Config persists in the Docker volume at
  `/home/paperclip/.paperclip/instances/default/config.json`
- Bootstrap CEO invite is stored in embedded Postgres — survives
  container restarts but not volume wipes.
- Better Auth warns about low-entropy secrets — use `openssl rand
  -base64 32` for production secrets.
