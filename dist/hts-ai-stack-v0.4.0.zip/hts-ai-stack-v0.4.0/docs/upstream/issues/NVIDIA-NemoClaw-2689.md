# NVIDIA/NemoClaw#2689 — v0.0.29 Dockerfile Step 17 patches fail against bundled OpenClaw 2026.4.24

| Field | Value |
|-------|-------|
| **Repo** | [NVIDIA/NemoClaw](https://github.com/NVIDIA/NemoClaw) |
| **Issue** | [#2689](https://github.com/NVIDIA/NemoClaw/issues/2689) |
| **State** | OPEN (likely fixed by [PR #2484](https://github.com/NVIDIA/NemoClaw/pull/2484), shipped in v0.0.30/v0.0.31) |
| **Severity** | high (blocks fresh sandbox build) |
| **Labels** | bug, Integration: OpenClaw, Docker, Platform: DGX Spark |
| **Opened** | 2026-04-29 |
| **Subscribed** | No (track via cron only — fix already merged upstream) |

## Impact on us

NemoClaw v0.0.29's `blueprint.yaml` declares `min_openclaw_version: "2026.4.9"`,
but the GHCR-pinned sandbox base image (`ghcr.io/nvidia/openshell-community/sandboxes/openclaw@sha256:b3d832b596…`)
actually contains **OpenClaw 2026.4.24**. Step 16's version gate skips the npm
reinstall ("`2026.4.24 >= 2026.4.9`, no upgrade needed"), so Step 17's Patch 4
runs against 2026.4.24's refactored `replaceConfigFile` and the python
`assert old in src` aborts with:

```text
AssertionError: writeConfigFile(params.nextConfig) pattern not found
```

Result: every fresh `nemoclaw onboard` (and `nemoclaw <name> rebuild --resume`)
fails at Step 17/56 of the Dockerfile. Reproduced locally on 2026-04-30.

## Workaround

Bumped `nemoclaw.manifest.json upstream.pinned_version` to `v0.0.31`, which
ships PR #2484's updated Patch 4 (and a corresponding `min_openclaw_version`
bump to `2026.4.24`).

## Action when resolved

1. Confirm the watcher reports CLOSED.
2. If we hit the same error pattern in the future, check whether the upstream
   blueprint and base image OpenClaw versions have drifted again, and either
   bump our pin or wait for upstream alignment.

## Status log

- **2026-04-29** — Filed upstream as #2689. Two reproductions on the same day
  (also [#2686](https://github.com/NVIDIA/NemoClaw/issues/2686)).
- **2026-04-29** — [PR #2484](https://github.com/NVIDIA/NemoClaw/pull/2484)
  merged into `main` ("upgrade OpenClaw 2026.4.9 → 2026.4.24") with updated
  Patch 4 targeting the `tryWriteSingleTopLevelIncludeMutation` flow.
- **2026-04-30** — Hit locally on v0.0.29; bumped pin to v0.0.31 in our
  manifest. Added to `upstream-watch.sh`.
- **2026-04-30** — ✅ Verified: fresh `nemoclaw onboard` against v0.0.31
  succeeded on this host. Step 17 Patch 4 no longer aborts. Sandbox
  `hts-ai-openshell-nemoclaw` is up. Issue effectively resolved for us by
  the pin bump; tracker stays open until upstream marks it CLOSED.
