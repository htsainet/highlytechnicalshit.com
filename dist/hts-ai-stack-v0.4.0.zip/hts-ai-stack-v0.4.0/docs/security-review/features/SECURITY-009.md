# SECURITY-009 — Shared Volume & Secret Isolation

**Priority:** MEDIUM
**Effort:** 8-12 hours
**Risk:** Low — hardening of existing shared-state patterns; no functional changes if done carefully.
**Target Release:** v0.6.0
**Threat:** Cross-service blast radius via shared Docker volumes and a
pooled `.env` secret file. A compromised container with access to a
shared volume can tamper with another service's data without needing
any network path; a compromised container with broad env-var access
can exfiltrate or abuse credentials intended for unrelated services.
**Depends on:** Nothing (independent hardening pass)
**Blocks:** Nothing
**Related:** FEATURE-055 (Authelia SSO), FEATURE-056 (L3 Microsegmentation)

## Problem

The stack currently has two cross-service blast-radius vectors that
L3/L7 controls (Authelia + microsegmentation) do **not** cover:

### 1. Shared Docker volumes

Volumes like `ollama_models`, `huggingface_cache`, shared config dirs,
and any mount used by multiple services create an off-network data
channel. If service A is compromised and volume V is mounted by both
A and B:

- A can poison model files B will later load (supply-chain within the stack)
- A can read B's config, tokens, or API keys stored in the volume
- A can plant malicious scripts in shared tool directories
- No network policy stops this — it's all filesystem

### 2. Pooled `.env` file

The single `.env` at the repo root holds secrets for every service:
HuggingFace tokens, OpenAI keys, Grafana passwords, Duplicati keys,
Authelia JWT secret, database passwords, encryption keys, etc.

Today, docker-compose typically passes many of these env vars into
many containers. A compromise of any service with broad env access
leaks secrets intended for unrelated services. "Least privilege for
credentials" is not currently enforced.

## Solution

Two-part hardening pass: **volume scope audit** + **per-service secret
scoping**.

### Part 1 — Volume scope audit

1. Inventory every `volumes:` mount in `docker-compose.yml` and every
   component's `docker-compose.override` fragments.
2. Classify each volume as:
   - **Exclusive** — mounted by exactly one service (safe)
   - **Shared read-write** — mounted RW by 2+ services (high risk)
   - **Shared read-only** — mounted RO by 2+ services (medium risk)
   - **Bind-mount from host** — mounted from a host path (audit separately)
3. For each **shared RW** volume, answer: does it *need* to be RW from
   every service? Usually the answer is "one writer, rest read-only".
   Convert the non-writer mounts to `:ro`.
4. For volumes genuinely needing multi-writer (rare — typically
   model caches), document why and accept the residual risk.
5. Extend manifest schema with a `volumes` block declaring
   intent (`writer` / `reader`), and add a validator that fails
   if a component declares `reader` but compose mounts RW.

### Part 2 — Per-service secret scoping

1. Audit `.env` → map each secret to which service(s) actually need it.
2. Replace the monolithic `.env` with one of:
   - **Docker secrets** (preferred long-term) — per-service, mounted at
     `/run/secrets/NAME`, never in env vars or process listing.
   - **Per-service env_files** — split `.env` into
     `secrets/<component>.env` files, each passed only to its owning
     service via `env_file:` in compose.
3. Remove broad `${VAR}` references from services that don't need them.
4. Generate secrets at install time into the scoped location; remove
   from global `.env` where possible.
5. Extend manifest schema with `secrets` block: which keys this
   component consumes. Generator enforces scoping in compose output.

### Part 3 — Tooling

- `scripts/diag/volume-audit.sh` — lists shared volumes and flags
  RW duplication
- `scripts/diag/secret-scope-audit.sh` — diffs declared vs. passed
  secrets per service; flags over-grants
- Integrate both into the pre-commit hook and CI

## Acceptance criteria

- [ ] Every shared volume is justified (or converted to RO on non-writer services).
- [ ] No service has access to `.env` vars it does not consume.
- [ ] Manifest schema includes `volumes` + `secrets` blocks, validated.
- [ ] Diagnostic scripts flag regressions automatically.
- [ ] Nothing breaks — existing functionality preserved under new scoping.
- [ ] Documented in `docs/security/volume-and-secret-isolation.md`.

## Out of scope

- Secrets rotation automation (separate feature)
- Vault / HashiCorp integration (stack stays self-contained)
- Encrypted-at-rest volumes (separate SECURITY ticket)
