#!/usr/bin/env bash
# Repomix – host tool for packing codebases into AI-friendly formats
#
# Provides install, configure, health, and destroy lifecycle functions.
# No long‑running service – invoke the CLI directly (e.g. `repomix` or `npx repomix@latest`).

set -euo pipefail

# Resolve repository root directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# Load shared helpers
# shellcheck source=scripts/lib/common.sh
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=scripts/lib/health.sh
source "$REPO_DIR/scripts/lib/health.sh"

# ── Lifecycle functions ──

repomix_install() {
  info "Installing Repomix …"
  if command -v repomix &>/dev/null; then
    ok "Repomix already installed"
    return 0
  fi

  if command -v npm &>/dev/null; then
    # Install globally via npm
    npm install -g repomix
  else
    warn "npm not available – falling back to npx (no permanent install)"
    # No installation needed; npx will fetch the latest version on each run.
    ok "Repomix will be invoked using npx"
    return 0
  fi

  if command -v repomix &>/dev/null; then
    ok "Repomix installed successfully"
  else
    warn "Repomix binary not found after install"
    return 1
  fi
}

repomix_configure() {
  info "Repomix requires no configuration"
}

repomix_start() {
  info "Repomix is a CLI tool – run it directly, e.g., 'repomix' or 'npx repomix@latest'"
}

repomix_stop() { :; }

repomix_restart() { repomix_stop && repomix_start; }

repomix_health() {
  if command -v repomix &>/dev/null; then
    ok "Repomix binary found: $(command -v repomix)"
    return 0
  else
    warn "Repomix not found in PATH"
    return 1
  fi
}

repomix_destroy() {
  info "Removing Repomix …"
  if command -v npm &>/dev/null; then
    npm uninstall -g repomix || true
  fi
  ok "Repomix removal complete (if it was installed via npm)"
}

repomix_status() {
  if command -v repomix &>/dev/null; then
    echo "installed"
  else
    echo "not_installed"
  fi
}

# ── Standalone execution handling ──
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)    ACTION="install";    shift ;;
      --configure)  ACTION="configure";  shift ;;
      --start)      ACTION="start";      shift ;;
      --stop)       ACTION="stop";       shift ;;
      --restart)    ACTION="restart";    shift ;;
      --health)     ACTION="health";     shift ;;
      --destroy)    ACTION="destroy";    shift ;;
      --status)     ACTION="status";     shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   repomix_install   ;;
    configure) repomix_configure ;;
    start)     repomix_start     ;;
    stop)      repomix_stop      ;;
    restart)   repomix_restart   ;;
    health)    repomix_health    ;;
    status)    repomix_status    ;;
    destroy)   repomix_destroy   ;;
    default)
      repomix_install
      repomix_configure
      repomix_start
      repomix_health
      ;;
  esac
fi
