# LocalAI Context

Last updated: 2026-04-15

## Role in stack

LocalAI provides a unified OpenAI-compatible API for running LLMs, image
generation, speech-to-text, text-to-speech, and embeddings — all through a
single endpoint. It serves as an alternative backend for users who prefer a
single unified API rather than dedicated per-task components (Ollama, Coqui
TTS, Faster-Whisper, Stable Diffusion, etc.).

## Install type

Docker Compose (profile: `localai`). GPU-accelerated with NVIDIA CUDA 12.

## Port

`8080` (host) → `8080` (container)

## Key details

- Models are downloaded on demand via API calls — no pre-seeding required
- Supports GGUF, Transformers, Diffusers, and Bark/Piper backends
- OpenAI API drop-in: `/v1/chat/completions`, `/v1/images/generations`,
  `/v1/audio/transcriptions`, `/v1/audio/speech`, `/v1/embeddings`
- Web UI gallery available at `http://localhost:8080/` for browsing and
  installing models interactively
