# NemoClaw — Deviations

Last updated: 2026-04-30

> **Scope.** This file is the home for every NemoClaw / OpenShell deviation
> from upstream's published install/upgrade procedure. The top-level
> `DEVIATIONS.md` only carries a stub pointing here.
>
> **Source of truth.** `scripts/components/nemoclaw/nemoclaw.manifest.json`
> is canonical: NemoClaw `v0.0.31`, OpenShell `0.0.36`. Every entry below is
> grounded to those pins. Pre-v0.0.31 narrative (v0.0.21 → v0.0.29
> transition) lives in [`DEVIATIONS-history.md`](DEVIATIONS-history.md).
>
> **Vendor doc followed (every entry):**
> <https://docs.nvidia.com/nemoclaw/latest/get-started/quickstart.html>

---

## NemoClaw pin — v0.0.31

- **Deviation:** Pinned to `v0.0.31` in
  `nemoclaw.manifest.json upstream.pinned_version`. Install passes
  `NEMOCLAW_INSTALL_TAG="v0.0.31"` to NVIDIA's `nemoclaw.sh` so the
  installer honours the pin.
- **Why:** v0.0.29's Dockerfile Step 17 Patch 4 has a literal-string
  python `assert` against OpenClaw's `replaceConfigFile` source that no
  longer matches OpenClaw 2026.4.24 (the version bundled in v0.0.29's
  GHCR-pinned base image). Every fresh `nemoclaw onboard` aborted with
  `AssertionError: writeConfigFile(params.nextConfig) pattern not found`.
  Tracked upstream as
  [NVIDIA/NemoClaw#2689](https://github.com/NVIDIA/NemoClaw/issues/2689)
  and [#2686](https://github.com/NVIDIA/NemoClaw/issues/2686).
  [PR #2484](https://github.com/NVIDIA/NemoClaw/pull/2484) ("upgrade
  OpenClaw 2026.4.9 → 2026.4.24", merged 2026-04-29) updates Patch 4 to
  target the refactored `tryWriteSingleTopLevelIncludeMutation` flow and
  bumps `min_openclaw_version` to `2026.4.24`. That fix landed in
  `v0.0.30` / `v0.0.31`. v0.0.31 also picks up CVE-2026-41349 /
  CVE-2026-22181 fixes and
  [PR #2227](https://github.com/NVIDIA/NemoClaw/pull/2227)'s
  mutable-config refactor (single `.openclaw` directory replaces the old
  `.openclaw` + `.openclaw-data` symlink bridge), plus
  [PR #2741](https://github.com/NVIDIA/NemoClaw/pull/2741)'s RC-file
  hardening (root-owned static shims; runtime exports go to
  `/tmp/nemoclaw-proxy-env.sh`).
- **Where implemented:** `scripts/components/nemoclaw/nemoclaw.manifest.json`
  (`upstream.pinned_version: "v0.0.31"`); OpenShell pin window unchanged
  from v0.0.29 (`[0.0.32, 0.0.36]`), so
  `openshell_pinned_version: "0.0.36"` stays valid per v0.0.31's
  `blueprint.yaml`.
- **Revisit when:**
  - [#2740](https://github.com/NVIDIA/NemoClaw/issues/2740) closes —
    v0.0.30 introduced a fresh-onboard blocker at Dockerfile Step 51/57
    (`ln -sfn .../workspace/media` ENOENT because the parent
    `.openclaw-data/workspace/` directory is not created on a fresh
    build — fallout from PR #2227). We did **not** hit this on Ubuntu;
    if it surfaces, bump to the release that closes #2740 or roll back
    to `v0.0.29`.
  - TC-SBX-02 (Connect & Chat) regression in PR #2484's nightly E2E
    (13/18) is resolved upstream — even with the fix in place the chat
    round-trip can hang with empty reply on Ubuntu/Docker. Validate
    end-to-end after onboard with a real chat probe before declaring
    v0.0.31 healthy.
- **Rollback:** set `pinned_version` back to `"v0.0.29"` and re-run
  `nemoclaw_install` with `NEMOCLAW_FORCE_REINSTALL=1`. Existing v0.0.29
  sandboxes survive a v0.0.31 install attempt.
- **Status (2026-04-30):** ✅ **Verified working on this host.** Fresh
  `nemoclaw onboard` against v0.0.31 completed end-to-end; sandbox
  `hts-ai-openshell-nemoclaw` is up with `mistral-nemo:latest` via
  llama-swap.
- **References:** [`REFERENCES.md`](REFERENCES.md),
  `docs/upstream/issues/NVIDIA-NemoClaw-2689.md`,
  `docs/upstream/issues/NVIDIA-NemoClaw-2686.md`,
  `docs/upstream/issues/NVIDIA-NemoClaw-2740.md`.

---

## OpenShell pin — `0.0.36` (single source: manifest)

- **Deviation:** `OPENSHELL_VERSION` is pinned to `"0.0.36"` to match
  NemoClaw v0.0.31's `blueprint.yaml` window
  (`min_openshell_version: "0.0.32"`, `max_openshell_version: "0.0.36"`).
  The version is **canonical in
  `scripts/components/nemoclaw/nemoclaw.manifest.json`
  `upstream.openshell_pinned_version`**. Five previously-hardcoded sites
  now read from the manifest — except `scripts/lib/common.sh`
  `install_openshell_nvidia()`, which receives the value from the caller
  via the `OPENSHELL_VERSION` env var to keep the library
  component-agnostic:
  - `scripts/components/nemoclaw/nemoclaw.sh` — reads via `jq` at startup
  - `scripts/utils/upgrade-nemoclaw.sh` — reads via `jq` at startup
  - `scripts/utils/verify-openshell-pin.sh` — reads via `jq` as `EXPECTED`
  - Indirectly, `scripts/utils/downgrade-nemoclaw.sh`'s
    `EXPECTED_OPENSHELL` constant remains hardcoded at `0.0.26`
    (intentional — it is an emergency rollback target for `v0.0.21`, not
    the current version)
- **Why:** Pinning to `0.0.36` (top of window) makes
  `install_openshell_nvidia()` a stable no-op after first install.
  Centralising the value in the manifest eliminates the drift surface
  that mis-synced versions during prior upgrade/rollback cycles.
- **Revisit when:** NemoClaw publishes a release with a different
  `max_openshell_version`. Update `upstream.openshell_pinned_version` in
  the manifest — all five sites pick up the change automatically.
  Check with: `find ~/.nemoclaw -name "blueprint.yaml" | xargs grep -i openshell`
- **Post-apply verification:** after any converge or nemoclaw upgrade:
  - `./scripts/utils/verify-openshell-pin.sh` — confirms installed
    binary, blueprint, and manifest value agree on the pinned version.
- **References:** [`REFERENCES.md`](REFERENCES.md).

---

## Llama-swap provider env block (NEMOCLAW_PROVIDER=custom)

- **Deviation:** `nemoclaw_install()` and the rollback wrapper invoke
  NVIDIA's installer with this env block so install step
  `[3/8] Configuring inference` routes to host-side llama-swap instead
  of NVIDIA Endpoints / NIM cloud:

  ```sh
  NEMOCLAW_EXPERIMENTAL=1 \
  NEMOCLAW_PROVIDER=custom \
  NEMOCLAW_ENDPOINT_URL=http://localhost:${LLAMA_SWAP_PORT:-8081}/v1 \
  NEMOCLAW_MODEL="$NEMOCLAW_MODEL" \
  COMPATIBLE_API_KEY=not-needed \
  NEMOCLAW_POLICY_TIER=balanced
  ```

  All six env vars verified still recognised at v0.0.31 (carried over
  from v0.0.29 phase-0 recon; v0.0.30/v0.0.31 made no provider-env
  changes).
- **Why:** Without `NEMOCLAW_PROVIDER=custom` + `NEMOCLAW_EXPERIMENTAL=1`
  the installer aborts in non-interactive mode with
  `NVIDIA_API_KEY (or NEMOCLAW_PROVIDER_KEY) is required for NVIDIA Endpoints`.
  `custom` is NVIDIA's documented provider for any OpenAI-compatible
  endpoint and is gated behind the experimental flag. Using it routes
  inference to the local llama-swap proxy — no cloud dependency, no API
  key.

  Note on the two provider names: `NEMOCLAW_PROVIDER=custom` is the
  **install-time** selector; the **runtime provider object** that
  `nemoclaw onboard` then creates is named `compatible-endpoint`. They
  are not interchangeable — the runtime name is what
  `openshell inference set --provider <name>` and
  `_ensure_inference_route_pinned` reference.
- **Where implemented:** `scripts/components/nemoclaw/nemoclaw.sh`
  `nemoclaw_install()` (reads pin from manifest via `jq`, provider env
  block); `scripts/utils/downgrade-nemoclaw.sh` (same env block;
  emergency rollback target remains `v0.0.21` /
  `EXPECTED_OPENSHELL="0.0.26"` — hardcoded intentionally, see comment in
  that file).
- **Revisit when:** Provider env vars are renamed in a future NemoClaw
  release. Re-read `install.sh --help` at the target tag before moving
  the pin.

---

## Inotify limit preflight + stale gateway cleanup

- **Deviation:** Raise `fs.inotify.max_user_instances` to 8192 and
  `fs.inotify.max_user_watches` to 524288 in a kernel preflight
  (`_fix_inotify_limits`) run before the vendor installer. Persisted to
  `/etc/sysctl.d/99-hts-ai-stack-inotify.conf`. Also force-remove any
  stale `openshell-cluster-<gateway>` / `openshell-gateway-<gateway>`
  container left over from a failed previous run
  (`_cleanup_stale_gateway_containers`) before invoking
  `nemoclaw onboard`.
- **Why:** The OpenShell gateway embeds a full k3s cluster whose kubelet
  and cAdvisor crash on Ubuntu's default inotify limits
  (`max_user_instances=128`) with `inotify_init: too many open files`,
  surfacing as `× gateway health check reported unhealthy` during
  `nemoclaw onboard`. The NVIDIA quickstart does not document these
  kernel prerequisites; values mirror Rancher/k3s guidance for
  k3s-in-docker. When the gateway fails health, the partially-started
  cluster container is left restarting and blocks the next attempt's
  `openshell gateway destroy` with `image is being used by running
  container <id>` — hence the cleanup helper.
- **Where implemented:** `scripts/components/nemoclaw/nemoclaw.sh`
  (`_fix_inotify_limits`, `_cleanup_stale_gateway_containers`, called
  from `nemoclaw_install`, `nemoclaw_configure`, and `nemoclaw_onboard`).
- **Revisit when:** NVIDIA's NemoClaw / OpenShell installer adds an
  equivalent preflight, or the gateway stops embedding k3s.

---

## Dashboard SSH-forward systemd oneshot

- **Vendor section followed:** Quickstart §"Restart the Port Forward".
- **Deviation:** Install a systemd **oneshot** unit
  `hts-nemoclaw-dashboard-forward.service` that runs the documented
  command `openshell -g <gateway> forward start --background 18789
  <sandbox>` once per boot (no timer, no watchdog). Also extract the
  live gateway auth token from `/sandbox/.openclaw/openclaw.json` into
  `resources/dashboard/nemoclaw-tokens.json` so the HTS dashboard tile
  can deep-link `http://127.0.0.1:18789/#token=<token>`.
- **Why:** NVIDIA's quickstart treats the SSH forward as a single
  user-driven command — fine for a manual workstation, but our stack is
  systemd-driven and must come up cleanly after reboot without typing
  anything. The oneshot automates exactly the documented command and
  exits; it is **not** a watchdog, retry loop, or escalation path. The
  static dashboard, which lives outside the gateway's auth domain, needs
  the `gateway.auth.token` to deep-link successfully. An earlier
  iteration (`hts-nemoclaw-health.timer` + `_ensure_forwards`
  retry/escalation + sandbox-side TCP relay supervisor) was removed in
  the same change — that machinery patched around symptoms instead of
  following the docs and produced more downtime than it cured. See
  [`DEVIATIONS-history.md`](DEVIATIONS-history.md) for the full removal
  log.
- **Where implemented:** `scripts/components/nemoclaw/nemoclaw.sh`
  (`_install_dashboard_forward_boot_unit`, `_start_dashboard_forward`,
  `_extract_dashboard_tokens`).
- **Revisit when:** NVIDIA publishes an auto-recovery / supervisor
  design for the dashboard forward, or builds dashboard token surfacing
  into NemoClaw itself.

---

## Version-aware idempotency check

- **Deviation:** `nemoclaw_install()` performs a version-aware
  idempotency check before deciding whether to re-run NVIDIA's
  `nemoclaw.sh`. An existing `nemoclaw` binary is only accepted when its
  parsed `--version` matches `NEMOCLAW_INSTALL_TAG` (read from
  `nemoclaw.manifest.json upstream.pinned_version`, leading `v`
  stripped). Mismatch, unparseable output, or `NEMOCLAW_FORCE_REINSTALL=1`
  re-runs the official installer in-place. Successful match logs
  `NemoClaw CLI already at pinned version: …`.
- **Why:** The previous guard was `command -v nemoclaw`, which silently
  no-op'd on every host that already had any older `nemoclaw` binary.
  When the manifest pin moved (e.g. v0.0.21 → v0.0.29 → v0.0.31),
  `--install` reported success while leaving the old CLI in place; that
  left `~/.nemoclaw/source/nemoclaw-blueprint/blueprint.yaml` at the old
  source's openshell window while `install_openshell_nvidia()` had
  already pushed the binary to the newer pin. The version-aware check
  makes pin bumps visibly upgrade the host CLI, which regenerates the
  blueprint on the next `nemoclaw onboard` / `--update`. NVIDIA's
  installer is a thin npm-global wrapper and supports in-place version
  replacement, so this is documented-tool reuse, not a workaround.
- **Where implemented:** `scripts/components/nemoclaw/nemoclaw.sh`
  `nemoclaw_install()` — `_need_install` / `_installed_ver` /
  `_desired_ver` block immediately before the
  `env … bash -c 'curl … nemoclaw.sh | bash'` invocation.
  `install_openshell_nvidia()` in `scripts/lib/common.sh` already had an
  equivalent version comparison — no change needed there.
- **Revisit when:** NVIDIA changes the `nemoclaw --version` output
  format (currently `nemoclaw vX.Y.Z`); the
  `grep -oE '[0-9]+\.[0-9]+\.[0-9]+'` in the check would need updating.
- **Known upstream regression (v0.0.29+):** `NEMOCLAW_SKIP_ONBOARD=1` is
  silently ignored by `nemoclaw.sh` — the installer's `[3/3] Onboarding`
  step always invokes `nemoclaw onboard`. When an earlier install left a
  `Previous onboarding session failed` marker, the embedded onboard
  fails non-zero but the CLI binary itself has already been replaced at
  the pinned version. `nemoclaw_install()` distinguishes these: if
  post-install `nemoclaw --version` matches `_desired_ver`, the
  installer's rc≠0 is downgraded to a `warn` block that points at the
  unattended recovery wrapper
  `./scripts/components/nemoclaw/nemoclaw.sh --onboard-fresh`; only an
  actual binary install failure still calls `fail`. The wrapper exports
  `NEMOCLAW_FRESH=1`, which `_do_onboard` plumbs through
  `_run_onboard_cmd` so `nemoclaw onboard --fresh --non-interactive` is
  invoked under the same provider env block (custom→llama-swap, model
  warm-up, log capture) used during install. `_do_onboard` also
  auto-recovers by re-running with `--fresh` if the first attempt's log
  contains `Previous onboarding session`. Bare
  `nemoclaw onboard --fresh` is **interactive** (prompts at
  `[3/8] Configuring inference`) and should not be invoked directly.
  Track upstream behaviour: revisit if a future NemoClaw release
  re-honours `NEMOCLAW_SKIP_ONBOARD` or drops the interactive `[3/8]`
  prompt under `--non-interactive`.
- **Cross-version upgrade plan (TODO):** Tactical fixes
  (`_force_recreate_gateway`, `--recreate-gateway` dispatcher,
  auto-recovery in `_do_onboard` on `transport error` /
  `Connection reset by peer`) unblock the current host but do not yet
  constitute a supported upgrade path. The full plan — detector for
  gateway version mismatch, snapshot-before-rebuild, supported cascade
  (`nemoclaw <name> rebuild` → `nemoclaw upgrade-sandboxes` → force
  recreate as last resort), wiring into
  `scripts/utils/upgrade-nemoclaw.sh`, and consolidation of these
  per-symptom entries — is tracked in
  [`docs/development/features/FEATURE-075.md`](../../../docs/development/features/FEATURE-075.md).
  Land that feature before the next NemoClaw pin bump.

---

## Sandbox lifecycle: prefer `nemoclaw <name> destroy`

- **Deviation:** `nemoclaw_destroy()` prefers
  `nemoclaw <name> destroy --yes` (the NVIDIA-documented lifecycle
  command) and only falls back to `openshell sandbox delete` when the
  `nemoclaw` CLI is missing or the sandbox is not registered with it
  (e.g., after a partial onboard). Same pattern in `nemoclaw_restart()`
  post-restart fallback and `nemoclaw_onboard()` overwrite branch.
- **Why:** Using `openshell sandbox delete` directly bypasses
  nemoclaw's bookkeeping (policy store, workspace backup, gateway state)
  and leaves stale references that break subsequent onboards. NVIDIA's
  CLI is the canonical lifecycle entry point. The fallback only exists
  to recover from states where the CLI cannot act.
- **Where implemented:** `scripts/components/nemoclaw/nemoclaw.sh`
  (`nemoclaw_destroy`, `nemoclaw_restart`, `nemoclaw_onboard`).
- **Revisit when:** NVIDIA's CLI exposes a documented `--force` or
  recovery flag that can clean up unregistered sandboxes on its own,
  making the openshell fallback unnecessary.

---

## Gateway-name accommodation (`nemoclaw`, not `hts-ai-…`)

- **Deviation:** The OpenShell gateway created by `nemoclaw onboard` is
  named `nemoclaw` (upstream hardcoded default), not our stack's
  `hts-ai-` prefix convention. We pass
  `NEMOCLAW_GATEWAY_NAME=hts-ai-openshell-nemoclaw` in the env block to
  `nemoclaw onboard`, but upstream silently ignores it. As a result
  `NEMOCLAW_GATEWAY_NAME` defaults to `"nemoclaw"` to match reality, and
  every `openshell sandbox exec -g nemoclaw …` /
  `openshell gateway select nemoclaw` call uses that upstream name.
- **Why:** OpenShell gateways are NVIDIA-managed runtime artifacts, not
  Docker containers we build. The `hts-ai-` prefix convention applies
  only to components we control (images, containers, Docker networks,
  volumes). Verified on 2026-04-23 via `openshell gateway select` — the
  deployed gateway is unambiguously `nemoclaw`, the sandbox is
  `hts-ai-openshell-nemoclaw` (sandbox naming IS honoured by upstream).
  Forking the NVIDIA installer to rename the gateway would violate the
  "follow NVIDIA's published NemoClaw docs" project rule.
- **Where implemented:** `scripts/components/nemoclaw/nemoclaw.sh`
  (`NEMOCLAW_GATEWAY_NAME` default at line 39).

---

## Inference route timeout — direct `openshell inference set`

- **Deviation:** After `nemoclaw onboard` (and on every `--start`), call
  `openshell inference set --provider <p> --model <m> --timeout <s>`
  directly to extend the gateway route timeout from OpenShell's 60 s
  default to `NEMOCLAW_INFERENCE_TIMEOUT` (default 300 s). NemoClaw's
  own CLI surface (`nemoclaw onboard`,
  `nemoclaw <name> config get|set|rotate-token`,
  `nemoclaw <name> rebuild`) does not expose the gateway route
  timeout — the closest config key, `agents.defaults.timeoutSeconds`,
  governs the openclaw agent loop inside the sandbox, not the
  sandbox→gateway→llama-swap relay timeout. So we fall through to the
  underlying `openshell` CLI for this one knob only, mirroring what
  `nemoclaw onboard` itself does internally for provider/model
  selection.
- **Why:** Mid-size GPU chat models (e.g. `mistral-nemo:latest`, the
  current `NEMOCLAW_MODEL` default) cold-load through Ollama+llama-swap
  in 60–120 s on first call. With the gateway route timeout at 60 s,
  the sandbox's stream to `https://inference.local/v1/...` is killed at
  exactly 60 s — observed in the sandbox log as
  `NET:OPEN [MED] DENIED inference.local:443 → NET:FAIL` — and the
  dashboard's first chat hangs forever. Subsequent prompts can stay
  broken if the route is flagged unhealthy by the kill. Bumping the
  route timeout to 300 s is enough to absorb any first-call cold-load
  on the local stack. We also extend the post-pin smoke probe's
  `curl --max-time` to match, so the probe both verifies the path AND
  pre-warms the model — once it returns, the dashboard's first chat
  answers in seconds.
- **Where implemented:** `scripts/components/nemoclaw/nemoclaw.sh`
  (`NEMOCLAW_INFERENCE_TIMEOUT` default at line 49,
  `_ensure_inference_route_pinned()` passes `--timeout`,
  `_probe_llamaswap_from_sandbox()` matches `curl --max-time` to the
  same budget); `.env` carries `NEMOCLAW_INFERENCE_TIMEOUT=300` so
  reconfigures pick it up.
- **Revisit when:** NemoClaw exposes the gateway route timeout via
  `nemoclaw <name> config set --key <dotpath>` or as an `onboard`
  flag — switch to the NemoClaw-native call and drop the direct
  `openshell` invocation. Track upstream NemoClaw changelog for
  `inference.timeout` / `route.timeoutSeconds` config keys.

---

## Default model — `mistral-nemo:latest`

- **Deviation:** Default `NEMOCLAW_MODEL` is `mistral-nemo:latest`, not
  the original `gemma4:e4b` we shipped earlier nor the
  `qwen2.5:7b-instruct-q4_K_M` that briefly took over.
- **Why:** Two failure modes pushed us off the previous defaults:
  1. `gemma4:e4b` is a *thinking* model — Ollama emits its
     `<think>...</think>` output on the non-standard `reasoning` field
     of chat-completions responses. The OpenClaw chat UI renders
     `content` only, so the dashboard appears blank for the 30–60+ s
     the model spends thinking before producing the first content
     token, and frequently trips the sandbox's 60 s network egress
     ceiling.
  2. `qwen2.5:7b-instruct-q4_K_M` chats fine in plain prompts but
     spirals on OpenClaw's tool-call agent loop — observed as the
     dashboard repeating "1 tool message" indefinitely while
     `nemoclaw <name> logs` shows `/v1/chat/completions` requests every
     3–5 s. The conversation poisons itself with
     `tool_call → tool_result → tool_call → …`.

  `mistral-nemo:latest` is NVIDIA/Mistral's purpose-built tool-caller
  (12B, Q4 ~7 GB weights, fits 12 GB VRAM with KV-cache headroom). It
  does not loop on tool calls in the OpenClaw agent loop and does not
  buffer behind a `<think>` block. It is the documented model for any
  in-stack workflow that needs reliable structured-output / tool use
  through llama-swap.
- **Where implemented:** single source of truth lives in
  `scripts/components/nemoclaw/nemoclaw.manifest.json` (`prompts.model`,
  default `mistral-nemo:latest`, writes `.env` `NEMOCLAW_MODEL`) plus
  one lone fallback at `scripts/components/nemoclaw/nemoclaw.sh:50`.
  Every other reference is a bare `${NEMOCLAW_MODEL}` — do not add
  inline `:-…` defaults at use sites. Mirrors:
  `scripts/utils/{smoke-test,diagnose,downgrade}-nemoclaw*.sh`,
  `tests/Test-Nemoclaw.Tests.ps1` and
  `tests/Test-UtilsScripts.Tests.ps1` assertions.
  `config/llama-swap.yaml` `peers.ollama.models` lists
  `mistral-nemo:latest` so llama-swap will route to it.
- **Revisit when:** OpenClaw's agent loop becomes resilient enough that
  smaller / non-tool-tuned models (e.g. `qwen2.5:7b-instruct-q4_K_M`)
  stop spiralling, OR a smaller purpose-built tool-caller emerges that
  wins on VRAM/latency. Reassess any time NemoClaw bumps its blueprint
  or the OpenClaw agent runtime.
- **References:** [`CONTEXT.md`](CONTEXT.md) §"2026-04-26 — Working
  configuration".
