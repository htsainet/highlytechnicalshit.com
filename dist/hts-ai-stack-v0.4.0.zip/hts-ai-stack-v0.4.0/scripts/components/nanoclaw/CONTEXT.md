# NanoClaw Component — CONTEXT

## What is NanoClaw?

NanoClaw is a lightweight, container‑based AI assistant that runs Claude (or other LLMs) inside isolated Docker containers. It provides multi‑platform messaging (Telegram, Discord, WhatsApp, etc.) and a clean, self‑hosted workflow. The upstream repository is at https://github.com/qwibitai/nanoclaw and the public docs are https://nanoclaw.dev.

## How it fits into the HTS AI Stack

- **Category:** `agents` – provides a personal AI agent platform.
- **Install type:** `host` – the component installs the upstream repository on the host and runs the `nanoclaw.sh` entrypoint as a background process.
- **Interaction:** Users invoke NanoClaw via its own CLI (`nanoclaw.sh`) which boots the required Node environment, Docker runtime, and starts the assistant. No additional ports are exposed; communication happens through configured messaging adapters.

## Install method

The component follows the upstream quick‑start instructions:
1. Clone the NanoClaw repository.
2. Run the provided `nanoclaw.sh` script which bootstraps Node, pnpm, Docker (if needed) and then hands off to the TypeScript setup flow.

All steps are idempotent – repeated installs are no‑ops. The wrapper script in this repo mirrors those steps and integrates with the stack’s `converge.sh` workflow.

## Dashboard

NanoClaw does not expose a dedicated HTTP dashboard, so the component dashboard entry leaves `port` null. The UI is accessed via the messaging channels it connects to.

## Upstream links

- **Repo:** https://github.com/qwibitai/nanoclaw
- **Docs:** https://nanoclaw.dev
- **Quick‑start:** https://github.com/qwibitai/nanoclaw#quick-start

See [usage.md](./usage.md) for command usage.
