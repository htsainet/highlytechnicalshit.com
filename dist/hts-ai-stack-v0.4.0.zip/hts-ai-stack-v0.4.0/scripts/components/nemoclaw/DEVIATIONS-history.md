# NemoClaw — Deviations History

Historical context for deviations that are no longer load-bearing or that
describe transitions we have already moved past. Kept as a record so future
sessions investigating "why is this code shaped like that?" can find the
original rationale; the current entries live in
[`DEVIATIONS.md`](DEVIATIONS.md).

> Vendor doc followed throughout:
> <https://docs.nvidia.com/nemoclaw/latest/get-started/quickstart.html>

---

## 2026-04-29 — v0.0.21 → v0.0.29 transition

This was the foundational pin bump that made every current entry possible.
On 2026-04-29 we moved NemoClaw from `v0.0.21` → `v0.0.29` and lifted
`OPENSHELL_VERSION` from five hardcoded sites into
`nemoclaw.manifest.json upstream.openshell_pinned_version` as the single
canonical source.

The bump adopted three upstream fixes that obsoleted host-side workaround
code we had been carrying:

- **PR #1824** (`fix(onboard): recover openshell gateway bootstrap
  startup`) — addressed the gateway bootstrap race and missing TLS
  bootstrap secrets (`openshell-server-tls`, `openshell-server-client-ca`,
  `openshell-client-tls`, `openshell-ssh-handshake`) that drove
  `_cleanup_stale_gateway_containers` and the extended gateway health
  loop in our scripts.
- **PR #466** (`fix(connect): add readiness poll with timeout`) — added
  `openshell sandbox list` readiness poll every 3 s (120 s max,
  `NEMOCLAW_CONNECT_TIMEOUT` configurable) to
  `nemoclaw <name> connect`, addressing the indefinite post-onboard
  hang.
- **PR #2472** (`fix(sandbox): fix non-root gateway startup and add
  crash safety net`) — wrapped Landlock-protected `.bashrc`/`.profile`
  writes in `|| true` and added `sandbox-safety-net.js`
  uncaught-exception preload; prevented gateway entrypoint crash under
  `set -e` in non-root containers.

OpenShell pin advanced from `0.0.26` → `0.0.36` to match v0.0.29's
blueprint requirements (`min_openshell_version: "0.0.32"`,
`max_openshell_version: "0.0.36"`).

The current pin (v0.0.31) inherits this baseline; the OpenShell window
was unchanged in v0.0.30 / v0.0.31.

---

## Removed scaffolding (`hts-nemoclaw-health.timer` and friends)

The following machinery existed under v0.0.21 / pre-Option-A and was
removed when the dashboard-forward path was rewritten as a single
documented oneshot:

- `hts-nemoclaw-health.timer` (systemd timer)
- `_install_health_timer()`
- `_ensure_forwards` retry/escalation
- `_forward_listening` / `_wait_forward_listening` listener probes
- Sandbox-side TCP relay supervisor
- `nemoclaw_health()`
- `nemoclaw.sh --repair-dashboard`
- `--list` / `--logs` / `--debug` wrappers

Each wrapped a NVIDIA-documented primitive with HTS-specific health
logic that drifted from the quickstart and produced more downtime than
it cured. Replaced by:

- `hts-nemoclaw-dashboard-forward.service` — single oneshot that runs
  the documented `openshell -g <gateway> forward start --background
  18789 <sandbox>` once per boot.
- `./scripts/components/nemoclaw/nemoclaw.sh --restart-forward` — manual
  single-shot recovery (the documented operator action).

If a future regression makes a watchdog genuinely necessary, propose it
as a new deviation entry first — do not silently re-introduce any of the
removed helpers.

---

## v0.0.21-era llama-swap policy hole (removed)

`_ensure_llamaswap_policy` was a host-side helper that punched a custom
network-policy hole through `host.openshell.internal:8081` so the
sandbox could call llama-swap directly. Removed on **2026-04-25** when
the documented `https://inference.local` relay path was identified as
the NVIDIA-approved way to route sandbox inference (see
[`CONTEXT.md`](CONTEXT.md) §"Inference routing"). The relay terminates
inside the gateway pod, so the sandbox never needs to reach
`host.openshell.internal:8081` directly. The helper solved a problem
that does not exist on the documented vendor path.

A side-effect we had to engineer around: `openshell policy get --full`
emits a multi-document YAML stream with capitalised top-level keys that
`policy set --policy` rejects. Documented for posterity in case a future
feature legitimately needs to patch live OpenShell policy.

---

## Multi-agent persona injection (removed 2026-04-28)

Multi-agent persona injection (caco-bot, haley) was removed entirely
under the project's "rewrite over repeat-fix" rule after two rounds of
chown workarounds leaked.

OpenClaw mkdirs `/sandbox/.openclaw/workspace-<agent>/` at session start;
that path is root-owned and read-only per sandbox policy, so any
non-default `agents.list` produced `EACCES: mkdir` on first chat.
Workarounds tried and abandoned:

1. Pre-create + chown `agents/` to sandbox user — only covered the
   subdir, not workspace-* siblings.
2. Chown `agents/` after mkdir — workspace-* still root-owned at
   runtime.
3. Writeback chain from `stack.json .sandbox.agent_personas` → env var —
   never wired correctly.

Removed: `_provision_agent_personas`,
`_sandbox_agent_models_match_expected`, the manifest prompt, the env
var, profile keys, wizard plumbing. Stock OpenClaw's single default
agent uses a writable workspace and works fine.
`resources/agents/{caco-bot,haley}/` is preserved on disk for any future
reimplementation but is no longer wired in.

If personas are reintroduced, the sandbox image must ship
`/sandbox/.openclaw/workspace-*` writable by the sandbox user (image
change, not host-side mkdir/chown), or a different config knob must
point openclaw at a writable workspace path under `.openclaw-data/`.

---

## Emergency rollback target (intentionally hardcoded at v0.0.21 / 0.0.26)

`scripts/utils/downgrade-nemoclaw.sh` keeps `EXPECTED_OPENSHELL="0.0.26"`
and a hardcoded `v0.0.21` target. This is **not** drift — it is an
emergency rollback path to the last known-good combination if a future
NemoClaw release breaks fresh installs and there is no time to derive a
new working pin window. Do not replace these constants with manifest
reads; the manifest is the *forward* pin.
