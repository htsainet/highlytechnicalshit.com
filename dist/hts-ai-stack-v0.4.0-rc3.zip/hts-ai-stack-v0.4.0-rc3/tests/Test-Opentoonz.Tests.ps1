$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:ComponentDir = Join-Path $script:RepoRoot 'scripts/components/opentoonz'
    $script:ComponentScript = Join-Path $script:ComponentDir 'opentoonz.sh'
    $script:ManifestFile = Join-Path $script:ComponentDir 'opentoonz.manifest.json'
}

# ── File existence ───────────────────────────────────────────────────────────

Describe 'opentoonz file inventory' {

    It 'component directory exists' {
        $script:ComponentDir | Should -Exist
    }

    It 'component script exists' {
        $script:ComponentScript | Should -Exist
    }

    It 'manifest file exists' {
        $script:ManifestFile | Should -Exist
    }

    It 'CONTEXT.md exists' {
        Join-Path $script:ComponentDir 'CONTEXT.md' | Should -Exist
    }

    It 'REFERENCES.md exists' {
        Join-Path $script:ComponentDir 'REFERENCES.md' | Should -Exist
    }
}

# ── Component script contract ────────────────────────────────────────────────

Describe 'opentoonz component contract' {

    BeforeAll {
        $script:ComponentContent = Get-Content -Path $script:ComponentScript -Raw
    }

    It 'defines opentoonz_install function' {
        $script:ComponentContent | Should -Match 'opentoonz_install\s*\(\)'
    }

    It 'defines opentoonz_configure function' {
        $script:ComponentContent | Should -Match 'opentoonz_configure\s*\(\)'
    }

    It 'defines opentoonz_start function' {
        $script:ComponentContent | Should -Match 'opentoonz_start\s*\(\)'
    }

    It 'defines opentoonz_stop function' {
        $script:ComponentContent | Should -Match 'opentoonz_stop\s*\(\)'
    }

    It 'defines opentoonz_health function' {
        $script:ComponentContent | Should -Match 'opentoonz_health\s*\(\)'
    }

    It 'defines opentoonz_restart function' {
        $script:ComponentContent | Should -Match 'opentoonz_restart\s*\(\)'
    }

    It 'defines opentoonz_destroy function' {
        $script:ComponentContent | Should -Match 'opentoonz_destroy\s*\(\)'
    }

    It 'defines opentoonz_status function' {
        $script:ComponentContent | Should -Match 'opentoonz_status\s*\(\)'
    }

    It 'supports --health and --stop CLI flags' {
        $script:ComponentContent | Should -Match '--health\)'
        $script:ComponentContent | Should -Match '--stop\)'
    }

    It 'header references the subfolder path' {
        $script:ComponentContent | Should -Match 'scripts/components/opentoonz/opentoonz\.sh'
    }
}

# ── No stale flat-path references ────────────────────────────────────────────

Describe 'opentoonz no stale flat-path references' {

    BeforeAll {
        $script:StaleRefs = @()
        Get-ChildItem -Path (Join-Path $script:RepoRoot 'scripts') -Include '*.sh','*.json' -Recurse -File |
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                $lines = $content -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    if ($lines[$i] -match 'components/opentoonz\.(sh|manifest\.json)' -and
                        $lines[$i] -notmatch 'components/opentoonz/opentoonz\.(sh|manifest\.json)') {
                        $rel = $_.FullName.Substring($script:RepoRoot.Length + 1)
                        $script:StaleRefs += "${rel}:$($i+1): $($lines[$i].Trim())"
                    }
                }
            }
    }

    It 'no scripts reference the old flat path' {
        $script:StaleRefs | Should -BeNullOrEmpty -Because 'all references should use subfolder path'
    }
}
