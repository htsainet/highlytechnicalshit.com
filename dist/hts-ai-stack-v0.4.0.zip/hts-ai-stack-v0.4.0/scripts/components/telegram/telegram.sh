#!/usr/bin/env bash
# scripts/components/telegram/telegram.sh — Telegram bot integration for OpenClaw
#
# Standalone usage:
#   ./scripts/components/telegram/telegram.sh              # full: install + configure + start + health
#   ./scripts/components/telegram/telegram.sh --install    # install only
#   ./scripts/components/telegram/telegram.sh --configure  # configure only
#   ./scripts/components/telegram/telegram.sh --start      # start only
#   ./scripts/components/telegram/telegram.sh --stop       # stop (no-op, runs inside OpenClaw)
#   ./scripts/components/telegram/telegram.sh --restart    # restart (stop + start)
#   ./scripts/components/telegram/telegram.sh --health     # health check only
#   ./scripts/components/telegram/telegram.sh --status     # show status + health
#   ./scripts/components/telegram/telegram.sh --destroy    # destroy (remove bot config)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-}"

# ── Functions ────────────────────────────────────────────────────────────────

# telegram_install — Ensure bot token is configured
telegram_install() {
  step "Telegram — install"
  info "Telegram bot runs inside the OpenClaw container — no separate install needed."
  ok "Telegram ready."
}

# telegram_configure — Apply bot token from .env, patch OpenClaw config
telegram_configure() {
  step "Telegram — configure"

  local env_file="$REPO_DIR/.env"

  # Read or prompt for bot token
  if [[ -z "$TELEGRAM_BOT_TOKEN" ]] && [[ -f "$env_file" ]]; then
    TELEGRAM_BOT_TOKEN=$(grep '^TELEGRAM_BOT_TOKEN=' "$env_file" | cut -d= -f2- | tr -d '[:space:]' || true)
  fi

  if [[ -z "$TELEGRAM_BOT_TOKEN" ]]; then
    echo ""
    warn "TELEGRAM_BOT_TOKEN not found in .env."
    echo "  Create a bot via @BotFather on Telegram (/newbot), then paste the token."
    read -r -p "  Bot token: " TELEGRAM_BOT_TOKEN
    [[ -n "$TELEGRAM_BOT_TOKEN" ]] || { fail "No token provided."; return 1; }
    echo "TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}" >> "$env_file"
    info "Token saved to .env."
  else
    info "TELEGRAM_BOT_TOKEN: ${TELEGRAM_BOT_TOKEN:0:10}..."
  fi

  ok "Telegram configured."
}

# telegram_start — Validate token and patch OpenClaw container config
telegram_start() {
  step "Telegram — start"

  # Validate token with Telegram API
  local bot_info
  bot_info=$(curl -sf "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe" || true)
  if ! echo "$bot_info" | grep -q '"ok":true'; then
    fail "Token rejected by Telegram — check TELEGRAM_BOT_TOKEN in .env."
    return 1
  fi

  local bot_name
  bot_name=$(echo "$bot_info" | grep -o '"username":"[^"]*"' | cut -d'"' -f4)
  info "Bot verified: @${bot_name}"

  # Patch OpenClaw config if container is running
  if docker ps --format '{{.Names}}' | grep -qw openclaw; then
    docker exec -e TELEGRAM_BOT_TOKEN="$TELEGRAM_BOT_TOKEN" openclaw \
      node -e "
        const fs = require('fs');
        const path = '/home/node/.openclaw/openclaw.json';
        const cfg = JSON.parse(fs.readFileSync(path, 'utf8'));
        cfg.channels = cfg.channels || {};
        cfg.channels.telegram = Object.assign(cfg.channels.telegram || {}, {
          enabled: true,
          botToken: process.env.TELEGRAM_BOT_TOKEN,
        });
        fs.writeFileSync(path, JSON.stringify(cfg, null, 2));
        console.log('openclaw.json updated.');
      "
    docker compose restart openclaw
    ok "Telegram bot @${bot_name} activated in OpenClaw."
  else
    warn "OpenClaw is not running — start the stack first to activate Telegram."
  fi
}

# telegram_stop — No-op (Telegram bot runs inside OpenClaw)
telegram_stop() {
  step "Telegram — stop"
  info "Telegram bot is managed inside the OpenClaw container."
  info "To disable: docker exec openclaw ... (remove telegram channel from config)"
  ok "Telegram stop guidance provided."
}

# telegram_health — Verify bot token is valid
telegram_health() {
  step "Telegram — health"
  if [[ -z "$TELEGRAM_BOT_TOKEN" ]]; then
    warn "TELEGRAM_BOT_TOKEN not set."
    return 1
  fi

  local bot_info
  bot_info=$(curl -sf "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe" || true)
  if echo "$bot_info" | grep -q '"ok":true'; then
    local bot_name
    bot_name=$(echo "$bot_info" | grep -o '"username":"[^"]*"' | cut -d'"' -f4)
    ok "Telegram bot @${bot_name} is responding."
  else
    warn "Telegram bot not responding — check token."
  fi
}

telegram_restart() {
  telegram_stop
  telegram_start
}

telegram_destroy() {
  step "Telegram — destroy"
  telegram_stop
  warn "Telegram bot runs inside OpenClaw — destroy the sandbox to fully remove."
  ok "Telegram destroy complete."
}

telegram_status() {
  step "Telegram — status"
  telegram_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   telegram_install   ;;
    configure) telegram_configure ;;
    start)     telegram_start     ;;
    stop)      telegram_stop      ;;
    restart)   telegram_restart   ;;
    health)    telegram_health    ;;
    status)    telegram_status    ;;
    destroy)   telegram_destroy   ;;
    default)
      telegram_install
      telegram_configure
      telegram_start
      telegram_health
      ;;
  esac
fi
