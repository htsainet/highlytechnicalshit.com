#!/usr/bin/env bash
# Tabby – self-hosted AI code completion server (Docker)
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
# shellcheck source=scripts/lib/common.sh
source "$REPO_DIR/scripts/lib/common.sh"
# shellcheck source=scripts/lib/health.sh
source "$REPO_DIR/scripts/lib/health.sh"
# shellcheck source=scripts/lib/compose.sh
source "$REPO_DIR/scripts/lib/compose.sh"

TABBY_CONTAINER="${TABBY_CONTAINER:-hts-ai-tabby}"
TABBY_PORT="${TABBY_PORT:-8085}"

###############################################################################
# Lifecycle
###############################################################################

tabby_install() {
  info "Building Tabby image …"
  compose_build --profile tabby
  ok "Tabby image ready"
}

tabby_configure() {
  info "Configuring Tabby …"
  if [[ -f "$REPO_DIR/.env" ]]; then
    if ! grep -q '^TABBY_PORT=' "$REPO_DIR/.env"; then
      echo "TABBY_PORT=${TABBY_PORT}" >> "$REPO_DIR/.env"
    fi
    if ! grep -q '^TABBY_MODEL=' "$REPO_DIR/.env"; then
      echo "TABBY_MODEL=TabbyML/StarCoder-1B" >> "$REPO_DIR/.env"
    fi
  fi
  ok "Tabby configured on port ${TABBY_PORT}"
}

tabby_start() {
  info "Starting Tabby …"
  compose_up --profile tabby
  wait_for_healthy "$TABBY_CONTAINER" 120
  ok "Tabby is running at http://localhost:${TABBY_PORT}"
}

tabby_stop() {
  info "Stopping Tabby …"
  compose_down --profile tabby
  ok "Tabby stopped"
}

tabby_restart() {
  tabby_stop
  tabby_start
}

tabby_health() {
  health_probe "Tabby :${TABBY_PORT}" \
    "http://localhost:${TABBY_PORT}/v1/health"
}

tabby_destroy() {
  info "Destroying Tabby (removing volumes) …"
  compose_down --profile tabby -v
  ok "Tabby destroyed"
}

tabby_status() {
  if docker ps --format '{{.Names}}' 2>/dev/null \
       | grep -q "^${TABBY_CONTAINER}$"; then
    echo "running"
  else
    echo "stopped"
  fi
}
