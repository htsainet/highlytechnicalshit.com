#!/bin/sh
# =============================================================================
# BitNet container entrypoint
# Downloads the configured model GGUF on first run (skips if already cached),
# then starts llama-server with an OpenAI-compatible API on :8080.
#
# Environment variables (all optional, defaults shown):
#   BITNET_MODEL      BitNet-b1.58-2B-4T           (model directory name)
#   BITNET_HF_REPO    microsoft/BitNet-b1.58-2B-4T-gguf
#   BITNET_GGUF       ggml-model-i2_s.gguf
#   BITNET_CTX_SIZE   4096
#   BITNET_N_PREDICT  512
#   BITNET_PARALLEL   1
#   BITNET_GPU_LAYERS 99   (set to 0 for CPU-only)
# =============================================================================
set -e

BITNET_MODEL="${BITNET_MODEL:-BitNet-b1.58-2B-4T}"
BITNET_HF_REPO="${BITNET_HF_REPO:-microsoft/BitNet-b1.58-2B-4T-gguf}"
BITNET_GGUF="${BITNET_GGUF:-ggml-model-i2_s.gguf}"
BITNET_CTX_SIZE="${BITNET_CTX_SIZE:-4096}"
BITNET_N_PREDICT="${BITNET_N_PREDICT:-512}"
BITNET_PARALLEL="${BITNET_PARALLEL:-1}"
BITNET_GPU_LAYERS="${BITNET_GPU_LAYERS:-99}"

MODEL_DIR="/app/models/${BITNET_MODEL}"
MODEL_FILE="${MODEL_DIR}/${BITNET_GGUF}"

# ── Download model on first run ───────────────────────────────────────────────
if [ ! -f "${MODEL_FILE}" ]; then
    echo "[bitnet] Model not found — downloading from Hugging Face..."
    echo "[bitnet] Repo : ${BITNET_HF_REPO}"
    echo "[bitnet] Dest : ${MODEL_DIR}"
    mkdir -p "${MODEL_DIR}"

    python3 - <<PYEOF
from huggingface_hub import snapshot_download
import os
snapshot_download(
    repo_id="${BITNET_HF_REPO}",
    local_dir="${MODEL_DIR}",
    token=os.environ.get("HF_TOKEN") or None,
    # skip raw safetensors weights — we only need the GGUF
    ignore_patterns=["*.safetensors", "*.bin", "*.pt"],
)
print("[bitnet] Download complete.")
PYEOF
fi

if [ ! -f "${MODEL_FILE}" ]; then
    echo "[bitnet] ERROR: expected ${MODEL_FILE} after download. Check HF repo name."
    exit 1
fi

echo "[bitnet] ─────────────────────────────────────────────"
echo "[bitnet] Model : ${MODEL_FILE}"
echo "[bitnet] API   : http://0.0.0.0:8080/v1"
echo "[bitnet] ─────────────────────────────────────────────"

# ── Start llama-server ────────────────────────────────────────────────────────
# -ngl        offload layers to GPU; set to 0 for CPU-only
# --alias     report model name as "bitnet" in /v1/models (for llama-swap routing)
# --host      must be 0.0.0.0 so Docker/OpenShell can reach it
exec /app/bin/llama-server \
    --model  "${MODEL_FILE}" \
    --alias  bitnet \
    --host   0.0.0.0 \
    --port   8080 \
    --ctx-size  "${BITNET_CTX_SIZE}" \
    --n-predict "${BITNET_N_PREDICT}" \
    --parallel  "${BITNET_PARALLEL}" \
    -ngl "${BITNET_GPU_LAYERS}"
