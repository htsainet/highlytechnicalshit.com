# SillyTavern References

Last updated: 2026-04-15

## Upstream

- [GitHub — SillyTavern/SillyTavern](https://github.com/SillyTavern/SillyTavern)

## Official documentation

- [SillyTavern Docs](https://docs.sillytavern.app/)
