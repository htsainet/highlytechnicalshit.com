$ErrorActionPreference = 'Stop'

BeforeDiscovery {
    $repoRoot  = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $scriptsDir = Join-Path $repoRoot 'scripts'

    # Find all .sh files that set SCRIPT_DIR
    $allShFiles = Get-ChildItem -Path $scriptsDir -Filter '*.sh' -File -Recurse

    # Build a map: file → does it set SCRIPT_DIR, does it use SCRIPT_DIR for source/., is it sourced by others
    $settersAndUsers = @()

    foreach ($f in $allShFiles) {
        $content = Get-Content $f.FullName -Raw
        $lines   = Get-Content $f.FullName

        # Does this file set SCRIPT_DIR?
        $setsSCRIPT_DIR = $lines | Where-Object { $_ -match '^\s*SCRIPT_DIR=' }

        # Does this file use $SCRIPT_DIR in a source/. command?
        $usesForSource = $lines | Where-Object {
            $_ -match '(source|\.\s)\s+.*\$SCRIPT_DIR' -and
            $_ -notmatch '^\s*#'
        }

        # Is this file sourced by any other file?
        $relativePath = $f.FullName.Substring($repoRoot.Length + 1)
        $baseName     = $f.Name
        $sourcedBy    = @()

        foreach ($other in $allShFiles) {
            if ($other.FullName -eq $f.FullName) { continue }
            $otherLines = Get-Content $other.FullName
            $refs = $otherLines | Where-Object {
                ($_ -match "(source|\.\s)\s+.*$baseName" -or
                 $_ -match "(source|\.\s)\s+.*$relativePath") -and
                $_ -notmatch '^\s*#'
            }
            if ($refs) {
                $sourcedBy += $other.Name
            }
        }

        if ($setsSCRIPT_DIR -and $usesForSource -and ($sourcedBy.Count -gt 0)) {
            $settersAndUsers += @{
                fileName     = $relativePath
                fullPath     = $f.FullName
                usesForSource = @($usesForSource)
                sourcedBy    = $sourcedBy
            }
        }
    }

    $script:CollisionCases = $settersAndUsers
}

# ── Tests ─────────────────────────────────────────────────────────────────────

Describe 'SCRIPT_DIR collision safety' {

    It 'finds shell scripts to analyse' {
        # Sanity: we should find scripts in the repo
        $scriptsDir = Join-Path ([System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))) 'scripts'
        $count = (Get-ChildItem -Path $scriptsDir -Filter '*.sh' -File -Recurse).Count
        $count | Should -BeGreaterThan 0
    }

    It '<fileName> — sourced by other scripts but uses $SCRIPT_DIR for sibling references (collision risk)' -TestCases $script:CollisionCases {
        param($fileName, $fullPath, $usesForSource, $sourcedBy)

        $content = Get-Content $fullPath -Raw

        # Check if the file uses a file-local variable (e.g., _LIFECYCLE_DIR, _MY_DIR)
        # instead of bare SCRIPT_DIR for its source references
        $hasLocalDir = $content -match '_[A-Z_]+_DIR="\$\(cd "\$\(dirname "\$\{BASH_SOURCE\[0\]\}"\)" && pwd\)"'

        # If it still uses $SCRIPT_DIR directly in source commands, that's the bug
        $bareScriptDirSources = $usesForSource | Where-Object {
            $_ -match 'source\s+"\$SCRIPT_DIR/' -or $_ -match '\.\s+"\$SCRIPT_DIR/'
        }

        # Fail if sourced by others AND uses bare $SCRIPT_DIR (not a local var) for source
        if ($bareScriptDirSources.Count -gt 0) {
            $msg = "File is sourced by [$($sourcedBy -join ', ')] but uses `$SCRIPT_DIR for sibling source commands. " +
                   "Use a file-local variable (e.g., _MY_DIR) to avoid collisions when sourced."
            $bareScriptDirSources.Count | Should -Be 0 -Because $msg
        }
    }
}
