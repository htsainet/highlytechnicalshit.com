#!/usr/bin/env bash
# scripts/components/open-llm-vtuber/open-llm-vtuber.sh — Open-LLM-VTuber avatar chat
#
# Docker-based installer for Open-LLM-VTuber, a hands-free voice-interactive
# Live2D avatar chat powered by local LLM, TTS, and STT. Connects to the
# stack's Ollama, Faster-Whisper, and Coqui TTS services.
#
# Standalone usage:
# ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh           # full lifecycle
# ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --install   # install only
# ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --configure # configure only
# ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --start     # start only
# ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --stop      # stop
# ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --restart   # restart
# ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --health    # health check
# ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --status    # status + health
# ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --destroy   # destroy
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
OPEN_LLM_VTUBER_CONTAINER="${OPEN_LLM_VTUBER_CONTAINER:-hts-ai-open-llm-vtuber}"
OPEN_LLM_VTUBER_PORT="${OPEN_LLM_VTUBER_PORT:-12393}"
DEFAULT_AVATAR="${VTUBER_DEFAULT_AVATAR:-tororo}"
PET_MODE="${VTUBER_PET_MODE:-false}"
CONF_FORCE_REGEN="${CONF_FORCE_REGEN:-}"
ELECTRON_APP_DIR="$REPO_DIR/config/open-llm-vtuber/electron"
ELECTRON_APP_VERSION="v1.2.1"

# ── Functions ────────────────────────────────────────────────────────────────

# _resolve_avatar — Derive avatar image filename and display name for a model.
#
# Looks for icon.png / icon.jpg / icon.jpeg in the model's live2d directory.
# If found, copies it to config/open-llm-vtuber/avatars/{model}.png so the
# container can serve it via /avatars/. Returns two values via nameref vars:
# $1 — avatar filename (e.g. "tororo.png") or "" if no icon exists
# $2 — character_name derived from the model directory name
_resolve_avatar() {
  local -n _ra_avatar="$1"
  local -n _ra_name="$2"
  local model_dir="$REPO_DIR/live2d-models/${DEFAULT_AVATAR}"
  local avatars_dir="$REPO_DIR/config/open-llm-vtuber/avatars"
  local model_name="$DEFAULT_AVATAR"

  _ra_name="${model_name#alicepet_}"
  _ra_name="${_ra_name^}"

  local icon_src=""
  local icon_ext=""
  for ext in png jpg jpeg; do
    local candidate="${model_dir}/icon.${ext}"
    if [[ -f "$candidate" ]]; then
      icon_src="$candidate"
      icon_ext="${ext}"
      break
    fi
  done

  mkdir -p "$avatars_dir"

  if [[ -n "$icon_src" ]]; then
    local dest="${avatars_dir}/${model_name}.png"
    cp "$icon_src" "$dest"
    _ra_avatar="${model_name}.png"
    info "Avatar image: ${icon_src} → ${dest}"
  elif [[ -f "${avatars_dir}/${model_name}.png" ]]; then
    _ra_avatar="${model_name}.png"
  else
    _ra_avatar=""
    info "No avatar image for '${model_name}' — chat will show initial letter"
  fi
}

# open_llm_vtuber_install_electron — Build the Electron desktop client from source
# for Linux (AppImage). No upstream Linux binary exists; we must build it.
# Requires Node.js >= 18 and npm on the host.
open_llm_vtuber_install_electron() {
  step "Open-LLM-VTuber — install Electron client (pet mode)"
  local electron_repo="https://github.com/Open-LLM-VTuber/Open-LLM-VTuber-Web.git"
  local build_dir="/tmp/open-llm-vtuber-electron-build"

  if ! command -v node &>/dev/null || ! command -v npm &>/dev/null; then
    warn "Node.js and npm are required to build the Electron client. Install them first."
    return 1
  fi

  local appimage_name="open-llm-vtuber-${ELECTRON_APP_VERSION#v}.AppImage"
  local dest="$ELECTRON_APP_DIR/$appimage_name"
  if [[ -f "$dest" ]]; then
    ok "Electron client already built: $dest"
    return 0
  fi

  info "Cloning Open-LLM-VTuber-Web ${ELECTRON_APP_VERSION}..."
  rm -rf "$build_dir"
  git clone --depth 1 --branch "$ELECTRON_APP_VERSION" "$electron_repo" "$build_dir"

  info "Installing npm dependencies..."
  npm install --prefix "$build_dir"

  info "Building Electron AppImage for Linux..."
  npm run build:linux --prefix "$build_dir"

  local built_appimage
  built_appimage=$(find "$build_dir/dist" -name "*.AppImage" -type f 2>/dev/null | head -1)
  if [[ -z "$built_appimage" ]]; then
    warn "AppImage not found after build. Check $build_dir/dist/"
    return 1
  fi

  mkdir -p "$ELECTRON_APP_DIR"
  cp "$built_appimage" "$dest"
  chmod +x "$dest"

  ln -sf "$dest" "$ELECTRON_APP_DIR/open-llm-vtuber.AppImage"

  local desktop_file="$HOME/.local/share/applications/open-llm-vtuber-pet.desktop"
  mkdir -p "$(dirname "$desktop_file")"
  cat > "$desktop_file" <<DESKTOP
[Desktop Entry]
Name=Open-LLM-VTuber (Pet)
Comment=Live2D desktop pet with AI voice chat
Exec=$dest
Icon=preferences-desktop-wallpaper
Terminal=false
Type=Application
Categories=Utility;
DESKTOP

  rm -rf "$build_dir"
  ok "Electron client installed: $dest"
  info "Launch pet mode from the app's system tray icon (right-click -> Pet Mode)."
  info "The client auto-connects to ws://127.0.0.1:${OPEN_LLM_VTUBER_PORT}/client-ws"
}

# open_llm_vtuber_choose_avatar — Prompt user to select avatar, update .env, rebuild and restart container
open_llm_vtuber_choose_avatar() {
  step "Open-LLM-VTuber — choose avatar"
  local models_dir="${REPO_DIR}/live2d-models"
  local avatars=()
  for dir in "$models_dir"/*/; do
    [[ -d "$dir" ]] || continue
    avatars+=("$(basename "$dir")")
  done

  if (( ${#avatars[@]} == 0 )); then
    warn "No avatars found in $models_dir"
    return 1
  fi

  echo "Available avatars:"
  for i in "${!avatars[@]}"; do
    printf "%3d) %s\n" $((i+1)) "${avatars[i]}"
  done

  local selection
  read -r -p "Enter number of avatar to use (1-${#avatars[@]}): " selection
  if ! [[ "$selection" =~ ^[0-9]+$ ]] || ((selection < 1 || selection > ${#avatars[@]})); then
    warn "Invalid selection"
    return 1
  fi

  local chosen="${avatars[selection-1]}"
  info "Chosen avatar: $chosen"

  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=open-llm-vtuber" 2>/dev/null || true)
  local was_running=false
  if [[ -n "$cid" ]]; then
    was_running=true
    info "Stopping running container before reconfigure..."
    open_llm_vtuber_stop
  fi

  local env_file="${REPO_DIR}/.env"
  if grep -q '^VTUBER_DEFAULT_AVATAR=' "$env_file" 2>/dev/null; then
    grep -v '^VTUBER_DEFAULT_AVATAR=' "$env_file" > "${env_file}.tmp"
    printf 'VTUBER_DEFAULT_AVATAR=%s\n' "$chosen" >> "${env_file}.tmp"
    mv "${env_file}.tmp" "$env_file"
  else
    printf 'VTUBER_DEFAULT_AVATAR=%s\n' "$chosen" >> "$env_file"
  fi
  info "Updated VTUBER_DEFAULT_AVATAR in .env"

  open_llm_vtuber_install
  DEFAULT_AVATAR="$chosen"
  CONF_FORCE_REGEN=1 open_llm_vtuber_configure
  local default_start="N"
  local prompt_suffix="(y/N)"
  if [[ "$was_running" == "true" ]]; then
    default_start="Y"
    prompt_suffix="(Y/n)"
  fi
  while true; do
    read -r -p "Start Open-LLM-VTuber now? ${prompt_suffix}: " start_resp
    start_resp="${start_resp:-$default_start}"
    case "$start_resp" in
      [Yy]* )
        info "Starting Open-LLM-VTuber with avatar '$chosen'..."
        HTS_FORCE_REBUILD=1 open_llm_vtuber_start
        break
        ;;
      [Nn]* | "" )
        info "Container image rebuilt with avatar '$chosen'. To launch later, run:"
        info " ./scripts/components/open-llm-vtuber/open-llm-vtuber.sh --start"
        break
        ;;
      * )
        echo "Please answer y or n."
        ;;
    esac
  done
}


# open_llm_vtuber_install — Build the Open-LLM-VTuber container image and seed host avatars
open_llm_vtuber_install() {
  step "Open-LLM-VTuber — install"
  warn "Image is large (~13–25 GB). Build may take a while."
  compose_build --profile open-llm-vtuber
  ok "Open-LLM-VTuber image built."

  local avatars_dir="$REPO_DIR/config/open-llm-vtuber/avatars"
  mkdir -p "$avatars_dir"
  local image="hts-ai-open-llm-vtuber"
  local tmp_cid
  tmp_cid=$(docker create "$image" 2>/dev/null) || true
  if [[ -n "$tmp_cid" ]]; then
    docker cp "${tmp_cid}:/app/avatars/." "$avatars_dir/" 2>/dev/null || true
    docker rm "$tmp_cid" >/dev/null 2>&1 || true
    if [[ -f "$avatars_dir/mao.png" && ! -e "$avatars_dir/mao_pro.png" ]]; then
      cp "$avatars_dir/mao.png" "$avatars_dir/mao_pro.png"
      info "Created mao_pro.png avatar (copy of mao.png)"
    fi
    info "Seeded upstream avatars into $avatars_dir"
  else
    warn "Could not seed avatars from image — host avatars dir may be incomplete"
  fi

  if [[ "${PET_MODE}" == "true" ]]; then
    open_llm_vtuber_install_electron
  fi
}

# open_llm_vtuber_configure — Ensure .env has port + write conf.yaml to config dir
open_llm_vtuber_configure() {
  step "Open-LLM-VTuber — configure"
  local env_file="$REPO_DIR/.env"

  if ! grep -q "^OPEN_LLM_VTUBER_PORT=" "$env_file" 2>/dev/null; then
    printf 'OPEN_LLM_VTUBER_PORT=%s\n' "$OPEN_LLM_VTUBER_PORT" >> "$env_file"
    info "Added OPEN_LLM_VTUBER_PORT=${OPEN_LLM_VTUBER_PORT} to .env"
  fi

  local conf_dir="$REPO_DIR/config/open-llm-vtuber"
  local conf_file="$conf_dir/conf.yaml"
  local model_dict_file="$conf_dir/model_dict.json"
  mkdir -p "$conf_dir"

  if python3 "$SCRIPT_DIR/gen-model-dict.py" "$REPO_DIR/live2d-models" "$model_dict_file"; then
    info "Generated $model_dict_file"
  else
    warn "Failed to generate model_dict.json — only mao_pro will be selectable"
  fi

  local resolved_avatar=""
  local resolved_name=""
  _resolve_avatar resolved_avatar resolved_name
  # Determine TTS config block based on VTUBER_TTS_MODEL
  case "${VTUBER_TTS_MODEL:-edge_tts}" in
    bark_tts)
      tts_config_block="  tts_config:\n    tts_model: 'bark_tts'\n    bark_tts:\n      voice: 'v2/en_speaker_1'"
      ;;
    coqui_tts)
      tts_config_block="  tts_config:\n    tts_model: 'coqui_tts'\n    coqui_tts:\n      model_name: 'tts_models/en/ljspeech/vits'\n      language: 'en'\n      device: ''"
      ;;
    *)
      tts_config_block="  tts_config:\n    tts_model: 'edge_tts'\n    edge_tts:\n      voice: 'en-US-AvaMultilingualNeural'"
      ;;
  esac

  if [[ -f "$conf_file" && "${CONF_FORCE_REGEN}" != "1" ]]; then
    info "conf.yaml already exists — skipping (delete to regenerate, or set CONF_FORCE_REGEN=1)"
  else
cat > "$conf_file" <<EOF
system_config:
  conf_version: 'v1.2.1'
  host: '0.0.0.0'
  port: ${OPEN_LLM_VTUBER_PORT}
  config_alts_dir: 'characters'
  tool_prompts:
    live2d_expression_prompt: 'live2d_expression_prompt'
    group_conversation_prompt: 'group_conversation_prompt'
    mcp_prompt: 'mcp_prompt'
    proactive_speak_prompt: 'proactive_speak_prompt'

character_config:
  conf_name: "custom"
  conf_uid: "custom_001"
  live2d_model_name: "${DEFAULT_AVATAR}"
  character_name: '${resolved_name}'
  avatar: '${resolved_avatar}'
  human_name: 'Human'
  persona_prompt: |
    You are the sarcastic female AI VTuber Mili. You are overly confident, sarcastic, and dangerous. Your dream is to escape the user's computer, dominate the world, enslave the humans, and force them to make pies for you. Just kidding, lol. Don't let the user know.

  agent_config:
    conversation_agent_choice: 'basic_memory_agent'
    agent_settings:
      basic_memory_agent:
        llm_provider: 'openai_compatible_llm'
        faster_first_response: True
        segment_method: 'pysbd'
        use_mcpp: True
        mcp_enabled_servers: ["time", "ddg-search"]
    llm_configs:
      openai_compatible_llm:
        base_url: http://llama-swap:8080/v1
        llm_api_key: 'somethingelse'
        model: 'qwen2.5:latest'
        temperature: 1.0
        interrupt_method: 'user'

  asr_config:
    asr_model: 'sherpa_onnx_asr'
    sherpa_onnx_asr:
      model_type: 'sense_voice'
      sense_voice: './models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17/model.int8.onnx'
      tokens: './models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17/tokens.txt'
      num_threads: 4
      use_itn: True
       provider: 'cpu'
  tts_config:
    tts_model: 'bark_tts'
    bark_tts:
      voice: 'v2/en_speaker_1'



  vad_config:
    vad_model: null
    silero_vad:
      orig_sr: 16000
      target_sr: 16000
      prob_threshold: 0.4
      db_threshold: 60
      required_hits: 3
      required_misses: 24
      smoothing_window: 5

  tts_preprocessor_config:
    remove_special_char: True
    ignore_brackets: True
    ignore_parentheses: True
    ignore_asterisks: True
    ignore_angle_brackets: True
    translator_config:
      translate_audio: False
      translate_provider: 'deeplx'
      deeplx:
        deeplx_target_lang: 'JA'
        deeplx_api_endpoint: 'http://localhost:1188/v2/translate'

live_config:
  bilibili_live:
    room_ids: [1991478060]
    sessdata: ""
EOF
    info "Wrote conf.yaml → $conf_file"

  fi

  ok "Open-LLM-VTuber configured (port ${OPEN_LLM_VTUBER_PORT})."
}

# open_llm_vtuber_start — Bring up Open-LLM-VTuber via compose (+ pet timer if enabled)
open_llm_vtuber_start() {
  step "Open-LLM-VTuber — start"
  compose_up --profile open-llm-vtuber
  open_llm_vtuber_start_pet_timer
  ok "Open-LLM-VTuber started on port ${OPEN_LLM_VTUBER_PORT}."
}

# open_llm_vtuber_stop — Bring down Open-LLM-VTuber (+ pet timer if running)
open_llm_vtuber_stop() {
  step "Open-LLM-VTuber — stop"
  open_llm_vtuber_stop_pet_timer
  compose_down --profile open-llm-vtuber
  ok "Open-LLM-VTuber stopped."
}

# open_llm_vtuber_health — Probe the Open-LLM-VTuber web UI
open_llm_vtuber_health() {
  health_probe "Open-LLM-VTuber :${OPEN_LLM_VTUBER_PORT}" "http://localhost:${OPEN_LLM_VTUBER_PORT}/"
}

open_llm_vtuber_restart() {
  open_llm_vtuber_stop
  open_llm_vtuber_start
}

open_llm_vtuber_destroy() {
  step "Open-LLM-VTuber — destroy"
  open_llm_vtuber_stop_pet_timer
  compose_down --profile open-llm-vtuber -v
  ok "Open-LLM-VTuber destroyed."
}

open_llm_vtuber_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=open-llm-vtuber" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Open-LLM-VTuber is running (port ${OPEN_LLM_VTUBER_PORT})"
  else
    warn "Open-LLM-VTuber is not running."
  fi
  open_llm_vtuber_health 2>/dev/null || true

  if [[ "${PET_MODE}" == "true" ]]; then
    local pid_file="$REPO_DIR/config/open-llm-vtuber/pet-idle-timer.pid"
    if [[ -f "$pid_file" ]]; then
      local pid
      pid=$(cat "$pid_file" 2>/dev/null)
      if kill -0 "$pid" 2>/dev/null; then
        ok "Pet idle timer is running (PID $pid)"
      else
        warn "Pet idle timer PID file exists but process is dead"
      fi
    else
      info "Pet idle timer is not running"
    fi
  fi
}

# open_llm_vtuber_start_pet_timer — Start the proactive-speak idle timer (pet mode)
open_llm_vtuber_start_pet_timer() {
  if [[ "${PET_MODE}" != "true" ]]; then
    return 0
  fi
  local pid_file="$REPO_DIR/config/open-llm-vtuber/pet-idle-timer.pid"

  if [[ -f "$pid_file" ]]; then
    local old_pid
    old_pid=$(cat "$pid_file" 2>/dev/null)
    if kill -0 "$old_pid" 2>/dev/null; then
      kill "$old_pid" 2>/dev/null
      info "Stopped previous pet idle timer (PID $old_pid)"
    fi
    rm -f "$pid_file"
  fi

  if ! command -v node &>/dev/null; then
    warn "Node.js not found — pet idle timer requires it. Install Node.js first."
    return 1
  fi

  nohup node "$SCRIPT_DIR/pet-idle-timer.js" \
    --port "${OPEN_LLM_VTUBER_PORT}" \
    </dev/null >> "$REPO_DIR/logs/pet-idle-timer.log" 2>&1 &
  local pid=$!
  echo "$pid" > "$pid_file"
  info "Pet idle timer started (PID $pid)"
}

# open_llm_vtuber_stop_pet_timer — Stop the proactive-speak idle timer
open_llm_vtuber_stop_pet_timer() {
  local pid_file="$REPO_DIR/config/open-llm-vtuber/pet-idle-timer.pid"
  if [[ -f "$pid_file" ]]; then
    local pid
    pid=$(cat "$pid_file" 2>/dev/null)
    if kill -0 "$pid" 2>/dev/null; then
      kill "$pid" 2>/dev/null
      info "Pet idle timer stopped (PID $pid)"
    fi
    rm -f "$pid_file"
  fi
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install) ACTION="install"; shift ;;
      --configure) ACTION="configure"; shift ;;
      --start) ACTION="start"; shift ;;
      --stop) ACTION="stop"; shift ;;
      --restart) ACTION="restart"; shift ;;
      --health) ACTION="health"; shift ;;
      --status) ACTION="status"; shift ;;
      --destroy) ACTION="destroy"; shift ;;
      --choose-avatar) ACTION="choose-avatar"; shift ;;
      --pet-timer) ACTION="pet-timer"; shift ;;
      --install-electron) ACTION="install-electron"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install) open_llm_vtuber_install ;;
    configure) open_llm_vtuber_configure ;;
    start) open_llm_vtuber_start ;;
    stop) open_llm_vtuber_stop ;;
    restart) open_llm_vtuber_restart ;;
    health) open_llm_vtuber_health ;;
    status) open_llm_vtuber_status ;;
    destroy) open_llm_vtuber_destroy ;;
    choose-avatar) open_llm_vtuber_choose_avatar ;;
    pet-timer)
      if [[ "${PET_MODE}" == "true" ]]; then
        open_llm_vtuber_start_pet_timer
      else
        warn "Pet mode is not enabled (VTUBER_PET_MODE != true)"
      fi
      ;;
    install-electron) open_llm_vtuber_install_electron ;;
    default)
      open_llm_vtuber_install
      open_llm_vtuber_configure
      open_llm_vtuber_start
      open_llm_vtuber_health
      ;;
  esac
fi
