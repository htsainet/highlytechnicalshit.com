# GIMP — Component Context

## Purpose

GIMP (GNU Image Manipulation Program) is a free and open-source raster
graphics editor for photo retouching, image composition, and image
authoring. It supports advanced features like layers, masks, curves,
and extensible plug-ins.

## Location

`scripts/components/gimp/` — component directory

## Key Files

| File | Purpose |
|------|---------|
| `gimp.manifest.json` | Convergence manifest |
| `gimp.sh` | Install / configure / health script |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and notes |

## Notes

- Installed via **snap** for latest stable version
- Desktop application — no Docker service or web UI
- Supports Python-Fu and Script-Fu plug-in scripting
- PSD, TIFF, PNG, JPEG, WebP and many other format support

See [usage.md](./usage.md) for command usage.
