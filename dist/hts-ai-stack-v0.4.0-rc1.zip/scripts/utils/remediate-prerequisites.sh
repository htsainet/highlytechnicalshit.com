#!/usr/bin/env bash
# remediate-prerequisites.sh — Install missing prerequisites in dependency order
#
# Reads prerequisites.json, identifies what's missing, and installs them
# in the correct scope order. Packages needing custom apt repos are
# delegated to their original installer scripts.
#
# Usage:
#   sudo ./remediate-prerequisites.sh              # install all missing
#   sudo ./remediate-prerequisites.sh --dry-run     # show what would be installed
#   sudo ./remediate-prerequisites.sh --scope dev   # only remediate 'dev' scope
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

PREREQ_FILE="$REPO_DIR/scripts/host/prerequisites.json"

if [[ ! -f "$PREREQ_FILE" ]]; then
  fail "prerequisites.json not found at $PREREQ_FILE"
fi

if ! command -v jq &>/dev/null; then
  fail "jq is required but not installed — run: sudo apt-get install -y jq"
fi

# ── Parse arguments ──────────────────────────────────────────────────────────
DRY_RUN=false
SCOPE_FILTER=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run)  DRY_RUN=true; shift ;;
    --scope)    SCOPE_FILTER="$2"; shift 2 ;;
    --help|-h)
      echo "Usage: $0 [--dry-run] [--scope <scope>]"
      echo ""
      echo "Options:"
      echo "  --dry-run   Show what would be installed without making changes"
      echo "  --scope     Only remediate a specific scope"
      echo ""
      echo "Scopes (install order): core → optional → networking → service → admin → dev → tooling"
      exit 0
      ;;
    *) fail "Unknown argument: $1" ;;
  esac
done

# ── Scope install order (dependencies first) ────────────────────────────────
SCOPE_ORDER=(core optional networking service admin dev tooling)

# ── Packages that need custom apt repos ──────────────────────────────────────
# These can't be installed via plain apt — their installer scripts set up
# the required GPG keys and apt sources first.
declare -A REPO_PACKAGES=(
  # Docker repo (download.docker.com)
  [docker-ce]="scripts/host/docker.sh"
  [docker-ce-cli]="scripts/host/docker.sh"
  [containerd.io]="scripts/host/docker.sh"
  [docker-buildx-plugin]="scripts/host/docker.sh"
  [docker-compose-plugin]="scripts/host/docker.sh"
  # NVIDIA Container Toolkit repo (nvidia.github.io)
  [nvidia-container-toolkit]="scripts/host/nvidia.sh"
  # Tailscale repo (pkgs.tailscale.com)
  [tailscale]="scripts/components/tailscale.sh"
  # Microsoft repos (packages.microsoft.com)
  [code]="scripts/host/tools.sh"
  [powershell]="scripts/host/tools.sh"
  [dotnet-sdk-8.0]="scripts/host/tools.sh"
)

# ── Helpers ──────────────────────────────────────────────────────────────────

_is_installed() {
  local pkg="$1"
  dpkg -s "$pkg" &>/dev/null || command -v "$pkg" &>/dev/null
}

_repo_available() {
  # Check if apt knows about the package (repo is configured)
  apt-cache show "$1" &>/dev/null 2>&1
}

_get_missing_for_scope() {
  local scope="$1"
  jq -r --arg s "$scope" \
    '.prerequisites[] | select(.scope == $s) | .package' "$PREREQ_FILE"
}

# ── Collect missing packages ────────────────────────────────────────────────
banner() {
  echo -e "\n${CYAN}${BOLD}╔══════════════════════════════════════════════════════╗${NC}"
  echo -e "${CYAN}${BOLD}║     PREREQUISITE REMEDIATOR                         ║${NC}"
  echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════╝${NC}\n"
}

banner

if [[ "$DRY_RUN" == "true" ]]; then
  info "DRY RUN — no changes will be made"
  echo ""
fi

TOTAL_MISSING=0
TOTAL_INSTALLED=0
TOTAL_SKIPPED=0
DELEGATED_INSTALLERS=()

for scope in "${SCOPE_ORDER[@]}"; do
  # If filtering by scope, skip non-matching
  if [[ -n "$SCOPE_FILTER" && "$scope" != "$SCOPE_FILTER" ]]; then
    continue
  fi

  MISSING_APT=()
  MISSING_REPO=()

  while IFS= read -r pkg; do
    [[ -z "$pkg" ]] && continue

    if _is_installed "$pkg"; then
      continue
    fi

    TOTAL_MISSING=$((TOTAL_MISSING + 1))

    # Check if this package needs a custom repo
    if [[ -n "${REPO_PACKAGES[$pkg]:-}" ]]; then
      if _repo_available "$pkg"; then
        # Repo is already configured, safe to apt install
        MISSING_APT+=("$pkg")
      else
        MISSING_REPO+=("$pkg")
      fi
    else
      MISSING_APT+=("$pkg")
    fi
  done < <(_get_missing_for_scope "$scope")

  # Skip scope if nothing to do
  if [[ ${#MISSING_APT[@]} -eq 0 && ${#MISSING_REPO[@]} -eq 0 ]]; then
    continue
  fi

  step "Scope: $scope"

  # ── Handle packages needing repo setup ──────────────────────────────────
  if [[ ${#MISSING_REPO[@]} -gt 0 ]]; then
    # Group by installer script
    declare -A installer_groups=()
    for pkg in "${MISSING_REPO[@]}"; do
      local_installer="${REPO_PACKAGES[$pkg]}"
      installer_groups["$local_installer"]+="$pkg "
    done

    for installer in "${!installer_groups[@]}"; do
      pkgs="${installer_groups[$installer]}"
      if [[ "$DRY_RUN" == "true" ]]; then
        info "WOULD DELEGATE: ${pkgs% } → $installer"
      else
        warn "Packages need repo setup: ${pkgs% }"
        info "Delegating to: $installer"

        installer_path="$REPO_DIR/$installer"
        if [[ -x "$installer_path" ]]; then
          if bash "$installer_path"; then
            # Verify what actually got installed
            for pkg in ${pkgs}; do
              if _is_installed "$pkg"; then
                TOTAL_INSTALLED=$((TOTAL_INSTALLED + 1))
                ok "Installed: $pkg (via $installer)"
              else
                TOTAL_SKIPPED=$((TOTAL_SKIPPED + 1))
                warn "Still missing after running $installer: $pkg"
              fi
            done
          else
            warn "$installer exited with errors — some packages may not be installed"
            TOTAL_SKIPPED=$((TOTAL_SKIPPED + ${#MISSING_REPO[@]}))
          fi
        else
          warn "Installer not found or not executable: $installer_path"
          info "Run manually: bash $installer_path"
          TOTAL_SKIPPED=$((TOTAL_SKIPPED + $(echo "$pkgs" | wc -w)))
          DELEGATED_INSTALLERS+=("$installer (${pkgs% })")
        fi
      fi
    done
    unset installer_groups
  fi

  # ── Handle standard apt packages ────────────────────────────────────────
  if [[ ${#MISSING_APT[@]} -gt 0 ]]; then
    if [[ "$DRY_RUN" == "true" ]]; then
      info "WOULD INSTALL: ${MISSING_APT[*]}"
    else
      info "Installing: ${MISSING_APT[*]}"
      # apt-get update may warn about unrelated repos; don't let that block us
      sudo apt-get update -qq 2>&1 | grep -v '^W:' || true
      # Install packages individually to handle failures gracefully
      for pkg in "${MISSING_APT[@]}"; do
        if sudo apt-get install -y -qq "$pkg" 2>/dev/null; then
          TOTAL_INSTALLED=$((TOTAL_INSTALLED + 1))
          ok "Installed: $pkg"
        else
          TOTAL_SKIPPED=$((TOTAL_SKIPPED + 1))
          warn "Failed to install: $pkg (may not be available for this platform)"
        fi
      done
    fi
  fi
done

# ── Summary ──────────────────────────────────────────────────────────────────
echo ""
step "Summary"

if [[ $TOTAL_MISSING -eq 0 ]]; then
  ok "All prerequisites are already installed — nothing to do."
  exit 0
fi

if [[ "$DRY_RUN" == "true" ]]; then
  info "Would remediate $TOTAL_MISSING package(s)"
else
  info "Installed: $TOTAL_INSTALLED  |  Skipped/Failed: $TOTAL_SKIPPED"
fi

if [[ ${#DELEGATED_INSTALLERS[@]} -gt 0 ]]; then
  echo ""
  warn "Some packages need their installer scripts run manually:"
  for entry in "${DELEGATED_INSTALLERS[@]}"; do
    info "  → $entry"
  done
fi

if [[ $TOTAL_SKIPPED -gt 0 ]]; then
  echo ""
  info "Re-run check-prerequisites.sh to verify remaining gaps:"
  info "  $REPO_DIR/scripts/utils/check-prerequisites.sh"
  exit 1
fi

ok "All missing prerequisites have been installed."
