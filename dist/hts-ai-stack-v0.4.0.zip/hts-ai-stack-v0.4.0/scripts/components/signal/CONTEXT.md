# Signal Component

Last updated: 2026-04-21

## What happens here

Signal CLI provides command-line access to the Signal messaging protocol.
Used in the stack as a notification channel — AI agents can send alerts
and summaries via Signal messages.

## Files and structure

| File | Purpose |
|------|---------|
| `signal.sh` | Full lifecycle: install, configure, start, stop, health |
| `signal.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Archive naming — native binary (important)

signal-cli releases ship **two variants** since at least v0.13.14:

| Archive suffix | Description |
|----------------|-------------|
| `Linux-native.tar.gz` | GraalVM-compiled native binary — **no JVM required** |
| `Linux-client.tar.gz` | JVM-based client |

We use `-native`. The old `Linux.tar.gz` name (no suffix) no longer exists.
`signal.sh` sets `SIGNAL_CLI_VERSION` (default `0.14.2`) and constructs the
URL accordingly. If the install fails with a 404, check that the version is
still current on <https://github.com/AsamK/signal-cli/releases>.

The binary inside the tarball unpacks to `bin/signal-cli` (the `--strip-components=1`
flag in the `tar` call handles this). No JVM install step is needed.

Fix committed 2026-04-21 (`236de79`): switched from `Linux.tar.gz` →
`Linux-native.tar.gz` and removed the Java runtime install block.

See [usage.md](./usage.md) for command usage.
