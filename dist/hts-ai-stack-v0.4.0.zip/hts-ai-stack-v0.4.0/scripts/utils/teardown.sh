#!/usr/bin/env bash
# teardown.sh — Stop the AI stack
#
# Stops all services defined in docker-compose.yml.
# NemoClaw sandboxes are managed separately by the nemoclaw CLI.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$SCRIPT_DIR/06-stop-test-instances.sh" "$@"
