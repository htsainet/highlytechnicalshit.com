$ErrorActionPreference = 'Stop'

BeforeDiscovery {
    $repoRoot  = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $stackPath = Join-Path $repoRoot 'config/stack.json'

    $script:StackPath    = $stackPath
    $script:StackExists  = Test-Path $stackPath
    $script:Stack        = if ($script:StackExists) {
        Get-Content $stackPath -Raw | ConvertFrom-Json
    } else { $null }
}

# ── Pre-flight ────────────────────────────────────────────────────────────────

Describe 'Stack file exists' {
    It 'config/stack.json is present' {
        $script:StackExists | Should -Be $true
    }

    It 'config/stack.json is valid JSON' {
        { Get-Content $script:StackPath -Raw | ConvertFrom-Json } | Should -Not -Throw
    }
}

# ── _meta block ───────────────────────────────────────────────────────────────

Describe '_meta block' {
    It 'has _meta block' {
        $script:Stack._meta | Should -Not -BeNullOrEmpty
    }

    It '_meta.format_version is "2"' {
        $script:Stack._meta.format_version | Should -Be '2'
    }

    It '_meta.saved_at is non-empty' {
        $script:Stack._meta.saved_at | Should -Not -BeNullOrEmpty
    }

    It '_meta.note is non-empty' {
        $script:Stack._meta.note | Should -Not -BeNullOrEmpty
    }
}

# ── Required top-level sections ───────────────────────────────────────────────

Describe 'Required top-level sections' {
    $requiredSections = @(
        'backend', 'model', 'pull_all_models',
        'instances', 'model_cache', 'voice', 'images',
        'sandbox', 'network', 'comms', 'admin', 'nas',
        'services', 'extras'
    )

    It '<_> section is present' -ForEach ($requiredSections | ForEach-Object { @{ _ = $_ } }) {
        $script:Stack.PSObject.Properties.Name | Should -Contain $_
    }
}

# ── backend ───────────────────────────────────────────────────────────────────

Describe 'backend' {
    It 'backend is a non-empty string' {
        $script:Stack.backend | Should -Not -BeNullOrEmpty
        $script:Stack.backend | Should -BeOfType [string]
    }

    It 'backend is a known value' {
        $script:Stack.backend | Should -BeIn @('ollama', 'bitnet', 'dual', 'lmstudio')
    }

    It 'dual backend has inference block' {
        if ($script:Stack.backend -eq 'dual') {
            $script:Stack.inference | Should -Not -BeNullOrEmpty
            $script:Stack.inference.router      | Should -Not -BeNullOrEmpty
            $script:Stack.inference.router_port | Should -Not -BeNullOrEmpty
            $script:Stack.inference.ollama_port | Should -Not -BeNullOrEmpty
        }
    }
}

# ── instances ─────────────────────────────────────────────────────────────────

Describe 'instances block' {
    It 'instances.mode is present' {
        $script:Stack.instances.mode | Should -Not -BeNullOrEmpty
    }

    It 'instances.prod_port is a number' {
        [int]$script:Stack.instances.prod_port | Should -BeGreaterThan 0
    }
}

# ── network ───────────────────────────────────────────────────────────────────

Describe 'network block' {
    It 'network.topology is present' {
        $script:Stack.network.topology | Should -Not -BeNullOrEmpty
    }

    It 'network.mode is present' {
        $script:Stack.network.mode | Should -Not -BeNullOrEmpty
    }
}

# ── services block ────────────────────────────────────────────────────────────

Describe 'services block' {
    It 'services.ollama has use_external boolean' {
        $script:Stack.services.ollama.use_external | Should -BeOfType [bool]
    }

    It 'services.open_webui has use_external boolean' {
        $script:Stack.services.open_webui.use_external | Should -BeOfType [bool]
    }

    It 'services.nemoclaw has deploy boolean' {
        $script:Stack.services.nemoclaw.deploy | Should -BeOfType [bool]
    }
}

# ── admin block ───────────────────────────────────────────────────────────────

Describe 'admin block' {
    It 'admin.tools is an array' {
        ,$script:Stack.admin.tools | Should -BeOfType [array]
    }

    It 'admin.ssh_pubkey_only is a boolean' {
        $script:Stack.admin.ssh_pubkey_only | Should -BeOfType [bool]
    }
}

# ── comms block ───────────────────────────────────────────────────────────────

Describe 'comms block' {
    It 'comms.platforms is an array' {
        ,$script:Stack.comms.platforms | Should -BeOfType [array]
    }

    It 'comms does not contain tokens with values (secrets stripped)' {
        $tokens = $script:Stack.comms.tokens
        if ($tokens) {
            $tokens.PSObject.Properties | ForEach-Object {
                $_.Value | Should -BeNullOrEmpty -Because "tokens must be stripped from stack.json"
            }
        }
    }
}

# ── no secrets in top-level keys ──────────────────────────────────────────────

Describe 'No secrets in stack.json' {
    $secretPatterns = @('password', 'token', 'secret', 'key', 'api_key', 'auth_key', 'bot_token')

    It 'top-level keys do not look like secrets' {
        foreach ($key in $script:Stack.PSObject.Properties.Name) {
            $key | Should -Not -Match ($secretPatterns -join '|')
        }
    }
}
