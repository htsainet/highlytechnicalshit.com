#!/usr/bin/env bash
# scripts/components/open-webui/open-webui.sh — Open WebUI chat frontend: install, configure, start
#
# Standalone usage:
#   ./scripts/components/open-webui/open-webui.sh              # full: install + configure + start + health + bootstrap
#   ./scripts/components/open-webui/open-webui.sh --install    # install only
#   ./scripts/components/open-webui/open-webui.sh --configure  # configure only
#   ./scripts/components/open-webui/open-webui.sh --start      # start only
#   ./scripts/components/open-webui/open-webui.sh --stop       # stop
#   ./scripts/components/open-webui/open-webui.sh --restart    # restart (stop + start)
#   ./scripts/components/open-webui/open-webui.sh --health     # health check only
#   ./scripts/components/open-webui/open-webui.sh --status     # show status + port + health
#   ./scripts/components/open-webui/open-webui.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"
source "$REPO_DIR/scripts/lib/tokens.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
WEBUI_PORT="${WEBUI_PORT:-3000}"
WEBUI_CONTAINER="${WEBUI_CONTAINER:-hts-ai-open-webui-1}"
LLAMA_SWAP_URL="http://llama-swap:8080"

# ── Functions ────────────────────────────────────────────────────────────────

# openwebui_install — Ensure external volume exists and pull the image
openwebui_install() {
  step "Open WebUI — install"

  # The open-webui volume is external: true in docker-compose.yml — pre-create it
  local vol="hts-ai_open_webui_data"
  if ! docker volume inspect "$vol" >/dev/null 2>&1; then
    info "Creating Docker volume: $vol"
    docker volume create "$vol" || warn "Failed to create $vol"
  fi

  compose_build open-webui
  ok "Open WebUI image built."
}

# openwebui_configure — Ensure WEBUI_SECRET_KEY and validate llama-swap
openwebui_configure() {
  step "Open WebUI — configure"

  # Generate WEBUI_SECRET_KEY if missing
  ensure_env_key "WEBUI_SECRET_KEY"

  info "Backend: llama-swap → ${LLAMA_SWAP_URL}/v1"

  ok "Open WebUI configured."
}

# openwebui_start — Bring up Open WebUI via compose
openwebui_start() {
  step "Open WebUI — start"

  # Warn if llama-swap isn't reachable (don't fail — let the user decide)
  local swap_port="${LLAMA_SWAP_PORT:-8081}"
  if ! curl -sf "http://localhost:${swap_port}/health" >/dev/null 2>&1; then
    warn "llama-swap not reachable on :${swap_port} — Open WebUI may not function"
  fi

  compose_up open-webui
  ok "Open WebUI started on port ${WEBUI_PORT}."
}

# openwebui_stop — Bring down Open WebUI
openwebui_stop() {
  step "Open WebUI — stop"
  compose_down open-webui
  ok "Open WebUI stopped."
}

# openwebui_health — Probe the Open WebUI HTTP endpoint
openwebui_health() {
  health_probe "Open WebUI :${WEBUI_PORT}" "http://localhost:${WEBUI_PORT}/"
}

# openwebui_bootstrap_api_key — Create admin account + API key on first run
# Idempotent: skips if WEBUI_API_KEY already exists in .env.
# Reads credentials from config/stack.secrets.json if available,
# otherwise falls back to a random admin account.
openwebui_bootstrap_api_key() {
  step "Open WebUI — API key bootstrap"

  local env_file="${REPO_DIR}/.env"
  local secrets_file="${REPO_DIR}/config/stack.secrets.json"

  # Already have a key? Nothing to do.
  if grep -Eq "^WEBUI_API_KEY=sk-" "$env_file" 2>/dev/null; then
    info "WEBUI_API_KEY already set — skipping bootstrap."
    return 0
  fi

  local base_url="http://localhost:${WEBUI_PORT}"
  local bootstrap_email bootstrap_name bootstrap_password

  # Try to read credentials from stack.secrets.json
  if [[ -f "$secrets_file" ]]; then
    bootstrap_email=$(python3 -c "import json; d=json.load(open('$secrets_file')); print(d.get('webui_credentials',{}).get('admin',{}).get('email',''))" 2>/dev/null || true)
    bootstrap_name=$(python3 -c "import json; d=json.load(open('$secrets_file')); print(d.get('webui_credentials',{}).get('admin',{}).get('name',''))" 2>/dev/null || true)
    bootstrap_password=$(python3 -c "import json; d=json.load(open('$secrets_file')); print(d.get('webui_credentials',{}).get('admin',{}).get('password',''))" 2>/dev/null || true)
  fi

  # Fall back to random credentials if not provided
  if [[ -z "$bootstrap_email" ]]; then
    bootstrap_email="admin@hts-ai-stack.local"
  fi
  if [[ -z "$bootstrap_name" ]]; then
    bootstrap_name="HTS Admin"
  fi
  if [[ -z "$bootstrap_password" ]]; then
    bootstrap_password=$(openssl rand -base64 24)
    info "No admin password in secrets — using generated password."
  else
    info "Using admin credentials from stack.secrets.json."
  fi

  # Try signup (first user = admin). If account exists, fall through to signin.
  local signup_resp
  signup_resp=$(curl -s --max-time 10 "${base_url}/api/v1/auths/signup" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${bootstrap_email}\",\"password\":\"${bootstrap_password}\",\"name\":\"${bootstrap_name}\"}" 2>/dev/null)

  local jwt=""
  # Extract token from signup response
  jwt=$(echo "$signup_resp" | python3 -c "import sys,json; print(json.load(sys.stdin).get('token',''))" 2>/dev/null || true)

  if [[ -z "$jwt" ]]; then
    warn "Could not bootstrap admin account (may already exist)."
    warn "Generate an API key manually: Open WebUI → Settings → Account → API Keys"
    warn "Then add to .env:  WEBUI_API_KEY=sk-..."
    return 0
  fi

  # Generate an API key
  local key_resp
  key_resp=$(curl -s --max-time 10 "${base_url}/api/v1/auths/api_key" \
    -X POST \
    -H "Authorization: Bearer ${jwt}" \
    -H "Content-Type: application/json" 2>/dev/null)

  local api_key
  api_key=$(echo "$key_resp" | python3 -c "import sys,json; print(json.load(sys.stdin).get('api_key',''))" 2>/dev/null || true)

  if [[ -z "$api_key" ]]; then
    warn "Admin account created but API key generation failed."
    warn "Generate manually: Open WebUI → Settings → Account → API Keys"
    return 0
  fi

  # Persist the API key in .env — pure-bash loop, no awk/sed.
  # API keys may contain '=' (e.g. base64 padding) which awk FS="=" splits
  # incorrectly, silently corrupting the value. Matches _write_env pattern
  # in menu-handler.sh.
  if grep -Eq "^WEBUI_API_KEY=" "$env_file"; then
    local tmp found=0; tmp=$(mktemp)
    while IFS= read -r line; do
      if [[ "$line" == "WEBUI_API_KEY="* && $found -eq 0 ]]; then
        echo "WEBUI_API_KEY=${api_key}"
        found=1
      else
        echo "$line"
      fi
    done < "$env_file" > "$tmp" && mv "$tmp" "$env_file"
  else
    printf 'WEBUI_API_KEY=%s\n' "$api_key" >> "$env_file"
  fi

  # Also export for immediate use by provision-webui-functions
  export WEBUI_API_KEY="$api_key"

  ok "API key generated and saved to .env (${api_key:0:10}...)"
  info "Admin account: ${bootstrap_email}"

  # ── Create regular user if credentials were provided ──────────────────────
  _openwebui_create_regular_user "$base_url" "$jwt" "$secrets_file"
}

# _openwebui_create_regular_user — Create a non-admin user from secrets
# Called by openwebui_bootstrap_api_key after admin account is set up.
_openwebui_create_regular_user() {
  local base_url="$1" admin_jwt="$2" secrets_file="$3"

  [[ -f "$secrets_file" ]] || return 0

  local user_email user_name user_password
  user_email=$(python3 -c "import json; d=json.load(open('$secrets_file')); print(d.get('webui_credentials',{}).get('user',{}).get('email',''))" 2>/dev/null || true)
  user_name=$(python3 -c "import json; d=json.load(open('$secrets_file')); print(d.get('webui_credentials',{}).get('user',{}).get('name',''))" 2>/dev/null || true)
  user_password=$(python3 -c "import json; d=json.load(open('$secrets_file')); print(d.get('webui_credentials',{}).get('user',{}).get('password',''))" 2>/dev/null || true)

  if [[ -z "$user_email" || -z "$user_password" ]]; then
    return 0
  fi

  info "Creating regular user account: ${user_email}..."

  # Open WebUI signup endpoint creates new users; first user is admin, subsequent are regular
  local signup_resp
  signup_resp=$(curl -s --max-time 10 "${base_url}/api/v1/auths/signup" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${user_email}\",\"password\":\"${user_password}\",\"name\":\"${user_name}\"}" 2>/dev/null)

  local user_id
  user_id=$(echo "$signup_resp" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || true)

  if [[ -n "$user_id" ]]; then
    ok "Regular user created: ${user_email}"
  else
    warn "Could not create regular user (may already exist): ${user_email}"
  fi
}

# openwebui_generate_dashboard_token — Sign in as admin to get a JWT and write
# it to a sidecar JSON file for the dashboard.  The token is used by the
# auto-login bridge page (resources/open-webui/login.html) that is mounted into
# the Open WebUI container at /static/login.html.
openwebui_generate_dashboard_token() {
  step "Open WebUI — dashboard token"

  local secrets_file="${REPO_DIR}/config/stack.secrets.json"
  local token_file="${REPO_DIR}/resources/dashboard/openwebui-token.json"
  local base_url="http://localhost:${WEBUI_PORT}"

  if [[ ! -f "$secrets_file" ]]; then
    warn "No stack.secrets.json — cannot generate auto-login token."
    return 0
  fi

  # Read admin credentials from secrets
  local email password
  email=$(python3 -c "import json; d=json.load(open('$secrets_file')); print(d.get('webui_credentials',{}).get('admin',{}).get('email',''))" 2>/dev/null || true)
  password=$(python3 -c "import json; d=json.load(open('$secrets_file')); print(d.get('webui_credentials',{}).get('admin',{}).get('password',''))" 2>/dev/null || true)

  if [[ -z "$email" || -z "$password" ]]; then
    warn "No admin credentials in stack.secrets.json — skipping dashboard token."
    return 0
  fi

  # Sign in via the API to get a JWT
  local signin_resp jwt
  signin_resp=$(curl -sf --max-time 10 "${base_url}/api/v1/auths/signin" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${email}\",\"password\":\"${password}\"}" 2>/dev/null || true)

  jwt=$(echo "$signin_resp" | python3 -c "import sys,json; print(json.load(sys.stdin).get('token',''))" 2>/dev/null || true)

  if [[ -z "$jwt" ]]; then
    warn "Could not sign in to Open WebUI — dashboard auto-login unavailable."
    return 0
  fi

  # Write sidecar JSON for the dashboard
  python3 -c "
import json
token_data = {'port': ${WEBUI_PORT}, 'token': '$jwt'}
with open('$token_file', 'w') as f:
    json.dump(token_data, f, indent=2)
" 2>/dev/null || echo "{\"port\":${WEBUI_PORT},\"token\":\"${jwt}\"}" > "$token_file"

  ok "Dashboard auto-login token written → $token_file"
}

# openwebui_provision_functions — Register built-in /slash commands via API
openwebui_provision_functions() {
  local provisioner="$REPO_DIR/scripts/utils/provision-webui-functions.sh"
  if [[ -x "$provisioner" ]]; then
    bash "$provisioner"
  fi
}

openwebui_restart() {
  openwebui_stop
  openwebui_start
}

openwebui_destroy() {
  step "Open WebUI — destroy"
  compose_down open-webui -v
  ok "Open WebUI destroyed."
}

openwebui_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=open-webui" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Open WebUI is running (port ${WEBUI_PORT})"
  else
    warn "Open WebUI is not running."
  fi
  openwebui_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   openwebui_install   ;;
    configure) openwebui_configure ;;
    start)     openwebui_start     ;;
    stop)      openwebui_stop      ;;
    restart)   openwebui_restart   ;;
    health)    openwebui_health    ;;
    status)    openwebui_status    ;;
    destroy)   openwebui_destroy   ;;
    default)
      openwebui_install
      openwebui_configure
      openwebui_start
      openwebui_health
      openwebui_bootstrap_api_key
      openwebui_generate_dashboard_token
      openwebui_provision_functions
      ;;
  esac
fi
