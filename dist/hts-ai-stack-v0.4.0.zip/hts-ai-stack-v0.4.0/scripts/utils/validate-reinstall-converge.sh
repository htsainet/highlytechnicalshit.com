#!/usr/bin/env bash
# scripts/utils/validate-reinstall-converge.sh
# Static validation for installer ordering and VRAM gating used by the wizard.
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
info(){ echo "[INFO] $*"; }
warn(){ echo "[WARN] $*" >&2; }
die(){ echo "[ERROR] $*" >&2; exit 2; }

# Helper: read a JSON field using jq if available, otherwise python3
_read_json_field() {
  local file="$1" key="$2"
  if command -v jq >/dev/null 2>&1; then
    jq -r "${key} // empty" "$file" 2>/dev/null || echo ""
  else
    python3 - <<PY "$file" "$key"
import json,sys
f=sys.argv[1]
key=sys.argv[2]
# strip leading dot from keys like ".order" used by jq expressions
if isinstance(key, str) and key.startswith('.'):
    key = key[1:]
try:
    j=json.load(open(f))
    v=j.get(key)
    print(v if v is not None else "")
except Exception:
    print("")
PY
  fi
}

fail=0

check_order() {
  local comp="$1" expected="$2"
  local mf="$REPO_DIR/scripts/components/${comp}/${comp}.manifest.json"
  if [[ ! -f "$mf" ]]; then
    warn "manifest for $comp not found: $mf"
    fail=1; return
  fi
  local got
  got=$(_read_json_field "$mf" ".order")
  if [[ -z "$got" ]]; then
    warn "order missing in $mf"
    fail=1; return
  fi
  if [[ "$got" -ne "$expected" ]]; then
    warn "$comp order expected $expected but found $got"
    fail=1
  else
    info "$comp order == $expected"
  fi
}

check_vram_min() {
  local comp="$1" expected_min="$2"
  local mf="$REPO_DIR/scripts/components/${comp}/${comp}.manifest.json"
  if [[ ! -f "$mf" ]]; then
    warn "manifest for $comp not found: $mf"
    fail=1; return
  fi
  local got
  got=$(_read_json_field "$mf" ".vram_minimum")
  got=${got:-0}
  if [[ "$got" -lt "$expected_min" ]]; then
    warn "$comp vram_minimum expected >= $expected_min but found $got"
    fail=1
  else
    info "$comp vram_minimum == $got (>= $expected_min)"
  fi
}

# Checks from todo: ollama (20), bitnet (23 right after ollama), prometheus (11), grafana (12)
check_order "ollama" 20
check_order "bitnet" 23
check_order "prometheus" 11
check_order "grafana" 12

# Check localai VRAM gating (should require >= 16384)
check_vram_min "localai" 16384

if [[ "$fail" -ne 0 ]]; then
  echo
  echo "VALIDATION: FAILED"
  exit 2
else
  echo
  echo "VALIDATION: PASSED — static ordering and VRAM gating look correct"
  exit 0
fi
