#!/usr/bin/env bash
# scripts/bundles/voice.sh — Voice chat bundle (STUB)
#
# Voice services (Whisper, Xtts) are not yet available.
# This bundle will extend the chat bundle with speech-to-text and text-to-speech.
#
# Usage:
#   ./scripts/bundles/voice.sh
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

banner "Voice Bundle (STUB)"

warn "Voice services (Whisper, Xtts) are not yet available."
info "Running the chat bundle instead."
echo ""

# Fall through to chat bundle
exec bash "$REPO_DIR/scripts/bundles/chat.sh" "$@"
