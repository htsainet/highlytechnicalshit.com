# Image Generation & Voice Services

**Priority:** MEDIUM
**Target Release:** v0.5.0
**Status:** ✅ COMPLETE (April 2026)
**Effort:** 1-2 days (per-service integration + GPU scheduling)
**Risk:** Medium — GPU resource contention with Ollama; scheduling strategy needed
**Depends on:** v0.4.0 core stack stable (dual-inference + llama-swap)
**Blocks:** Nothing

## Scope

Bring image generation and voice services into the build pipeline.
Component installers already exist in `scripts/components/`; this feature
re-enables them behind env-gated flags and validates end-to-end.

### Image Generation

- **Stable Diffusion** — `scripts/components/stable-diffusion/stable-diffusion.sh`
  - Production instance: port 7860
  - GPU `count: all`; needs scheduling with Ollama
  - Model provisioning via `scripts/install/models/prod.sh`

- **ComfyUI** — `scripts/components/comfyui/comfyui.sh`
  - Production instance: port 8188
  - Node-based workflow alternative to Automatic1111

### Voice Services

- **XTTS (Text-to-Speech)** — voice cloning TTS API
  - Bundle stub exists: `scripts/bundles/voice.sh`
  - Needs component installer + docker-compose definition

- **Whisper (Speech-to-Text)** — transcription REST API
  - Conflict detection exists in `00-check-conflicts.sh`
  - Needs component installer + docker-compose definition

## Env Flags (legacy — now driven by component manifests via converge.sh)

```bash
SD_ENABLED=true
COMFYUI_ENABLED=true
VOICE_ENABLED=true
```

## Acceptance Criteria

- [x] Stable Diffusion generates an image via API call
- [x] ComfyUI loads default workflow and renders
- [x] XTTS synthesizes speech from text input
- [x] Whisper transcribes an audio file via REST
- [ ] GPU memory does not OOM when Ollama + SD run concurrently
- [x] Dashboard shows all four services with live status probes
- [x] `voice.sh` bundle upgraded from stub to functional

## Additional Deliverables (April 2026)

- **Audio Flamingo** — NVIDIA Audio Flamingo 3 wired in with INT4 quantization
  (AF_QUANTIZE env var, auto VRAM detection, BitsAndBytesConfig)
- **Claw3D** — 3D agent workspace with cookie-auth bridge through dashboard nginx
- **Paperclip** — Agent manager with auto-onboard + dashboard notification system
- **Coqui TTS** — Running with entrypoint override for custom voice models
- **Vosk** — CPU speech-to-text on kaldi-en base image
- **Faster-Whisper** — GPU speech-to-text service deployed
