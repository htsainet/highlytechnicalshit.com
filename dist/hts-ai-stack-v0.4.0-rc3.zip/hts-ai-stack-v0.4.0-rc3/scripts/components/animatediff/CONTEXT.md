# AnimateDiff — Component Context

## Purpose

AnimateDiff adds motion modules to Stable Diffusion to generate short
animated sequences from text prompts. Unlike frame-by-frame generation,
AnimateDiff produces temporally coherent animations by learning motion
patterns from video data.

## Location

`scripts/components/animatediff/` — component directory

## Key Files

| File | Purpose |
|------|---------|
| `animatediff.manifest.json` | Convergence manifest |
| `animatediff.sh` | Install / configure / start / health script |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and notes |

## Notes

- Docker compose service on port **8603** (Gradio web UI)
- GPU-accelerated with CUDA — requires NVIDIA GPU
- Base model: Stable Diffusion v1.5 (~4GB VRAM for inference)
- Motion adapter: animatediff-motion-adapter-v1-5-3
- Models auto-downloaded from HuggingFace on first start
- Also available as ComfyUI nodes (see ComfyUI component)
