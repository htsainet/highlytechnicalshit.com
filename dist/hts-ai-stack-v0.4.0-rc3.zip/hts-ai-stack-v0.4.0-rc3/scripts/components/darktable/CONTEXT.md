# Darktable — Component Context

## Purpose

Darktable is a free and open-source photography workflow application and
RAW developer. It provides non-destructive editing of RAW images with a
virtual lighttable and darkroom, similar to Adobe Lightroom. Supports
GPU acceleration via OpenCL.

## Location

`scripts/components/darktable/` — component directory

## Key Files

| File | Purpose |
|------|---------|
| `darktable.manifest.json` | Convergence manifest |
| `darktable.sh` | Install / configure / health script |
| `CONTEXT.md` | This file |
| `REFERENCES.md` | Upstream links and notes |

## Notes

- Installed via **snap** for latest stable version
- Desktop application — no Docker service or web UI
- GPU-accelerated processing via OpenCL
- Non-destructive editing — originals are never modified
- Supports 400+ camera RAW formats
