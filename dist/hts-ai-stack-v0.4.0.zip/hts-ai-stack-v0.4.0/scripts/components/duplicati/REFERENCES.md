# Duplicati References

Last updated: 2026-04-15

## Upstream

- [GitHub — duplicati/duplicati](https://github.com/duplicati/duplicati)

## Official documentation

- [Duplicati Manual](https://docs.duplicati.com/)
