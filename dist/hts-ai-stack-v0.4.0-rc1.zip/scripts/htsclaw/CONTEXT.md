# htsclaw — Self-Managed OpenClaw Sandbox

Last updated: 2026-04-11 23:11:00

## What happens here

htsclaw drives OpenShell directly — no NemoClaw middleman — to create, manage,
and secure OpenClaw agent sandboxes. You control OpenClaw versioning, dependency
patching, and policy enforcement yourself.

## Architecture

```text
Host
├── openshell CLI           (installed globally)
├── scripts/htsclaw/        (this folder — setup, teardown, upgrade, menus)
└── Docker
    └── openshell-cluster-htsclaw   (gateway container, k3s embedded)
        └── Sandbox pod
            └── OpenClaw agent (your version, your patches)
                └── llama-swap (model routing via host.openshell.internal)
```

## Files and structure

| Folder / File | Purpose |
|---------------|---------|
| `policies/` | OpenShell network/filesystem policy YAML files (version-controlled, auditable) |
| `sandbox/` | Sandbox lifecycle scripts — create, destroy, upgrade, exec helpers |
| `personas/` | Agent persona provisioning — SOUL.md/IDENTITY.md injection into sandboxes |
| `menus/` | Python whiptail CLI — interactive setup, teardown, upgrade menus |
| `health/` | Health checks and systemd timer for sandbox liveness monitoring |
| `dashboard/` | Dashboard token extraction and service card integration |
| `REFERENCES.md` | Architecture, permissions, policy semantics, interoperability reference |

## Process / Workflow

1. **Setup** — `menus/htsclaw-menu.py` walks user through sandbox creation
2. **Policy** — `policies/openclaw-sandbox.yaml` applied via `openshell policy set`
3. **Provider** — llama-swap configured as LLM backend inside sandbox
4. **Personas** — SOUL.md/IDENTITY.md uploaded into sandbox workspaces
5. **Health** — systemd timer monitors sandbox liveness every 5 minutes
6. **Upgrade** — destroy + recreate sandbox, `npm update` OpenClaw inside
7. **Teardown** — forwards stopped, sandbox deleted, gateway optionally destroyed

## Relationship to NemoClaw

htsclaw replaces NemoClaw as an install option (`SANDBOX_ENGINE=htsclaw`).
NemoClaw remains available as `SANDBOX_ENGINE=nemoclaw` for users who prefer
NVIDIA's managed experience. Both use OpenShell underneath — they cannot share
a gateway (htsclaw uses gateway name `htsclaw`, NemoClaw uses `nemoclaw`).

## What good looks like

- Policy YAML tracked in Git (security review F2 compliance)
- OpenClaw patched same-day via `npm audit fix` inside sandbox
- No NemoClaw-specific workarounds (GH-503, placeholder pkg, stale sandboxes)
- Agent personas match NemoClaw parity (SOUL.md, IDENTITY.md, multi-agent routing)
- Health timer catches dead forwards and restarts them
- Dashboard shows htsclaw sandbox card with auth token

## Rollout Tracker

See [FEATURE-019](../../docs/development/features/FEATURE-019.md) for remaining
integration steps (component script, bundle, wizard wiring, port audit).

## Tools and skills

- **openshell CLI** — sandbox lifecycle, policy, port forwarding, file upload/exec
- **whiptail** — Ubuntu built-in TUI for interactive menus (no extra deps)
- **Python 3** — menu wrapper calling whiptail via subprocess
- **systemd** — health timer for liveness monitoring
- **UFW** — firewall rules restricting sandbox port access
