#!/usr/bin/env bash
# 07-setup-connectivity.sh — Run all optional connectivity setup scripts.
#
# Calls each script in order. Any script that was already configured will
# skip its completed steps — safe to re-run.
#
# Usage:
#   ./07-setup-connectivity.sh [--telegram] [--signal] [--tailscale] [--firefox-home]
#
#   With no flags: runs all four.
#   With flags:    runs only the specified scripts.
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=setup/tooling/ui.sh
source "$REPO_DIR/setup/tooling/ui.sh"

htsai_banner "07 — Connectivity Setup"

info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
section() { echo -e "\n${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; \
            echo -e "${GREEN}  $*${NC}"; \
            echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }

FIREFOX_HOMEPAGE_URL="${FIREFOX_HOMEPAGE_URL:-http://127.0.0.1}"

# ── Pre-run checklist ─────────────────────────────────────────────────────────
checklist_start
checklist_item false "1. Telegram bot configured (optional)"
checklist_item false "2. Signal bot configured (optional)"
checklist_item false "3. Tailscale VPN configured (optional)"
checklist_item false "4. Firefox homepage set (optional)"
checklist_end

set_firefox_homepage() {
  local profiles_ini profile_dir user_js

  if ! command -v firefox >/dev/null 2>&1; then
    warn "Firefox is not installed; skipping homepage setup."
    return 0
  fi

  profiles_ini="$HOME/.mozilla/firefox/profiles.ini"
  if [ ! -f "$profiles_ini" ]; then
    warn "Firefox profile not found; open Firefox once, then re-run with --firefox-home."
    return 0
  fi

  profile_dir="$(awk -F= '
    /^\[Profile/ { in_profile=1; path=""; rel=1; def=0; next }
    in_profile && /^Path=/ { path=$2; next }
    in_profile && /^IsRelative=/ { rel=$2; next }
    in_profile && /^Default=/ { def=$2; next }
    /^$/ {
      if (in_profile && def == 1) {
        if (rel == 1) print ENVIRON["HOME"] "/.mozilla/firefox/" path;
        else print path;
        exit
      }
      in_profile=0
    }
    END {
      if (in_profile && def == 1) {
        if (rel == 1) print ENVIRON["HOME"] "/.mozilla/firefox/" path;
        else print path;
      }
    }
  ' "$profiles_ini")"

  if [ -z "$profile_dir" ] || [ ! -d "$profile_dir" ]; then
    warn "Could not locate the default Firefox profile; skipping homepage setup."
    return 0
  fi

  user_js="$profile_dir/user.js"
  touch "$user_js"

  if grep -q '^user_pref("browser.startup.homepage",' "$user_js"; then
    sed -i "s|^user_pref(\"browser.startup.homepage\",.*|user_pref(\"browser.startup.homepage\", \"$FIREFOX_HOMEPAGE_URL\");|" "$user_js"
  else
    printf 'user_pref("browser.startup.homepage", "%s");\n' "$FIREFOX_HOMEPAGE_URL" >> "$user_js"
  fi

  if grep -q '^user_pref("browser.startup.page",' "$user_js"; then
    sed -i 's|^user_pref("browser.startup.page",.*|user_pref("browser.startup.page", 1);|' "$user_js"
  else
    printf 'user_pref("browser.startup.page", 1);\n' >> "$user_js"
  fi

  info "Firefox homepage set to $FIREFOX_HOMEPAGE_URL"
}

# ── Parse flags ───────────────────────────────────────────────────────────────
RUN_TELEGRAM=false
RUN_SIGNAL=false
RUN_TAILSCALE=false
RUN_FIREFOX_HOME=false

if [ $# -eq 0 ]; then
  RUN_TELEGRAM=true
  RUN_SIGNAL=true
  RUN_TAILSCALE=true
  RUN_FIREFOX_HOME=true
else
  for arg in "$@"; do
    case "$arg" in
      --telegram)  RUN_TELEGRAM=true ;;
      --signal)    RUN_SIGNAL=true ;;
      --tailscale) RUN_TAILSCALE=true ;;
      --firefox-home) RUN_FIREFOX_HOME=true ;;
      *) echo "Unknown flag: $arg"; echo "Usage: $0 [--telegram] [--signal] [--tailscale] [--firefox-home]"; exit 1 ;;
    esac
  done
fi

# ── Run scripts ───────────────────────────────────────────────────────────────
if $RUN_TELEGRAM; then
  section "Telegram Bot"
  bash "$REPO_DIR/setup/comms/setup-telegram.sh"
fi

if $RUN_SIGNAL; then
  section "Signal Integration"
  bash "$REPO_DIR/setup/comms/setup-signal.sh"
fi

if $RUN_TAILSCALE; then
  section "Tailscale VPN"
  bash "$REPO_DIR/setup/networking/setup-tailscale.sh"
fi

if $RUN_FIREFOX_HOME; then
  section "Firefox Homepage"
  set_firefox_homepage
fi

echo ""
info "07-setup-connectivity.sh complete."
