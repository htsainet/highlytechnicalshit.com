#!/usr/bin/env bash
# Flip the four repo pin sites from 0.0.32 -> 0.0.26.
#
# Does NOT touch DEVIATIONS.md, CONTEXT.md, or the NemoClaw blueprint —
# those need prose edits / a NemoClaw rollback decision.
#
# Uses python literal search/replace (no sed, no regex) so a missing target
# fails loudly instead of silently corrupting the file.
#
# Usage (from repo root):
#   bash update-repo-pins-to-0.0.26.sh

set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/tim/hts/hts-ai-stack}"
cd "$REPO_ROOT"

say() { printf '\n\033[1;36m[repo-pins]\033[0m %s\n' "$*"; }

replace_once() {
  local file="$1" old="$2" new="$3"
  python3 - "$file" "$old" "$new" <<'PY'
import sys, pathlib
path, old, new = sys.argv[1], sys.argv[2], sys.argv[3]
p = pathlib.Path(path)
text = p.read_text()
count = text.count(old)
if count == 0:
    print(f"  SKIP {path}: literal not found: {old!r}", file=sys.stderr)
    sys.exit(2)
if count > 1:
    print(f"  AMBIGUOUS {path}: {count} matches for {old!r} — aborting", file=sys.stderr)
    sys.exit(3)
p.write_text(text.replace(old, new))
print(f"  OK   {path}")
PY
}

say "scripts/lib/common.sh"
replace_once scripts/lib/common.sh '  local max_ver="0.0.32"' '  local max_ver="0.0.26"'
replace_once scripts/lib/common.sh '  local min_ver="0.0.32"' '  local min_ver="0.0.26"'
replace_once scripts/lib/common.sh '# Pin: 0.0.32 (exact) — required by NemoClaw v0.0.23 blueprint.yaml.' \
                                    '# Pin: 0.0.26 (exact) — rolled back from 0.0.32, see DEVIATIONS.md.'

say "scripts/components/nemoclaw/nemoclaw.sh"
# OPENSHELL_VERSION default is already 0.0.26 in your tree — update the comments
replace_once scripts/components/nemoclaw/nemoclaw.sh \
  '# NemoClaw v0.0.23 blueprint enforces min=max=0.0.32.' \
  '# Pinned to 0.0.26 (rolled back from 0.0.32, see DEVIATIONS.md).'
replace_once scripts/components/nemoclaw/nemoclaw.sh \
  '# Updated from 0.0.26 (2026-04-23) — see DEVIATIONS.md → NemoClaw.' \
  '# Reverted to 0.0.26 — see DEVIATIONS.md → NemoClaw.'

say "scripts/utils/upgrade-nemoclaw.sh"
replace_once scripts/utils/upgrade-nemoclaw.sh \
  'OPENSHELL_VERSION="${OPENSHELL_VERSION:-0.0.32}"' \
  'OPENSHELL_VERSION="${OPENSHELL_VERSION:-0.0.26}"'
replace_once scripts/utils/upgrade-nemoclaw.sh \
  '# OPENSHELL_VERSION: pin to 0.0.32 — required by NemoClaw v0.0.23 blueprint.yaml.' \
  '# OPENSHELL_VERSION: pin to 0.0.26 — rolled back from 0.0.32.'
replace_once scripts/utils/upgrade-nemoclaw.sh \
  '# Updated from 0.0.26 (2026-04-23) — see DEVIATIONS.md → NemoClaw.' \
  '# See DEVIATIONS.md → NemoClaw for rollback rationale.'

say "scripts/utils/verify-openshell-pin.sh"
replace_once scripts/utils/verify-openshell-pin.sh 'EXPECTED="0.0.32"' 'EXPECTED="0.0.26"'
# Flip the stale-check so it now warns about lingering 0.0.32 strings
replace_once scripts/utils/verify-openshell-pin.sh \
  '#   3. No stale 0.0.26 defaults remain in the four repo files' \
  '#   3. No stale 0.0.32 defaults remain in the four repo files'
replace_once scripts/utils/verify-openshell-pin.sh \
  '  echo "[FAIL] stale 0.0.26 still present:"' \
  '  echo "[FAIL] stale 0.0.32 still present:"'

say "Done. Remaining manual edits:"
cat <<'EOF'
  • DEVIATIONS.md              — add a rollback entry under NemoClaw
  • scripts/components/nemoclaw/CONTEXT.md (lines ~113-114) — update "Current pin"
  • ~/.nemoclaw/blueprint.yaml — only if NOT rolling NemoClaw back to a
                                  version whose blueprint already allows 0.0.26
EOF

# Sanity: any remaining literal 0.0.32 in those four files?
say "Sweep for leftover 0.0.32 in the four pin files:"
grep -nH '0\.0\.32' \
  scripts/lib/common.sh \
  scripts/components/nemoclaw/nemoclaw.sh \
  scripts/utils/upgrade-nemoclaw.sh \
  scripts/utils/verify-openshell-pin.sh \
  2>/dev/null || echo "  (none — clean)"
