# NAT Optimizer Configuration (PoC)

This document holds a minimal, safe skeleton for configuring the NeMo Agent Toolkit optimizer for the NAT PoC.

Goals

- Provide parameter ranges for numeric tuning (learning rate, temperature, top_p, etc.)
- Define evaluation metric and evaluation workflow to drive optimization
- Keep configs reproducible and auditable

Security

- Do not store secrets in these files. Use environment variables or secrets manager.
- Keep model artifacts off public registries unless provenance is verified.

Example optimizer config (see scripts/components/nat-optimizer-config.yml for YAML form)

Next steps

- Wire this config into a nat eval job (nat eval) and run optimizer with a small evaluation dataset.
- Capture results and produce a small report in `docs/plans/nat-poc-report.md`.
