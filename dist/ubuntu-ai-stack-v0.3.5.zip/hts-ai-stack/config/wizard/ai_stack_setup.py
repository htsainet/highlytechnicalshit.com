#!/usr/bin/env python3
"""
AI Stack Setup Menu
Configures your AI stack and writes config/stack.json in the repo root.
Secrets (tokens, auth keys) are stripped from the committed file and written
separately to config/stack.secrets.json (gitignored).
"""

import json
import os
import shutil
import questionary
from datetime import datetime
from pathlib import Path

# ── Config paths ──────────────────────────────────────────────────────────────
# ai_stack_setup.py lives at:  <repo>/new_sen_sa_tion/stack-config/
# Repo root is two levels up.
_SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT    = (_SCRIPT_DIR / ".." / "..").resolve()
CONFIG_DIR   = REPO_ROOT / "config"
BACKUP_DIR   = CONFIG_DIR / "backups"
STACK_JSON   = CONFIG_DIR / "stack.json"
SECRETS_JSON = CONFIG_DIR / "stack.secrets.json"

# ── Predefined model lists per backend ───────────────────────────────────────

OLLAMA_MODELS = [
    "llama3.2:3b",
    "llama3.1:8b",
    "llama3.1:70b",
    "mistral:7b",
    "mistral-nemo",
    "phi3:mini",
    "phi3:medium",
    "gemma2:9b",
    "gemma2:27b",
    "qwen2.5:7b",
    "deepseek-r1:7b",
    "codellama:13b",
]

BITNET_MODELS = [
    "bitnet-b1.58-2B-4T",
    "bitnet-b1.58-3B",
    "Llama3-8B-1.58-100B-tokens",
    "Falcon3-1B-1.58B",
    "Falcon3-3B-1.58B",
    "Falcon3-7B-1.58B",
]

DOCKER_NETWORK_DETAILS = {
    "Direct bind": {
        "mode": "host",
        "description": "Container uses host network directly. Fastest, least isolated."
    },
    "Single vnet": {
        "mode": "bridge",
        "description": "Containers share a single bridge network. Simple and isolated."
    },
    "Secure vnet": {
        "mode": "custom_bridge",
        "description": "Separate networks per service with firewall rules. Most secure."
    },
}

# ── Styles ────────────────────────────────────────────────────────────────────

STYLE = questionary.Style([
    ("qmark",        "fg:#00bfff bold"),
    ("question",     "bold"),
    ("answer",       "fg:#00ff99 bold"),
    ("pointer",      "fg:#00bfff bold"),
    ("highlighted",  "fg:#00bfff bold"),
    ("selected",     "fg:#00ff99"),
    ("separator",    "fg:#555555"),
    ("instruction",  "fg:#888888"),
])

TOTAL_STEPS = 13

# ── Helpers ───────────────────────────────────────────────────────────────────

def section(step: int, title: str):
    width = 52
    print(f"\n{'─' * width}")
    print(f"  {step} / {TOTAL_STEPS}  ▸  {title}")
    print(f"{'─' * width}")


def print_banner():
    print("""
╔══════════════════════════════════════════════════╗
║          AI STACK SETUP CONFIGURATOR             ║
║          Ubuntu AI Environment Builder           ║
╚══════════════════════════════════════════════════╝
""")


# ── Menu Steps ────────────────────────────────────────────────────────────────

def choose_backend() -> str:
    section(1, "Backend Engine")
    return questionary.select(
        "Choose your inference backend:",
        choices=[
            questionary.Choice("Ollama  — Easy setup, broad model support", value="ollama"),
            questionary.Choice("BitNet  — 1-bit quantised, ultra low memory", value="bitnet"),
        ],
        style=STYLE,
    ).ask()


def choose_model(backend: str) -> str:
    section(2, "Default Model")
    models = OLLAMA_MODELS if backend == "ollama" else BITNET_MODELS
    return questionary.select(
        f"Select default model for {backend.title()}:",
        choices=models,
        style=STYLE,
    ).ask()


def choose_instances() -> dict:
    section(3, "Deployment Instances")
    mode = questionary.select(
        "Instance topology:",
        choices=[
            questionary.Choice("Single         — One instance, simple setup",        value="single"),
            questionary.Choice("Prod / Test    — Separate production & test stacks", value="prod_test"),
        ],
        style=STYLE,
    ).ask()

    config = {"mode": mode}

    if mode == "prod_test":
        config["prod_port"] = questionary.text(
            "Production API port:", default="11434", style=STYLE
        ).ask()
        config["test_port"] = questionary.text(
            "Test API port:", default="11435", style=STYLE
        ).ask()

    return config


def choose_model_cache() -> dict:
    section(4, "Model Cache")
    cache = questionary.select(
        "Model cache location:",
        choices=[
            questionary.Choice("None     — No caching, pull on demand",       value="none"),
            questionary.Choice("Local    — Cache on this machine's disk",     value="local"),
            questionary.Choice("Network  — Shared network cache (NFS / SMB)", value="network"),
        ],
        style=STYLE,
    ).ask()

    config = {"type": cache}

    if cache == "local":
        config["path"] = questionary.text(
            "Local cache path:", default="/opt/ai_models", style=STYLE
        ).ask()
    elif cache == "network":
        config["mount"] = questionary.text(
            "Network share mount point:", default="/mnt/ai_models", style=STYLE
        ).ask()
        config["share_path"] = questionary.text(
            "Share path (e.g. //nas/ai_models or nfs://server/path):",
            style=STYLE,
        ).ask()

    return config


def choose_voice() -> dict:
    section(5, "Voice Support")
    enabled = questionary.confirm(
        "Enable voice input / output?", default=False, style=STYLE
    ).ask()

    config = {"enabled": enabled}

    if enabled:
        config["stt"] = questionary.select(
            "Speech-to-text engine:",
            choices=[
                questionary.Choice("Whisper (local)    — Private, no cloud",   value="whisper"),
                questionary.Choice("Faster-Whisper     — Optimised local STT", value="faster_whisper"),
                questionary.Choice("Vosk (offline)     — Lightweight STT",     value="vosk"),
            ],
            style=STYLE,
        ).ask()

        config["tts"] = questionary.select(
            "Text-to-speech engine:",
            choices=[
                questionary.Choice("Piper   — Fast local neural TTS",   value="piper"),
                questionary.Choice("Coqui   — High quality local TTS",  value="coqui"),
                questionary.Choice("espeak  — Lightweight, robotic",     value="espeak"),
            ],
            style=STYLE,
        ).ask()

        config["wake_word"] = questionary.confirm(
            "Enable wake-word detection?", default=False, style=STYLE
        ).ask()

    return config


def choose_images() -> dict:
    section(6, "Image Generation")
    enabled = questionary.confirm(
        "Enable image generation?", default=False, style=STYLE
    ).ask()

    config = {"enabled": enabled}

    if enabled:
        config["engine"] = questionary.select(
            "Image generation engine:",
            choices=[
                questionary.Choice("Stable Diffusion  — Full control, GPU heavy", value="stable_diffusion"),
                questionary.Choice("ComfyUI           — Node-based SD pipeline",  value="comfyui"),
                questionary.Choice("InvokeAI          — Polished SD UI",          value="invokeai"),
                questionary.Choice("Fooocus           — Simple SD interface",     value="fooocus"),
            ],
            style=STYLE,
        ).ask()

        config["gpu_layers"] = questionary.select(
            "GPU offload layers:",
            choices=["0 (CPU only)", "16", "32", "48", "All"],
            style=STYLE,
        ).ask()

    return config


def choose_claw3d() -> dict:
    section(7, "Claw3D  (3D Visualisation)")
    enabled = questionary.confirm(
        "Enable Claw3D visualisation engine?", default=False, style=STYLE
    ).ask()

    config = {"enabled": enabled}

    if enabled:
        config["renderer"] = questionary.select(
            "Rendering backend:",
            choices=["OpenGL", "Vulkan", "WebGL (browser)"],
            style=STYLE,
        ).ask()

        config["resolution"] = questionary.select(
            "Default viewport resolution:",
            choices=["1280x720", "1920x1080", "2560x1440", "4K"],
            style=STYLE,
        ).ask()

    return config


def choose_paperclip() -> dict:
    section(8, "Paperclip  (OpenClaw Agent Manager)")
    enabled = questionary.confirm(
        "Enable Paperclip agent manager?", default=True, style=STYLE
    ).ask()

    config = {"enabled": enabled}

    if enabled:
        config["max_agents"] = questionary.select(
            "Max concurrent OpenClaw agents:",
            choices=["2", "4", "8", "16", "32"],
            style=STYLE,
        ).ask()

        config["agent_memory"] = questionary.select(
            "Agent memory backend:",
            choices=["In-memory (fast)", "Redis (persistent)", "SQLite (lightweight)"],
            style=STYLE,
        ).ask()

        config["auto_restart"] = questionary.confirm(
            "Auto-restart failed agents?", default=True, style=STYLE
        ).ask()

    return config


def choose_openspace() -> dict:
    section(9, "OpenSpace  (Agent Skills Framework)")
    enabled = questionary.confirm(
        "Enable OpenSpace self-evolving agent skills?", default=False, style=STYLE
    ).ask()

    config = {"enabled": enabled}

    if enabled:
        config["dashboard"] = questionary.confirm(
            "Enable OpenSpace dashboard?", default=True, style=STYLE
        ).ask()

        config["skill_auto_improve"] = questionary.confirm(
            "Auto-improve skills from execution feedback?", default=True, style=STYLE
        ).ask()

        config["skill_sharing"] = questionary.confirm(
            "Enable skill sharing / community access?", default=False, style=STYLE
        ).ask()

    return config


def choose_docker_network() -> dict:
    section(10, "Docker Network")
    choice = questionary.select(
        "Docker network topology:",
        choices=[
            questionary.Choice("Direct bind  — Host network, fastest",             value="Direct bind"),
            questionary.Choice("Single vnet  — Shared bridge, simple",             value="Single vnet"),
            questionary.Choice("Secure vnet  — Isolated networks, firewall rules", value="Secure vnet"),
        ],
        style=STYLE,
    ).ask()

    details = DOCKER_NETWORK_DETAILS[choice]
    return {"topology": choice, **details}


def choose_comms() -> dict:
    section(11, "Communications  (Bot Integrations)")
    selected = questionary.checkbox(
        "Select communication platforms  [Space to toggle, Enter to confirm]:",
        choices=[
            questionary.Choice("Telegram  — Bot API, lightweight",               value="telegram"),
            questionary.Choice("Signal    — Encrypted messaging via signal-cli", value="signal"),
            questionary.Choice("Discord   — Bot with slash commands",            value="discord"),
        ],
        style=STYLE,
    ).ask() or []

    config = {"platforms": selected, "tokens": {}}

    for platform in selected:
        if platform == "telegram":
            config["tokens"]["telegram_bot_token"] = questionary.text(
                "Telegram bot token (blank to set later):", default="", style=STYLE
            ).ask()
        elif platform == "signal":
            config["tokens"]["signal_phone_number"] = questionary.text(
                "Signal phone number (e.g. +441234567890):", default="", style=STYLE
            ).ask()
        elif platform == "discord":
            config["tokens"]["discord_bot_token"] = questionary.text(
                "Discord bot token (blank to set later):", default="", style=STYLE
            ).ask()

    return config


def choose_admin() -> dict:
    section(12, "Admin & Remote Access")
    selected = questionary.checkbox(
        "Select remote admin tools  [Space to toggle, Enter to confirm]:",
        choices=[
            questionary.Choice("Tailscale   — Zero-config VPN mesh",          value="tailscale"),
            questionary.Choice("xRDP        — Remote desktop (RDP protocol)", value="xrdp"),
            questionary.Choice("SSH Server  — OpenSSH daemon",                value="ssh_server"),
        ],
        style=STYLE,
    ).ask() or []

    config = {"tools": selected}

    if "tailscale" in selected:
        config["tailscale_authkey"] = questionary.text(
            "Tailscale auth key (blank to auth interactively):", default="", style=STYLE
        ).ask()

    if "ssh_server" in selected:
        config["ssh_port"] = questionary.text(
            "SSH port:", default="22", style=STYLE
        ).ask()
        config["ssh_pubkey_only"] = questionary.confirm(
            "Disable password login (pubkey only)?", default=True, style=STYLE
        ).ask()

    if "xrdp" in selected:
        config["xrdp_port"] = questionary.text(
            "RDP port:", default="3389", style=STYLE
        ).ask()

    return config


def choose_extras() -> dict:
    section(13, "Extra Components")
    extras = questionary.checkbox(
        "Select any additional components  [Space to toggle, Enter to confirm]:",
        choices=[
            questionary.Choice("Open WebUI    — Browser chat interface", value="open_webui"),
            questionary.Choice("Prometheus    — Metrics & monitoring",   value="prometheus"),
            questionary.Choice("Grafana       — Dashboards",             value="grafana"),
            questionary.Choice("Nginx proxy   — Reverse proxy / TLS",    value="nginx"),
            questionary.Choice("Portainer     — Docker GUI manager",     value="portainer"),
        ],
        style=STYLE,
    ).ask()
    return {"components": extras or []}


# ── Summary & Save ────────────────────────────────────────────────────────────

def tick(val: bool) -> str:
    return "✓ enabled" if val else "✗ disabled"


def print_summary(cfg: dict):
    print("""
╔══════════════════════════════════════════════════╗
║               CONFIGURATION SUMMARY             ║
╚══════════════════════════════════════════════════╝""")

    print(f"  Backend       : {cfg['backend'].title()}")
    print(f"  Model         : {cfg['model']}")
    print(f"  Instances     : {cfg['instances']['mode']}")
    print(f"  Model cache   : {cfg['model_cache']['type']}")

    v = cfg['voice']
    print(f"  Voice         : {tick(v['enabled'])}", end="")
    if v['enabled']:
        print(f"  [STT: {v['stt']} / TTS: {v['tts']}]", end="")
    print()

    img = cfg['images']
    print(f"  Images        : {tick(img['enabled'])}", end="")
    if img['enabled']:
        print(f"  [{img['engine']}]", end="")
    print()

    c3 = cfg['claw3d']
    print(f"  Claw3D        : {tick(c3['enabled'])}", end="")
    if c3['enabled']:
        print(f"  [{c3['renderer']} / {c3['resolution']}]", end="")
    print()

    pp = cfg['paperclip']
    print(f"  Paperclip     : {tick(pp['enabled'])}", end="")
    if pp['enabled']:
        print(f"  [{pp['max_agents']} agents / {pp['agent_memory']}]", end="")
    print()

    os = cfg['openspace']
    print(f"  OpenSpace     : {tick(os['enabled'])}", end="")
    if os['enabled']:
        dashboard = "with dashboard" if os.get('dashboard') else "server only"
        print(f"  [{dashboard}]", end="")
    print()

    print(f"  Docker net    : {cfg['network']['topology']}  ({cfg['network']['mode']})")

    comms = cfg['comms']['platforms']
    print(f"  Comms         : {', '.join(comms) if comms else 'none'}")

    admin = cfg['admin']['tools']
    print(f"  Admin         : {', '.join(admin) if admin else 'none'}")

    extras = cfg['extras']['components']
    print(f"  Extras        : {', '.join(extras) if extras else 'none'}")
    print()


def save_config(cfg: dict) -> tuple[Path, Path | None]:
    """
    Saves config to config/stack.json (secrets stripped).
    If tokens exist, saves them to config/stack.secrets.json (gitignored).
    Backs up the previous stack.json to config/backups/YYYYMMDD-HHMMSS/ first.
    Returns (stack_json_path, secrets_json_path_or_None).
    """
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)

    # ── Backup existing stack.json ─────────────────────────────────────────────
    if STACK_JSON.exists():
        backup_slot = BACKUP_DIR / timestamp
        backup_slot.mkdir(parents=True, exist_ok=True)
        shutil.copy2(STACK_JSON, backup_slot / "stack.json")
        # Backup .env too if present (as .env.bak — gitignored)
        env_file = REPO_ROOT / ".env"
        if env_file.exists():
            shutil.copy2(env_file, backup_slot / ".env.bak")

    # ── Extract secrets into a separate dict ───────────────────────────────────
    import copy
    clean = copy.deepcopy(cfg)
    secrets: dict = {}

    comms_tokens = clean.get("comms", {}).get("tokens", {})
    if any(comms_tokens.values()):
        secrets["comms_tokens"] = comms_tokens
    # Always strip token values from the clean copy
    for key in comms_tokens:
        comms_tokens[key] = ""

    admin = clean.get("admin", {})
    ts_key = admin.pop("tailscale_authkey", "")
    if ts_key:
        secrets["tailscale_authkey"] = ts_key

    # ── Add metadata ───────────────────────────────────────────────────────────
    clean["_meta"] = {
        "format_version": "1",
        "saved_at": timestamp,
        "note": "Secrets/tokens are never stored here — see stack.secrets.json or .env.",
    }

    # ── Write canonical config ─────────────────────────────────────────────────
    with open(STACK_JSON, "w") as f:
        json.dump(clean, f, indent=2)

    # ── Write secrets (gitignored) if any ─────────────────────────────────────
    secrets_path = None
    if secrets:
        secrets["_meta"] = {"saved_at": timestamp}
        with open(SECRETS_JSON, "w") as f:
            json.dump(secrets, f, indent=2)
        os.chmod(SECRETS_JSON, 0o600)
        secrets_path = SECRETS_JSON

    return STACK_JSON, secrets_path


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    print_banner()
    print("  Use arrow keys to navigate, Enter to select.\n")

    try:
        backend     = choose_backend()
        model       = choose_model(backend)
        instances   = choose_instances()
        model_cache = choose_model_cache()
        voice       = choose_voice()
        images      = choose_images()
        claw3d      = choose_claw3d()
        paperclip   = choose_paperclip()
        openspace   = choose_openspace()
        network     = choose_docker_network()
        comms       = choose_comms()
        admin       = choose_admin()
        extras      = choose_extras()

        config = {
            "generated_at" : datetime.now().isoformat(),
            "backend"      : backend,
            "model"        : model,
            "instances"    : instances,
            "model_cache"  : model_cache,
            "voice"        : voice,
            "images"       : images,
            "claw3d"       : claw3d,
            "paperclip"    : paperclip,
            "openspace"    : openspace,
            "network"      : network,
            "comms"        : comms,
            "admin"        : admin,
            "extras"       : extras,
        }

        print_summary(config)

        confirm = questionary.confirm(
            "Save this configuration to JSON?",
            default=True,
            style=STYLE,
        ).ask()

        if confirm:
            stack_path, secrets_path = save_config(config)
            print(f"  ✓ Config saved  → {stack_path}")
            if secrets_path:
                print(f"  ✓ Secrets saved → {secrets_path}  (gitignored)")
            print(f"  ✓ Backup stored → {BACKUP_DIR / config.get('_meta', {}).get('saved_at', 'latest')}")
            print()
        else:
            print("  Config not saved.\n")

    except KeyboardInterrupt:
        print("\n\n  Setup cancelled.\n")


if __name__ == "__main__":
    main()
