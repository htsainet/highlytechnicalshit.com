#!/usr/bin/env bash
# scripts/components/nemoclaw/nemoclaw.sh — NemoClaw sandbox: install, onboard, configure
#
# Standalone usage:
#   ./scripts/components/nemoclaw/nemoclaw.sh                # full: install + onboard + health
#   ./scripts/components/nemoclaw/nemoclaw.sh --install      # install only
#   ./scripts/components/nemoclaw/nemoclaw.sh --configure    # cgroup v2 + registry + provider config
#   ./scripts/components/nemoclaw/nemoclaw.sh --start        # install + start sandboxes + forwards + tokens
#   ./scripts/components/nemoclaw/nemoclaw.sh --stop         # destroy all sandboxes
#   ./scripts/components/nemoclaw/nemoclaw.sh --restart      # restart (stop + start)
#   ./scripts/components/nemoclaw/nemoclaw.sh --status       # show status + health
#   ./scripts/components/nemoclaw/nemoclaw.sh --restart-forward  # vendor-doc port-forward restart (NVIDIA quickstart §"Restart the Port Forward")
#   ./scripts/components/nemoclaw/nemoclaw.sh --destroy      # destroy all sandboxes + remove boot unit
#   ./scripts/components/nemoclaw/nemoclaw.sh --onboard      # onboard sandboxes only
#   ./scripts/components/nemoclaw/nemoclaw.sh --tokens       # extract dashboard tokens
#   ./scripts/components/nemoclaw/nemoclaw.sh --rotate-token # invalidate current token, mint new one, refresh tokens file
#   ./scripts/components/nemoclaw/nemoclaw.sh --diagnose-chat # collect chat-hang diagnostic bundle (read-only)
#   ./scripts/components/nemoclaw/nemoclaw.sh --update                # update OpenClaw inside sandboxes
#   ./scripts/components/nemoclaw/nemoclaw.sh --backup-premigration   # one-time pre-migration workspace backup
#   ./scripts/components/nemoclaw/nemoclaw.sh --recreate-gateway      # force-recreate gateway (cures version-mismatch wedges)
#   ./scripts/components/nemoclaw/nemoclaw.sh --cleanup               # remove host artifacts (systemd / sysctl / UFW), preserve sandbox
#
# For lifecycle ops not listed above, use the vendor CLI directly per
# NVIDIA's NemoClaw documentation:
#   nemoclaw status                          — gateway-wide status
#   nemoclaw <sandbox> status                — sandbox status + inference health
#   nemoclaw <sandbox> logs --follow         — sandbox logs
#   nemoclaw <sandbox> restart               — restart sandbox (clears auth lockout)
#   nemoclaw debug --sandbox <sandbox>       — diagnostics bundle
#   nemoclaw list                            — list registered sandboxes
# Docs: https://docs.nvidia.com/nemoclaw/latest/get-started/quickstart.html
#
# Can also be sourced by bundle scripts for individual function access.
#
# NEMOCLAW_EXPERIMENTAL=1 is required for local-model workflows.
# Without it, NemoClaw only supports NVIDIA NIM hosted models.
# This flag enables custom provider endpoints (local Ollama / llama-swap),
# non-interactive onboard, and sandbox recreation.  See ISSUE-033.
set -euo pipefail

# Help short-circuit: print the header usage block and exit BEFORE sourcing
# libs, loading .env, or running any preflight side effects (sudo prompt,
# inotify check, jq manifest read). Must come before lib sourcing so that
# `--help` works even on hosts without jq installed.
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  for _arg in "$@"; do
    case "$_arg" in
      --help|-h)
        # Print header usage block (lines 2-29) using pure bash — no sed/awk.
        _line_no=0
        while IFS= read -r _line; do
          _line_no=$((_line_no + 1))
          (( _line_no < 2 )) && continue
          (( _line_no > 29 )) && break
          # Strip leading "# " or "#"
          if [[ "$_line" == "# "* ]]; then
            printf '%s\n' "${_line#\# }"
          elif [[ "$_line" == "#"* ]]; then
            printf '%s\n' "${_line#\#}"
          else
            printf '%s\n' "$_line"
          fi
        done < "${BASH_SOURCE[0]}"
        unset _line _line_no
        exit 0
        ;;
    esac
  done
  unset _arg
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/assert-postcondition.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
NEMOCLAW_ENABLED="${NEMOCLAW_ENABLED:-true}"
NEMOCLAW_AUTO_UPDATE="${NEMOCLAW_AUTO_UPDATE:-false}"
NEMOCLAW_MODEL="${NEMOCLAW_MODEL:-mistral-nemo:latest}"
# Gateway route timeout (seconds) for streams from sandbox → llama-swap.
# Default OpenShell value is 60s; mid-size GPU model cold loads via Ollama
# can exceed that, so first-prompt streams get killed before the first token.
# NemoClaw's CLI does not expose this knob — see DEVIATIONS.md → NemoClaw.
NEMOCLAW_INFERENCE_TIMEOUT="${NEMOCLAW_INFERENCE_TIMEOUT:-300}"
NEMOCLAW_GATEWAY_NAME="nemoclaw"
NEMOCLAW_GATEWAY_PORT="${NEMOCLAW_GATEWAY_PORT:-8084}"
NEMOCLAW_SANDBOX_NAME="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"
# OPENSHELL_VERSION: canonical value is in nemoclaw.manifest.json
# upstream.openshell_pinned_version. See DEVIATIONS.md → NemoClaw.
OPENSHELL_VERSION="${OPENSHELL_VERSION:-$(jq -r '.upstream.openshell_pinned_version' \
  "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.manifest.json" 2>/dev/null)}"
[[ -z "$OPENSHELL_VERSION" || "$OPENSHELL_VERSION" == "null" ]] && {
  echo "FATAL: could not read openshell_pinned_version from nemoclaw.manifest.json" >&2
  exit 1
}
LLAMA_SWAP_HOST_URL="http://host.openshell.internal:${LLAMA_SWAP_PORT:-8081}/v1"

# ── Internal helpers ─────────────────────────────────────────────────────────

# _warm_llamaswap_model — block until the given model is loaded in Ollama
# (via llama-swap) so subsequent calls — including OpenShell's verify probe
# during `inference set` — don't trip its short internal timeout on cold load.
#
# Idempotent: a no-op if the model is already hot. Non-fatal: returns 0 even
# on warm-up failure so callers can continue (the verify call will surface
# the real error if the endpoint is genuinely broken).
_warm_llamaswap_model() {
  local model="${1:-${NEMOCLAW_MODEL}}"
  local swap_port="${LLAMA_SWAP_PORT:-8081}"

  info "Warming up model '${model}' via llama-swap (may take ~60-120 s on cold start)..."
  python3 -c "
import urllib.request, json, sys
api_key = '${COMPATIBLE_API_KEY:-not-needed}'
req = urllib.request.Request(
    'http://localhost:${swap_port}/v1/chat/completions',
    data=json.dumps({
        'model': '${model}',
        'messages': [{'role': 'user', 'content': 'hi'}],
        'max_tokens': 1,
        'stream': False
    }).encode(),
    headers={
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {api_key}'
    }
)
try:
    r = urllib.request.urlopen(req, timeout=180)
    sys.exit(0 if r.status < 500 else 1)
except Exception as e:
    print(f'Warm-up warning: {e}', file=sys.stderr)
    sys.exit(0)  # Non-fatal — let caller attempt the next step anyway
" 2>&1 && info "Model warm-up complete." || warn "Warm-up inconclusive — proceeding."
  return 0
}

_ensure_sudo() {
  if sudo -n true 2>/dev/null; then return 0; fi
  info "Administrator privileges required."
  sudo -v || { fail "Sudo authentication failed."; exit 1; }
}

# _preflight_required_tools — Verify host has the binaries nemoclaw_install
# transitively depends on (timeout for onboard, python3/curl for sandbox-side
# fixes and dashboard probe, docker for gateway/sandbox lifecycle, jq for
# manifest reads). Called from nemoclaw_install only — read-only paths like
# --status / --tokens skip this and give clearer per-call errors.
# UFW is intentionally NOT in this list; _setup_ufw apt-installs it on demand.
_preflight_required_tools() {
  local missing=()
  local cmd
  for cmd in timeout python3 curl docker jq; do
    command -v "$cmd" >/dev/null 2>&1 || missing+=("$cmd")
  done
  if (( ${#missing[@]} > 0 )); then
    fail "Required command(s) not found in PATH: ${missing[*]}"
    fail "Install them before running nemoclaw_install."
    exit 1
  fi
}

# _check_experimental_flag_supported — Soft guard against future NemoClaw
# releases that may drop NEMOCLAW_EXPERIMENTAL. We pass it on every install
# (line ~1221) per the v0.0.21–v0.0.29 quickstart. If a future bump renames
# or removes the flag, the install will silently use a different default —
# this warn fires to make that drift visible at upgrade time.
# Best-effort only; never fails the install.
_check_experimental_flag_supported() {
  if ! command -v nemoclaw >/dev/null 2>&1; then return 0; fi
  local installed_ver
  installed_ver=$(nemoclaw --version 2>/dev/null | grep -oE 'v?[0-9]+\.[0-9]+\.[0-9]+' | head -1 || true)
  # Probe the help / env output for the flag name. Two channels: --help text,
  # and the install script's source if reachable. We accept either.
  local seen=0
  if nemoclaw --help 2>&1 | grep -qi 'EXPERIMENTAL'; then seen=1; fi
  if [[ $seen -eq 0 ]] && [[ -d "$HOME/.nemoclaw/source" ]]; then
    grep -rqI 'NEMOCLAW_EXPERIMENTAL' "$HOME/.nemoclaw/source" 2>/dev/null && seen=1
  fi
  if [[ $seen -eq 0 ]]; then
    warn "Installed NemoClaw (${installed_ver:-unknown}) does not appear to recognize NEMOCLAW_EXPERIMENTAL."
    warn "  The install passed it anyway — verify the pin in nemoclaw.manifest.json"
    warn "  and the install path in DEVIATIONS.md before relying on local-model behavior."
  fi
}

# Back up sandbox workspace before destructive operations.
# Uses nemoclaw snapshot create (preferred) or openshell download (fallback).
# Per NVIDIA docs, the installer calls backup-all automatically before upgrades;
# we mirror that practice for our lifecycle operations.
_backup_sandbox() {
  local sandbox="$1"

  # Preferred: nemoclaw CLI snapshot (preserves full workspace state)
  if command -v nemoclaw &>/dev/null; then
    if nemoclaw "$sandbox" snapshot create 2>/dev/null; then
      ok "Snapshot created for '${sandbox}'."
      return 0
    fi
    warn "nemoclaw snapshot create failed — falling back to openshell download."
  fi

  # Fallback: download critical workspace files via openshell
  if ! command -v openshell &>/dev/null; then return 1; fi
  if ! openshell sandbox get "$sandbox" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null 2>&1; then
    return 1
  fi

  local backup_dir="$REPO_DIR/logs/nemoclaw-backups/${sandbox}/$(date +%Y%m%dT%H%M%S)"
  mkdir -p "$backup_dir"
  local files=(
    ".openclaw/openclaw.json"
    ".openclaw-data/SOUL.md"
    ".openclaw-data/USER.md"
    ".openclaw-data/IDENTITY.md"
    ".openclaw-data/AGENTS.md"
    ".openclaw-data/MEMORY.md"
  )
  local count=0
  for f in "${files[@]}"; do
    if openshell sandbox download -g "$NEMOCLAW_GATEWAY_NAME" "$sandbox" \
         "/sandbox/$f" "$backup_dir/" 2>/dev/null; then
      count=$((count + 1))
    fi
  done
  info "Workspace backed up (${count} files) → ${backup_dir}"
}

# nemoclaw_backup_premigration — One-time workspace backup before the
# Option A architecture flip.
#
# The current sandbox was created by the inverted architecture and is NOT
# registered in ~/.nemoclaw/sandboxes.json. 'nemoclaw backup-all' silently
# skips it. This function uses 'openshell sandbox download' to copy workspace
# files to logs/nemoclaw-backups/ before the flip recreates the sandbox.
#
# Run ONCE before nemoclaw_install: ./nemoclaw.sh --backup-premigration
nemoclaw_backup_premigration() {
  step "NemoClaw — pre-migration backup"

  if ! command -v openshell &>/dev/null; then
    fail "openshell CLI not found — cannot backup without it."
    return 1
  fi

  local sandbox="$NEMOCLAW_SANDBOX_NAME"
  if ! openshell sandbox get "$sandbox" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null 2>&1; then
    warn "Sandbox '${sandbox}' not found — nothing to backup."
    return 0
  fi

  local backup_dir="$REPO_DIR/logs/nemoclaw-backups/premigration-$(date +%Y%m%dT%H%M%S)"
  mkdir -p "$backup_dir"
  info "Backing up '${sandbox}' workspace → ${backup_dir}"

  local files=(
    ".openclaw/openclaw.json"
    ".openclaw-data/SOUL.md"
    ".openclaw-data/USER.md"
    ".openclaw-data/IDENTITY.md"
    ".openclaw-data/AGENTS.md"
    ".openclaw-data/MEMORY.md"
  )
  local count=0 failed=0
  for f in "${files[@]}"; do
    local dest="$backup_dir/$(basename "$f")"
    if openshell sandbox download -g "$NEMOCLAW_GATEWAY_NAME" "$sandbox" \
         "/sandbox/$f" "$backup_dir/" 2>/dev/null; then
      if [[ -s "$dest" ]]; then
        count=$((count + 1))
      else
        warn "Downloaded but empty: ${f}"
        failed=$((failed + 1))
      fi
    else
      warn "Could not download: ${f}"
      failed=$((failed + 1))
    fi
  done

  # Snapshot full directories (openshell sandbox download supports directories)
  openshell sandbox download -g "$NEMOCLAW_GATEWAY_NAME" "$sandbox" \
    "/sandbox/.openclaw" "$backup_dir/openclaw-dir/" 2>/dev/null \
    && info "Full .openclaw/ directory backed up." \
    || warn "Full .openclaw/ directory backup failed (may not exist)."

  openshell sandbox download -g "$NEMOCLAW_GATEWAY_NAME" "$sandbox" \
    "/sandbox/.openclaw-data" "$backup_dir/openclaw-data-dir/" 2>/dev/null \
    && info "Full .openclaw-data/ directory backed up." \
    || warn "Full .openclaw-data/ directory backup failed (may not exist)."

  echo ""
  ok "Pre-migration backup complete: ${count} files saved (${failed} skipped)"
  info "Backup location: ${backup_dir}"
  info "To restore after onboard:"
  info "  openshell sandbox upload -g <gateway> <sandbox> <local-file> /sandbox/<path>"
}

_check_sandbox_health() {
  local sandbox="$1"
  if ! command -v openshell &>/dev/null; then
    echo "    Phase : unknown (openshell not installed)"
    return 1
  fi
  local sandbox_out phase
  sandbox_out=$(openshell sandbox get "$sandbox" -g "$NEMOCLAW_GATEWAY_NAME" 2>/dev/null || true)
  phase=$(echo "$sandbox_out" | grep "Phase:" | grep -oE '[A-Za-z]+$' | head -1 || true)

  echo -e "    Phase : ${phase:-unknown}"

  [[ "${phase:-}" == "Ready" ]]
}

_ensure_nemoclaw_model_ready() {
  local model="${1:-$NEMOCLAW_MODEL}"

  if [[ -f "$REPO_DIR/scripts/components/ollama/ollama.sh" ]]; then
    # Run the Ollama ensure step in background so the pull can progress while we wait.
    (
      source "$REPO_DIR/scripts/components/ollama/ollama.sh"
      export OLLAMA_MODEL="$model"
      ollama_ensure_models
    ) &
    local ensure_pid=$!
    # Poll the API until the model appears, printing a progress line every 5 s.
    while kill -0 "$ensure_pid" 2>/dev/null; do
      if curl -s "${OLLAMA_BASE_URL}/api/tags" | jq -r '.models[].name' | grep -qxF "$model"; then
        break
      fi
      info "Waiting for model '${model}' to be pulled…"
      sleep 5
    done
    wait "$ensure_pid" || fail "Pre-flight failed: NemoClaw model '${model}' not ready in Ollama."
  fi
}

_do_onboard() {
  local sandbox="$1" model="$2"
  local recreate="${3:-false}"
  local fresh="${4:-${NEMOCLAW_FRESH:-false}}"
  local timeout_sec="${NEMOCLAW_ONBOARD_TIMEOUT:-600}"
  local log_file="$REPO_DIR/logs/nemoclaw-gateway-${sandbox}.log"
  mkdir -p "$REPO_DIR/logs"

  # Pre-flight: make sure the Ollama model this sandbox will route to is
  # actually pulled before we ask NemoClaw to validate the endpoint.
  # Belt-and-suspenders with Task 4's converge-wired ollama_ensure_models;
  # cheap when the model is already present (no-op /api/tags check).
  _ensure_nemoclaw_model_ready "$model"

  # Pre-flight: verify llama-swap is reachable before attempting onboard
  local swap_port="${LLAMA_SWAP_PORT:-8081}"
  local max_attempts=10
  local attempt=0
  local swap_ok=false
  while [[ $attempt -lt $max_attempts ]]; do
    attempt=$((attempt + 1))
    if python3 -c "
import urllib.request, sys
try:
    r = urllib.request.urlopen('http://localhost:${swap_port}/health', timeout=5)
    sys.exit(0 if r.status < 500 else 1)
except Exception:
    sys.exit(1)
" 2>/dev/null; then
      swap_ok=true
      break
    fi
    if [[ $attempt -lt $max_attempts ]]; then
      info "llama-swap (:${swap_port}) not ready — retry ${attempt}/${max_attempts} (waiting 10s)..."
      sleep 10
    fi
  done
  if [[ "$swap_ok" != "true" ]]; then
    fail "Pre-flight failed: llama-swap (:${swap_port}) is unreachable after ${max_attempts} attempts — cannot onboard '${sandbox}'."
    return 1
  fi

  info "Onboarding sandbox: ${sandbox} (model: ${model} via llama-swap)..."

  # Pre-flight: warm up the model so NemoClaw's 15 s validation doesn't time out.
  _warm_llamaswap_model "$model"

  # Use localhost for the onboard URL so the NemoClaw CLI can validate the
  # endpoint from the host (host.openshell.internal only resolves inside
  # Docker containers). After onboard, _setup_provider() updates the
  # provider to use host.openshell.internal for in-sandbox access.
  local onboard_url="http://localhost:${swap_port}/v1"

  info "Onboarding sandbox '${sandbox}' — up to ${timeout_sec}s, progress streams to ${log_file}..."
  _run_onboard_cmd "$sandbox" "$onboard_url" "$model" "$timeout_sec" "$log_file" "$recreate" "$fresh"
  local rc=$?

  if [[ "$rc" -ne 0 ]]; then
    # Auto-recover from a stale "Previous onboarding session failed" marker by
    # retrying with --fresh. Upstream surfaces this only on stderr, which we
    # capture into $log_file.
    if [[ "$fresh" != "true" ]] \
       && grep -q "Previous onboarding session" "$log_file" 2>/dev/null; then
      warn "Detected stale onboarding session for '${sandbox}' — retrying with --fresh (300s)..."
      fresh="true"
      _run_onboard_cmd "$sandbox" "$onboard_url" "$model" 300 "$log_file" "$recreate" "$fresh"
      rc=$?
    # Auto-recover from a wire-incompatible gateway left over from an older
    # openshell version (symptom: "transport error" / "Connection reset by
    # peer (os error 104)" against the gateway API). Force-recreate the
    # gateway containers, then retry with --fresh.
    elif grep -qE 'transport error|Connection reset by peer' "$log_file" 2>/dev/null; then
      warn "Gateway transport error detected for '${sandbox}' — likely an openshell version mismatch."
      warn "Force-recreating gateway containers and retrying with --fresh (600s)..."
      _force_recreate_gateway
      fresh="true"
      _run_onboard_cmd "$sandbox" "$onboard_url" "$model" 600 "$log_file" "$recreate" "$fresh"
      rc=$?
    elif [[ "$rc" -eq 124 ]]; then
      warn "Onboard timed out after ${timeout_sec}s for '${sandbox}' — retrying (300s)..."
      _run_onboard_cmd "$sandbox" "$onboard_url" "$model" 300 "$log_file" "$recreate" "$fresh"
      rc=$?
    else
      warn "Onboard failed (exit ${rc}) for '${sandbox}' — retrying (300s)..."
      _run_onboard_cmd "$sandbox" "$onboard_url" "$model" 300 "$log_file" "$recreate" "$fresh"
      rc=$?
    fi
  fi

  if [[ "$rc" -eq 124 ]]; then
    fail "Onboard timed out for '${sandbox}' after retry. See log: ${log_file}"
    return 1
  elif [[ "$rc" -ne 0 ]]; then
    fail "Onboard failed (exit ${rc}) for '${sandbox}' after retry. See log: ${log_file}"
    return 1
  fi
  ok "Sandbox '${sandbox}' onboarded."
}

# Run the nemoclaw onboard command on the HOST with timeout, capturing stderr to log.
# Separated from _do_onboard to enable retry without duplicating the command.
_run_onboard_cmd() {
  local sandbox="$1" onboard_url="$2" model="$3" timeout_sec="$4" log_file="$5"
  local recreate="${6:-false}"
  local fresh="${7:-false}"
  echo "--- $(date -Iseconds) onboard attempt (timeout=${timeout_sec}s, recreate=${recreate}, fresh=${fresh}) ---" >> "$log_file"

  # B1: Pass NEMOCLAW_GATEWAY_NAME — upstream may hardcode "nemoclaw" as the
  # gateway name; this env var is a best-effort override. If ignored, smoke
  # test 1 will reveal it. See REFERENCES.md § Gateway Name Risk.
  local env_args=(
    NEMOCLAW_EXPERIMENTAL=1
    NEMOCLAW_ACCEPT_THIRD_PARTY_SOFTWARE=1
    NEMOCLAW_SANDBOX_NAME="$sandbox"
    NEMOCLAW_GATEWAY_NAME="$NEMOCLAW_GATEWAY_NAME"
    NEMOCLAW_PROVIDER="custom"
    NEMOCLAW_ENDPOINT_URL="$onboard_url"
    COMPATIBLE_API_KEY="not-needed"
    NEMOCLAW_MODEL="$model"
    NEMOCLAW_POLICY_TIER="balanced"
    # NB: do NOT add the `local-inference` preset. It enforces a 60 s ceiling
    # on connections to `inference.local:443`, which kills any streaming chat
    # at exactly T+60s with NET:FAIL [LOW]. The pre-d4c892b config (these four
    # presets) worked because llama-swap is reached through `compatible-endpoint`
    # → `host.openshell.internal:8081` (rewritten by `_setup_provider()`),
    # which the gateway forwards on behalf of `inference.local` without the
    # streaming throttle the `local-inference` preset adds.
    NEMOCLAW_POLICY_PRESETS="npm,pypi,telegram,huggingface"
  )
  [[ "$recreate" == "true" ]] && env_args+=(NEMOCLAW_RECREATE_SANDBOX=1)

  # NemoClaw's --fresh flag discards a "Previous onboarding session failed"
  # marker on disk so onboarding can re-start from step [1/8]. Used both by
  # the dispatcher's --onboard-fresh action and by _do_onboard's auto-recovery.
  local cmd_args=(--non-interactive)
  [[ "$fresh" == "true" ]] && cmd_args+=(--fresh)

  timeout "${timeout_sec}" env "${env_args[@]}" \
    nemoclaw onboard "${cmd_args[@]}" </dev/null 2>>"$log_file"
  return $?
}

# Run a command inside a sandbox via SSH (non-interactive, returns stdout).
_sandbox_ssh() {
  local sandbox="$1"; shift
  local openshell_bin
  openshell_bin=$(command -v openshell)
  ssh -o StrictHostKeyChecking=no \
      -o UserKnownHostsFile=/dev/null \
      -o GlobalKnownHostsFile=/dev/null \
      -o LogLevel=ERROR \
      -o "ProxyCommand=$openshell_bin ssh-proxy --gateway-name $NEMOCLAW_GATEWAY_NAME --name $sandbox" \
      "sandbox@openshell-$sandbox" "$@"
}

# Start a Python TCP relay inside a sandbox (listen_port → target_port).
# openshell forward maps host:PORT → sandbox:PORT (same port), so when the
# dashboard host port differs from the sandbox's internal service port we need
# a lightweight relay inside the sandbox.
#
# The relay runs under a supervisor loop that automatically restarts it on
# crash (max 10 retries, 2-second backoff). This fixes ISSUE-034 where the
# bare nohup relay would die silently, leaving the CPU sandbox unreachable.
# Extract NemoClaw auth tokens and write a JSON sidecar for the dashboard.
_extract_dashboard_tokens() {
  if ! command -v openshell &>/dev/null; then return 0; fi

  local token_file="$REPO_DIR/resources/dashboard/nemoclaw-tokens.json"
  local tmpdir
  tmpdir=$(mktemp -d)

  declare -A sandbox_ports=(
    ["hts-ai-openshell-nemoclaw"]=18789
  )

  local json="{"
  local first=true
  for sandbox in "${!sandbox_ports[@]}"; do
    local port="${sandbox_ports[$sandbox]}"
    openshell sandbox get "$sandbox" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null || continue

    local dl_dir="$tmpdir/$sandbox"
    mkdir -p "$dl_dir"
    openshell sandbox download -g "$NEMOCLAW_GATEWAY_NAME" "$sandbox" /sandbox/.openclaw/openclaw.json "$dl_dir/" 2>/dev/null || continue

    local token
    token=$(python3 -c "
import json, sys
with open('$dl_dir/openclaw.json') as f:
    d = json.load(f)
print(d.get('gateway',{}).get('auth',{}).get('token',''))
" 2>/dev/null)

    if [[ -n "$token" ]]; then
      [[ "$first" == "true" ]] || json+=","
      json+="\"$sandbox\":{\"port\":$port,\"token\":\"$token\"}"
      first=false
    fi
  done
  json+="}"

  echo "$json" | python3 -m json.tool > "$token_file" 2>/dev/null || echo "$json" > "$token_file"
  rm -rf "$tmpdir"
  info "Dashboard tokens written → $token_file"
  _print_dashboard_url
}

# _print_dashboard_url — Print the live dashboard URL(s) prominently so the
# operator never has to grep through a JSON file. Called at the end of every
# action that writes the tokens file (--start, --onboard, --tokens, --rotate-token).
# Silent (rc 0) if the file is missing or empty — never blocks a flow.
_print_dashboard_url() {
  local token_file="$REPO_DIR/resources/dashboard/nemoclaw-tokens.json"
  [[ -f "$token_file" ]] || return 0
  command -v python3 &>/dev/null || return 0

  local urls
  urls=$(python3 - "$token_file" <<'PY' 2>/dev/null
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(0)
for sb, v in d.items():
    port = v.get("port")
    tok = v.get("token")
    if port and tok:
        print(f"  {sb}:")
        print(f"    http://127.0.0.1:{port}/#token={tok}")
PY
)
  [[ -n "$urls" ]] || return 0

  echo
  echo "──────────────────────────────────────────────────────────────"
  echo "  NemoClaw dashboard — open in a fresh browser tab:"
  echo "$urls"
  echo "──────────────────────────────────────────────────────────────"
  echo
}

# Update OpenClaw / sandbox images.
#
# NVIDIA's documented upgrade paths (preferred → fallback):
#   1. nemoclaw upgrade-sandboxes --auto   (batch, compares image digests)
#   2. nemoclaw <name> rebuild             (per-sandbox, preserves workspace)
#   3. Manual delete + re-onboard          (last resort, loses workspace)
#
# NVIDIA troubleshooting explicitly warns: "Do not run openclaw update inside
# the sandbox." OpenClaw is image-pinned, not updated in place.
#
# After any upgrade, run openclaw doctor --fix for cross-version structure
# repair (per NVIDIA rebuild docs).
_update_openclaw() {
  if ! command -v openshell &>/dev/null; then return 0; fi

  local sandboxes=("hts-ai-openshell-nemoclaw")

  # Path 1: nemoclaw upgrade-sandboxes (official batch upgrade)
  if command -v nemoclaw &>/dev/null; then
    info "Checking for sandbox upgrades via nemoclaw CLI..."
    if NEMOCLAW_GATEWAY_PORT="$NEMOCLAW_GATEWAY_PORT" \
       NEMOCLAW_DASHBOARD_PORT=18789 \
       nemoclaw upgrade-sandboxes --auto --yes 2>&1; then
      # Post-upgrade: openclaw doctor --fix (M6)
      for sandbox in "${sandboxes[@]}"; do
        openshell sandbox exec -g "$NEMOCLAW_GATEWAY_NAME" -n "$sandbox" -- \
          openclaw doctor --fix --non-interactive 2>/dev/null || true
      done
      ok "Sandbox upgrade complete (nemoclaw upgrade-sandboxes)."
      return 0
    fi
    warn "nemoclaw upgrade-sandboxes failed — trying per-sandbox rebuild..."

    # Path 2: nemoclaw <name> rebuild (per-sandbox, preserves workspace)
    for sandbox in "${sandboxes[@]}"; do
      openshell sandbox get "$sandbox" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null 2>&1 || continue
      _backup_sandbox "$sandbox"
      if NEMOCLAW_GATEWAY_PORT="$NEMOCLAW_GATEWAY_PORT" \
         nemoclaw "$sandbox" rebuild --yes 2>&1; then
        openshell sandbox exec -g "$NEMOCLAW_GATEWAY_NAME" -n "$sandbox" -- \
          openclaw doctor --fix --non-interactive 2>/dev/null || true
        ok "Sandbox '${sandbox}' rebuilt."
        continue
      fi
      warn "nemoclaw rebuild failed for '${sandbox}' — falling back to manual recreate."
    done
    return 0
  fi

  warn "nemoclaw CLI not found on host — cannot upgrade sandboxes. Run nemoclaw_install first."
}

# ── Kernel inotify limits (required by k3s inside the OpenShell gateway) ─────
#
# The OpenShell gateway container runs a full k3s cluster. k3s's kubelet and
# cAdvisor use inotify heavily for fsnotify watchers and container metrics; on
# a stock Ubuntu host (max_user_instances=128, max_user_watches=65536) the
# kubelet crashes during "Starting to listen" with
#   "inotify_init: too many open files"
#   "fsnotify watcher: too many open files"
# which surfaces to the user as "× gateway health check reported unhealthy".
#
# NVIDIA's NemoClaw/OpenShell quickstart does not document these limits, so
# this is logged in DEVIATIONS.md. The values mirror the Rancher / k3s
# recommendations for running k3s-in-docker.
# Revisit when NVIDIA adds an equivalent preflight to the installer, or when
# the gateway stops embedding k3s.
_fix_inotify_limits() {
  step "NemoClaw — inotify limits (k3s-in-gateway preflight)"
  _ensure_sudo

  local want_instances=8192
  local want_watches=524288

  local cur_instances cur_watches
  cur_instances=$(cat /proc/sys/fs/inotify/max_user_instances 2>/dev/null || echo 0)
  cur_watches=$(cat /proc/sys/fs/inotify/max_user_watches 2>/dev/null || echo 0)

  local need_persist=0
  if (( cur_instances < want_instances )); then
    info "Raising fs.inotify.max_user_instances: ${cur_instances} → ${want_instances}"
    sudo sysctl -w "fs.inotify.max_user_instances=${want_instances}" >/dev/null
    need_persist=1
  else
    info "fs.inotify.max_user_instances OK (${cur_instances} ≥ ${want_instances})"
  fi
  if (( cur_watches < want_watches )); then
    info "Raising fs.inotify.max_user_watches: ${cur_watches} → ${want_watches}"
    sudo sysctl -w "fs.inotify.max_user_watches=${want_watches}" >/dev/null
    need_persist=1
  else
    info "fs.inotify.max_user_watches OK (${cur_watches} ≥ ${want_watches})"
  fi

  local sysctl_file="/etc/sysctl.d/99-hts-ai-stack-inotify.conf"
  if [[ "$need_persist" -eq 1 ]] || [[ ! -f "$sysctl_file" ]]; then
    info "Persisting inotify limits to ${sysctl_file}"
    sudo tee "$sysctl_file" >/dev/null <<EOF
# Managed by scripts/components/nemoclaw/nemoclaw.sh (_fix_inotify_limits).
# Required for k3s running inside the OpenShell gateway container.
# See DEVIATIONS.md → NemoClaw (inotify preflight).
fs.inotify.max_user_instances = ${want_instances}
fs.inotify.max_user_watches   = ${want_watches}
EOF
  fi
  ok "inotify limits verified."
}

# ── Stale gateway container cleanup ──────────────────────────────────────────
#
# If a previous `openshell gateway start` crashed (e.g. due to an earlier
# inotify failure), the `openshell-cluster-<gateway>` container can be left in
# a restarting state. A subsequent `nemoclaw onboard` / `openshell gateway
# destroy` then fails with:
#   "cannot be forced... image is being used by running container <id>"
#   "Container <id> is restarting, wait until the container is running"
# because `gateway destroy` does not force-remove a restarting container.
# This helper force-removes ONLY containers that are actually stale
# (restarting/exited/dead/created). A `running` container is left alone —
# previously we force-rm'd it unconditionally, which made every --start kill
# a healthy gateway and pay the 30s–2min k3s reboot tax.
_cleanup_stale_gateway_containers() {
  command -v docker &>/dev/null || return 0
  local gw="$NEMOCLAW_GATEWAY_NAME"
  local names=("openshell-cluster-${gw}" "openshell-gateway-${gw}")
  local name status removed=0
  for name in "${names[@]}"; do
    docker inspect "$name" &>/dev/null || continue
    status=$(docker inspect -f '{{.State.Status}}' "$name" 2>/dev/null || echo unknown)
    case "$status" in
      running)
        # Healthy — leave it alone.
        ;;
      restarting|exited|dead|created|paused|unknown)
        info "Removing stale gateway container '${name}' (status=${status})..."
        docker rm -f "$name" >/dev/null 2>&1 || true
        removed=1
        ;;
      *)
        info "Removing gateway container '${name}' in unexpected state '${status}'..."
        docker rm -f "$name" >/dev/null 2>&1 || true
        removed=1
        ;;
    esac
  done
  [[ "$removed" -eq 1 ]] && ok "Stale gateway containers cleared."
  return 0
}

# _force_recreate_gateway — Force-remove the gateway containers regardless of
# status. Used when the running gateway was created by an older openshell
# version and is now wire-incompatible with the upgraded client (symptom:
# `openshell sandbox list -g <gw>` returns
#   × transport error / Connection reset by peer (os error 104)
# even though preflight reports the gateway "healthy" on its TCP port).
# Unlike `_cleanup_stale_gateway_containers` this also removes a `running`
# container, paying the k3s reboot tax on purpose to escape the stuck state.
# The next `nemoclaw onboard` will recreate the gateway from the current
# blueprint.
_force_recreate_gateway() {
  command -v docker &>/dev/null || { warn "docker not on PATH — cannot force-recreate gateway."; return 1; }
  local gw="$NEMOCLAW_GATEWAY_NAME"
  local names=("openshell-cluster-${gw}" "openshell-gateway-${gw}")
  local name status removed=0
  step "NemoClaw — force-recreate gateway '${gw}'"
  for name in "${names[@]}"; do
    if docker inspect "$name" &>/dev/null; then
      status=$(docker inspect -f '{{.State.Status}}' "$name" 2>/dev/null || echo unknown)
      info "Removing gateway container '${name}' (status=${status})..."
      docker rm -f "$name" >/dev/null 2>&1 || warn "  docker rm -f ${name} failed"
      removed=1
    fi
  done
  if [[ "$removed" -eq 0 ]]; then
    info "No gateway containers found — nothing to remove."
  else
    ok "Gateway containers removed; next onboard will recreate from blueprint."
  fi
  return 0
}

# ── cgroup v2 fix (Ubuntu 24.04) ─────────────────────────────────────────────
_fix_cgroups() {
  step "NemoClaw — cgroup v2 check"
  _ensure_sudo

  local fs_type
  fs_type=$(stat -fc %T /sys/fs/cgroup/)

  if [[ "$fs_type" == "cgroup2fs" ]]; then
    if [[ -r /etc/docker/daemon.json ]] && grep -q "default-cgroupns-mode" /etc/docker/daemon.json; then
      info "cgroup v2 fix already applied"
    else
      info "Applying cgroup v2 fix for Docker/k3s..."
      if [[ -f /etc/docker/daemon.json ]]; then
        sudo python3 -c "
import json
with open('/etc/docker/daemon.json') as f:
    config = json.load(f)
config['default-cgroupns-mode'] = 'host'
with open('/etc/docker/daemon.json', 'w') as f:
    json.dump(config, f, indent=2)
print('Merged into existing daemon.json')
"
      else
        sudo bash -c 'echo "{\"default-cgroupns-mode\": \"host\"}" > /etc/docker/daemon.json'
      fi
      sudo systemctl restart docker
    fi
  else
    info "cgroup v1 detected (${fs_type}) — fix not needed"
  fi
}

# ── Sandbox live policy overlay for llama-swap ─────────────────────────────────
# REMOVED 2026-04-25: was solving the wrong problem.
#
# Per NVIDIA NemoClaw v0.0.21 source (src/lib/onboard.ts:4331-4416, function
# `setupInference`) and the OpenShell v0.0.26 documented inference path
# (docs/get-started/tutorials/inference-ollama.mdx, "Option B: Host-Level
# Ollama"), the canonical architecture is:
#
#   sandbox / openclaw  ─── HTTPS ──▶  https://inference.local/v1
#                                              │  (relay terminates inside the
#                                              │   gateway pod, not the sandbox)
#                                              ▼
#                              http://host.openshell.internal:${LLAMA_SWAP_PORT}/v1
#                                              │
#                                              ▼
#                                        llama-swap (host)
#
# `inference.local` is baked into the sandbox Dockerfile via
# `ARG NEMOCLAW_INFERENCE_BASE_URL=https://inference.local/v1` (onboard.ts:1225)
# and the gateway resolves it through whatever provider+model is bound by
# `openshell inference set`. The sandbox NEVER calls
# `host.openshell.internal:8081` directly, so a custom network policy entry
# for that host is unnecessary — the gateway makes the upstream request.
#
# The previous `_ensure_llamaswap_policy` helper opened a sandbox-side hole to
# `host.openshell.internal:8081`. That hole was (a) outside the documented
# vendor path, (b) unable to clear the corporate proxy at 10.200.0.1:3128
# anyway (proxy 403 was surfacing through `inference.local` because the probe
# was wrong, not because policy was missing), and (c) DEVIATIONS.md-grade
# work that we'd have had to maintain forever.
#
# To restore the right behaviour we now:
#   1. update the `compatible-endpoint` provider's OPENAI_BASE_URL to the
#      host-side llama-swap upstream (host.openshell.internal:${LLAMA_SWAP_PORT}/v1);
#   2. re-run `openshell inference set --provider compatible-endpoint --model <model>`
#      to pin the gateway's relay route (mirrors NemoClaw `setupInference`);
#   3. probe the sandbox-facing URL `https://inference.local/v1/chat/completions`
#      — the only URL openclaw actually calls.
#
# See docs/pipeline/04-setup-nemoclaw.md and scripts/components/nemoclaw/CONTEXT.md
# for the full write-up.

# ── Inference route — pin sandbox-facing relay to the configured provider ─────
#
# Mirrors NemoClaw v0.0.21 `setupInference()` (src/lib/onboard.ts:4331-4416).
# Step 4 of `nemoclaw onboard` already runs `openshell inference set` with
# whatever provider/model was selected by the wizard. We re-run it here for
# two reasons:
#
#   1. After `_setup_provider()` rewrites `compatible-endpoint`'s
#      OPENAI_BASE_URL to point at host-side llama-swap, the gateway needs
#      to be told that the named provider is the active inference route,
#      AND that the bound model is the one llama-swap will actually serve.
#      Without this, `https://inference.local/v1` may resolve to a stale
#      provider/model from the last onboard wizard run.
#   2. `--start` and `reconfigure.sh` paths must be idempotent — operators
#      should be able to flip models (`NEMOCLAW_MODEL=...`) and re-run
#      this script without going through the full onboard wizard.
#
# `--no-verify` is intentionally NOT used: NemoClaw's `setupInference` only
# sets `--no-verify` for the `vllm-local` / `ollama-local` providers.
# `compatible-endpoint` is treated as a remote provider and verified.
_ensure_inference_route_pinned() {
  local gateway="${1:-$NEMOCLAW_GATEWAY_NAME}"
  local provider="${2:-compatible-endpoint}"
  local model="${3:-${NEMOCLAW_MODEL}}"

  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not found — cannot pin inference route"
    return 0
  fi

  # Warm the model BEFORE openshell's `inference set` runs its own verify
  # probe — that probe has a short, internal timeout that is NOT covered by
  # our --timeout flag (which controls the runtime route timeout). Without
  # this, a `--start` after a long onboard image build (which TTLs the model
  # out of Ollama) fails with "request to http://host.openshell.internal:8081
  # /v1/chat/completions timed out" during the verify step.
  _warm_llamaswap_model "$model"

  info "Pinning inference route: gateway=${gateway} provider=${provider} model=${model} timeout=${NEMOCLAW_INFERENCE_TIMEOUT}s"
  if ! openshell inference set \
         --provider "$provider" \
         --model    "$model" \
         --timeout  "$NEMOCLAW_INFERENCE_TIMEOUT"; then
    warn "openshell inference set failed once — retrying in 3s..."
    sleep 3
    openshell inference set \
      --provider "$provider" \
      --model    "$model" \
      --timeout  "$NEMOCLAW_INFERENCE_TIMEOUT" \
      || fail "Failed to pin inference route (provider=${provider} model=${model}). \
Run 'openshell inference get' to inspect; the sandbox call to https://inference.local will not route correctly."
  fi
  ok "Inference route pinned: ${provider} → ${model} (timeout ${NEMOCLAW_INFERENCE_TIMEOUT}s)."
}

# ── UFW firewall — restrict LLM endpoint to localhost + Docker ────────────────
_setup_ufw() {
  step "NemoClaw — firewall (UFW)"
  _ensure_sudo

  if ! command -v ufw &>/dev/null; then
    info "Installing UFW..."
    sudo apt-get install -y ufw
  fi

  # Docker's default bridge subnet; covers host.openshell.internal traffic
  local docker_subnet="172.16.0.0/12"
  local swap_port="${LLAMA_SWAP_PORT:-8081}"

  # Remove stale htsclaw UFW rules (ports 8083, 18790, 18792 — never used,
  # now reserved-only entries in portmap.json). Delete by comment match so
  # rule numbers don't need to be hard-coded (they shift after each delete).
  if sudo ufw status | grep -qi "htsclaw"; then
    info "Removing stale htsclaw UFW rules..."
    # ufw delete by rule spec — repeat for each htsclaw port/direction.
    for _port in 8083 18790 18792; do
      sudo ufw delete allow "$_port"/tcp 2>/dev/null || true
      sudo ufw delete deny  "$_port"/tcp 2>/dev/null || true
      sudo ufw delete allow from 100.64.0.0/10 to any port "$_port" proto tcp 2>/dev/null || true
      sudo ufw delete allow from 172.16.0.0/12 to any port "$_port" proto tcp 2>/dev/null || true
    done
    ok "Stale htsclaw UFW rules removed."
  fi

  # Allow SSH so we don't lock ourselves out
  if ! sudo ufw status | grep -q "22/tcp"; then
    sudo ufw allow 22/tcp comment "SSH" >/dev/null
  fi

  # Allow llama-swap from Docker/OpenShell subnets only
  if ! sudo ufw status | grep -q "${swap_port}/tcp.*ALLOW.*${docker_subnet}"; then
    info "Allowing llama-swap (:${swap_port}) from Docker subnet ${docker_subnet}..."
    sudo ufw allow from "$docker_subnet" to any port "$swap_port" proto tcp \
      comment "llama-swap — Docker/OpenShell sandboxes" >/dev/null
  else
    info "UFW rule for llama-swap already exists"
  fi

  # Deny llama-swap from everywhere else (explicit block before default policy)
  if ! sudo ufw status | grep -q "${swap_port}/tcp.*DENY"; then
    sudo ufw deny "$swap_port"/tcp comment "llama-swap — block LAN/WAN" >/dev/null
  fi

  # Enable UFW if not already active
  if ! sudo ufw status | grep -q "Status: active"; then
    info "Enabling UFW..."
    sudo ufw --force enable
  else
    info "UFW already active"
  fi

  ok "Firewall configured — llama-swap accessible from Docker only."

  # Allow NemoClaw ports from Tailscale only (gateway + sandbox dashboard).
  # 100.64.0.0/10 is the Tailscale CGNAT range.
  local tailscale_subnet="100.64.0.0/10"
  local gateway_port="${NEMOCLAW_GATEWAY_PORT:-8084}"
  local sandbox_port=18789
  for _nc_port in "$gateway_port" "$sandbox_port"; do
    if ! sudo ufw status | grep -q "${_nc_port}/tcp.*ALLOW.*${tailscale_subnet}"; then
      info "Allowing NemoClaw (:${_nc_port}) from Tailscale ${tailscale_subnet}..."
      sudo ufw allow from "$tailscale_subnet" to any port "$_nc_port" proto tcp \
        comment "NemoClaw — Tailscale access" >/dev/null
    else
      info "UFW rule for NemoClaw port ${_nc_port} already exists"
    fi
  done

  ok "NemoClaw ports allowed from Tailscale."
}

# ── Provider configuration ────────────────────────────────────────────────────
_setup_provider() {
  step "NemoClaw — inference provider (llama-swap via host.openshell.internal)"
  # Both sandboxes share the gateway inference route.
  # Point all providers at llama-swap via host.openshell.internal so the
  # gateway pod (which lacks hostNetwork) can reach the host.
  # llama-swap handles model-based routing (e.g. NEMOCLAW_MODEL → Ollama, bitnet → BitNet).
  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not found — skipping provider configuration"
    return 0
  fi

  local swap_url="http://host.openshell.internal:${LLAMA_SWAP_PORT:-8081}/v1"
  info "Endpoint: ${swap_url}"

  # Capture provider list once; fail fast if the provider API itself is unavailable.
  local providers
  if ! providers=$(openshell provider list 2>&1); then
    fail "Cannot list openshell providers — provider API unavailable: ${providers}"
  fi

  # compatible-endpoint: CRITICAL PATH — created by nemoclaw onboard for the
  # 'custom' provider. Must point at host.openshell.internal or in-sandbox
  # inference requests cannot reach llama-swap (sandbox lacks hostNetwork).
  # Retry once in case the gateway hasn't fully settled after onboard.
  local updated_compatible_ep=false
  if echo "$providers" | grep -q "compatible-endpoint"; then
    info "Updating compatible-endpoint → ${swap_url}"
    if ! openshell provider update compatible-endpoint \
         --config "OPENAI_BASE_URL=${swap_url}"; then
      warn "compatible-endpoint update failed — retrying in 3 s..."
      sleep 3
      openshell provider update compatible-endpoint \
        --config "OPENAI_BASE_URL=${swap_url}" || \
        fail "Failed to update compatible-endpoint provider — inference from sandbox will not reach llama-swap"
    fi
    updated_compatible_ep=true
  fi

  # llama-swap-local: supplemental provider for explicit model routing.
  # Warn only on failure — inference still routes via compatible-endpoint.
  if ! echo "$providers" | grep -q "llama-swap-local"; then
    info "Registering llama-swap-local provider..."
    openshell provider create \
      --name  llama-swap-local \
      --type  openai \
      --credential OPENAI_API_KEY=not-needed \
      --config "baseUrl=${swap_url}" || \
      warn "Failed to register llama-swap-local provider (supplemental — inference routes via compatible-endpoint)"
  else
    openshell provider update llama-swap-local \
      --config "baseUrl=${swap_url}" || \
      warn "Failed to update llama-swap-local provider (supplemental — inference routes via compatible-endpoint)"
  fi

  _ensure_inference_route_pinned "$NEMOCLAW_GATEWAY_NAME" "compatible-endpoint" "${NEMOCLAW_MODEL}"

  # Verify the only postcondition we actually care about: the sandbox can
  # serve a completion via the documented sandbox-facing inference URL,
  # `https://inference.local/v1/chat/completions`. This URL is baked into
  # the sandbox at build time by `nemoclaw onboard` (NemoClaw v0.0.29
  # src/lib/onboard.ts — `ARG NEMOCLAW_INFERENCE_BASE_URL`) and is
  # the ONLY URL openclaw calls; the gateway resolves it through the
  # provider+model bound by `openshell inference set` and then makes the
  # upstream call to llama-swap on the host. We probe the relay URL here
  # so a green postcondition really means "what openclaw uses works".
  if [[ "$updated_compatible_ep" == "true" ]]; then
    local sb="$NEMOCLAW_SANDBOX_NAME"
    local gw="$NEMOCLAW_GATEWAY_NAME"
    local expected_model="${NEMOCLAW_MODEL}"

    _probe_llamaswap_from_sandbox() {
      # stdout goes to /dev/null inside assert_postcondition; the grep -q
      # result is what drives the check. The gateway injects the inference
      # auth header automatically, so the sandbox does not need an
      # Authorization header on this URL (NemoClaw onboard.ts:3400 ->
      # crates/openshell-router/src/backend.rs).
      #
      # --max-time tracks NEMOCLAW_INFERENCE_TIMEOUT so a cold-load (Ollama
      # paging mid-size weights into VRAM on first call) doesn't trip
      # the curl client timeout BEFORE the gateway route timeout — and so
      # this probe doubles as the pre-warm: when it returns, the model is
      # hot and the dashboard's first chat answers in seconds.
      #
      # Retry-with-backoff: a freshly bumped route version (we just pinned
      # version N+1 above) can briefly return 503 while the gateway
      # propagates the new provider/model binding, and the host-side
      # warmup we did earlier doesn't guarantee the sandbox-side relay is
      # already routing. We retry up to 5 times with a 10s pause; each
      # attempt still gets the full NEMOCLAW_INFERENCE_TIMEOUT for the
      # actual model load. This is the single biggest source of "first
      # --start after a fresh onboard" flakes in this script — see
      # CONTEXT.md § "Lessons that bit us" lesson 5.
      local attempts=5
      local delay=10
      local i out=""
      for ((i=1; i<=attempts; i++)); do
        out=$(openshell sandbox exec -g "$gw" -n "$sb" -- \
          sh -c "curl -fsS --max-time ${NEMOCLAW_INFERENCE_TIMEOUT} \
                   -H 'Content-Type: application/json' \
                   -d '{\"model\":\"${expected_model}\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"max_tokens\":1,\"stream\":false}' \
                   https://inference.local/v1/chat/completions" 2>&1) || true
        if grep -q "\"${expected_model}\"" <<<"$out"; then
          [[ $i -gt 1 ]] && info "  Sandbox inference probe succeeded on attempt ${i}/${attempts}."
          return 0
        fi
        if [[ $i -lt $attempts ]]; then
          info "  Sandbox inference probe attempt ${i}/${attempts} not green yet — retrying in ${delay}s..."
          sleep "$delay"
        fi
      done
      return 1
    }

    assert_postcondition \
      "sandbox reaches https://inference.local and serves ${expected_model}" \
      _probe_llamaswap_from_sandbox
  fi

  ok "Inference providers configured (sandbox → https://inference.local → llama-swap)."
}

# ── Boot-time dashboard forward unit ─────────────────────────────────────────
# Install a systemd ONESHOT (no timer) that runs NVIDIA's documented
# port-forward command exactly once at boot:
#
#   openshell forward start --background 18789 <sandbox>
#
# Source: https://docs.nvidia.com/nemoclaw/latest/get-started/quickstart.html
#         § "Restart the Port Forward"
#
# This is NOT a watchdog. It does not poll, retry, or escalate. It only
# automates the user-driven manual step from the docs across reboots, so
# the dashboard is reachable at 127.0.0.1:18789 after boot without typing
# the command. If the forward dies during a session, the user runs the
# same documented command (or `nemoclaw.sh --restart-forward`).
#
# An older HTS health timer (`hts-nemoclaw-health.{service,timer}`) is
# disabled and removed if present — it was drift from the NemoClaw docs.
_install_dashboard_forward_boot_unit() {
  _ensure_sudo

  # Cleanup of legacy drift-watchdog (no-op if absent)
  if systemctl list-unit-files 2>/dev/null | grep -q '^hts-nemoclaw-health\.timer'; then
    sudo systemctl disable --now hts-nemoclaw-health.timer 2>/dev/null || true
    sudo rm -f /etc/systemd/system/hts-nemoclaw-health.timer \
                /etc/systemd/system/hts-nemoclaw-health.service
    sudo systemctl daemon-reload
    info "Removed legacy hts-nemoclaw-health timer (drift from NemoClaw docs)."
  fi

  local unit_name="hts-nemoclaw-dashboard-forward"
  local unit_file="/etc/systemd/system/${unit_name}.service"
  local run_user
  run_user=$(whoami)

  # Resolve NVM-managed node path so the unit can find openshell.
  [[ -f "$HOME/.nvm/nvm.sh" ]] && source "$HOME/.nvm/nvm.sh" || true
  local extra_path=""
  if command -v node &>/dev/null; then
    extra_path="$(dirname "$(command -v node)"):"
  fi
  if command -v openshell &>/dev/null; then
    local os_dir
    os_dir="$(dirname "$(command -v openshell)")"
    [[ "$extra_path" == *"$os_dir"* ]] || extra_path="${extra_path}${os_dir}:"
  fi

  local openshell_bin
  openshell_bin="$(command -v openshell || echo /usr/local/bin/openshell)"

  sudo tee "$unit_file" > /dev/null <<EOF
[Unit]
Description=HTS AI Stack — NemoClaw dashboard port forward (NVIDIA quickstart §Restart the Port Forward)
Documentation=https://docs.nvidia.com/nemoclaw/latest/get-started/quickstart.html
After=network-online.target docker.service
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
User=${run_user}
Environment=PATH=${extra_path}/usr/local/bin:/usr/bin:/bin
Environment=HOME=$(eval echo ~"$run_user")
ExecStart=${openshell_bin} -g ${NEMOCLAW_GATEWAY_NAME} forward start --background 18789 ${NEMOCLAW_SANDBOX_NAME}
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${unit_name}

[Install]
WantedBy=multi-user.target
EOF

  sudo systemctl daemon-reload
  sudo systemctl enable "${unit_name}.service"
  ok "Installed boot unit: ${unit_name}.service (one-shot at boot, no timer)."
}

# ── Functions ────────────────────────────────────────────────────────────────

# _ensure_nemoclaw_gateway — Verify the gateway is running; restart the container
# if missing after a host reboot. Does NOT create the gateway (creation is
# delegated to 'nemoclaw onboard', per NVIDIA Option A design).
_ensure_nemoclaw_gateway() {
  if openshell gateway select "$NEMOCLAW_GATEWAY_NAME" &>/dev/null; then
    local cluster_ctr="openshell-cluster-${NEMOCLAW_GATEWAY_NAME}"
    if docker inspect --format '{{.State.Running}}' "$cluster_ctr" 2>/dev/null | grep -q "true"; then
      info "Gateway '${NEMOCLAW_GATEWAY_NAME}' selected."
      return 0
    fi
    # Container missing (e.g., after host reboot).
    # Per NVIDIA troubleshooting ("Reconnect after a host reboot"):
    #   openshell gateway start --name <name>   (no --recreate)
    warn "Gateway '${NEMOCLAW_GATEWAY_NAME}' metadata found but container missing — restarting..."
    info "Booting gateway k3s — typically 30s–2min, no output during this step..."
    if openshell gateway start --name "$NEMOCLAW_GATEWAY_NAME" 2>/dev/null; then
      openshell gateway select "$NEMOCLAW_GATEWAY_NAME" \
        || fail "Gateway restarted but could not be selected."
      ok "Gateway '${NEMOCLAW_GATEWAY_NAME}' restarted."
      return 0
    fi
    fail "Gateway '${NEMOCLAW_GATEWAY_NAME}' exists but could not be restarted. Run 'nemoclaw onboard' to recreate."
    return 1
  fi
  # Gateway does not exist — creation is handled by 'nemoclaw onboard'.
  # Per NVIDIA guidance, avoid 'openshell gateway start --recreate' unless
  # explicitly required; nemoclaw onboard manages the full lifecycle.
  info "Gateway '${NEMOCLAW_GATEWAY_NAME}' not found — will be created by nemoclaw onboard."
  return 0
}

# nemoclaw_install — Install OpenShell (host) and NemoClaw CLI (host).
# Gateway and sandbox creation are handled by 'nemoclaw onboard' (Option A flip).
nemoclaw_install() {
  _ensure_sudo
  _preflight_required_tools

  # k3s inside the OpenShell gateway will crash on Ubuntu defaults (128
  # inotify instances). Apply before anything runs `openshell gateway start`.
  _fix_inotify_limits
  # If a prior run left a crashed cluster container behind, force-remove it so
  # the vendor installer can create a fresh one.
  _cleanup_stale_gateway_containers

  # ── OpenShell CLI (host-side) ──
  step "NemoClaw — OpenShell CLI"
  local pre_ver
  pre_ver=$(openshell --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
  install_openshell_nvidia || warn "OpenShell install encountered issues — proceeding..."
  local post_ver
  post_ver=$(openshell --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
  [[ "$pre_ver" != "$post_ver" ]] && _OPENSHELL_REINSTALLED=true

  # Read canonical pin from the manifest — single source of truth (see REFERENCES.md → NemoClaw).
  # jq fallback: || echo fires when jq is absent or the manifest is unreadable.
  NEMOCLAW_INSTALL_TAG="${NEMOCLAW_INSTALL_TAG:-$(
    jq -r '.upstream.pinned_version // "v0.0.21"' \
      "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.manifest.json" 2>/dev/null \
      || echo v0.0.21
  )}"

  # ── NemoClaw CLI (host-side) ──
  # Per NVIDIA docs: curl -fsSL https://www.nvidia.com/nemoclaw.sh | bash
  # NEMOCLAW_SKIP_ONBOARD=1 prevents automatic 'nemoclaw onboard' during install.
  # If the flag is not recognized, the installer may run onboard; that is safe —
  # nemoclaw_onboard() is idempotent.
  step "NemoClaw — official installer (host)"

  # Version-aware idempotency: an existing nemoclaw binary is only acceptable if
  # its version matches NEMOCLAW_INSTALL_TAG (the manifest pin). Without this
  # check, manifest pin bumps silently no-op on hosts that already have an older
  # CLI, which leaves ~/.nemoclaw/source/nemoclaw-blueprint/blueprint.yaml at
  # the old version and breaks scripts/utils/verify-openshell-pin.sh.
  # Override with NEMOCLAW_FORCE_REINSTALL=1 to reinstall regardless.
  local _need_install=false _installed_ver="" _desired_ver="${NEMOCLAW_INSTALL_TAG#v}"
  if ! command -v nemoclaw &>/dev/null; then
    _need_install=true
  else
    _installed_ver="$(nemoclaw --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || true)"
    if [[ "${NEMOCLAW_FORCE_REINSTALL:-0}" == "1" ]]; then
      info "NemoClaw CLI present (v${_installed_ver:-unknown}); NEMOCLAW_FORCE_REINSTALL=1 — reinstalling to ${NEMOCLAW_INSTALL_TAG}."
      _need_install=true
    elif [[ -z "$_installed_ver" ]]; then
      warn "NemoClaw CLI present but --version output unparseable; reinstalling to ${NEMOCLAW_INSTALL_TAG}."
      _need_install=true
    elif [[ "$_installed_ver" != "$_desired_ver" ]]; then
      info "NemoClaw CLI v${_installed_ver} does not match pin ${NEMOCLAW_INSTALL_TAG} — upgrading."
      _need_install=true
    fi
  fi

  if [[ "$_need_install" == "true" ]]; then
    info "Installing NemoClaw CLI on host (target ${NEMOCLAW_INSTALL_TAG})..."

    _ensure_nemoclaw_model_ready "$NEMOCLAW_MODEL"

    # Pre-flight: v0.0.21's [3/8] step validates the custom endpoint at install time.
    # Ensure llama-swap is reachable before the installer reaches that step.
    local swap_port="${LLAMA_SWAP_PORT:-8081}"
    local attempt=0 max_attempts=10 swap_ok=false
    while [[ $attempt -lt $max_attempts ]]; do
      attempt=$((attempt + 1))
      if python3 -c "
import urllib.request, sys
try:
    r = urllib.request.urlopen('http://localhost:${swap_port}/health', timeout=5)
    sys.exit(0 if r.status < 500 else 1)
except Exception:
    sys.exit(1)
" 2>/dev/null; then
        swap_ok=true
        break
      fi
      [[ $attempt -lt $max_attempts ]] && \
        info "llama-swap (:${swap_port}) not ready — retry ${attempt}/${max_attempts} (waiting 10s)..." && sleep 10
    done
    [[ "$swap_ok" == "true" ]] \
      || fail "Pre-flight failed: llama-swap (:${swap_port}) unreachable — ensure llama-swap is running before installing NemoClaw."

    # Pass provider env so the new [3/8] Configuring inference step routes to
    # llama-swap (NEMOCLAW_PROVIDER=custom) instead of NVIDIA Endpoints, which
    # would require NVIDIA_API_KEY. See DEVIATIONS.md → NemoClaw.
    #
    # NOTE: as of NemoClaw v0.0.29, NEMOCLAW_SKIP_ONBOARD=1 is silently ignored
    # — the installer's [3/3] Onboarding step always runs `nemoclaw onboard`,
    # which can fail against a stale "Previous onboarding session" left by an
    # earlier (e.g. v0.0.21) attempt. We treat that case as a non-fatal warning
    # below if the CLI binary itself reached the pinned version, because our
    # own nemoclaw_onboard() handles onboarding under our control.
    local _installer_rc=0
    env NEMOCLAW_NON_INTERACTIVE=1 \
        NEMOCLAW_ACCEPT_THIRD_PARTY_SOFTWARE=1 \
        NEMOCLAW_SKIP_ONBOARD=1 \
        NEMOCLAW_INSTALL_TAG="$NEMOCLAW_INSTALL_TAG" \
        NEMOCLAW_EXPERIMENTAL=1 \
        NEMOCLAW_PROVIDER=custom \
        NEMOCLAW_ENDPOINT_URL="http://localhost:${LLAMA_SWAP_PORT:-8081}/v1" \
        NEMOCLAW_MODEL="$NEMOCLAW_MODEL" \
        COMPATIBLE_API_KEY=not-needed \
        NEMOCLAW_POLICY_MODE=suggested \
      bash -c 'curl -fsSL https://www.nvidia.com/nemoclaw.sh | bash' \
      || _installer_rc=$?
    # PATH refresh: NVIDIA installer uses nvm + npm global (not system PATH).
    # Do NOT source ~/.bashrc (non-interactive shell).
    [[ -f "$HOME/.nvm/nvm.sh" ]] && source "$HOME/.nvm/nvm.sh" || true
    local npm_prefix
    npm_prefix=$(npm config get prefix 2>/dev/null || true)
    export PATH="$HOME/.local/bin:$HOME/.npm-global/bin:${npm_prefix:+${npm_prefix}/bin:}$PATH"
    command -v nemoclaw &>/dev/null \
      || fail "nemoclaw CLI not found in PATH after install — check nvm/npm setup."
    local _post_ver
    _post_ver="$(nemoclaw --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || true)"
    if [[ $_installer_rc -ne 0 ]]; then
      if [[ -n "$_post_ver" && "$_post_ver" == "$_desired_ver" ]]; then
        warn "NemoClaw installer exited rc=${_installer_rc} but CLI is at pinned v${_post_ver}."
        warn "Most common cause: NemoClaw v0.0.29 ignores NEMOCLAW_SKIP_ONBOARD=1 and"
        warn "ran 'nemoclaw onboard' automatically, hitting a stale session from an"
        warn "earlier attempt. The onboard step is interactive when called by hand,"
        warn "so use the unattended wrapper to recover:"
        warn "    ./scripts/components/nemoclaw/nemoclaw.sh --onboard-fresh"
        warn "(this passes --fresh + provider env: PROVIDER=custom, llama-swap, --non-interactive)"
      else
        fail "NemoClaw official installer failed (rc=${_installer_rc}, CLI now at v${_post_ver:-unknown}, expected v${_desired_ver})."
      fi
    fi
    ok "NemoClaw CLI installed: $(nemoclaw --version 2>/dev/null || true)"
  else
    info "NemoClaw CLI already at pinned version: $(nemoclaw --version 2>/dev/null || true)"
  fi

  ok "NemoClaw host installation complete."
  _check_experimental_flag_supported
}

# nemoclaw_configure — inotify preflight, cgroup v2 fix, provider config
nemoclaw_configure() {
  _fix_inotify_limits
  _fix_cgroups
  _setup_ufw
  _setup_provider
  ok "NemoClaw configured."
}

# nemoclaw_onboard — Create/manage NemoClaw sandboxes
nemoclaw_onboard() {
  if [[ "$NEMOCLAW_ENABLED" != "true" ]]; then
    step "NemoClaw — onboard (SKIPPED)"
    info "Skipping NemoClaw deployment — using existing installation"
    return 0
  fi

  step "NemoClaw — onboard (GPU sandbox)"
  echo ""
  warn "Port 18789 must be free before continuing."
  warn "First run will pull ~2.4 GB of images."
  echo ""

  # Belt-and-suspenders: onboard may be invoked directly (skipping
  # nemoclaw_install / nemoclaw_configure), so re-assert the kernel preflight
  # and clean any zombie gateway container from a failed previous run.
  _fix_inotify_limits
  _cleanup_stale_gateway_containers

  # GPU sandbox → tool-capable Ollama model via llama-swap.
  # CPU sandbox removed — gVisor/Daytona evaluation pending (FEATURE-012, FEATURE-013).
  declare -A sandbox_models=(
    ["hts-ai-openshell-nemoclaw"]="$NEMOCLAW_MODEL"
  )

  for sandbox in "${!sandbox_models[@]}"; do
    local model="${sandbox_models[$sandbox]}"

    if ! openshell sandbox get "$sandbox" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null 2>&1; then
      _do_onboard "$sandbox" "$model"
      continue
    fi

    # Sandbox exists: check health and prompt
    echo ""
    info "Sandbox '${sandbox}' already exists. Checking health..."
    local health_label
    if _check_sandbox_health "$sandbox"; then
      health_label="${GREEN}healthy (Phase: Ready)${NC}"
    else
      health_label="${YELLOW}degraded${NC}"
    fi
    # In unattended mode (no TTY, converge --yes, or NONINTERACTIVE), skip existing sandbox
    if [[ ! -t 0 ]] || [[ "${NONINTERACTIVE:-}" == "1" ]] || [[ "${YES_MODE:-}" == "1" ]]; then
      info "Non-interactive mode — keeping existing sandbox '${sandbox}'."
      continue
    fi

    echo -e "\n  Sandbox '${sandbox}' is ${health_label}.\n"
    echo    "  Options:"
    echo -e "    [s] Skip  — keep existing sandbox  ${YELLOW}(default, auto-selects in 30s)${NC}"
    echo    "    [o] Overwrite — destroy and re-onboard"
    echo ""

    local reply=""
    if read -r -t 30 -p "  Choice [s/o]: " reply 2>/dev/null; then
      : # got input
    else
      echo ""
      info "No input — skipping '${sandbox}'."
    fi

    case "${reply,,}" in
      o|overwrite)
        warn "Destroying sandbox '${sandbox}'..."
        # Use nemoclaw destroy (official); fall back if sandbox is unregistered.
        # See DEVIATIONS.md → NemoClaw (destroy fallback).
        if command -v nemoclaw &>/dev/null; then
          nemoclaw "$sandbox" destroy --yes 2>/dev/null || \
            openshell sandbox delete -g "$NEMOCLAW_GATEWAY_NAME" "$sandbox" 2>/dev/null || true
        else
          openshell sandbox delete -g "$NEMOCLAW_GATEWAY_NAME" "$sandbox" 2>/dev/null || true
        fi
        _do_onboard "$sandbox" "$model"
        ;;
      *)
        info "Sandbox '${sandbox}' — keeping existing."
        ;;
    esac
  done

  # Post-onboard: configure provider
  _setup_provider

  # NemoClaw's own onboard only forwards port 18789 (and stomps the previous
  # forward each run); re-issue the documented vendor command so the host
  # listener is up before tokens are extracted.
  _start_dashboard_forward
  _extract_dashboard_tokens

  # Auto-update OpenClaw if a newer version is available
  if [[ "$NEMOCLAW_AUTO_UPDATE" == "true" ]]; then
    _update_openclaw
    # Re-extract tokens after update — gateway restart may regenerate them
    _extract_dashboard_tokens
  else
    info "OpenClaw auto-update disabled (NEMOCLAW_AUTO_UPDATE=false)"
  fi
  # Fix allowedOrigins for sandboxes (CPU sandbox exposed on different port)
  _fix_sandbox_origins

  # Install boot-time oneshot so the documented forward-start command runs
  # automatically after reboot (no watchdog, no timer).
  _install_dashboard_forward_boot_unit

  ok "NemoClaw onboarding complete."
}

# _start_dashboard_forward — Run NVIDIA's documented forward-start command.
#
# Source: https://docs.nvidia.com/nemoclaw/latest/get-started/quickstart.html
#         § "Restart the Port Forward"
#
# The entire vendor-prescribed recovery for a dead dashboard forward is:
#
#     openshell -g <gateway> forward start --background <port> <sandbox>
#
# That's it. NVIDIA's design treats the SSH forward as a single user-driven
# command — no watchdog, no retry loop, no escalation, no listener probe.
# This wrapper exists only to (a) thread our gateway/sandbox names through
# and (b) be callable from `nemoclaw_start`, the boot-time oneshot unit,
# and the explicit `--restart-forward` flag. All earlier HTS drift
# (`_ensure_forwards`, `_forward_listening`, `_wait_forward_listening`,
# sandbox-side relay, escalation to `nemoclaw <name> restart`) was removed
# in alignment with the documented design.
_start_dashboard_forward() {
  local sandbox="${1:-$NEMOCLAW_SANDBOX_NAME}"
  local port="${2:-18789}"
  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not found; cannot start dashboard forward."
    return 1
  fi
  # Stop any prior forward on this port (idempotent), then start per docs.
  openshell -g "$NEMOCLAW_GATEWAY_NAME" forward stop "$port" 2>/dev/null || true
  if openshell -g "$NEMOCLAW_GATEWAY_NAME" forward start --background "$port" "$sandbox" 2>/dev/null; then
    ok "Dashboard forward started: 127.0.0.1:${port} → ${sandbox} (per NVIDIA quickstart)."
  else
    warn "openshell forward start returned non-zero; check 'openshell -g ${NEMOCLAW_GATEWAY_NAME} forward list'."
    return 1
  fi
}

# _sandbox_root_exec — Execute a command as root (uid 0) inside a sandbox.
#
# openclaw.json and other files under /sandbox/.openclaw/ are root-owned
# (baked at image build time). Neither 'openshell sandbox exec' nor SSH can
# write to them because they run as the unprivileged 'sandbox' user.
# The only route is: docker exec → containerd → --user 0.
#
# Usage: _sandbox_root_exec <sandbox-name> <exec-id-prefix> <command...>
#   Returns: stdout of the command; rc of the inner exec.
_sandbox_root_exec() {
  local sandbox="$1" exec_prefix="$2"; shift 2
  local cluster_container="openshell-cluster-${NEMOCLAW_GATEWAY_NAME}"

  if ! docker inspect "$cluster_container" &>/dev/null; then
    warn "Cluster container '${cluster_container}' not found."
    return 1
  fi

  # Resolve the containerd task ID for this sandbox's pod
  local ctr_id
  ctr_id=$(docker exec "$cluster_container" \
    /bin/sh -c "ctr -n k8s.io tasks list 2>/dev/null | awk '{print \$1}'" \
    | while read -r id; do
        local hn
        hn=$(docker exec "$cluster_container" \
          ctr -n k8s.io tasks exec --exec-id "hn-${id:0:8}" --user 0 "$id" \
          hostname 2>/dev/null) || continue
        if [[ "$hn" == "$sandbox" ]]; then echo "$id"; break; fi
      done)

  if [[ -z "${ctr_id:-}" ]]; then
    warn "Could not find containerd task for '${sandbox}'."
    return 1
  fi

  docker exec "$cluster_container" \
    ctr -n k8s.io tasks exec \
      --exec-id "${exec_prefix}-${sandbox:0:8}" --user 0 "$ctr_id" \
      "$@"
}

# _sandbox_root_restart_gw — Restart the OpenClaw gateway in-process.
# Per CONTEXT.md, the official restart signal is SIGUSR1 (in-process restart).
# SIGTERM/pkill is avoided — it kills the process rather than reloading it.
_sandbox_root_restart_gw() {
  local sandbox="$1"
  _sandbox_root_exec "$sandbox" "gw" \
    /bin/sh -c "kill -USR1 \$(cat /tmp/openclaw-gateway.pid 2>/dev/null) 2>/dev/null || true" \
    2>/dev/null || true
  sleep 3
}

# _fix_sandbox_origins — Patch controlUi.allowedOrigins so the Control UI
# works when a sandbox is exposed on a non-default port (e.g. GPU on 18789).
_fix_sandbox_origins() {
  if ! command -v openshell &>/dev/null; then return 0; fi

  declare -A sandbox_ports=(
    ["hts-ai-openshell-nemoclaw"]=18789
  )

  for sandbox in "${!sandbox_ports[@]}"; do
    local port="${sandbox_ports[$sandbox]}"
    openshell sandbox get "$sandbox" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null || continue

    info "Fixing allowedOrigins for '${sandbox}' → :${port}..."
    local fix_script="import json,pathlib;p=pathlib.Path('/sandbox/.openclaw/openclaw.json');d=json.loads(p.read_text());d.setdefault('gateway',{}).setdefault('controlUi',{})['allowedOrigins']=['http://127.0.0.1:${port}','http://localhost:${port}'];p.write_text(json.dumps(d,indent=2));print('OK')"

    local result
    result=$(_sandbox_root_exec "$sandbox" "fix" python3 -c "$fix_script" 2>&1) || {
      warn "Failed to fix allowedOrigins for '${sandbox}': ${result}"
      continue
    }

    _sandbox_root_restart_gw "$sandbox"
  done

  ok "Sandbox allowedOrigins fixed."
}

# nemoclaw_start — Ensure gateway, sandbox, and OpenClaw are running.
# Called by converge --start. Self-heals: if the sandbox is missing, runs full
# onboard (creates gateway + sandbox). If sandbox exists but OpenClaw is not
# serving (Phase != Ready), re-onboards non-interactively with RECREATE_SANDBOX.
nemoclaw_start() {
  step "NemoClaw — start"

  # Apply kernel preflight on every start path too — converge may invoke
  # nemoclaw.sh --start directly without going through install/configure
  # (e.g. after a host reboot or when the binary is already present but the
  # gateway is unhealthy). Cheap to re-assert; no-op when already set.
  _fix_inotify_limits
  _cleanup_stale_gateway_containers

  # Ensure the nemoclaw CLI is on the host — if missing, install it.
  if ! command -v nemoclaw &>/dev/null; then
    warn "nemoclaw CLI not found on host — running install..."
    nemoclaw_install
  fi

  _ensure_nemoclaw_gateway

  if ! openshell sandbox get "$NEMOCLAW_SANDBOX_NAME" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null 2>&1; then
    warn "Sandbox '${NEMOCLAW_SANDBOX_NAME}' not found — running full onboard..."
    nemoclaw_onboard
    return $?
  fi

  if ! _check_sandbox_health "$NEMOCLAW_SANDBOX_NAME" &>/dev/null; then
    warn "Sandbox '${NEMOCLAW_SANDBOX_NAME}' exists but is not Ready — re-onboarding (recreate)..."
    _do_onboard "$NEMOCLAW_SANDBOX_NAME" "$NEMOCLAW_MODEL" "true"
    # Inline finalization (nemoclaw_onboard() path skipped for speed; run explicitly)
    _setup_provider
    _fix_sandbox_origins
    _install_dashboard_forward_boot_unit
  else
    _ensure_nemoclaw_model_ready "$NEMOCLAW_MODEL"
    _setup_provider
    _fix_sandbox_origins
    _install_dashboard_forward_boot_unit
    info "Sandbox '${NEMOCLAW_SANDBOX_NAME}' is healthy."
  fi

  _start_dashboard_forward

  # Dashboard liveness probe — `nemoclaw <name> status` reports Phase: Ready and
  # Inference: healthy without proving openclaw inside the sandbox is actually
  # serving HTTP on 18789. Today's failure mode: rebuild leaves the sandbox in
  # Ready but openclaw empty-replies on connect (TCP accept, zero-byte close).
  # Per NVIDIA docs the documented recovery for an unresponsive in-sandbox
  # OpenClaw is `nemoclaw <name> rebuild` (which runs `openclaw doctor --fix`
  # automatically). We warn — we do NOT auto-rebuild, because that re-introduces
  # the watchdog drift this branch removed (rip-out-drift, see DEVIATIONS.md).
  #
  # Probe gates the rest of start: tokens are only written for a live dashboard,
  # and `ok` only fires on a green probe. On failure we exit non-zero so callers
  # (converge, CI) see the truth instead of a misleading success.
  if ! _probe_dashboard_after_start; then
    fail "NemoClaw dashboard not responsive after start. See warning above for the documented recovery."
    return 1
  fi
  _extract_dashboard_tokens
  _heal_install_status
  ok "NemoClaw started."
}

# _heal_install_status — Self-heal the dashboard's install-status.json on a
# successful start. The status file is install-time only; if a previous
# `--start` failed (e.g. the postcondition flake during a model cold-load),
# the dashboard pins to phase=error and shows nemoclaw red even after the
# next start succeeds. Without this, the only way to clear it is a manual
# JSON edit or a full converge re-run.
#
# Behaviour:
#   - If services.nemoclaw == "error", set it to "running" and drop
#     messages.nemoclaw.
#   - If phase == "error" and no other service is in error, set phase to
#     "complete" so the dashboard exits install-mode and runs live probes.
#   - No-op if the file does not exist or already shows nemoclaw running.
#   - Atomic write via tempfile + rename. Python instead of bash JSON
#     surgery — load_env-grade safety.
_heal_install_status() {
  local status_file="${REPO_DIR}/resources/dashboard/install-status.json"
  [[ -f "$status_file" ]] || return 0
  command -v python3 &>/dev/null || return 0

  python3 - "$status_file" <<'PY' || return 0
import json, os, sys, tempfile, datetime
path = sys.argv[1]
try:
    with open(path) as f:
        d = json.load(f)
except Exception:
    sys.exit(0)
svcs = d.setdefault('services', {})
msgs = d.setdefault('messages', {})
changed = False
if svcs.get('nemoclaw') == 'error':
    svcs['nemoclaw'] = 'running'
    msgs.pop('nemoclaw', None)
    changed = True
if d.get('phase') == 'error' and not any(s == 'error' for s in svcs.values()):
    d['phase'] = 'complete'
    changed = True
if not changed:
    sys.exit(0)
d['updated'] = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix='.install-status.')
try:
    with os.fdopen(fd, 'w') as f:
        json.dump(d, f, indent=2)
        f.write('\n')
    os.replace(tmp, path)
except Exception:
    try: os.unlink(tmp)
    except FileNotFoundError: pass
    sys.exit(0)
PY
  info "Healed dashboard install-status.json (nemoclaw → running)."
}

# _probe_dashboard_after_start — Verify the host-side forward to :18789 returns
# a real HTTP response after start. Runs after `_start_dashboard_forward`, so
# the SSH tunnel is up; the only thing this catches is the openclaw process
# inside the sandbox failing to bind/serve. Warn-only by design — recovery is
# the user's call (documented: `nemoclaw <name> rebuild`).
_probe_dashboard_after_start() {
  local port=18789
  local attempts=10
  local delay=3
  local code=000
  local i

  # Brief grace before first probe: SSH -L can report "started" before the
  # local listener is actually accepting, and openclaw inside the sandbox may
  # still be finishing its HTTP bind right after Phase: Ready flips on. 2s
  # head-start eliminates the spurious-warn race we hit otherwise.
  sleep 2

  for ((i=1; i<=attempts; i++)); do
    code=$(curl -sS -m 5 -o /dev/null -w '%{http_code}' "http://127.0.0.1:${port}/" 2>/dev/null)
    code=${code:-000}
    if [[ "$code" == "200" ]]; then
      [[ $i -gt 1 ]] && info "Dashboard responsive after ${i} attempts (~$((i * delay))s warmup)."
      [[ $i -eq 1 ]] && info "Dashboard responsive: 127.0.0.1:${port} → HTTP 200."
      return 0
    fi
    [[ $i -lt $attempts ]] && sleep "$delay"
  done
  warn "Dashboard probe failed after ${attempts} attempts (~$((attempts * delay))s): 127.0.0.1:${port} returned HTTP ${code}."
  warn "  The SSH forward is up (see 'ps -ef | grep \"ssh.*-L 127.0.0.1:${port}\"'),"
  warn "  but openclaw inside sandbox '${NEMOCLAW_SANDBOX_NAME}' is not serving."
  warn "  Per NVIDIA NemoClaw quickstart, the documented recovery is:"
  warn "      nemoclaw ${NEMOCLAW_SANDBOX_NAME} rebuild"
  warn "  (rebuild preserves workspace and runs 'openclaw doctor --fix' automatically)."
  return 1
}


# nemoclaw_stop — Non-destructive stop (H4 fix).
#
# Per NVIDIA docs, `nemoclaw stop` only stops host auxiliary services
# (cloudflared). It does NOT destroy the sandbox. Sandbox deletion is
# `nemoclaw <name> destroy` — see nemoclaw_destroy below.
#
# Our stop: tear down port forwards so the dashboard is unreachable from the
# host, but leave the gateway + sandbox running for fast restart.
nemoclaw_stop() {
  step "NemoClaw — stop"
  if ! command -v openshell &>/dev/null; then
    warn "openshell CLI not found"
    return 1
  fi

  # Stop port forwards (dashboard becomes unreachable from host)
  local gw="$NEMOCLAW_GATEWAY_NAME"
  local fwd_ports=(18789)
  for port in "${fwd_ports[@]}"; do
    openshell -g "$gw" forward stop "$port" 2>/dev/null || true
  done
  info "Port forwards stopped."

  ok "NemoClaw stopped."
}

# nemoclaw_restart — Rebuild sandbox preserving workspace state.
#
# NVIDIA's `nemoclaw <name> rebuild` backs up workspace, destroys the sandbox,
# recreates with current image, restores workspace, then runs
# `openclaw doctor --fix` for cross-version structure repair.
nemoclaw_restart() {
  step "NemoClaw — restart"

  if ! command -v nemoclaw &>/dev/null; then
    warn "nemoclaw CLI not found — installing first..."
    nemoclaw_install
  fi

  # Preferred: nemoclaw rebuild (preserves workspace)
  _backup_sandbox "$NEMOCLAW_SANDBOX_NAME"
  if NEMOCLAW_GATEWAY_PORT="$NEMOCLAW_GATEWAY_PORT" \
     nemoclaw "$NEMOCLAW_SANDBOX_NAME" rebuild --yes 2>&1; then
    openshell sandbox exec -g "$NEMOCLAW_GATEWAY_NAME" -n "$NEMOCLAW_SANDBOX_NAME" -- \
      openclaw doctor --fix --non-interactive 2>/dev/null || true
    _start_dashboard_forward
    _extract_dashboard_tokens
    ok "NemoClaw restarted (rebuild)."
    return 0
  fi
  warn "nemoclaw rebuild failed — falling back to manual restart."

  nemoclaw_stop

  if openshell sandbox get "$NEMOCLAW_SANDBOX_NAME" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null 2>&1; then
    warn "Deleting sandbox '${NEMOCLAW_SANDBOX_NAME}' for manual rebuild..."
    # Prefer nemoclaw destroy; fall back only if unavailable or sandbox unregistered.
    # See DEVIATIONS.md → NemoClaw (destroy fallback).
    if command -v nemoclaw &>/dev/null; then
      nemoclaw "$NEMOCLAW_SANDBOX_NAME" destroy --yes 2>/dev/null || \
        openshell sandbox delete -g "$NEMOCLAW_GATEWAY_NAME" "$NEMOCLAW_SANDBOX_NAME" 2>/dev/null || true
    else
      openshell sandbox delete -g "$NEMOCLAW_GATEWAY_NAME" "$NEMOCLAW_SANDBOX_NAME" 2>/dev/null || true
    fi
  fi

  nemoclaw_install
  nemoclaw_start
  ok "NemoClaw restarted (manual rebuild)."
}

# nemoclaw_destroy — Back up and destroy sandbox (M4 + correct semantic).
#
# Per NVIDIA docs, `nemoclaw <name> destroy` permanently deletes the sandbox
# and its persistent volume. All workspace files are lost.
# We back up workspace first per NVIDIA's recommendation to snapshot before
# destructive operations.
nemoclaw_destroy() {
  step "NemoClaw — destroy"

  # Back up workspace before destruction (M4)
  _backup_sandbox "$NEMOCLAW_SANDBOX_NAME"

  # Delete sandbox — per NVIDIA docs, prefer `nemoclaw <name> destroy`.
  # Falls back to `openshell sandbox delete` only if nemoclaw CLI unavailable
  # or the sandbox is not registered in ~/.nemoclaw/sandboxes.json.
  if command -v nemoclaw &>/dev/null; then
    warn "Destroying sandbox '${NEMOCLAW_SANDBOX_NAME}'..."
    nemoclaw "$NEMOCLAW_SANDBOX_NAME" destroy --yes 2>/dev/null || {
      warn "nemoclaw destroy failed — falling back to openshell sandbox delete."
      # Fallback: sandbox may not be registered with nemoclaw (e.g. pre-migration).
      # openshell sandbox delete is the only remaining route in that case.
      # See DEVIATIONS.md → NemoClaw (destroy fallback).
      openshell sandbox delete -g "$NEMOCLAW_GATEWAY_NAME" "$NEMOCLAW_SANDBOX_NAME" 2>/dev/null || true
    }
  elif command -v openshell &>/dev/null; then
    if openshell sandbox get "$NEMOCLAW_SANDBOX_NAME" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null 2>&1; then
      warn "nemoclaw CLI not found — destroying via openshell sandbox delete (last resort)."
      # Deviation: nemoclaw CLI not installed; no other path available.
      # See DEVIATIONS.md → NemoClaw (destroy fallback).
      openshell sandbox delete -g "$NEMOCLAW_GATEWAY_NAME" "$NEMOCLAW_SANDBOX_NAME" 2>/dev/null || true
    fi
  fi

  # Stop port forwards
  nemoclaw_stop 2>/dev/null || true

  # Disable HTS systemd units: the legacy health timer (drift, removed) and
  # the new boot-time forward oneshot. Both removals are no-ops if absent.
  sudo systemctl disable --now hts-nemoclaw-health.timer 2>/dev/null || true
  sudo systemctl disable --now hts-nemoclaw-dashboard-forward.service 2>/dev/null || true
  sudo rm -f /etc/systemd/system/hts-nemoclaw-health.timer \
              /etc/systemd/system/hts-nemoclaw-health.service \
              /etc/systemd/system/hts-nemoclaw-dashboard-forward.service 2>/dev/null || true
  sudo systemctl daemon-reload 2>/dev/null || true
  ok "NemoClaw destroyed."
}

nemoclaw_status() {
  step "NemoClaw — status"
  if command -v openshell &>/dev/null; then
    if openshell sandbox get "$NEMOCLAW_SANDBOX_NAME" -g "$NEMOCLAW_GATEWAY_NAME" &>/dev/null 2>&1; then
      ok "Sandbox '${NEMOCLAW_SANDBOX_NAME}' exists."
      openshell sandbox get "$NEMOCLAW_SANDBOX_NAME" -g "$NEMOCLAW_GATEWAY_NAME" 2>/dev/null || true
    else
      warn "No NemoClaw sandbox found."
    fi
  else
    warn "openshell CLI not installed."
  fi

  # Vendor-documented status probe: `nemoclaw <name> status` covers inference
  # health, sandbox state, version drift, and channel conflicts.
  # Ref: NVIDIA NemoClaw quickstart §"Check Sandbox Status".
  if command -v nemoclaw &>/dev/null; then
    NEMOCLAW_GATEWAY_PORT="$NEMOCLAW_GATEWAY_PORT" \
      nemoclaw "$NEMOCLAW_SANDBOX_NAME" status 2>&1 || true
  fi
}

# nemoclaw_cleanup — Remove host-side artifacts WITHOUT destroying the
# sandbox or its workspace. Use this when uninstalling the component but
# wanting to preserve sandbox state for a later reinstall, or to reset
# host-side wiring without losing workspace data.
#
# Removes (idempotent — "already gone" is success):
#   - systemd oneshot: hts-nemoclaw-dashboard-forward.service
#   - sysctl persistence: /etc/sysctl.d/99-hts-ai-stack-inotify.conf
#     (running sysctls are NOT reverted — k3s may still be running)
#   - UFW rules added by _setup_ufw (llama-swap subnet allow/deny + Tailscale
#     allows for gateway/sandbox dashboard ports)
#
# Does NOT touch:
#   - sandbox / workspace data (use --destroy or nemoclaw <name> destroy)
#   - gateway containers (use --recreate-gateway)
#   - the nemoclaw / openshell binaries
#   - inotify kernel sysctls currently in effect (only the persistence file)
nemoclaw_cleanup() {
  step "NemoClaw — host cleanup (preserves sandbox)"
  _ensure_sudo

  # 1. systemd dashboard-forward oneshot
  local unit="hts-nemoclaw-dashboard-forward.service"
  local unit_file="/etc/systemd/system/${unit}"
  if [[ -f "$unit_file" ]] || systemctl list-unit-files 2>/dev/null | grep -q "^${unit}"; then
    info "Removing systemd unit: ${unit}"
    sudo systemctl disable --now "$unit" 2>/dev/null || true
    sudo rm -f "$unit_file"
    sudo systemctl daemon-reload 2>/dev/null || true
    sudo systemctl reset-failed "$unit" 2>/dev/null || true
    ok "${unit} removed."
  else
    info "${unit} already absent — nothing to do."
  fi

  # 2. sysctl persistence file (does not revert running kernel values)
  local sysctl_file="/etc/sysctl.d/99-hts-ai-stack-inotify.conf"
  if [[ -f "$sysctl_file" ]]; then
    info "Removing ${sysctl_file} (running sysctls left in place — reboot to revert)"
    sudo rm -f "$sysctl_file"
    ok "Inotify sysctl persistence removed."
  else
    info "${sysctl_file} already absent — nothing to do."
  fi

  # 3. UFW rules added by _setup_ufw. Match by comment to avoid rule-number
  # drift. Removal is best-effort; absent rules are not an error.
  if command -v ufw >/dev/null 2>&1 && sudo ufw status 2>/dev/null | grep -q 'Status: active'; then
    info "Removing NemoClaw UFW rules (comment-matched)"
    local swap_port="${LLAMA_SWAP_PORT:-8081}"
    local docker_subnet="172.16.0.0/12"
    local tailscale_subnet="100.64.0.0/10"
    local gateway_port="${NEMOCLAW_GATEWAY_PORT:-8084}"
    local sandbox_port=18789
    sudo ufw delete allow from "$docker_subnet" to any port "$swap_port" proto tcp 2>/dev/null || true
    sudo ufw delete deny  "$swap_port"/tcp 2>/dev/null || true
    for _nc_port in "$gateway_port" "$sandbox_port"; do
      sudo ufw delete allow from "$tailscale_subnet" to any port "$_nc_port" proto tcp 2>/dev/null || true
    done
    ok "UFW NemoClaw rules removed (where present)."
  else
    info "UFW inactive or absent — skipping rule removal."
  fi

  ok "NemoClaw host cleanup complete. Sandbox + workspace preserved."
  info "  To restore firewall rules + boot unit:  ./scripts/components/nemoclaw/nemoclaw.sh --start"
  info "  To remove the sandbox too:              ./scripts/components/nemoclaw/nemoclaw.sh --destroy"
}

# nemoclaw_reset — Destroy + re-onboard + start in one shot.
#
# Use this when you want a *clean slate* test (no preserved workspace state,
# no leftover agents.list entries, no stale openclaw config). Distinct from
# `nemoclaw <name> rebuild`, which preserves workspace state and is the right
# tool for upgrading the agent version while keeping memories/journals.
#
# Picks up current `.env` values (NEMOCLAW_MODEL, NEMOCLAW_INFERENCE_TIMEOUT)
# so behavior is config-driven.
#
# Requires explicit confirmation: pass --yes (or NEMOCLAW_RESET_YES=1) — this
# DELETES the sandbox and ALL workspace state inside it.
nemoclaw_rotate_token() {
  local sandbox="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"

  step "NemoClaw — rotate dashboard token"

  warn "Rotating the token will INVALIDATE every existing dashboard tab"
  warn "and mobile session for sandbox '${sandbox}'."

  # NOTE: `nemoclaw <name> config rotate-token` rotates the PROVIDER credential
  # (e.g. COMPATIBLE_API_KEY) — not the dashboard auth token. That's a different
  # value (gateway.auth.token in /sandbox/.openclaw/openclaw.json). To rotate
  # the dashboard token we mint a fresh secret, write it directly into the
  # sandbox's openclaw.json (root-owned, requires _sandbox_root_exec), then
  # bounce the in-sandbox gateway so it re-reads the file.
  local new_token
  new_token=$(python3 -c "import secrets; print(secrets.token_hex(32))" 2>/dev/null)
  if [[ -z "$new_token" ]]; then
    fail "Could not generate new token (python3 missing?)."
    return 1
  fi

  local rotate_script
  rotate_script="
import json, pathlib
p = pathlib.Path('/sandbox/.openclaw/openclaw.json')
d = json.loads(p.read_text())
d.setdefault('gateway', {}).setdefault('auth', {})['token'] = '${new_token}'
p.write_text(json.dumps(d, indent=2))
print('OK')
"
  local result
  result=$(_sandbox_root_exec "$sandbox" "rotok" python3 -c "$rotate_script" 2>&1) || {
    fail "Failed to write new dashboard token in '${sandbox}': ${result}"
    return 1
  }

  _sandbox_root_restart_gw "$sandbox" || warn "Gateway restart reported non-zero — token may not be active until next start."

  # Refresh the tokens file (and print the URL banner) from the now-current value.
  _extract_dashboard_tokens || warn "Token refresh after rotation reported issues — check logs."

  ok "Dashboard token rotated for '${sandbox}'."
}

# nemoclaw_diagnose_chat — collect the data needed to diagnose a "chat hangs"
# symptom. Captures: gateway inference state, host-side llama-swap reachability,
# sandbox-side relay timeout/inference config, and the recent NET:OPEN/FAIL
# pattern (which reveals whether a hidden timeout is killing the stream).
#
# Read-only. Safe to run while a chat is hanging — it doesn't restart anything.
nemoclaw_diagnose_chat() {
  local sandbox="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"
  local swap_port="${LLAMA_SWAP_PORT:-8081}"
  local out_dir="$REPO_DIR/logs"
  mkdir -p "$out_dir"
  local out="$out_dir/nemoclaw-chat-diag-$(date +%Y%m%d-%H%M%S).log"

  step "NemoClaw — diagnose chat hang"
  info "Writing diagnostic bundle to: ${out}"

  {
    echo "=== generated $(date -Is) ==="
    echo
    echo "=== 1. gateway inference state (openshell inference get) ==="
    if command -v openshell &>/dev/null; then
      openshell inference get 2>&1 || true
    else
      echo "openshell CLI not on PATH"
    fi
    echo

    echo "=== 2. dashboard forward listening on :18789 ==="
    ss -tlnp 2>/dev/null | grep 18789 || echo "(no listener — dashboard forward is down)"
    echo

    echo "=== 3. host-side llama-swap (:${swap_port}) /v1/models head ==="
    curl -s --max-time 5 "http://127.0.0.1:${swap_port}/v1/models" \
      | python3 -m json.tool 2>&1 | head -20 || echo "(unreachable)"
    echo

    echo "=== 4. host-side llama-swap warm chat-completion (proves model serves) ==="
    /usr/bin/time -f "elapsed=%e s" -o /tmp/.diag-time \
      curl -s --max-time 60 -X POST "http://127.0.0.1:${swap_port}/v1/chat/completions" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${COMPATIBLE_API_KEY:-not-needed}" \
        -d "{\"model\":\"${NEMOCLAW_MODEL}\",\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}],\"max_tokens\":4,\"stream\":false}" \
        2>&1 | head -5 || true
    echo "  $(cat /tmp/.diag-time 2>/dev/null)"
    rm -f /tmp/.diag-time
    echo

    echo "=== 5. sandbox-side relay/openclaw config (timeout fields) ==="
    if command -v nemoclaw &>/dev/null; then
      nemoclaw "$sandbox" connect <<'INNER' 2>&1 | head -100 || true
echo "--- /sandbox/.openclaw/openclaw.json (timeout/relay fields) ---"
if [[ -r /sandbox/.openclaw/openclaw.json ]]; then
  python3 -c "
import json, sys
d = json.load(open('/sandbox/.openclaw/openclaw.json'))
def walk(o, prefix=''):
    if isinstance(o, dict):
        for k, v in o.items():
            kl = k.lower()
            if any(s in kl for s in ('timeout','provider','baseurl','base_url','api','model','reasoning','stream','protocol')):
                if not isinstance(v, (dict, list)):
                    print(f'  {prefix}{k} = {v}')
            walk(v, prefix + k + '.')
    elif isinstance(o, list):
        for i, item in enumerate(o):
            walk(item, prefix + f'[{i}].')
walk(d)
" 2>&1 | head -60
else
  echo "  (openclaw.json not readable — sandbox may not be running)"
fi
echo
echo "--- env (filtered) ---"
env | grep -iE "timeout|inference|nemoclaw|openclaw|reasoning" | sort | head -30
echo
echo "--- iptables OUTPUT chain (looking for connection-tracking timeouts) ---"
sudo -n iptables -t mangle -L OUTPUT -nv 2>/dev/null | head -10 || true
INNER
    else
      echo "(nemoclaw CLI not available — cannot probe sandbox)"
    fi
    echo

    echo "=== 6. recent NET:OPEN/FAIL/DENIED (last 15 events) ==="
    if command -v nemoclaw &>/dev/null; then
      nemoclaw "$sandbox" logs 2>&1 \
        | grep -E "NET:|router|/v1/|protocol" \
        | tail -30 || true
    fi
    echo

    echo "=== 7. timing analysis (Δ between OPEN and FAIL) ==="
    if command -v nemoclaw &>/dev/null; then
      nemoclaw "$sandbox" logs 2>&1 \
        | grep -E "NET:OPEN|NET:FAIL|NET:.*DENIED" \
        | tail -20 \
        | python3 -c "
import sys, re
last_open = None
for line in sys.stdin:
    m = re.match(r'\[(\d+\.\d+)\]', line)
    if not m: continue
    ts = float(m.group(1))
    if 'NET:OPEN [INFO] ALLOWED' in line:
        last_open = ts
        print(f'  T+0.000  OPEN-ALLOWED  {line.strip()[:120]}')
    elif 'NET:FAIL' in line and last_open:
        print(f'  T+{ts-last_open:6.3f}  FAIL          {line.strip()[:120]}')
    elif 'DENIED' in line and last_open:
        print(f'  T+{ts-last_open:6.3f}  DENIED        {line.strip()[:120]}')
" 2>&1 || true
    fi
    echo

    echo "=== 8. tokens file ==="
      python3 -m json.tool "$REPO_DIR/resources/dashboard/nemoclaw-tokens.json" 2>/dev/null || true
  } 2>&1 | tee "$out"

  echo
  ok "Diagnostic bundle written to: ${out}"
  echo "  Share this file (or its contents) for analysis."
}

nemoclaw_reset() {
  local auto_yes="${1:-${NEMOCLAW_RESET_YES:-0}}"

  step "NemoClaw — reset (destroy → onboard → start)"
  warn "This will PERMANENTLY DELETE sandbox '${NEMOCLAW_SANDBOX_NAME}'"
  warn "and all workspace state inside it. A pre-destroy backup is taken"
  warn "to ${NEMOCLAW_BACKUP_DIR:-~/.nemoclaw/rebuild-backups}/ but restore"
  warn "is manual (this is a clean-slate reset, not a rebuild)."
  echo

  if [[ "$auto_yes" != "1" && "$auto_yes" != "--yes" && "$auto_yes" != "yes" ]]; then
    read -r -p "  Proceed? [y/N]: " reply
    case "$reply" in
      y|Y|yes|YES) ;;
      *) info "Reset cancelled."; return 0 ;;
    esac
  fi

  nemoclaw_destroy
  nemoclaw_onboard
  nemoclaw_install      # idempotent — ensures CLI/openshell pin survived
  nemoclaw_start
  _start_dashboard_forward
  _extract_dashboard_tokens
  nemoclaw_status

  ok "NemoClaw reset complete. Open the dashboard and start a fresh chat."
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"
  RESET_AUTO_YES=0

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)              ACTION="install";              shift ;;
      --configure)            ACTION="configure";            shift ;;
      --start)                ACTION="start";                shift ;;
      --stop)                 ACTION="stop";                 shift ;;
      --restart)              ACTION="restart";              shift ;;
      --status)               ACTION="status";               shift ;;
      --restart-forward)      ACTION="restart-forward";      shift ;;
      --destroy)              ACTION="destroy";              shift ;;
      --onboard)              ACTION="onboard";              shift ;;
      --onboard-fresh)        ACTION="onboard-fresh";        shift ;;
      --recreate-gateway)     ACTION="recreate-gateway";     shift ;;
      --cleanup)              ACTION="cleanup";              shift ;;
      --reset)                ACTION="reset";                shift ;;
      --yes|-y)               RESET_AUTO_YES=1;              shift ;;
      --tokens)               ACTION="tokens";               shift ;;
      --rotate-token)         ACTION="rotate-token";         shift ;;
      --diagnose-chat)        ACTION="diagnose-chat";        shift ;;
      --update)               ACTION="update";               shift ;;
      --backup-premigration)  ACTION="backup-premigration";  shift ;;
      *)
        echo "[ERROR] Unknown option: $1" >&2
        echo "Run with --help to see available actions." >&2
        exit 2
        ;;
    esac
  done

  case "$ACTION" in
    install)              nemoclaw_install              ;;
    configure)            nemoclaw_configure            ;;
    backup-premigration)  nemoclaw_backup_premigration  ;;
    start)
      nemoclaw_install
      _setup_ufw    # idempotent; self-heals UFW after --cleanup
      nemoclaw_start
      _start_dashboard_forward
      _extract_dashboard_tokens
      ;;
    stop)             nemoclaw_stop                 ;;
    restart)          nemoclaw_restart              ;;
    status)           nemoclaw_status               ;;
    restart-forward)
      # NVIDIA quickstart §"Restart the Port Forward" — single-shot recovery.
      _start_dashboard_forward
      _extract_dashboard_tokens
      ;;
    destroy)   nemoclaw_destroy              ;;
    onboard)   nemoclaw_onboard              ;;
    onboard-fresh)
      # Wrapper for `nemoclaw onboard --fresh` that injects the unattended
      # provider env (NEMOCLAW_PROVIDER=custom → llama-swap, --non-interactive,
      # llama-swap pre-flight, model warm-up, log capture). Use after the
      # NVIDIA installer's embedded onboard hits a stale session marker.
      export NEMOCLAW_FRESH=1
      nemoclaw_onboard
      ;;
    recreate-gateway)
      # Force-recreate the OpenShell gateway containers, then onboard --fresh.
      # Use when an openshell-version bump has left the running gateway
      # wire-incompatible with the new client (symptom: nemoclaw onboard
      # exits mid-[4/8] with "transport error / Connection reset by peer").
      _force_recreate_gateway
      export NEMOCLAW_FRESH=1
      nemoclaw_onboard
      ;;
    reset)     nemoclaw_reset "$RESET_AUTO_YES" ;;
    cleanup)   nemoclaw_cleanup              ;;
    tokens)    _extract_dashboard_tokens     ;;
    rotate-token) nemoclaw_rotate_token       ;;
    diagnose-chat) nemoclaw_diagnose_chat     ;;
    update)
      _update_openclaw
      _start_dashboard_forward
      _extract_dashboard_tokens
      ;;
    default)
      nemoclaw_install
      _fix_cgroups
      nemoclaw_onboard
      nemoclaw_status
      ;;
  esac
fi
