# Observability & Audit Trail

**Priority:** HIGH
**Effort:** 8-12 hours
**Risk:** Low — additive infrastructure. No behavioral change to existing services.
**Target Release:** v0.5.0
**Implementation Plan:** [SECURITY-005-observability-plan.md](../../planning/SECURITY-005-observability-plan.md)
**Threat:** Unobservable stack is undetectable compromise. Prompt injection, anomalous agent
behavior, and policy violations cannot be detected or investigated without centralized logging.
**Depends on:** Nothing
**Blocks:** SECURITY-007 (persona integrity needs audit data for drift detection)

## Problem

No centralized log aggregation across the stack. Each container logs to its own stdout,
visible only via `docker logs`. There is no unified search, no alerting, and no retention
policy for logs. Prometheus collects metrics but not logs.

Without observability:

- Prompt injection attempts are invisible
- Agent behavior drift cannot be measured
- OpenShell policy violations are logged locally inside the sandbox but not aggregated
- Incident response requires manual `docker logs` across 12+ containers

Papers 2603.22868 (Agent-Sentry) and 2602.11416 (Security-Aware Planning) both assume
runtime telemetry as a prerequisite for their security models.

## Solution

Deploy a lightweight log aggregation stack alongside existing Prometheus metrics:

1. **Loki** — log aggregation (pairs with existing Grafana)
2. **Promtail** — Docker log shipper to Loki
3. **Grafana dashboards** — unified log search + alerting

This avoids the weight of a full ELK stack while providing searchable, correlated logs
across all containers.

## Implementation Steps

### 1. Add Loki + Promtail to `docker-compose.yml`

Loki for storage, Promtail scrapes Docker container logs via the Docker socket.

### 2. Add Grafana datasource for Loki

Auto-provision via `resources/grafana/provisioning/datasources/`.

### 3. Create alert rules

Priority alerts:

- OpenShell policy violation patterns in NemoClaw logs
- Authentication failures in Open WebUI / Grafana
- Unusual model load patterns in Ollama (potential abuse)
- Container restart loops

### 4. Log retention policy

Configure Loki retention (7-day default, configurable via stack.json).

## Acceptance Criteria

- [ ] All container logs searchable from Grafana
- [ ] Alert fires on simulated auth failure
- [ ] Logs rotate after configured retention period
- [ ] No PII stored in logs (scrub patterns configured)

## Paper References

- 2603.22868 — Agent-Sentry: behavioral bounding requires execution telemetry
- 2602.11416 — Security-aware planning needs observability for autonomy metrics
- Session 1 finding H2
