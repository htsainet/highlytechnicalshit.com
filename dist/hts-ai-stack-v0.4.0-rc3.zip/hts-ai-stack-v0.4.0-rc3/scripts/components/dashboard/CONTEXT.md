# Dashboard Component

Last updated: 2026-04-17

## What happens here

The dashboard is the stack's landing page — a local web UI showing
installed services, their health status, and quick-access links.
Runs on nginx with a reverse proxy for health probes and auth bridging.

## Files and structure

| File | Purpose |
|------|---------|
| `dashboard.sh` | Full lifecycle: install, configure, start, stop, health |
| `dashboard.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |

## Architecture

The dashboard runs as an **nginx:1.29-alpine** container serving static
files with two proxy features:

### Health probe proxy

`GET /api/probe/<docker-service>/<internal-port>/<path>`

Nginx proxies to Docker containers via Docker DNS (resolver 127.0.0.11).
This eliminates CORS failures that occur when the browser tries to
fetch cross-port health endpoints directly. The dashboard JS uses this
proxy for all Docker-hosted services; host-native services use direct
`no-cors` fetch.

- Config: `config/dashboard-nginx.conf`
- `internalPort` in `services.json` must match the container-side port
  (right side of docker-compose port mapping), NOT the host port.

### Cookie auth bridge

`GET /api/auth-bridge?target=<url>&cookie=<name>&value=<val>`

For services using cookie-based authentication (e.g., Claw3D's
`studio_access` cookie), this endpoint serves a tiny HTML page that
sets the cookie on localhost and redirects to the target URL.
Per RFC 6265, cookies on `localhost` apply to all ports, so setting
the cookie on port 80 (dashboard) makes it available on port 3006
(Claw3D) etc.

Services opt in via the `cookieAuth` field in `services.json`:
```json
{
  "cookieAuth": {
    "name": "studio_access",
    "envVar": "CLAW3D_ACCESS_TOKEN",
    "default": "hts-claw3d-local"
  }
}
```

### Notifications

The dashboard loads `notifications.json` (if present) on boot and
refresh. Each notification can display an action button on a service
card:

```json
[{
  "service": "paperclip",
  "label": "ACCEPT INVITE",
  "url": "http://127.0.0.1:3101/invite/pcp_bootstrap_...",
  "expires": "2026-04-20T13:15:38.742Z"
}]
```

Expired notifications are automatically hidden. Currently used by
Paperclip to surface bootstrap CEO invite URLs.
