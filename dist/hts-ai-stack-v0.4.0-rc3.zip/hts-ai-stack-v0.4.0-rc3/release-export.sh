#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────
# release-export.sh — Export a scrubbed snapshot to the release repo
#
# Usage:
#   ./release-export.sh [--dry-run]
#
# What it does:
#   1. Exports the current git HEAD to a temp directory
#   2. Removes personal/dev-only files
#   3. Replaces private org URLs with release org URLs
#   4. Redacts personal references
#   5. Adds content disclaimers where needed
#   6. Initializes a fresh git repo and commits
#   7. Pushes to the release repo (unless --dry-run)
# ─────────────────────────────────────────────────────────────────────
set -euo pipefail

# ── Configuration ──────────────────────────────────────────────────
SOURCE_REPO="$(cd "$(dirname "$0")" && pwd)"
RELEASE_ORG="htsai-net"
RELEASE_REPO="hts-ai-stack-release"
RELEASE_URL="https://github.com/${RELEASE_ORG}/${RELEASE_REPO}"
RELEASE_CLONE_URL="${RELEASE_URL}.git"

PRIVATE_ORG="htsainet"
PRIVATE_REPO="hts-ai-stack"

EXPORT_DIR="/tmp/hts-release-export"
DRY_RUN=false

# ── Parse flags ────────────────────────────────────────────────────
[[ "${1:-}" == "--dry-run" ]] && DRY_RUN=true

# ── Colors ─────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "${GREEN}[export]${NC} $*"; }
warn() { echo -e "${YELLOW}[export]${NC} $*"; }
err()  { echo -e "${RED}[export]${NC} $*" >&2; }

# ── Files/dirs to EXCLUDE from export ──────────────────────────────
EXCLUDE_FILES=(
  # Personal / dev-only notes
  "brainstorming.md"
  "ideas.md"
  "ides for setup flow with json obhects.md"

  # Internal refactor planning
  "refactor/CONTEXT.md"
  "refactor/REFERENCES.md"

  # Runtime logs (only tracked one)
  "logs/upstream-watch.log"

  # Post-commit hook that syncs to private website repo
  ".githooks/post-commit"

  # Feature doc describing private→public mirror strategy
  "docs/development/features/FEATURE-016.md"

  # This script itself
  "release-export.sh"
)

EXCLUDE_DIRS=(
  # Refactor directory (internal planning)
  "refactor"
)

# ── URL / reference replacements ───────────────────────────────────
# Each entry: "search|replacement"
REPLACEMENTS=(
  # GitHub org references: private repo → release repo
  # NOTE: highlytechnicalshit.com refs are the PUBLIC website — keep those as-is
  "github.com/${PRIVATE_ORG}/${PRIVATE_REPO}|github.com/${RELEASE_ORG}/${RELEASE_REPO}"
  "raw.githubusercontent.com/${PRIVATE_ORG}/${PRIVATE_REPO}|raw.githubusercontent.com/${RELEASE_ORG}/${RELEASE_REPO}"

  # Personal GitHub username
  "github.com/timjore/hts-ai-stack|github.com/${RELEASE_ORG}/${RELEASE_REPO}"

  # gh repo clone reference
  "gh repo clone ${PRIVATE_ORG}/${PRIVATE_REPO}|gh repo clone ${RELEASE_ORG}/${RELEASE_REPO}"
)

# ── Lines to redact from specific files ────────────────────────────
# Format: "file|line_pattern|replacement_line"
REDACTIONS=(
  # CONTEXT.md: remove private/public repo strategy lines
  'CONTEXT.md|Org Private Repo|Repo: https://github.com/'"${RELEASE_ORG}/${RELEASE_REPO}"
  'CONTEXT.md|Org Public Repo|'
  # post-commit references to highlytechnicalshit.com are excluded (file removed)
)

# ═══════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════

log "Starting release export from: ${SOURCE_REPO}"
log "Target repo: ${RELEASE_URL}"
$DRY_RUN && warn "DRY RUN — will not push"
echo ""

# ── Step 1: Clean export directory ─────────────────────────────────
log "Step 1/7: Preparing export directory..."
rm -rf "${EXPORT_DIR}"
mkdir -p "${EXPORT_DIR}"

# ── Step 2: Export tracked files via git archive ───────────────────
log "Step 2/7: Exporting git HEAD (tracked files only)..."
cd "${SOURCE_REPO}"
git archive HEAD | tar -x -C "${EXPORT_DIR}"

FILE_COUNT=$(find "${EXPORT_DIR}" -type f | wc -l)
log "  Exported ${FILE_COUNT} files"

# ── Step 3: Remove excluded files and directories ──────────────────
log "Step 3/7: Removing personal/dev-only files..."
REMOVED=0

for dir in "${EXCLUDE_DIRS[@]}"; do
  target="${EXPORT_DIR}/${dir}"
  if [[ -d "$target" ]]; then
    rm -rf "$target"
    log "  ✗ ${dir}/ (directory)"
    REMOVED=$((REMOVED + 1))
  fi
done

for file in "${EXCLUDE_FILES[@]}"; do
  target="${EXPORT_DIR}/${file}"
  if [[ -f "$target" ]]; then
    rm -f "$target"
    log "  ✗ ${file}"
    REMOVED=$((REMOVED + 1))
  fi
done

log "  Removed ${REMOVED} items"

# ── Step 4: Apply URL replacements ─────────────────────────────────
log "Step 4/7: Replacing private org URLs with release URLs..."
REPLACED=0

for entry in "${REPLACEMENTS[@]}"; do
  search="${entry%%|*}"
  replace="${entry##*|}"

  # Find files containing the search string (binary-safe skip)
  while IFS= read -r file; do
    if grep -q "$search" "$file" 2>/dev/null; then
      # Use perl for reliable in-place replacement (no sed -i portability issues)
      perl -pi -e "s|\Q${search}\E|${replace}|g" "$file"
      log "  ↻ ${file#${EXPORT_DIR}/}: ${search} → ${replace}"
      REPLACED=$((REPLACED + 1))
    fi
  done < <(find "${EXPORT_DIR}" -type f -name '*.sh' -o -name '*.md' -o -name '*.json' -o -name '*.jsonc' -o -name '*.py' -o -name '*.yml' -o -name '*.yaml' -o -name '*.html')
done

log "  ${REPLACED} replacements made"

# ── Step 5: Apply line-level redactions ────────────────────────────
log "Step 5/7: Redacting personal references..."

for entry in "${REDACTIONS[@]}"; do
  IFS='|' read -r file pattern replacement <<< "$entry"
  target="${EXPORT_DIR}/${file}"

  if [[ -f "$target" ]] && grep -q "$pattern" "$target" 2>/dev/null; then
    if [[ -z "$replacement" ]]; then
      # Delete the line
      perl -ni -e "print unless /\Q${pattern}\E/" "$target"
      log "  ✗ ${file}: removed line matching '${pattern}'"
    else
      # Replace the line
      perl -pi -e "s|^.*\Q${pattern}\E.*\$|${replacement}|" "$target"
      log "  ↻ ${file}: redacted line matching '${pattern}'"
    fi
  fi
done

# ── Step 6: Add content disclaimers ────────────────────────────────
log "Step 6/7: Adding content disclaimers..."

# caco-bot disclaimer
CACO_DIR="${EXPORT_DIR}/resources/agents/caco-bot"
if [[ -d "$CACO_DIR" ]]; then
  cat > "${CACO_DIR}/DISCLAIMER.md" << 'DISCLAIMER'
# Content Disclaimer

The caco-bot persona is a **fictional character** designed as a retro-gaming
enthusiast with a deliberately provocative personality. It contains:

- Strong language and profanity (in-character)
- Opinionated hot-takes on gaming topics
- Deliberately confrontational conversational style

This persona is provided as an **example of character-driven agent design**.
It includes a PRIME DIRECTIVE that prohibits instructions related to real
violence, self-harm, illegal activity, or genuine harassment.

**This content does not reflect the views of the project maintainers.**
DISCLAIMER
  log "  + resources/agents/caco-bot/DISCLAIMER.md"
fi

# ── Step 7: Verify no secrets leaked ───────────────────────────────
log "Step 7/7: Final security scan..."
LEAK_COUNT=0

# Scan for known sensitive patterns (actual secret VALUES, not code referencing secret files)
while IFS= read -r match; do
  err "  ⚠ POSSIBLE LEAK: ${match}"
  LEAK_COUNT=$((LEAK_COUNT + 1))
done < <(grep -rn \
  -e 'timjore' \
  -e 'tim@htsai' \
  -e 'M@Nt' \
  -e 'WEBUI_SECRET_KEY=[a-f0-9]\{8,\}' \
  --include='*.sh' --include='*.md' --include='*.json' --include='*.py' \
  --include='*.yml' --include='*.yaml' --include='*.html' \
  "${EXPORT_DIR}" 2>/dev/null || true)

# Also check for the private org name (should all be replaced)
while IFS= read -r match; do
  # Allow: cspell dictionary, git history refs, highlytechnicalshit.com (public website)
  if echo "$match" | grep -qv 'cspell\|commit\|Merge.*pull\|highlytechnicalshit'; then
    err "  ⚠ UNREPLACED PRIVATE ORG: ${match}"
    LEAK_COUNT=$((LEAK_COUNT + 1))
  fi
done < <(grep -rn "${PRIVATE_ORG}" \
  --include='*.sh' --include='*.md' --include='*.json' --include='*.py' \
  --include='*.yml' --include='*.yaml' --include='*.html' \
  "${EXPORT_DIR}" 2>/dev/null || true)

echo ""
if (( LEAK_COUNT > 0 )); then
  err "═══════════════════════════════════════════════"
  err " RELEASE BLOCKED: ${LEAK_COUNT} potential leak(s) found!"
  err " Review findings above and fix before pushing."
  err "═══════════════════════════════════════════════"
  if ! $DRY_RUN; then
    err "Export directory preserved at: ${EXPORT_DIR}"
    exit 1
  fi
else
  log "✅ No secrets or personal data detected"
fi

# ── Final stats ────────────────────────────────────────────────────
FINAL_COUNT=$(find "${EXPORT_DIR}" -type f | wc -l)
log ""
log "═══════════════════════════════════════════════"
log " Export complete: ${FINAL_COUNT} files in ${EXPORT_DIR}"
log "═══════════════════════════════════════════════"

if $DRY_RUN; then
  warn "DRY RUN complete. Inspect ${EXPORT_DIR} then run without --dry-run to push."
  exit 0
fi

# ── Initialize and push ───────────────────────────────────────────
log ""
log "Initializing release repo and pushing..."

cd "${EXPORT_DIR}"
git init -b main
git add -A
git commit -m "v0.4.0-rc1: initial release snapshot

Scrubbed export from hts-ai-stack private repo.
Includes: htsclaw sandbox, security hardening, health timer,
monitoring stack, agent personas, dashboard integration.

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"

git remote add origin "${RELEASE_CLONE_URL}"
git push -u origin main --force

log ""
log "═══════════════════════════════════════════════"
log " ✅ Released to: ${RELEASE_URL}"
log " Bootstrap: bash <(curl -fsSL ${RELEASE_URL/github.com/raw.githubusercontent.com}/refs/heads/main/bootstrap.sh)"
log "═══════════════════════════════════════════════"
