# BitNet Component

Last updated: 2026-04-15

## What happens here

BitNet provides 1-bit LLM inference — extremely efficient models that run
on CPU without a GPU. Used in the stack as a lightweight fallback inference
engine alongside Ollama.

## Files and structure

| File | Purpose |
|------|---------|
| `bitnet.sh` | Full lifecycle: install, configure, start, stop, health |
| `bitnet.manifest.json` | Component metadata, config schema, dashboard entry |
| `CONTEXT.md` | This file — component-level context |
| `REFERENCES.md` | Upstream links and documentation |
