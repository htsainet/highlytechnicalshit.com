# Aider Component — REFERENCES

## Official

- Homepage / docs: <https://aider.chat>
- Install docs: <https://aider.chat/docs/install.html>
- LLM / model connection docs: <https://aider.chat/docs/llms.html>
- Architect mode (tiered reasoning): <https://aider.chat/2024/09/26/architect.html>
- Config file reference: <https://aider.chat/docs/config/aider_conf.html>
- GitHub: <https://github.com/Aider-AI/aider>
- PyPI: <https://pypi.org/project/aider-chat/>

## pipx (install tool)

- Docs: <https://pipx.pypa.io/stable/>

## OpenAI-compatible / LiteLLM routing

- LiteLLM docs: <https://docs.litellm.ai/>
- Aider with OpenAI-compatible endpoints: <https://aider.chat/docs/llms/openai-compat.html>

## Vendor-instruction deviations

None. Install follows upstream instructions exactly (pipx). No entry in
`/DEVIATIONS.md` is required for this component.

The host-install-vs-container decision is a project-policy choice, not a
vendor deviation — see `CONTEXT.md § Why host-installed and not
containerized?`.

## Related components in this stack

- llama-swap: <https://github.com/mostlygeek/llama-swap> — preferred backend
- ollama: <https://ollama.com> — model provider behind llama-swap
- OpenCode: <https://opencode.ai> — alternative terminal coding agent
- CrewAI: <https://docs.crewai.com> — multi-agent orchestration (different use case)

## Related features

- FEATURE-054 — Developer Tools Suite (OpenCode, Aider, Tabby, Gitea Runner)
- FEATURE-064 — Starter Model Pull + Day-2 Upgrade Command (`model-select.sh`)
- FEATURE-067 — Aider Coding-Tier Preset (architect + editor via llama-swap)
