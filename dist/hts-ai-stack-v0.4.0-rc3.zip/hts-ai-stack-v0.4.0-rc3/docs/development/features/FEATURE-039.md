# FEATURE-039 — ComfyUI: GPU Image Generation Service

## Metadata

| Field | Value |
|-------|-------|
| **Priority** | MEDIUM |
| **Effort** | 1 day |
| **Risk** | Low — optional profile, no impact on core stack |
| **Target Release** | v0.6.0 |
| **Depends on** | FEATURE-005 (Deferred Services re-enablement) |
| **Blocks** | Nothing |

## Problem

ComfyUI is a node-based Stable Diffusion workflow UI that benefits from the
NVIDIA GPU already in the stack. It was wired into the pipeline but not fully
operational due to data persistence and container startup issues.

## Solution

Integrate ComfyUI as an optional `--profile comfyui` service using the
`mmartial/comfyui-nvidia-docker` image with bind-mount data directories.

### Data Layout

| Host path | Container path | Purpose |
|-----------|----------------|---------|
| `./data/comfyui/run` | `/comfy/mnt` | ComfyUI venv + source (persists across restarts) |
| `./data/comfyui/basedir` | `/basedir` | Models, outputs, custom nodes, user data |

Bind mounts are used instead of named Docker volumes because the image's
init script enforces ownership checks (`WANTED_UID`/`WANTED_GID`) and named
volumes are always created `root:root` with no pre-start chown mechanism.

### Key Configuration

```yaml
environment:
  - BASE_DIRECTORY=/basedir
  - SECURITY_LEVEL=normal
  - WANTED_UID=${COMFYUI_UID:-1000}
  - WANTED_GID=${COMFYUI_GID:-1000}
  - COMFY_CMDLINE_EXTRA=--listen 0.0.0.0
```

- `WANTED_UID`/`WANTED_GID` match the host caller via `id -u` / `id -g` written
  to `.env` during `comfyui_configure()`
- `COMFY_CMDLINE_EXTRA=--listen 0.0.0.0` is the correct env var for this image
  (not `CLI_ARGS`)
- `start_period: 600s` — first-run installs PyTorch + ComfyUI (~5–10 min)

### Port

| Service | Host Port | Container Port |
|---------|-----------|----------------|
| ComfyUI UI | `8188` | `8188` |

### Usage

```bash
./scripts/components/comfyui/comfyui.sh               # install + start + seed models
./scripts/components/comfyui/comfyui.sh --seed-models # download checkpoints only
./scripts/components/comfyui/comfyui.sh --health      # probe health
./scripts/components/comfyui/comfyui.sh --stop        # stop ComfyUI
```

## Acceptance Criteria

- [ ] `./scripts/components/comfyui/comfyui.sh` installs and starts ComfyUI cleanly
- [ ] ComfyUI UI reachable at `http://localhost:8188`
- [ ] GPU visible inside container (`nvidia-smi` shows RTX 3060)
- [ ] Models persist across container restarts (`./data/comfyui/basedir/models/`)
- [ ] venv persists across restarts (`./data/comfyui/run/`) — subsequent starts < 30s
- [ ] `--seed-models` downloads SD 1.5 base and optional checkpoints
- [ ] `nuke-stack.sh` cleans up `./data/comfyui/` or documents manual step
