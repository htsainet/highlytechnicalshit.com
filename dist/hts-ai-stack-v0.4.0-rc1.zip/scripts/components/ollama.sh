#!/usr/bin/env bash
# scripts/components/ollama.sh — Ollama LLM inference: install, models, health
#
# Standalone usage:
#   ./scripts/components/ollama.sh                # install + start + health
#   ./scripts/components/ollama.sh --pull-models   # pull all prod models from registry
#   ./scripts/components/ollama.sh --swap lean     # load lean chat model
#   ./scripts/components/ollama.sh --swap mean     # load mean chat model
#   ./scripts/components/ollama.sh --swap claw     # load claw chat model
#   ./scripts/components/ollama.sh --health        # health check only
#   ./scripts/components/ollama.sh --stop          # stop Ollama
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
OLLAMA_CONTAINER="${OLLAMA_CONTAINER:-hts-ai-ollama-gpu}"
OLLAMA_PORT="${OLLAMA_PORT:-11434}"
OLLAMA_BASE_URL="${OLLAMA_BASE_URL:-http://localhost:${OLLAMA_PORT}}"
OLLAMA_MODEL="${OLLAMA_MODEL:-gemma4:e4b}"
CLAW_MODEL="${CLAW_MODEL:-deepseek-r1:14b}"
REGISTRY_FILE="$REPO_DIR/scripts/install/models/registry.json"

# ── Functions ─────────────────────────────────────────────────────────────────

# ollama_install — Pull the Ollama Docker image via compose
ollama_install() {
  step "Ollama — build image"
  compose_build --profile ollama-gpu
  ok "Ollama image built."
}

# ollama_configure — Ensure .env has required Ollama keys
ollama_configure() {
  step "Ollama — configure"
  local env_file="$REPO_DIR/.env"

  _ensure_key() {
    local key="$1" default="$2"
    if ! grep -q "^${key}=" "$env_file" 2>/dev/null; then
      printf '%s=%s\n' "$key" "$default" >> "$env_file"
      info "Added ${key}=${default} to .env"
    fi
  }

  _ensure_key "OLLAMA_PORT" "$OLLAMA_PORT"
  _ensure_key "OLLAMA_BASE_URL" "$OLLAMA_BASE_URL"
  _ensure_key "OLLAMA_MODEL" "$OLLAMA_MODEL"
  ok "Ollama .env keys verified."
}

# ollama_start — Bring up Ollama via compose (with exclusivity guard)
ollama_start() {
  step "Ollama — start"
  compose_up --profile ollama-gpu
  ok "Ollama container started."
}

# ollama_stop — Bring down Ollama
ollama_stop() {
  step "Ollama — stop"
  compose_down --profile ollama-gpu
  ok "Ollama stopped."
}

# ollama_health — Probe the Ollama API
ollama_health() {
  health_probe "Ollama :${OLLAMA_PORT}" "${OLLAMA_BASE_URL}/api/tags"
}

# ollama_swap_model <model> — Pull and warm a specific model
ollama_swap_model() {
  local model="$1"
  echo -e "\n${CYAN}${BOLD}┌──────────────────────────────────────────────────┐${NC}"
  echo -e "${CYAN}${BOLD}│  Downloading model: ${model}$(printf '%*s' $((28 - ${#model})) '')│${NC}"
  echo -e "${CYAN}${BOLD}└──────────────────────────────────────────────────┘${NC}\n"
  docker exec "$OLLAMA_CONTAINER" ollama pull "$model" 2>&1
  info "Warming $model (10m keep_alive)..."
  curl -s "${OLLAMA_BASE_URL}/api/generate" \
    -d "{\"model\":\"${model}\",\"keep_alive\":\"10m\",\"prompt\":\"\"}" >/dev/null 2>&1 || true
  ok "ollama → $model loaded"
}

# ollama_pull_models [--all|--model NAME]
# Reads registry.json and pulls prod models. With --all pulls all envs.
ollama_pull_models() {
  local pull_all=false
  local specific_model=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --all)   pull_all=true; shift ;;
      --model) specific_model="$2"; shift 2 ;;
      *)       shift ;;
    esac
  done

  if [[ ! -f "$REGISTRY_FILE" ]]; then
    warn "Registry file not found: $REGISTRY_FILE — skipping model pull."
    return 0
  fi

  step "Ollama — pull models"

  if [[ -n "$specific_model" ]]; then
    _ollama_pull_if_missing "$specific_model"
    return
  fi

  local filter='.ollama[]'
  if [[ "$pull_all" == false ]]; then
    filter='.ollama[] | select(.env[] == "prod")'
  fi

  local models
  models=$(jq -r "$filter | .model" "$REGISTRY_FILE" 2>/dev/null) || {
    warn "Failed to parse registry.json"
    return 1
  }

  while IFS= read -r model; do
    [[ -z "$model" ]] && continue
    _ollama_pull_if_missing "$model"
  done <<< "$models"

  ok "Model pull complete."
}

# ── Internal helpers ──────────────────────────────────────────────────────────

# _ollama_pull_if_missing <model> — Pull a model if not already in Ollama
_ollama_pull_if_missing() {
  local model="$1"
  local model_base="${model%%:*}"

  if curl -s "${OLLAMA_BASE_URL}/api/tags" 2>/dev/null | grep -q "\"${model_base}\""; then
    info "Already present: $model"
  else
    # Check NAS cache first
    local nas_cache="${NAS_MODEL_CACHE:-/mnt/nas/llm-cache/ollama}"
    if [[ -d "$nas_cache" ]] && docker exec "$OLLAMA_CONTAINER" test -d /home/ollama/.ollama/models 2>/dev/null; then
      info "Pulling $model (checking NAS cache at $nas_cache)..."
    fi
    echo -e "\n${CYAN}${BOLD}┌──────────────────────────────────────────────────┐${NC}"
    echo -e "${CYAN}${BOLD}│  Downloading model: ${model}$(printf '%*s' $((28 - ${#model})) '')│${NC}"
    echo -e "${CYAN}${BOLD}└──────────────────────────────────────────────────┘${NC}\n"
    docker exec "$OLLAMA_CONTAINER" ollama pull "$model" \
      && ok "$model pulled." \
      || warn "$model failed to pull — check name/connectivity."
  fi
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"
  SWAP_MODE=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --pull-models) ACTION="pull"; shift ;;
      --swap)        ACTION="swap"; SWAP_MODE="$2"; shift 2 ;;
      --health)      ACTION="health"; shift ;;
      --stop)        ACTION="stop"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      ollama_install
      ollama_configure
      ollama_start
      ollama_health
      ;;
    pull)
      ollama_pull_models --all
      ;;
    swap)
      case "$SWAP_MODE" in
        lean) ollama_swap_model "smollm2:135m" ;;
        mean) ollama_swap_model "$OLLAMA_MODEL" ;;
        claw) ollama_swap_model "$CLAW_MODEL" ;;
        *)    fail "Unknown swap mode: $SWAP_MODE (use lean|mean|claw)" ;;
      esac
      ;;
    health)
      ollama_health
      ;;
    stop)
      ollama_stop
      ;;
  esac
fi
