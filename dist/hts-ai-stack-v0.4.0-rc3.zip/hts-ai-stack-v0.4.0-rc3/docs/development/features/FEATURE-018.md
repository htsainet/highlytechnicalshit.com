# Alternative Inference Backends — vLLM and llama.cpp

**Priority:** LOW
**Effort:** 8–12 hours
**Risk:** Low — additive; does not replace existing Ollama/llama-swap stack.
**Target Release:** v0.6.0
**Depends on:** Nothing
**Blocks:** Nothing

## Problem

The stack currently uses Ollama (GPU inference) and llama-swap (model routing)
as its inference layer. Alternative backends may offer better performance,
different model format support, or architectural flexibility for specific
workloads.

## Solution

Evaluate and optionally integrate two alternative inference backends:

### vLLM

- High-throughput serving with PagedAttention
- OpenAI-compatible API
- Better batched inference performance for multi-user scenarios
- GPU-focused — complements Ollama for high-throughput workloads

### llama.cpp

- Lightweight C++ inference with broad model format support (GGUF)
- CPU-optimized with optional GPU offloading
- Lower memory footprint than Ollama for small models
- Direct GGUF loading without Ollama's Modelfile abstraction

## Implementation Steps

### Phase 1 — Evaluation

Benchmark both backends against Ollama on the current hardware:

- Tokens/second (single user, batched)
- Memory usage (idle, loaded, inference)
- Model load time
- API compatibility with llama-swap

### Phase 2 — Docker Integration

If evaluation shows clear benefits for specific workloads:

- Add Docker Compose service definitions
- Integrate with llama-swap as additional backends
- Update dashboard with new service cards

### Phase 3 — Documentation

- Document when to use each backend (use-case matrix)
- Update architecture diagrams
- Add configuration examples

## Port Allocation

Ports TBD — reserve in REFERENCES.md Host Port Map during implementation.

## Acceptance Criteria

- [ ] Benchmark comparison completed (Ollama vs vLLM vs llama.cpp)
- [ ] Decision documented: adopt, defer, or reject each backend
- [ ] If adopted: Docker service running and accessible via llama-swap
- [ ] Performance comparison documented in planning docs
