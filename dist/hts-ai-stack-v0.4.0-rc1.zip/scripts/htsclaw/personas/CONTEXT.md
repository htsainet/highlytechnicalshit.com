# Personas — Agent Identity Provisioning

Last updated: 2026-04-11 10:00:00

## What happens here

Uploads SOUL.md and IDENTITY.md files into sandbox workspaces so each OpenClaw
agent has a distinct personality, system prompt, and behavioral constraints.
Ported from NemoClaw's `_provision_agent_personas()` function.

## Files and structure

| File | Purpose |
|------|---------|
| `provision.sh` | Upload persona files + configure multi-agent routing inside sandbox |

## How it works

1. Reads agent definitions from `resources/agents/<agent-name>/`
2. Creates workspace directories inside sandbox via `openshell sandbox exec`
3. Uploads SOUL.md, IDENTITY.md, and shared AGENTS.md via `openshell sandbox upload`
4. Configures `openclaw config set` for per-agent model routing

## Process

1. Read agent definitions from `resources/agents/<agent-name>/`
2. Create workspace directories inside sandbox
3. Upload SOUL.md, IDENTITY.md, and shared AGENTS.md
4. Configure per-agent model routing via `openclaw config set`

## Source files (not in this folder)

Persona content lives in `resources/agents/` — this folder only has the
provisioning script. Keeping content and provisioning separate means personas
are reusable across sandbox engines (htsclaw, NemoClaw, or future alternatives).

## Key difference from NemoClaw

NemoClaw uses `containerd exec` (uid 0) for root-owned files inside the sandbox.
htsclaw uses `openshell sandbox exec` and `openshell sandbox upload` directly —
same underlying mechanism, but without the NemoClaw ceremony.

## Tools and dependencies

- **openshell CLI** — sandbox exec and file upload commands
- **openclaw** — config set for per-agent model routing

## What good looks like

- Personas injected on first setup and on upgrade (not lost between recreates)
- SHA256 baseline for drift detection (SECURITY-007 compliance)
- Persona files read-only inside sandbox
- Multi-agent routing works: each agent gets its own model assignment
