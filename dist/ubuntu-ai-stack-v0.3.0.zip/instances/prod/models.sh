#!/usr/bin/env bash
set -euo pipefail
# ─────────────────────────────────────────────────────────────────────────────
# instances/prod/models.sh
# Seeds ollama-prod with approved models and starts sd-prod.
# Leaves both containers RUNNING after completion.
# ─────────────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
HELPERS="${REPO_ROOT}/scripts/install/models/helpers.sh"
export COMPOSE_FILE="$SCRIPT_DIR/docker-compose.yml"

if [[ ! -f "$HELPERS" ]]; then
  echo "[FAIL] helpers.sh not found at $HELPERS" >&2
  exit 1
fi
source "$HELPERS"

OLLAMA_CONTAINER="ollama-prod"
OLLAMA_PORT="11434"
OLLAMA_DEFAULT="qwen2.5:7b-instruct-q4_K_M"
SD_SERVICE="stable-diffusion-prod"

# ─────────────────────────────────────────────────────────────────────────────
# PROD OLLAMA MODELS
# Vetted, stable models only. Test in ollama-test before adding here.
# ─────────────────────────────────────────────────────────────────────────────
OLLAMA_MODELS_PROD=(
  "phi3.5:latest"
  "smollm2:135m"
  "qwen3.5:0.8b"
  "qwen3.5:9b"
  "qwen2.5:7b-instruct-q4_K_M"
  "mistral-nemo:latest"
  "gurubot/ollamatron:8b-q4_K_M"
  "granite3.1-dense:8b"
)

# ─────────────────────────────────────────────────────────────────────────────

step "0 — Host directories"
create_model_dirs

# ── Step 1: Ollama prod ───────────────────────────────────────────────────────
step "1 — Ollama prod models"

start_container "$OLLAMA_CONTAINER"
wait_for_ollama "$OLLAMA_CONTAINER" "$OLLAMA_PORT"

info "Pulling default model first: $OLLAMA_DEFAULT"
pull_ollama_if_missing "$OLLAMA_CONTAINER" "$OLLAMA_PORT" "$OLLAMA_DEFAULT"

info "Pulling remaining prod models in background..."
pids=()
for model in "${OLLAMA_MODELS_PROD[@]}"; do
  if [[ "$model" == "$OLLAMA_DEFAULT" ]]; then
    continue
  fi
  (
    pull_ollama_if_missing "$OLLAMA_CONTAINER" "$OLLAMA_PORT" "$model"
  ) &
  pids+=("$!")
done

for pid in "${pids[@]}"; do
  wait "$pid"
done
ok "All prod ollama models are ready."

# ── Step 2: Stable Diffusion prod ────────────────────────────────────────────
step "2 — Stable Diffusion prod"
info "SD prod uses factory defaults — no models to download."
info "Starting $SD_SERVICE..."
start_container "$SD_SERVICE"
ok "sd-prod started with factory defaults."

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
ok "Prod setup complete."
info "  ollama-prod  → running on port $OLLAMA_PORT (default: $OLLAMA_DEFAULT)"
info "  sd-prod      → running on port 7860 (factory defaults)"
