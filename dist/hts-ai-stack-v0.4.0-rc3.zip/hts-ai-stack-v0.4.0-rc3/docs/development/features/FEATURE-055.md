# FEATURE-055 — Authelia SSO + Traefik Reverse Proxy

| Field | Value |
|-------|-------|
| Status | Proposed |
| Category | Security / Access |
| Target Release | v0.5.0 |
| Priority | HIGH |
| Effort | L (multi-phase, manifest-wide) |
| Components | `traefik` (new), `authelia` (new), all existing components (manifest extension) |
| Dependencies | Docker, `.env` secrets plumbing, manifest wizard (FEATURE-000 family) |
| Related | SECURITY-000 (UFW), SECURITY-001 (Tailscale ACL), SECURITY-003 (fail2ban) |

## Summary

Introduce a two-container reverse-proxy + auth layer (Traefik + Authelia
with Redis session store) sitting in front of the ~60 components in the
stack. Give users **one login for the whole stack** with 2FA, **100%
local** (no cloud IdP), driven by manifest metadata so each component
self-declares its auth capability.

Architecture:

```
Browser → Traefik (443) → Authelia (forward-auth) → Service
                       ↘ (bypass)                 ↗
```

Every manifest gets a new `auth` block; a generator produces
`docker-compose.override.traefik.yml` and `stack/authelia/access_control.yml`
from those manifests. Existing `localhost:PORT` endpoints keep working
during rollout (auth is opt-in via a stack-level flag).

## Goals

1. Single login for the stack when the app supports delegated auth.
2. Defense in depth for legacy apps that can't delegate.
3. 100% local — no third-party IdP, no telemetry, no cloud calls.
4. Manifest-driven — zero hand-rolled Traefik labels.
5. Backwards compatible — `auth.enabled=false` = current behavior unchanged.

## Auth tiers (per-component classification)

| Tier | Meaning | Example components |
|---|---|---|
| `sso_header` | App trusts `Remote-User` header → single login | Grafana, Prometheus, Alertmanager, cAdvisor |
| `sso_oidc` | App speaks OIDC → Authelia issues tokens | Gitea, Portainer, Open WebUI, n8n, Flowise, Langflow |
| `gated` | App has own auth; Authelia is outer gate (double login) | Duplicati, ComfyUI, AnimateDiff, KoboldCpp, Ardour |
| `api_only` | Internal API, no browser UI, network-gated | Ollama, LocalAI, faster-whisper, coqui-tts, llama-swap |
| `bypass` | Public (e.g., dashboard landing page) | Dashboard |

Default for unclassified = `gated` + `two_factor`.

## Manifest schema addition

```json
"auth": {
  "tier": "sso_header|sso_oidc|gated|bypass|api_only",
  "subdomain": "grafana",
  "upstream_port": 3000,
  "upstream_scheme": "http",
  "header_user": "X-WEBAUTH-USER",
  "header_groups": "X-WEBAUTH-GROUPS",
  "oidc": {
    "client_id": "grafana",
    "redirect_uris": ["https://grafana.hts.local/login/generic_oauth"],
    "scopes": ["openid", "profile", "email", "groups"]
  },
  "policy": "one_factor|two_factor|bypass",
  "allowed_groups": ["admins"],
  "allowed_networks": ["lan"]
}
```

Validated by `scripts/wizard/schemas/auth.schema.json`.

## Phases

### Phase 1 — Core infrastructure
- **1.1** New `traefik` component (lifecycle script, manifest `order: 10`,
  `stack/traefik/traefik.yml` static config, `stack/traefik/dynamic/` for
  middlewares, mkcert-generated `*.hts.local` wildcard cert).
- **1.2** New `authelia` component (lifecycle + `--reset-password`,
  `--add-user`, `--enroll-totp`, `--reset-totp`, `--register-oidc-client`
  actions; `stack/authelia/configuration.yml`; file backend
  `users_database.yml`; Argon2id hashes).
- **1.3** Session Redis (sidecar or reuse existing) — local only.
- **1.4** `mkcert` added to `scripts/host/tools.sh` CORE; cert gen wired
  into `authelia configure`. Decide local DNS strategy
  (`/etc/hosts` drop-in vs. dnsmasq container) — see Open Questions.
- **1.5** New Docker network `traefik_proxy`; services opt in via
  manifest-generated compose fragment.

### Phase 2 — Manifest extension
- **2.1** Schema for the `auth` block (JSON schema file).
- **2.2** Extend manifest validator; fail-fast on missing fields
  (e.g., `sso_oidc` tier without `oidc.client_id`).
- **2.3** Bulk triage: classify all 62 components in one chore PR.
- **2.4** `scripts/wizard/generate-traefik-labels.sh` — reads enabled
  manifests, emits `docker-compose.override.traefik.yml` with
  routers/middlewares/services labels.
- **2.5** `scripts/components/authelia/generate-access-control.sh` —
  aggregates policies into `stack/authelia/access_control.yml`.

### Phase 3 — Per-component integration
- **3.1** `sso_header` wiring: each component's `configure` writes its
  own proxy-auth config (e.g., Grafana `[auth.proxy]`, Prometheus
  reverse-proxy headers). Auto-disable app's native login when
  `auth.enabled=true`.
- **3.2** `sso_oidc` wiring: Authelia `register-oidc-client <manifest>`
  action; component `configure` consumes client creds from Authelia,
  writes them into app config; both restart.
- **3.3** `gated` docs: update CONTEXT.md of double-auth components
  (Duplicati, ComfyUI, etc.) to explain the model and encourage
  browser password-manager autofill for the inner lock.
- **3.4** `api_only` pattern: IP allowlist + optional API-key
  middleware for Ollama/LocalAI/whisper/tts/llama-swap. Document.
- **3.5** User onboarding UX: `--add-user` (prompts, Argon2id hash,
  writes to users DB), `--enroll-totp` (QR code via `qrencode` in
  terminal, user scans with authenticator app), `--reset-totp`.

### Phase 4 — Bootstrap + wizard integration
- **4.1** Wizard "Authentication" section: enable SSO?, cookie domain
  (default `hts.local`), create admin user now?. Persists under
  `.auth` in `config/hts-ai.config.json`.
- **4.2** Bootstrap order: insert mkcert → Traefik → Authelia → Redis
  *after* Docker and *before* components. **NVIDIA drivers remain LAST.**
- **4.3** Dashboard tile generator reads `auth.subdomain`; switches
  tile URLs from `http://localhost:PORT` to `https://<svc>.hts.local`
  when auth is enabled. Keeps direct-port fallback link for debug.
- **4.4** `backups/pre-nuke-checklist.sh` backs up `.env` auth secrets,
  `users_database.yml`, and the `authelia_config` Docker volume so
  restore-after-nuke preserves logins.

### Phase 5 — Documentation & tests
- `docs/auth-architecture.md` — diagram, request flow, tier cheat-sheet.
- `docs/auth-adding-a-user.md` — operator runbook.
- `docs/auth-adding-a-component.md` — developer guide.
- Update each component CONTEXT.md with its auth tier.
- `tests/auth/` integration tests:
  - `test-traefik-routes.sh` — every enabled component has a valid route.
  - `test-authelia-policy.sh` — unauthenticated → 302 to auth.
  - `test-sso-header.sh` — post-login app sees `Remote-User`.

## Secrets (generated at install, stored in `.env`)

- `AUTHELIA_JWT_SECRET` (64 bytes, URL-safe)
- `AUTHELIA_SESSION_SECRET` (64 bytes)
- `AUTHELIA_STORAGE_ENCRYPTION_KEY` (64 bytes)
- `AUTHELIA_REDIS_PASSWORD` (32 bytes)
- Per-component OIDC client secrets (generated on `register-oidc-client`)

All 0600, backed up via pre-nuke-checklist.

## Rollout strategy

- Ship behind `auth.enabled=false` default. Users opt in via wizard.
- When disabled: stack behaves exactly as today, zero new containers.
- When enabled: Traefik + Authelia + Redis come up; classified
  components get their labels via the generated override file.
- First `auth.enabled=true` install creates a `tim` admin user from
  `.env` defaults and prompts for TOTP enrollment on first browser login.

## Risks & mitigations

| Risk | Mitigation |
|---|---|
| Breaking every URL at once | Behind feature flag; opt-in per install |
| TLS trust pain on phones/other boxes | Export mkcert CA; doc for adding to device trust; optional real domain later |
| Legacy double-login friction | Browser password manager; `gated` tier clearly documented |
| Manifest misclassification | Triage PR carefully reviewed; re-tiering is a one-line manifest edit |
| Config drift between manifests and generated files | Generators are the source of truth; generated files are `.gitignore`d or marked "DO NOT EDIT" |
| Lost admin 2FA | `--reset-totp` recovery action |
| `hts.local` collision with real mDNS/LAN | Accepted risk — stack is isolated on a dedicated LAN segment; document workaround if a user hits it |

## Out of scope (future features)

- **L3 microsegmentation / per-service spoke networks** — see
  [FEATURE-056](FEATURE-056.md). Layers on top of this feature to
  give genuine defense-in-depth (L7 Authelia + L3 network isolation).
- External access via Tailscale Funnel or Cloudflare Tunnel (separate feature)
- LLDAP integration for multi-user directory (Phase 6 / follow-up)
- SAML provider (Authelia is OIDC-only; would require Authentik)
- Audit log shipping to Loki (ties to SECURITY-005)
- Per-component API keys brokered via Authelia

## Open questions

- **Local DNS strategy:** `/etc/hosts` entries (simple, per-host) vs.
  dnsmasq container (LAN-wide, more setup)? → Propose `/etc/hosts`
  for v0.5.0, dnsmasq as follow-up.
- **Cookie domain default:** **RESOLVED — `hts.local`.** Wizard may still
  override, but `hts.local` is the default everywhere (certs, ACLs,
  redirect URIs, docs).
- **Wildcard cert device distribution:** provide a helper to export
  mkcert root CA to Android/iOS? → Nice-to-have, doc-only for v0.5.0.

## Acceptance criteria

- [ ] `auth.enabled=false` install behaves identically to pre-feature stack.
- [ ] `auth.enabled=true` install produces working `https://<svc>.hts.local`
      URLs for all classified components.
- [ ] Single login propagates to at least Grafana (`sso_header`) and
      Gitea (`sso_oidc`) without second prompt.
- [ ] 2FA enforced on components with `policy: two_factor`.
- [ ] All 62 existing components have an `auth` block in their manifest.
- [ ] Nuke-pave restore with saved `.env` + `authelia_config` volume
      reproduces logins and 2FA enrollments.
- [ ] `tests/auth/` integration tests pass in CI.
