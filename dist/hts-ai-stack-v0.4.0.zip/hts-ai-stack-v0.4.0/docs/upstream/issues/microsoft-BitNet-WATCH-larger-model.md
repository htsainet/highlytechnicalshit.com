# microsoft/BitNet — Watch: Fully-trained larger model (8B+)

| Field | Value |
|-------|-------|
| **Repo** | [microsoft/BitNet](https://github.com/microsoft/BitNet) |
| **Issue** | WATCH — no upstream issue; monitoring model releases |
| **State** | WATCH |
| **Severity** | low |
| **Labels** | model-release |
| **Opened** | — |
| **Subscribed** | — |

## Summary

The largest natively-trained BitNet b1.58 model with sufficient training depth is
currently **BitNet-b1.58-2B-4T** (2B parameters, 4 trillion training tokens).

An 8B-parameter variant exists (`HF1BitLLM/Llama3-8B-1.58-100B-tokens`) but was
only trained on 100B tokens — far too few to compete with the 2B-4T model in
practice. It is tracked in `registry.json` as a test model only.

Microsoft has indicated larger natively-trained models are on the roadmap.
This entry tracks that release.

## Hardware context

- **GPU:** RTX 3060 12GB VRAM
- **RAM:** 32 GB system RAM
- **BitNet role:** CPU-only inference backend (offload path via llama-swap)

A well-trained 8B model would be a meaningful capability upgrade for CPU-side
tasks. With 32 GB RAM, an 8B i2_s GGUF (~2–3 GB) would run comfortably.

## What "ready to promote" looks like

A new model is worth promoting to `prod` in `registry.json` when **all** of:

- Parameters ≥ 8B
- Training tokens ≥ 1T (ideally 4T+)
- Native 1.58-bit training (not post-training quantization)
- Official GGUF available from `microsoft/` or `HF1BitLLM/` on Hugging Face
- Benchmarks show improvement over BitNet-b1.58-2B-4T on reasoning/instruction tasks

## Action when a qualifying model is released

1. Add new entry to `scripts/install/models/registry.json` under `"bitnet"`.
2. Update `docker/bitnet/entrypoint.sh` defaults (`BITNET_MODEL`, `BITNET_HF_REPO`, `BITNET_GGUF`)
   or pass new values via `docker-compose.yml` env override.
3. Test against the `llama-swap` CPU route (`http://localhost:8080/v1/models`).
4. Promote to `"env": ["prod"]` and demote or remove the 2B-4T entry if the
   new model clearly outperforms it.
5. Update `REFERENCES.md` dependency inventory row for `microsoft/BitNet`.
6. Archive this file to `issues/resolved/`.

## Current workaround

`BitNet-b1.58-2B-4T` remains in prod. It is well-trained and fast (~34 t/s on
x86 CPU), making it a solid fit for lightweight CPU-side tasks.

## Status log

- **2026-04-14** — Watch created. 2B-4T confirmed as the best available
  natively-trained BitNet model. Llama3-8B-1.58 (100B tokens) remains in test
  only due to insufficient training depth. Monitoring Microsoft BitNet repo for
  larger model announcements.
