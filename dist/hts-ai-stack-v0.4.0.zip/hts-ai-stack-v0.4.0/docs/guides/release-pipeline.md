# Release Pipeline

End-to-end process for cutting a public release of the HTS AI stack.

This doc captures the *actual* pipeline in use as of v0.4.0-rc2 (the
first release cut after FEATURE-062 landed) so anyone — including
future-you with no memory of how this worked — can reproduce it.

## Repo topology

Three repositories, each with a distinct role.

| Repo | Visibility | What lives there |
|---|---|---|
| `htsai-net/hts-ai-stack-release` | private | Source of truth. Full git history, all feature branches, all PRs, all tags. This is where development happens. |
| `htsai-net/hts-ai-stack-release` | public | Release mirror. Single-commit-per-release convention on `main` (unrelated history; no dev branches, no workspace files). Tagged per release. |
| `htsainet/highlytechnicalshit.com` | public | Public-facing website. Hosts `index.html`, the zipped snapshot under `dist/`, and the `bootstrap.sh` users curl to stand up a fresh machine. |

Public users never see the source repo. They discover the stack via
the website, download the zip (or curl bootstrap.sh, which clones the
release mirror), and install.

## Release artifacts per cut

For each public release you produce:

1. A tag on the **source** repo (`htsai-net/hts-ai-stack-release`) at the
   commit being released — e.g. `v0.4.0-rc2`.
2. A single squashed snapshot commit on `main` of the **release
   mirror** (`htsai-net/hts-ai-stack-release`), tagged the same.
3. A GitHub pre-release (or release) on the release mirror with the
   same tag.
4. An updated zip at `dist/hts-ai-stack-vX.Y.Z[-rcN].zip` on the
   **website**, with `index.html` + `bootstrap.sh` pointing at it.

All four are produced from the same source commit so everything stays
in lockstep.

## The pipeline

### Step 0 — Preflight on the source repo

Before any release work, on the feature branch (or whatever you're
releasing from):

```bash
cd ~/hts/hts-ai-stack
git status                                  # must be clean
pwsh -NoLogo -NoProfile -File tests/Invoke-RepoChecks.ps1
./scripts/maintenance/scrub-check.sh --all  # FEATURE-062 gate
```

All three must be clean. `scrub-check.sh` is your last line of
defence against PII / secrets — it enforces the rules in
`config/pii-deny.txt` and the built-in deny list (keys, PATs, JWTs,
operator-specific tokens).

Optional but recommended: `./scripts/maintenance/clean-for-commit.sh`
(dry run) to make sure no runtime artifacts have crept in.

### Step 1 — Tag the source

```bash
git tag -a v0.4.0-rc2 -m "v0.4.0-rc2 pre-release"
git push origin v0.4.0-rc2
```

Tag on whatever ref you're releasing from — feature branch is fine
for release candidates; merge to `main` first for a final release.

### Step 2 — Build the scrubbed snapshot

The `build-snapshot.sh` tool codifies exactly the procedure used for
rc2:

```bash
./scripts/release/build-snapshot.sh \
    --out /tmp/release-snapshot \
    --tarball /tmp/hts-ai-stack-v0.4.0-rc2.tgz   # optional
```

What it does:

1. `git ls-files | tar` — tracked files only (honours `.gitignore`;
   excludes all operator-local state).
2. Strips a hard-coded workspace blacklist of files that are tracked
   but should never appear in a public release:
   - `BATCH_2_MERGE_READY.txt`, `batch_2_results.md`, `brainstorming.md`
   - `cspell.json`, `docker-images.md`
   - `.claude/`
3. Runs `scrub-check.sh --path <OUT>` as a post-build gate. If it
   fails, the build fails — you cannot ship a dirty snapshot.

Output: a directory at `--out` ready to publish. Expected size for
v0.4.0-rc2: ~738 files / 5.7 MB.

**AI instruction files** (`CLAUDE.md`, `AGENTS.md`,
`.github/copilot-instructions.md`) are included in the snapshot.
`release-export.sh` generalizes `CLAUDE.md` by redacting the developer
name from the identity line and removing the `refactor/` Quick-Nav row
(which points to a directory excluded from release). The two symlinks
resolve to the redacted copy automatically. See the "AI Instruction
Files" section in `CONTEXT.md` for the full symlink strategy.

### Step 3 — Publish to the release mirror

One-commit-per-release convention, `main` has *unrelated history* to
the source repo. Easiest flow:

```bash
# 1. Clone the release mirror into a scratch location
cd /tmp && rm -rf release-publish
gh repo clone htsai-net/hts-ai-stack-release release-publish
cd release-publish

# 2. Wipe everything except .git
find . -mindepth 1 -maxdepth 1 -not -name .git -exec rm -rf {} +

# 3. Copy the scrubbed snapshot on top
cp -a /tmp/release-snapshot/. .

# 4. Sanity-check (belt-and-suspenders)
~/hts/hts-ai-stack/scripts/maintenance/scrub-check.sh --all

# 5. Commit, tag, push main + tag
git add -A
git commit -m "v0.4.0-rc2: release snapshot

Snapshot of htsai-net/hts-ai-stack-release @ <source-sha>.
See source repo for full history and changelog."
git tag -a v0.4.0-rc2 -m "v0.4.0-rc2"
git push origin main
git push origin v0.4.0-rc2

# 6. Create the GitHub pre-release / release
gh release create v0.4.0-rc2 \
    --repo htsai-net/hts-ai-stack-release \
    --prerelease \
    --title "v0.4.0-rc2" \
    --notes "Second release candidate. See source repo for details."

# 7. Clean up
cd / && rm -rf /tmp/release-publish
```

Drop `--prerelease` for a final tagged release.

### Step 4 — Publish to the website

The website repo lives at `htsainet/highlytechnicalshit.com` and
auto-deploys from `main` via GitHub Pages (custom domain
`highlytechnicalshit.com`).

```bash
# 1. Clone the website and the scrubbed snapshot
cd /tmp && rm -rf website
gh repo clone htsainet/highlytechnicalshit.com website
cd website

# 2. Produce the zip (top-level dir in the zip must match the tag)
cd /tmp
mv release-snapshot hts-ai-stack-v0.4.0-rc2
zip -qr hts-ai-stack-v0.4.0-rc2.zip hts-ai-stack-v0.4.0-rc2
cp hts-ai-stack-v0.4.0-rc2.zip website/dist/

# 3. Update index.html — two spots:
#    - <footer id="siteFooter">hts-ai-stack vX.Y.Z · released YYYY-MM-DD</footer>
#    - the dl-btn <a href="dist/hts-ai-stack-vX.Y.Z.zip" download>...</a>
#    - the releaseDate JS literal (controls the "fresh" badge window)
#    Example edits: rc1 -> rc2 + bump date.

# 4. Verify bootstrap.sh still points at the public mirror:
grep REPO_SLUG website/bootstrap.sh
#   → REPO_SLUG="htsai-net/hts-ai-stack-release"

# 5. (Usually no edit needed) Verify install.sh migration warning URL
grep "set-url origin" website/install.sh
#   → ...htsai-net/hts-ai-stack-release.git

# 6. Remove the old release's zip if you don't need it in archive
rm website/dist/hts-ai-stack-v0.4.0-rc1.zip   # optional

# 7. Commit + push
cd website
git add -A
git commit -m "release: v0.4.0-rc2"
git push origin main
```

GitHub Pages picks up the push; the site is live within a minute.

## One-time user flow (what the install side looks like)

For context — this is what the pipeline enables.

```bash
# Fresh Ubuntu machine, zero repo access needed:
bash <(curl -fsSL \
    https://raw.githubusercontent.com/htsainet/highlytechnicalshit.com/refs/heads/main/bootstrap.sh)
```

`bootstrap.sh`:

1. Installs prerequisites (curl, gpg, git, chrony, gh).
2. Authenticates `gh` via browser (no password).
3. Sets git identity from the GitHub session.
4. Clones `htsai-net/hts-ai-stack-release` (the public mirror) to
   `~/hts/hts-ai-stack`.
   - If `gh` can't reach it, falls back to unzipping the most-recent
     `hts-ai-stack*.zip` from `~/Downloads` — which is why the
     website hosts the zip too.
5. Installs PowerShell 7 + Pester.
6. Installs Docker.
7. Installs NVIDIA drivers (last; triggers reboot).

After reboot: `cd ~/hts/hts-ai-stack && ./install.sh`.

## Release conventions

### Version numbering

- `vMAJOR.MINOR.PATCH` — final release.
- `vMAJOR.MINOR.PATCH-rcN` — release candidate (pre-release on GitHub).
- Tag format is identical across source repo, release mirror, and
  (as a convention in the zip filename / top-level dir) the website.

### Zip naming

- `hts-ai-stack-vX.Y.Z[-rcN].zip`
- Top-level directory inside the zip: `hts-ai-stack-vX.Y.Z[-rcN]/`
- Keep the `v` prefix. (The manually-built rc2 snapshot accidentally
  omitted it as `hts-ai-stack-0.4.0-rc2.zip` — the released build
  restored the `v`.)

### Release mirror commits

Single squashed commit per release on `main`. Unrelated history — do
NOT try to merge source-repo branches into the mirror. Each release
is a fresh wipe + tracked-files drop.

Commit message format:

```text
vX.Y.Z[-rcN]: release snapshot

Snapshot of htsai-net/hts-ai-stack-release @ <source-sha>.
See source repo for full history and changelog.
```

### Source repo branching

- Cut release candidates from feature branches (current practice —
  rc2 was cut from `feature/manifest-wizard`). No merge required.
- Cut final releases from `main` after merging the relevant feature
  branch(es).

## Guardrails

Every release passes through these gates:

1. **Pre-commit hook** — `.githooks/pre-commit` runs `scrub-check.sh`
   on staged files (blocks commits with PII / secrets).
2. **`build-snapshot.sh` post-build gate** — re-runs scrub-check on
   the assembled snapshot before you can publish it.
3. **Release-mirror sanity pass** — the final `scrub-check.sh --all`
   inside `/tmp/release-publish` before `git commit`.

The `.gitignore`-honouring `git ls-files` export guarantees
operator-local paths (tokens, secrets, backups) never make it into
the snapshot to begin with; the scrub-check rules catch anything that
slipped into tracked content.

If a scrub hit shows up at release time and it's a false positive for
that operator's environment, add the token to `config/pii-deny.txt`
(gitignored per-operator) rather than editing the scrubber rules.

## Troubleshooting

**Scrub fails on the snapshot but the working tree is clean.**
Look at the workspace blacklist. If a tracked file (e.g.
`BATCH_2_MERGE_READY.txt`) contains operator paths, either add it to
the BLACKLIST in `scripts/release/build-snapshot.sh` or scrub the
file in source.

**Release mirror push rejected as non-fast-forward.**
Expected — mirror has unrelated history. Use `git push origin main`
against a freshly re-copied tree. If someone force-pushed, re-clone.

**Website zip has a different top-level directory name than the tag.**
Re-zip from a directory whose name is exactly `hts-ai-stack-vX.Y.Z`.
bootstrap.sh's zip-fallback path uses a glob (`hts-ai-stack*`) so any
name works, but consumers expect the versioned directory.

**`gh repo clone` fails with 404 for a public user.**
They're hitting the private source repo. Check their
`bootstrap.sh` — `REPO_SLUG` must be `htsai-net/hts-ai-stack-release`.

## Key files

| Path | Purpose |
|---|---|
| `scripts/release/build-snapshot.sh` | Assembles a scrubbed, blacklist-filtered snapshot directory (+ optional tarball) |
| `scripts/maintenance/scrub-check.sh` | PCRE sweep for PII / secrets / operator tokens. Used as a pre-commit gate and by `build-snapshot.sh`. |
| `scripts/maintenance/clean-for-commit.sh` | Removes runtime artifacts (logs, dashboard tokens, backups) before a commit. |
| `config/pii-deny.txt.example` | Template for per-operator name / handle / pet-name deny list. Copy to `config/pii-deny.txt` (gitignored). |
| `.githooks/pre-commit` | Wires `scrub-check.sh` into the commit flow. Requires `git config core.hooksPath .githooks` (done once per clone). |
| `docs/development/features/FEATURE-062.md` | Feature spec + phase status for the hygiene system. |

## Release history

| Tag | Source SHA | Released | Notes |
|---|---|---|---|
| `v0.4.0-rc1` | (pre-FEATURE-062) | 2026-04-12 | First public release candidate. Pre-scrubber — manual redaction pass. |
| `v0.4.0-rc2` | `d4f827b` | 2026-04-18 | First release cut with `build-snapshot.sh` + scrub-check. Replaces the earlier un-scrubbed rc2 zip on the website. |
