$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))

    # Detect backend engine from .env
    $envFile = Join-Path $script:RepoRoot '.env'
    $script:BackendEngine = 'ollama'
    if (Test-Path $envFile) {
        $match = Select-String -Path $envFile -Pattern '^BACKEND_ENGINE=(.+)$' -ErrorAction SilentlyContinue
        if ($match) { $script:BackendEngine = $match.Matches[0].Groups[1].Value.Trim() }
    }
}

Describe 'Docker compose validation' {
    It 'docker-compose.yml is valid YAML' {
        $composeFile = Join-Path $script:RepoRoot 'docker-compose.yml'
        $composeFile | Should -Exist
        { docker compose -f $composeFile config --quiet 2>&1 } | Should -Not -Throw
    }

    It 'defines the expected core services' {
        $composeFile = Join-Path $script:RepoRoot 'docker-compose.yml'
        $services = docker compose -f $composeFile config --services 2>&1 | Sort-Object
        $services | Should -Contain 'dashboard'
        $services | Should -Contain 'open-webui'
        $services | Should -Contain 'ollama'
        $services | Should -Contain 'bitnet'
    }

    It 'defines the ai-network bridge network' {
        $composeFile = Join-Path $script:RepoRoot 'docker-compose.yml'
        $networks = docker compose -f $composeFile config --format json 2>&1 | ConvertFrom-Json
        $networks.networks.PSObject.Properties.Name | Should -Contain 'ai-network'
    }
}

Describe 'Docker network' {
    It 'ai-network exists' {
        $network = docker network ls --filter name=hts-ai-stack_ai-network --format '{{.Name}}' 2>&1
        $network | Should -Not -BeNullOrEmpty
    }

    It 'ai-network uses bridge driver' {
        $driver = docker network inspect hts-ai-stack_ai-network --format '{{.Driver}}' 2>&1
        $driver | Should -Be 'bridge'
    }
}

Describe 'Container health — Ollama backend' -Skip:($script:BackendEngine -ne 'ollama') {
    It 'dashboard is running' {
        $status = docker inspect --format '{{.State.Status}}' dashboard 2>&1
        $status | Should -Be 'running'
    }

    It 'ollama is running and healthy' {
        $status = docker inspect --format '{{.State.Status}}' ollama 2>&1
        $status | Should -Be 'running'
        $health = docker inspect --format '{{.State.Health.Status}}' ollama 2>&1
        $health | Should -Be 'healthy'
    }

    It 'open-webui is running' {
        $status = docker inspect --format '{{.State.Status}}' open-webui 2>&1
        $status | Should -Be 'running'
    }
}

Describe 'Container health — BitNet backend' -Skip:($script:BackendEngine -ne 'bitnet') {
    It 'dashboard is running' {
        $status = docker inspect --format '{{.State.Status}}' dashboard 2>&1
        $status | Should -Be 'running'
    }

    It 'bitnet is running and healthy' {
        $status = docker inspect --format '{{.State.Status}}' bitnet 2>&1
        $status | Should -Be 'running'
        $health = docker inspect --format '{{.State.Health.Status}}' bitnet 2>&1
        $health | Should -Be 'healthy'
    }

    It 'open-webui is running' {
        $status = docker inspect --format '{{.State.Status}}' open-webui 2>&1
        $status | Should -Be 'running'
    }
}

Describe 'Endpoint health — Ollama backend' -Skip:($script:BackendEngine -ne 'ollama') {
    It 'dashboard responds on :80' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:80 2>&1
        $response | Should -Be '200'
    }

    It 'ollama API responds on :11434' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:11434/api/tags 2>&1
        $response | Should -Be '200'
    }

    It 'open-webui responds on :3000' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:3000 2>&1
        $response | Should -Be '200'
    }
}

Describe 'Endpoint health — BitNet backend' -Skip:($script:BackendEngine -ne 'bitnet') {
    It 'dashboard responds on :80' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:80 2>&1
        $response | Should -Be '200'
    }

    It 'bitnet API responds on :8080' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:8080/v1/models 2>&1
        $response | Should -Be '200'
    }

    It 'open-webui responds on :3000' {
        $response = curl -sf -o /dev/null -w '%{http_code}' http://localhost:3000 2>&1
        $response | Should -Be '200'
    }
}

Describe 'Script inventory' {
    It 'has exactly the five expected entry-point scripts' {
        foreach ($script in @('bootstrap.sh', 'install.sh', 'setup.sh', 'teardown.sh', 'verify.sh')) {
            $path = Join-Path $script:RepoRoot $script
            $path | Should -Exist -Because "$script must exist"
            $mode = (Get-Item -LiteralPath $path -Force).UnixFileMode
            ($mode -band [System.IO.UnixFileMode]::UserExecute) | Should -Not -Be 0 -Because "$script must be executable"
        }
    }

    It 'entry-point scripts pass bash -n syntax check' {
        foreach ($script in @('bootstrap.sh', 'install.sh', 'setup.sh', 'teardown.sh', 'verify.sh')) {
            $path = Join-Path $script:RepoRoot $script
            & bash -n $path
            $LASTEXITCODE | Should -Be 0 -Because "$script must parse cleanly"
        }
    }
}
