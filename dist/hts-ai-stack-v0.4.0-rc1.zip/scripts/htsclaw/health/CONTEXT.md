# Health — Liveness Monitoring

Last updated: 2026-04-11 10:00:00

## What happens here

Health check functions and a systemd timer that monitors sandbox liveness every
5 minutes. Restarts dead port forwards and alerts if the sandbox is unhealthy.
Ported from NemoClaw's `_install_health_timer()` and `_ensure_forwards()`.

## Files and structure

| File | Purpose |
|------|---------|
| `health.sh` | Health probe function + forward revival logic |
| `htsclaw-health.service` | systemd oneshot service that runs the health check |
| `htsclaw-health.timer` | systemd timer triggering health check every 5 minutes |

## What it checks

1. **Sandbox exists** — `openshell sandbox get <name>` succeeds
2. **OpenClaw gateway responds** — HTTP probe on forwarded port `/healthz`
3. **Port forward alive** — `openshell forward list` shows active forward
4. **Forward revival** — if forward is dead, stop and restart it
5. **Gateway revival** — if gateway is not responding, restart it via lifecycle

## Process

1. systemd timer fires every 5 minutes
2. Health probe checks sandbox existence, gateway HTTP, and port forward
3. Dead forwards revived automatically via `openshell forward`
4. Results logged to systemd journal

## Key difference from NemoClaw

NemoClaw health timer also manages a Python TCP relay for non-standard port
mapping (openshell forward is same-port only). htsclaw uses port 18792 natively
so no relay is needed — simpler health check.

## Tools and dependencies

- **openshell CLI** — sandbox get, forward list/start/stop
- **curl** — HTTP health probes against gateway `/healthz`
- **systemd** — timer and service units for scheduled execution

## What good looks like

- Dead forwards revived automatically within 5 minutes
- Health status visible via `htsclaw-menu.py → Status`
- systemd timer survives reboots
- No silent failures — health output logged to journal
