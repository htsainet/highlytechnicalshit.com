#!/usr/bin/env bash
# 04-setup-nemoclaw.sh — NemoClaw install entry point.
#
# Routes to the nemoclaw component when NEMOCLAW_ENABLED=true, else skips.
# NemoClaw is now a normal toggleable component in the wizard; its enable
# state lives in stack.json at .sandbox.nemoclaw and is materialised into
# .env as NEMOCLAW_ENABLED by config/wizard/apply_config.sh.
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"

load_env
NEMOCLAW_ENABLED="${NEMOCLAW_ENABLED:-false}"

banner "04 — NemoClaw Sandbox Setup"

if [[ "$NEMOCLAW_ENABLED" == "true" ]]; then
  exec bash "$REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh" "$@"
else
  info "NemoClaw disabled (NEMOCLAW_ENABLED=${NEMOCLAW_ENABLED}) — skipping."
fi
