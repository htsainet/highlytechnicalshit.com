#!/usr/bin/env bash
# scripts/utils/flip-nemoclaw.sh — DEPRECATED
#
# This script swapped model assignments between GPU and CPU NemoClaw sandboxes.
# The CPU sandbox has been removed in favour of alternative sandbox technologies
# (see FEATURE-012 gVisor, FEATURE-013 Daytona).
#
# Kept for reference only. Will be removed in a future release.
set -euo pipefail

echo "ERROR: flip-nemoclaw.sh is deprecated — the CPU sandbox has been removed." >&2
echo "See FEATURE-012 (gVisor) and FEATURE-013 (Daytona) for alternative sandboxes." >&2
exit 1
