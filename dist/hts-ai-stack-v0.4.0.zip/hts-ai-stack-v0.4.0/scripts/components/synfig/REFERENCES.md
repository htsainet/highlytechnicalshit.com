# Synfig Studio — References

## Upstream

- **Homepage**: <https://www.synfig.org/>
- **Source**: <https://github.com/synfig/synfig>
- **Wiki**: <https://wiki.synfig.org/>

## Notes

- Available in Ubuntu universe repository
- Exports to video, animated GIF, and Lottie JSON
- Supports bone-based rigging for character animation
