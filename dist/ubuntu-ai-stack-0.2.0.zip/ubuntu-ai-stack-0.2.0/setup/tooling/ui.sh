#!/usr/bin/env bash

# Shared terminal UI helpers for installer scripts.

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

htsai_banner() {
  local label="$1"

  cat <<BANNER

  _   _ _____ ____       _    ___
 | | | |_   _/ ___|     / \  |_ _|
 | |_| | | | \___ \    / _ \  | |
 |  _  | | |  ___) |  / ___ \ | |
 |_| |_| |_| |____/  /_/   \_\___|     ubuntu ai stack

            ${label}
  ----------------------------------------
BANNER
}

checklist_start() {
  echo -e "\n  ${GREEN}Setup checklist — already-done steps are marked [x]:${NC}\n"
}

checklist_item() {
  local done="$1"
  local text="$2"

  if [ "$done" = "true" ]; then
    echo -e "  ${GREEN}[x]${NC} ${text}"
  else
    echo -e "  ${YELLOW}[ ]${NC} ${text}"
  fi
}

checklist_end() {
  echo -e "\n ----------------------------------------\n"
}
