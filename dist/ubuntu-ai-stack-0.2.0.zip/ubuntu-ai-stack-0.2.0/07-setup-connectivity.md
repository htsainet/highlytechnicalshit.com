# 07-setup-connectivity.sh — Optional Connectivity + Local Access

Runs the optional connectivity and convenience setup steps in one place. Each
step is safe to re-run and skips work that is already complete.

```bash
./07-setup-connectivity.sh
```

With no flags, the script runs all four optional steps:

| Flag | What it does | Notes |
| --- | --- | --- |
| `--telegram` | Configures Telegram bot support for OpenClaw | Requires a bot token |
| `--signal` | Configures Signal integration | Requires Signal account setup |
| `--tailscale` | Connects the machine to your Tailscale network | Useful for remote access |
| `--firefox-home` | Sets Firefox homepage to a local stack URL | Writes to Firefox `user.js` |

---

## Usage

```bash
# Run every optional step
./07-setup-connectivity.sh

# Run only one step
./07-setup-connectivity.sh --telegram
./07-setup-connectivity.sh --signal
./07-setup-connectivity.sh --tailscale
./07-setup-connectivity.sh --firefox-home

# Run any combination
./07-setup-connectivity.sh --tailscale --firefox-home
```

---

## Telegram

Runs [setup/comms/setup-telegram.md](setup/comms/setup-telegram.md) through
[setup/comms/setup-telegram.sh](setup/comms/setup-telegram.sh).

Use this when you want NemoClaw reachable from Telegram. If the bot token is
not already present in `.env`, the underlying script prompts for it.

---

## Signal

Runs [setup/comms/setup-signal.md](setup/comms/setup-signal.md) through
[setup/comms/setup-signal.sh](setup/comms/setup-signal.sh).

Use this when you want NemoClaw reachable from Signal using `signal-cli`.

---

## Tailscale

Runs [setup/networking/setup-tailscale.md](setup/networking/setup-tailscale.md)
through [setup/networking/setup-tailscale.sh](setup/networking/setup-tailscale.sh).

Use this when you want secure remote access to the machine and local services
without exposing ports directly to the public internet.

---

## Firefox Homepage

Sets Firefox's startup homepage by writing these preferences into the default
profile's `user.js`:

```js
user_pref("browser.startup.homepage", "http://127.0.0.1");
user_pref("browser.startup.page", 1);
```

Behavior:

- If Firefox is not installed, the step warns and skips.
- If Firefox has never been opened and no profile exists yet, the step warns and skips.
- If `user.js` already has those preferences, they are updated in place.

Override the homepage URL for a different local service:

```bash
FIREFOX_HOMEPAGE_URL=http://127.0.0.1:3000 ./07-setup-connectivity.sh --firefox-home
```

This is useful if you want Firefox to open directly to Open WebUI, NemoClaw, or
another service instead of the dashboard on port 80.

---

## Recommended Use

- Run the full script if you want all optional connectivity steps handled in one pass.
- Run only `--firefox-home` on workstation machines where you want the browser to open to the local stack dashboard.
- Run only `--tailscale` on headless or remote machines where browser customization is not relevant.

---

## Next Steps

After connectivity is configured, start or verify the stack:

```bash
./06-start-stack.sh
docker compose ps
```
