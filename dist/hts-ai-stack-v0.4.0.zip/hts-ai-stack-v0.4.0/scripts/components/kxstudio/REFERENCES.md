# KXStudio References

Last updated: 2026-04-17

## Upstream

- [KXStudio](https://kx.studio/)
- [KXStudio Repositories](https://kx.studio/Repositories)
- [Cadence — JACK management](https://kx.studio/Applications:Cadence)
- [Catia — JACK patchbay](https://kx.studio/Applications:Catia)
- [Carla — plugin host](https://kx.studio/Applications:Carla)

## PPA

- Repository package: `kxstudio-repos` (adds KXStudio PPA to apt sources)
- PPA URL: `https://launchpad.net/~kxstudio-debian/+archive/ubuntu/kxstudio`

## Packages

- `cadence` — JACK session management and configuration
- `catia` — JACK patchbay for audio/MIDI routing
- `carla` — Advanced plugin host (LV2, VST2, VST3, LADSPA, DSSI)
