$ErrorActionPreference = 'Stop'

# Test-ModelCache.Tests.ps1
#
# Fails if any model in registry.json is missing from the local/NAS model cache.
# Also fails if a shell script performs a hardcoded `ollama pull` for a model
# that is not listed in registry.json.
#
# Skips automatically when no model cache is configured or mounted.
#
# Cache root detection (first match wins):
#   1. MODEL_CACHE_DIR environment variable
#   2. Parent directory of NAS_SD_CACHE environment variable
#   3. /mnt/nas/llm-cache  (default seed-model-cache.sh destination)
#
# To populate the cache, run:
#   ./seed-model-cache.sh --dest <path>   (e.g. --dest /mnt/nas/llm-cache)
#
# To run this test:
#   pwsh -NoLogo -NoProfile -File tests/Test-ModelCache.Tests.ps1

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))

    # ── Locate cache root ────────────────────────────────────────────────────
    $cacheEnv = [System.Environment]::GetEnvironmentVariable('MODEL_CACHE_DIR')
    if (-not [string]::IsNullOrWhiteSpace($cacheEnv)) {
        $script:CacheRoot = $cacheEnv
    } else {
        $sdCacheEnv = [System.Environment]::GetEnvironmentVariable('NAS_SD_CACHE')
        if (-not [string]::IsNullOrWhiteSpace($sdCacheEnv)) {
            $script:CacheRoot = Split-Path $sdCacheEnv -Parent
        } else {
            $script:CacheRoot = '/mnt/nas/llm-cache'
        }
    }

    $script:OllamaManifestDir = Join-Path $script:CacheRoot 'ollama' 'models' 'manifests'
    $script:SdCacheDir        = Join-Path $script:CacheRoot 'sd-checkpoints'

    $script:OllamaCacheExists = Test-Path $script:OllamaManifestDir
    $script:SdCacheExists     = Test-Path $script:SdCacheDir
    $script:CacheEnabled      = $script:OllamaCacheExists -or $script:SdCacheExists

    # ── Load registry ────────────────────────────────────────────────────────
    $registryPath = Join-Path $script:RepoRoot 'setup' 'models' 'registry.json'
    if (-not (Test-Path $registryPath)) {
        throw "registry.json not found at $registryPath"
    }
    $script:Registry = Get-Content $registryPath -Raw | ConvertFrom-Json
}

# Resolve an Ollama model name to its on-disk manifest relative path.
# Ollama stores manifests at:
#   <manifests>/registry.ollama.ai/library/<name>/<tag>          - plain
#   <manifests>/registry.ollama.ai/<owner>/<name>/<tag>          - namespaced
#   <manifests>/huggingface.co/<owner>/<repo>/<tag>              - HF shorthand
function Resolve-OllamaManifestPath {
    param([string]$Model)

    if ($Model -match '^(.+):([^:]+)$') {
        $name = $Matches[1]
        $tag  = $Matches[2]
    } else {
        $name = $Model
        $tag  = 'latest'
    }

    # HuggingFace shorthand: hf.co/<owner>/<repo>
    if ($name -match '^hf\.co/(.+)$') {
        return "huggingface.co/$($Matches[1])/$tag"
    }

    # Namespaced community model: <owner>/<repo>
    if ($name -match '^[^/]+/[^/]+$') {
        return "registry.ollama.ai/$name/$tag"
    }

    # Plain library model: <name>
    return "registry.ollama.ai/library/$name/$tag"
}

# ── Ollama model cache ────────────────────────────────────────────────────────
Describe 'Ollama model cache' -Skip:(-not $script:CacheEnabled) {

    It 'ollama manifest directory exists under cache root' -Skip:(-not $script:OllamaCacheExists) {
        $script:OllamaManifestDir | Should -Exist
    }

    It 'all registry Ollama models are present in the cache' -Skip:(-not $script:OllamaCacheExists) {
        $missing = foreach ($entry in $script:Registry.ollama) {
            $rel  = Resolve-OllamaManifestPath -Model $entry.model
            $full = Join-Path $script:OllamaManifestDir $rel
            if (-not (Test-Path $full)) {
                $entry.model
            }
        }

        if ($missing) {
            throw (
                "Ollama models missing from cache. Run: ./seed-model-cache.sh --dest $($script:CacheRoot)`n" +
                ($missing -join "`n")
            )
        }
    }
}

# ── Stable Diffusion checkpoint cache ─────────────────────────────────────────
Describe 'Stable Diffusion checkpoint cache' -Skip:(-not $script:CacheEnabled) {

    It 'sd-checkpoints directory exists under cache root' -Skip:(-not $script:SdCacheExists) {
        $script:SdCacheDir | Should -Exist
    }

    It 'all registry SD checkpoints are present in the cache' -Skip:(-not $script:SdCacheExists) {
        $missing = foreach ($entry in $script:Registry.'sd-checkpoints') {
            $full = Join-Path $script:SdCacheDir $entry.filename
            if (-not (Test-Path $full)) {
                $entry.filename
            }
        }

        if ($missing) {
            throw (
                "SD checkpoints missing from cache. Run: ./seed-model-cache.sh --dest $($script:CacheRoot)`n" +
                ($missing -join "`n")
            )
        }
    }
}

# ── Registry completeness (always runs, no cache required) ────────────────────
Describe 'Registry completeness' {

    It 'every hardcoded ollama pull target in .sh files is listed in registry.json' {
        $registeredModels = $script:Registry.ollama | ForEach-Object { $_.model }
        $unregistered = [System.Collections.Generic.List[string]]::new()

        foreach ($file in (Get-ChildItem $script:RepoRoot -Recurse -Filter '*.sh')) {
            $content = Get-Content $file.FullName -Raw -ErrorAction SilentlyContinue
            if (-not $content) { continue }
            # Match: ollama pull <token> — skip shell variable references starting with $
            $pullMatches = [regex]::Matches($content, '(?m)\bollama\s+pull\s+(\S+)')
            foreach ($m in $pullMatches) {
                $model = $m.Groups[1].Value.Trim('"').Trim("'")
                if ($model -match '^\$') { continue }   # skip $VAR / ${VAR}
                if ($model -notin $registeredModels) {
                    $unregistered.Add("$($file.Name): $model")
                }
            }
        }

        if ($unregistered.Count -gt 0) {
            throw (
                "Hard-coded 'ollama pull' targets not in setup/models/registry.json.`n" +
                "Add the model to registry.json or replace the literal with a variable:`n" +
                ($unregistered -join "`n")
            )
        }
    }

    It 'every model name in prod.sh OLLAMA_MODELS_PROD array is listed in registry.json' {
        $prodScript = Join-Path $script:RepoRoot 'setup' 'models' 'prod.sh'
        if (-not (Test-Path $prodScript)) {
            Set-ItResult -Skipped -Because 'setup/models/prod.sh not found'
            return
        }

        $registeredModels = $script:Registry.ollama | ForEach-Object { $_.model }
        $content = Get-Content $prodScript -Raw

        # Extract the OLLAMA_MODELS_PROD array body
        $arrayMatch = [regex]::Match($content, 'OLLAMA_MODELS_PROD=\(([^)]+)\)')
        if (-not $arrayMatch.Success) {
            Set-ItResult -Skipped -Because 'OLLAMA_MODELS_PROD array not found in prod.sh'
            return
        }

        $unregistered = foreach ($line in ($arrayMatch.Groups[1].Value -split "`n")) {
            $line = $line -replace '#.*$', '' -replace '^\s+|\s+$', ''   # strip comments & whitespace
            $line = $line.Trim('"').Trim("'")
            if ($line -and $line -notin $registeredModels) { $line }
        }

        if ($unregistered) {
            throw (
                "Models in prod.sh OLLAMA_MODELS_PROD not in registry.json:`n" +
                ($unregistered -join "`n")
            )
        }
    }

    It 'every model name in test.sh OLLAMA_MODELS_TEST array is listed in registry.json' {
        $testScript = Join-Path $script:RepoRoot 'setup' 'models' 'test.sh'
        if (-not (Test-Path $testScript)) {
            Set-ItResult -Skipped -Because 'setup/models/test.sh not found'
            return
        }

        $registeredModels = $script:Registry.ollama | ForEach-Object { $_.model }
        $content = Get-Content $testScript -Raw

        $arrayMatch = [regex]::Match($content, 'OLLAMA_MODELS_TEST=\(([^)]+)\)')
        if (-not $arrayMatch.Success) {
            Set-ItResult -Skipped -Because 'OLLAMA_MODELS_TEST array not found in test.sh'
            return
        }

        $unregistered = foreach ($line in ($arrayMatch.Groups[1].Value -split "`n")) {
            $line = $line -replace '#.*$', '' -replace '^\s+|\s+$', ''
            $line = $line.Trim('"').Trim("'")
            if ($line -and $line -notin $registeredModels) { $line }
        }

        if ($unregistered) {
            throw (
                "Models in test.sh OLLAMA_MODELS_TEST not in registry.json:`n" +
                ($unregistered -join "`n")
            )
        }
    }
}
