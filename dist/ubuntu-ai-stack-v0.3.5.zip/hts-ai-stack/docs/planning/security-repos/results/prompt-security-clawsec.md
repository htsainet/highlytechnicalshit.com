# prompt-security/clawsec

> **Source:** [repo-review-batch1.md](../repo-review/results/repo-review-batch1.md) — Repo 2
> **Reviewed:** 2026-03-30 | **Verdict:** ADOPT

**Stars:** 551 | **Forks:** 57 | **Trust:** HIGH-ADOPT
**Org:** Prompt Security / SentinelOne

## Summary

Complete security skill suite — "skill of skills" installer that deploys, verifies, and maintains multiple security skills. Backed by Prompt Security (acquired by SentinelOne).

## Skills Included

| Skill | Function |
|-------|----------|
| clawsec-suite | Meta-installer — orchestrates all other skills |
| clawsec-feed | Live NVD CVE advisory feed, auto-polling |
| clawsec-scanner | Vulnerability scanner (deps + SAST + OpenClaw DAST) |
| clawsec-nanoclaw | NanoClaw platform security |
| clawsec-clawhub-checker | ClawHub skill reputation checks |
| clawtributor | Community incident reporting (opt-in, shares anonymized data) |
| openclaw-audit-watchdog | Automated audit |

## Key Features

1. **SOUL.md / IDENTITY.md drift detection** — monitors critical agent identity files, auto-restores if modified
2. **SHA256 checksum verification** — every skill artifact checksummed
3. **NVD CVE feed** — automated vulnerability advisory polling
4. **SBOM manifests** — every contributed skill requires SBOM in skill.json

## Stack Mapping

| ClawSec Concept | Stack Component | Action |
|----------------|----------------|--------|
| SOUL.md drift detection | SillyTavern character cards | Replaces SillyTavern for drift detection |
| SHA256 skill verification | Not implemented | Adopt |
| NVD CVE feed | Not implemented | Adopt |
| Audit watchdog | Not implemented | Evaluate alongside SlowMist nightly audit |
| ClawHub reputation checks | Not implemented | Use when evaluating skill additions |

## Risks

- clawtributor shares anonymized incident data externally — opt-in only
- AGPL-3.0 license — source release required if modified and distributed
- SentinelOne acquisition could mean future licensing changes

## Verdict

**ADOPT.** Install clawsec-suite, skip clawtributor (data sharing concern). Drift detection alone is worth it. Use alongside SlowMist guide — complementary: SlowMist = behavioral framework + nightly audit, ClawSec = skill verification + drift detection + CVE feed.

Complementary with: [slowmist/openclaw-security-practice-guide](slowmist-openclaw-security-practice-guide.md)
