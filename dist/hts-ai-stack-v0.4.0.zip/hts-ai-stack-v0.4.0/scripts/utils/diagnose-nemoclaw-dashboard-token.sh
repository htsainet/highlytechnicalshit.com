#!/usr/bin/env bash
# diagnose-nemoclaw-dashboard-token.sh
#
# Checks why the NemoClaw dashboard card may show a login/pair page instead
# of auto-logging in. Compares:
#   1. Token persisted in resources/dashboard/nemoclaw-tokens.json (what the
#      dashboard card uses to build #token=...).
#   2. Live token inside the sandbox's /sandbox/.openclaw/openclaw.json (what
#      the gateway will accept).
#   3. The actual <a> href emitted by the rendered dashboard for the
#      NemoClaw card (best-effort: parses index.html and the JSON file).
#   4. Currently-paired devices on the gateway (auto-pair watcher).
#
# No mutation. Read-only diagnosis. NemoClaw v0.0.21 reference:
#   scripts/nemoclaw-start.sh:639-655 (print_dashboard_urls)
#   scripts/nemoclaw-start.sh:657-740 (start_auto_pair / device approval)

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
GATEWAY="${NEMOCLAW_GATEWAY_NAME:-nemoclaw}"
SANDBOX="${NEMOCLAW_SANDBOX_NAME:-hts-ai-openshell-nemoclaw}"
PORT="${NEMOCLAW_DASHBOARD_PORT:-18789}"
TOKEN_FILE="$REPO_DIR/resources/dashboard/nemoclaw-tokens.json"

color() { printf '\033[%sm%s\033[0m\n' "$1" "$2"; }
hdr()   { echo; color '1;36' "── $* ──────────────────────────────────────────────────"; }
ok()    { color '0;32' "[ok]   $*"; }
warn()  { color '0;33' "[warn] $*"; }
err()   { color '0;31' "[err]  $*"; }
info()  { color '0;37' "[info] $*"; }

require() { command -v "$1" &>/dev/null || { err "missing tool: $1"; exit 2; }; }
require openshell
require python3
require curl

hdr "Persisted token (resources/dashboard/nemoclaw-tokens.json)"
if [[ -f "$TOKEN_FILE" ]]; then
  cat "$TOKEN_FILE"
  PERSISTED_TOKEN=$(python3 -c "
import json
d = json.load(open('$TOKEN_FILE'))
e = d.get('$SANDBOX') or {}
print(e.get('token', ''))
" 2>/dev/null || true)
  PERSISTED_PORT=$(python3 -c "
import json
d = json.load(open('$TOKEN_FILE'))
e = d.get('$SANDBOX') or {}
print(e.get('port', ''))
" 2>/dev/null || true)
  if [[ -n "$PERSISTED_TOKEN" ]]; then
    ok "persisted token present (len=${#PERSISTED_TOKEN}, port=${PERSISTED_PORT})"
  else
    err "persisted token MISSING for sandbox '$SANDBOX'"
  fi
else
  err "token file does not exist: $TOKEN_FILE"
  PERSISTED_TOKEN=""
fi

hdr "Live token (sandbox /sandbox/.openclaw/openclaw.json)"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
if openshell sandbox download -g "$GATEWAY" "$SANDBOX" \
   /sandbox/.openclaw/openclaw.json "$TMP/" 2>/dev/null; then
  LIVE_TOKEN=$(python3 -c "
import json
d = json.load(open('$TMP/openclaw.json'))
print(d.get('gateway',{}).get('auth',{}).get('token',''))
")
  LIVE_ALLOWED=$(python3 -c "
import json
d = json.load(open('$TMP/openclaw.json'))
o = d.get('gateway',{}).get('controlUi',{}).get('allowedOrigins',[]) or []
print(','.join(o) if o else '<none>')
")
  if [[ -n "$LIVE_TOKEN" ]]; then
    ok "live token present (len=${#LIVE_TOKEN})"
    info "allowedOrigins: $LIVE_ALLOWED"
  else
    err "live token MISSING in openclaw.json (gateway.auth.token)"
  fi
else
  err "could not download /sandbox/.openclaw/openclaw.json — is sandbox '$SANDBOX' on gateway '$GATEWAY' running?"
  LIVE_TOKEN=""
fi

hdr "Token comparison"
if [[ -n "$PERSISTED_TOKEN" && -n "$LIVE_TOKEN" ]]; then
  if [[ "$PERSISTED_TOKEN" == "$LIVE_TOKEN" ]]; then
    ok "persisted == live  (dashboard link will use the correct token)"
  else
    err "persisted != live  (dashboard token is STALE — re-run: $REPO_DIR/scripts/components/nemoclaw/nemoclaw.sh --tokens)"
    info "persisted: $PERSISTED_TOKEN"
    info "live     : $LIVE_TOKEN"
  fi
fi

hdr "Constructed dashboard URL (matches NemoClaw v0.0.21 print_dashboard_urls)"
if [[ -n "${LIVE_TOKEN:-}" ]]; then
  echo "  http://127.0.0.1:${PORT}/#token=${LIVE_TOKEN}"
fi

hdr "Forward listener (host TCP)"
if ss -tln 2>/dev/null | awk -v p=":${PORT}$" '$4 ~ p { found=1 } END { exit !found }'; then
  ok "127.0.0.1:${PORT} is LISTENing"
else
  err "no listener on 127.0.0.1:${PORT} — run: openshell -g $GATEWAY forward start $PORT $SANDBOX --background"
fi
openshell -g "$GATEWAY" forward list 2>/dev/null | sed 's/^/  /'

hdr "HTTP probe (root + token-anchored URL)"
echo "[probe] /"
curl -sS -o /dev/null -w '  HTTP %{http_code}  size=%{size_download}\n' "http://127.0.0.1:${PORT}/" || true
if [[ -n "${LIVE_TOKEN:-}" ]]; then
  echo "[probe] /#token=…  (note: # is client-side, server sees same path)"
  curl -sS -o /dev/null -w '  HTTP %{http_code}  size=%{size_download}\n' "http://127.0.0.1:${PORT}/" || true
  echo "[probe] /api/auth/whoami  (with bearer token)"
  curl -sS -o /dev/null -w '  HTTP %{http_code}\n' \
    -H "Authorization: Bearer ${LIVE_TOKEN}" \
    "http://127.0.0.1:${PORT}/api/auth/whoami" || true
fi

hdr "Paired devices (auto-pair watcher state)"
# Run inside sandbox as the sandbox user; openclaw devices list reads the
# gateway state. Failures here are expected if the auto-pair watcher hasn't
# run yet on a freshly-restarted sandbox.
openshell sandbox exec -g "$GATEWAY" -n "$SANDBOX" -- \
  sh -lc 'OPENCLAW=$(command -v openclaw || echo /usr/local/bin/openclaw); \
          "$OPENCLAW" devices list --json 2>/dev/null | python3 -m json.tool 2>/dev/null \
          || echo "<openclaw devices list failed — auto-pair watcher may not have started>"' \
  2>&1 | sed 's/^/  /'

hdr "Auto-pair log tail"
openshell sandbox exec -g "$GATEWAY" -n "$SANDBOX" -- \
  sh -lc 'tail -n 30 /tmp/auto-pair.log 2>/dev/null || echo "<no /tmp/auto-pair.log yet>"' \
  2>&1 | sed 's/^/  /'

hdr "Summary"
echo "If you see a login/pair page in the browser:"
echo "  1. If 'persisted != live' above → run nemoclaw.sh --tokens to refresh."
echo "  2. If 'no listener' above       → restart the forward (see line shown)."
echo "  3. If devices list shows no 'openclaw-control-ui' / 'webchat' device →"
echo "     open the URL in the browser, the auto-pair watcher should approve"
echo "     within ~10s. Tail /tmp/auto-pair.log to watch."
echo "  4. If pairing succeeded but UI still asks to login → the token in the"
echo "     URL fragment may be ignored by the served UI bundle. Open dev tools,"
echo "     localStorage, and check whether 'token' or 'auth.token' was set."
