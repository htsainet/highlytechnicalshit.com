$ErrorActionPreference = 'Stop'

BeforeAll {
    $script:RepoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $script:WizardScript = Join-Path $script:RepoRoot 'config/wizard/ai_stack_setup.sh'
}

function global:Invoke-WizardMenuMockRun {
    param(
        [Parameter(Mandatory)]
        [ValidateSet('none', 'network')]
        [string]$CacheType
    )

    $runId = [Guid]::NewGuid().ToString('N')
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) "wizard-menu-test-$runId"
    $repoRoot = Join-Path $tempRoot 'repo'
    $wizardDir = Join-Path $repoRoot 'config/wizard'
    $mockBin = Join-Path $tempRoot 'mockbin'
    $mockLog = Join-Path $tempRoot 'whiptail.log'
    $runLog = Join-Path $tempRoot 'wizard.log'

    New-Item -ItemType Directory -Path $wizardDir -Force | Out-Null
    New-Item -ItemType Directory -Path $mockBin -Force | Out-Null

    $wizardCopy = Join-Path $wizardDir 'ai_stack_setup.sh'
    Copy-Item -Path $script:WizardScript -Destination $wizardCopy -Force

    $mockWhiptail = @'
#!/usr/bin/env bash
set -euo pipefail

args="$*"
echo "$args" >> "${MOCK_LOG:?MOCK_LOG not set}"

if [[ "$args" == *"--menu"* ]]; then
  case "$args" in
    *"[1/13] Backend Engine"*) echo "ollama" >&2 ;;
    *"[2/13] Default Model"*) echo "llama3.2:3b" >&2 ;;
    *"[3/13] Deployment Instances"*) echo "single" >&2 ;;
    *"[4/13] Model Cache"*)
      if [[ "${WIZARD_CACHE_TYPE:-none}" == "network" ]]; then
        echo "network" >&2
      else
        echo "none" >&2
      fi
      ;;
    *"[10/13] Docker Network"*) echo "Single vnet" >&2 ;;
    *"NAS — What next?"*) echo "s" >&2 ;;
    *) echo "single" >&2 ;;
  esac
  exit 0
fi

if [[ "$args" == *"--checklist"* ]]; then
  echo "" >&2
  exit 0
fi

if [[ "$args" == *"--inputbox"* ]]; then
  if [[ "$#" -gt 0 ]]; then
    printf '%s\n' "${@: -1}" >&2
  else
    printf '\n' >&2
  fi
  exit 0
fi

if [[ "$args" == *"--yesno"* ]]; then
  # Save confirmation: Yes
  if [[ "$args" == *"Save Configuration?"* ]]; then
    exit 0
  fi

  # Only answer NAS discovery question positively in network mode.
  if [[ "$args" == *"NAS / Synology"* ]]; then
    if [[ "${WIZARD_CACHE_TYPE:-none}" == "network" ]]; then
      exit 0
    fi
    exit 1
  fi

  # All optional feature prompts default to No.
  exit 1
fi

if [[ "$args" == *"--msgbox"* ]]; then
  exit 0
fi

exit 0
'@

    $mockWhiptailPath = Join-Path $mockBin 'whiptail'
    Set-Content -Path $mockWhiptailPath -Value $mockWhiptail -NoNewline
    & bash -c "chmod +x '$mockWhiptailPath'"

    $pathWithMock = "${mockBin}:$([Environment]::GetEnvironmentVariable('PATH'))"

    & bash -c "cd '$repoRoot' && PATH='$pathWithMock' MOCK_LOG='$mockLog' WIZARD_CACHE_TYPE='$CacheType' bash '$wizardCopy'" *> $runLog
    $exitCode = $LASTEXITCODE

    $stackJsonPath = Join-Path $repoRoot 'config/stack.json'
    $stackJson = $null
    if (Test-Path $stackJsonPath) {
        $stackJson = Get-Content -Path $stackJsonPath -Raw | ConvertFrom-Json
    }

    [PSCustomObject]@{
        ExitCode = $exitCode
        StackJsonPath = $stackJsonPath
        StackJson = $stackJson
        MockLogPath = $mockLog
        MockLog = if (Test-Path $mockLog) { Get-Content -Path $mockLog -Raw } else { '' }
        RunLogPath = $runLog
        TempRoot = $tempRoot
    }
}

Describe 'Wizard menu flow validation' {
    It 'skips Synology prompt when model cache is none' {
        $result = Invoke-WizardMenuMockRun -CacheType 'none'
        try {
            $result.ExitCode | Should -Be 0
            (Test-Path $result.StackJsonPath) | Should -BeTrue
            $result.StackJson.model_cache.type | Should -Be 'none'
            $result.StackJson.nas.enabled | Should -BeFalse
            $result.MockLog | Should -Not -Match '\[5/13\] NAS / Synology'
        }
        finally {
            if (Test-Path $result.TempRoot) {
                Remove-Item -Path $result.TempRoot -Recurse -Force
            }
        }
    }

    It 'shows Synology prompt when model cache is network' {
        $result = Invoke-WizardMenuMockRun -CacheType 'network'
        try {
            $result.ExitCode | Should -Be 0
            (Test-Path $result.StackJsonPath) | Should -BeTrue
            $result.StackJson.model_cache.type | Should -Be 'network'
            $result.MockLog | Should -Match '\[5/13\] NAS / Synology'
        }
        finally {
            if (Test-Path $result.TempRoot) {
                Remove-Item -Path $result.TempRoot -Recurse -Force
            }
        }
    }

    It 'visits all core menu screens in order for none-cache path' {
      $result = Invoke-WizardMenuMockRun -CacheType 'none'
      try {
        $result.ExitCode | Should -Be 0
        $result.MockLog | Should -Match '(?s)\[1/13\] Backend Engine.*\[2/13\] Default Model.*\[3/13\] Deployment Instances.*\[4/13\] Model Cache.*\[6/13\] Voice Support.*\[6/13\] Image Generation.*\[8/13\] Claw3D \(3D Visualisation\).*\[9/13\] Paperclip \(OpenClaw Agent Manager\).*\[10/13\] Docker Network.*\[11/13\] Communications \(Bot Integrations\).*\[12/13\] Admin & Remote Access.*\[13/13\] Extra Components.*Save Configuration\?'
        $result.MockLog | Should -Not -Match '\[5/13\] NAS / Synology'
      }
      finally {
        if (Test-Path $result.TempRoot) {
          Remove-Item -Path $result.TempRoot -Recurse -Force
        }
      }
    }

    It 'visits NAS screen for network-cache path and continues through remaining screens' {
      $result = Invoke-WizardMenuMockRun -CacheType 'network'
      try {
        $result.ExitCode | Should -Be 0
        $result.MockLog | Should -Match '(?s)\[1/13\] Backend Engine.*\[2/13\] Default Model.*\[3/13\] Deployment Instances.*\[4/13\] Model Cache.*\[5/13\] NAS / Synology.*\[10/13\] Docker Network.*\[13/13\] Extra Components.*Save Configuration\?'
      }
      finally {
        if (Test-Path $result.TempRoot) {
          Remove-Item -Path $result.TempRoot -Recurse -Force
        }
      }
    }
}
