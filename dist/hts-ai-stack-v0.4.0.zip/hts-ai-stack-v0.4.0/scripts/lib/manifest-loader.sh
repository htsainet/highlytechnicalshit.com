#!/usr/bin/env bash
# scripts/lib/manifest-loader.sh — Load component manifests into registry arrays
# Source this file; do NOT run directly.
#
# Reads all *.manifest.json files from scripts/components/ and populates the
# same COMPONENT_* associative arrays that component-registry.sh defines.
# Either this file OR component-registry.sh should be sourced — not both.
#
# Used by: converge.sh, reconfigure.sh
# Requires: common.sh sourced first (for REPO_DIR)
# Requires: jq

# ── Output arrays (same names as component-registry.sh) ──────────────────────
declare -gA COMPONENT_SCRIPT
declare -gA COMPONENT_CONFIG_KEY
declare -gA COMPONENT_PROFILE
declare -gA COMPONENT_FUNC_PREFIX
declare -gA COMPONENT_DISPLAY_NAME
declare -gA COMPONENT_HEALTH_URL
declare -gA COMPONENT_HEALTH_TIMEOUT
declare -gA COMPONENT_HEALTH_PROBE_TIMEOUT
declare -gA COMPONENT_INSTALL_TYPE
declare -gA COMPONENT_WIZARD_DEFAULT
declare -gA COMPONENT_NUMERIC_ORDER
declare -gA COMPONENT_VRAM_MINIMUM
declare -gA COMPONENT_VRAM_ESTIMATE
declare -gA COMPONENT_DOWNLOAD_SIZE
declare -ga COMPONENT_ORDER

# ── Manifest helpers ──────────────────────────────────────────────────────────

# manifest_file <id>
# Prints the path to a component's manifest file.
# Checks subfolder layout first (components/{id}/{id}.manifest.json),
# then falls back to flat layout (components/{id}.manifest.json).
manifest_file() {
  local sub="${REPO_DIR}/scripts/components/${1}/${1}.manifest.json"
  if [[ -f "$sub" ]]; then
    echo "$sub"
  else
    echo "${REPO_DIR}/scripts/components/${1}.manifest.json"
  fi
}

# manifest_get <id> <jq_filter>
# Runs a jq filter against a component's manifest. Returns raw output.
manifest_get() {
  local id="$1" filter="$2"
  jq -r "$filter" "$(manifest_file "$id")"
}

# manifest_toggleable_ids
# Prints component IDs that are toggleable (config.toggleable == true),
# deduped by group — one representative per group.
manifest_toggleable_ids() {
  local seen_groups=()
  local id group

  for id in "${COMPONENT_ORDER[@]}"; do
    local file; file="$(manifest_file "$id")"
    local toggleable; toggleable=$(jq -r '.config.toggleable // false' "$file")
    [[ "$toggleable" != "true" ]] && continue

    group=$(jq -r '.config.group // ""' "$file")
    if [[ -n "$group" ]]; then
      # Emit only the first member of each group
      if [[ " ${seen_groups[*]} " != *" $group "* ]]; then
        seen_groups+=("$group")
        echo "$id"
      fi
    else
      echo "$id"
    fi
  done
}

# ── Config key derivation ─────────────────────────────────────────────────────
# Produces a backward-compatible config_key string from manifest config block.
# Mirrors the format expected by state-desired.sh case statement.
#
# always             → "always"
# boolean            → "dashboard.enabled"
# enum               → "backend:ollama,dual"
# array_member       → "extras.components:duplicati"
_derive_config_key() {
  local file="$1"
  jq -r '
    .config as $c |
    if   $c.type == "always"       then "always"
    elif $c.type == "boolean"      then ($c.read_path | ltrimstr("."))
    elif $c.type == "enum"         then (($c.read_path | ltrimstr(".")) + ":" + ($c.match_values | join(",")))
    elif $c.type == "array_member" then (($c.read_path | ltrimstr(".")) + ":" + $c.member_value)
    else ""
    end
  ' "$file"
}

# ── Core loader ───────────────────────────────────────────────────────────────

# _manifest_load_one <manifest_file>
# Extracts all fields from a single manifest in one jq call and populates arrays.
_manifest_load_one() {
  local file="$1"

  # Single jq call — tab-separated to avoid subprocess per field
  local fields
  fields=$(jq -r '[
    .id,
    .display_name,
    (.order | tostring),
    .script,
    (.func_prefix // ""),
    (.profile // ""),
    (.health.url // ""),
    ((.health.timeout // 60) | tostring),
    ((.health.probe_timeout // 5) | tostring),
    (.install_type // ""),
    ((.wizard_default // false) | tostring),
    ((.vram_minimum // 0) | tostring),
    ((.vram_estimate_mb // 0) | tostring),
    ((.download_size_mb // 0) | tostring)
  ] | join("\t")' "$file") || return 1

  local id display order script func_prefix profile health_url health_timeout health_probe_timeout install_type wizard_default vram_minimum vram_estimate download_size
  IFS=$'\t' read -r id display order script func_prefix profile health_url health_timeout health_probe_timeout install_type wizard_default vram_minimum vram_estimate download_size <<< "$fields"

  local config_key
  config_key=$(_derive_config_key "$file")

  COMPONENT_SCRIPT[$id]="$script"
  COMPONENT_CONFIG_KEY[$id]="$config_key"
  COMPONENT_PROFILE[$id]="$profile"
  COMPONENT_FUNC_PREFIX[$id]="$func_prefix"
  COMPONENT_DISPLAY_NAME[$id]="$display"
  COMPONENT_HEALTH_URL[$id]="$health_url"
  COMPONENT_HEALTH_TIMEOUT[$id]="$health_timeout"
  COMPONENT_HEALTH_PROBE_TIMEOUT[$id]="$health_probe_timeout"
  COMPONENT_INSTALL_TYPE[$id]="$install_type"
  COMPONENT_WIZARD_DEFAULT[$id]="$wizard_default"
  COMPONENT_NUMERIC_ORDER[$id]="$order"
  COMPONENT_VRAM_MINIMUM[$id]="$vram_minimum"
  COMPONENT_VRAM_ESTIMATE[$id]="$vram_estimate"
  COMPONENT_DOWNLOAD_SIZE[$id]="$download_size"

  # Append "order<tab>id" pair — indexed array handles duplicate order values
  _MANIFEST_ORDER_LIST+=("$order	$id")
}

# manifest_load_all
# Loads all *.manifest.json files and builds COMPONENT_ORDER sorted by order field.
manifest_load_all() {
  local manifest_dir="${REPO_DIR}/scripts/components"

  if ! command -v jq &>/dev/null; then
    echo "[FAIL] manifest-loader requires jq" >&2
    return 1
  fi

  declare -ga _MANIFEST_ORDER_LIST=()

  local file
  # Support both flat (*.manifest.json) and subfolder (*/*.manifest.json) layouts
  for file in "$manifest_dir"/*.manifest.json "$manifest_dir"/*/*.manifest.json; do
    [[ -f "$file" ]] || continue
    _manifest_load_one "$file" || {
      echo "[WARN] Failed to load manifest: $file" >&2
    }
  done

  # Build COMPONENT_ORDER sorted numerically by order field.
  # Uses an indexed array of "ORDER<tab>ID" pairs so duplicate order values
  # are preserved (an associative array keyed by order drops duplicates).
  COMPONENT_ORDER=()
  local _pair_ord _pair_id
  while IFS=$'\t' read -r _pair_ord _pair_id; do
    COMPONENT_ORDER+=("$_pair_id")
  done < <(printf '%s\n' "${_MANIFEST_ORDER_LIST[@]}" | sort -t$'\t' -k1 -n)

  unset _MANIFEST_ORDER_LIST
}

# ── Helper functions (same API as component-registry.sh) ─────────────────────

component_exists() {
  [[ -n "${COMPONENT_SCRIPT[${1}]:-}" ]]
}

component_list() {
  printf '%s\n' "${COMPONENT_ORDER[@]}"
}

component_script() {
  echo "${COMPONENT_SCRIPT[${1}]:-}"
}

component_config_key() {
  echo "${COMPONENT_CONFIG_KEY[${1}]:-}"
}

component_profile() {
  echo "${COMPONENT_PROFILE[${1}]:-}"
}

component_func_prefix() {
  echo "${COMPONENT_FUNC_PREFIX[${1}]:-}"
}

component_display_name() {
  echo "${COMPONENT_DISPLAY_NAME[${1}]:-${1}}"
}

component_install_type() {
  echo "${COMPONENT_INSTALL_TYPE[${1}]:-}"
}

component_wizard_default() {
  echo "${COMPONENT_WIZARD_DEFAULT[${1}]:-false}"
}
