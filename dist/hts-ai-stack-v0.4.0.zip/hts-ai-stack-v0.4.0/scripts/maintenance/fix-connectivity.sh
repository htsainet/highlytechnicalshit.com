#!/usr/bin/env bash
# scripts/maintenance/fix-connectivity.sh — Diagnose and fix SSH + Tailscale + OpenWebUI connectivity
#
# Usage:
#   sudo ./scripts/maintenance/fix-connectivity.sh [--fix] [--password-auth]
#
# Flags:
#   --fix            Attempt to fix detected problems (start services, bring up stack)
#   --password-auth  Also enable SSH password authentication
#
# Read-only by default. Pass --fix to apply repairs.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"

FIX=false
PASSWORD_AUTH=false

for arg in "$@"; do
  case "$arg" in
    --fix)           FIX=true ;;
    --password-auth) PASSWORD_AUTH=true ;;
    *) echo "Unknown argument: $arg"; exit 1 ;;
  esac
done

PASS="✅"
FAIL="❌"
WARN="⚠️ "
FIX_ICON="🔧"

section() { echo; echo "━━━ $1 ━━━"; }
ok()      { echo "  ${PASS} $1"; }
fail()    { echo "  ${FAIL} $1"; }
warn()    { echo "  ${WARN} $1"; }
fixed()   { echo "  ${FIX_ICON} $1"; }

# ── Tailscale ──────────────────────────────────────────────────────────────────
section "Tailscale"

if ! command -v tailscale &>/dev/null; then
  fail "tailscale not installed"
else
  TS_STATUS=$(tailscale status --json 2>/dev/null || echo '{}')
  TS_BACKEND=$(echo "$TS_STATUS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('BackendState','unknown'))" 2>/dev/null || echo "unknown")
  TS_IP=$(tailscale ip -4 2>/dev/null || echo "")

  if [[ "$TS_BACKEND" == "Running" ]]; then
    ok "Tailscale running — IP: ${TS_IP}"
  else
    fail "Tailscale state: ${TS_BACKEND}"
    if $FIX; then
      tailscale up
      fixed "Ran: tailscale up"
    else
      echo "    Run with --fix to attempt: tailscale up"
    fi
  fi

  # Tailscale SSH (port 22 hijack) — INTENTIONALLY DISABLED.
  # Enabling Tailscale's built-in SSH replaces native sshd on the tailnet
  # interface and breaks 3rd-party Android/iOS clients (Terminus, Termius,
  # Blink, ConnectBot) which cannot speak Tailscale-native auth. We keep
  # native sshd as the SSH endpoint over the tailnet. To diagnose SSH-over-
  # Tailscale issues, use scripts/maintenance/diagnose-ssh-tailscale.sh.
  TS_RUNSSH="$(tailscale debug prefs 2>/dev/null \
    | python3 -c 'import json,sys; d=json.loads(sys.stdin.read() or "{}"); print(d.get("RunSSH",False))' 2>/dev/null \
    || echo "False")"
  if [[ "$TS_RUNSSH" == "True" ]]; then
    warn "Tailscale SSH hijack is enabled — this breaks mobile SSH clients."
    if $FIX; then
      tailscale set --ssh=false
      fixed "Disabled Tailscale SSH hijack (tailscale set --ssh=false)"
    else
      echo "    Run with --fix to disable: tailscale set --ssh=false"
    fi
  else
    ok "Tailscale SSH hijack disabled (native sshd owns port 22)."
  fi
fi

# ── SSH daemon ────────────────────────────────────────────────────────────────
section "SSH Daemon"

SSH_ACTIVE=$(systemctl is-active sshd 2>/dev/null || systemctl is-active ssh 2>/dev/null || echo "inactive")

if [[ "$SSH_ACTIVE" == "active" ]]; then
  ok "sshd is running"
else
  fail "sshd is not running (state: ${SSH_ACTIVE})"
  if $FIX; then
    systemctl enable --now sshd 2>/dev/null || systemctl enable --now ssh 2>/dev/null
    fixed "Started sshd"
  else
    echo "    Run with --fix to attempt: systemctl enable --now sshd"
  fi
fi

SSHD_CONFIG="/etc/ssh/sshd_config"
PW_AUTH=$(grep -E "^PasswordAuthentication" "$SSHD_CONFIG" 2>/dev/null | awk '{print $2}' || echo "unset")

if [[ "$PW_AUTH" == "yes" ]]; then
  ok "PasswordAuthentication: yes"
elif $PASSWORD_AUTH; then
  if grep -qE "^PasswordAuthentication" "$SSHD_CONFIG"; then
    # Update existing line using Python to avoid sed
    python3 - "$SSHD_CONFIG" <<'PYEOF'
import sys, re, pathlib
p = pathlib.Path(sys.argv[1])
content = p.read_text()
content = re.sub(r'^PasswordAuthentication\s+\S+', 'PasswordAuthentication yes', content, flags=re.MULTILINE)
p.write_text(content)
PYEOF
  else
    echo "PasswordAuthentication yes" >> "$SSHD_CONFIG"
  fi
  systemctl reload sshd 2>/dev/null || systemctl reload ssh 2>/dev/null
  fixed "PasswordAuthentication set to yes and sshd reloaded"
else
  warn "PasswordAuthentication: ${PW_AUTH} — pass --password-auth --fix to enable"
fi

# ── OpenWebUI ─────────────────────────────────────────────────────────────────
section "OpenWebUI"

if ! command -v docker &>/dev/null; then
  fail "docker not installed"
else
  OWU_CONTAINER=$(docker ps --filter "name=open-webui" --format "{{.Names}}" 2>/dev/null | head -1)
  OWU_PORT=$(docker ps --filter "name=open-webui" --format "{{.Ports}}" 2>/dev/null | head -1)

  if [[ -n "$OWU_CONTAINER" ]]; then
    ok "Container running: ${OWU_CONTAINER} (${OWU_PORT})"
  else
    fail "OpenWebUI container not running"
    if $FIX; then
      cd "$REPO_ROOT"
      docker compose up -d
      fixed "Ran: docker compose up -d"
    else
      echo "    Run with --fix to attempt: docker compose up -d"
    fi
  fi
fi

# ── Firewall ──────────────────────────────────────────────────────────────────
section "Firewall (ufw)"

if command -v ufw &>/dev/null; then
  UFW_STATUS=$(ufw status 2>/dev/null | head -1)
  echo "  Status: ${UFW_STATUS}"
  if echo "$UFW_STATUS" | grep -q "inactive"; then
    ok "ufw inactive — no firewall blocking"
  else
    ufw status numbered 2>/dev/null | grep -E "(22|3000|8080|Tailscale)" | while read -r line; do
      echo "    $line"
    done

    # Check port 3000 specifically
    if ufw status 2>/dev/null | grep -qE "^3000"; then
      ok "Port 3000 allowed in UFW"
    else
      fail "Port 3000 NOT in UFW rules — OpenWebUI will be blocked"
      if $FIX; then
        ufw allow in on tailscale0 to any port 3000 comment "OpenWebUI — Tailscale only"
        fixed "Added UFW rule: port 3000 on tailscale0"
      else
        echo "    Run with --fix to add: ufw allow in on tailscale0 to any port 3000"
      fi
    fi
  fi
else
  ok "ufw not installed"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
section "Summary"

TS_IP_FINAL=$(tailscale ip -4 2>/dev/null || echo "unavailable")
echo "  Tailscale IP : ${TS_IP_FINAL}"
echo "  SSH address  : ${TS_IP_FINAL}:22"
echo "  OpenWebUI    : http://${TS_IP_FINAL}:3000"
echo
if ! $FIX; then
  echo "  ℹ️  Re-run with --fix to auto-repair detected issues"
  echo "  ℹ️  Add --password-auth to also enable SSH password login"
fi
