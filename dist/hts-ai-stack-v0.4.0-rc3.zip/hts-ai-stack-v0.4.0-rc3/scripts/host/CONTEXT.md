# Host Provisioning Scripts

Last updated: 2026-04-16 12:00:00

## What happens here

This workspace contains scripts that configure the host operating system before any Docker services run. Each script targets a specific subsystem (Docker engine, NVIDIA drivers, Node.js, NAS mounts) and the prerequisite tracker documents every apt package the stack installs.

## Process / Workflow

1. `bootstrap.sh` (repo root) calls host scripts to install OS-level dependencies.
   NVIDIA drivers are always installed **last** because they require a forced reboot.
2. After reboot, `install.sh` runs remaining idempotent host scripts (docker, node, tools)
   before delegating to `converge.sh` for Docker service deployment
3. Each `{subsystem}.sh` is idempotent — detects if already provisioned before acting
4. `prerequisites.json` tracks every `apt-get install` across the entire stack
5. `Test-HostPrerequisites.Tests.ps1` enforces that no package is installed without a tracker entry

## Ownership

| Script | Called by | Notes |
|--------|-----------|-------|
| `nvidia.sh` | `bootstrap.sh` only | NVIDIA drivers + CUDA. Always last in bootstrap — requires reboot |
| `docker.sh` | `bootstrap.sh`, then idempotent re-run in `install.sh` | Docker CE + Compose |
| `node.sh` | `install.sh` | NVM + Node.js |
| `tools.sh` | `install.sh` | jq, .env tokens, backend config; dev tools gated by `admin.install_dev_tools` |
| `nas.sh` | Standalone / manual | NFS plumbing — separate from main install flow |

## Files and structure

| File | Purpose |
|------|---------|
| `docker.sh` | Install Docker CE, Docker Compose plugin, add user to docker group |
| `nvidia.sh` | Install NVIDIA drivers and NVIDIA Container Toolkit for GPU passthrough |
| `tools.sh` | Install utility packages (curl, jq, yq, tree, htop, etc.) |
| `node.sh` | Install Node.js via NodeSource for npm-based tooling |
| `nas.sh` | Configure Synology NAS mounts for model cache and backups |
| `prerequisites.json` | Stack-wide apt prerequisite tracker (all scopes, all scripts) |

## What good looks like

- Every `apt-get install` in the stack has a matching entry in `prerequisites.json`
- Each entry includes: package name, installer script path, reason, date added, scope
- Valid scopes: `core`, `dev`, `admin`, `optional`, `service`, `networking`, `tooling`
- Scripts check for existing installs before running (idempotent)
- NVIDIA script handles driver install + reboot gate correctly
- Pester test `Test-HostPrerequisites.Tests.ps1` passes on every commit

## Tools and skills

- **apt-get** — Package installation on Ubuntu
- **Pester** — `Test-HostPrerequisites.Tests.ps1` cross-references all apt installs against the tracker
- **jq** — Used by other scripts to parse `prerequisites.json` (not available during bootstrap itself)
