#!/usr/bin/env bash
# scripts/components/gitea/gitea.sh — Gitea self-hosted git: install, start, health
#
# Standalone usage:
#   ./scripts/components/gitea/gitea.sh              # full: install + configure + start + health
#   ./scripts/components/gitea/gitea.sh --install    # install only
#   ./scripts/components/gitea/gitea.sh --configure  # configure only
#   ./scripts/components/gitea/gitea.sh --start      # start only
#   ./scripts/components/gitea/gitea.sh --stop       # stop
#   ./scripts/components/gitea/gitea.sh --restart    # restart (stop + start)
#   ./scripts/components/gitea/gitea.sh --health     # health check only
#   ./scripts/components/gitea/gitea.sh --status     # show status + port + health
#   ./scripts/components/gitea/gitea.sh --destroy    # destroy (remove containers + volumes)
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"
source "$REPO_DIR/scripts/lib/compose.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
GITEA_CONTAINER="${GITEA_CONTAINER:-hts-ai-gitea-1}"
GITEA_PORT="${GITEA_PORT:-3001}"

# ── Functions ────────────────────────────────────────────────────────────────

# gitea_install — Pull the Gitea Docker image
gitea_install() {
  step "Gitea — install"
  compose_build gitea
  ok "Gitea image built."
}

# gitea_configure — Minimal configuration (env vars are in docker-compose.yml)
gitea_configure() {
  step "Gitea — configure"
  info "Gitea configuration is managed via docker-compose.yml environment block."
  ok "Gitea configured."
}

# gitea_start — Bring up Gitea via compose
gitea_start() {
  step "Gitea — start"
  compose_up gitea
  ok "Gitea started (internal port ${GITEA_PORT})."
}

# gitea_stop — Bring down Gitea
gitea_stop() {
  step "Gitea — stop"
  compose_down gitea
  ok "Gitea stopped."
}

# gitea_health — Probe the Gitea health endpoint
gitea_health() {
  step "Gitea — health"
  wait_for_healthy "$GITEA_CONTAINER" 60
}

gitea_restart() {
  gitea_stop
  gitea_start
}

gitea_destroy() {
  step "Gitea — destroy"
  compose_down gitea -v
  ok "Gitea destroyed."
}

gitea_status() {
  local cid
  cid=$(docker ps -qf "label=com.docker.compose.service=gitea" 2>/dev/null)
  if [[ -n "$cid" ]]; then
    ok "Gitea is running (port ${GITEA_PORT})"
  else
    warn "Gitea is not running."
  fi
  gitea_health 2>/dev/null || true
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)   ACTION="install";   shift ;;
      --configure) ACTION="configure"; shift ;;
      --start)     ACTION="start";     shift ;;
      --stop)      ACTION="stop";      shift ;;
      --restart)   ACTION="restart";   shift ;;
      --health)    ACTION="health";    shift ;;
      --status)    ACTION="status";    shift ;;
      --destroy)   ACTION="destroy";   shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    install)   gitea_install   ;;
    configure) gitea_configure ;;
    start)     gitea_start     ;;
    stop)      gitea_stop      ;;
    restart)   gitea_restart   ;;
    health)    gitea_health    ;;
    status)    gitea_status    ;;
    destroy)   gitea_destroy   ;;
    default)
      gitea_install
      gitea_configure
      gitea_start
      gitea_health
      ;;
  esac
fi
