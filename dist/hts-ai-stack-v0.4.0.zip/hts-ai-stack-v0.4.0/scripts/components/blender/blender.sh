#!/usr/bin/env bash
# scripts/components/blender/blender.sh — Blender: install, configure, health
#
# Host-native installer for Blender, the free 3D creation suite.
# 3D modeling, rigging, animation, simulation, rendering (Cycles with CUDA),
# compositing, and video editing.
#
# Standalone usage:
#   ./scripts/components/blender/blender.sh              # full: install + configure + health
#   ./scripts/components/blender/blender.sh --install    # install only
#   ./scripts/components/blender/blender.sh --configure  # configure only
#   ./scripts/components/blender/blender.sh --start      # no-op (desktop app)
#   ./scripts/components/blender/blender.sh --stop       # no-op (desktop app)
#   ./scripts/components/blender/blender.sh --restart    # no-op (desktop app)
#   ./scripts/components/blender/blender.sh --health     # health check only
#   ./scripts/components/blender/blender.sh --status     # show status + health
#   ./scripts/components/blender/blender.sh --destroy    # uninstall Blender
#
# Can also be sourced by bundle scripts for individual function access.
# NOTE: This is a native desktop application, not a Docker service.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration ────────────────────────────────────────────────────────────
load_env

# ── Functions ────────────────────────────────────────────────────────────────

blender_install() {
  step "Blender — install"
  if command -v blender &>/dev/null; then
    skip "Blender already installed."
  else
    info "Installing Blender via snap (official distribution)..."
    sudo snap install blender --classic
    ok "Blender installed."
  fi
}

blender_configure() {
  step "Blender — configure"
  info "Blender is a desktop application — no service configuration needed."
  info "CUDA GPU rendering is available if NVIDIA drivers are installed."
  info "Enable Cycles render engine in Blender > Preferences > System > CUDA."
  ok "Blender configured."
}

blender_start() {
  step "Blender — start"
  info "Blender is a desktop application. Launch from your application menu."
}

blender_stop() {
  step "Blender — stop"
  info "Blender is a desktop application. Close it from the window."
}

blender_restart() {
  blender_stop
  blender_start
}

blender_health() {
  step "Blender — health"
  if command -v blender &>/dev/null; then
    local ver
    ver=$(blender --version 2>/dev/null | head -1 || echo "unknown")
    ok "Blender is installed: $ver"
    return 0
  else
    warn "Blender is not installed."
    return 1
  fi
}

blender_status() {
  step "Blender — status"
  blender_health
}

blender_destroy() {
  step "Blender — destroy"
  if snap list blender &>/dev/null 2>&1; then
    info "Removing Blender snap..."
    sudo snap remove blender
    ok "Blender removed."
  elif dpkg -l blender &>/dev/null 2>&1; then
    info "Removing Blender apt package..."
    sudo apt-get remove -y blender
    ok "Blender removed."
  else
    skip "Blender is not installed."
  fi
}

# ── CLI entry point ──────────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  case "${1:-}" in
    --install)   blender_install   ;;
    --configure) blender_configure ;;
    --start)     blender_start     ;;
    --stop)      blender_stop      ;;
    --restart)   blender_restart   ;;
    --health)    blender_health    ;;
    --status)    blender_status    ;;
    --destroy)   blender_destroy   ;;
    *)
      blender_install
      blender_configure
      blender_health
      ;;
  esac
fi
