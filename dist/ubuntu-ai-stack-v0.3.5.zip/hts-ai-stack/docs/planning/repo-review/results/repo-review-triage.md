# OpenClaw Repo Review — Triage & Priority Plan

**Date:** March 30, 2026
**Total repos in list:** ~170
**Repos worth reviewing:** ~40 (see below)
**Repos to skip:** ~130 (noise, duplicates, unrelated, or too immature)

---

## Triage Methodology

Scored each repo on three criteria:

1. **Core relevance** — Does it directly affect NemoClaw → OpenClaw → Ollama?
2. **Security relevance** — Does it address a threat from your threat model?
3. **Maturity signal** — Is this from a known org, or does it look like a weekend project?

Repos with no description, no stars context, and generic names were deprioritized.
Blockchain/ERC-8004 repos grouped separately for the "interesting but not now" bucket.

---

## TIER 1 — Review First (Core Security)

These directly address security of your core stack. Review in order.

| # | Repo | Why | Category |
|---|------|-----|----------|
| 1 | [slowmist/openclaw-security-practice-guide](https://github.com/slowmist/openclaw-security-practice-guide) | SlowMist is a known blockchain security firm. If they wrote an OpenClaw security guide, it's worth reading regardless of blockchain angle. | security |
| 2 | [prompt-security/clawsec](https://github.com/prompt-security/clawsec) | Prompt Security is a real company focused on LLM security. Their tool likely addresses prompt injection — your #1 threat. | security |
| 3 | [adversa-ai/secureclaw](https://github.com/adversa-ai/secureclaw) | Adversa AI is a known AI red-teaming firm. High likelihood of quality security tooling. | security |
| 4 | [tophant-ai/ClawVault](https://github.com/tophant-ai/ClawVault) | "Agent security" — vault implies credential/secret management, which you need. | security |
| 5 | [Atlas-Cowork/openclaw-reference-setup](https://github.com/Atlas-Cowork/openclaw-reference-setup) | "Production grade openclaw config" — compare against your own setup for gaps. | security |
| 6 | [Tencent/AI-Infra-Guard](https://github.com/Tencent/AI-Infra-Guard) | Tencent is a major org. AI infrastructure security guard — likely covers container/infra hardening. | security |
| 7 | [gendigitalinc/sage](https://github.com/gendigitalinc/sage) | Gen Digital (NortonLifeLock parent). Agent security from an established security company. | security |
| 8 | [sinewaveai/agent-security-scanner-mcp](https://github.com/sinewaveai/agent-security-scanner-mcp) | MCP-based security scanner — could plug directly into your OpenClaw instance. | security |
| 9 | [pegasi-ai/clawreins](https://github.com/pegasi-ai/clawreins) | "Security human approval" — maps to HITL controls from the 2602.11416 paper. | security |
| 10 | [SeyZ/clawbands](https://github.com/SeyZ/clawbands) | "Like OpenShell" — alternative sandboxing approach worth comparing. | security |
| 11 | [microsoft/PromptKit](https://github.com/microsoft/PromptKit) | Already marked high trust. Microsoft prompt engineering toolkit. | microsoft |
| 12 | [Drakon-Systems-Ltd/ShieldCortex](https://github.com/Drakon-Systems-Ltd/ShieldCortex) | "Newer version" of claude-cortex. Security layer — review alongside the older mkdelta221 version. | security |

---

## TIER 2 — Review Second (Architecture & Memory)

These inform your architecture decisions around agent memory, config, and observability.

| # | Repo | Why | Category |
|---|------|-----|----------|
| 13 | [MemTensor/MemOS](https://github.com/MemTensor/MemOS) | Agent memory OS — relevant to your drift detection and memory integrity goals. The HEARTBEAT paper (2603.23064) makes memory architecture critical. | memory |
| 14 | [massaindustries/openclaw-logger](https://github.com/massaindustries/openclaw-logger) | Log analysis for OpenClaw — you have no observability stack yet. Could be a quick win. | security |
| 15 | [onecli/onecli](https://github.com/onecli/onecli) | Agent credential management — relevant to your .env token handling. | security |
| 16 | [clawshell/clawshell](https://github.com/clawshell/clawshell) | Token security — relevant to your OPENCLAW_TOKEN and WEBUI_SECRET_KEY management. | security |
| 17 | [iflytek/skillhub](https://github.com/iflytek/skillhub) | Skill security from iFlytek (major Chinese AI company). Relevant to skill supply chain threat. | security |
| 18 | [NevaMind-AI/memU](https://github.com/NevaMind-AI/memU) | Another memory system — compare approaches for agent state management. | memory |
| 19 | [EverMind-AI/EverMemOS](https://github.com/EverMind-AI/EverMemOS) | Third memory OS option — triangulate the best approach. | memory |
| 20 | [UnitOneAI/SecuritySkills](https://github.com/UnitOneAI/SecuritySkills) | Security-focused OpenClaw skills — could be directly adoptable. | security |

---

## TIER 3 — Review for Character/Persona Architecture

Only relevant if you keep SillyTavern or build equivalent functionality.

| # | Repo | Why | Category |
|---|------|-----|----------|
| 21 | [malfoyslastname/character-card-spec-v2](https://github.com/malfoyslastname/character-card-spec-v2) | The actual V2 character card spec. If you're doing character cards at all, this is the reference. | character-cards |
| 22 | [bradennapier/character-cards-v2](https://github.com/bradennapier/character-cards-v2) | Implementation of the V2 spec — compare with above. | character-cards |
| 23 | [kahalewai/openclaw-secure-personas](https://github.com/kahalewai/openclaw-secure-personas) | "Secure personas" — directly relevant if personas become a security boundary. | personas |
| 24 | [Ca1nlee/persona-cloner-skill](https://github.com/Ca1nlee/persona-cloner-skill) | Persona cloning as an OpenClaw skill — review for both utility and attack surface. | personas |
| 25 | [FanYin1/openclaw-sillytavern-cards](https://github.com/FanYin1/openclaw-sillytavern-cards) | OpenClaw ↔ SillyTavern card integration. | integration |
| 26 | [OpenRouterTeam/character](https://github.com/OpenRouterTeam/character) | OpenRouter's character system — established org, likely well-designed. | character-cards |

---

## TIER 4 — Interesting but Not Now

Worth bookmarking. Review when your core is stable.

### Blockchain / Trustless Agent Identity

| Repo | Why |
|------|-----|
| [ChaosChain/trustless-agents-erc-ri](https://github.com/ChaosChain/trustless-agents-erc-ri) | ERC reference implementation for trustless agents. Your blockchain character storage idea. |
| [erc-8004/erc-8004-contracts](https://github.com/erc-8004/erc-8004-contracts) | The actual ERC-8004 contracts — agent identity on-chain. |
| [sudeepb02/awesome-erc8004](https://github.com/sudeepb02/awesome-erc8004) | Curated list of ERC-8004 resources. |
| [CasualHackathon/TrustlessAgents](https://github.com/CasualHackathon/TrustlessAgents) | Hackathon project — lower maturity but interesting concepts. |
| [jasonsiuxMCP/clawon8004](https://github.com/jasonsiuxMCP/clawon8004) | MCP + ERC-8004 bridge. |
| [ExpertVagabond/awesome-blockchain-mcps](https://github.com/ExpertVagabond/awesome-blockchain-mcps) | Curated blockchain MCP list. |

**Assessment:** The ERC-8004 ecosystem is building toward on-chain agent identity and immutable persona records. Your instinct about blockchain for character storage maps here. As I said earlier, Git with signed commits gives you 90% of the traceability benefit today. ERC-8004 becomes interesting when you need cross-platform agent identity verification or public persona marketplaces. Bookmark for v1.0+.

### Alternative Platforms / LLM Runners

| Repo | Why |
|------|-----|
| [containers/ramalama](https://github.com/containers/ramalama) | Podman-native LLM runner — alternative to Ollama worth knowing about. |
| [LostRuins/koboldcpp](https://github.com/LostRuins/koboldcpp) | KoboldCpp — established alternative LLM runner. |
| [intentee/paddler](https://github.com/intentee/paddler) | LLM load balancer — relevant when you scale beyond one GPU. |
| [mostlygeek/llama-swap](https://github.com/mostlygeek/llama-swap) | Model hot-swapping — relevant to your model promotion workflow. |
| [vllm-project/semantic-router](https://github.com/vllm-project/semantic-router) | Semantic routing — relevant to multi-model architectures. |

### NIST / Compliance Frameworks

| Repo | Why |
|------|-----|
| [Justicegaines03/OpenClaw_NIST-AI-RMF_Compliance](https://github.com/Justicegaines03/OpenClaw_NIST-AI-RMF_Compliance) | NIST AI Risk Management Framework applied to OpenClaw. |
| [Virtual-Enviroment-Fellowship/nist-inspired-openclaw-brain](https://github.com/Virtual-Enviroment-Fellowship/nist-inspired-openclaw-brain) | NIST-inspired agent architecture. |
| [ukncsc/zero-trust-architecture](https://github.com/ukncsc/zero-trust-architecture) | UK NCSC zero trust reference — government source, high credibility. |

### Skills Ecosystem

| Repo | Why |
|------|-----|
| [VoltAgent/awesome-nemoclaw](https://github.com/VoltAgent/awesome-nemoclaw) | Curated NemoClaw resources. |
| [VoltAgent/awesome-openclaw-skills](https://github.com/VoltAgent/awesome-openclaw-skills) | Curated skills list — useful for understanding the ecosystem, but per the skill security paper (2603.16572), treat with caution. |
| [kepano/obsidian-skills](https://github.com/kepano/obsidian-skills) | Kepano (Obsidian creator) — high credibility. Skills for knowledge management. |
| [openclaw/clawhub](https://github.com/openclaw/clawhub) | Official skill hub — understand the distribution channel. |

### Prompt Engineering (from your "ready for dedupe" list)

| Repo | Why |
|------|-----|
| [microsoft/PromptKit](https://github.com/microsoft/PromptKit) | Already in Tier 1. |
| [danielmiessler/Fabric](https://github.com/danielmiessler/Fabric) | Daniel Miessler is a respected security researcher. Fabric is well-established. |
| [BoundaryML/baml](https://github.com/BoundaryML/baml) | Structured LLM output — could help with agent output validation. |

---

## SKIP — Not Worth Reviewing

These fall into: weekend projects with no README, duplicates, unrelated tooling,
repos with concerning trust signals, or things too far from your core stack.

**Skipped categories and reasoning:**

- **LeoYeAI/* repos (7 repos):** Prolific single contributor, many repos with generic names. Review one (openclaw-guardian) if curiosity warrants, skip rest.
- **ExpertVagabond/* repos (5 repos):** Appears to be one person's project suite. Marketplace/template repos — not relevant to core security.
- **Mobile repos (4 repos):** Not in scope for your server-based stack.
- **Most SillyTavern plugins:** Unless you commit to SillyTavern as core, these are peripheral.
- **Misc dashboards/UIs (4 repos):** You have your own dashboard. These add nothing to security.
- **Generic "openclaw-agents" repos:** Most are tutorial/example repos.
- **NanoFlow-io/Clawdboss + variants (3 repos):** Three versions of the same thing suggests instability. Review the latest only if Tier 1 doesn't cover the same ground.
- **Bug bounty toolkit, nginx hardening, Linux audit:** Generic DevOps — not agent-specific. You already know how to do this.
- **openclaw/skills:** You marked this not-trusted yourself. Agree.
- **Repos with no description AND unknown trust:** ~40 repos. Not worth spending rate limit budget on.

---

## Review Session Plan

**Session 2 (next):** Tier 1 repos 1-6 (security repos from known orgs)
**Session 3:** Tier 1 repos 7-12 (remaining security + Microsoft)
**Session 4:** Tier 2 repos 13-20 (memory + observability + credentials)
**Session 5:** Tier 3 repos 21-26 (character/persona — only if SillyTavern stays)
**Session 6:** Cherry-pick from Tier 4 based on what Tier 1-3 reveals

Each session: I fetch README + key files for 5-6 repos, assess fit, flag security concerns,
and update your references list with trust levels and review dates.

---

## Repos to Reclassify in Your List

A few repos are miscategorized in your current list:

| Repo | Current Category | Suggested Category |
|------|-----------------|-------------------|
| slowmist/openclaw-security-practice-guide | alternative-platforms | security |
| Tencent/AI-Infra-Guard | alternative-platforms | security |
| SeyZ/clawbands | alternative-platforms | security |
| X-Scale-AI/openclaw-security | unclassified | security |
| X-Scale-AI/grits-audit | unclassified | security |
| oceanbase/powermem | personas | memory |
| MemTensor/MemOS-Cloud-OpenClaw-Plugin | personas | memory |
| comet-ml/opik-openclaw | personas | observability |

---

## The Blockchain Question — Detailed Take

You mentioned a repo that stores characters in blockchain. That maps to the
ERC-8004 cluster above. Here's the tradeoff matrix:

| Approach | Integrity | Traceability | Complexity | When to Use |
|----------|-----------|-------------|------------|-------------|
| Git + signed commits | High | High | Low | Now. Single operator, local stack. |
| Git + CI validation | High | High | Medium | v0.3+. When you have Jenkins/CI running. |
| Content-addressed storage (IPFS) | Very high | Medium | Medium | When you need tamper-proof distribution. |
| On-chain (ERC-8004) | Immutable | Public | High | Multi-tenant, marketplace, cross-platform identity. |

**Recommendation:** Start with Git + signed commits. It's already in your stack,
costs nothing, and gives you full diff history. Layer blockchain when you have
a reason for public verifiability or cross-platform agent identity.
