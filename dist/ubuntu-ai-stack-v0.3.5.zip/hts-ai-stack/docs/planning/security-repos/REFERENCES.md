# Security Repos — Tracking

Repositories focused on security tooling, hardening, and threat defense for AI agent stacks.
Cross-referenced with our [threat model](../security-review/CONTEXT.md).
Review workflow documented in [CONTEXT.md](CONTEXT.md).

**Trust:** `high` · `reference` · `medium` · `unknown` · `not-trusted`
**Health:** `healthy` · `watch` · `stale`

---

| Repo | Description | Trust | Bots Reviewed | Engine | Health | Last Update | Last Checked | Details |
|------|-------------|-------|---------------|--------|--------|-------------|--------------|---------|
| [Tencent/AI-Infra-Guard](https://github.com/Tencent/AI-Infra-Guard) | Full-stack AI red teaming and security platform (3.4k★, Apache 2.0, Python, 2026-03-31). Agent/skill/MCP scanning, jailbreak evaluation | high | haiku-4-5 | haiku | healthy | 2026-03-31 | 2026-03-31 | |
| [slowmist/openclaw-security-practice-guide](https://github.com/slowmist/openclaw-security-practice-guide) | Three-layer defense matrix (pre/in/post-action), nightly audit, Git brain backup, skill audit (2.6k★, MIT) | medium | haiku-4-5 | haiku | healthy | 2026-03-30 | 2026-03-31 | [slowmist-openclaw-security-practice-guide.md](results/slowmist-openclaw-security-practice-guide.md) |
| [prompt-security/clawsec](https://github.com/prompt-security/clawsec) | Drift detection for SOUL.md/IDENTITY.md, SHA256 skill verification, NVD CVE feed, audit watchdog. Prompt Security / SentinelOne | unknown | | | | | | [prompt-security-clawsec.md](results/prompt-security-clawsec.md) |
| [adversa-ai/secureclaw](https://github.com/adversa-ai/secureclaw) | AI red-teaming firm — agent security tooling | unknown | | | | | | |
| [tophant-ai/ClawVault](https://github.com/tophant-ai/ClawVault) | Credential/secret management for agents | unknown | | | | | | |
| [Atlas-Cowork/openclaw-reference-setup](https://github.com/Atlas-Cowork/openclaw-reference-setup) | Production-grade OpenClaw config — compare against our setup | unknown | | | | | | |
| [gendigitalinc/sage](https://github.com/gendigitalinc/sage) | Agent security from Gen Digital (NortonLifeLock parent) | unknown | | | | | | |
| [sinewaveai/agent-security-scanner-mcp](https://github.com/sinewaveai/agent-security-scanner-mcp) | MCP-based security scanner | unknown | | | | | | |
| [pegasi-ai/clawreins](https://github.com/pegasi-ai/clawreins) | Security human approval / HITL controls | unknown | | | | | | |
| [SeyZ/clawbands](https://github.com/SeyZ/clawbands) | Alternative sandboxing — compare with OpenShell | unknown | | | | | | |
| [Drakon-Systems-Ltd/ShieldCortex](https://github.com/Drakon-Systems-Ltd/ShieldCortex) | Security layer for agents (newer version of claude-cortex) | unknown | | | | | | |
| [tonioloewald/ajs-clawbot](https://github.com/tonioloewald/ajs-clawbot) | Agent security | unknown | | | | | | |
| [onecli/onecli](https://github.com/onecli/onecli) | Agent credential management | unknown | | | | | | |
| [clawshell/clawshell](https://github.com/clawshell/clawshell) | Token security | unknown | | | | | | |
| [SafeAI-Lab-X/ClawKeeper](https://github.com/SafeAI-Lab-X/ClawKeeper) | Norton-like security for OpenClaw | unknown | | | | | | |
| [SleuthCo/clawshield-public](https://github.com/SleuthCo/clawshield-public) | Agent security (needs Anthropic) | unknown | | | | | | |
| [freema/openclaw-mcp](https://github.com/freema/openclaw-mcp) | MCP server for OpenClaw | unknown | | | | | | |
| [NanoFlow-io/Clawdboss](https://github.com/NanoFlow-io/Clawdboss) | Agent security | unknown | | | | | | |
| [NanoFlow-io/clawdboss-upgrade](https://github.com/NanoFlow-io/clawdboss-upgrade) | Agent security (upgrade) | unknown | | | | | | |
| [NanoFlow-io/clawdboss-lite](https://github.com/NanoFlow-io/clawdboss-lite) | Agent security (lite) | unknown | | | | | | |
| [arthurpanhku/DocSentinel](https://github.com/arthurpanhku/DocSentinel) | Agent security | unknown | | | | | | |
| [knownsec/openclaw-security](https://github.com/knownsec/openclaw-security) | | unknown | | | | | | |
| [secnova-ai/ClawdSecbot](https://github.com/secnova-ai/ClawdSecbot) | | unknown | | | | | | |
| [knostic/openclaw-shield](https://github.com/knostic/openclaw-shield) | | unknown | | | | | | |
| [massaindustries/openclaw-logger](https://github.com/massaindustries/openclaw-logger) | Log analysis for OpenClaw | unknown | | | | | | |
| [mholovetskyi/openclawenterprise](https://github.com/mholovetskyi/openclawenterprise) | Security layer | unknown | | | | | | |
| [iflytek/skillhub](https://github.com/iflytek/skillhub) | Skill security from iFlytek | unknown | | | | | | |
| [mkdelta221/claude-cortex](https://github.com/mkdelta221/claude-cortex) | Older version of ShieldCortex | unknown | | | | | | |
| [enabled404/openclawsecurity](https://github.com/enabled404/openclawsecurity) | | unknown | | | | | | |
| [UnitOneAI/SecuritySkills](https://github.com/UnitOneAI/SecuritySkills) | Security-focused OpenClaw skills | unknown | | | | | | |
| [Justicegaines03/OpenClaw_NIST-AI-RMF_Compliance](https://github.com/Justicegaines03/OpenClaw_NIST-AI-RMF_Compliance) | NIST AI RMF applied to OpenClaw | unknown | | | | | | |
| [Virtual-Enviroment-Fellowship/nist-inspired-openclaw-brain](https://github.com/Virtual-Enviroment-Fellowship/nist-inspired-openclaw-brain) | NIST-inspired agent architecture | unknown | | | | | | |
| [oscarsixsecllc/sarge](https://github.com/oscarsixsecllc/sarge) | | unknown | | | | | | |
| [ClawSecure/clawsecure-openclaw-security](https://github.com/ClawSecure/clawsecure-openclaw-security) | | unknown | | | | | | |
| [InitiumBuilders/claris-ai](https://github.com/InitiumBuilders/claris-ai) | | unknown | | | | | | |
| [droxey/clincher](https://github.com/droxey/clincher) | | unknown | | | | | | |
| [GravityZenAI/AI-Bastion](https://github.com/GravityZenAI/AI-Bastion) | | unknown | | | | | | |
| [corbat-tech/corbat-openclaw-hardening](https://github.com/corbat-tech/corbat-openclaw-hardening) | | unknown | | | | | | |
| [darfaz/clawmoat](https://github.com/darfaz/clawmoat) | | unknown | | | | | | |
| [rnieva421/OpenClaw-ClawSec-ContainerHardening](https://github.com/rnieva421/OpenClaw-ClawSec-ContainerHardening) | | unknown | | | | | | |
| [PWani/aegis](https://github.com/PWani/aegis) | | unknown | | | | | | |
| [jd-opensource/JoySafeter](https://github.com/jd-opensource/JoySafeter) | Agent security builder | unknown | | | | | | |
| [ukncsc/zero-trust-architecture](https://github.com/ukncsc/zero-trust-architecture) | UK NCSC zero trust reference | unknown | | | | | | |
| [X-Scale-AI/grits-audit](https://github.com/X-Scale-AI/grits-audit) | Security audit tooling | unknown | | | | | | |
| [X-Scale-AI/openclaw-security](https://github.com/X-Scale-AI/openclaw-security) | Security tooling | unknown | | | | | | |
