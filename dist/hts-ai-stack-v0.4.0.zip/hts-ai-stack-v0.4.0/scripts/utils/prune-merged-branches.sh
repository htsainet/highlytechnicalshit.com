#!/usr/bin/env bash
# Prune branches whose commits are already in origin/main.
# Leaves protected remote branches alone (e.g., main, HEAD).
# Run on host (not inside snap) so HTTPS works.
set -euo pipefail

cd "$(dirname "$0")/../.."

PROTECTED_REMOTE=("main" "HEAD")

echo ">>> Fetching origin..."
git fetch origin --prune

echo ">>> Ensuring we're on main..."
git checkout main
git pull --ff-only origin main

echo ""
echo ">>> Local branches fully merged into main (will be deleted):"
mapfile -t LOCAL_MERGED < <(git branch --merged main --format='%(refname:short)' | grep -vx main || true)
if ((${#LOCAL_MERGED[@]} == 0)); then
  echo "    (none)"
else
  printf '    %s\n' "${LOCAL_MERGED[@]}"
  for b in "${LOCAL_MERGED[@]}"; do
    # commits on this branch not in main — should be empty since --merged reports it
    if [[ -z "$(git log --oneline "main..${b}" 2>/dev/null)" ]]; then
      # safe: every commit is in main. Use -D because -d compares to upstream
      # tracking ref, which may be stale or diverged.
      git branch -D "$b"
    else
      echo "    skipping $b (has commits not in main)"
    fi
  done
fi

echo ""
echo ">>> Remote branches fully merged into origin/main (candidates):"
CANDIDATES=()
while IFS= read -r rb; do
  # Only accept refs literally starting with "origin/" and containing a real branch name
  [[ "$rb" == origin/* ]] || continue
  short="${rb#origin/}"
  # Skip weird/empty shorts (e.g., "origin" alone, or HEAD alias)
  [[ -z "$short" || "$short" == "origin" || "$short" == HEAD* ]] && continue
  skip=0
  for p in "${PROTECTED_REMOTE[@]}"; do
    [[ "$short" == "$p" ]] && skip=1 && break
  done
  ((skip)) && continue
  # Verify the remote ref actually exists before considering it
  git show-ref --verify --quiet "refs/remotes/origin/${short}" || continue
  # zero unique commits vs main => fully merged
  if [[ -z "$(git log --oneline "origin/main..origin/${short}" 2>/dev/null)" ]]; then
    CANDIDATES+=("$short")
  fi
done < <(git branch -r --format='%(refname:short)')

if ((${#CANDIDATES[@]} == 0)); then
  echo "    (none)"
else
  printf '    origin/%s\n' "${CANDIDATES[@]}"
  echo ""
  read -r -p ">>> Delete these ${#CANDIDATES[@]} remote branch(es) on GitHub? [y/N] " ans
  if [[ "${ans,,}" == "y" ]]; then
    for b in "${CANDIDATES[@]}"; do
      echo "    git push origin --delete $b"
      git push origin --delete "$b" || echo "      (failed; continuing)"
    done
  else
    echo "    skipped."
  fi
fi

echo ""
echo ">>> Final state:"
git --no-pager branch -a
