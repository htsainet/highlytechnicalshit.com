#!/usr/bin/env bash
# scripts/lib/gpu.sh — GPU detection and VRAM helpers
# Source this file; do NOT run directly.
#
# Requires: common.sh sourced first (for ok / warn helpers).
#
# Functions:
#   get_gpu_vram_gb        — returns max total VRAM across GPUs in whole GB (0 if no GPU)
#   get_gpu_free_vram_gb   — returns free VRAM on first GPU in whole GB (0 if no GPU)
#   check_vram_requirement — exits 1 if total VRAM < required
#   check_free_vram        — exits 1 if free VRAM < required
#
# NOTE: free VRAM checks are point-in-time snapshots — usage changes as
# models load/unload (e.g. via llama-swap). FEATURE-052 will replace
# these spot checks with a proper VRAM budget system that tracks all
# selected services' requirements against total GPU capacity.

# ── VRAM detection ───────────────────────────────────────────────────────────

get_gpu_vram_gb() {
  if ! command -v nvidia-smi &>/dev/null; then
    echo 0
    return
  fi
  # Query total memory in MiB, take the max across GPUs, convert to GB
  nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>/dev/null \
    | sort -rn | head -1 | awk '{printf "%d", $1 / 1024}'
}

get_gpu_free_vram_gb() {
  if ! command -v nvidia-smi &>/dev/null; then
    echo 0
    return
  fi
  # Query free memory in MiB on the first GPU, convert to GB
  nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits 2>/dev/null \
    | head -1 | awk '{printf "%d", $1 / 1024}'
}

# check_vram_requirement <required_gb> [component_name]
# Returns 0 if total VRAM is sufficient, 1 otherwise (with warnings).
check_vram_requirement() {
  local required_gb=$1
  local component="${2:-this component}"
  local available_gb
  available_gb=$(get_gpu_vram_gb)

  if [[ "$available_gb" -lt "$required_gb" ]]; then
    warn "${component} requires ≥${required_gb}GB VRAM."
    warn "Detected: ${available_gb}GB total VRAM."
    warn "This component is wired up but cannot run on current hardware."
    return 1
  fi
  ok "VRAM check passed: ${available_gb}GB total (≥${required_gb}GB required)"
  return 0
}

# check_free_vram <required_gb> [component_name]
# Returns 0 if free VRAM right now is sufficient, 1 otherwise.
# This is a point-in-time snapshot — see FEATURE-052 for the planned
# budget-based approach that will supersede this.
check_free_vram() {
  local required_gb=$1
  local component="${2:-this component}"
  local free_gb
  free_gb=$(get_gpu_free_vram_gb)

  if [[ "$free_gb" -lt "$required_gb" ]]; then
    warn "${component} needs ≥${required_gb}GB free VRAM."
    warn "Currently free: ${free_gb}GB (other models may be loaded)."
    return 1
  fi
  ok "Free VRAM check passed: ${free_gb}GB free (≥${required_gb}GB needed)"
  return 0
}
