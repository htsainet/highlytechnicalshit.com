#!/usr/bin/env pwsh

<#
.SYNOPSIS
Auto-updates "Last updated" timestamps in CONTEXT.md files based on file modification date.

.DESCRIPTION
Scans all CONTEXT.md files and updates their "Last updated: YYYY-MM-DD HH:MM:SS" marker
to match the file's last modified timestamp. Creates marker if it doesn't exist.

.EXAMPLE
./Update-ContextTimestamps.ps1
Updates all CONTEXT.md files in the repository.

.EXAMPLE
./Update-ContextTimestamps.ps1 -RepoRoot /path/to/repo -Verbose
Updates with verbose output showing each file processed.
#>

param(
    [string]$RepoRoot = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)),
    [switch]$WhatIf
)

$ErrorActionPreference = 'Stop'

# Find all CONTEXT.md files
$ContextFiles = @(Get-ChildItem -Path $RepoRoot -Filter "CONTEXT.md*" -Recurse)

Write-Host "Found $($ContextFiles.Count) CONTEXT.md files to process"

foreach ($File in $ContextFiles) {
    $Content = Get-Content $File.FullName -Raw
    $LastModified = $File.LastWriteTime
    $TimestampString = $LastModified.ToString('yyyy-MM-dd HH:mm:ss')
    $NewMarker = "Last updated: $TimestampString"

    # Check if file already has a timestamp
    if ($Content -match 'Last updated[:\s]+\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}') {
        # Replace existing timestamp
        $Content = $Content -replace 'Last updated[:\s]+\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}', $NewMarker
        $Action = "Updated"
    }
    elseif ($Content -match 'Last updated') {
        # Replace any existing Last updated marker (regardless of format)
        $Content = $Content -replace 'Last updated[^\n]*', $NewMarker
        $Action = "Upgraded"
    }
    else {
        # Add marker after first heading (# Title)
        $Lines = $Content -split "`n"
        $NewLines = @()
        $Added = $false

        foreach ($Line in $Lines) {
            $NewLines += $Line
            if (-not $Added -and $Line -match '^# ') {
                $NewLines += ""
                $NewLines += $NewMarker
                $Added = $true
            }
        }

        $Content = $NewLines -join "`n"
        $Action = "Added"
    }

    if ($WhatIf) {
        Write-Host "$Action (WhatIf): $($File.FullName) => $TimestampString"
    }
    else {
        Set-Content -Path $File.FullName -Value $Content -NoNewline
        Write-Host "$Action`: $($File.FullName) => $TimestampString"
    }
}

Write-Host "Done. Processed $($ContextFiles.Count) files."
