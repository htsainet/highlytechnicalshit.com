# Tailscale ACL Enforcement

**Priority:** HIGH
**Effort:** 1-2 hours
**Risk:** Low — escape hatch approach means zero behavioral change until intentionally enforced
**Target Release:** v0.5.0
**Threat:** Any device joining the tailnet (including less-trusted or borrowed devices) can reach every service on the OpenClaw host — Ollama, llama-swap, Open WebUI, Grafana, Portainer — with no access controls. The Tailscale ACL policy exists in `config/tailscale-acl-policy.jsonc` but the escape hatch is active.
**Depends on:** SECURITY-000 (services should be localhost-bound before closing the escape hatch, so Tailscale becomes the only network path)
**Blocks:** Nothing

## Problem

The current ACL policy in `config/tailscale-acl-policy.jsonc` has a working escape hatch:

```jsonc
{"action": "accept", "src": ["*"], "dst": ["*:*"]}
```

This means every tailnet device has full access to every port. The granular `tag:operator →
tag:openclaw-host` rules are defined but inactive. The policy was designed with a safe rollout
approach — but the switch has never been flipped.

## Solution

Close the escape hatch once SECURITY-000 is confirmed working. With services bound to
`127.0.0.1` and UFW active, Tailscale becomes the only ingress path — so ACL enforcement
becomes the final meaningful access control layer.

## Implementation Steps

### 1. Confirm operator tags are applied

Tag the OpenClaw host (if not already done by Tailscale sidecar):

```bash
sudo tailscale set --advertise-tags=tag:openclaw-host
```

Tag each operator device via the Tailscale admin console or:

```bash
sudo tailscale set --advertise-tags=tag:operator
```

### 2. Verify granular rules in `config/tailscale-acl-policy.jsonc`

Current defined rules allow `tag:operator` access to:

| Port | Service |
|------|---------|
| 22 | SSH |
| 80 | Dashboard |
| 3000 | Open WebUI |
| 11434 | Ollama |
| 18789 | NemoClaw GPU sandbox |

Add any missing ports before closing the escape hatch.

### 3. Close the escape hatch

In the Tailscale admin console (Access Controls tab), comment out:

```jsonc
// {"action": "accept", "src": ["*"], "dst": ["*:*"]},
```

The granular rules immediately take effect. Test from an operator device — all tagged
services should be reachable. Test from a non-operator device — all should be blocked.

### 4. Commit the updated ACL policy

```bash
cp <exported-policy> config/tailscale-acl-policy.jsonc
git add config/tailscale-acl-policy.jsonc
git commit -m "security: close Tailscale ACL escape hatch"
```

## Acceptance Criteria

- `config/tailscale-acl-policy.jsonc` has escape hatch commented out
- Operator device can reach all listed ports via Tailscale IP
- Non-operator device (or device without tag) cannot reach any port
- `tailscale ping <openclaw-host>` succeeds from operator device
