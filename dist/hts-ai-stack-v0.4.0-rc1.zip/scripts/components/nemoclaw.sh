#!/usr/bin/env bash
# scripts/components/nemoclaw.sh — NemoClaw sandbox: install, onboard, configure
#
# Standalone usage:
#   ./scripts/components/nemoclaw.sh              # full setup: install + configure + onboard + health
#   ./scripts/components/nemoclaw.sh --onboard     # onboard sandboxes only
#   ./scripts/components/nemoclaw.sh --configure   # cgroup v2 + registry + provider config
#   ./scripts/components/nemoclaw.sh --health      # health check only
#   ./scripts/components/nemoclaw.sh --stop        # destroy all sandboxes
#   ./scripts/components/nemoclaw.sh --update      # update OpenClaw inside sandboxes
#
# Can also be sourced by bundle scripts for individual function access.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$REPO_DIR/scripts/lib/common.sh"
source "$REPO_DIR/scripts/lib/health.sh"

# ── Configuration from .env ──────────────────────────────────────────────────
load_env
NEMOCLAW_DEPLOY="${NEMOCLAW_DEPLOY:-true}"
NEMOCLAW_AGENT_PERSONAS="${NEMOCLAW_AGENT_PERSONAS:-true}"
NEMOCLAW_AUTO_UPDATE="${NEMOCLAW_AUTO_UPDATE:-false}"
OLLAMA_MODEL="${OLLAMA_MODEL:-gemma4:e4b}"
# NemoClaw internally hardcodes gateway name "nemoclaw" — no override needed.
LLAMA_SWAP_HOST_URL="http://host.openshell.internal:${LLAMA_SWAP_PORT:-8081}/v1"

# ── Internal helpers ─────────────────────────────────────────────────────────

_ensure_sudo() {
  if sudo -n true 2>/dev/null; then return 0; fi
  info "Administrator privileges required."
  sudo -v || { fail "Sudo authentication failed."; exit 1; }
}

_source_nvm() {
  NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
  set +eu
  # shellcheck disable=SC1091
  if [[ -s "$NVM_DIR/nvm.sh" ]]; then source "$NVM_DIR/nvm.sh"; fi
  set -eu
}

# Work around openclaw tarball missing directory entries (GH-503).
# npm's tar extractor hard-fails because the tarball is missing directory
# entries for extensions/, skills/, and dist/plugin-sdk/config/. System tar
# handles this fine. We pre-extract openclaw into node_modules BEFORE npm
# install so npm sees the dependency is already satisfied and skips it.
# Ported from upstream NVIDIA/NemoClaw scripts/install.sh.
_pre_extract_openclaw() {
  local install_dir="$1" npm_bin="$2"
  local openclaw_version

  # Resolve openclaw version from package.json
  if [[ -f "${install_dir}/package.json" ]] && command -v node &>/dev/null; then
    openclaw_version=$(node -e "const v = require('${install_dir}/package.json').dependencies?.openclaw; if (v) console.log(v)" 2>/dev/null || true)
  fi
  if [[ -z "${openclaw_version:-}" && -f "${install_dir}/Dockerfile.base" ]]; then
    openclaw_version=$(awk 'match($0, /openclaw@[0-9][0-9.]+/) { print substr($0, RSTART + 9, RLENGTH - 9); exit }' "${install_dir}/Dockerfile.base")
  fi

  if [[ -z "${openclaw_version:-}" ]]; then
    warn "Could not determine openclaw version — skipping pre-extraction"
    return 1
  fi

  info "Pre-extracting openclaw@${openclaw_version} with system tar (GH-503 workaround)…"
  local tmpdir
  tmpdir=$(mktemp -d)
  if "$npm_bin" pack "openclaw@${openclaw_version}" --pack-destination "$tmpdir" >/dev/null 2>&1; then
    local tgz
    tgz=$(find "$tmpdir" -maxdepth 1 -name 'openclaw-*.tgz' -print -quit)
    if [[ -n "$tgz" && -f "$tgz" ]]; then
      if mkdir -p "${install_dir}/node_modules/openclaw" \
        && tar xzf "$tgz" -C "${install_dir}/node_modules/openclaw" --strip-components=1; then
        info "openclaw pre-extracted successfully"
      else
        warn "Failed to extract openclaw tarball"
        rm -rf "$tmpdir"
        return 1
      fi
    else
      warn "npm pack succeeded but tarball not found"
      rm -rf "$tmpdir"
      return 1
    fi
  else
    warn "Failed to download openclaw tarball"
    rm -rf "$tmpdir"
    return 1
  fi
  rm -rf "$tmpdir"
}

# Verify that a nemoclaw binary is the real NemoClaw CLI and not the broken
# placeholder npm package (npmjs.org/nemoclaw 0.1.0 — 249 bytes, no build
# artifacts). The real CLI prints "nemoclaw v<semver>" on --version.
# Ported from upstream NVIDIA/NemoClaw scripts/install.sh (PR #970, #1606).
_is_real_nemoclaw_cli() {
  local bin_path="${1:-nemoclaw}"
  local version_output
  version_output=$("$bin_path" --version 2>/dev/null) || return 1
  # Real CLI outputs: "nemoclaw v0.0.10" (or any semver, with optional pre-release)
  [[ "$version_output" =~ ^nemoclaw[[:space:]]+v[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?$ ]]
}

_check_sandbox_health() {
  local sandbox="$1"
  local status_out
  status_out=$(nemoclaw "$sandbox" status 2>/dev/null)

  local phase nim
  phase=$(echo "$status_out" | grep "Phase:" | awk '{print $2}')
  nim=$(echo "$status_out"   | grep "NIM:"   | sed 's/.*NIM:[[:space:]]*//')

  echo -e "    Phase : ${phase:-unknown}"
  echo -e "    NIM   : ${nim:-unknown}"

  [[ "${phase:-}" == "Ready" ]]
}

_do_onboard() {
  local sandbox="$1" model="$2"
  local timeout_sec="${NEMOCLAW_ONBOARD_TIMEOUT:-600}"
  local log_file="$REPO_DIR/logs/nemoclaw-gateway-${sandbox}.log"
  mkdir -p "$REPO_DIR/logs"

  # Pre-flight: verify llama-swap is reachable before attempting onboard
  local swap_port="${LLAMA_SWAP_PORT:-8081}"
  if ! curl -sf "http://localhost:${swap_port}/health" >/dev/null 2>&1; then
    fail "Pre-flight failed: llama-swap (:${swap_port}) is unreachable — cannot onboard '${sandbox}'."
    return 1
  fi

  info "Onboarding sandbox: ${sandbox} (model: ${model} via llama-swap)..."
  # Use localhost for the onboard URL so the NemoClaw CLI can validate the
  # endpoint from the host (host.openshell.internal only resolves inside
  # Docker containers). After onboard, _setup_provider() updates the
  # provider to use host.openshell.internal for in-sandbox access.
  local onboard_url="http://localhost:${swap_port}/v1"

  _run_onboard_cmd "$sandbox" "$onboard_url" "$model" "$timeout_sec" "$log_file"
  local rc=$?

  if [[ "$rc" -ne 0 ]]; then
    # First attempt failed — retry once with a shorter timeout
    if [[ "$rc" -eq 124 ]]; then
      warn "Onboard timed out after ${timeout_sec}s for '${sandbox}' — retrying (300s)..."
    else
      warn "Onboard failed (exit ${rc}) for '${sandbox}' — retrying (300s)..."
    fi
    _run_onboard_cmd "$sandbox" "$onboard_url" "$model" 300 "$log_file"
    rc=$?
  fi

  if [[ "$rc" -eq 124 ]]; then
    fail "Onboard timed out for '${sandbox}' after retry. See log: ${log_file}"
    return 1
  elif [[ "$rc" -ne 0 ]]; then
    fail "Onboard failed (exit ${rc}) for '${sandbox}' after retry. See log: ${log_file}"
    return 1
  fi
  ok "Sandbox '${sandbox}' onboarded."
}

# Run the nemoclaw onboard command with timeout, capturing stderr to a log.
# Separated from _do_onboard to enable retry without duplicating the command.
_run_onboard_cmd() {
  local sandbox="$1" onboard_url="$2" model="$3" timeout_sec="$4" log_file="$5"
  echo "--- $(date -Iseconds) onboard attempt (timeout=${timeout_sec}s) ---" >> "$log_file"
  # stdin from /dev/null prevents any accidental interactive prompt from
  # blocking the pipeline.  Timeout prevents an indefinite hang if a step
  # (gateway start, image pull, openshell sandbox connect) never returns.
  # NemoClaw internally hardcodes gateway name "nemoclaw" — our
  # NEMOCLAW_GATEWAY_NAME env var is accepted but overridden inside onboard.
  # NEMOCLAW_RECREATE_SANDBOX=1 handles the case where NemoClaw's local
  # registry was cleared (nuke/pave) but the gateway still has the sandbox.
  timeout "${timeout_sec}" bash -c '
    NEMOCLAW_EXPERIMENTAL=1 \
    NEMOCLAW_ACCEPT_THIRD_PARTY_SOFTWARE=1 \
    NEMOCLAW_RECREATE_SANDBOX=1 \
    NEMOCLAW_SANDBOX_NAME="$1" \
    NEMOCLAW_PROVIDER="custom" \
    NEMOCLAW_ENDPOINT_URL="$2" \
    COMPATIBLE_API_KEY="not-needed" \
    NEMOCLAW_MODEL="$3" \
    NEMOCLAW_POLICY_PRESETS=npm,pypi,telegram,huggingface \
      nemoclaw onboard --non-interactive
  ' _ "$sandbox" "$onboard_url" "$model" </dev/null 2>>"$log_file"
  return $?
}

# Run a command inside a sandbox via SSH (non-interactive, returns stdout).
_sandbox_ssh() {
  local sandbox="$1"; shift
  local openshell_bin
  openshell_bin=$(command -v openshell)
  ssh -o StrictHostKeyChecking=no \
      -o UserKnownHostsFile=/dev/null \
      -o GlobalKnownHostsFile=/dev/null \
      -o LogLevel=ERROR \
      -o "ProxyCommand=$openshell_bin ssh-proxy --gateway-name nemoclaw --name $sandbox" \
      "sandbox@openshell-$sandbox" "$@"
}

# Start a Python TCP relay inside a sandbox (listen_port → target_port).
# openshell forward maps host:PORT → sandbox:PORT (same port), so when the
# dashboard host port differs from the sandbox's internal service port we need
# a lightweight relay inside the sandbox.
#
# The relay runs under a supervisor loop that automatically restarts it on
# crash (max 10 retries, 2-second backoff). This fixes ISSUE-034 where the
# bare nohup relay would die silently, leaving the CPU sandbox unreachable.
_start_port_relay() {
  local sandbox="$1" listen_port="$2" target_port="$3"
  local tmpdir
  tmpdir=$(mktemp -d)

  cat > "$tmpdir/relay.py" << 'PYEOF'
#!/usr/bin/env python3
"""TCP relay: forwards LISTEN_PORT -> TARGET_PORT on localhost."""
import socket, threading, sys, os

LISTEN_PORT = int(sys.argv[1])
TARGET_PORT = int(sys.argv[2])

with open(f'/tmp/relay-{LISTEN_PORT}.pid', 'w') as f:
    f.write(str(os.getpid()))

def relay(src, dst):
    try:
        while True:
            data = src.recv(4096)
            if not data:
                break
            dst.sendall(data)
    except Exception:
        pass
    finally:
        src.close()
        dst.close()

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind(('127.0.0.1', LISTEN_PORT))
sock.listen(8)

while True:
    client, _ = sock.accept()
    try:
        target = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        target.connect(('127.0.0.1', TARGET_PORT))
        threading.Thread(target=relay, args=(client, target), daemon=True).start()
        threading.Thread(target=relay, args=(target, client), daemon=True).start()
    except Exception:
        client.close()
PYEOF

  # Supervisor script: restarts relay.py on crash with backoff, max 10 retries.
  cat > "$tmpdir/relay-supervisor.sh" <<SUPEOF
#!/usr/bin/env bash
MAX_RESTARTS=10
DELAY=2
LOG=/tmp/relay-supervisor-${listen_port}.log
echo \$\$ > /tmp/relay-supervisor-${listen_port}.pid
n=0
while [ \$n -lt \$MAX_RESTARTS ]; do
  python3 /sandbox/relay.py ${listen_port} ${target_port}
  rc=\$?
  n=\$((n + 1))
  echo "\$(date -Iseconds) relay exited (rc=\$rc) restart \$n/\$MAX_RESTARTS" >> "\$LOG"
  sleep \$DELAY
done
echo "\$(date -Iseconds) supervisor: max restarts (\$MAX_RESTARTS) reached" >> "\$LOG"
SUPEOF

  openshell sandbox upload "$sandbox" "$tmpdir/relay.py" /sandbox/relay.py 2>/dev/null || {
    warn "Failed to upload relay script to '${sandbox}'"
    rm -rf "$tmpdir"
    return 1
  }
  openshell sandbox upload "$sandbox" "$tmpdir/relay-supervisor.sh" /sandbox/relay-supervisor.sh 2>/dev/null || {
    warn "Failed to upload relay supervisor to '${sandbox}'"
    rm -rf "$tmpdir"
    return 1
  }
  rm -rf "$tmpdir"

  # Kill any existing supervisor + relay, then start the supervisor
  _sandbox_ssh "$sandbox" \
    "pid=\$(cat /tmp/relay-supervisor-${listen_port}.pid 2>/dev/null); \
     [ -n \"\$pid\" ] && kill \$pid 2>/dev/null; \
     pkill -f 'python3 /sandbox/relay.py ${listen_port}' 2>/dev/null; \
     chmod +x /sandbox/relay-supervisor.sh; \
     nohup /sandbox/relay-supervisor.sh > /dev/null 2>&1 & echo \$!" \
    2>/dev/null || {
    warn "Failed to start relay supervisor in '${sandbox}'"
    return 1
  }
}

# Extract NemoClaw auth tokens and write a JSON sidecar for the dashboard.
_extract_dashboard_tokens() {
  if ! command -v openshell &>/dev/null; then return 0; fi

  local token_file="$REPO_DIR/resources/dashboard/nemoclaw-tokens.json"
  local tmpdir
  tmpdir=$(mktemp -d)

  declare -A sandbox_ports=(
    ["hts-ai-openshell-nemoclaw-gpu"]=18789
  )

  local json="{"
  local first=true
  for sandbox in "${!sandbox_ports[@]}"; do
    local port="${sandbox_ports[$sandbox]}"
    openshell sandbox get "$sandbox" &>/dev/null || continue

    local dl_dir="$tmpdir/$sandbox"
    mkdir -p "$dl_dir"
    openshell sandbox download "$sandbox" /sandbox/.openclaw/openclaw.json "$dl_dir/" 2>/dev/null || continue

    local token
    token=$(python3 -c "
import json, sys
with open('$dl_dir/openclaw.json') as f:
    d = json.load(f)
print(d.get('gateway',{}).get('auth',{}).get('token',''))
" 2>/dev/null)

    if [[ -n "$token" ]]; then
      [[ "$first" == "true" ]] || json+=","
      json+="\"$sandbox\":{\"port\":$port,\"token\":\"$token\"}"
      first=false
    fi
  done
  json+="}"

  echo "$json" | python3 -m json.tool > "$token_file" 2>/dev/null || echo "$json" > "$token_file"
  rm -rf "$tmpdir"
  info "Dashboard tokens written → $token_file"
}

# Provision agent persona files (SOUL.md, IDENTITY.md) from resources/agents/
# into sandbox workspaces and configure multi-agent routing.
#
# Each agent gets its own workspace directory inside the sandbox
# (/sandbox/.openclaw-data/workspace-<agent>/), with its SOUL.md and
# IDENTITY.md. openclaw.json is patched to define agents.list so the
# gateway routes between personas. Only agents whose resource dirs exist
# are provisioned.
# Controlled by NEMOCLAW_AGENT_PERSONAS env var (default: true).
_provision_agent_personas() {
  local enabled="${NEMOCLAW_AGENT_PERSONAS:-true}"
  if [[ "$enabled" != "true" ]]; then
    info "Agent persona injection disabled — skipping."
    return 0
  fi

  if ! command -v openshell &>/dev/null; then return 0; fi

  local agents_dir="$REPO_DIR/resources/agents"
  [[ -d "$agents_dir" ]] || return 0

  # Map: resource-dir-name → sandbox-name
  # All agents share the GPU sandbox now that the CPU sandbox was removed
  # (gVisor/Daytona evaluation pending — FEATURE-012, FEATURE-013).
  declare -A persona_map=(
    ["haley"]="hts-ai-openshell-nemoclaw-gpu"
    ["caco-bot"]="hts-ai-openshell-nemoclaw-gpu"
  )

  # Track which agents were provisioned per sandbox for config patching
  declare -A sandbox_agents  # sandbox → space-separated agent list

  for agent in "${!persona_map[@]}"; do
    local sandbox="${persona_map[$agent]}"
    local src_dir="$agents_dir/$agent"
    [[ -d "$src_dir" ]] || continue

    # Only push to sandboxes that exist
    openshell sandbox get "$sandbox" &>/dev/null || continue

    # Each agent gets its own workspace directory.
    # /sandbox/.openclaw-data/ is sandbox-owned; /sandbox/.openclaw/ is root-owned.
    local ws_dir="/sandbox/.openclaw-data/workspace-${agent}"
    openshell sandbox exec -n "$sandbox" -- mkdir -p "$ws_dir" 2>/dev/null || {
      warn "Failed to create workspace dir for '${agent}' in '${sandbox}'"
      continue
    }

    for file in SOUL.md IDENTITY.md; do
      [[ -f "$src_dir/$file" ]] || continue
      # Trailing slash on dest tells openshell to upload INTO the directory
      openshell sandbox upload "$sandbox" "$src_dir/$file" "${ws_dir}/" 2>/dev/null \
        && info "Provisioned ${agent}/${file} → ${sandbox}:${ws_dir}/" \
        || warn "Failed to provision ${agent}/${file} → ${sandbox}"
    done

    # Upload shared AGENTS.md template if the agent doesn't have its own
    local shared_agents_md="$agents_dir/AGENTS.md"
    if [[ ! -f "$src_dir/AGENTS.md" && -f "$shared_agents_md" ]]; then
      openshell sandbox upload "$sandbox" "$shared_agents_md" "${ws_dir}/" 2>/dev/null \
        && info "Provisioned shared AGENTS.md → ${sandbox}:${ws_dir}/" \
        || warn "Failed to provision shared AGENTS.md → ${sandbox}"
    fi

    sandbox_agents["$sandbox"]+="${agent} "
  done

  # Patch openclaw.json inside each sandbox for multi-agent routing.
  # openclaw.json is root-owned, so we exec as uid 0 via containerd.
  for sandbox in "${!sandbox_agents[@]}"; do
    openshell sandbox get "$sandbox" &>/dev/null || continue
    local agents_csv="${sandbox_agents[$sandbox]% }"

    # Build the agents.list JSON on the host by reading IDENTITY.md from resources.
    # The model field must match a fully-qualified provider/model-id from the
    # models.providers section of openclaw.json (e.g. "inference/gemma4:e4b").
    local default_model="inference/${OLLAMA_MODEL:-gemma4:e4b}"
    local agents_json
    agents_json=$(python3 - "$agents_csv" "$agents_dir" "$default_model" <<'PYEOF'
import json, re, sys, pathlib
agents = sys.argv[1].split()
agents_dir = pathlib.Path(sys.argv[2])
default_model = sys.argv[3]
result = []
first = True
for agent in sorted(agents):
    id_file = agents_dir / agent / "IDENTITY.md"
    name, emoji, model = agent, "", default_model
    if id_file.exists():
        text = id_file.read_text()
        m = re.search(r"\*\*Name:\*\*\s*(.+)", text)
        if m: name = m.group(1).strip()
        m = re.search(r"\*\*Emoji:\*\*\s*(.+)", text)
        if m: emoji = m.group(1).strip()
        m = re.search(r"\*\*Model:\*\*\s*(.+)", text)
        if m: model = m.group(1).strip()
    entry = {"id": agent, "name": name,
             "model": model,
             "workspace": "/sandbox/.openclaw-data/workspace-" + agent,
             "identity": {"name": name}}
    if emoji: entry["identity"]["emoji"] = emoji
    if first: entry["default"] = True; first = False
    result.append(entry)
print(json.dumps(result))
PYEOF
    ) || { warn "Failed to build agents list JSON"; continue; }

    # Escape the JSON for embedding in a Python one-liner
    local escaped_json
    escaped_json=$(printf '%s' "$agents_json" | python3 -c "import sys; print(repr(sys.stdin.read()))")

    local patch_script="import json,pathlib;p=pathlib.Path('/sandbox/.openclaw/openclaw.json');d=json.loads(p.read_text());d['agents']={'list':json.loads(${escaped_json})};p.write_text(json.dumps(d,indent=2));print('OK')"

    local result
    result=$(_sandbox_root_exec "$sandbox" "agents" python3 -c "$patch_script" 2>&1) || {
      warn "Failed to patch multi-agent config in '${sandbox}': ${result}"
      continue
    }

    # Create per-agent dirs under ~/.openclaw/agents/<id>/agent/ with models.json.
    # The gateway needs these to actually route sessions to the agent — the
    # agents.list config alone isn't enough.
    local agentdir_script
    agentdir_script="
import json, pathlib
cfg = json.loads(pathlib.Path('/sandbox/.openclaw/openclaw.json').read_text())
providers = cfg.get('models', {}).get('providers', {})
models_json = json.dumps({'providers': providers}, indent=2)
for agent in cfg.get('agents', {}).get('list', []):
    agent_dir = pathlib.Path('/sandbox/.openclaw/agents') / agent['id'] / 'agent'
    agent_dir.mkdir(parents=True, exist_ok=True)
    mf = agent_dir / 'models.json'
    if not mf.exists():
        mf.write_text(models_json)
        print(f'Created {mf}')
    else:
        print(f'Exists  {mf}')
print('OK')
"
    result=$(_sandbox_root_exec "$sandbox" "adir" python3 -c "$agentdir_script" 2>&1) || {
      warn "Failed to create agent dirs in '${sandbox}': ${result}"
    }

    _sandbox_root_restart_gw "$sandbox"
    ok "Multi-agent config patched in '${sandbox}' (${agents_csv// /, })"
  done
}

# Update OpenClaw inside each sandbox.
#
# IMPORTANT: Per NVIDIA upstream guidance, NemoClaw owns the OpenShell lifecycle.
# Avoid `npm i -g openclaw@latest`, `openshell self-update`, or
# `openshell gateway start --recreate` inside sandboxes.
# The correct path is `nemoclaw onboard` which recreates sandboxes with latest
# images. The --update flag is kept for backward compat but now delegates to
# nemoclaw onboard --non-interactive for each sandbox.
# See: https://github.com/NVIDIA/NemoClaw#openshell-lifecycle
_update_openclaw() {
  if ! command -v nemoclaw &>/dev/null; then
    warn "nemoclaw CLI not found — cannot update OpenClaw."
    return 0
  fi
  if ! command -v openshell &>/dev/null; then return 0; fi

  local sandboxes=("hts-ai-openshell-nemoclaw-gpu")

  for sandbox in "${sandboxes[@]}"; do
    openshell sandbox get "$sandbox" &>/dev/null 2>&1 || continue

    info "Re-onboarding '${sandbox}' to pull latest OpenClaw/gateway images..."
    warn "This will recreate the sandbox. Data in /sandbox is ephemeral."

    local model
    if [[ "$sandbox" == *"-gpu"* ]]; then
      model="$OLLAMA_MODEL"
    else
      model="bitnet"
    fi

    # Destroy and re-onboard via nemoclaw (the supported path)
    nemoclaw "$sandbox" destroy --yes 2>/dev/null || true
    _do_onboard "$sandbox" "$model"

    ok "Sandbox '${sandbox}' re-onboarded with latest images."
  done
}

# ── cgroup v2 fix (Ubuntu 24.04) ─────────────────────────────────────────────
_fix_cgroups() {
  step "NemoClaw — cgroup v2 check"
  _ensure_sudo

  local fs_type
  fs_type=$(stat -fc %T /sys/fs/cgroup/)

  if [[ "$fs_type" == "cgroup2fs" ]]; then
    if [[ -r /etc/docker/daemon.json ]] && grep -q "default-cgroupns-mode" /etc/docker/daemon.json; then
      info "cgroup v2 fix already applied"
    else
      info "Applying cgroup v2 fix for Docker/k3s..."
      if [[ -f /etc/docker/daemon.json ]]; then
        sudo python3 -c "
import json
with open('/etc/docker/daemon.json') as f:
    config = json.load(f)
config['default-cgroupns-mode'] = 'host'
with open('/etc/docker/daemon.json', 'w') as f:
    json.dump(config, f, indent=2)
print('Merged into existing daemon.json')
"
      else
        sudo bash -c 'echo "{\"default-cgroupns-mode\": \"host\"}" > /etc/docker/daemon.json'
      fi
      sudo systemctl restart docker
    fi
  else
    info "cgroup v1 detected (${fs_type}) — fix not needed"
  fi
}

# ── Registry patching (sandboxes.json) ────────────────────────────────────────
_patch_registry() {
  local sandboxes_json="$HOME/.nemoclaw/sandboxes.json"
  [[ -f "$sandboxes_json" ]] || return 0

  step "NemoClaw — patch registry"
  info "Patching NemoClaw registry for llama-swap dual-backend..."
  python3 - "$sandboxes_json" "$OLLAMA_MODEL" <<'EOF_PY'
import json, sys
path = sys.argv[1]
gpu_model = sys.argv[2]
with open(path) as f:
    data = json.load(f)
for name, sb in data.get("sandboxes", {}).items():
    sb["provider"] = "llama-swap-local"
    if "gpu" in name:
        sb["model"] = gpu_model
    elif "cpu" in name:
        sb["model"] = "bitnet"
with open(path, "w") as f:
    json.dump(data, f, indent=2)
print(f"  Registry patched for llama-swap (gpu→{gpu_model}, cpu→bitnet).")
EOF_PY
}

# ── UFW firewall — restrict LLM endpoint to localhost + Docker ────────────────
_setup_ufw() {
  step "NemoClaw — firewall (UFW)"
  _ensure_sudo

  if ! command -v ufw &>/dev/null; then
    info "Installing UFW..."
    sudo apt-get install -y ufw
  fi

  # Docker's default bridge subnet; covers host.openshell.internal traffic
  local docker_subnet="172.16.0.0/12"
  local swap_port="${LLAMA_SWAP_PORT:-8081}"

  # Allow SSH so we don't lock ourselves out
  if ! sudo ufw status | grep -q "22/tcp"; then
    sudo ufw allow 22/tcp comment "SSH" >/dev/null
  fi

  # Allow llama-swap from Docker/OpenShell subnets only
  if ! sudo ufw status | grep -q "${swap_port}/tcp.*ALLOW.*${docker_subnet}"; then
    info "Allowing llama-swap (:${swap_port}) from Docker subnet ${docker_subnet}..."
    sudo ufw allow from "$docker_subnet" to any port "$swap_port" proto tcp \
      comment "llama-swap — Docker/OpenShell sandboxes" >/dev/null
  else
    info "UFW rule for llama-swap already exists"
  fi

  # Deny llama-swap from everywhere else (explicit block before default policy)
  if ! sudo ufw status | grep -q "${swap_port}/tcp.*DENY"; then
    sudo ufw deny "$swap_port"/tcp comment "llama-swap — block LAN/WAN" >/dev/null
  fi

  # Enable UFW if not already active
  if ! sudo ufw status | grep -q "Status: active"; then
    info "Enabling UFW..."
    sudo ufw --force enable
  else
    info "UFW already active"
  fi

  ok "Firewall configured — llama-swap accessible from Docker only."
}

# ── Provider configuration ────────────────────────────────────────────────────
_setup_provider() {
  step "NemoClaw — inference provider (llama-swap via host.openshell.internal)"
  # Both sandboxes share the gateway inference route.
  # Point all providers at llama-swap via host.openshell.internal so the
  # gateway pod (which lacks hostNetwork) can reach the host.
  # llama-swap handles model-based routing (gemma4:e4b → Ollama, bitnet → BitNet).
  if command -v openshell &>/dev/null; then
    local swap_url="http://host.openshell.internal:${LLAMA_SWAP_PORT:-8081}/v1"
    info "Endpoint: ${swap_url}"

    # Update compatible-endpoint (created by onboard for 'custom' provider)
    if openshell provider list 2>/dev/null | grep -q "compatible-endpoint"; then
      info "Updating compatible-endpoint → ${swap_url}"
      openshell provider update compatible-endpoint \
        --config "OPENAI_BASE_URL=${swap_url}" 2>/dev/null || \
        warn "Failed to update compatible-endpoint provider"
    fi

    # Create or update llama-swap-local provider
    if ! openshell provider list 2>/dev/null | grep -q "llama-swap-local"; then
      info "Registering llama-swap-local provider..."
      openshell provider create \
        --name  llama-swap-local \
        --type  openai \
        --credential OPENAI_API_KEY=not-needed \
        --config "baseUrl=${swap_url}" || \
        warn "Failed to register llama-swap-local provider"
    else
      openshell provider update llama-swap-local \
        --config "baseUrl=${swap_url}" 2>/dev/null || \
        warn "Failed to update llama-swap-local provider"
    fi

    ok "Inference providers configured (llama-swap routes by model name)."
  else
    warn "openshell CLI not found — skipping provider configuration"
  fi
}

# ── Systemd health timer (ISSUE-034) ─────────────────────────────────────────
# Install a systemd timer that runs `nemoclaw.sh --health` every 5 minutes.
# This revives silently-dead openshell forwards and relay processes so the
# dashboard never stays in "health offline" for more than one interval.
_install_health_timer() {
  _ensure_sudo

  local service_name="hts-nemoclaw-health"
  local service_file="/etc/systemd/system/${service_name}.service"
  local timer_file="/etc/systemd/system/${service_name}.timer"
  local script_path="$REPO_DIR/scripts/components/nemoclaw.sh"
  local run_user
  run_user=$(whoami)

  # Resolve NVM-managed node path so the service can find nemoclaw/openshell
  _source_nvm
  local extra_path=""
  if command -v node &>/dev/null; then
    extra_path="$(dirname "$(command -v node)"):"
  fi
  if command -v openshell &>/dev/null; then
    local os_dir
    os_dir="$(dirname "$(command -v openshell)")"
    [[ "$extra_path" == *"$os_dir"* ]] || extra_path="${extra_path}${os_dir}:"
  fi

  sudo tee "$service_file" > /dev/null <<EOF
[Unit]
Description=HTS AI Stack — NemoClaw health check
After=network-online.target docker.service

[Service]
Type=oneshot
ExecStart=${script_path} --health
WorkingDirectory=${REPO_DIR}
User=${run_user}
Environment=PATH=${extra_path}/usr/local/bin:/usr/bin:/bin
Environment=HOME=$(eval echo ~"$run_user")
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${service_name}
EOF

  sudo tee "$timer_file" > /dev/null <<EOF
[Unit]
Description=HTS AI Stack — NemoClaw health timer (every 5 min)

[Timer]
OnBootSec=2min
OnUnitActiveSec=5min
Persistent=true

[Install]
WantedBy=timers.target
EOF

  sudo systemctl daemon-reload
  sudo systemctl enable --now "${service_name}.timer"
  ok "Installed systemd timer: ${service_name}.timer (every 5 min)"
}

# ── Functions ────────────────────────────────────────────────────────────────

# nemoclaw_install — GitHub CLI + OpenShell CLI + NemoClaw (npm)
nemoclaw_install() {
  _ensure_sudo

  # ── GitHub CLI ──
  step "NemoClaw — GitHub CLI"
  if gh --version &>/dev/null; then
    info "GitHub CLI already installed ($(gh --version | head -1))"
  else
    info "Installing GitHub CLI..."
    curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | \
      sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg

    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] \
      https://cli.github.com/packages stable main" | \
      sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null

    sudo apt update && sudo apt install -y gh
  fi

  if ! gh auth status &>/dev/null; then
    info "Authenticating with GitHub..."
    gh auth login
  else
    info "GitHub CLI already authenticated"
  fi

  # ── OpenShell CLI ──
  step "NemoClaw — OpenShell CLI"
  if openshell --version &>/dev/null; then
    info "OpenShell already installed ($(openshell --version))"
  else
    info "Downloading OpenShell binary..."
    local arch tarball
    arch=$(uname -m)
    tarball="openshell-${arch}-unknown-linux-musl.tar.gz"

    gh release download --repo NVIDIA/OpenShell --pattern "$tarball"
    tar xzf "$tarball"
    sudo install -m 755 openshell /usr/local/bin/openshell
    rm -f "$tarball" openshell
    openshell --version
  fi

  # ── NemoClaw (npm) ──
  step "NemoClaw — npm install"
  _source_nvm

  if ! command -v npm &>/dev/null; then
    fail "npm not found — NVM may not have sourced correctly. Try: source ~/.nvm/nvm.sh"
    exit 1
  fi

  local npm_bin npm_prefix nemoclaw_bin
  npm_bin=$(command -v npm)
  npm_prefix=$("$npm_bin" config get prefix)
  nemoclaw_bin="$npm_prefix/bin/nemoclaw"

  if [[ -x "$nemoclaw_bin" ]]; then
    # Detect the broken placeholder npm package (249 bytes, no build artifacts)
    if ! _is_real_nemoclaw_cli "$nemoclaw_bin"; then
      warn "Found nemoclaw at $nemoclaw_bin but it is the broken placeholder npm package."
      warn "Removing it and installing the real NemoClaw CLI..."
      "$npm_bin" uninstall -g nemoclaw 2>/dev/null || true
    else
      info "NemoClaw already installed ($("$nemoclaw_bin" --version 2>/dev/null || echo 'installed'))"
    fi
  fi

  if [[ ! -x "$nemoclaw_bin" ]] || ! _is_real_nemoclaw_cli "$nemoclaw_bin" 2>/dev/null; then
    info "Installing NemoClaw (npm $(npm --version), node $(node --version))..."

    local nemoclaw_src="$HOME/.nemoclaw/source"
    rm -rf "$nemoclaw_src"
    mkdir -p "$(dirname "$nemoclaw_src")"

    # Resolve the best available ref: releases → tags → main.
    # NVIDIA currently uses git tags only (no formal GitHub Releases while
    # the project is in alpha), so the releases endpoint usually 404s.
    local release_ref=""
    # 1) Try GitHub Releases (if they start using them)
    release_ref=$(curl -fsSL --max-time 10 \
      https://api.github.com/repos/NVIDIA/NemoClaw/releases/latest 2>/dev/null \
      | grep '"tag_name"' | sed -E 's/.*"tag_name":[[:space:]]*"([^"]+)".*/\1/' | head -1 || true)
    # 2) Fall back to the most recent semver git tag
    if ! [[ "$release_ref" =~ ^v[0-9] ]]; then
      release_ref=$(curl -fsSL --max-time 10 \
        https://api.github.com/repos/NVIDIA/NemoClaw/tags?per_page=20 2>/dev/null \
        | grep '"name"' | sed -E 's/.*"name":[[:space:]]*"([^"]+)".*/\1/' \
        | grep -E '^v[0-9]' | head -1 || true)
    fi
    # 3) Last resort: main
    [[ "$release_ref" =~ ^v[0-9] ]] || release_ref="main"
    info "NemoClaw ref: $release_ref"

    git clone --depth 1 --branch "$release_ref" https://github.com/NVIDIA/NemoClaw.git "$nemoclaw_src"

    # Pre-extract openclaw to work around tarball missing directory entries (GH-503).
    # Upstream's installer does this before npm install to prevent extraction failures.
    _pre_extract_openclaw "$nemoclaw_src" "$npm_bin" || \
      warn "Pre-extraction failed — npm install may fail if openclaw tarball is broken"

    (cd "$nemoclaw_src" && "$npm_bin" install --ignore-scripts)
    # NOTE: Do NOT run `npm audit fix` here. Upstream NVIDIA never does.
    # It can break pinned dependency versions and cause silent CLI failures.
    (cd "$nemoclaw_src/nemoclaw" && "$npm_bin" install --ignore-scripts)
    (cd "$nemoclaw_src/nemoclaw" && "$npm_bin" run build)
    (cd "$nemoclaw_src" && "$npm_bin" link)

    [[ -x "$nemoclaw_bin" ]] || { fail "nemoclaw binary not found at $nemoclaw_bin"; exit 1; }
    "$nemoclaw_bin" --version
  fi

  ok "NemoClaw prerequisites installed."
}

# nemoclaw_configure — cgroup v2 fix, registry patching, provider config
nemoclaw_configure() {
  _fix_cgroups
  _setup_ufw
  _patch_registry
  _setup_provider
  ok "NemoClaw configured."
}

# nemoclaw_onboard — Create/manage NemoClaw sandboxes
nemoclaw_onboard() {
  if [[ "$NEMOCLAW_DEPLOY" != "true" ]]; then
    step "NemoClaw — onboard (SKIPPED)"
    info "Skipping NemoClaw deployment — using existing installation"
    return 0
  fi

  step "NemoClaw — onboard (GPU sandbox)"
  echo ""
  warn "Port 18789 must be free before continuing."
  warn "First run will pull ~2.4 GB of images."
  echo ""

  # GPU sandbox → Ollama (OLLAMA_MODEL from .env) via llama-swap.
  # CPU sandbox removed — gVisor/Daytona evaluation pending (FEATURE-012, FEATURE-013).
  declare -A sandbox_models=(
    ["hts-ai-openshell-nemoclaw-gpu"]="$OLLAMA_MODEL"
  )

  for sandbox in "${!sandbox_models[@]}"; do
    local model="${sandbox_models[$sandbox]}"

    if ! nemoclaw list 2>/dev/null | grep -q "$sandbox"; then
      _do_onboard "$sandbox" "$model"
      continue
    fi

    # Sandbox exists: check health and prompt
    echo ""
    info "Sandbox '${sandbox}' already exists. Checking health..."
    local health_label
    if _check_sandbox_health "$sandbox"; then
      health_label="${GREEN}healthy (Phase: Ready)${NC}"
    else
      health_label="${YELLOW}degraded${NC}"
    fi
    echo -e "\n  Sandbox '${sandbox}' is ${health_label}.\n"
    echo    "  Options:"
    echo -e "    [s] Skip  — keep existing sandbox  ${YELLOW}(default, auto-selects in 30s)${NC}"
    echo    "    [o] Overwrite — destroy and re-onboard"
    echo ""

    local reply=""
    if read -r -t 30 -p "  Choice [s/o]: " reply 2>/dev/null; then
      : # got input
    else
      echo ""
      info "No input — skipping '${sandbox}'."
    fi

    case "${reply,,}" in
      o|overwrite)
        warn "Destroying sandbox '${sandbox}'..."
        nemoclaw "$sandbox" destroy --yes 2>/dev/null || true
        _do_onboard "$sandbox" "$model"
        ;;
      *)
        info "Sandbox '${sandbox}' — keeping existing."
        ;;
    esac
  done

  # Post-onboard: patch registry and configure provider
  _patch_registry
  _setup_provider

  # NemoClaw's own onboard only forwards port 18789 (and stomps the previous
  # forward each run), so we must ensure both sandboxes are forwarded.
  _ensure_forwards
  _extract_dashboard_tokens

  # Auto-update OpenClaw if a newer version is available
  if [[ "$NEMOCLAW_AUTO_UPDATE" == "true" ]]; then
    _update_openclaw
    # Re-extract tokens after update — gateway restart may regenerate them
    _extract_dashboard_tokens
  else
    info "OpenClaw auto-update disabled (NEMOCLAW_AUTO_UPDATE=false)"
  fi
  # Fix allowedOrigins for sandboxes (CPU sandbox exposed on different port)
  _fix_sandbox_origins

  # Push agent persona files (SOUL.md, IDENTITY.md) into sandbox workspaces
  _provision_agent_personas

  # Install systemd timer to auto-revive dead forwards/relays (ISSUE-034)
  _install_health_timer

  ok "NemoClaw onboarding complete."
}

# _ensure_forwards — Set up port forwards for both sandboxes.
# GPU maps directly (host:18789 → sandbox:18789).
# CPU needs a relay because openshell forward maps same-port only and the
# sandbox's OpenClaw dashboard always listens on 18789 internally.
#
# The openshell forward --background processes can silently die, so this
# function checks for dead forwards and restarts them.  Safe to call
# repeatedly (health checks, start, etc.).
_ensure_forwards() {
  if ! command -v openshell &>/dev/null; then return 0; fi

  local internal_port=18789  # All sandboxes serve OpenClaw on this port

  declare -A sandbox_ports=(
    ["hts-ai-openshell-nemoclaw-gpu"]=18789
  )

  for sandbox in "${!sandbox_ports[@]}"; do
    local port="${sandbox_ports[$sandbox]}"
    openshell sandbox get "$sandbox" &>/dev/null || continue

    # Check if an existing forward is alive — skip if running
    local fwd_status
    fwd_status=$(openshell forward list 2>/dev/null | grep "$port" || true)
    if echo "$fwd_status" | grep -q "running"; then
      continue
    fi

    # Forward is missing or dead — (re)start it
    openshell forward stop "$port" 2>/dev/null || true

    openshell forward start "$port" "$sandbox" --background 2>/dev/null || true
    info "Restarted forward :${port} → ${sandbox}"
  done
}

# _sandbox_root_exec — Execute a command as root (uid 0) inside a sandbox.
#
# openclaw.json and other files under /sandbox/.openclaw/ are root-owned
# (baked at image build time). Neither 'openshell sandbox exec' nor SSH can
# write to them because they run as the unprivileged 'sandbox' user.
# The only route is: docker exec → containerd → --user 0.
#
# Usage: _sandbox_root_exec <sandbox-name> <exec-id-prefix> <command...>
#   Returns: stdout of the command; rc of the inner exec.
_sandbox_root_exec() {
  local sandbox="$1" exec_prefix="$2"; shift 2
  local cluster_container="openshell-cluster-nemoclaw"

  if ! docker inspect "$cluster_container" &>/dev/null; then
    warn "Cluster container '${cluster_container}' not found."
    return 1
  fi

  # Resolve the containerd task ID for this sandbox's pod
  local ctr_id
  ctr_id=$(docker exec "$cluster_container" \
    /bin/sh -c "ctr -n k8s.io tasks list 2>/dev/null | awk '{print \$1}'" \
    | while read -r id; do
        local hn
        hn=$(docker exec "$cluster_container" \
          ctr -n k8s.io tasks exec --exec-id "hn-${id:0:8}" --user 0 "$id" \
          hostname 2>/dev/null) || continue
        if [[ "$hn" == "$sandbox" ]]; then echo "$id"; break; fi
      done)

  if [[ -z "${ctr_id:-}" ]]; then
    warn "Could not find containerd task for '${sandbox}'."
    return 1
  fi

  docker exec "$cluster_container" \
    ctr -n k8s.io tasks exec \
      --exec-id "${exec_prefix}-${sandbox:0:8}" --user 0 "$ctr_id" \
      "$@"
}

# _sandbox_root_restart_gw — Kill the gateway so PID 1 restarts it with new config
_sandbox_root_restart_gw() {
  local sandbox="$1"
  _sandbox_root_exec "$sandbox" "gw" \
    /bin/sh -c "kill \$(cat /tmp/openclaw-gateway.pid 2>/dev/null) 2>/dev/null || pkill -f 'openclaw.*gateway' 2>/dev/null || true" \
    2>/dev/null || true
  sleep 3
}

# _fix_sandbox_origins — Patch controlUi.allowedOrigins so the Control UI
# works when a sandbox is exposed on a non-default port (e.g. GPU on 18789).
_fix_sandbox_origins() {
  if ! command -v openshell &>/dev/null; then return 0; fi

  declare -A sandbox_ports=(
    ["hts-ai-openshell-nemoclaw-gpu"]=18789
  )

  for sandbox in "${!sandbox_ports[@]}"; do
    local port="${sandbox_ports[$sandbox]}"
    openshell sandbox get "$sandbox" &>/dev/null || continue

    info "Fixing allowedOrigins for '${sandbox}' → :${port}..."
    local fix_script="import json,pathlib;p=pathlib.Path('/sandbox/.openclaw/openclaw.json');d=json.loads(p.read_text());d.setdefault('gateway',{}).setdefault('controlUi',{})['allowedOrigins']=['http://127.0.0.1:${port}','http://localhost:${port}'];p.write_text(json.dumps(d,indent=2));print('OK')"

    local result
    result=$(_sandbox_root_exec "$sandbox" "fix" python3 -c "$fix_script" 2>&1) || {
      warn "Failed to fix allowedOrigins for '${sandbox}': ${result}"
      continue
    }

    _sandbox_root_restart_gw "$sandbox"
  done

  ok "Sandbox allowedOrigins fixed."
}

# nemoclaw_health — Check sandbox status and inference endpoints
nemoclaw_health() {
  step "NemoClaw — health"

  # Check llama-swap (unified endpoint)
  local swap_port="${LLAMA_SWAP_PORT:-8081}"
  if curl -sf "http://localhost:${swap_port}/health" >/dev/null 2>&1; then
    ok "llama-swap (:${swap_port}) is reachable."
  else
    warn "llama-swap (:${swap_port}) not reachable — start the stack first."
  fi

  # Sandbox-level health (if nemoclaw CLI is available)
  if command -v nemoclaw &>/dev/null; then
    local sandboxes
    sandboxes=$(nemoclaw list 2>/dev/null || true)
    if [[ -n "$sandboxes" ]]; then
      while IFS= read -r sandbox; do
        [[ -z "$sandbox" ]] && continue
        [[ "$sandbox" == *"hts-ai-"* ]] || continue
        sandbox=$(echo "$sandbox" | awk '{print $1}')
        info "Checking sandbox: ${sandbox}..."
        _check_sandbox_health "$sandbox" || warn "Sandbox '${sandbox}' not ready"
      done <<< "$sandboxes"
    fi
  fi

  # Revive any dead port forwards (openshell forward --background can die)
  _ensure_forwards

  # Refresh dashboard tokens — sandboxes regenerate them on restart
  _extract_dashboard_tokens
}

# nemoclaw_start — Print connection info for sandboxes
nemoclaw_start() {
  step "NemoClaw — start (connect sandboxes)"

  if ! command -v nemoclaw &>/dev/null; then
    warn "nemoclaw CLI not found — run nemoclaw_install first."
    return 1
  fi

  _nemoclaw_connect_sandbox "hts-ai-openshell-nemoclaw-gpu"

  # Refresh dashboard tokens after (re)connecting sandboxes
  _extract_dashboard_tokens

  ok "NemoClaw sandboxes started."
}

# _nemoclaw_connect_sandbox <name> — Connect a single sandbox (with conflict handling)
_nemoclaw_connect_sandbox() {
  local sandbox="$1"
  local status_out

  status_out=$(NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" status 2>&1 || true)

  if echo "$status_out" | grep -qi "unknown command\|no sandboxes\|not found"; then
    warn "Sandbox '$sandbox' not found — run nemoclaw_onboard first."
    return 0
  fi

  if echo "$status_out" | grep -qi "connected"; then
    echo ""
    warn "NemoClaw sandbox '$sandbox' is already connected."
    echo -e "  ${CYAN}[i]${NC}gnore (default)  ${CYAN}[r]${NC}eplace  ${CYAN}[d]${NC}estroy"
    local choice
    if read -r -t 30 -p "  Choice [i/r/d, 30s timeout → ignore]: " choice 2>/dev/null; then
      choice="${choice,,}"
    else
      echo ""
      info "Timeout — defaulting to ignore"
      choice="i"
    fi
    case "$choice" in
      r|replace)
        info "Replacing $sandbox..."
        NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" disconnect 2>/dev/null || true
        sleep 1
        NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" connect </dev/null &>/dev/null &
        disown
        sleep 2 ;;
      d|destroy)
        warn "Destroying $sandbox..."
        NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" destroy 2>/dev/null || true ;;
      *)
        info "Ignoring $sandbox (already connected)." ;;
    esac
  else
    info "Connecting $sandbox..."
    NEMOCLAW_EXPERIMENTAL=1 nemoclaw "$sandbox" connect </dev/null &>/dev/null &
    disown
    sleep 2
  fi
}

# nemoclaw_stop — Destroy all NemoClaw sandboxes
nemoclaw_stop() {
  step "NemoClaw — stop"
  if ! command -v nemoclaw &>/dev/null; then
    warn "nemoclaw CLI not found"
    return 1
  fi

  local sandboxes
  sandboxes=$(nemoclaw list 2>/dev/null || true)
  if [[ -n "$sandboxes" ]]; then
    while IFS= read -r sandbox; do
      [[ -z "$sandbox" ]] && continue
      [[ "$sandbox" == *"hts-ai-"* ]] || continue
      sandbox=$(echo "$sandbox" | awk '{print $1}')
      warn "Destroying sandbox '${sandbox}'..."
      nemoclaw "$sandbox" destroy --yes 2>/dev/null || true
    done <<< "$sandboxes"
  fi
  ok "NemoClaw sandboxes stopped."
}

# ── Standalone execution ─────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ACTION="default"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --onboard)   ACTION="onboard"; shift ;;
      --configure) ACTION="configure"; shift ;;
      --health)    ACTION="health"; shift ;;
      --start)     ACTION="start"; shift ;;
      --stop)      ACTION="stop"; shift ;;
      --update)    ACTION="update"; shift ;;
      *) shift ;;
    esac
  done

  case "$ACTION" in
    default)
      nemoclaw_install
      _fix_cgroups             # pre-onboard: cgroup v2 system fix
      nemoclaw_onboard         # create sandboxes + post-onboard registry/provider
      nemoclaw_health
      ;;
    start)
      nemoclaw_start
      _ensure_forwards
      _extract_dashboard_tokens
      ;;
    onboard)
      nemoclaw_onboard
      ;;
    configure)
      nemoclaw_configure
      ;;
    health)
      nemoclaw_health
      ;;
    stop)
      nemoclaw_stop
      ;;
    update)
      _update_openclaw
      _ensure_forwards
      _extract_dashboard_tokens
      ;;
  esac
fi
