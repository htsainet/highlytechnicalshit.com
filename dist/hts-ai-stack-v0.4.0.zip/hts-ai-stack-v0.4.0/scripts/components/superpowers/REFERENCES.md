# Superpowers References

- Repo: https://github.com/obra/superpowers
- Docs / README: https://github.com/obra/superpowers#readme
- Installation guide: https://github.com/obra/superpowers#installation
